-- ═══════════════════════════════════════════════════════════════════════
--  Prometheus — усиленный пайплайн STRONG
--
--  Отличается от config.strong.lua одним: HookWatchdog работает в режиме
--  «poison» — при обнаружении хука тихо подменяет результат, вместо того
--  чтобы кидать error() и светиться в консоли исполнителя.
--
--  AntiTamper ПОЛНОСТЬЮ НА МЕСТЕ (UseDebug = true, ExecutorTolerant = true).
--  Раньше его приходилось убирать: он сверял точный текст сообщения error()
--  и принимал обёртку pcall от исполнителя за взлом. Теперь это решено
--  флагом ExecutorTolerant, а не удалением шага — подробности в README,
--  раздел «Режим совместимости с исполнителями».
--
--  Всё остальное на месте: RobloxGuard, RobloxConsoleEcho, IntegrityCheck,
--  HookWatchdog и полная обфускация (Vmify x2, EncryptStrings и т.д.).
--
--  ВАЖНО ПРО ПОРЯДОК ВСТАВКИ: RobloxConsoleEcho и RobloxGuard оба вставляют
--  свой код в самое начало скрипта. Поэтому RobloxConsoleEcho стоит ПЕРВЫМ —
--  тогда итоговый порядок будет: гарда → эхо → Watermark → ваш код.
--  Если поменять их местами, эхо окажется ВПЕРЕДИ гарды.
--
--  Доступные шаги: RobloxGuard, RobloxConsoleEcho, SplitStrings,
--  EncryptStrings, AddVararg, Vmify, AntiTamper, ConstantArray,
--  NumbersToExpressions, Watermark, WatermarkCheck, WrapInFunction
--  (ProxifyLocals НЕ используем — он генерирует битый код)
-- ═══════════════════════════════════════════════════════════════════════

return {
	LuaVersion = "Lua51",          -- "LuaU" для Roblox (базовая поддержка), "Lua51" — стабильнее
	VarNamePrefix = "",
	NameGenerator = "MangledShuffled",
	PrettyPrint = false,
	Seed = 0,

	Steps = {
		------------------------------------------------------------------
		-- 1. ПРОВЕРКИ ROBLOX — ставятся первыми, чтобы их тоже обфусцировало
		------------------------------------------------------------------
		{
			Name = "RobloxConsoleEcho",
			Settings = {
				PoisonVar = "",
				Token = "",                -- пусто = сгенерировать случайный при обфускации
				TokenLength = 24,
				BlockOnFail = false,       -- true = останавливать скрипт, если токен не найден в логе
				ClearConsole = true,       -- вытолкнуть токен из виду после проверки
				ClearLines = 40,
				Action = "spoil",
				ErrorMessage = "This script can only be run inside Roblox",
			},
		},
		{
			Name = "RobloxGuard",
			Settings = {

				-- базовые проверки движка
				CheckGame = true,          -- typeof(game) == "Instance"
				CheckWorkspace = true,     -- typeof(workspace) == "Instance"
				CheckScript = true,        -- typeof(script) == "Instance"
				-- реальные вызовы Roblox API
				CheckService = "Players",  -- game:GetService("Players")
				CheckGuid = true,          -- HttpService:GenerateGUID(false) → 36 символов
				CheckLogService = true,    -- LogService:GetLogHistory() → table
				CheckTerrain = true,       -- typeof(workspace.Terrain) == "Instance"
				CheckRunService = true,    -- RunService:IsStudio() → boolean
				CheckTick = true,          -- typeof(tick()) == "number"
				-- опциональные, ВЫКЛЮЧЕНЫ (могут не пройти в Roblox Studio)
				CheckPlaceId = false,      -- game.PlaceId ~= 0
				CheckJobId = false,        -- game.JobId непустой (в Studio пустой!)
				-- ЛОЖНАЯ ВЕТКА (этап 5, пункт 6). Раньше здесь был "return":
				-- вне Roblox скрипт молча выходил, и это сразу говорило
				-- аналитику «защита сработала, ищи проверку». Теперь скрипт
				-- продолжается и выполняет правдоподобную пустышку.
				Action = "decoy",          -- "return" | "error" | "loop" | "spoil" | "decoy"
				ErrorMessage = "This script can only be run inside Roblox",
				BranchVar = "",            -- флаг ложной ветки; имя подставит build_config.py
			},
		},

		------------------------------------------------------------------
		-- ЛОЖНАЯ ВЕТКА (этап 5, пункт 6).
		--
		-- Стоит ТРЕТЬИМ, и это важно:
		--   • ПОСЛЕ RobloxGuard — иначе флаг взведётся уже после проверки
		--     ветки, и настоящий код выполнится в чужой среде;
		--   • ДО StringPools и Vmify — сканировать надо живой AST (после
		--     Vmify вызовов print там уже нет), а строки пустышки должны
		--     лечь в зашифрованный пул наравне с настоящими.
		--
		-- SkipFirst = 2: два сторожевых блока в начале остаются СНАРУЖИ
		-- ветки. EnvAttest вставит свой блок в позицию 1 позже и тоже
		-- сработает до ветки: он проверяет среду, а не только Roblox.
		{ Name = "FalseBranch", Settings = { BranchVar = "", SkipFirst = 2, Style = "replay", MaxCalls = 24 } },
		-- Этап 5, пункт 7: полезная нагрузка уходит с загрузки на первый кадр.
		-- Стоит строго ПОСЛЕ FalseBranch: тот должен просканировать живой AST,
		-- а этот шаг упаковывает всю программу в функцию, и сканировать
		-- становится нечего. SkipFirst = 0 — внутрь уходит всё, считая гарды.
		{ Name = "DeferActivation", Settings = { SkipFirst = 0 } },
		{
			Name = "WatermarkCheck",
			Settings = { Content = "protected-by-prometheus" },
		},
		{
			-- Периодическая перепроверка хуков (не только на старте)
			Name = "HookWatchdog",
			Settings = {

				Interval = 30,            -- проверять каждый 30-й кадр Heartbeat
				Event = "Heartbeat",
				CheckPcall = true,
				CheckString = true,
				CheckTableMath = true,
				Action = "spoil",        -- тихо: только маркер, без ошибок в консоль
				ErrorMessage = "Integrity check failed",
			},
		},
		{
			-- Контроль целостности таблицы контрольных значений
			Name = "IntegrityCheck",
			Settings = {

				Count = 12,
				MaxValue = 1000000,
				Action = "spoil",
			},
		},

		------------------------------------------------------------------
		-- 2. ОБФУСКАЦИЯ (порядок важен)
		------------------------------------------------------------------
		-- ВАЖНО: StringPools идёт ПЕРЕД SplitStrings. Если наоборот, SplitStrings
		-- режет литералы на куски короче 12 байт, и фильтр длины в пуле (защита
		-- коротких служебных строк вроде "Players") отсекает их вообще все —
		-- тихая порча перестаёт работать.
		{ Name = "StringPools", Settings = { MinPools = 4, MaxPools = 8, GroupByFunction = true, PoisonVar = "" } },
		{ Name = "SplitStrings", Settings = {} },
		{ Name = "AddVararg", Settings = {} },

		-- Проход VM №1 — превращает логику в байткод своей виртуальной машины
				-- Ленивая таблица обработчиков ВКЛЮЧЕНА. Это первый проход Vmify: он
		-- компилирует ИСХОДНУЮ программу, поэтому его дерево переходов — это
		-- граф самого скрипта пользователя. Именно его и надо спрятать.
		{ Name = "Vmify", Settings = { JunkHandlers = 0.05, LazyHandlers = true } },


		-- AntiTamper: UseDebug=true нужен для anti-beautify (детектит
		-- переформатирование), ExecutorTolerant=true отключает проверки,
		-- которые исполнитель ломает сам фактом обёртки pcall/error.
		{ Name = "AntiTamper", Settings = { UseDebug = true, ExecutorTolerant = true, PoisonVar = "" } },

		{
			-- Аттестация среды: не «похоже ли на Roblox», а «не песочница ли
			-- это, не подменены ли функции, не стоит ли хук/трассировщик».
			-- Проверки «десктопности» (io/arg/package) сознательно ВЫКЛЮЧЕНЫ:
			-- исполнители (Delta, Arceus X) предоставляют io и os, и такие
			-- проверки дали бы ложное срабатывание ровно у тех, для кого
			-- скрипт и предназначен.
			Name = "EnvAttest",
			Settings = {
				PoisonVar = "",
				BranchVar = "",
				CheckTypeof = true,
				CheckTask = false,     -- +20 КБ, ~15% сборок не компилируется
				CheckDebugInfo = false,-- +30 КБ; вкл., когда вывод станет Luau-only
				CheckBit32 = false,    -- +20 КБ, ~15% сборок не компилируется
				CheckIdentity = true,      -- game.Workspace == workspace
				CheckGuidFormat = false,   -- +28 КБ; RobloxGuard уже проверяет длину 36
				CheckProxies = true,       -- stdlib-функции должны быть нативными
				CheckHook = true,          -- debug.gethook() == nil
				CheckTraceback = false,-- +45 КБ; самая дорогая, включает осторожно
				CheckDesktop = false,      -- io/arg/package/os.getenv — см. комментарий выше
				Action = "decoy",
			},
		},

		-- Проход VM №2 — поверх уже обфусцированного кода
				-- Здесь ленивая таблица ВЫКЛЮЧЕНА — осознанно, по замерам.
		-- Второй проход Vmify компилирует не программу, а КОД ПЕРВОГО
		-- ИНТЕРПРЕТАТОРА: его дерево переходов описывает однотипный
		-- служебный код, прятать его почти нечего. А платить пришлось бы
		-- дорого: внешний ВМ делает на порядок больше переходов, чем
		-- внутренний, и ленивая таблица на нём стоила 0.76 с против 0.08 с
		-- на демо-скрипте (9.5×). На обоих проходах сразу — 3.74 с (47×).
		-- На внутреннем — 0.22 с (2.75×), и прячет как раз логику скрипта.
		{ Name = "Vmify", Settings = { JunkHandlers = 0.05, LazyHandlers = false } },

		{
			Name = "ConstantArray",
			Settings = {
				Threshold = 1,
				StringsOnly = true,
				Shuffle = true,
				Rotate = true,
				LocalWrapperThreshold = 0,
			
				-- Флаг порчи общий со StringPools
				PoisonVar = "",
				SelfHash = true,
			},
		},
		{
			Name = "NumbersToExpressions",
			Settings = {
				NumberRepresentationMutation = true,
				-- 0.05 = 5% единиц выражаются через состояние VM: (1 - (_cnt() % 1)).
				-- Такое выражение статический свёртчик констант свернуть не может,
				-- а в рантайме оно всегда даёт ровно 1. Больше 0.1 ставить не стоит
				-- — растёт размер и время работы.
				StateNumbersThreshold = 0.05,
			},
		},

		{ Name = "WrapInFunction", Settings = {} },

		-- Этап 5, пункт 3: Luau-only синтаксис. Обычный lua5.1 файл не откроет.
		{ Name = "LuauLock", Settings = { ContinueChance = 1, CompoundChance = 0 } },
	},
}
