-- ═══════════════════════════════════════════════════════════════════════
--  Облегчённый пайплайн — АВАРИЙНЫЙ ЗАПАСНОЙ ВАРИАНТ
--
--  obfuscate.sh автоматически переходит на него, если усиленный Strong
--  несколько раз подряд выдал файл, который не компилируется
--  (ошибки вида "function or expression too complex").
--
--  Обычно править здесь ничего не нужно. Основной конфиг: config.strong.lua
-- ═══════════════════════════════════════════════════════════════════════

return {
	LuaVersion = "Lua51",
	VarNamePrefix = "",
	NameGenerator = "MangledShuffled",
	PrettyPrint = false,
	Seed = 0,

	Steps = {
		{
			Name = "RobloxConsoleEcho",
			Settings = { Token = "", TokenLength = 24, BlockOnFail = false, ClearConsole = true, ClearLines = 40 },
		},
		{
			Name = "RobloxGuard",
			Settings = {
				CheckGame = true,
				CheckWorkspace = true,
				CheckScript = true,
				CheckService = "Players",
				CheckGuid = true,
				CheckLogService = true,
				CheckTerrain = true,
				CheckRunService = true,
				CheckTick = true,
				CheckPlaceId = false,
				CheckJobId = false,
				Action = "return",
			},
		},
		{ Name = "EncryptStrings", Settings = {} },
		{ Name = "Vmify", Settings = {} },
		{
			Name = "ConstantArray",
			Settings = {
				Threshold = 1,
				StringsOnly = true,
				Shuffle = true,
				Rotate = true,
				LocalWrapperThreshold = 0,
			},
		},
		{
			Name = "NumbersToExpressions",
			Settings = { NumberRepresentationMutation = true },
		},
		{ Name = "WrapInFunction", Settings = {} },
	},
}
