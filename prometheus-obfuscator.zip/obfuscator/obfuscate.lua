-- ═══════════════════════════════════════════════════════════════════════════
--  obfuscate.lua — драйвер обфускации на чистом Lua 5.1
--
--  Запускает весь пайплайн в своём же процессе и сам перебирает сиды, пока
--  результат не начнёт компилироваться. Внешних зависимостей нет: ни Python,
--  ни shell-утилит. Нужен только интерпретатор Lua 5.1 — он лежит в ../tools.
--
--  Использование:
--      lua obfuscate.lua [флаги] <вход.lua> <выход.lua>
--
--  Флаги:
--      --preset=strong|executor|fallback   какой конфиг взять (по умолчанию strong)
--      --seed=N                            стартовый сид (по умолчанию случаен)
--      --tries=N                           сколько сидов перебрать (по умолчанию 25)
--      --pretty                            читаемый вывод (слабее защиты!)
--      --no-guard                          убрать проверки Roblox
--      --action=return|error|loop|decoy    реакция гарды на чужую среду
--      --no-verify                         не проверять результат luau-compile
--
--  Про --pretty: читаемая сборка ВСЕГДА слабее. AntiTamper в ней отключается
--  самим обфускатором, и это не наша прихоть, а его логика. Для боевого файла
--  флаг не включать.
-- ═══════════════════════════════════════════════════════════════════════════

local WIN = package.config:sub(1, 1) == "\\"
local SEP = WIN and "\\" or "/"

-- Где лежит этот скрипт. arg[0] в Lua 5.1 — путь к скрипту.
local HERE = (arg and arg[0] or ""):match("^(.-)[/\\]?[^/\\]*$")
if HERE == "" then HERE = "." end

local ROOT = HERE .. SEP .. ".."
local OBF  = HERE                       -- obfuscator/
local SRC  = OBF .. SEP .. "prometheus-lua" .. SEP .. "src"

------------------------------------------------------------------------------
-- Разбор флагов
------------------------------------------------------------------------------
local opts = {
	preset = "strong", seed = nil, tries = 25, pretty = false,
	no_guard = false, action = nil, verify = true,
}
local positional = {}

for _, a in ipairs(arg or {}) do
	if a:sub(1, 2) == "--" then
		local k, v = a:match("^%-%-([%w%-]+)=(.*)$")
		if not k then k = a:sub(3) end
		if k == "pretty" then opts.pretty = true
		elseif k == "no-guard" then opts.no_guard = true
		elseif k == "no-verify" then opts.verify = false
		elseif k == "preset" then opts.preset = v
		elseif k == "action" then opts.action = v
		elseif k == "seed" then opts.seed = tonumber(v)
		elseif k == "tries" then opts.tries = tonumber(v) or 25
		else
			io.stderr:write("неизвестный флаг: " .. a .. "\n")
		end
	elseif a ~= (arg and arg[0]) then
		table.insert(positional, a)
	end
end

if #positional < 2 then
	io.stderr:write(" usage: lua obfuscate.lua [флаги] <вход.lua> <выход.lua>\n")
	os.exit(2)
end
local INPUT, OUTPUT = positional[1], positional[2]

------------------------------------------------------------------------------
-- Чтение файлов
------------------------------------------------------------------------------
local function readfile(path)
	local fh, err = io.open(path, "rb")
	if not fh then return nil, err end
	local data = fh:read("*a")
	fh:close()
	return data
end

local function writefile(path, data)
	local fh, err = io.open(path, "wb")
	if not fh then return nil, err end
	fh:write(data)
	fh:close()
	return true
end

------------------------------------------------------------------------------
-- Путь к luau-compile под текущую платформу
--
-- Проверять результат надо именно Luau, а не Lua 5.1: сборка содержит
-- Luau-only синтаксис (continue, +=), и обычный Lua её не открывает — это
-- часть защиты. Раньше проверка шла через Python; здесь она на os.execute.
------------------------------------------------------------------------------
local function luauCompile()
	local sub = WIN and "windows" or (readfile("/proc/sys/kernel/ostype") == "Linux\n" and "linux" or "macos")
	if not WIN then
		-- /proc есть только на Linux; на macOS его нет, поэтому смотрим uname
		local pipe = io.popen("uname -s 2>nul") or io.popen("uname -s")
		if pipe then
			local os_name = (pipe:read("*a") or ""):lower()
			pipe:close()
			sub = os_name:find("linux") and "linux" or "macos"
		end
	end
	local name = WIN and "luau-compile.exe" or "luau-compile"
	return ROOT .. SEP .. "luau" .. SEP .. sub .. SEP .. name
end

local LUAUC = luauCompile()

local function compiles(path)
	if not opts.verify then return true end
	local q = WIN and '"' or "'"
	local cmd = q .. LUAUC .. q .. " " .. q .. path .. q .. " > " ..
	            (WIN and "NUL" or "/dev/null") .. " 2>" ..
	            (WIN and "NUL" or "/dev/null")
	local code = os.execute(cmd)
	-- os.execute в 5.1 возвращает код, в 5.2+ — true/false. Учитываем оба.
	if type(code) == "boolean" then return code end
	return code == 0
end

------------------------------------------------------------------------------
-- Сборка конфига
--
-- Подстановки текстовые, по одной на ключ. Важно: флаг порчи и флаг ложной
-- ветки получают имена РАЗНОЙ длины (9 и 11 букв), чтобы по виду нельзя было
-- связать два канала реакции. Пустая строка в настройке — шаг выключен.
------------------------------------------------------------------------------
local function random_name(n)
	local t = {}
	for i = 1, n do
		t[i] = string.char(97 + math.random(0, 25))
	end
	return "_" .. table.concat(t)
end

local function build_config(seed)
	local path = OBF .. SEP .. "config." .. opts.preset .. ".lua"
	local text, err = readfile(path)
	if not text then
		error("не могу прочитать конфиг " .. path .. ": " .. tostring(err))
	end

	text = text:gsub("Seed%s*=%s*%-?%d+", "Seed = " .. seed, 1)

	if opts.action then
		text = text:gsub('Action%s*=%s*"[^"]*"', 'Action = "' .. opts.action .. '"')
	end

	-- WatermarkCheck: содержимое метки заменяем случайной строкой, чтобы имя
	-- обфускатора не попадало в выход.
	local wm = {}
	for i = 1, 32 do wm[i] = string.format("%x", math.random(0, 15)) end
	text = text:gsub('Content%s*=%s*"[^"]*"', 'Content = "' .. table.concat(wm) .. '"', 1)

	local poison = random_name(9)
	local n_poison = 0
	text, n_poison = text:gsub('PoisonVar%s*=%s*"[^"]*"', 'PoisonVar = "' .. poison .. '"')

	local branch = random_name(11)
	local n_branch = 0
	text, n_branch = text:gsub('BranchVar%s*=%s*"[^"]*"', 'BranchVar = "' .. branch .. '"')

	if opts.pretty then
		text = text:gsub("PrettyPrint%s*=%s*%a+", "PrettyPrint = true", 1)
	end

	if opts.no_guard then
		text = remove_roblox_guard(text)
	end

	return text, poison, n_poison, branch, n_branch
end

------------------------------------------------------------------------------
-- Вырезание блока RobloxGuard
--
-- Считаем скобки: внутри Settings = { ... } есть вложенные таблицы, и
-- нежадное регулярное выражение обрезало бы блок посередине.
------------------------------------------------------------------------------
function remove_roblox_guard(text)
	local marker = text:find('"RobloxGuard"', 1, true)
	if not marker then return text end

	-- Идём назад от имени шага до открывающей скобки его записи.
	local start = nil
	for i = marker, 1, -1 do
		if text:sub(i, i) == "{" then start = i break end
	end
	if not start then return text end

	-- И от неё — назад до начала строки, чтобы вырезать запись целиком
	-- вместе с отступом.
	local nl = text:sub(1, start):reverse():find("\n", 1, true) or (#text - start + 1)
	local line_start = start - nl + 1

	local depth, finish = 0, nil
	for i = start, #text do
		local c = text:sub(i, i)
		if c == "{" then depth = depth + 1
		elseif c == "}" then
			depth = depth - 1
			if depth == 0 then finish = i break end
		end
	end
	if not finish then return text end

	local j = finish + 1
	while j <= #text and text:sub(j, j):match("[ \t]") do j = j + 1 end
	if text:sub(j, j) == "," then j = j + 1 end
	while j <= #text and text:sub(j, j):match("[ \t]") do j = j + 1 end
	if text:sub(j, j) == "\n" then j = j + 1 end

	return text:sub(1, line_start - 1) .. text:sub(j)
end

------------------------------------------------------------------------------
-- Запуск
------------------------------------------------------------------------------
package.path = SRC .. "/?.lua;" .. package.path

local ok_prom, Prometheus = pcall(require, "prometheus")
if not ok_prom then
	io.stderr:write(" не могу загрузить обфускатор: " .. tostring(Prometheus) .. "\n")
	io.stderr:write(" ожидался каталог: " .. SRC .. "\n")
	os.exit(1)
end

local source, err = readfile(INPUT)
if not source then
	io.stderr:write(" не могу прочитать " .. INPUT .. ": " .. tostring(err) .. "\n")
	os.exit(1)
end

math.randomseed(opts.seed or (os.time() + tonumber(tostring({}):match("0x(%x+)"), 16) or 0))

local base_seed = opts.seed or math.random(1, 2000000000)
local chosen, chosen_seed

io.stdout:write("═══════════════════════════════════════════════════\n")
io.stdout:write(" Обфускация:      " .. INPUT .. "\n")
io.stdout:write(" Пресет:          " .. opts.preset .. "\n")
io.stdout:write(" Выход:           " .. OUTPUT .. "\n")
io.stdout:write("═══════════════════════════════════════════════════\n")

for i = 0, opts.tries - 1 do
	local seed = base_seed + i * 7919
	local cfg_text, poison, n_poison, branch, n_branch = build_config(seed)

	-- Конфиг — это Lua-таблица, поэтому честно вычисляем её, а не парсим.
	local chunk, load_err = loadstring(cfg_text, "=config")
	if not chunk then
		io.stderr:write(" конфиг не читается: " .. tostring(load_err) .. "\n")
		os.exit(1)
	end
	local cfg = chunk()

	-- Лог обфускатора глушим: он печатает по шагу, и это забивает экран.
	Prometheus.Logger.logLevel = Prometheus.Logger.LogLevel.Error
	Prometheus.colors.enabled = false

	local ok, out = pcall(function()
		return Prometheus.Pipeline:fromConfig(cfg):apply(source, INPUT)
	end)

	if ok and out and #out > 0 then
		writefile(OUTPUT, out)
		if compiles(OUTPUT) then
			chosen, chosen_seed = out, seed
			io.stdout:write(string.format(
				" poison-var: %s (%d шаг(а)/(ей))\n", poison, n_poison))
			io.stdout:write(string.format(
				" branch-var: %s (%d шаг(а)/(ей))\n", branch, n_branch))
			break
		end
	end
	chosen = nil
end

if not chosen then
	io.stderr:write(" ══ не удалось собрать файл ни на одном из " .. opts.tries .. " сидов ══\n")
	io.stderr:write(" Попробуйте --tries=60 или другой --seed.\n")
	os.exit(1)
end

io.stdout:write(string.format(
	" Готово: %d б → %d б  (×%.1f)  сид %d\n",
	#source, #chosen, #chosen / math.max(1, #source), chosen_seed))
if opts.pretty then
	io.stdout:write(" ВНИМАНИЕ: --pretty ослабляет защиту (AntiTamper отключается).\n")
end
io.stdout:write(" ═══════════════════════════════════════════════════\n")
