-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- steps.lua
--
-- This Script provides a collection of obfuscation steps.

return {
	WrapInFunction = require("prometheus.steps.WrapInFunction"),
	SplitStrings = require("prometheus.steps.SplitStrings"),
	Vmify = require("prometheus.steps.Vmify"),
	ConstantArray = require("prometheus.steps.ConstantArray"),
	ProxifyLocals = require("prometheus.steps.ProxifyLocals"),
	AntiTamper = require("prometheus.steps.AntiTamper"),
	EncryptStrings = require("prometheus.steps.EncryptStrings"),
	StringPools = require("prometheus.steps.StringPools"),
	NumbersToExpressions = require("prometheus.steps.NumbersToExpressions"),
	AddVararg = require("prometheus.steps.AddVararg"),
	WatermarkCheck = require("prometheus.steps.WatermarkCheck"),
	RobloxGuard = require("prometheus.steps.RobloxGuard"),
	RobloxConsoleEcho = require("prometheus.steps.RobloxConsoleEcho"),
	HookWatchdog = require("prometheus.steps.HookWatchdog"),
	IntegrityCheck = require("prometheus.steps.IntegrityCheck"),
	EnvAttest = require("prometheus.steps.EnvAttest"),
	FalseBranch = require("prometheus.steps.FalseBranch"),
	DeferActivation = require("prometheus.steps.DeferActivation"),
	LuauLock = require("prometheus.steps.LuauLock"),
}