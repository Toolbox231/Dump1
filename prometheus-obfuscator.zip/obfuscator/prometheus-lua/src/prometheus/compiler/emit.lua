-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- emit.lua
--
-- This Script contains the container function body emission for the compiler.

local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local util = require("prometheus.util");
local constants = require("prometheus.compiler.constants");
local AstKind = Ast.AstKind;

local MAX_REGS = constants.MAX_REGS;

return function(Compiler)
    local function hasAnyEntries(tbl)
        return type(tbl) == "table" and next(tbl) ~= nil;
    end

    local function unionLookupTables(a, b)
        local out = {};
        for k, v in pairs(a or {}) do
            out[k] = v;
        end
        for k, v in pairs(b or {}) do
            out[k] = v;
        end
        return out;
    end

    local function canMergeParallelAssignmentStatements(statA, statB)
        if type(statA) ~= "table" or type(statB) ~= "table" then
            return false;
        end

        if statA.usesUpvals or statB.usesUpvals then
            return false;
        end

        local a = statA.statement;
        local b = statB.statement;
        if type(a) ~= "table" or type(b) ~= "table" then
            return false;
        end
        if a.kind ~= AstKind.AssignmentStatement or b.kind ~= AstKind.AssignmentStatement then
            return false;
        end

        if type(a.lhs) ~= "table" or type(a.rhs) ~= "table" or type(b.lhs) ~= "table" or type(b.rhs) ~= "table" then
            return false;
        end

        if #a.lhs ~= #a.rhs or #b.lhs ~= #b.rhs then
            return false;
        end

        -- Avoid merging vararg/call assignments because they can affect multi-return behavior.
        local function hasUnsafeRhs(rhsList)
            for _, rhsExpr in ipairs(rhsList) do
                if type(rhsExpr) ~= "table" then
                    return true;
                end
                local kind = rhsExpr.kind;
                if kind == AstKind.FunctionCallExpression or kind == AstKind.PassSelfFunctionCallExpression or kind == AstKind.VarargExpression then
                    return true;
                end
            end
            return false;
        end
        if hasUnsafeRhs(a.rhs) or hasUnsafeRhs(b.rhs) then
            return false;
        end

        local aReads = type(statA.reads) == "table" and statA.reads or {};
        local aWrites = type(statA.writes) == "table" and statA.writes or {};
        local bReads = type(statB.reads) == "table" and statB.reads or {};
        local bWrites = type(statB.writes) == "table" and statB.writes or {};

        -- Allow merging even if one statement has no writes (e.g., x = o(x) style assignments)
        -- Only require that at least one of them has writes
        if not hasAnyEntries(aWrites) and not hasAnyEntries(bWrites) then
            return false;
        end

        for r in pairs(aReads) do
            if bWrites[r] then
                return false;
            end
        end

        for r, b in pairs(aWrites) do
            if bWrites[r] or bReads[r] then
                return false;
            end
        end

        return true;
    end

    local function mergeParallelAssignmentStatements(statA, statB)
        local lhs = {};
        local rhs = {};
        local aLhs, bLhs = statA.statement.lhs, statB.statement.lhs;
        local aRhs, bRhs = statA.statement.rhs, statB.statement.rhs;
        for i = 1, #aLhs do lhs[i] = aLhs[i]; end
        for i = 1, #bLhs do lhs[#aLhs + i] = bLhs[i]; end
        for i = 1, #aRhs do rhs[i] = aRhs[i]; end
        for i = 1, #bRhs do rhs[#aRhs + i] = bRhs[i]; end

        return {
            statement = Ast.AssignmentStatement(lhs, rhs),
            writes = unionLookupTables(statA.writes, statB.writes),
            reads = unionLookupTables(statA.reads, statB.reads),
            usesUpvals = statA.usesUpvals or statB.usesUpvals,
        };
    end

    local function mergeAdjacentParallelAssignments(blockstats)
        local merged = {};
        local i = 1;
        while i <= #blockstats do
            local stat = blockstats[i];
            i = i + 1;

            while i <= #blockstats and canMergeParallelAssignmentStatements(stat, blockstats[i]) do
                stat = mergeParallelAssignmentStatements(stat, blockstats[i]);
                i = i + 1;
            end

            table.insert(merged, stat);
        end
        return merged;
    end

    function Compiler:emitContainerFuncBody()
        local blocks = {};

        util.shuffle(self.blocks);

        for i, block in ipairs(self.blocks) do
            local id = block.id;
            local blockstats = block.statements;

            for i = 2, #blockstats do
                local stat = blockstats[i];
                local reads = stat.reads;
                local writes = stat.writes;
                local maxShift = 0;
                local usesUpvals = stat.usesUpvals;
                for shift = 1, i - 1 do
                    local stat2 = blockstats[i - shift];

                    if stat2.usesUpvals and usesUpvals then
                        break;
                    end

                    local reads2 = stat2.reads;
                    local writes2 = stat2.writes;
                    local f = true;

                    for r, b in pairs(reads2) do
                        if(writes[r]) then
                            f = false;
                            break;
                        end
                    end

                    if f then
                        for r, b in pairs(writes2) do
                            if(writes[r]) then
                                f = false;
                                break;
                            end
                            if(reads[r]) then
                                f = false;
                                break;
                            end
                        end
                    end

                    if not f then
                        break
                    end

                    maxShift = shift;
                end

                local shift = math.random(0, maxShift);
                for j = 1, shift do
                    blockstats[i - j], blockstats[i - j + 1] = blockstats[i - j + 1], blockstats[i - j];
                end
            end

            local mergedBlockStats = mergeAdjacentParallelAssignments(blockstats);
            for _=1, 7 do
                mergedBlockStats = mergeAdjacentParallelAssignments(mergedBlockStats);
            end

            blockstats = {};
            for _, stat in ipairs(mergedBlockStats) do
                table.insert(blockstats, stat.statement);
            end

            local block = { id = id, index = i, block = Ast.Block(blockstats, block.scope) }
            table.insert(blocks, block);
            blocks[id] = block;
        end

        table.sort(blocks, function(a, b) return a.id < b.id end);

        ------------------------------------------------------------------
        -- Мусорные обработчики (этап 5, пункт 3).
        --
        -- Мёртвые блоки подмешиваются к настоящим. Читающий диспетчер
        -- аналитик не может отличить их от рабочих: тот же вид кода, те же
        -- регистры, в конце — такой же переход. Но ни один переход не ведёт
        -- на их id, поэтому они не выполняются никогда.
        --
        -- id берутся из того же диапазона, что и настоящие (см.
        -- Compiler:createBlock — math.random(0, 2^24)), поэтому мёртвые
        -- блоки перемешаны с живыми и по порядку, и по значению.
        ------------------------------------------------------------------
        if self.JunkHandlers and self.JunkHandlers > 0 and #blocks > 0 then
            local junkCount = math.floor(#blocks * self.JunkHandlers + 0.5);

            -- Регистры, у которых уже есть переменные в области контейнера.
            -- MAX_REGS — это таблица, а не регистр, её пропускаем.
            local regVars = {};
            for i, var in pairs(self.registerVars) do
                if i ~= MAX_REGS then
                    table.insert(regVars, var);
                end
            end

            if junkCount > 0 and #regVars >= 2 then
                local realIds = {};
                for _, b in ipairs(blocks) do
                    table.insert(realIds, b.id);
                end

                for _ = 1, junkCount do
                    local jid;
                    repeat
                        jid = math.random(0, 2 ^ 24);
                    until not self.usedBlockIds[jid];
                    self.usedBlockIds[jid] = true;

                    local jScope = Scope:new(self.containerFuncScope);
                    local stmts = {};

                    -- Тело: несколько присваиваний между регистрами.
                    -- Только арифметика над числами — если блок по какой-то
                    -- причине всё же выполнится, он не уронит скрипт.
                    for _ = 1, math.random(1, 3) do
                        local a = regVars[math.random(1, #regVars)];
                        local b = regVars[math.random(1, #regVars)];
                        jScope:addReferenceToHigherScope(self.containerFuncScope, a);
                        jScope:addReferenceToHigherScope(self.containerFuncScope, b);

                        local expr = Ast.VariableExpression(self.containerFuncScope, b);
                        local style = math.random(1, 3);
                        if style == 2 then
                            expr = Ast.AddExpression(expr, Ast.NumberExpression(math.random(1, 4096)));
                        elseif style == 3 then
                            expr = Ast.MulExpression(expr, Ast.NumberExpression(math.random(1, 8)));
                        end

                        table.insert(stmts, Ast.AssignmentStatement(
                            { Ast.AssignmentVariable(self.containerFuncScope, a) },
                            { expr }
                        ));
                    end

                    -- Такой же переход, как у настоящего блока: выглядит
                    -- правдоподобно, а заодно страхует от зависания.
                    jScope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
                    table.insert(stmts, Ast.AssignmentStatement(
                        { Ast.AssignmentVariable(self.containerFuncScope, self.posVar) },
                        { Ast.NumberExpression(realIds[math.random(1, #realIds)]) }
                    ));

                    table.insert(blocks, { id = jid, index = -1, block = Ast.Block(stmts, jScope) });
                end

                table.sort(blocks, function(a, b) return a.id < b.id end);
            end
        end

        -- Build a strict threshold condition between adjacent block IDs.
        -- Using a midpoint avoids exact-id comparisons while preserving dispatch.
        local function buildBlockThresholdCondition(scope, leftId, rightId, useAndOr)
            local bound = math.floor((leftId + rightId) / 2);
            local posExpr = self:pos(scope);
            local boundExpr = Ast.NumberExpression(bound);

            if useAndOr then
                -- Kept for compatibility with caller variations.
                return Ast.LessThanExpression(posExpr, boundExpr);
            else
                local variant = math.random(1, 2);
                if variant == 1 then
                    return Ast.LessThanExpression(posExpr, boundExpr);
                else
                    return Ast.GreaterThanExpression(boundExpr, posExpr);
                end
            end
        end

        -- Build an elseif chain for a range of blocks
        local function buildElseifChain(tb, l, r, pScope)
            -- Handle invalid range by returning an empty block
            if r < l then
                local emptyScope = Scope:new(pScope);
                return Ast.Block({}, emptyScope);
            end

            local len = r - l + 1;

            -- For single block
            if len == 1 then
                tb[l].block.scope:setParent(pScope);
                return tb[l].block;
            end

            -- For small ranges, use elseif chain
            if len <= 4 then
                local ifScope = Scope:new(pScope);
                local elseifs = {};

                -- First block uses the first midpoint threshold
                tb[l].block.scope:setParent(ifScope);
                local firstCondition = buildBlockThresholdCondition(ifScope, tb[l].id, tb[l + 1].id, false);
                local firstBlock = tb[l].block;

                -- Middle blocks use their upper midpoint threshold
                for i = l + 1, r - 1 do
                    tb[i].block.scope:setParent(ifScope);
                    local condition = buildBlockThresholdCondition(ifScope, tb[i].id, tb[i + 1].id, false);
                    table.insert(elseifs, {
                        condition = condition,
                        body = tb[i].block
                    });
                end

                -- Last block becomes else
                tb[r].block.scope:setParent(ifScope);
                local elseBlock = tb[r].block;

                return Ast.Block({
                    Ast.IfStatement(firstCondition, firstBlock, elseifs, elseBlock);
                }, ifScope);
            end

            -- For larger ranges, use binary split with and/or chaining
            local mid = l + math.ceil(len / 2);
            local leftMaxId = tb[mid - 1].id;
            local rightMinId = tb[mid].id;
            -- Float-safe split: any bound strictly between adjacent IDs works.
            -- Midpoint avoids integer-only math.random(min, max) behavior.
            local bound = math.floor((leftMaxId + rightMinId) / 2);
            local ifScope = Scope:new(pScope);

            local lBlock = buildElseifChain(tb, l, mid - 1, ifScope);
            local rBlock = buildElseifChain(tb, mid, r, ifScope);

            -- Randomly choose between different condition styles
            local condStyle = math.random(1, 3);
            local condition;
            local trueBlock, falseBlock;

            if condStyle == 1 then
                -- pos < bound
                condition = Ast.LessThanExpression(self:pos(ifScope), Ast.NumberExpression(bound));
                trueBlock, falseBlock = lBlock, rBlock;
            elseif condStyle == 2 then
                -- bound > pos
                condition = Ast.GreaterThanExpression(Ast.NumberExpression(bound), self:pos(ifScope));
                trueBlock, falseBlock = lBlock, rBlock;
            else
                -- Equivalent split using strict > with branches reversed.
                condition = Ast.GreaterThanExpression(self:pos(ifScope), Ast.NumberExpression(bound));
                trueBlock, falseBlock = rBlock, lBlock;
            end

            return Ast.Block({
                Ast.IfStatement(condition, trueBlock, {}, falseBlock);
            }, ifScope);
        end

        ------------------------------------------------------------------
        -- Ленивая таблица обработчиков (этап 5, пункт 3).
        --
        -- Раньше диспетчер был статическим деревом if/elseif по id блока.
        -- Прочитав его, аналитик получал весь граф переходов, не запуская
        -- скрипт: сразу видно, какая ветка при каком pos берётся, где у
        -- цикла проверка, а где тело.
        --
        -- Теперь диспетчер — таблица СТРОИТЕЛЕЙ. Обработчик создаётся только
        -- когда выполнение впервые доходит до его блока, и строитель при этом
        -- съедается (B[k] = nil). Отсюда три следствия:
        --
        --   • статически дерева переходов больше нет — только «ключ →
        --     строитель». Чтобы найти нужный ключ, надо сначала вычислить
        --     адрес перехода, а он зависит от состояния VM (pos = id -
        --     (cnt() % 1)), то есть свёрткой констант не берётся;
        --   • в отладчике таблица H содержит лишь УЖЕ выполненные блоки.
        --     Непройденные ветки (обработчики ошибок, лимитные проверки)
        --     не существуют как объекты до первого захода в них;
        --   • строитель одноразовый: кто не успел, тот не увидит.
        --
        -- Шифр ключа: k = p * K + A. Строитель регистрируется по k(id),
        -- диспетчер ищет по k(pos). K нечётное → отображение взаимно
        -- однозначно на целых. id ≤ 2^24, K ≤ 2^16 → произведение порядка
        -- 2^40, точно представимо в double: никакого расхождения между
        -- значением, посчитанным при сборке, и посчитанным в рантайме.
        ------------------------------------------------------------------
        local function buildLazyDispatcher(tb)
            local K = math.random(3, 32767) * 2 + 1;   -- нечётное
            local A = math.random(1, 16777216);        -- 2^24

            -- Таблицы и функция поиска живут в области контейнера:
            -- обработчики замыкают на них как на upvalue.
            local handlersVar  = self.containerFuncScope:addVariable();
            local buildersVar  = self.containerFuncScope:addVariable();
            local lookupVar    = self.containerFuncScope:addVariable();
            self.diagPrintVar_isPrint = true;

            local entries = {};

            for _, b in ipairs(tb) do
                local stmts = b.block.statements;

                -- Запись в pos — это и есть переход. Физически она может
                -- стоять не последней (например, перед setReturn), но в
                -- исходной схеме все операторы блока всё равно выполнялись
                -- подряд, до выхода из тела цикла. Поэтому операторы
                -- оставляем на месте, а найденную запись вынимаем.
                -- ВАЖНО: искать надо и среди ПАРАЛЛЕЛЬНЫХ присваиваний.
                -- mergeAdjacentParallelAssignments выше склеивает соседние
                -- присваивания, и запись в pos регулярно оказывается второй
                -- целью: `A, U = m > S, 13285934`. Детектор, который смотрит
                -- только на #lhs == 1, такой переход не видит, ставит в конец
                -- `return nil` — и цикл обрывается на первом же блоке.
                local posIdx, posRhs, posSlot = nil, nil, nil;
                for i = #stmts, 1, -1 do
                    local st = stmts[i];
                    if st.kind == AstKind.AssignmentStatement then
                        for j, lhs in ipairs(st.lhs) do
                            if lhs.kind == AstKind.AssignmentVariable
                                and lhs.id == self.posVar then
                                posIdx, posSlot = i, j;
                                posRhs = st.rhs[j];
                                break;
                            end
                        end
                        if posIdx then break end
                    end
                end

                -- Единственный случай, когда оператор с записью в pos
                -- выбрасывается: pos там единственная цель. Иначе оператор
                -- обязан остаться на своём месте — см. комментарий ниже.
                local dropPosStmt = posIdx and #stmts[posIdx].lhs == 1;
                local body = {};
                for i, st in ipairs(stmts) do
                    if not (dropPosStmt and i == posIdx) then
                        table.insert(body, st);
                    end
                end

                -- Переход становится возвратом: обработчик отдаёт СЛЕДУЮЩИЙ
                -- адрес, диспетчер сам пишет его в pos.
                if dropPosStmt then
                    -- pos — единственная цель: оператор убираем совсем,
                    -- а его правую часть отдаём наружу.
                    table.insert(body, Ast.ReturnStatement{ posRhs });
                elseif posIdx then
                    -- оператор уже стоит в body на своём месте; здесь
                    -- pos записан в параллельном присваивании вместе с
                    -- другими переменными (`q, F = A, 3378755`). Убирать
                    -- оператор нельзя — потеряются соседние цели, а ВЫНОСИТЬ
                    -- его в конец тоже нельзя: следующие операторы блока
                    -- читают эти самые переменные (`p = A > q`), и от
                    -- перестановки они получают nil. Поэтому все операторы
                    -- идут в исходном порядке, а в конец добавляется только
                    -- чтение pos.
                    -- Этот кейс — не редкость: mergeAdjacentParallelAssignments
                    -- регулярно склеивает setPos с соседним присваиванием.
                    table.insert(body, Ast.ReturnStatement{ self:pos(b.block.scope) });
                else
                    -- Записи в pos не было вовсе (тупиковый блок) — выходим.
                    table.insert(body, Ast.ReturnStatement{ Ast.NilExpression() });
                end

                -- Область функции-обработчика: родитель — контейнер, тело —
                -- прежняя область блока. Переподключаем, чтобы upvalue
                -- считались от обработчика, а не напрямую от контейнера.
                local handlerScope = Scope:new(self.containerFuncScope);
                b.block.scope:setParent(handlerScope);
                local handler = Ast.FunctionLiteralExpression(
                    {}, Ast.Block(body, b.block.scope)
                );

                -- Строитель: пустая обёртка. Внутренняя функция не создаётся,
                -- пока строителя не вызовут — в этом и есть ленивость.
                local builderScope = Scope:new(self.containerFuncScope);
                local builder = Ast.FunctionLiteralExpression({}, Ast.Block({
                    Ast.ReturnStatement{ handler }
                }, Scope:new(builderScope)));

                table.insert(entries, Ast.KeyedTableEntry(
                    Ast.NumberExpression(b.id * K + A), builder
                ));
            end

            -- Поиск ВСТРОЕН в цикл, отдельной функции lookup нет:
            --
            --   while pos do
            --       local k = pos * K + A
            --       local h = H[k]
            --       if h == nil then
            --           h = B[k]
            --           if h ~= nil then
            --               h = h()      -- построить при первом заходе
            --               H[k] = h
            --               B[k] = nil   -- строитель одноразовый
            --           end
            --       end
            --       pos = h and h() or nil
            --   end
            --
            -- Два решения, каждое из которых принято по результатам замеров.
            --
            -- 1. ПОЧЕМУ ВСТРОЕНО, а не функцией. Отдельный lookup(k) — это
            --    лишний вызов на каждый шаг ВМ. Пайплайн делает Vmify дважды,
            --    проходы вложены, и накладные расходы перемножались: 0.08 с
            --    против 5.35 с на демо-скрипте. Встроенная схема оставляет
            --    ровно один вызов — сам обработчик: 5.35 с → 0.4 с.
            --
            -- 2. ПОЧЕМУ НЕТ ЛИШНЕЙ ЛОКАЛИ. В первой версии было
            --    `local b = B[k]`, и генератор имён периодически давал ей то
            --    же имя, что и параметру-ключу: получалось `local z = W[z]`,
            --    после чего `H[z] = h` и `B[z] = nil` писали по ключу-ФУНКЦИИ.
            --    Мемоизация молча ломалась, строитель не съедался, обработчик
            --    пересобирался на каждом заходе. Теперь внутри ровно одна
            --    локальная (h) плюс ключ (k), и затенение невозможно.
            --
            -- `break` не нужен: если строителя нет, h остаётся nil, pos
            -- становится nil, и цикл встаёт сам.

            local hVar = self.whileScope:addVariable();

            -- local function lookup(k)
            --     local h = H[k]
            --     if h == nil and B[k] ~= nil then
            --         h = B[k]()      -- обработчик строится при первом заходе
            --         H[k] = h
            --         B[k] = nil      -- строитель одноразовый
            --     end
            --     return h
            -- end
            --
            -- ВАЖНО: здесь ровно ОДНА локальная переменная внутри, и она не
            -- может затенять параметр-ключ. В первой версии был `local b = B[k]`,
            -- и генератор имён периодически давал ей то же имя, что и ключу:
            -- получалось `local z = W[z]`, после чего `H[z] = h` и `B[z] = nil`
            -- писали по ключу-ФУНКЦИИ. Мемоизация молча ломалась, строитель не
            -- съедался, и обработчик пересобирался на каждом заходе.
            -- Поиск ВСТРОЕН в цикл, отдельной функции lookup нет.
            --
            -- Первая версия вызывала lookup(k) на каждой диспетчеризации —
            -- это лишний вызов на каждый шаг ВМ. На вложенных проходах
            -- (пайплайн делает Vmify дважды) накладные расходы
            -- перемножаются: замеры давали 0.08 с → 5.35 с. Встроенная
            -- схема оставляет ровно один вызов — сам обработчик:
            --
            --   while pos do
            --       local k = pos * K + A
            --       local h = H[k]
            --       if h == nil then
            --           h = B[k]
            --           if h ~= nil then
            --               h = h()      -- построить при первом заходе
            --               H[k] = h
            --               B[k] = nil   -- строитель одноразовый
            --           end
            --       end
            --       pos = h and h() or nil
            --   end
            --
            -- `break` здесь не нужен: если строителя нет, h остаётся nil,
            -- pos становится nil, и цикл встаёт сам.
            local keyVar = self.whileScope:addVariable();
            local keyInit = Ast.AddExpression(
                Ast.MulExpression(self:pos(self.whileScope), Ast.NumberExpression(K)),
                Ast.NumberExpression(A)
            );

            local bScope = Scope:new(self.whileScope);
            local bInner = Scope:new(bScope);

            local whileStmt = Ast.WhileStatement(
                Ast.Block({
                    Ast.LocalVariableDeclaration(self.whileScope, { keyVar }, { keyInit }),
                    Ast.LocalVariableDeclaration(self.whileScope, { hVar }, {
                        Ast.IndexExpression(
                            Ast.VariableExpression(self.containerFuncScope, handlersVar),
                            Ast.VariableExpression(self.whileScope, keyVar)
                        )
                    }),
                    Ast.IfStatement(
                        Ast.EqualsExpression(
                            Ast.VariableExpression(self.whileScope, hVar),
                            Ast.NilExpression()
                        ),
                        Ast.Block({
                            Ast.AssignmentStatement(
                                { Ast.AssignmentVariable(self.whileScope, hVar) },
                                { Ast.IndexExpression(
                                    Ast.VariableExpression(self.containerFuncScope, buildersVar),
                                    Ast.VariableExpression(self.whileScope, keyVar)
                                ) }
                            ),
                            Ast.IfStatement(
                                Ast.NotEqualsExpression(
                                    Ast.VariableExpression(self.whileScope, hVar),
                                    Ast.NilExpression()
                                ),
                                Ast.Block({
                                    Ast.AssignmentStatement(
                                        { Ast.AssignmentVariable(self.whileScope, hVar) },
                                        { Ast.FunctionCallExpression(
                                            Ast.VariableExpression(self.whileScope, hVar), {}
                                        ) }
                                    ),
                                    Ast.AssignmentStatement(
                                        { Ast.AssignmentIndexing(
                                            Ast.VariableExpression(self.containerFuncScope, handlersVar),
                                            Ast.VariableExpression(self.whileScope, keyVar)
                                        ) },
                                        { Ast.VariableExpression(self.whileScope, hVar) }
                                    ),
                                    -- Съедаем строителя: повторно его не достать.
                                    Ast.AssignmentStatement(
                                        { Ast.AssignmentIndexing(
                                            Ast.VariableExpression(self.containerFuncScope, buildersVar),
                                            Ast.VariableExpression(self.whileScope, keyVar)
                                        ) },
                                        { Ast.NilExpression() }
                                    ),
                                }, bInner),
                                {}, nil
                            ),
                        }, bScope),
                        {}, nil
                    ),
                    Ast.AssignmentStatement(
                        { self:posAssignment(self.whileScope) },
                        { Ast.OrExpression(
                            Ast.AndExpression(
                                Ast.VariableExpression(self.whileScope, hVar),
                                Ast.FunctionCallExpression(
                                    Ast.VariableExpression(self.whileScope, hVar), {}
                                )
                            ),
                            Ast.NilExpression()
                        ) }
                    ),
                }, self.whileScope),
                self:pos(self.whileScope)
            );

            return {
                handlersVar = handlersVar,
                buildersVar = buildersVar,
                entries     = entries,
                whileStmt   = whileStmt,
            };
        end

        local lazy = nil;
        local whileBody;
        if self.LazyHandlers then
            lazy = buildLazyDispatcher(blocks);
        else
            whileBody = buildElseifChain(blocks, 1, #blocks, self.containerFuncScope);
        end
        if self.whileScope then
            -- Ensure whileScope is properly connected
            self.whileScope:setParent(self.containerFuncScope);
        end

        self.whileScope:addReferenceToHigherScope(self.containerFuncScope, self.returnVar, 1);
        self.whileScope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);

        self.containerFuncScope:addReferenceToHigherScope(self.scope, self.unpackVar);

        local declarations = {
            self.returnVar,
        }

        for i, var in pairs(self.registerVars) do
            if(i ~= MAX_REGS) then
                table.insert(declarations, var);
            end
        end

        local stats = {}

        if self.maxUsedRegister >= MAX_REGS then
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.registerVars[MAX_REGS]}, {Ast.TableConstructorExpression({})}));
        end

        table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, util.shuffle(declarations), {}));

        if lazy then
            -- local H = {}
            -- local B = { [k]=строитель, ... }
            -- local function lookup(k) ... end
            table.insert(stats, Ast.LocalVariableDeclaration(
                self.containerFuncScope, { lazy.handlersVar },
                { Ast.TableConstructorExpression({}) }
            ));
            table.insert(stats, Ast.LocalVariableDeclaration(
                self.containerFuncScope, { lazy.buildersVar },
                { Ast.TableConstructorExpression(lazy.entries) }
            ));
            table.insert(stats, lazy.whileStmt);
        else
            table.insert(stats, Ast.WhileStatement(whileBody, Ast.VariableExpression(self.containerFuncScope, self.posVar)));
        end


        table.insert(stats, Ast.AssignmentStatement({
            Ast.AssignmentVariable(self.containerFuncScope, self.posVar)
        }, {
            Ast.LenExpression(Ast.VariableExpression(self.containerFuncScope, self.detectGcCollectVar))
        }));

        table.insert(stats, Ast.ReturnStatement{
            Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.unpackVar), {
                Ast.VariableExpression(self.containerFuncScope, self.returnVar)
            });
        });

        return Ast.Block(stats, self.containerFuncScope);
    end
end
