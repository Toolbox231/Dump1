-- Custom Step for the Prometheus Obfuscator
--
-- RobloxConsoleEcho.lua
--
-- Prints a random token into the Roblox console, then reads it back through
-- LogService:GetLogHistory() to prove that the real Roblox logging API works.
-- Afterwards the token is wiped from memory and pushed out of view.
--
-- ВАЖНО ПРО ПОРЯДОК: этот шаг вставляет свой код в самое начало скрипта,
-- как и RobloxGuard. Поэтому в конфиге он должен стоять ДО RobloxGuard —
-- иначе гарда окажется не первой. Итоговый порядок: гарда → эхо → ваш код.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");

local RobloxConsoleEcho = Step:extend();
RobloxConsoleEcho.Description = "Prints a random token and verifies it via LogService";
RobloxConsoleEcho.Name = "RobloxConsoleEcho";

RobloxConsoleEcho.SettingsDescriptor = {
	Token = {
		name = "Token",
		description = "The token printed to the console. Leave empty to generate a random one at obfuscation time",
		type = "string",
		default = "",
	},
	TokenLength = {
		name = "TokenLength",
		description = "Length of the randomly generated token",
		type = "number",
		default = 24,
		min = 4,
		max = 200,
	},
	BlockOnFail = {
		name = "BlockOnFail",
		description = "Stop the script if the token was NOT found in the log. Keep OFF unless you are sure: Roblox may not reflect output in GetLogHistory() instantly",
		type = "boolean",
		default = false,
	},
	ClearConsole = {
		name = "ClearConsole",
		description = "Push the token out of view afterwards by printing empty lines",
		type = "boolean",
		default = true,
	},
	ClearLines = {
		name = "ClearLines",
		description = "How many empty lines to print when clearing",
		type = "number",
		default = 40,
		min = 1,
		max = 500,
	},
	Action = {
		name = "Action",
		description = "What to do on failure (only used when BlockOnFail is on)",
		type = "enum",
		values = { "return", "error", "loop", "spoil" },
		default = "return",
	},
	PoisonVar = {
		name = "PoisonVar",
		description = "Global flag for fail-slow mode (Action = 'spoil')",
		type = "string",
		default = "",
	},
	ErrorMessage = {
		name = "ErrorMessage",
		description = "The message thrown when Action is 'error'",
		type = "string",
		default = "This script can only be run inside Roblox",
	},
};

local HEX = "0123456789abcdef";

local function globalRef(ast, name)
	local scope, id = ast.globalScope:resolve(name);
	return Ast.VariableExpression(scope, id);
end

local function randomToken(len)
	local out = {};
	for i = 1, len do
		local idx = math.random(1, #HEX);
		out[i] = HEX:sub(idx, idx);
	end
	return table.concat(out);
end

function RobloxConsoleEcho:init(settings) end

function RobloxConsoleEcho:apply(ast)
	local body = ast.body;
	local typeofRef = globalRef(ast, "typeof");

	local token = self.Token;
	if not token or #token == 0 then
		token = randomToken(self.TokenLength or 24);
	end

	-- do ... end — изолируем свои локальные
	local doScope = Scope:new(body.scope);

	local tokenId = doScope:addVariable();
	local tokenRef = Ast.VariableExpression(doScope, tokenId);
	local tokenAssign = Ast.AssignmentVariable(doScope, tokenId);

	local okId = doScope:addVariable();
	local okRef = Ast.VariableExpression(doScope, okId);
	local okAssign = Ast.AssignmentVariable(doScope, okId);

	local readOkId = doScope:addVariable();
	local readOkRef = Ast.VariableExpression(doScope, readOkId);
	local historyId = doScope:addVariable();
	local historyRef = Ast.VariableExpression(doScope, historyId);

	-- local okRead, history = pcall(function() return game:GetService("LogService"):GetLogHistory() end)
	local funcScope = Scope:new(doScope);
	local readCall = Ast.FunctionCallExpression(
		globalRef(ast, "pcall"),
		{
			Ast.FunctionLiteralExpression({}, Ast.Block({
				Ast.ReturnStatement({
					Ast.PassSelfFunctionCallExpression(
						Ast.PassSelfFunctionCallExpression(
							globalRef(ast, "game"),
							"GetService",
							{ Ast.StringExpression("LogService") }
						),
						"GetLogHistory",
						{}
					)
				})
			}, funcScope))
		}
	);

	-- if okRead and typeof(history) == "table" and #history > 0 then ... end
	--
	-- ВАЖНО: внутри не объявляется ни одного нового local. Генератор имён
	-- переиспользует короткие имена во вложенных областях видимости, и любой
	-- новый local здесь перекрыл бы (затенил) внешнюю переменную token —
	-- тогда сравнение превратилось бы в `X.message == X` и всегда было бы ложью.
	local lastEntry = Ast.IndexExpression(historyRef, Ast.LenExpression(historyRef));

	local ifScope = Scope:new(doScope);
	local verifyBlock = Ast.Block({
		Ast.IfStatement(
			Ast.AndExpression(
				Ast.EqualsExpression(
					Ast.FunctionCallExpression(typeofRef, { Ast.IndexExpression(historyRef, Ast.LenExpression(historyRef)) }),
					Ast.StringExpression("table")
				),
				Ast.EqualsExpression(
					Ast.IndexExpression(Ast.IndexExpression(historyRef, Ast.LenExpression(historyRef)), Ast.StringExpression("message")),
					tokenRef
				),
				false
			),
			Ast.Block({
				Ast.AssignmentStatement({ okAssign }, { Ast.BooleanExpression(true) })
			}, Scope:new(ifScope)),
			{},
			nil
		)
	}, ifScope);

	local verifyCondition = Ast.AndExpression(
		readOkRef,
		Ast.AndExpression(
			Ast.EqualsExpression(
				Ast.FunctionCallExpression(typeofRef, { historyRef }),
				Ast.StringExpression("table")
			),
			Ast.GreaterThanExpression(Ast.LenExpression(historyRef), Ast.NumberExpression(0)),
			false
		),
		false
	);

	local statements = {
		-- local token = "<random>"
		Ast.LocalVariableDeclaration(doScope, { tokenId }, { Ast.StringExpression(token) }),
		-- print(token)
		Ast.FunctionCallStatement(globalRef(ast, "print"), { tokenRef }),
		-- local ok = false
		Ast.LocalVariableDeclaration(doScope, { okId }, { Ast.BooleanExpression(false) }),
		-- local okRead, history = pcall(...)
		Ast.LocalVariableDeclaration(doScope, { readOkId, historyId }, { readCall }),
		Ast.IfStatement(verifyCondition, verifyBlock, {}, nil),
	};

	-- if not ok then <action> end
	if self.BlockOnFail then
		local failScope = Scope:new(doScope);
		local failBlock;
		if self.Action == "error" then
			failBlock = Ast.Block({
				Ast.FunctionCallStatement(globalRef(ast, "error"), { Ast.StringExpression(self.ErrorMessage) })
			}, failScope);
		elseif self.Action == "loop" then
			local loopScope = Scope:new(failScope);
			failBlock = Ast.Block({
				Ast.WhileStatement(Ast.Block({}, Scope:new(loopScope)), Ast.BooleanExpression(true), loopScope)
			}, failScope);
		elseif self.Action == "spoil" and self.PoisonVar and self.PoisonVar ~= "" then
			failBlock = Ast.Block({
				Ast.AssignmentStatement(
					{ globalRef(ast, self.PoisonVar) },
					{ Ast.NumberExpression(math.random(3, 16)) }
				)
			}, failScope);
		else
			failBlock = Ast.Block({ Ast.ReturnStatement({}) }, failScope);
		end
		table.insert(statements, Ast.IfStatement(Ast.NotExpression(okRef, false), failBlock, {}, nil));
	end

	-- token = nil  — стираем след
	table.insert(statements, Ast.AssignmentStatement({ tokenAssign }, { Ast.NilExpression() }));

	-- print(string.rep("\n", N)) — выталкиваем из виду
	if self.ClearConsole then
		-- print(string.rep("\n", N)) — через IndexExpression, а не PassSelf,
		-- иначе получится string:rep(...) (синтаксис метода), что неверно.
		table.insert(statements, Ast.FunctionCallStatement(globalRef(ast, "print"), {
			Ast.FunctionCallExpression(
				Ast.IndexExpression(globalRef(ast, "string"), Ast.StringExpression("rep")),
				{ Ast.StringExpression("\n"), Ast.NumberExpression(self.ClearLines or 40) }
			)
		}));
	end

	table.insert(body.statements, 1, Ast.DoStatement(Ast.Block(statements, doScope)));
end

return RobloxConsoleEcho;
