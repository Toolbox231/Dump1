-- Custom Step for the Prometheus Obfuscator
--
-- HookWatchdog.lua
--
-- Периодически перепроверяет, что критичные функции не подменены (хуки) —
-- не только один раз на старте. Подписывается на RunService.Heartbeat,
-- поэтому проверка идёт событийно, без блокирующего цикла ожидания.
--
-- ВНЕ Roblox вызов game:GetService упадёт внутри pcall — шаг просто ничего
-- не делает. Это нормально: вне Roblox скрипт и так рубит RobloxGuard.
--
-- Совместимость: в Lua 5.1 это debug.getinfo(f).what, в Luau (Roblox)
-- debug.getinfo НЕТ, вместо него debug.info(f, "s") == "=[C]".
-- Детектор выбирает доступный вариант, а если нет ни одного — отключается,
-- чтобы не засыпать консоль ошибками.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local RandomStrings = require("prometheus.randomStrings");

local HookWatchdog = Step:extend();
HookWatchdog.Description = "Periodically re-checks that critical functions are not hooked";
HookWatchdog.Name = "HookWatchdog";

HookWatchdog.SettingsDescriptor = {
	Interval = {
		name = "Interval",
		description = "How many Heartbeat frames between two checks (throttle)",
		type = "number",
		default = 30,
		min = 1,
		max = 100000,
	},
	Event = {
		name = "Event",
		description = "Which RunService event to subscribe to",
		type = "enum",
		values = { "Heartbeat", "RenderStepped", "Stepped" },
		default = "Heartbeat",
	},
	CheckPcall = {
		name = "CheckPcall",
		description = "Verify pcall is still a C function",
		type = "boolean",
		default = true,
	},
	CheckString = {
		name = "CheckString",
		description = "Verify string.char / string.byte / string.sub / string.rep",
		type = "boolean",
		default = true,
	},
	CheckTableMath = {
		name = "CheckTableMath",
		description = "Verify table.concat / math.floor",
		type = "boolean",
		default = true,
	},
	Action = {
		name = "Action",
		description = "What to do when a hook is detected",
		type = "enum",
		values = { "error", "poison", "both", "spoil" },
		default = "both",
	},
	ErrorMessage = {
		name = "ErrorMessage",
		description = "Message thrown when Action includes 'error'",
		type = "string",
		default = "Integrity check failed",
	},
	PoisonVar = {
		name = "PoisonVar",
		description = "Global flag for fail-slow mode (Action = 'spoil')",
		type = "string",
		default = "",
	},
};

function HookWatchdog:init(settings) end

local function globalRef(ast, name)
	local scope, id = ast.globalScope:resolve(name);
	return Ast.VariableExpression(scope, id);
end

local function field(base, name)
	return Ast.IndexExpression(base, Ast.StringExpression(name));
end

local function call(fnRef, args)
	return Ast.FunctionCallExpression(fnRef, args or {});
end

-- type(X) == "..."
local function typeEquals(ast, valueExpr, typeName)
	return Ast.EqualsExpression(
		call(globalRef(ast, "type"), { valueExpr }),
		Ast.StringExpression(typeName)
	);
end

function HookWatchdog:apply(ast)
	local body = ast.body;

	-- Цели для периодической проверки
	local targets = {};
	if self.CheckPcall then
		table.insert(targets, globalRef(ast, "pcall"));
	end
	if self.CheckString then
		table.insert(targets, field(globalRef(ast, "string"), "char"));
		table.insert(targets, field(globalRef(ast, "string"), "byte"));
		table.insert(targets, field(globalRef(ast, "string"), "sub"));
		table.insert(targets, field(globalRef(ast, "string"), "rep"));
	end
	if self.CheckTableMath then
		table.insert(targets, field(globalRef(ast, "table"), "concat"));
		table.insert(targets, field(globalRef(ast, "math"), "floor"));
	end
	if #targets == 0 then
		return;
	end

	local doScope = Scope:new(body.scope);
	local debugRef = globalRef(ast, "debug");
	local getInfoRef = field(debugRef, "getinfo");
	local infoRef = field(debugRef, "info");

	----------------------------------------------------------------------
	-- WATCH(f) -> "C" | что-то ещё. Выбираем доступный способ определения.
	----------------------------------------------------------------------
	local watchId = doScope:addVariable();
	local watchRef = Ast.VariableExpression(doScope, watchId);

	local function buildDetector(scope, build)
		local argId = scope:addVariable();
		local argRef = Ast.VariableExpression(scope, argId);
		return Ast.FunctionLiteralExpression({ argRef }, Ast.Block({
			Ast.ReturnStatement({ build(argRef) })
		}, scope));
	end

	-- вариант 1 (Lua 5.1): debug.getinfo(f).what
	local v1Scope = Scope:new(doScope);
	local detector1 = buildDetector(v1Scope, function(argRef)
		return field(call(getInfoRef, { argRef }), "what");
	end);

	-- вариант 2 (Luau / Roblox): debug.info(f, "s") == "=[C]" and "C" or "Lua"
	local v2Scope = Scope:new(doScope);
	local detector2 = buildDetector(v2Scope, function(argRef)
		return Ast.OrExpression(
			Ast.AndExpression(
				Ast.EqualsExpression(call(infoRef, { argRef, Ast.StringExpression("s") }), Ast.StringExpression("=[C]")),
				Ast.StringExpression("C"),
				false
			),
			Ast.StringExpression("Lua"),
			false
		);
	end);

	-- вариант 3: проверять нечем — всегда считаем функцию «родной»
	local v3Scope = Scope:new(doScope);
	local detector3 = Ast.FunctionLiteralExpression({}, Ast.Block({
		Ast.ReturnStatement({ Ast.StringExpression("C") })
	}, v3Scope));

	local debugIsTable = typeEquals(ast, debugRef, "table");
	local watchExpr = Ast.OrExpression(
		Ast.OrExpression(
			Ast.AndExpression(
				Ast.AndExpression(debugIsTable, typeEquals(ast, getInfoRef, "function"), false),
				detector1,
				false
			),
			Ast.AndExpression(
				Ast.AndExpression(debugIsTable, typeEquals(ast, infoRef, "function"), false),
				detector2,
				false
			),
			false
		),
		detector3,
		false
	);

	----------------------------------------------------------------------
	-- Условие срабатывания: WATCH(f) ~= "C" для любой из целей
	----------------------------------------------------------------------
	local condition = nil;
	for i = 1, #targets do
		local check = Ast.NotEqualsExpression(call(watchRef, { targets[i] }), Ast.StringExpression("C"));
		if condition == nil then
			condition = check;
		else
			condition = Ast.OrExpression(condition, check, false);
		end
	end

	----------------------------------------------------------------------
	-- Тело колбэка Heartbeat
	----------------------------------------------------------------------
	local counterId = doScope:addVariable();
	local counterRef = Ast.VariableExpression(doScope, counterId);
	local counterAssign = Ast.AssignmentVariable(doScope, counterId);

	local poisonScope, poisonId = ast.globalScope:resolve("_" .. RandomStrings.randomString(16));
	local poisonAssign = Ast.AssignmentVariable(poisonScope, poisonId);

	local cbScope = Scope:new(doScope);
	local cbStatements = {
		Ast.AssignmentStatement({ counterAssign }, {
			Ast.AddExpression(counterRef, Ast.NumberExpression(1), false)
		}),
		Ast.IfStatement(
			Ast.NotEqualsExpression(
				Ast.ModExpression(counterRef, Ast.NumberExpression(self.Interval or 30), false),
				Ast.NumberExpression(0)
			),
			Ast.Block({ Ast.ReturnStatement({}) }, Scope:new(cbScope)),
			{},
			nil
		),
	};

	local triggerStatements = {};
	if self.Action == "error" or self.Action == "both" then
		table.insert(triggerStatements, Ast.FunctionCallStatement(
			globalRef(ast, "error"),
			{ Ast.StringExpression(self.ErrorMessage) }
		));
	end
	if self.Action == "poison" or self.Action == "both" then
		table.insert(triggerStatements, Ast.AssignmentStatement({ poisonAssign }, { Ast.NilExpression() }));
	end

	if self.Action == "spoil" and self.PoisonVar and self.PoisonVar ~= "" then
		-- Fail-slow: тихо пишем задержку до начала порчи, без error() и сообщений.
		-- Присваивание завёрнуто в pcall(function() ... end): напрямую Vmify его
		-- не переваривает и умирает без сообщения об ошибке.
		table.insert(triggerStatements, Ast.FunctionCallStatement(
			globalRef(ast, "pcall"),
			{ Ast.FunctionLiteralExpression({}, Ast.Block({
				Ast.AssignmentStatement(
					{ globalRef(ast, self.PoisonVar) },
					{ Ast.NumberExpression(math.random(3, 16)) }
				)
			}, Scope:new(doScope))) }
		));
	end

	table.insert(cbStatements, Ast.IfStatement(
		condition,
		Ast.Block(triggerStatements, Scope:new(cbScope)),
		{},
		nil
	));

	local callback = Ast.FunctionLiteralExpression({}, Ast.Block(cbStatements, cbScope));

	----------------------------------------------------------------------
	-- do ... end
	----------------------------------------------------------------------
	local pcallScope = Scope:new(doScope);
	local subscribe = Ast.PassSelfFunctionCallStatement(
		field(
			Ast.PassSelfFunctionCallExpression(
				globalRef(ast, "game"),
				"GetService",
				{ Ast.StringExpression("RunService") }
			),
			self.Event or "Heartbeat"
		),
		"Connect",
		{ callback }
	);

	table.insert(body.statements, 1, Ast.DoStatement(Ast.Block({
		Ast.LocalVariableDeclaration(doScope, { watchId }, { watchExpr }),
		Ast.LocalVariableDeclaration(doScope, { counterId }, { Ast.NumberExpression(0) }),
		Ast.FunctionCallStatement(globalRef(ast, "pcall"), {
			Ast.FunctionLiteralExpression({}, Ast.Block({ subscribe }, pcallScope))
		}),
	}, doScope)));
end

return HookWatchdog;
