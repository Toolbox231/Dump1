-- Этап 5, пункт 3 — Luau-синтаксис.
--
-- Цель: чтобы файл НЕ открывался обычным lua5.1. Десктопный анализатор
-- вынужден править файл руками, а любая правка ломает line-info (см.
-- AntiTamper) — то есть попытка открыть уже выдаёт себя.
--
-- Что даёт Luau-only синтаксис в этом шаге:
--   * `continue`           — в Lua 5.1 нет вообще, синтаксическая ошибка.
--   * `+=` `-=` `*=` и т.д. — то же самое (печатаются только в режиме LuaU).
--
-- Важно: `continue` печатается анпарсером БЕЗ проверки версии, поэтому
-- работает и при LuaVersion = "Lua51". Составные операторы печатаются только
-- при LuaVersion = "LuaU" — если версия 5.1, они молча превращаются обратно в
-- обычное присваивание, и замок держится на одном `continue`.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local visitast = require("prometheus.visitast");
local util = require("prometheus.util");
local RandomStrings = require("prometheus.randomStrings");

local AstKind = Ast.AstKind;

local LuauLock = Step:extend();
LuauLock.Description = "Вставляет Luau-only синтаксис (continue, составные операторы), из-за которого файл не открывается обычным lua5.1.";
LuauLock.Name = "LuauLock";

LuauLock.SettingsDescriptor = {
	-- Какую долю циклов помечать `continue`.
	ContinueChance = {
		type = "number",
		default = 1,
		min = 0,
		max = 1,
		description = "Доля циклов, в которые вставляется Luau-only `continue`.",
	},
	-- Какую долю подходящих присваиваний превращать в `+=` / `-=`.
	CompoundChance = {
		type = "number",
		default = 0.3,
		min = 0,
		max = 1,
		description = "Доля присваиваний вида x = x + y, превращаемых в x += y (печатается только при LuaVersion = LuaU).",
	},
};

function LuauLock:init(_) end

------------------------------------------------------------------------
-- Условие, которое ВСЕГДА ложно, но статически не сворачивается.
--
-- (cnt() % 1) ~= 0 : счётчик всегда возвращает целое, значит его остаток от
-- деления на 1 всегда равен 0, и условие никогда не выполняется. Доказать это
-- статически нельзя — нужно знать тип возвращаемого значения.
--
-- Прямая константа (`if false then continue end`) была бы вырезана любым
-- свёртчиком констант, а `nil ~= 0`или иная константа читается
-- на глаз.
------------------------------------------------------------------------
local function buildFalseCondition(self, ast, scope)
	local name = "_" .. RandomStrings.randomString(9);
	local Parser = require("prometheus.parser");
	local Enums = require("prometheus.enums");

	return name, function()
		local scope2, id = ast.globalScope:resolve(name);
		scope:addReferenceToHigherScope(ast.globalScope, id);
		return Ast.NotEqualsExpression(
			Ast.ModExpression(
				Ast.FunctionCallExpression(Ast.VariableExpression(scope2, id), {}),
				Ast.NumberExpression(1)
			),
			Ast.NumberExpression(0)
		);
	end;
end

function LuauLock:apply(ast)
	-- ── 1. Счётчик, на котором держится ложное условие ──────────────────
	-- Объявляется один раз, в отдельном do-блоке в начале файла.
	local counterName = "_" .. RandomStrings.randomString(9);
	if self.ContinueChance > 0 then
		local Parser = require("prometheus.parser");
		local Enums = require("prometheus.enums");
		local code = "do\n"
			.. "\tlocal n = 0;\n"
			.. "\t" .. counterName .. " = function()\n"
			.. "\t\tn = n + 1;\n"
			.. "\t\treturn n;\n"
			.. "\tend;\n"
			.. "end";
		local parsed = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code);
		local doStat = parsed.body.statements[1];
		doStat.body.scope:setParent(ast.body.scope);
		table.insert(ast.body.statements, 1, doStat);
	end

	local function counterExpr(scope)
		local gs, id = ast.globalScope:resolve(counterName);
		scope:addReferenceToHigherScope(ast.globalScope, id);
		return Ast.ModExpression(
			Ast.FunctionCallExpression(Ast.VariableExpression(gs, id), {}),
			Ast.NumberExpression(1)
		);
	end

	-- ── 2. `continue` внутрь циклов ────────────────────────────────────
	-- ВАЖНО: блок счётчика вставляем ДО обхода — но обход его не тронет,
	-- потому что единицу внутри `n = n + 1` мы здесь не переписываем
	-- (в отличие от NumbersToExpressions, где это и было причиной
	-- бесконечной рекурсии).
	--
	-- Сам `continue` оборачиваем в `if <ложь> then continue end`: в Luau
	-- `continue` обязан быть последним оператором в блоке, и без обёртки он
	-- изменил бы логику цикла.
	local continueCount = 0;
	if self.ContinueChance > 0 then
		visitast(ast, nil, function(node, data)
			if node.kind == AstKind.WhileStatement
				or node.kind == AstKind.RepeatStatement
				or node.kind == AstKind.ForStatement
				or node.kind == AstKind.ForInStatement then
				if math.random() > self.ContinueChance then
					return;
				end
				local body = node.body;
				if not body or type(body.statements) ~= "table" then
					return;
				end
				local ifScope = Scope:new(body.scope);
				local thenScope = Scope:new(ifScope);
				local cond = counterExpr(ifScope);
				-- ContinueStatement(loop, scope): первый аргумент — сам цикл,
				-- анпарсер его только хранит, но передавать надо узел цикла.
				table.insert(body.statements, Ast.IfStatement(
					cond,
					Ast.Block({ Ast.ContinueStatement(node, thenScope) }, thenScope),
					{},
					nil
				));
				continueCount = continueCount + 1;
			end
		end);
	end

	-- ── 3. `x = x + y` → `x += y` ──────────────────────────────────────
	-- Печатается как составной оператор только при LuaVersion = "LuaU".
	-- При 5.1 анпарсер вернёт обычное присваивание — семантика не ломается
	-- ни в одном из режимов.
	local compoundOps = {
		[AstKind.AddExpression] = AstKind.CompoundAddStatement,
		[AstKind.SubExpression] = AstKind.CompoundSubStatement,
		[AstKind.MulExpression] = AstKind.CompoundMulStatement,
		[AstKind.DivExpression] = AstKind.CompoundDivStatement,
		[AstKind.ModExpression] = AstKind.CompoundModStatement,
	};
	local compoundCount = 0;

	if self.CompoundChance > 0 then
		visitast(ast, nil, function(node, data)
			if node.kind ~= AstKind.AssignmentStatement then
				return;
			end
			if #node.lhs ~= 1 or #node.rhs ~= 1 then
				return;
			end
			local lhs, rhs = node.lhs[1], node.rhs[1];
			if lhs.kind ~= AstKind.AssignmentVariable then
				return;
			end

			-- Нужно выражение вида <та же переменная> <оп> <что-то>.
			-- Свёртчик мог бы упростить `x = x + 1`, но нам важно только
			-- совпадение переменной слева и слева внутри бинарного узла.
			local opKind = compoundOps[rhs.kind];
			if not opKind then
				return;
			end
			local inner = rhs.lhs;
			if not inner or inner.kind ~= AstKind.VariableExpression then
				return;
			end
			if inner.scope ~= lhs.scope or inner.id ~= lhs.id then
				return;
			end
			if math.random() > self.CompoundChance then
				return;
			end

			node.kind = opKind;
			compoundCount = compoundCount + 1;
		end);
	end

	self.continueCount = continueCount;
	self.compoundCount = compoundCount;
end

return LuauLock;
