-- Custom Step for the Prometheus Obfuscator
--
-- FalseBranch.lua
--
-- Этап 5, пункт 6: ЛОЖНАЯ ВЕТКА для чужого окружения.
--
-- Зачем, если уже есть тихая порча
-- --------------------------------
-- Порча решает другую задачу. Её триггер — ПРАВКА ФАЙЛА: аналитик
-- переформатировал скрипт, и результаты тихо расходятся. Там расхождение —
-- именно то, что нужно: он не понимает, сломал ли скрипт сам.
--
-- Но на ЧУЖОЕ ОКРУЖЕНИЕ порча отвечает плохо. В песочнице без Roblox скрипт
-- либо молча выходит (RobloxGuard), либо выдаёт мусор. И то и другое сразу
-- говорит аналитику: «защита сработала, копай дальше». Он ЗНАЕТ, что
-- наткнулся на проверку, и будет её искать.
--
-- Ложная ветка делает наоборот. Скрипт не молчит и не портится — он
-- ЗАПУСКАЕТСЯ и выдаёт правдоподобный результат. Аналитик видит работающую
-- программу и считает, что обошёл защиту. Самое дорогое, что можно ему
-- подсунуть: не ошибка, а уверенность.
--
-- Как устроено
-- ------------
--   [1] RobloxConsoleEcho
--   [2] RobloxGuard      — если это не Roblox, взводит флаг ветки
--   [3] if <флаг> then <ложная ветка> else <настоящая программа> end
--
-- Флаг — ОТДЕЛЬНАЯ глобальная переменная, не та, что у порчи. Иначе
-- окружение и правка файла отвечали бы одинаково, а нужны разные ответы на
-- разные события.
--
-- Ложная ветка строится из самой программы: обходим AST, находим все
-- выводящие вызовы (print/warn/io.write) и повторяем их В ТОМ ЖЕ ПОРЯДКЕ,
-- с теми же строковыми литералами. Всё, что вычисляется в рантайме,
-- заменяется правдоподобной константой из пула литералов программы.
-- Получается тот же по форме вывод: те же строки, то же количество, те же
-- приставки — но без настоящей работы.
--
-- Всё завёрнуто в pcall: ложная ветка НЕ МОЖЕТ упасть, потому что падение —
-- это как раз тот сигнал, который мы здесь убираем.
--
-- Почему шаг стоит третьим, до StringPools и Vmify
-- ------------------------------------------------
-- Сканировать надо настоящий AST. После Vmify программа превращается в
-- данные виртуальной машины, и никаких вызовов print там уже нет — искать
-- нечего. А строки ложной ветки пусть заберёт StringPools: тогда они лежат
-- в зашифрованном пуле наравне с настоящими, и по файлу не видно, где чьи.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");

local FalseBranch = Step:extend();
FalseBranch.Description = "Runs a plausible decoy instead of the real code when the environment check fails";
FalseBranch.Name = "FalseBranch";

local K = Ast.AstKind;

FalseBranch.SettingsDescriptor = {
	BranchVar = {
		name = "BranchVar",
		description = "Global flag set by the environment guards. Empty string disables the step",
		type = "string",
		default = "",
	},
	SkipFirst = {
		name = "SkipFirst",
		description = "How many leading statements stay OUTSIDE the branch (the guards must run first)",
		type = "number",
		default = 2,
		min = 0,
		max = 64,
	},
	Style = {
		name = "Style",
		description = "replay — repeat the program's own output calls; quiet — produce nothing",
		type = "enum",
		values = { "replay", "quiet" },
		default = "replay",
	},
	MaxCalls = {
		name = "MaxCalls",
		description = "Upper bound on the number of replayed output calls",
		type = "number",
		default = 24,
		min = 1,
		max = 256,
	},
	EchoKnown = {
		name = "EchoKnown",
		description = "Replay calls found inside function bodies too (they may never run for real)",
		type = "boolean",
		default = true,
	},
};

-- Глобалы НЕ переименовываются, поэтому на них можно ориентироваться.
local SINKS = { print = true, warn = true };

local function globalName(node)
	if not node or node.kind ~= K.VariableExpression then return nil end
	if not node.scope or not node.scope.isGlobal then return nil end
	return node.scope:getVariableName(node.id);
end

local function isSink(node)
	if not node then return false end
	if node.kind == K.VariableExpression then
		return SINKS[globalName(node)] == true;
	end
	-- io.write — единственный вывод, до которого надо добираться индексом.
	if node.kind == K.IndexExpression then
		return globalName(node.base) == "io"
			and node.index and node.index.kind == K.StringExpression
			and node.index.value == "write";
	end
	return false;
end

function FalseBranch:init(settings) end

------------------------------------------------------------------------------
-- Обход AST. Свой, а не visitast: тому нужен весь AST целиком, а здесь
-- обходить надо ХВОСТ программы, и важен порядок обхода — именно в нём
-- собираются выводящие вызовы.
------------------------------------------------------------------------------

-- Порядок ключей задаёт порядок обхода; для выражений он же — порядок
-- вычисления (левая часть раньше правой).
local EXPR_KEYS = { "lhs", "base", "index", "args", "entries", "value", "condition", "rhs" };

local function walkExpr(node, cb)
	if type(node) ~= "table" or not node.kind then return end
	cb(node);
	for _, key in ipairs(EXPR_KEYS) do
		local v = node[key];
		if type(v) == "table" then
			if v.kind then
				walkExpr(v, cb);
			else
				for _, item in ipairs(v) do walkExpr(item, cb) end
			end
		end
	end
	-- Тела замыканий: обходим, только если разрешено (см. EchoKnown).
	if node.body and node.body.statements then
		cb({ kind = "__body", body = node.body });
	end
end

local BODY_STATEMENT_KINDS = {
	[K.IfStatement] = function(st, out)
		walkExpr(st.condition, out[3]);
		out[1](st.body);
		for _, eif in ipairs(st.elseifs or {}) do
			walkExpr(eif.condition, out[3]);
			out[1](eif.body);
		end
		if st.elsebody then out[1](st.elsebody) end
	end,
	[K.WhileStatement] = function(st, out)
		walkExpr(st.condition, out[3]); out[1](st.body);
	end,
	[K.RepeatStatement] = function(st, out)
		out[1](st.body); walkExpr(st.condition, out[3]);
	end,
	[K.DoStatement] = function(st, out) out[1](st.body) end,
	[K.ForStatement] = function(st, out)
		walkExpr(st.initialValue, out[3]);
		walkExpr(st.finalValue, out[3]);
		walkExpr(st.incrementBy, out[3]);
		out[1](st.body);
	end,
	[K.ForInStatement] = function(st, out)
		for _, e in ipairs(st.expressions or {}) do walkExpr(e, out[3]) end
		out[1](st.body);
	end,
};

local FUNCTION_KINDS = {
	[K.FunctionDeclaration] = true,
	[K.LocalFunctionDeclaration] = true,
};

--- Обойти список операторов. cb(node) вызывается для каждого узла.
--  insideFunction=true, когда мы внутри тела функции: такой код выполнится,
--  только если функцию вызовут.
local function walk(stmts, cb, deferred, insideFunction)
	for _, st in ipairs(stmts) do
		cb(st, insideFunction);

		if BODY_STATEMENT_KINDS[st.kind] then
			BODY_STATEMENT_KINDS[st.kind](st, {
				function(b) if b and b.statements then walk(b.statements, cb, deferred, insideFunction) end end,
				deferred,
				cb,
			});
		elseif FUNCTION_KINDS[st.kind] then
			-- Тело функции кладём в отложенные: выполнится ли оно — неизвестно.
			if st.body and st.body.statements then
				table.insert(deferred, st.body.statements);
			end
		else
			-- Всё остальное: выражения оператора.
			for _, key in ipairs({ "condition", "value" }) do
				walkExpr(st[key], cb);
			end
			-- Замыкание в ПРИСВАИВАНИИ (`local _p = function() ... end`) —
			-- отдельный случай, который раньше не ловился.FUNCTION_KINDS
			-- смотрит только на операторы-объявления функций, а шаг
			-- DeferActivation упаковывает всю программу именно в
			-- присваивание замыкания. Без этой ветки обходчик не видел
			-- ни одного print, и пустышка вырождалась в table.insert.
			for _, e in ipairs(st.expressions or {}) do
				if e and e.kind == K.FunctionLiteralExpression
					and e.body and e.body.statements then
					table.insert(deferred, e.body.statements);
				end
				walkExpr(e, cb);
			end
			for _, e in ipairs(st.args or {}) do walkExpr(e, cb) end
			if st.base then walkExpr(st.base, cb) end
		end
	end
end

------------------------------------------------------------------------------
-- Построение ложной ветки
------------------------------------------------------------------------------

--- Подменить вычисляемые части на правдоподобные константы.
--  Строковые литералы сохраняем: именно они держат форму вывода
--  («Сумма 1..5 = »), без неё ложная ветка сразу видна.
local function shadow(node, pools)
	if node.kind == K.StringExpression
		or node.kind == K.NumberExpression
		or node.kind == K.BooleanExpression
		or node.kind == K.NilExpression then
		return node;
	end

	-- Конкатенация — основной случай: держим литеральные части, меняем только
	-- вычисляемые.  "Сумма = " .. s   ->   "Сумма = " .. <значение из пула>
	if node.kind == K.StrCatExpression then
		return Ast.StrCatExpression(shadow(node.lhs, pools), shadow(node.rhs, pools));
	end

	-- Всё остальное (идентификатор, вызов, индекс, арифметика) — вычисляемое.
	pools.i = pools.i + 1;
	if #pools.strs > 0 then
		return Ast.StringExpression(pools.strs[((pools.i - 1) % #pools.strs) + 1]);
	end
	if #pools.nums > 0 then
		return Ast.NumberExpression(pools.nums[((pools.i - 1) % #pools.nums) + 1]);
	end
	return Ast.NumberExpression(pools.i);
end

function FalseBranch:apply(ast)
	if not self.BranchVar or self.BranchVar == "" then
		return ast;
	end

	local stmts = ast.body.statements;
	local skip = math.min(math.floor(self.SkipFirst or 0), #stmts);

	-- То, что пойдёт под ветку: настоящая программа.
	local real = {};
	for i = skip + 1, #stmts do
		table.insert(real, stmts[i]);
	end
	if #real == 0 then
		return ast;
	end

	----------------------------------------------------------------------
	-- Собираем литералы и выводящие вызовы
	----------------------------------------------------------------------
	local strs, nums, sinks = {}, {}, {};
	local deferred = {};
	local limit = math.floor(self.MaxCalls or 24);

	local function cb(node, insideFunction)
		if not node or not node.kind then return end
		if node.kind == K.StringExpression then
			local v = node.value;
			-- Служебные идентификаторы в выводе выглядят как мусор.
			if type(v) == "string" and #v > 0 and #v < 64 then
				table.insert(strs, v);
			end
		elseif node.kind == K.NumberExpression then
			table.insert(nums, node.value);
		elseif node.kind == K.FunctionCallStatement or node.kind == K.FunctionCallExpression then
			if isSink(node.base) and #sinks < limit then
				table.insert(sinks, node);
			end
		end
	end

	walk(real, cb, deferred, false);
	if self.EchoKnown then
		for _, d in ipairs(deferred) do
			walk(d, cb, {}, true);
		end
	end

	local pools = { strs = strs, nums = nums, i = 0 };

	----------------------------------------------------------------------
	-- Тело ложной ветки
	----------------------------------------------------------------------
	-- gid() отдаёт ДВА значения (область, id). В середине списка аргументов
	-- лишние отбрасываются, и VariableExpression получает id == nil — отсюда
	-- «table index is nil». Поэтому раскладываем явно.
	local tblScope, tblId = self:gid(ast, "table");
	local pcallScope, pcallId = self:gid(ast, "pcall");
	local flagScope, flagId = self:gid(ast, self.BranchVar);

	local branchScope = Scope:new(ast.body.scope);
	local decoyScope = Scope:new(branchScope);
	local elseScope = Scope:new(branchScope);
	local bodyScope = Scope:new(decoyScope);

	local decoyStats = {};

	if self.Style == "replay" then
		if #sinks > 0 then
			for _, s in ipairs(sinks) do
				local args = {};
				for _, a in ipairs(s.args or {}) do
					table.insert(args, shadow(a, pools));
				end
				table.insert(decoyStats, Ast.FunctionCallStatement(s.base, args));
			end
		else
			-- Выводящих вызовов не нашлось (библиотечный скрипт). Полная
			-- тишина выглядит подозрительно, поэтому имитируем работу.
			for _ = 1, 4 do
				table.insert(decoyStats, Ast.FunctionCallStatement(
					Ast.IndexExpression(
						Ast.VariableExpression(tblScope, tblId),
						Ast.StringExpression("insert")
					),
					{ Ast.TableConstructorExpression({}), Ast.NumberExpression(math.random(1, 9)) }
				));
			end
		end
	end

	----------------------------------------------------------------------
	-- Заворачиваем в pcall: ложная ветка не имеет права падать.
	-- Падение — это и есть тот сигнал, который мы здесь убираем.
	----------------------------------------------------------------------
	-- pcall — НА КАЖДЫЙ вызов по отдельности, а не одним на всех.
	--
	-- Сначала была общая обёртка, и это была ошибка: в CLI Luau нет warn,
	-- первый же warn(...) падал, pcall его проглатывал — и весь остальной
	-- вывод пустышки пропадал. Аналитик видел одну строку вместо нормального
	-- вывода и сразу понимал, что перед ним заглушка. Раздельные pcall
	-- дают: что упало — то молча пропустилось, остальное печатается.
	local decoyBody;
	if #decoyStats > 0 then
		local calls = {};
		for _, st in ipairs(decoyStats) do
			table.insert(calls, Ast.FunctionCallStatement(
				Ast.VariableExpression(pcallScope, pcallId),
				{ Ast.FunctionLiteralExpression({}, Ast.Block({ st }, Scope:new(bodyScope))) }
			));
		end
		decoyBody = Ast.Block(calls, decoyScope);
	else
		decoyBody = Ast.Block({}, decoyScope);
	end

	----------------------------------------------------------------------
	-- Сборка ветки
	----------------------------------------------------------------------
	local flagExpr = function() return Ast.VariableExpression(flagScope, flagId) end;

	local branch = Ast.IfStatement(
		flagExpr(),
		decoyBody,
		{},
		Ast.Block(real, elseScope)
	);

	for i = #stmts, skip + 1, -1 do
		table.remove(stmts, i);
	end

	-- Флаг ложен по умолчанию: пока сторож его не взвёл, идёт настоящая
	-- программа. Инициализируем ТОЛЬКО если nil — RobloxGuard идёт по
	-- пайплайну раньше и мог уже взвести флаг; безусловное присваивание
	-- стёрло бы его.
	local initScope = Scope:new(ast.body.scope);
	table.insert(stmts, Ast.IfStatement(
		Ast.EqualsExpression(flagExpr(), Ast.NilExpression()),
		Ast.Block({
			Ast.AssignmentStatement(
				{ Ast.AssignmentVariable(flagScope, flagId) },
				{ Ast.BooleanExpression(false) }
			),
		}, initScope),
		{},
		nil
	));
	table.insert(stmts, branch);

	return ast;
end

--- Надёжное получение глобала: resolve() падает с assert, если имени нет
--- в глобальной области, а нам нужны и те, что программа ни разу не вызвала.
function FalseBranch:gid(ast, name)
	local gs = ast.globalScope;
	if not gs:hasVariable(name) then
		return gs, gs:addVariable(name);
	end
	return gs:resolve(name);
end

return FalseBranch;
