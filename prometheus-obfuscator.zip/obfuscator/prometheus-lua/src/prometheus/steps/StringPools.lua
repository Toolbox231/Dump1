-- StringPools.lua
--
-- Заменяет ЕДИНЫЙ пул строк набором независимых пулов.
-- Что даёт по сравнению со штатным EncryptStrings:
--   * несколько пулов вместо одного глобального STRINGS — аналитик не получает
--     «все строки разом» в одной таблице;
--   * у каждого пула СВОЁ ключевое расписание (LCG-параметры, charmap,
--     начальное значение prevVal) — взлом одного пула не открывает остальные;
--   * ключ на элемент: состояние PRNG и prevVal выводятся из индекса элемента,
--     поэтому одинаковый байт на разных позициях даёт разный шифротекст;
--   * ленивая расшифровка: строка раскрывается при первом обращении и кладётся
--     в кэш;
--   * доступ идет через ФУНКЦИЮ, а не через таблицу с __index — старая слабость
--     `getmetatable(STRINGS).__index` (через неё читался весь кэш раскрытых
--     строк) устранена: метатаблицы нет вообще.

local Step = require("prometheus.step")
local Ast = require("prometheus.ast")
local Parser = require("prometheus.parser")
local Enums = require("prometheus.enums")
local visitast = require("prometheus.visitast")
local util = require("prometheus.util")
local AstKind = Ast.AstKind

local StringPools = Step:extend()
StringPools.Description = "Splits encrypted strings into several independent lazily-decrypted pools with per-element keys."
StringPools.Name = "StringPools"

StringPools.SettingsDescriptor = {
	MinPools = {
		type = "number",
		default = 2,
		min = 1,
		max = 64,
	},
	MaxPools = {
		type = "number",
		default = 8,
		min = 1,
		max = 64,
	},
	GroupByFunction = {
		type = "boolean",
		default = true,
	},
	-- Имя глобального флага отравления. Пусто — порча отключена.
	-- Детекторы (IntegrityCheck, RobloxGuard, HookWatchdog, AntiTamper)
	-- пишут в него число = задержка в обращениях до начала порчи.
	PoisonVar = {
		type = "string",
		default = "",
	},
}

function StringPools:init(_) end

local MASK45 = 35184372088832 -- 2^45

local function primitive_root_257(idx)
	local g, m, d = 1, 128, 2 * idx + 1
	repeat
		g, m, d = g * g * (d >= m and 3 or 1) % 257, m / 2, d % m
	until m < 1
	return g
end

-- Экранирование строки в Lua-литерал
local function luaQuote(s)
	local out = s:gsub(".", function(c)
		local b = string.byte(c)
		if c == "\\" then return "\\\\"
		elseif c == "\"" then return "\\\""
		elseif c == "\n" then return "\\n"
		elseif c == "\r" then return "\\r"
		elseif c == "\t" then return "\\t"
		-- ВАЖНО: ровно 3 цифры. Иначе следующий за escape символ-цифра
		-- «съедается» парсером в тот же escape (\44 + 5 -> \445).
		elseif b < 32 or b > 126 then return string.format("\\%03d", b)
		else return c end
	end)
	return "\"" .. out .. "\""
end

-- Один пул: своё ключевое расписание + свой шифратор/дешифратор.
function StringPools:makePool(usedSeeds)
	local pool = {}

	pool.mul45 = math.random(0, 63) * 4 + 1
	pool.add45 = math.random(0, MASK45 - 1) * 2 + 1
	pool.mul8 = primitive_root_257(math.random(0, 127))
	pool.secret8 = math.random(0, 255)

	-- Множители, через которые индекс элемента вмешивается в ключ.
	pool.kMul45 = math.random(1, 1048576) * 2 + 1
	pool.kMul8 = math.random(1, 4096) * 2 + 1
	pool.kPv = math.random(1, 251)

	pool.state45 = 0
	pool.state8 = 2
	pool.prev = {}

	local floor = math.floor

	local function genSeed()
		local seed
		repeat
			seed = math.random(0, MASK45 - 1)
		until not usedSeeds[seed]
		usedSeeds[seed] = true
		return seed
	end

	local function nextByte()
		if #pool.prev == 0 then
			pool.state45 = (pool.state45 * pool.mul45 + pool.add45) % MASK45
			repeat
				pool.state8 = pool.state8 * pool.mul8 % 257
			until pool.state8 ~= 1
			local r = pool.state8 % 32
			local shift = 13 - (pool.state8 - r) / 32
			local n = floor(pool.state45 / 2 ^ shift) % 4294967296 / 2 ^ r
			local rnd = floor(n % 1 * 4294967296) + floor(n)
			local lo = rnd % 65536
			local hi = (rnd - lo) / 65536
			pool.prev = { lo % 256, (lo - lo % 256) / 256, hi % 256, (hi - hi % 256) / 256 }
		end
		local len = #pool.prev
		local out = pool.prev[len]
		pool.prev[len] = nil
		return out
	end

	-- Шифрование элемента idx. Должно в точности повторять то, что делает
	-- сгенерированный дешифратор.
	function pool:encrypt(str, idx)
		local seed = genSeed()
		pool.prev = {}
		pool.state45 = (seed + idx * self.kMul45) % MASK45
		pool.state8 = (seed + idx * self.kMul8) % 255 + 2
		local out = {}
		local prevVal = (self.secret8 + idx * self.kPv) % 256
		for i = 1, #str do
			local byte = string.byte(str, i)
			out[i] = string.char((byte - (nextByte() + prevVal)) % 256)
			prevVal = byte
		end
		return table.concat(out), seed
	end

	-- Код рантайма пула. Возвращает список строк-строк кода.
	pool.enc = {}
	pool.keys = {}
	pool.index = {}
	pool.values = {}

	-- Кладёт строку в пул, возвращает её индекс (дубликаты внутри пула
	-- складываются в один элемент).
	function pool:put(str)
		local idx = self.index[str]
		if idx then return idx end
		local cipher, seed = self:encrypt(str, #self.values + 1)
		local idx2 = #self.values + 1
		self.values[idx2] = str
		self.enc[idx2] = cipher
		self.keys[idx2] = seed
		self.index[str] = idx2
		return idx2
	end

	return pool
end

-- Можно ли безопасно портить эту строку.
--
-- Решение принимается НА ЭТАПЕ ОБФУСКАЦИИ, а не в рантайме: в рантайме лишний
-- вызов string.find стоит десятки килобайт VM-кода и упирается в предел Lua
-- «control structure too long». Здесь же стоимость нулевая.
--
-- Портить нельзя:
--   * короткие строки — это имена сервисов, ключи, идентификаторы;
--   * строки вида ^[%a_][%w_.:]*$ — идентификаторы и служебные пути
--     ("Players", "game:GetService", "workspace.Terrain"). Испорти такое —
--     программа упадёт, а падение видно: защита снова себя выдаёт.
--
-- Проверено на практике: без этих фильтров на части сидов скрипт вообще
-- замолкал (0 строк вывода), а молчание при правке файла — это и есть
-- главная подсказка для аналитика.
local function isSpoilable(str)
	if type(str) ~= "string" then return false; end
	if #str < 12 then return false; end
	if str:find("^[%a_][%w_.:]*$") then return false; end
	return str:find(" ") ~= nil;
end

-- Общий рантайм: ОДИН комплект служебного кода на все пулы.
-- Размер результата почти не зависит от числа пулов: пулы различаются
-- таблицами параметров и данных, а не копиями машинки. Это принципиально:
-- при копировании машинки в каждый пул цепочка управления VM раздувается
-- и Lua 5.1 падает с «control structure too long» уже на 3 пулах.
function StringPools:genRuntime(pools, poolCount, spoilLimit)
	local L = {}
	local a = function(s) L[#L + 1] = s end
	local poisonName = self.PoisonVar

	a("do")
	a("\tlocal floor = math.floor;")
	a("\tlocal random = math.random;")
	a("\tlocal remove = table.remove;")
	a("\tlocal char = string.char;")
	a("\tlocal byte = string.byte;")

	a("\tlocal charmap = {};")
	a("\tlocal nums = {};")
	a("\tfor i = 1, 256 do nums[i] = i; end;")
	a("\trepeat")
	a("\t\tlocal i = random(1, #nums);")
	a("\t\tlocal n = remove(nums, i);")
	a("\t\tcharmap[n] = char(n - 1);")
	a("\tuntil #nums == 0;")

	-- Своё ключевое расписание у каждого пула
	a("\tlocal P = {")
	for _, pool in ipairs(pools) do
		a("\t\t{ m45 = " .. tostring(pool.mul45)
			.. ", a45 = " .. tostring(pool.add45)
			.. ", m8 = " .. tostring(pool.mul8)
			.. ", s8 = " .. tostring(pool.secret8)
			.. ", k45 = " .. tostring(pool.kMul45)
			.. ", k8 = " .. tostring(pool.kMul8)
			.. ", kpv = " .. tostring(pool.kPv) .. " },")
	end
	a("\t};")

	-- Данные пулов
	a("\tlocal ENC = {")
	for _, pool in ipairs(pools) do
		local e = {}
		for j = 1, #pool.values do e[j] = luaQuote(pool.enc[j]) end
		a("\t\t{ " .. table.concat(e, ",") .. " },")
	end
	a("\t};")
	a("\tlocal KEY = {")
	for _, pool in ipairs(pools) do
		local k = {}
		for j = 1, #pool.values do k[j] = tostring(pool.keys[j]) end
		a("\t\t{ " .. table.concat(k, ",") .. " },")
	end
	a("\t};")

	-- Граница «портимых» строк в каждом пуле: элементы с индексами
	-- 1..SPOILLIM[p] можно портить без риска сломать управление.
	-- Считается на этапе обфускации (см. isSpoilable), поэтому в рантайме
	-- проверка стоит одно сравнение, а не вызов string.find.
	if spoilLimit then
		local lim = {}
		for i = 1, poolCount do lim[i] = tostring(spoilLimit[i] or 0) end
		a("\tlocal SPOILLIM = { " .. table.concat(lim, ",") .. " };")
	end

	a("\tlocal CACHE = {};")
	a("\tfor i = 1, " .. tostring(poolCount) .. " do CACHE[i] = {}; end;")

	-- Общее состояние PRNG; параметры подставляются из текущего пула
	a("\tlocal state45 = 0;")
	a("\tlocal state8 = 2;")
	a("\tlocal prev = {};")
	a("\tlocal curM45 = 1;")
	a("\tlocal curA45 = 0;")
	a("\tlocal curM8 = 1;")
	a("\tlocal function pb()")
	a("\t\tif #prev == 0 then")
	a("\t\t\tstate45 = (state45 * curM45 + curA45) % " .. tostring(MASK45) .. ";")
	a("\t\t\trepeat")
	a("\t\t\t\tstate8 = state8 * curM8 % 257;")
	a("\t\t\tuntil state8 ~= 1;")
	a("\t\t\tlocal r = state8 % 32;")
	a("\t\t\tlocal shift = 13 - (state8 - r) / 32;")
	a("\t\t\tlocal n = floor(state45 / 2 ^ shift) % 4294967296 / 2 ^ r;")
	a("\t\t\tlocal rnd = floor(n % 1 * 4294967296) + floor(n);")
	a("\t\t\tlocal lo = rnd % 65536;")
	a("\t\t\tlocal hi = (rnd - lo) / 65536;")
	a("\t\t\tprev = { lo % 256, (lo - lo % 256) / 256, hi % 256, (hi - hi % 256) / 256 };")
	a("\t\tend;")
	a("\t\tlocal len = #prev;")
	a("\t\tlocal out = prev[len];")
	a("\t\tprev[len] = nil;")
	a("\t\treturn out;")
	a("\tend;")

	-- Общий дешифратор. Ключ зависит и от пула, и от индекса элемента.
	a("\tlocal function GET(p, idx)")
	a("\t\tlocal v = CACHE[p][idx];")
	a("\t\tif v == nil then")
	a("\t\t\tlocal par = P[p];")
	a("\t\t\tprev = {};")
	a("\t\t\tcurM45 = par.m45;")
	a("\t\t\tcurA45 = par.a45;")
	a("\t\t\tcurM8 = par.m8;")
	a("\t\t\tstate45 = (KEY[p][idx] + idx * par.k45) % " .. tostring(MASK45) .. ";")
	a("\t\t\tstate8 = (KEY[p][idx] + idx * par.k8) % 255 + 2;")
	a("\t\t\tlocal s = ENC[p][idx];")
	a("\t\t\tlocal out = \"\";")
	a("\t\t\tlocal pv = (par.s8 + idx * par.kpv) % 256;")
	a("\t\t\tfor i = 1, #s do")
	a("\t\t\t\tpv = (byte(s, i) + pb() + pv) % 256;")
	a("\t\t\t\tout = out .. charmap[pv + 1];")
	a("\t\t\tend;")
	a("\t\t\tCACHE[p][idx] = out;")
	a("\t\t\tv = out;")
	a("\t\tend;")
	-- Отложенная тихая порча. Кэш НЕ трогаем — портится только возвращаемое
	-- значение, поэтому расхождение нарастает постепенно, а не ломает всё сразу.
	if poisonName and poisonName ~= "" then
		a("\t\tif " .. poisonName .. " then")
		a("\t\t\tif type(" .. poisonName .. ") == \"number\" then")
		a("\t\t\t\t" .. poisonName .. " = " .. poisonName .. " - 1;")
		a("\t\t\t\tif " .. poisonName .. " <= 0 then " .. poisonName .. " = true; end;")
			a("\t\t\telseif idx <= SPOILLIM[p] and random(1, 3) == 1 then")
			-- Портим один байт, и только в строках, которые БЕЗОПАСНО портить.
			--
			-- Решение кто «портимый» принято на этапе обфускации (см. isSpoilable
			-- и двухпроходную раскладку): портимые занимают младшие индексы,
			-- поэтому здесь достаточно одного сравнения idx <= SPOILLIM[p].
			-- Рантайм-фильтр через string.find здесь стоил бы десятки
			-- килобайт VM-кода и упирался бы в предел «control structure
			-- too long».
			--
			-- Проверено на практике: без фильтра на части сидов скрипт вообще
			-- замолкал (0 строк вывода), а молчание при правке файла — это и
			-- есть главная подсказка для аналитика.
			a("\t\t\t\tlocal i = (idx % #v) + 1;")
			a("\t\t\t\tlocal b = (byte(v, i) + 1 + (idx % 13)) % 256;")
			a("\t\t\t\tv = v:sub(1, i - 1) .. char(b) .. v:sub(i + 1);")
			a("\t\t\tend;")
		a("\t\tend;")
	end

	a("\t\treturn v;")
	a("\tend;")

	-- Тонкие обёртки: снаружи каждый пул выглядит отдельной функцией
	for i = 1, poolCount do
		a("\tfunction POOL" .. tostring(i) .. "(idx) return GET(" .. tostring(i) .. ", idx); end;")
	end

	-- ── Канал отравления ────────────────────────────────────────────────────
	-- Никаких error() и сообщений. Детектор пишет в флаг ЧИСЛО — это задержка
	-- в обращениях. Пока число не истратится, строка выдаётся нормально, то
	-- есть порча ОТЛОЖЕННАЯ. Затем каждая выдача портит по одному байту:
	-- программа продолжает работать, но результаты постепенно расходятся.
	-- Для аналитика это самое дорогое: он не отличает защиту от бага.
	-- ВАЖНО: инициализируем ТОЛЬКО если флаг ещё nil.
	-- AntiTamper вставляет свой код в начало позже StringPools, поэтому его
	-- проверки выполняются РАНЬШЕ инициализации пулов. Безусловное
	-- `флаг = false` стирало бы уже взведённый детектором трип.
	if poisonName and poisonName ~= "" then
		a("\tif " .. poisonName .. " == nil then " .. poisonName .. " = false; end")
	end

	a("end")
	return L
end

function StringPools:apply(ast, _)
	-- ── Проход 1: собираем строки, группируя по объемлющей функции ──────────
	local groups = {}
	local groupOfNode = {}

	visitast(ast, function(node, data)
		if node.kind == AstKind.StringExpression then
			local fnode
			if self.GroupByFunction and data and data.functionData then
				fnode = data.functionData.node
			else
				fnode = ast
			end
			if fnode == nil then fnode = ast end
			local gi = groupOfNode[fnode]
			if not gi then
				gi = #groups + 1
				groups[gi] = {}
				groupOfNode[fnode] = gi
			end
			table.insert(groups[gi], node)
		end
	end)

	if #groups == 0 then
		return ast
	end

	util.shuffle(groups)

	-- ── Сколько пулов ───────────────────────────────────────────────────────
	local minP, maxP = self.MinPools, self.MaxPools
	if maxP < minP then maxP = minP end
	local poolCount = math.random(minP, maxP)
	if poolCount > #groups then poolCount = #groups end

	-- ── Раскладка групп по пулам ────────────────────────────────────────────
	local usedSeeds = {}
	local pools = {}
	for i = 1, poolCount do
		pools[i] = self:makePool(usedSeeds)
	end

	local assignment = {}
	for gi = 1, #groups do
		assignment[gi] = ((gi - 1) % poolCount) + 1
	end

	-- ── Проход 2: шифруем и строим замену ───────────────────────────────────
	-- Двухпроходная раскладка: сначала кладём строки, которые БЕЗОПАСНО
	-- портить — они занимают младшие индексы 1..spoilLimit[pi]. Тогда в
	-- рантайме проверка сводится к одному сравнению idx <= SPOILLIM[p].
	local replacement = {}
	local spoilLimit = {}
	for pi = 1, poolCount do
		spoilLimit[pi] = 0
	end

	for gi, nodes in ipairs(groups) do
		local pi = assignment[gi]
		for _, node in ipairs(nodes) do
			if isSpoilable(node.value) then
				local idx = pools[pi]:put(node.value)
				replacement[node] = { pool = pi, idx = idx }
				if idx > spoilLimit[pi] then spoilLimit[pi] = idx end
			end
		end
	end

	for gi, nodes in ipairs(groups) do
		local pi = assignment[gi]
		for _, node in ipairs(nodes) do
			if not replacement[node] then
				local idx = pools[pi]:put(node.value)
				replacement[node] = { pool = pi, idx = idx }
			end
		end
	end

	-- ── Генерируем рантайм ──────────────────────────────────────────────────
	local lines = self:genRuntime(pools, poolCount, spoilLimit)
	local code = table.concat(lines, "\n")

	local newAst = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code)
	local doStat = newAst.body.statements[1]

	local scope = ast.body.scope
	local poolVars = {}
	for i = 1, poolCount do
		poolVars[i] = scope:addVariable()
	end

	doStat.body.scope:setParent(scope)

	-- Переименовываем POOLk и таблицы данных enc/keys в локальные переменные.
	visitast(newAst, nil, function(node, data)
		if node.kind == AstKind.FunctionDeclaration then
			local nm = node.scope:getVariableName(node.id)
			for i = 1, poolCount do
				if nm == "POOL" .. tostring(i) then
					data.scope:removeReferenceToHigherScope(node.scope, node.id)
					data.scope:addReferenceToHigherScope(scope, poolVars[i])
					node.scope = scope
					node.id = poolVars[i]
					return
				end
			end
		end
	end)

	-- Объявляем таблицы enc/keys как локальные внутри блока пула.
	-- Их имена в сгенерированном коде: enc<i> / keys<i>.
	-- Подменяем ссылки на локальные переменные области do-блока пула.
	-- (Проще: переименовать генерацию так, чтобы enc/keys были локальными
	--  самого блока пула — это уже так, они объявлены как `local enc = {}`.)
	-- Поэтому дополнительной обработки не требуется.

	-- Заменяем обращения к строкам
	visitast(ast, nil, function(node)
		if node.kind == AstKind.StringExpression then
			local r = replacement[node]
			if r then
				local idxNum = Ast.NumberExpression(r.idx)
				return Ast.FunctionCallExpression(
					Ast.VariableExpression(scope, poolVars[r.pool]),
					{ idxNum }
				)
			end
		end
	end)

	table.insert(ast.body.statements, 1, doStat)
	local decls = {}
	for i = 1, poolCount do decls[i] = poolVars[i] end
	table.insert(ast.body.statements, 1, Ast.LocalVariableDeclaration(scope, util.shuffle(decls), {}))

	return ast
end

return StringPools
