-- Custom Step for the Prometheus Obfuscator
--
-- DeferActivation.lua
--
-- Этап 5, пункт 7: ОТЛОЖЕННАЯ АКТИВАЦИЯ.
--
-- Зачем
-- -----
-- Пока полезный код лежит прямо в теле чанка, он выполняется на загрузке.
-- Это щедрый подарок аналитику: достаточно один раз запустить скрипт в
-- песочнице и снять дамп — вся логика уже отработала, все строки
-- расшифрованы, все состояния видны. Никаких усилий, один прогон.
--
-- Отложенная активация убирает это. Тело чанка только РЕГИСТРИРУЕТ
-- полезную нагрузку и подписывается на событие. Сам код уходит в функцию,
-- которая будет вызвана позже — по кадру. Песочница без цикла событий
-- загрузит скрипт, увидит пустоту и ничего не получит.
--
-- Как устроено
-- ------------
--   local _p = function()
--       <полезная нагрузка — бывшее тело чанка>
--   end
--   local _done = false
--   local _fire = function() if _done then return end _done = true _p() end
--   <активация: кадр → задержка → прямой вызов>
--
-- Три способа активации идут по очереди, от лучшего к последнему:
--
--   1. КАДР (RunService.Heartbeat). Настоящий Roblox дёрнет обработчик
--      на следующем кадре — через ~16 мс. Это основной путь.
--   2. ЗАДЕРЖКА (task.delay). Если события нет или подписка не удалась.
--   3. ПРЯМОЙ ВЫЗОВ. Если нет вообще ничего — исполнитель без task и без
--      рабочей подписки.
--
-- Пункт 3 — страховка, а не слабость. Пользователь запускает скрипт в
-- настоящем исполнителе, и если там окажется среда, где не работает ни
-- Heartbeat, ни task.delay, скрипт обязан всё равно работать: молчащий
-- скрипт пользователь спишет на поломку. Проверки среды (RobloxGuard,
-- EnvAttest, FalseBranch) уже отсекают чужие окружения — этой страховкой
-- воспользоваться может только тот, кто их все прошёл.
--
-- Почему шаг стоит до FalseBranch
-- -------------------------------
-- Шаг заворачивает хвост программы в функцию. FalseBranch, идущий следом,
-- оборачивает всё, что после гардов, в if/else — и получается ровно то, что
-- нужно:
--
--   if <флаг> then <пустышка> else local _p = ... <активация> end
--
-- Полезная нагрузка не выполняется в чужой среде даже отложенно, а
-- настоящая среда получает её на первом кадре. Менять местами нельзя:
-- поставь FalseBranch первым — DeferActivation обнаружит, что после гардов
-- ничего нет, и завернёт пустоту.
--
-- Про vararg
-- ----------
-- Тело чанка переносится внутрь функции. Если в нём был `...`, это теперь
-- vararg функции, а не чанка — при запуске через loadstring разница
-- видна. В обычных скриптах `...` на верхнем уровне не встречается, но
-- знать стоит.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");

local DeferActivation = Step:extend();
DeferActivation.Description = "Defers the real payload to the first frame instead of running it at load time";
DeferActivation.Name = "DeferActivation";

local K = Ast.AstKind;

DeferActivation.SettingsDescriptor = {
	SkipFirst = {
		name = "SkipFirst",
		description = "How many leading statements stay outside the payload. 0 (default) — everything goes inside, which is what keeps the scope depths consistent",
		type = "number",
		default = 0,
		min = 0,
		max = 64,
	},
	Mode = {
		name = "Mode",
		description = "frame — activate on RunService.Heartbeat; delay — on task.delay; both — frame, then delay, then direct call",
		type = "enum",
		values = { "frame", "delay", "both" },
		default = "both",
	},
	DelaySeconds = {
		name = "DelaySeconds",
		description = "Fallback delay before activation if no frame event fired",
		type = "number",
		default = 0.35,
		min = 0,
		max = 60,
	},
	FallbackDirect = {
		name = "FallbackDirect",
		description = "Call the payload directly if neither the frame event nor task.delay is available. ON protects the user from a silently dead script",
		type = "boolean",
		default = true,
	},
	PlaceIds = {
		name = "PlaceIds",
		description = "Comma-separated PlaceId whitelist. Empty — no gating",
		type = "string",
		default = "",
	},
	UserIds = {
		name = "UserIds",
		description = "Comma-separated UserId whitelist (LocalPlayer, if present). Empty — no gating",
		type = "string",
		default = "",
	},
};

local function parseIds(str)
	local out = {};
	if type(str) ~= "string" then return out end
	for part in tostring(str):gmatch("%d+") do
		table.insert(out, tonumber(part));
	end
	return out;
end

-- ВАЖНО: init() вызывается БЕЗ аргументов. Настройки к этому моменту уже
-- разложены по полям самим Step:new — значения по умолчанию подставлены,
-- типы проверены. Поэтому здесь читаем self.X, а не параметр.
function DeferActivation:init()
	self._PlaceIds = parseIds(self.PlaceIds);
	self._UserIds = parseIds(self.UserIds);
end

------------------------------------------------------------------------------
-- Разрешаем глобал, а если его нет — добавляем. Возвращает ДВА значения,
-- поэтому в списках аргументов вызывать нельзя.
------------------------------------------------------------------------------
-- ДВЕ ловушки, и обе уже стоили сборки:
--
--   1. Scope:resolve(name) возвращает ДВА значения — (scope, id), а не одно.
--      Запись `return gs, gs:resolve(name)` отдаёт три, и вызывающий
--      `local s, id = ...` получает в id САМУ ОБЛАСТЬ. Потом
--      VariableExpression(scope=gs, id=gs) молча даёт nil при выводе имени,
--      и всё падает в unparser на склейке строки.
--   2. Лишние возвраты в середине списка аргументов отбрасываются — так
--      VariableExpression получает id == nil.
--
-- Правильно: ветка «переменной нет» и ветка «переменная есть» возвращают
-- ровно по два значения, и ни один вызов не стоит внутри аргументов.
function DeferActivation:gid(ast, name)
	local gs = ast.globalScope;
	if not gs:hasVariable(name) then
		return gs, gs:addVariable(name);
	end
	return gs:resolve(name);
end

local function gref(ast, name)
	local s, id = DeferActivation:gid(ast, name);
	return Ast.VariableExpression(s, id);
end

local function str(s) return Ast.StringExpression(s) end

------------------------------------------------------------------------------
-- game:GetService("RunService").Heartbeat — через IndexExpression, а не
-- через метод с двоеточием: в AST для `a:b()` нужен PassSelf, и ручная
-- сборка без него даёт синтаксически неверный вызов.
------------------------------------------------------------------------------
local function getServiceCall(ast, svc)
	-- НИКАКИХ одиночных присваиваний из resolve(): `local id = gs:resolve(n)`
	-- положит в id саму область, потому что resolve отдаёт (scope, id).
	-- Эта ошибка уже дала «attempt to concatenate local base» в unparser.
	local gameS, gameId = DeferActivation:gid(ast, "game");
	-- game:GetService(...) — настоящий вызов МЕТОДА. Ручная сборка через
	-- IndexExpression + FunctionCallExpression даёт game.GetService(...)
	-- без self, то есть нерабочий вызов.
	return Ast.PassSelfFunctionCallExpression(
		Ast.VariableExpression(gameS, gameId), "GetService", { str(svc) }
	);
end

function DeferActivation:apply(ast, pipeline)
	local stmts = ast.body.statements;
	local skip = math.floor(self.SkipFirst or 2);
	if #stmts <= skip then
		-- Заворачивать нечего.
		return ast;
	end

	----------------------------------------------------------------------
	-- ПЕРЕПОДЧИНЕНИЕ ОБЛАСТИ — это не деталь, а то, без чего шаг не работает.
	--
	-- Тело чанка — область `oldTop`. Именно в ней объявлены все локальные
	-- переменные программы. Если просто перенести операторы внутрь функции,
	-- компилятор зарегистрирует oldTop с глубиной 1 (глубина функции), а
	-- код активации останется на глубине 0 и будет ссылаться на свои же
	-- переменные в oldTop. Одна область, две глубины — и Vmify падает:
	--   «Unresolved Upvalue» (compiler.lua) или
	--   «attempt to compare nil with number» (compile_top.lua).
	--
	-- Выход ровно тот, которым пользуется штатный WrapInFunction: старая
	-- область переподчиняется НОВОЙ, а новая становится областью тела чанка.
	-- Тогда oldTop принадлежит функции (глубина 1), а всё, что осталось
	-- снаружи, живёт в новой области (глубина 0). Конфликта нет.
	----------------------------------------------------------------------
	local oldTop = ast.body.scope;
	local newTop = Scope:new(ast.globalScope);
	oldTop:setParent(newTop);

	----------------------------------------------------------------------
	-- ВСЕ вспомогательные переменные — в ОДНОЙ области, и это НОВАЯ область
	-- тела чанка.
	--
	-- Сначала каждая объявлялась в своём `Scope:new(helperScope)`. Выглядело
	-- аккуратнее, но сломало вывод: четыре дочерние области по одной
	-- переменной — и переименователь дал им всем ОДИНАКОВОЕ имя. В выводе
	-- получалось четыре `local U` подряд в одном блоке, они перекрывали друг
	-- друга, и `_fire` вызывал уже не то, что нужно.
	----------------------------------------------------------------------
	local helperScope = newTop;

	-- Вся программа целиком уходит в функцию — вместе с гардами.
	--
	-- SkipFirst НЕ отрезает гарды от нагрузки, а задаёт, сколько первых
	-- операторов останутся снаружи. По умолчанию 0: снаружи не остаётся
	-- ничего, и тогда ничто на глубине 0 не ссылается на oldTop. Стоит
	-- оставить снаружи хоть один оператор, объявляющий переменную в oldTop,
	-- — конфликт глубин возвращается.
	local payload = {};
	for i = skip + 1, #stmts do
		table.insert(payload, stmts[i]);
	end

	-- Тело функции — старая область: именно там живут переменные программы.
	local payloadFunc = Ast.FunctionLiteralExpression({}, Ast.Block(payload, oldTop));

	-- local _p = function() ... end
	local pVar = helperScope:addVariable("_p");

	-- local _done = false
	local doneVar = helperScope:addVariable("_done");

	-- local _fire = function() if _done then return end _done = true _p() end
	local fireVar = helperScope:addVariable("_fire");
	local fireBody = Scope:new(helperScope);
	local fireGuardBody = Scope:new(fireBody);

	--------------------------------------------------------------------------
	-- Проверка привязки (PlaceId / UserId). По умолчанию списки пусты — тогда
	-- этот блок вообще не попадает в выход.
	--------------------------------------------------------------------------
	local gateStats = {};
	if #self._PlaceIds > 0 or #self._UserIds > 0 then
		local gateVar = fireBody:addVariable("_allow");

		-- _allow = <цепочка сравнений>
		--
		-- Цепочка `or`, а НЕ цикл по массиву. Причина техническая, но
		-- жёсткая: переменная цикла жила бы в `statement.scope` цикла ForIn,
		-- а компилятор проставляет глубину только областям БЛОКОВ. Итог —
		-- «attempt to compare nil with number» на первом же Vmify. Цепочка
		-- сравнений не заводит ни одной новой области.
		local function eqChain(ids, getValue)
			local expr = nil;
			for _, v in ipairs(ids) do
				local one = Ast.EqualsExpression(getValue(), Ast.NumberExpression(v));
				expr = (expr == nil) and one or Ast.OrExpression(expr, one, true);
			end
			return expr;
		end

		local cond = nil;
		if #self._PlaceIds > 0 then
			cond = eqChain(self._PlaceIds, function()
				return Ast.IndexExpression(getServiceCall(ast, "Players"), str("PlaceId"));
			end);
		end
		if #self._UserIds > 0 then
			local u = eqChain(self._UserIds, function()
				return Ast.IndexExpression(
					Ast.IndexExpression(getServiceCall(ast, "Players"), str("LocalPlayer")),
					str("UserId")
				);
			end);
			cond = (cond == nil) and u or Ast.OrExpression(cond, u, true);
		end

		table.insert(gateStats, Ast.LocalVariableDeclaration(
			fireBody, { gateVar }, { Ast.BooleanExpression(false) }
		));
		table.insert(gateStats, Ast.IfStatement(
			cond,
			Ast.Block({
				Ast.AssignmentStatement(
					{ Ast.AssignmentVariable(fireBody, gateVar) },
					{ Ast.BooleanExpression(true) }
				),
			}, Scope:new(fireBody)),
			{}, nil
		));
		-- if not _allow then return end
		table.insert(gateStats, Ast.IfStatement(
			Ast.NotExpression(Ast.VariableExpression(fireBody, gateVar)),
			Ast.Block({ Ast.ReturnStatement({}) }, Scope:new(fireBody)),
			{}, nil
		));
	end

	-- Тело _fire: сначала проверка привязки (если задана), потом сам вызов.
	local fireStats = {};
	for _, s in ipairs(gateStats) do table.insert(fireStats, s) end
	table.insert(fireStats, Ast.IfStatement(
		Ast.VariableExpression(helperScope, doneVar),
		Ast.Block({ Ast.ReturnStatement({}) }, fireGuardBody),
		{}, nil
	));
	table.insert(fireStats, Ast.AssignmentStatement(
		{ Ast.AssignmentVariable(helperScope, doneVar) },
		{ Ast.BooleanExpression(true) }
	));
	table.insert(fireStats, Ast.FunctionCallStatement(
		Ast.VariableExpression(helperScope, pVar), {}
	));

	--------------------------------------------------------------------------
	-- Активация
	--------------------------------------------------------------------------
	local activation = {};

	-- local _p = function() <вся программа> end
	table.insert(activation, Ast.LocalVariableDeclaration(
		helperScope, { pVar }, { payloadFunc }
	));
	-- local _done = false
	table.insert(activation, Ast.LocalVariableDeclaration(
		helperScope, { doneVar }, { Ast.BooleanExpression(false) }
	));
	-- local _fire = function() if _done then return end _done = true _p() end
	table.insert(activation, Ast.LocalVariableDeclaration(
		helperScope, { fireVar },
		{ Ast.FunctionLiteralExpression({}, Ast.Block(fireStats, fireBody)) }
	));
	-- local _armed = false
	local armedVar = helperScope:addVariable("_armed");
	table.insert(activation, Ast.LocalVariableDeclaration(
		helperScope, { armedVar }, { Ast.BooleanExpression(false) }
	));

	local pcallScope, pcallId = self:gid(ast, "pcall");
	local pcallRef = function() return Ast.VariableExpression(pcallScope, pcallId) end;

	--------------------------------------------------------------------------
	-- 1. Кадр.
	--------------------------------------------------------------------------
	if self.Mode == "frame" or self.Mode == "both" then
		-- Область блока, а НЕ её родитель. Переменные обязаны жить в той же
		-- области, что и блок: __depth проставляется только областям блоков,
		-- и переменная из синтетической родительской области ломает Vmify
		-- («attempt to compare nil with number» в compile_top).
		local fnScope = Scope:new(helperScope);
		local connVar = fnScope:addVariable("_c");
		local rsVar = fnScope:addVariable("_rs");

		local inner = {
			-- local _rs = game:GetService("RunService")
			Ast.LocalVariableDeclaration(fnScope, { rsVar },
				{ getServiceCall(ast, "RunService") }),
			-- local _c
			Ast.LocalVariableDeclaration(fnScope, { connVar }, {}),
			-- _c = _rs.Heartbeat:Connect(function() ... end)
			Ast.AssignmentStatement(
				{ Ast.AssignmentVariable(fnScope, connVar) },
				{
					Ast.PassSelfFunctionCallExpression(
						Ast.IndexExpression(
							Ast.VariableExpression(fnScope, rsVar),
							str("Heartbeat")
						),
						"Connect",
						{
							Ast.FunctionLiteralExpression({}, Ast.Block({
								Ast.FunctionCallStatement(pcallRef(), {
									Ast.FunctionLiteralExpression({}, Ast.Block({
										Ast.PassSelfFunctionCallStatement(
											Ast.VariableExpression(fnScope, connVar),
											"Disconnect", {}
										),
									}, Scope:new(fnScope)))
								}),
								Ast.FunctionCallStatement(
									Ast.VariableExpression(helperScope, fireVar), {}
								),
							}, Scope:new(fnScope)))
						}
					)
				}
			),
			-- _armed = _c ~= nil
			Ast.AssignmentStatement(
				{ Ast.AssignmentVariable(helperScope, armedVar) },
				{
					Ast.NotEqualsExpression(
						Ast.VariableExpression(fnScope, connVar),
						Ast.NilExpression()
					)
				}
			),
		};

		table.insert(activation, Ast.FunctionCallStatement(pcallRef(), {
			Ast.FunctionLiteralExpression({}, Ast.Block(inner, fnScope))
		}));
	end

	--------------------------------------------------------------------------
	-- 2. Задержка.
	--------------------------------------------------------------------------
	if self.Mode == "delay" or self.Mode == "both" then
		local ifScope = Scope:new(helperScope);
		local delayScope = Scope:new(ifScope);
		table.insert(activation, Ast.IfStatement(
			Ast.NotExpression(Ast.VariableExpression(helperScope, armedVar)),
			Ast.Block({
				Ast.FunctionCallStatement(pcallRef(), {
					Ast.FunctionLiteralExpression({}, Ast.Block({
						Ast.FunctionCallStatement(
							Ast.IndexExpression(gref(ast, "task"), str("delay")),
							{
								Ast.NumberExpression(self.DelaySeconds),
								Ast.VariableExpression(helperScope, fireVar),
							}
						),
						Ast.AssignmentStatement(
							{ Ast.AssignmentVariable(helperScope, armedVar) },
							{ Ast.BooleanExpression(true) }
						),
					}, delayScope))
				}),
			}, Scope:new(ifScope)),
			{}, nil
		));
	end

	--------------------------------------------------------------------------
	-- 3. Прямой вызов — страховка.
	--------------------------------------------------------------------------
	if self.FallbackDirect then
		local lastScope = Scope:new(helperScope);
		table.insert(activation, Ast.IfStatement(
			Ast.NotExpression(Ast.VariableExpression(helperScope, armedVar)),
			Ast.Block({
				Ast.FunctionCallStatement(
					Ast.VariableExpression(helperScope, fireVar), {}
				),
			}, lastScope),
			{}, nil
		));
	end

	ast.body = Ast.Block(activation, newTop);
	return ast;
end

return DeferActivation;
