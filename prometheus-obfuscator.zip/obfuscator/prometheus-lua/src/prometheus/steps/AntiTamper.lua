-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- AntiTamper.lua
--
-- This Script provides an Obfuscation Step, that breaks the script, when someone tries to tamper with it.

local Step = require("prometheus.step")
local RandomStrings = require("prometheus.randomStrings")
local Parser = require("prometheus.parser")
local Enums = require("prometheus.enums")
local logger = require("logger")

local AntiTamper = Step:extend()
AntiTamper.Description = "This Step Breaks your Script when it is modified. This is only effective when using the new VM."
AntiTamper.Name = "Anti Tamper"

AntiTamper.SettingsDescriptor = {
	UseDebug = {
		type = "boolean",
		default = true,
		description = "Use debug library. (Recommended, however scripts will not work without debug library.)",
	},
	ExecutorTolerant = {
		type = "boolean",
		default = true,
		description = "Смягчает проверки, которые ложно срабатывают в исполнителях (Arceus X / Delta): сравнение текста ошибки по вхождению вместо точного равенства, устойчивое извлечение номера строки, выход вместо бесконечного цикла при ложном срабатывании.",
	},
	PoisonVar = {
		type = "string",
		default = "",
		description = "Fail-slow: вместо error() проверка пишет в этот глобальный флаг задержку до начала тихой порчи результатов.",
	},
	ExpectedLine = {
		type = "number",
		default = 1,
		min = 1,
		description = "Абсолютный номер строки, который обязаны сообщить ВСЕ кадры трассировки. В минифицированной сборке файл занимает одну строку, поэтому 1.",
	},
}

local function generateSanityCheck()
	local sanityCheckAnswers = {}
	local sanityPasses = math.random(1, 10)
	for i = 1, sanityPasses do
		sanityCheckAnswers[i] = (math.random(1, 2 ^ 24) % 2 == 1)
	end
	local primaryCheck = RandomStrings.randomString()
	local codeParts = {}
	local function addCode(fmt, ...)
		table.insert(codeParts, string.format(fmt, ...))
	end

	local function generateAssignment(idx)
		local index = math.min(idx, sanityPasses)
		addCode("            valid = %s;\n", tostring(sanityCheckAnswers[index]))
	end
	local function generateValidation(idx)
		local index = math.min(idx - 1, sanityPasses)
		addCode("            if valid == %s then\n", tostring(sanityCheckAnswers[index]))
		addCode("            else\n")
		addCode("                while true do end\n")
		addCode("            end\n")
	end

	addCode("do local valid = '%s';", primaryCheck)
	addCode("for i = 0, %d do\n", sanityPasses)
	for i = 0, sanityPasses do
		if i == 0 then
			addCode("        if i == 0 then\n")
			addCode("            if valid ~= '%s' then\n", primaryCheck)
			addCode("                while true do end\n")
			addCode("            end\n")
			addCode("            valid = %s;\n", tostring(sanityCheckAnswers[1]))
		elseif i == 1 then
			addCode("        elseif i == 1 then\n")
			addCode("            if valid == %s then\n", tostring(sanityCheckAnswers[1]))
			addCode("            end\n")
		else
			addCode("        elseif i == %d then\n", i)

			--[[
                Basically, even iterations are used to assign a new sanity check value,
                and odd iterations are used to validate the previous sanity check value.
            ]]
			if i % 2 == 0 then
				generateAssignment(i)
			else
				generateValidation(i)
			end
		end
	end
	addCode("        end\n")
	addCode("    end\n")
	addCode("do valid = true end\n")
	return table.concat(codeParts)
end

function AntiTamper:init(settings) end

function AntiTamper:apply(ast, pipeline)
	if pipeline.PrettyPrint then
		logger:warn(string.format('"%s" cannot be used with PrettyPrint, ignoring "%s"', self.Name, self.Name))
		return ast
	end
	local code = generateSanityCheck()
	if self.UseDebug then
		local string = RandomStrings.randomString()
		code = code
			.. [[
            -- ---- Проверки через debug.* ----
            -- ВАЖНО: состав debug.* в Roblox/Luau отличается от Lua 5.1:
            -- нет debug.getinfo и string.dump, вместо них debug.info, а
            -- debug.getupvalue БРОСАЕТ ошибку ("getupvalue Invalid index")
            -- на C-функциях вместо возврата nil. Поэтому каждый вызов обёрнут
            -- в pcall: если проверку выполнить нельзя — она пропускается,
            -- а не роняет скрипт.
			if type(debug) == "table" then
				pcall(function()
					-- Anti Beautify (line hook)
					if type(debug.sethook) == "function" then
						local called = 0;
						local allowedLine = nil;
						debug.sethook(function(s, line)
							if not line then
								return
							end
							called = called + 1;
							if allowedLine then
							if allowedLine ~= line then
								-- РАНЬШЕ здесь было debug.sethook(error, "l", 5):
								-- хук подменялся на error, и через несколько
								-- строк скрипт падал с сообщением "line".
								-- Это ровно тот баг, на который указывал
								-- внешний разбор (§6.2 п.3: «хук должен
								-- стрелять молча»): падение само по себе
								-- подсказывает аналитику, что защита есть.
								-- Теперь — только отметка и снятие хука.
								valid = false;
								debug.sethook();
							end
							else
								allowedLine = line;
							end
						end, "l", 5);
						(function() end)();
						(function() end)();
						debug.sethook();
						if called < 2 then
							valid = false;
						end
					end

					-- Anti Function Hook.
					-- В терпимом режиме ОТКЛЮЧЕН: исполнитель сам оборачивает
					-- pcall/string.*, и проверка приняла бы его за взлом.
					local checkHooks = ]] .. tostring(not self.ExecutorTolerant) .. [[;
					local funcs = {};
					if type(pcall) == "function" then funcs[#funcs + 1] = pcall; end
					if type(string) == "table" then
						if type(string.char) == "function" then funcs[#funcs + 1] = string.char; end
						if type(string.byte) == "function" then funcs[#funcs + 1] = string.byte; end
						if type(string.sub) == "function" then funcs[#funcs + 1] = string.sub; end
						if type(string.dump) == "function" then funcs[#funcs + 1] = string.dump; end
					end

					for i = 1, #funcs do
						local fn = funcs[i];

						-- Lua 5.1: debug.getinfo(f).what
						if checkHooks and type(debug.getinfo) == "function" then
							local ok, info = pcall(debug.getinfo, fn);
							if ok and type(info) == "table" and info.what ~= nil and info.what ~= "C" then
								valid = false;
							end
						end

						-- Luau / Roblox: debug.info(f, "s")
						if checkHooks and type(debug.info) == "function" then
							local ok, src = pcall(debug.info, fn, "s");
							if ok and type(src) == "string" and src ~= "=[C]" then
								valid = false;
							end
						end

						-- upvalue. Ошибка getupvalue для C-функции — это НОРМА,
						-- а не признак взлома, поэтому флаг ставим только когда
						-- вызов прошёл успешно и реально вернул upvalue.
						if checkHooks and type(debug.getupvalue) == "function" then
							local ok, uv = pcall(debug.getupvalue, fn, 1);
							if ok and uv ~= nil then
								valid = false;
							end
						end

						-- C-функцию нельзя сдампить
						if checkHooks and type(string) == "table" and type(string.dump) == "function" then
							local ok, dumped = pcall(string.dump, fn);
							if ok and dumped ~= nil then
								valid = false;
							end
						end
					end

					-- Anti Beautify (traceback)
					if type(debug.traceback) == "function" then
						local function getTraceback()
							local str = (function(arg)
								return debug.traceback(arg)
							end)("]] .. string .. [[");
							return str;
						end
						local ok, traceback = pcall(getTraceback);
						if ok and type(traceback) == "string" then
							valid = valid and traceback:sub(1, (traceback:find("\n") or 2) - 1) == "]] .. string .. [[";
						-- Сверка АБСОЛЮТОВ, а не относительного смещения.
						--
						-- Раньше проверялся только первый кадр:
						--   firstLine = traceback:match(":(%d+):")
						--   valid = firstLine == nil or firstLine == "1"
						-- Этого мало. Аналитик может переформатировать файл
						-- и пододвинуть преамбулу так, что нужный кадр снова
						-- окажется на строке 1 — проверка пройдёт.
						--
						-- Теперь проверяются ВСЕ СВОИ кадры: в минифицированной
						-- сборке файл занимает ровно одну строку, значит
						-- каждый свой кадр обязан сообщить ровно EXP_LINE.
						--
						-- EXP_LINE подставляется на этапе обфускации.
						local EXP_LINE = ]] .. tostring(self.ExpectedLine) .. [[;
						if os and os.getenv and os.getenv("TBDUMP") then
							io.stderr:write("=== TB ===\\n" .. traceback .. "=== /TB ===\\n");
						end
						local frames = 0;
						local firstOk = false;
						--
						-- Формат трассировки РАЗНЫЙ в Lua 5.1 и Luau, и это
						-- важно:
						--   Lua 5.1:  [string "..."]:1: in function <...>
						--             [C]: in function 'pcall'
						--   Luau:     Script:1 function foo
						--             (ни двоеточия после номера, ни [C])
						--
						-- Шаблон ":(%d+):" в Luau не совпадал НИ РАЗУ. Старая
						-- проверка от этого молча выключалась: firstLine был
						-- nil, а nil считался нормой. То есть в Roblox эта
						-- защита не работала вообще. Теперь номер строки
						-- ищется в обоих форматах.
						--
						-- Проверяем ПЕРВЫЙ кадр с номером строки — самый
						-- внутренний, он всегда наш. Проверять все кадры
						-- нельзя: при загрузке через loadstring + pcall (а
						-- именно так скрипт грузят исполнители) в трассировку
						-- попадают кадры самого исполнителя с другими номерами
						-- строк, и это даёт ложное срабатывание — вывод
						-- оказывается испорчен у обычного пользователя.
						for ln in traceback:gmatch("[^\\n]+") do
							local n = ln:match(":(%d+)%s") or ln:match(":(%d+)$");
							if n then
								frames = frames + 1;
								if frames == 1 then
									firstOk = (tonumber(n) == EXP_LINE);
								end
							end
						end
						-- Ни одного кадра с номером строки — трассировку
						-- подменили или она пуста; это тоже не норма.
						if frames == 0 or not firstOk then
							valid = false;
						end
						end
					end
				end)
			end
        ]]
    end
    -- Fail-slow: вместо error() пишем в флаг задержку до начала порчи.
    local poisonTrip;
    if self.PoisonVar and self.PoisonVar ~= "" then
        poisonTrip = self.PoisonVar .. " = " .. tostring(math.random(3, 16)) .. ";";
    else
        poisonTrip = "error(\"Tamper Detected!\");";
    end

code = code .. [[
    local gmatch = string.gmatch;
    local err = function() error("Tamper Detected!") end;

    local pcallIntact2 = false;
    local pcallIntact = pcall(function()
        pcallIntact2 = true;
    end) and pcallIntact2;

    local random = math.random;
    local tblconcat = table.concat;
    local unpkg = table and table.unpack or unpack;
    local n = random(3, 65);
    local acc1 = 0;
    local acc2 = 0;
    local pcallRet = {pcall(function() local a = ]] .. tostring(math.random(1, 2^24)) .. [[ - "]] .. RandomStrings.randomString() .. [[" ^ ]] .. tostring(math.random(1, 2^24)) .. [[ return "]] .. RandomStrings.randomString() .. [[" / a; end)};
    local origMsg = pcallRet[2];
    local line = tonumber(gmatch(tostring(origMsg), ':(%d*):')());
    for i = 1, n do
        local len = math.random(1, 100);
        local n2 = random(0, 255);
        local pos = random(1, len);
        local shouldErr = random(1, 2) == 1;
        local msg = origMsg:gsub(':(%d*):', ':' .. tostring(random(0, 10000)) .. ':');
        local arr = {pcall(function()
            if random(1, 2) == 1 or i == n then
                local line2 = tonumber(gmatch(tostring(({pcall(function() local a = ]] .. tostring(math.random(1, 2^24)) .. [[ - "]] .. RandomStrings.randomString() .. [[" ^ ]] .. tostring(math.random(1, 2^24)) .. [[ return "]] .. RandomStrings.randomString() .. [[" / a; end)})[2]), ':(%d*):')());
                valid = valid and line == line2;
            end
            if shouldErr then
                error(msg, 0);
            end
            local arr = {};
            for i = 1, len do
                arr[i] = random(0, 255);
            end
            arr[pos] = n2;
            return unpkg(arr);
        end)};
        if shouldErr then
            valid = valid and arr[1] == false and arr[2] == msg;
        else
            valid = valid and arr[1];
            acc1 = (acc1 + arr[pos + 1]) % 256;
            acc2 = (acc2 + n2) % 256;
        end
    end
    valid = valid and acc1 == acc2;

    if not valid then
        ]] .. poisonTrip .. [[
    end
end

    -- Anti Function Arg Hook
    local obj = setmetatable({}, {
        __tostring = err,
    });
    obj[math.random(1, 100)] = obj;
    (function() end)(obj);

    if not valid then ]] .. poisonTrip .. [[ end
    ]]

    -- ── Режим совместимости с исполнителями ────────────────────────────
    -- Исполнители (Arceus X, Delta, ...) перехватывают error/pcall и меняют
    -- окружение. Часть проверок AntiTamper на это реагирует как на взлом.
    -- Здесь такие проверки смягчаются: смысл (файл не переформатирован)
    -- сохраняется, но точное совпадение строк больше не требуется.
    if self.ExecutorTolerant then
        -- 2.1 Текст ошибки: ищем вхождение, а не точное равенство.
        --     Исполнитель может дописать к сообщению свой префикс/суффикс.
        code = code:gsub(
            "valid = valid and arr%[1%] == false and arr%[2%] == msg;",
            function()
                return "valid = valid and arr[1] == false and (arr[2] == msg or (tostring(arr[2]):find(msg, 1, true) ~= nil));"
            end
        );

        -- 2.2 Номер строки: gmatch может ничего не найти, тогда вызов
        --     результата как функции упадёт. Извлекаем безопасным способом.
        code = code:gsub(
            "local line = tonumber%(gmatch%(tostring%(origMsg%), ':%(%%d%*%):'%)%(%)%);",
            function()
                return "local line = nil; do local it = gmatch(tostring(origMsg), ':(%d*):'); if it then line = tonumber(it()); end end"
            end
        );

        -- 2.3 Сравниваем номера строк только если оба получены.
        code = code:gsub(
            "valid = valid and line == line2;",
            function()
                return "if line ~= nil and line2 ~= nil then valid = valid and line == line2; end"
            end
        );

        -- 2.4 При ложном срабатывании выходим, а не вешаем поток: в исполнителе
        --     зависание хуже ошибки — пользователь просто не понимает, что случилось.
        code = code:gsub("while true do end", function() return "return" end);

        -- 2.5 Проверка хуков функций отключена (см. checkHooks), но настоящую
        --     ПОДМЕНУ pcall заглушкой всё равно ловим: обёртка исполнителя
        --     функцию выполняет (pcallIntact = true), заглушка — нет.
        code = code:gsub(
            "valid = valid and acc1 == acc2;",
            function()
                return "valid = valid and pcallIntact;\nvalid = valid and acc1 == acc2;"
            end
        );
    end

    local parsed = Parser:new({LuaVersion = Enums.LuaVersion.Lua51}):parse(code);
    local doStat = parsed.body.statements[1];
    doStat.body.scope:setParent(ast.body.scope);
    table.insert(ast.body.statements, 1, doStat);

    return ast;
end

return AntiTamper;
