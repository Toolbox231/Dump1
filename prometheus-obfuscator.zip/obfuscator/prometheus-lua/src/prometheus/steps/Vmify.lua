-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- Vmify.lua
--
-- This Script provides a Complex Obfuscation Step that will compile the entire Script to  a fully custom bytecode that does not share it's instructions
-- with lua, making it much harder to crack than other lua obfuscators

local Step = require("prometheus.step");
local Compiler = require("prometheus.compiler.compiler");

local Vmify = Step:extend();
Vmify.Description = "This Step will Compile your script into a fully-custom (not a half custom like other lua obfuscators) Bytecode Format and emit a vm for executing it.";
Vmify.Name = "Vmify";

Vmify.SettingsDescriptor = {
	-- Адреса переходов, зависимые от состояния VM (этап 5, пункт 3).
	StatefulJumps = {
		type = "boolean",
		default = true,
		description = "Писать адрес перехода как <id> - (cnt() % 1), а не константой: граф переходов не читается статически.",
	},
	-- Мусорные обработчики (этап 5, пункт 3). Сколько мёртвых блоков
	-- подмешивать к настоящим, долей от числа настоящих.
	JunkHandlers = {
		type = "number",
		default = 0.15,
		min = 0,
		max = 2,
		description = "Доля мёртвых блоков (мусорных обработчиков), которые встраиваются в диспетчер, но никогда не выполняются.",
	},
	LazyHandlers = {
		type = "boolean",
		default = true,
		description = "Ленивая таблица обработчиков: диспетчер не строит статическое дерево if/elseif, а достаёт обработчик из таблицы строителей, создавая его при первом заходе в блок. Строитель одноразовый.",
	},
}

function Vmify:init(_) end

function Vmify:apply(ast)
    -- Create Compiler
	local compiler = Compiler:new({
		JunkHandlers = self.JunkHandlers,
		LazyHandlers = self.LazyHandlers,
		StatefulJumps = self.StatefulJumps,
	});

    -- Compile the Script into a bytecode vm
    return compiler:compile(ast);
end

return Vmify;