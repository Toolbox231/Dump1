-- Custom Step for the Prometheus Obfuscator
--
-- EnvAttest.lua
--
-- Аттестация среды исполнения и детект инструментария анализа.
--
-- Отличается от RobloxGuard принципиально: RobloxGuard проверяет «похоже ли это
-- на Roblox», EnvAttest проверяет «не является ли эта среда песочницей,
-- трассировщиком или эмулятором» и отдельно — «не подменены ли сами функции».
--
-- Три класса проверок:
--
--   1. Присутствие того, что есть только в Roblox-Luau: typeof, task, bit32,
--      debug.info. Их нет в стоковом Lua 5.1.
--   2. Identity-проверки, которые нельзя подделать «похожим» объектом:
--      game.Workspace ДОЛЖЕН быть тем же объектом, что workspace; GUID от
--      HttpService должен иметь настоящий формат, а не просто длину 36.
--   3. Детект инструментария: stdlib-функции должны быть нативными (what == "C"),
--      не должно стоять debug-хука, в трассе не должно быть имён файлов харнесса.
--
-- ПРОВЕРКИ «ДЕСКТОПНОСТИ» (arg / io / package / os.getenv) ВЫКЛЮЧЕНЫ ПО
-- УМОЛЧАНИЮ И ЭТО СДЕЛАНО НАМЕРЕННО. Многие Roblox-исполнители (Delta,
-- Arceus X Neo) предоставляют io и os для работы с файлами. Включить эти
-- проверки — получить ложное срабатывание и мёртвый скрипт у пользователя.
-- Совместимость с исполнителями для нас важнее максимального детекта.
-- Включать флагом CheckDesktop = true, только если целевая среда — настоящий
-- Roblox без исполнителя.
--
-- Все проверки пишут в флаг порчи (Action = "spoil"), а не кидают error().
-- Так ложное срабатывание деградирует до расхождения результатов, а не до
-- сломанного скрипта.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Parser = require("prometheus.parser");
local Enums = require("prometheus.enums");

local EnvAttest = Step:extend();
EnvAttest.Description = "Attests the runtime environment and detects instrumentation/sandboxing";
EnvAttest.Name = "EnvAttest";

EnvAttest.SettingsDescriptor = {
	CheckTypeof = {
		name = "CheckTypeof",
		description = "typeof is present and is a function",
		type = "boolean",
		default = true,
	},
	CheckTask = {
		name = "CheckTask",
		description = "task table is present (Roblox only, absent in Luau CLI)",
		type = "boolean",
		default = true,
	},
	CheckDebugInfo = {
		name = "CheckDebugInfo",
		description = "debug.info (Luau) or debug.getinfo (5.1) is present",
		type = "boolean",
		default = true,
	},
	CheckBit32 = {
		name = "CheckBit32",
		description = "bit32 is present (Luau/Roblox only)",
		type = "boolean",
		default = true,
	},
	CheckIdentity = {
		name = "CheckIdentity",
		description = "game.Workspace is the very same object as workspace",
		type = "boolean",
		default = true,
	},
	CheckGuidFormat = {
		name = "CheckGuidFormat",
		description = "HttpService:GenerateGUID(false) matches a real GUID pattern, not just length 36",
		type = "boolean",
		default = true,
	},
	CheckProxies = {
		name = "CheckProxies",
		description = "stdlib functions must be native (what == 'C'); a Lua wrapper means the sandbox proxied them",
		type = "boolean",
		default = true,
	},
	CheckHook = {
		name = "CheckHook",
		description = "debug.gethook() must be nil — a set hook means a profiler or tracer is attached",
		type = "boolean",
		default = true,
	},
	CheckTraceback = {
		name = "CheckTraceback",
		description = "debug.traceback() must not contain harness/sandbox/emulator file names",
		type = "boolean",
		default = true,
	},
	CheckDesktop = {
		name = "CheckDesktop",
		description = "arg/io/package/os.getenv must be ABSENT. OFF by default: many Roblox executors provide io and os",
		type = "boolean",
		default = false,
	},
	Action = {
		name = "Action",
		description = "What to do when attestation fails",
		type = "enum",
		values = { "return", "error", "spoil", "decoy" },
		default = "spoil",
	},
	PoisonVar = {
		name = "PoisonVar",
		description = "Global flag for fail-slow mode (Action = 'spoil')",
		type = "string",
		default = "",
	},
	ErrorMessage = {
		name = "ErrorMessage",
		description = "Message for Action = 'error'",
		type = "string",
		default = "Unsupported environment",
	},
	BranchVar = {
		name = "BranchVar",
		description = "Global flag for the decoy branch (Action = 'decoy'). Separate from PoisonVar on purpose",
		type = "string",
		default = "",
	},
};

function EnvAttest:init(settings) end

function EnvAttest:apply(ast)
	----------------------------------------------------------------------
	-- Ветка «аттестация не прошла»
	----------------------------------------------------------------------
	local action;
	if self.Action == "decoy" and self.BranchVar and self.BranchVar ~= "" then
		-- Ложная ветка (этап 5, пункт 6): среда чужая, но скрипт НЕ выходит
		-- и НЕ портит строки — он идёт в ветку с правдоподобной пустышкой.
		action = self.BranchVar .. " = true;";
	elseif self.Action == "spoil" and self.PoisonVar and self.PoisonVar ~= "" then
		-- Fail-slow: НИКАКИХ error() и сообщений. Число = задержка в
		-- обращениях к строкам до начала порчи. Программа продолжает
		-- работать, только результаты постепенно расходятся.
		action = self.PoisonVar .. " = " .. tostring(math.random(3, 16)) .. ";";
	elseif self.Action == "error" then
		action = "error(\"" .. self.ErrorMessage .. "\");";
	else
		action = "return;";
	end

	----------------------------------------------------------------------
	-- Генерируем код проверок
	----------------------------------------------------------------------
	local c = {};
	local function add(fmt, ...)
		c[#c + 1] = string.format(fmt, ...);
	end

	-- Каждая проверка — ОТДЕЛЬНАЯ ФУНКЦИЯ. Это не стилистика, а necessity:
	-- весь скрипт после Vmify превращается в одну гигантскую управляющую
	-- конструкцию, и встроенный в неё код проверок пробивает предел Lua
	-- «control structure too long». Разложив проверки по своим функциям, мы
	-- держим каждую конструкцию короткой и укладываемся в лимит.
	add("do");
	add("\tlocal attested = true;");
	add("\tlocal checks = {};");

	if self.CheckTypeof then
		add("\tchecks[#checks + 1] = function()");
		add("\t\treturn type(typeof) == \"function\";");
		add("\tend;");
	end

	if self.CheckTask then
		add("\tchecks[#checks + 1] = function()");
		add("\t\treturn type(task) == \"table\";");
		add("\tend;");
	end

	if self.CheckDebugInfo then
		add("\tchecks[#checks + 1] = function()");
		add("\t\tif type(debug) ~= \"table\" then return false; end");
		add("\t\treturn debug.info ~= nil or debug.getinfo ~= nil;");
		add("\tend;");
	end

	if self.CheckBit32 then
		add("\tchecks[#checks + 1] = function()");
		add("\t\treturn type(bit32) == \"table\";");
		add("\tend;");
	end

	if self.CheckIdentity then
		-- Не «похожий объект», а тот же самый. Подделать можно только
		-- подсунув реальный DataModel, а это уже полноценная эмуляция.
		add("\tchecks[#checks + 1] = function()");
		add("\t\tif typeof(game) ~= \"Instance\" or typeof(workspace) ~= \"Instance\" then return false; end");
		add("\t\treturn game.Workspace == workspace;");
		add("\tend;");
	end

	if self.CheckGuidFormat then
		-- Проверяем формат, не длину: 36 случайных символов подделать легко,
		-- а расстановку дефисов и hex-алфавит — уже надо знать, что проверяют.
		add("\tchecks[#checks + 1] = function()");
		add("\t\tlocal g = game:GetService(\"HttpService\"):GenerateGUID(false);");
		add("\t\tif type(g) ~= \"string\" or #g ~= 36 then return false; end");
		add("\t\treturn g:match(\"^%%x%%x%%x%%x%%x%%x%%x%%x%%-%%x%%x%%x%%x%%-%%x%%x%%x%%x%%-%%x%%x%%x%%x%%-%%x%%x%%x%%x%%x%%x%%x%%x%%x%%x%%x%%x$\") ~= nil;");
		add("\tend;");
	end

	if self.CheckProxies then
		-- Если stdlib-функция — Lua-обёртка, значит среду проксируют.
		-- Проверяем только те, исполнители НЕ обязаны оборачивать:
		-- pcall/error намеренно исключены (исполнители их оборачивают
		-- штатно, и это не взлом).
		add("\tchecks[#checks + 1] = function()");
		add("\t\tlocal probes = { string.byte, string.sub, math.floor, string.char };");
		add("\t\tfor i = 1, #probes do");
		add("\t\t\tlocal ok, r = pcall(function()");
		add("\t\t\t\tif debug ~= nil and debug.info ~= nil then return debug.info(probes[i], \"s\"); end");
		add("\t\t\t\treturn debug.getinfo(probes[i], \"S\").what;");
		add("\t\t\tend);");
		add("\t\t\tif ok and r ~= nil then");
		add("\t\t\t\tlocal native = (r == \"=[C]\" or r == \"[C]\" or r == \"C\");");
		add("\t\t\t\tif not native then return false; end");
		add("\t\t\tend");
		add("\t\tend");
		add("\t\treturn true;");
		add("\tend;");
	end

	if self.CheckHook then
		-- Поставленный хук = профилировщик или трассировщик.
		add("\tchecks[#checks + 1] = function()");
		add("\t\tif type(debug) ~= \"table\" or type(debug.gethook) ~= \"function\" then return true; end");
		add("\t\tlocal ok, hookFn = pcall(debug.gethook);");
		add("\t\treturn ok and hookFn == nil;");
		add("\tend;");
	end

	if self.CheckTraceback then
		add("\tchecks[#checks + 1] = function()");
		add("\t\tlocal ok, tb = pcall(debug.traceback);");
		add("\t\tif not ok or type(tb) ~= \"string\" then return true; end");
		add("\t\tlocal low = tb:lower();");
		add("\t\treturn not (low:find(\"harness\") or low:find(\"runner\") or low:find(\"sandbox\")");
		add("\t\t\tor low:find(\"emulat\") or low:find(\"decompil\") or low:find(\"%%.py\"));");
		add("\tend;");
	end

	if self.CheckDesktop then
		-- СМОТРИ КОММЕНТАРИЙ В ШАПКЕ ФАЙЛА: по умолчанию выключено,
		-- потому что ломает исполнители, предоставляющие io/os.
		add("\tchecks[#checks + 1] = function()");
		add("\t\tif arg ~= nil or io ~= nil or package ~= nil then return false; end");
		add("\t\tif type(os) == \"table\" and (os.getenv ~= nil or os.exit ~= nil) then return false; end");
		add("\t\treturn true;");
		add("\tend;");
	end

	-- Прогоняем все проверки. Упавшая проверка = взлом, но НЕ ошибка:
	-- мы не падаем сами, а молча помечаем среду чужой.
	add("\tfor i = 1, #checks do");
	add("\t\tlocal ok, good = pcall(checks[i]);");
	add("\t\tif not (ok and good) then attested = false; end");
	add("\tend");

	add("\tif not attested then");
	add("\t\t%s", action);
	add("\tend");
	add("end");

	----------------------------------------------------------------------
	-- Вставляем в самое начало, до Vmify — чтобы проверки тоже обфусцировало
	----------------------------------------------------------------------
	local code = table.concat(c, "\n");
	if os.getenv("EA_DUMP") then io.stderr:write("=== EA DUMP ===\n", code, "\n=== END ===\n"); end
	local parsed = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code);
	local doStat = parsed.body.statements[1];
	doStat.body.scope:setParent(ast.body.scope);
	table.insert(ast.body.statements, 1, doStat);

	return ast;
end

return EnvAttest;
