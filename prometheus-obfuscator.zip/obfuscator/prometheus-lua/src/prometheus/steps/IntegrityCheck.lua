-- Custom Step for the Prometheus Obfuscator
--
-- IntegrityCheck.lua
--
-- Встраивает таблицу контрольных значений и их взвешенную контрольную сумму.
-- На старте сумма пересчитывается: если таблицу поправили, укоротили,
-- или «свернули» числа (constant folding) — контрольная сумма не сойдётся.
--
-- ЧЕСТНО ПРО ВОЗМОЖНОСТИ: это ловит правки САМОЙ таблицы контрольных
-- значений, а не любую правку файла. Полная привязка «хэш всего файла → ключ
-- расшифровки строк» требует постобработки уже сгенерированного файла и
-- того, чтобы движок отдавал исходник чанка через debug.info/getinfo —
-- в Roblox это не гарантировано, поэтому здесь оставлен безопасный вариант.
--
-- Ставить шаг нужно ПОСЛЕ NumbersToExpressions, иначе числа таблицы будут
-- переписаны в выражения.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");

local IntegrityCheck = Step:extend();
IntegrityCheck.Description = "Verifies a table of sentinel values against a checksum";
IntegrityCheck.Name = "IntegrityCheck";

-- Модуль для вычислений: держим значения небольшими, чтобы арифметика
-- оставалась точной и на Lua 5.1 (doubles), и на Luau.
local MODULUS = 2147483647;

IntegrityCheck.SettingsDescriptor = {
	Count = {
		name = "Count",
		description = "How many sentinel values to embed",
		type = "number",
		default = 12,
		min = 2,
		max = 64,
	},
	MaxValue = {
		name = "MaxValue",
		description = "Upper bound for each sentinel value",
		type = "number",
		default = 1000000,
		min = 16,
		max = 1000000,
	},
	Action = {
		name = "Action",
		description = "What to do when the checksum does not match",
		type = "enum",
		values = { "return", "error", "loop", "spoil" },
		default = "return",
	},
	ErrorMessage = {
		name = "ErrorMessage",
		description = "Message thrown when Action is 'error'",
		type = "string",
		default = "Integrity check failed",
	},
	PoisonVar = {
		name = "PoisonVar",
		description = "Global flag for fail-slow mode (Action = 'spoil')",
		type = "string",
		default = "",
	},
};

function IntegrityCheck:init(settings) end

local function globalRef(ast, name)
	local scope, id = ast.globalScope:resolve(name);
	return Ast.VariableExpression(scope, id);
end

function IntegrityCheck:apply(ast)
	local body = ast.body;
	local count = math.max(2, math.floor(self.Count or 12));
	local maxValue = math.max(16, math.floor(self.MaxValue or 1000000));

	local doScope = Scope:new(body.scope);

	-- Генерируем контрольные значения и веса
	local values = {};
	local weights = {};
	local checksum = 0;
	for i = 1, count do
		local v = math.random(1, maxValue);
		local w = (i * 7919 + 13) % 65521;
		if w == 0 then
			w = 1;
		end
		values[i] = v;
		weights[i] = w;
		checksum = (checksum + v * w) % MODULUS;
	end

	local tableId = doScope:addVariable();
	local tableRef = Ast.VariableExpression(doScope, tableId);

	local entries = {};
	for i = 1, count do
		entries[i] = Ast.TableEntry(Ast.NumberExpression(values[i]));
	end

	-- sum = t[1]*w1 + t[2]*w2 + ... (без цикла — разворачиваем в выражение)
	local sumExpr = Ast.MulExpression(
		Ast.IndexExpression(tableRef, Ast.NumberExpression(1)),
		Ast.NumberExpression(weights[1]),
		false
	);
	for i = 2, count do
		sumExpr = Ast.AddExpression(sumExpr, Ast.MulExpression(
			Ast.IndexExpression(tableRef, Ast.NumberExpression(i)),
			Ast.NumberExpression(weights[i]),
			false
		), false);
	end

	local condition = Ast.OrExpression(
		Ast.NotEqualsExpression(Ast.LenExpression(tableRef), Ast.NumberExpression(count)),
		Ast.NotEqualsExpression(
			Ast.ModExpression(sumExpr, Ast.NumberExpression(MODULUS), false),
			Ast.NumberExpression(checksum)
		),
		false
	);

	local ifScope = Scope:new(doScope);
	local actionBlock;
	if self.Action == "error" then
		actionBlock = Ast.Block({
			Ast.FunctionCallStatement(globalRef(ast, "error"), { Ast.StringExpression(self.ErrorMessage) })
		}, ifScope);
	elseif self.Action == "spoil" and self.PoisonVar and self.PoisonVar ~= "" then
		-- Fail-slow: НИКАКИХ error() и сообщений. Пишем в флаг число =
		-- задержка в обращениях до начала порчи. Программа продолжает
		-- работать, только результаты постепенно расходятся.
		actionBlock = Ast.Block({
			-- Присваивание завёрнуто в pcall(function() ... end).
			-- Напрямую Vmify его не переваривает: шаг умирает на этапе Vmify
			-- без сообщения об ошибке (проверено на 30 сидах — 0 удачных сборок).
			-- Через замыкание собирается нормально.
			Ast.FunctionCallStatement(
				globalRef(ast, "pcall"),
				{ Ast.FunctionLiteralExpression({}, Ast.Block({
					Ast.AssignmentStatement(
						{ globalRef(ast, self.PoisonVar) },
						{ Ast.NumberExpression(math.random(3, 16)) }
					)
				}, Scope:new(ifScope))) }
			)
		}, ifScope);
	elseif self.Action == "loop" then
		local loopScope = Scope:new(ifScope);
		actionBlock = Ast.Block({
			Ast.WhileStatement(Ast.Block({}, Scope:new(loopScope)), Ast.BooleanExpression(true), loopScope)
		}, ifScope);
	else
		actionBlock = Ast.Block({ Ast.ReturnStatement({}) }, ifScope);
	end

	table.insert(body.statements, 1, Ast.DoStatement(Ast.Block({
		Ast.LocalVariableDeclaration(doScope, { tableId }, { Ast.TableConstructorExpression(entries) }),
		Ast.IfStatement(condition, actionBlock, {}, nil),
	}, doScope)));
end

return IntegrityCheck;
