-- Custom Step for the Prometheus Obfuscator
--
-- RobloxGuard.lua
--
-- Injects a runtime check at the very top of the script that verifies the code
-- is actually executing inside the Roblox engine, by calling into the real
-- Roblox DataModel API. If the check fails the script bails out before any
-- real logic runs, so the obfuscated file is useless when it is ripped out and
-- run in plain Lua, LuaJIT, a decompiler, or a custom executor.

local Step = require("prometheus.step");
local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");

local RobloxGuard = Step:extend();
RobloxGuard.Description = "Adds runtime checks that the script is running inside Roblox";
RobloxGuard.Name = "RobloxGuard";

RobloxGuard.SettingsDescriptor = {
	CheckGame = {
		name = "CheckGame",
		description = "typeof(game) == 'Instance'",
		type = "boolean",
		default = true,
	},
	CheckWorkspace = {
		name = "CheckWorkspace",
		description = "typeof(workspace) == 'Instance'",
		type = "boolean",
		default = true,
	},
	CheckScript = {
		name = "CheckScript",
		description = "typeof(script) == 'Instance'",
		type = "boolean",
		default = true,
	},
	CheckService = {
		name = "CheckService",
		description = "Service resolved through game:GetService(). Empty string disables",
		type = "string",
		default = "Players",
	},
	CheckGuid = {
		name = "CheckGuid",
		description = "HttpService:GenerateGUID(false) returns a 36 char string",
		type = "boolean",
		default = true,
	},
	CheckLogService = {
		name = "CheckLogService",
		description = "LogService:GetLogHistory() returns a table",
		type = "boolean",
		default = true,
	},
	CheckTerrain = {
		name = "CheckTerrain",
		description = "typeof(workspace.Terrain) == 'Instance'",
		type = "boolean",
		default = true,
	},
	CheckRunService = {
		name = "CheckRunService",
		description = "RunService:IsStudio() returns a boolean",
		type = "boolean",
		default = true,
	},
	CheckTick = {
		name = "CheckTick",
		description = "typeof(tick()) == 'number' (tick only exists in Roblox)",
		type = "boolean",
		default = true,
	},
	CheckPlaceId = {
		name = "CheckPlaceId",
		description = "game.PlaceId ~= 0. WARNING: 0 in Studio for unsaved places",
		type = "boolean",
		default = false,
	},
	CheckJobId = {
		name = "CheckJobId",
		description = "game.JobId is a non-empty string. WARNING: empty in Studio, so keep this OFF while testing locally",
		type = "boolean",
		default = false,
	},
	Action = {
		name = "Action",
		description = "What the script does when it is NOT running inside Roblox",
		type = "enum",
		values = { "return", "error", "loop", "spoil", "decoy" },
		default = "return",
	},
	ErrorMessage = {
		name = "ErrorMessage",
		description = "The message thrown when Action is 'error'",
		type = "string",
		default = "This script can only be run inside Roblox",
	},
	BranchVar = {
		name = "BranchVar",
		description = "Global flag for the decoy branch (Action = 'decoy'). Separate from PoisonVar on purpose",
		type = "string",
		default = "",
	},
	PoisonVar = {
		name = "PoisonVar",
		description = "Global flag for fail-slow mode (Action = 'spoil')",
		type = "string",
		default = "",
	},
};

function RobloxGuard:init(settings) end

-- Resolve a global name (game, workspace, script, typeof, pcall, tick, ...) into
-- an AST variable expression. Globals are never renamed, so these survive the
-- renaming pass untouched.
local function globalRef(ast, name)
	local scope, id = ast.globalScope:resolve(name);
	return Ast.VariableExpression(scope, id);
end

-- Цель присваивания для глобала. Это НЕ то же, что globalRef: то отдаёт
-- ВЫРАЖЕНИЕ (чтение), здесь нужен узел записи. Подстановка globalRef в lhs
-- ломает Vmify: компилятор присваиваний не знает вид VariableExpression и
-- падает с «Invalid Assignment lhs». Ошибка была скрытой до появления
-- Action = "decoy" — ветка "spoil" с тем же кодом ни разу не запускалась.
local function globalAssign(ast, name)
	local scope, id = ast.globalScope:resolve(name);
	return Ast.AssignmentVariable(scope, id);
end

-- Declare a local inside `scope` and return its declaration + a reference.
local function localVar(scope, expr)
	local id = scope:addVariable();
	return Ast.LocalVariableDeclaration(scope, { id }, { expr }), Ast.VariableExpression(scope, id);
end

-- Build: pcall(function() <statements> return <returnExpr> end)
-- `build` receives the new function scope and returns (statements, returnExpr).
local function pcallFn(ast, parentScope, build)
	local funcScope = Scope:new(parentScope);
	local statements, returnExpr = build(funcScope);
	local body = Ast.Block(statements, funcScope);
	if returnExpr then
		table.insert(body.statements, Ast.ReturnStatement({ returnExpr }));
	end
	return Ast.FunctionCallExpression(
		globalRef(ast, "pcall"),
		{ Ast.FunctionLiteralExpression({}, body) }
	);
end

function RobloxGuard:apply(ast)
	local body = ast.body;

	-- typeof only exists inside the Roblox engine, so this is the first gate.
	-- In plain Lua it is nil and the whole `and` chain short circuits here,
	-- meaning none of the Roblox calls below are ever evaluated.
	local typeofRef = globalRef(ast, "typeof");
	local condition = Ast.NotEqualsExpression(typeofRef, Ast.NilExpression());

	local function andWith(expr)
		condition = Ast.AndExpression(condition, expr, false);
	end

	local function instanceOf(expr)
		return Ast.EqualsExpression(
			Ast.FunctionCallExpression(typeofRef, { expr }),
			Ast.StringExpression("Instance")
		);
	end

	local function typeofEquals(expr, typeName)
		return Ast.EqualsExpression(
			Ast.FunctionCallExpression(typeofRef, { expr }),
			Ast.StringExpression(typeName)
		);
	end

	-- game:GetService(name)
	local function getService(name)
		return Ast.PassSelfFunctionCallExpression(
			globalRef(ast, "game"),
			"GetService",
			{ Ast.StringExpression(name) }
		);
	end

	----------------------------------------------------------------------
	-- 1. Базовые проверки движка
	----------------------------------------------------------------------
	if self.CheckGame then
		andWith(instanceOf(globalRef(ast, "game")));
	end
	if self.CheckWorkspace then
		andWith(instanceOf(globalRef(ast, "workspace")));
	end
	if self.CheckScript then
		andWith(instanceOf(globalRef(ast, "script")));
	end

	----------------------------------------------------------------------
	-- 2. Реальные вызовы Roblox DataModel API
	----------------------------------------------------------------------
	if self.CheckService and #self.CheckService > 0 then
		andWith(pcallFn(ast, body.scope, function(s)
			local decl, svc = localVar(s, getService(self.CheckService));
			return { decl }, instanceOf(svc);
		end));
	end

	if self.CheckGuid then
		andWith(pcallFn(ast, body.scope, function(s)
			local d1, http = localVar(s, getService("HttpService"));
			local d2, guid = localVar(s, Ast.PassSelfFunctionCallExpression(
				http, "GenerateGUID", { Ast.BooleanExpression(false) }
			));
			return { d1, d2 }, Ast.AndExpression(
				typeofEquals(guid, "string"),
				Ast.EqualsExpression(Ast.LenExpression(guid), Ast.NumberExpression(36)),
				false
			);
		end));
	end

	if self.CheckLogService then
		andWith(pcallFn(ast, body.scope, function(s)
			local decl, history = localVar(s, Ast.PassSelfFunctionCallExpression(
				getService("LogService"), "GetLogHistory", {}
			));
			return { decl }, typeofEquals(history, "table");
		end));
	end

	if self.CheckTerrain then
		andWith(instanceOf(Ast.IndexExpression(globalRef(ast, "workspace"), Ast.StringExpression("Terrain"))));
	end

	if self.CheckRunService then
		andWith(pcallFn(ast, body.scope, function(s)
			local decl, isStudio = localVar(s, Ast.PassSelfFunctionCallExpression(
				getService("RunService"), "IsStudio", {}
			));
			return { decl }, typeofEquals(isStudio, "boolean");
		end));
	end

	if self.CheckTick then
		andWith(pcallFn(ast, body.scope, function()
			return {}, typeofEquals(Ast.FunctionCallExpression(globalRef(ast, "tick"), {}), "number");
		end));
	end

	----------------------------------------------------------------------
	-- 3. Опциональные (могут не пройти в Roblox Studio — читайте описание)
	----------------------------------------------------------------------
	if self.CheckPlaceId then
		andWith(Ast.NotEqualsExpression(
			Ast.IndexExpression(globalRef(ast, "game"), Ast.StringExpression("PlaceId")),
			Ast.NumberExpression(0)
		));
	end

	if self.CheckJobId then
		andWith(pcallFn(ast, body.scope, function(s)
			local decl, jobId = localVar(s, Ast.IndexExpression(globalRef(ast, "game"), Ast.StringExpression("JobId")));
			return { decl }, Ast.AndExpression(
				typeofEquals(jobId, "string"),
				Ast.GreaterThanExpression(Ast.LenExpression(jobId), Ast.NumberExpression(0)),
				false
			);
		end));
	end

	----------------------------------------------------------------------
	-- Ветка «мы не в Roblox»
	----------------------------------------------------------------------
	local ifScope = Scope:new(body.scope);
	local actionBlock;

	if self.Action == "error" then
		actionBlock = Ast.Block({
			Ast.FunctionCallStatement(
				globalRef(ast, "error"),
				{ Ast.StringExpression(self.ErrorMessage) }
			)
		}, ifScope);
	elseif self.Action == "decoy" and self.BranchVar and self.BranchVar ~= "" then
		-- Ложная ветка (этап 5, пункт 6). НИКАКОГО return: скрипт должен
		-- продолжиться и дойти до ветки, где вместо настоящего кода
		-- выполнится правдоподобная пустышка. Ранний выход здесь был бы
		-- ровно тем сигналом («защита сработала»), который мы убираем.
		--
		-- Флаг ветки НЕ тот же, что у порчи: окружение и правка файла —
		-- разные события, и отвечать на них надо по-разному.
		--
		-- Присваивание завёрнуто в pcall(function() ... end) — напрямую
		-- Vmify его не переваривает (см. комментарий в ветке spoil).
		actionBlock = Ast.Block({
			Ast.FunctionCallStatement(
				globalRef(ast, "pcall"),
				{ Ast.FunctionLiteralExpression({}, Ast.Block({
						Ast.AssignmentStatement(
							{ globalAssign(ast, self.BranchVar) },
							{ Ast.BooleanExpression(true) }
						)
				}, Scope:new(ifScope))) }
			)
		}, ifScope);
	elseif self.Action == "spoil" and self.PoisonVar and self.PoisonVar ~= "" then
		-- Fail-slow: НИКАКИХ error() и сообщений. Пишем в флаг число =
		-- задержка в обращениях до начала порчи. Программа продолжает
		-- работать, только результаты постепенно расходятся.
		actionBlock = Ast.Block({
			-- Присваивание завёрнуто в pcall(function() ... end).
			-- Напрямую Vmify его не переваривает: шаг умирает на этапе Vmify
			-- без сообщения об ошибке (проверено на 30 сидах — 0 удачных сборок).
			-- Через замыкание собирается нормально.
			Ast.FunctionCallStatement(
				globalRef(ast, "pcall"),
				{ Ast.FunctionLiteralExpression({}, Ast.Block({
						Ast.AssignmentStatement(
							{ globalAssign(ast, self.PoisonVar) },
							{ Ast.NumberExpression(math.random(3, 16)) }
						)
				}, Scope:new(ifScope))) }
			)
		}, ifScope);
	elseif self.Action == "loop" then
		local loopScope = Scope:new(ifScope);
		actionBlock = Ast.Block({
			Ast.WhileStatement(
				Ast.Block({}, Scope:new(loopScope)),
				Ast.BooleanExpression(true),
				loopScope
			)
		}, ifScope);
	else
		actionBlock = Ast.Block({ Ast.ReturnStatement({}) }, ifScope);
	end

	table.insert(body.statements, 1, Ast.IfStatement(
		Ast.NotExpression(condition, false),
		actionBlock,
		{},
		nil
	));
end

return RobloxGuard;
