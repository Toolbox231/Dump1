-- ═══════════════════════════════════════════════════════════════
--  Простой тестовый скрипт для проверки обфускации в Roblox
--  Работает и в Script (сервер), и в LocalScript (клиент)
-- ═══════════════════════════════════════════════════════════════

local RunService = game:GetService("RunService")

print("=== Проверка обфускации ===")
print("PlaceId: " .. tostring(game.PlaceId))
print("IsStudio: " .. tostring(RunService:IsStudio()))

-- Простая математика
local counter = 0
for i = 1, 5 do
	counter = counter + i
end
print("Сумма 1..5 = " .. tostring(counter))

-- Строка, которая после обфускации должна быть зашифрована
local secret = "Обфусцированный скрипт работает!"
print(secret)

-- Функция с условием
local function checkValue(value)
	if value > 10 then
		return "больше десяти"
	end
	return "меньше или равно десяти"
end

print("Проверка 15: " .. checkValue(15))
print("Проверка 7: " .. checkValue(7))

print("=== Конец ===")
