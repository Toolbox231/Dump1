@echo off
rem Обфускация: Windows. Запуск: obfuscate.bat мой_скрипт.lua готовый.lua
setlocal
set DIR=%~dp0
set LUA=%DIR%tools\windows\lua5.1.exe
if not exist "%LUA%" (
  echo ne nayden interpreter Lua: %LUA%
  exit /b 1
)
"%LUA%" "%DIR%obfuscator\obfuscate.lua" %*
endlocal
