#!/bin/sh
# Обфускация: Linux / macOS. Запуск: ./obfuscate.sh мой_скрипт.lua готовый.lua
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

case "$(uname -s 2>/dev/null || echo unknown)" in
	Linux)  LUA="$DIR/tools/linux/lua" ;;
	Darwin) LUA="$DIR/tools/macos/lua5.1" ;;
	*)      echo "не удалось определить ОС; запустите вручную:" >&2
	        echo "  lua obfuscator/obfuscate.lua вход.lua выход.lua" >&2
	        exit 1 ;;
esac

# Права на выполнение часто теряются при распаковке архива.
[ -x "$LUA" ] || chmod +x "$LUA" 2>/dev/null || true
[ -x "$DIR/luau/$( [ "$(uname -s)" = Linux ] && echo linux || echo macos )/luau-compile" ] && \
	chmod +x "$DIR/luau/linux/luau-compile" "$DIR/luau/macos/luau-compile" 2>/dev/null || true

if [ ! -x "$LUA" ]; then
	echo "не найден интерпретатор Lua: $LUA" >&2
	exit 1
fi

exec "$LUA" "$DIR/obfuscator/obfuscate.lua" "$@"
