-- Имитация Roblox API для проверки обфусцированных скриптов в обычном Lua.
--
-- Покрывает API, которые использует RobloxGuard:
--   typeof, game:GetService(), HttpService:GenerateGUID,
--   LogService:GetLogHistory(), workspace.Terrain, RunService:IsStudio(), tick()
--
-- print() переопределён так, чтобы реально складывать сообщения в историю лога —
-- это нужно для проверки RobloxConsoleEcho.

local function newInstance(className, extra)
	local inst = { ClassName = className }
	if extra then
		for k, v in pairs(extra) do
			inst[k] = v
		end
	end
	return inst
end

function typeof(value)
	if type(value) == "table" and value.ClassName then
		return "Instance"
	end
	return type(value)
end

function tick()
	return os.time() + (os.clock() % 1)
end

-- ── История лога (как LogService в Roblox) ──────────────────────────────
local logHistory = {}

local function recordMessage(msg, messageType)
	table.insert(logHistory, {
		message = tostring(msg),
		messageType = messageType or "MessageOutput",
		timestamp = os.time(),
	})
end

local realPrint = print
function print(...)
	local parts = {}
	for i = 1, select("#", ...) do
		parts[i] = tostring((select(i, ...)))
	end
	local msg = table.concat(parts, "\t")
	recordMessage(msg, "MessageOutput")
	realPrint(msg)
end

-- Минимальная реализация события (RBXScriptSignal)
local function newSignal()
	local signal = { _handlers = {} }
	function signal:Connect(fn)
		table.insert(self._handlers, fn)
		return { Disconnect = function() end }
	end
	function signal:Fire(...)
		for _, fn in ipairs(self._handlers) do
			fn(...)
		end
	end
	return signal
end

-- ── Сервисы ─────────────────────────────────────────────────────────────
local guidCounter = 0
local httpServiceMock = newInstance("HttpService")
function httpServiceMock:GenerateGUID(wrapInCurlyBraces)
	guidCounter = guidCounter + 1
	local g = string.format(
		"%08X-%04X-4%03X-%04X-%012X",
		guidCounter, guidCounter * 7 % 0x10000, guidCounter * 13 % 0x1000,
		guidCounter * 17 % 0x10000, guidCounter * 7919 % 0x1000000000000
	)
	if wrapInCurlyBraces then
		return "{" .. g .. "}"
	end
	return g
end

local logServiceMock = newInstance("LogService")
function logServiceMock:GetLogHistory()
	return logHistory
end

local runServiceMock = newInstance("RunService")
function runServiceMock:IsStudio() return false end
function runServiceMock:IsServer() return false end
function runServiceMock:IsClient() return true end
runServiceMock.RenderStepped = newSignal()
runServiceMock.Heartbeat = newSignal()

local humanoid = newInstance("Humanoid", { WalkSpeed = 16, MaxHealth = 100, Health = 100 })
local character = newInstance("Model", {})
function character:WaitForChild(name)
	return humanoid
end

local function newPlayer(name)
	local player = newInstance("Player", { Name = name })
	player.CharacterAdded = newSignal()
	return player
end

local localPlayer = newPlayer("TestPlayer")

local playersMock = newInstance("Players")
playersMock.LocalPlayer = localPlayer
playersMock.PlayerAdded = newSignal()
function playersMock:GetPlayers()
	return { localPlayer }
end

local userInputServiceMock = newInstance("UserInputService")
function userInputServiceMock:IsKeyDown(keyCode)
	return false
end

game = newInstance("DataModel", { PlaceId = 987654321, GameId = 555111, JobId = "job-abc-123" })
local services = {
	Players = playersMock,
	RunService = runServiceMock,
	UserInputService = userInputServiceMock,
	HttpService = httpServiceMock,
	LogService = logServiceMock,
}
function game:GetService(name)
	return assert(services[name], "Unknown service: " .. tostring(name))
end

workspace = newInstance("Workspace")
workspace.Terrain = newInstance("Terrain")
script = newInstance("LocalScript")
Instance = { new = newInstance }

Enum = {
	KeyCode = {
		LeftShift = newInstance("EnumItem", { Name = "LeftShift" }),
	},
}

-- ── Дострой окружения до Roblox-Luau ─────────────────────────────────────
-- Это НЕ часть Roblox API, а вещи, которых в Lua 5.1 просто нет. Имитация
-- обязана их предоставлять, иначе скрипт, проверяющий «я внутри Roblox/Luau»,
-- будет ложно срабатывать на нашей же песочнице — и мы начнём гоняться за
-- защитой, которая ломает сама себя.

-- game.Workspace и workspace — один и тот же объект. Identity-проверка
-- (game.Workspace == workspace) опирается именно на это.
game.Workspace = workspace
game.PlaceId = 0
game.JobId = ""
game.GameId = 0

-- task.* есть в Roblox, отсутствует в Luau CLI.
task = {
	wait = function(n) return n or 0 end,
	delay = function(n, f) return { Disconnect = function() end } end,
	spawn = function(f, ...) return f(...) end,
	defer = function(f, ...) return f(...) end,
	cancel = function() end,
	synchronize = function() end,
	desynchronize = function() end,
}

-- debug.info есть в Luau; в Lua 5.1 только debug.getinfo. Реализуем
-- совместимую обёртку, чтобы один и тот же скрипт шёл в обеих средах.
if debug and debug.info == nil then
	function debug.info(threadOrFunc, ...)
		local opts = select(1, ...)
		if type(threadOrFunc) ~= "function" and type(threadOrFunc) ~= "number" then
			opts = threadOrFunc
			threadOrFunc = 1
		end
		if opts == nil then opts = "sln" end
		local ok, info = pcall(debug.getinfo, threadOrFunc, ({
			s = "S", l = "l", n = "n", a = "n", f = "f",
		})[opts] or opts)
		if not ok or type(info) ~= "table" then return nil end
		if opts == "s" then
			return info.what == "C" and "=[C]" or (info.source or "?")
		end
		return info[({ l = "currentline", n = "name" })[opts]] or info[opts]
	end
end

-- bit32 есть и в Luau, и в Roblox; в Lua 5.1 отсутствует.
if bit32 == nil then
	local function tobits(n)
		n = n % 2 ^ 32
		local t = {}
		for i = 1, 32 do
			t[i] = n % 2
			n = (n - n % 2) / 2
		end
		return t
	end
	local function frombits(t)
		local n = 0
		for i = 32, 1, -1 do n = n * 2 + t[i] end
		return n % 2 ^ 32
	end
	bit32 = {
		band = function(...)
			local r = tobits(select(1, ...) or 0)
			for i = 2, select("#", ...) do
				local b = tobits((select(i, ...)))
				for k = 1, 32 do r[k] = (r[k] == 1 and b[k] == 1) and 1 or 0 end
			end
			return frombits(r)
		end,
		bor = function(...)
			local r = tobits(select(1, ...) or 0)
			for i = 2, select("#", ...) do
				local b = tobits((select(i, ...)))
				for k = 1, 32 do r[k] = (r[k] == 1 or b[k] == 1) and 1 or 0 end
			end
			return frombits(r)
		end,
		bxor = function(...)
			local r = tobits(select(1, ...) or 0)
			for i = 2, select("#", ...) do
				local b = tobits((select(i, ...)))
				for k = 1, 32 do r[k] = (r[k] ~= b[k]) and 1 or 0 end
			end
			return frombits(r)
		end,
		bnot = function(n)
			local r = tobits(n)
			for k = 1, 32 do r[k] = r[k] == 1 and 0 or 1 end
			return frombits(r)
		end,
		lshift = function(n, s) return (n * 2 ^ s) % 2 ^ 32 end,
		rshift = function(n, s) return math.floor(n / 2 ^ s) % 2 ^ 32 end,
		extract = function(n, f, w)
			w = w or 1
			return math.floor(n / 2 ^ f) % 2 ^ w
		end,
		replace = function(n, v, f, w)
			w = w or 1
			local m = 2 ^ w - 1
			return (n - (math.floor(n / 2 ^ f) % 2 ^ w) * 2 ^ f) + (v % 2 ^ w) * 2 ^ f
		end,
	}
end

-- Если передан путь к файлу первым аргументом — запускаем его.
-- Без аргумента просто поднимаем окружение (удобно для require-тестов).
local target = arg and arg[1]
if target then
	dofile(target)
end
