-- ═══════════════════════════════════════════════════════════════════════════
--  verify.lua — проверка обфусцированного файла на чистом Lua 5.1
--
--  Запускает файл под настоящим Luau в окружении, которое притворяется
--  Roblox, и показывает вывод. Плюс два контрольных прогона, которые
--  нельзя сделать «на глаз»:
--
--    • --no-fire — события НЕ дёргаются. С отложенной активацией вывод
--      обязан быть полностью пустым: это и есть доказательство, что
--      полезная нагрузка не выполнилась на загрузке.
--
--    • --hostile — чужое окружение (без мока Roblox). Должна сработать
--      ложная ветка: скрипт выдаёт правдоподобный, но чужой вывод.
--
--  Использование:
--      lua verify.lua [флаги] <файл.lua>
--
--  Флаги:
--      --no-fire    не дёргать события (проверка отложенной активации)
--      --hostile    запустить без мока Roblox (проверка ложной ветки)
--      --timeout=N  предел времени на прогон, секунд (по умолчанию 60)
-- ═══════════════════════════════════════════════════════════════════════════

local WIN = package.config:sub(1, 1) == "\\"
local SEP = WIN and "\\" or "/"

local HERE = (arg and arg[0] or ""):match("^(.-)[/\\]?[^/\\]*$")
if HERE == "" then HERE = "." end
local ROOT = HERE .. SEP .. ".."

local no_fire, hostile, timeout, target = false, false, 60, nil

for _, a in ipairs(arg or {}) do
	if a == "--no-fire" then no_fire = true
	elseif a == "--hostile" then hostile = true
	elseif a:match("^%-%-timeout=") then timeout = tonumber(a:match("=(%d+)")) or 60
	elseif a:sub(1, 2) ~= "--" and a ~= (arg and arg[0]) then target = a
	end
end

if not target then
	io.stderr:write(" usage: lua verify.lua [флаги] <файл.lua>\n")
	os.exit(2)
end

------------------------------------------------------------------------------
-- Путь к бинарям Luau под текущую платформу
------------------------------------------------------------------------------
local function platform()
	if WIN then return "windows" end
	local pipe = io.popen("uname -s")
	if pipe then
		local name = (pipe:read("*a") or ""):lower()
		pipe:close()
		if name:find("linux") then return "linux" end
	end
	return "macos"
end

local SUB = platform()
local EXE = WIN and ".exe" or ""
local LUAU = ROOT .. SEP .. "luau" .. SEP .. SUB .. SEP .. "luau" .. EXE
local LUAUC = ROOT .. SEP .. "luau" .. SEP .. SUB .. SEP .. "luau-compile" .. EXE

local function readfile(path)
	local fh, err = io.open(path, "rb")
	if not fh then return nil, err end
	local d = fh:read("*a")
	fh:close()
	return d
end

local function writefile(path, data)
	local fh, err = io.open(path, "wb")
	if not fh then return nil, err end
	fh:write(data)
	fh:close()
	return true
end

local function exists(path)
	local fh = io.open(path, "rb")
	if fh then fh:close() return true end
	return false
end

if not exists(LUAU) then
	io.stderr:write(" не нашёл интерпретатор Luau: " .. LUAU .. "\n")
	os.exit(1)
end

local source, err = readfile(target)
if not source then
	io.stderr:write(" не могу прочитать " .. target .. ": " .. tostring(err) .. "\n")
	os.exit(1)
end

------------------------------------------------------------------------------
-- Свёртка текста в ОДНУ строку
--
-- Проверяемый файл минифицирован и занимает ровно одну строку, а AntiTamper
-- сверяет АБСОЛЮТНЫЙ номер строки. Любой перевод строки в преамбуле
-- сдвинул бы файл на строку 2, проверка сработала бы, и мы измеряли бы
-- ИСПОРЧЕННЫЙ вывод, выдавая его за чистый. Поэтому всё, что идёт ДО
-- файла, склеивается без единого перевода.
------------------------------------------------------------------------------
local function oneline(text)
	local out = {}
	for ln in tostring(text):gmatch("[^\r\n]*") do
		local i = ln:find("--", 1, true)
		if i and not ln:sub(1, i - 1):find('"', 1, true)
		     and not ln:sub(1, i - 1):find("'", 1, true) then
			ln = ln:sub(1, i - 1)
		end
		ln = ln:gsub("^%s+", ""):gsub("%s+$", "")
		if ln ~= "" then out[#out + 1] = ln end
	end
	return table.concat(out, " ")
end

-- Достройка окружения: в CLI Luau нет io и task, а скрипт их использует.
local SHIM = [[
if io == nil then
	io = { write = function(...)
		local t = {}
		for i = 1, select("#", ...) do t[i] = tostring((select(i, ...))) end
		print(table.concat(t))
	end }
end
if task == nil then
	task = { wait = function() end, defer = function(f, ...) return f(...) end,
	         spawn = function(f, ...) return f(...) end, delay = function() end }
end
]]

-- Эпилог: дёрнуть все события, на которые скрипт успел подписаться.
--
-- Без него отложенная активация в CLI Luau не сработает никогда: цикла
-- событий здесь нет, загрузка закончится, и мы будем мерять пустоту,
-- приняв её за поломку.
local EPILOGUE = [[
pcall(function()
	local rs = rawget(_G, "RunService")
	if type(rs) ~= "table" and type(game) == "table"
		and type(game.GetService) == "function" then
		pcall(function() rs = game:GetService("RunService") end)
	end
	if type(rs) ~= "table" then return end
	for _, name in ipairs({ "Heartbeat", "RenderStepped", "Stepped" }) do
		local sig = rs[name]
		if type(sig) == "table" and type(sig.Fire) == "function" then
			local ok, err = pcall(function() sig:Fire(0.016) end)
			if not ok then
				print("[эпилог] обработчик кадра упал: " .. tostring(err))
			end
		end
	end
end)
]]

local MOCK_PATH = HERE .. SEP .. "mock_roblox.lua"
local parts = {}

if not hostile then
	parts[#parts + 1] = oneline(SHIM)
	local mock = readfile(MOCK_PATH)
	if not mock then
		io.stderr:write(" не нашёл мок Roblox: " .. MOCK_PATH .. "\n")
		os.exit(1)
	end
	parts[#parts + 1] = oneline(mock)
end

-- Цель оборачивается в функцию: минифицированный файл — это
-- `return (function(...) ... end)(...)`, то есть последний оператор файла
-- есть return. Всё, что дописано после return, даёт синтаксическую ошибку
-- «Expected <eof>». Обёртка превращает файл в вызов, после которого
-- эпилог уже законен.
-- Разделитель `;` ставится ТОЛЬКО если перед целью что-то уже есть.
-- Luau не понимает `;` в начале файла («Expected identifier, got ';'»),
-- а в чужом режиме цель идёт первой — преамбулы нет.
local body = source:gsub("%s+$", "")
local wrapped = "(function(...) " .. body .. " end)(...)"
if #parts > 0 then
	parts[#parts + 1] = "; " .. wrapped .. " ;"
else
	parts[#parts + 1] = wrapped .. " ;"
end
if not no_fire then
	parts[#parts + 1] = oneline(EPILOGUE)
end

local tmp = os.tmpname()
if WIN and not tmp:find("%.") then tmp = tmp .. ".lua" end
local tmpname = tmp:gsub("%.+$", "") .. ".lua"
writefile(tmpname, table.concat(parts, " "))

local q = WIN and '"' or "'"
local cmd = q .. LUAU .. q .. " " .. q .. tmpname .. q
local pipe = io.popen(cmd .. " 2>&1")
local output = pipe and pipe:read("*a") or ""
if pipe then pipe:close() end

os.remove(tmpname)

io.stdout:write(output)

------------------------------------------------------------------------------
-- Разбор результата
------------------------------------------------------------------------------
io.stdout:write("──────────────────────────────────────────────────\n")

if hostile then
	if output:find("эпилог", 1, true) or output:find("stacktrace", 1, true) then
		io.stdout:write(" ✘ скрипт упал в чужой среде — защита себя выдала\n")
		os.exit(1)
	end
	io.stdout:write(" ✔ чужое окружение: скрипт отработал без падения\n")
	io.stdout:write("   (ложная ветка — вывод правдоподобный, но чужой)\n")
	os.exit(0)
end

if no_fire then
	if output:gsub("%s", "") == "" then
		io.stdout:write(" ✔ ПОЛНАЯ ТИШИНА — нагрузка отложена, на загрузке не выполнилась\n")
		os.exit(0)
	end
	io.stdout:write(" ✘ без кадра что-то выполнилось — отложенная активация не работает\n")
	os.exit(1)
end

if output:find("эпилог", 1, true) or output:find("stacktrace", 1, true) then
	io.stdout:write(" ✘ есть ошибка выполнения\n")
	os.exit(1)
end
io.stdout:write(" ✔ файл запустился под Luau в окружении Roblox\n")
