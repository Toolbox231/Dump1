#!/bin/sh
# Проверка готового файла: Linux / macOS. Запуск: ./verify.sh готовый.lua
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

case "$(uname -s 2>/dev/null || echo unknown)" in
	Linux)  LUA="$DIR/tools/linux/lua"; SUB=linux ;;
	Darwin) LUA="$DIR/tools/macos/lua5.1"; SUB=macos ;;
	*)      echo "не удалось определить ОС" >&2; exit 1 ;;
esac

[ -x "$LUA" ] || chmod +x "$LUA" 2>/dev/null || true
chmod +x "$DIR/luau/$SUB/luau" "$DIR/luau/$SUB/luau-compile" 2>/dev/null || true

exec "$LUA" "$DIR/verify/verify.lua" "$@"
