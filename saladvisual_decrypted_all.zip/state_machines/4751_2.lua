-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4751] / function #2
-- offset 3080307..3127392 (47085 bytes, type=state-machine)

function(...)
  local P,Z,G,Y,e,j,C;
  local N,q,b,D,p,r=3189571861;
  local K=c(J);
  local J;
  if a==25 then
    J=H;
    while true do
      local c,k=d[J];
      if c<23 then
        if c>=11 then
          if c>=17 then
            if c>=20 then
              if c>=21 then
                if c~=22 then
                  e,q,D,r=r[9],r[8],r[5],r[6];
                  J=f[J];
                else
                  K[4]=m[L[J]];
                  K[4]=K[4](K[36]);
                  K[7]=K[d[J+1]]~=y[J];
                  J=T[J]-1+1;
                end
              else
                C=4;
                K[5]=#K[35];
                K[4]=1;
                K[d[J+1]]=1;
                K[7]=l[J+1];
                K[12]=L[J];
                k=r;
                r,D,q={[6]=k,[8]=q,[9]=e,[5]=D},K[6]+0,K[5]+0;
                e=K[C]-D;
                J=z[J+1]-1+1;
              end
            else
              if c<18 then
                C,Z,Y,b=B(N,O(S(N,14),262143),(O(S(N,28),15))),f[J],T[J],z[J];
                p=Y<16384 and 7 or(Y<2097152 and 14 or 21);
                G,P=O(Y,A(1,p)-1),S(Y,p);
                T[J]=B(G,62,(O(S(C,7),127)));
                z[J]=B(b,107,(O(S(C,14),127)));
                d[J]=B(P,94,(O(S(C,21),127)));
                f[J]=B(Z,73,(O(C,127)));
                J=J-1;
              else
                if c~=19 then
                  K[10]=L[J]+K[11];
                  K[13]=K[9]+L[J+1];
                  K[12]=w(y[J+1],K[13]);
                  K[13]=K[2]+498024281;
                  local v,I=K[13];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[13]=I;
                  K[d[J+1]]=K[13]==343971351;
                  J=(if K[13]then T[J+1]-1 else T[J]-1)+1;
                else
                  K[4]=m[y[J+1]];
                  K[d[J+1]]=s[14];
                  K[6]=s[21];
                  K[T[J+1]]=s[112];
                  K[9]=s[15];
                  K[10]=s[34];
                  local v,I=K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[5]=I;
                  v,I=K[6];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[6]=I;
                  v,I=K[8];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[8]=I;
                  I,v=K[9];
                  repeat
                    local i=I%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[9]=v;
                  J=z[J]-1+1;
                end
              end
            end
          else
            if c>=14 then
              if c>=15 then
                if c~=16 then
                  Z,C=(B(T[J],(O(B(N,(O(S(N,29),7))),536870911)))),f[J]+1;
                  for v=1,z[J],1 do
                    Z=O(B(Z,(A(Z,13))),536870911);
                    Z=B(Z,(S(Z,13)));
                    Z=O(B(Z,(A(Z,14))),536870911);
                    f[C]=B(f[C],(O(S(Z,0),127)));
                    T[C]=B(T[C],(O(S(Z,7),127)));
                    z[C]=B(z[C],(O(S(Z,14),127)));
                    d[C]=B(d[C],(O(S(Z,21),127)));
                    C=C+1;
                  end;
                  d[J]=41;
                else
                  J=T[J];
                end
              else
                K[7]=not K[4];
                local v,I=K[2];
                repeat
                  local i=v%4294967296;
                  if i~=i then
                    I=0;
                    break;
                  end
                  I=i-i%1;
                until true;
                K[4]=I;
                K[2]=B(K[4],f[J]);
                K[4]=L[J];
                N=K[4];
                J=T[J];
              end
            else
              if c>=12 then
                if c==13 then
                  J=T[J];
                else
                  local v,I=K[d[J+1]];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[5]=I;
                  K[6]=K[4];
                  v,I=K[6];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[6]=I;
                  K[d[J+3]]=K[6]+l[J];
                  local i,E,Q=d[J+2],l[J+2],J+2;
                  I,v=K[f[Q]],O(E,4294967295);
                  local t,R,g=O(I,4294967295),O(v,65535),S(v,16);
                  I,v=O(t,65535),S(t,16);
                  E=O(R*I+A(O(R*v+g*I,65535),16),4294967295);
                  g=nil;
                  repeat
                    v=E%4294967296;
                    if v~=v then
                      g=0;
                      break;
                    end
                    g=v-v%1;
                  until true;
                  K[i]=g;
                  K[T[J+3]]=L[J+2]+K[8];
                  K[T[J+1]]=K[z[J+3]]+y[J+1];
                  K[6]=w(y[J],K[f[J+3]]);
                  g,E=z[J+1],K[6];
                  R,v=O(g,4294967295),O(E,4294967295);
                  i,E,Q,t=O(R,65535),S(R,16),O(v,65535),S(v,16);
                  v=O(i*Q+A(O(i*t+E*Q,65535),16),4294967295);
                  t=nil;
                  repeat
                    i=v%4294967296;
                    if i~=i then
                      t=0;
                      break;
                    end
                    t=i-i%1;
                  until true;
                  K[6]=t;
                  K[6]=K[6]+L[J];
                  J+=3;
                end
              else
                C,Z={...},f[J];
                F(C,1,d[J+1],Z,K);
                K[4]=l[J+1];
                N=K[4];
                K[2]=B(L[J+1],y[J+1]);
                K[T[J]]=s[14];
                K[5]=s[21];
                K[6]=s[112];
                K[7]=s[15];
                J=z[J]-1+1;
              end
            end
          end
        else
          if c>=5 then
            if c<8 then
              if c>=6 then
                if c==7 then
                  Z,C=z[J],f[J]+1;
                  for v=1,T[J],1 do
                    Z=O(B(Z,(A(Z,13))),536870911);
                    Z=B(Z,(S(Z,13)));
                    Z=O(B(Z,(A(Z,14))),536870911);
                    f[C]=B(f[C],(O(S(Z,0),127)));
                    T[C]=B(T[C],(O(S(Z,7),127)));
                    z[C]=B(z[C],(O(S(Z,14),127)));
                    d[C]=B(d[C],(O(S(Z,21),127)));
                    C=C+1;
                  end;
                  d[J]=41;
                else
                  C,Z,Y=4,d[J+1],d[J+2];
                  b,p=C+Y-1,C+Z;
                  G=K[p];
                  P=G.n;
                  j=Z+P-1;
                  G.n=j;
                  F(G,1,P,Z,G);
                  F(K,5,p-1,1,G);
                  F(h(K[C](W(G,1,G.n))),1,Y,C,K);
                  K[7]=K[4];
                  K[f[J+2]]=K[2];
                  K[f[J]]=B(K[4],z[J+1]);
                  K[8]=o[T[J]];
                  K[10]=7;
                  K[9]=K[f[J+1]];
                  C=T[J+1];
                  Z,Y,b,p=K[C],K[C+1],K[C+2],K[C+3];
                  K[C]=Z(Y,b,p);
                  K[z[J+2]]=K[2];
                  K[5]=B(K[4],z[J]);
                  J=T[J+2]-2+2;
                end
              else
                C=4;
                K[9]=o[T[J]];
                K[4]=K[9];
                K[6]=K[8];
                Z,Y,b,p=K[C],K[5],K[6],K[7];
                K[C]=Z(Y,b,p);
                K[12]=K[z[J]];
                J=f[J];
              end
            else
              if c>=9 then
                if c~=10 then
                  C,Y=11,1;
                  K[5]=K[5]+l[J];
                  local v,I=K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[13]=I;
                  K[11]=o[f[J]];
                  K[14]=16;
                  b,K[C]=8,h(K[C](W(K,12,14)));
                  C=8;
                  K[9]=B(K[2],99624956);
                  K[8]=o[T[J+1]];
                  K[d[J+1]]=K[12];
                  Z=z[J+1];
                  p=C+Z;
                  G=K[p];
                  P=G.n;
                  j=Z+P-1;
                  G.n=j;
                  F(G,1,P,Z,G);
                  F(K,9,p-1,1,G);
                  P=h(K[C](W(G,1,G.n)));
                  F(P,1,Y,C,K);
                  J=z[J]-1+1;
                else
                  local v,I,i=f[J],B(T[J],(O(B(N,(O(S(N,29),7))),536870911))),n[6];
                  local E=B(i[v],187638924);
                  i[v]=E;
                  v,i=n[5],E+1;
                  E=V(v,i);
                  local Q,t;
                  if E<128 then
                    Q,t=E,i+1;
                  else
                    local R=V(v,i+1);
                    if R<128 then
                      Q,t=(E-128)*128+R,i+2;
                    else
                      local g=V(v,i+2);
                      if g<128 then
                        Q,t=(E-128)*16384+(R-128)+g*128,i+3;
                      else
                        local u=V(v,i+3);
                        Q,t=E-128+(R-128)*2097152+(g-128)*128+u%128*16384+(u-u%128)*2097152,i+4;
                      end
                    end
                  end
                  E,i=I*16843009,t+Q;
                  local R=i-Q%4;
                  for Q=t,R-1,4 do
                    _(v,Q,(B(X(v,Q),E)));
                  end;
                  for E=R,i-1,1 do
                    x(v,E,(B(V(v,E),I)));
                  end;
                  f[J]=29;
                  T[J]=72;
                  z[J]=93;
                  d[J]=41;
                end
              else
                local v,I,i=d[J+6],y[J+6],K[12];
                local E,Q=O(I,4294967295),O(i,4294967295);
                local t,R,g,u=O(E,65535),S(E,16),O(Q,65535),S(Q,16);
                Q=O(t*g+A(O(t*u+R*g,65535),16),4294967295);
                E=nil;
                repeat
                  I=Q%4294967296;
                  if I~=I then
                    E=0;
                    break;
                  end
                  E=I-I%1;
                until true;
                K[v]=E;
                K[d[J+4]]=K[9]+l[J+1];
                K[d[J+1]]=O(L[J],K[d[J+2]]);
                Q,E=L[J+1],J+5;
                i,v=K[d[E]],O(Q,4294967295);
                g,Q,R=O(i,4294967295),O(v,65535),S(v,16);
                E,v=O(g,65535),S(g,16);
                t=O(Q*E+A(O(Q*v+R*E,65535),16),4294967295);
                i=nil;
                repeat
                  Q=t%4294967296;
                  if Q~=Q then
                    i=0;
                    break;
                  end
                  i=Q-Q%1;
                until true;
                K[9]=i;
                K[9]=K[d[J+3]]+K[T[J+5]];
                K[9]=K[10]+K[9];
                v,I,i=T[J+3],K[9];
                repeat
                  u=I%4294967296;
                  if u~=u then
                    i=0;
                    break;
                  end
                  i=u-u%1;
                until true;
                K[v]=i;
                K[2]=B(K[f[J+5]],283811062);
                v,Q=K[5];
                repeat
                  g=v%4294967296;
                  if g~=g then
                    Q=0;
                    break;
                  end
                  Q=g-g%1;
                until true;
                K[5]=Q;
                K[12]=K[5]+L[J+4];
                g,u=l[J+4],K[12];
                E,I=O(g,4294967295),O(u,4294967295);
                u,Q,v,t=O(E,65535),S(E,16),O(I,65535),S(I,16);
                R=O(u*v+A(O(u*t+Q*v,65535),16),4294967295);
                Q=nil;
                repeat
                  E=R%4294967296;
                  if E~=E then
                    Q=0;
                    break;
                  end
                  Q=E-E%1;
                until true;
                K[11]=Q;
                K[T[J]]=y[J+4]+K[11];
                K[z[J+2]]=K[z[J+6]]+L[J+3];
                K[f[J+1]]=w(y[J],K[13]);
                u,g=l[J+2],K[12];
                Q,E=O(u,4294967295),O(g,4294967295);
                u,g,v,t=O(Q,65535),S(Q,16),O(E,65535),S(E,16);
                E=O(u*v+A(O(u*t+g*v,65535),16),4294967295);
                u=nil;
                repeat
                  g=E%4294967296;
                  if g~=g then
                    u=0;
                    break;
                  end
                  u=g-g%1;
                until true;
                K[11]=u;
                K[T[J+6]]=K[5]+L[J+5];
                J=f[J+3]-6+6;
              end
            end
          else
            if c>=2 then
              if c>=3 then
                if c~=4 then
                  J=z[J];
                else
                  K[11]=K[d[J+3]]+d[J+4];
                  K[d[J+5]]=w(y[J+5],K[d[J+1]]);
                  local v,I=l[J+1],K[10];
                  local i,E=O(v,4294967295),O(I,4294967295);
                  local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                  E=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                  i=nil;
                  repeat
                    I=E%4294967296;
                    if I~=I then
                      i=0;
                      break;
                    end
                    i=I-I%1;
                  until true;
                  K[9]=i;
                  K[7]=K[7]+d[J+2];
                  K[7]=O(y[J+1],K[7]);
                  E,I=l[J+5],J+6;
                  t,Q=K[d[I]],O(E,4294967295);
                  E,v,i=O(t,4294967295),O(Q,65535),S(Q,16);
                  Q,t=O(E,65535),S(E,16);
                  R=O(v*Q+A(O(v*t+i*Q,65535),16),4294967295);
                  g=nil;
                  repeat
                    Q=R%4294967296;
                    if Q~=Q then
                      g=0;
                      break;
                    end
                    g=Q-Q%1;
                  until true;
                  K[7]=g;
                  K[f[J+4]]=K[9]+K[7];
                  K[7]=K[8]+K[7];
                  I,R=K[7];
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      R=0;
                      break;
                    end
                    R=v-v%1;
                  until true;
                  K[7]=R;
                  v,I=K[4];
                  repeat
                    t=v%4294967296;
                    if t~=t then
                      I=0;
                      break;
                    end
                    I=t-t%1;
                  until true;
                  K[4]=I;
                  K[10]=K[4]+L[J+2];
                  I,i=y[J],K[10];
                  g,R=O(I,4294967295),O(i,4294967295);
                  t,i,I,v=O(g,65535),S(g,16),O(R,65535),S(R,16);
                  g=O(t*I+A(O(t*v+i*I,65535),16),4294967295);
                  i=nil;
                  repeat
                    t=g%4294967296;
                    if t~=t then
                      i=0;
                      break;
                    end
                    i=t-t%1;
                  until true;
                  K[9]=i;
                  K[T[J]]=l[J+4]+K[9];
                  K[z[J+5]]=K[f[J+6]]+y[J+3];
                  K[10]=w(l[J+6],K[11]);
                  v,I,t=T[J+2],l[J+3],J+4;
                  R,i=K[z[t]],O(I,4294967295);
                  E,I,g=O(R,4294967295),O(i,65535),S(i,16);
                  i,t=O(E,65535),S(E,16);
                  E=O(I*i+A(O(I*t+g*i,65535),16),4294967295);
                  I=nil;
                  repeat
                    Q=E%4294967296;
                    if Q~=Q then
                      I=0;
                      break;
                    end
                    I=Q-Q%1;
                  until true;
                  K[v]=I;
                  K[4]=K[4]+L[J+1];
                  K[4]=B(L[J],K[4]);
                  K[z[J+6]]=K[2];
                  J+=6;
                end
              else
                K[d[J+1]]=O(L[J+2],K[6]);
                local v,I=y[J+1],K[6];
                local i,E=O(v,4294967295),O(I,4294967295);
                local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                I=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                R=nil;
                repeat
                  Q=I%4294967296;
                  if Q~=Q then
                    R=0;
                    break;
                  end
                  R=Q-Q%1;
                until true;
                K[6]=R;
                K[6]=K[9]+K[6];
                K[d[J+2]]=K[T[J]]+K[6];
                v,I=K[z[J+1]];
                repeat
                  t=v%4294967296;
                  if t~=t then
                    I=0;
                    break;
                  end
                  I=t-t%1;
                until true;
                K[6]=I;
                K[8]=K[5];
                g,t=K[8];
                repeat
                  Q=g%4294967296;
                  if Q~=Q then
                    t=0;
                    break;
                  end
                  t=Q-Q%1;
                until true;
                K[8]=t;
                K[11]=K[8]+T[J+1];
                R,i=L[J],K[11];
                g,Q=O(R,4294967295),O(i,4294967295);
                v,I,E,t=O(g,65535),S(g,16),O(Q,65535),S(Q,16);
                g=O(v*E+A(O(v*t+I*E,65535),16),4294967295);
                Q=nil;
                repeat
                  E=g%4294967296;
                  if E~=E then
                    Q=0;
                    break;
                  end
                  Q=E-E%1;
                until true;
                K[10]=Q;
                K[9]=279205178+K[f[J+2]];
                J+=2;
              end
            else
              J=if c==1 then if K[z[J]]then T[J]else f[J]else z[J];
            end
          end
        end
      else
        if c<34 then
          if c>=28 then
            if c>=31 then
              if c>=32 then
                if c==33 then
                  K[6]=K[7]+K[6];
                  local v,I,i=d[J+1],K[6];
                  repeat
                    local E=I%4294967296;
                    if E~=E then
                      i=0;
                      break;
                    end
                    i=E-E%1;
                  until true;
                  K[v]=i;
                  K[7]=K[4];
                  K[8]=K[2];
                  K[d[J+2]]=B(K[8],0);
                  K[8]=l[J];
                  N=K[z[J+2]];
                  i,I,v=f[J+2],K[f[J+1]];
                  repeat
                    local E=I%4294967296;
                    if E~=E then
                      v=0;
                      break;
                    end
                    v=E-E%1;
                  until true;
                  K[i]=v;
                  K[10]=K[7]+z[J+1];
                  v,i=K[f[J]],O(414206657,4294967295);
                  local E,Q,t=O(v,4294967295),O(i,65535),S(i,16);
                  i,I=O(E,65535),S(E,16);
                  v=O(Q*i+A(O(Q*I+t*i,65535),16),4294967295);
                  t=nil;
                  repeat
                    I=v%4294967296;
                    if I~=I then
                      t=0;
                      break;
                    end
                    t=I-I%1;
                  until true;
                  K[9]=t;
                  K[T[J+2]]=l[J+1]+K[z[J]];
                  J=J+2;
                else
                  K[8]=s[34];
                  local v,I=K[4];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[4]=I;
                  I,v=K[d[J+1]];
                  repeat
                    local i=I%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[5]=v;
                  I,v=K[6];
                  repeat
                    local i=I%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[6]=v;
                  v,I=K[7];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[7]=I;
                  I,v=K[8];
                  repeat
                    local i=I%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[8]=v;
                  K[4]=B(K[4],l[J+1]);
                  K[d[J+2]]=B(K[5],y[J]);
                  K[4]=K[f[J+2]]+K[5];
                  K[4]=L[J+2]+K[4];
                  K[5]=B(K[6],l[J+2]);
                  J=f[J+1]-2+2;
                end
              else
                C,e,q,D,r=4,r[9],r[8],r[5],r[6];
                K[5]=#K[34];
                K[4]=1;
                K[f[J]]=1;
                r,D,q={[6]=r,[8]=q,[9]=e,[5]=D},K[6]+0,K[5]+0;
                e=K[C]-D;
                J=z[J];
              end
            else
              if c<29 then
                K[6]=L[J];
                K[T[J]]=K[4];
                return K[5](W(K,6,8));
              else
                if c==30 then
                  K[5]=K[34];
                  Z=K[d[J+1]];
                  K[5]=Z;
                  K[4]=Z[y[J+2]];
                  C=d[J+2];
                  K[C]=K[C](K[C+1],K[C+2]);
                  K[5]=N;
                  C=6;
                  K[9]=B(K[5],l[J]);
                  K[6]=o[z[J+2]];
                  K[8]=5;
                  Z,Y,b,p=K[C],K[7],K[8],K[9];
                  K[C]=Z(Y,b,p);
                  K[5]=N;
                  K[9]=B(K[5],l[J+1]);
                  K[5]=o[f[J+1]];
                  J=z[J]-2+2;
                else
                  C=4;
                  K[11]=m[l[J+1]][y[J]];
                  K[4]=m[L[J]][l[J]];
                  K[6]=5;
                  K[5]=K[7];
                  Z=K[C];
                  Y,K[C]=1,Z(K[5],K[6]);
                  K[6]=K[d[J+1]];
                  Z=K[6];
                  K[6]=Z;
                  K[5]=Z[L[J+1]];
                  K[8]=K[5];
                  K[d[J+2]]=K[6];
                  C,Z=z[J+2],T[J+2];
                  b=C+Z;
                  K[C]=h(K[C](W(K,C+1,b)));
                  K[5]=K[f[J+2]];
                  K[6]=K[8];
                  K[4]=K[11];
                  J=f[J+1]-2+2;
                end
              end
            end
          else
            if c<25 then
              if c==24 then
                K[6]=K[d[J+3]]+K[8];
                K[5]=K[5]+K[6];
                local v,I=K[5];
                repeat
                  local i=v%4294967296;
                  if i~=i then
                    I=0;
                    break;
                  end
                  I=i-i%1;
                until true;
                K[5]=I;
                K[6]=K[5];
                v,I=K[6];
                repeat
                  local i=v%4294967296;
                  if i~=i then
                    I=0;
                    break;
                  end
                  I=i-i%1;
                until true;
                K[6]=I;
                K[d[J+2]]=L[J+2];
                N=K[d[J+1]];
                K[10]=K[6]+y[J];
                I,v=l[J+2],K[10];
                local i,E=O(I,4294967295),O(v,4294967295);
                local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                i=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                I=nil;
                repeat
                  R=i%4294967296;
                  if R~=R then
                    I=0;
                    break;
                  end
                  I=R-R%1;
                until true;
                K[9]=I;
                K[8]=L[J+3]+K[9];
                K[11]=K[f[J+1]]+L[J+1];
                K[10]=w(l[J],K[11]);
                R,I=L[J],K[10];
                v,Q=O(R,4294967295),O(I,4294967295);
                i,R,g,I=O(v,65535),S(v,16),O(Q,65535),S(Q,16);
                v=O(i*g+A(O(i*I+R*g,65535),16),4294967295);
                Q=nil;
                repeat
                  E=v%4294967296;
                  if E~=E then
                    Q=0;
                    break;
                  end
                  Q=E-E%1;
                until true;
                K[9]=Q;
                K[T[J+1]]=K[6]+y[J+3];
                J=f[J+2]-3+3;
              else
                K[6]=K[6]-1023;
                K[6]=d[J+1]^K[6];
                K[z[J+1]]=K[4]*K[6];
                K[5]=2*K[5];
                K[5]=z[J]-K[5];
                K[4]=K[5]*K[4];
                K[7]=K[36]~=K[4];
                J=(if K[7]then f[J+1]-1 else f[J]-1)+1;
              end
            else
              if c<26 then
                K[4]=o[z[J+1]];
                K[d[J+1]](y[J]);
                J=T[J+1]-1+1;
              else
                if c~=27 then
                  K[f[J]]=m[l[J]][L[J]];
                else
                  J=T[J];
                end
              end
            end
          end
        else
          if c<40 then
            if c<37 then
              if c<35 then
                C,K[8]=8,K[d[J+1]];
                K[10]=K[6];
                K[11]=K[4];
                K[C]=K[C](K[9],K[10],K[11]);
                K[7]=K[8];
                K[9]=m[y[J+1]][l[J]];
                K[11]=m[y[J]][y[J+4]];
                K[13]=13;
                C=d[J+3];
                K[C]=K[C](K[C+1],K[C+2]);
                K[d[J+2]]=m[l[J+1]][l[J+3]];
                K[d[J+4]]=K[4];
                C,Y=z[J],f[J+2];
                b,Z=C+2,2;
                K[C]=h(K[C](W(K,C+1,b)));
                K[z[J+4]]=K[z[J+1]];
                K[5]=K[11];
                C,Y=T[J+2],z[J+3];
                b,p=C+Y-1,C+Z;
                G=K[p];
                P=G.n;
                G.n=Z+P-1;
                F(G,1,P,Z,G);
                F(K,C+1,p-1,1,G);
                j=h(K[C](W(G,1,G.n)));
                F(j,1,Y,C,K);
                K[12]=K[4];
                J=f[J+3]-4+4;
              else
                if c~=36 then
                  K[6]=B(K[7],y[J]);
                  K[7]=B(K[8],l[J]);
                  K[d[J+1]]=K[6]+K[7];
                  K[d[J+2]]=K[5]+K[6];
                  K[z[J+2]]=K[4]+K[5];
                  local v,I=K[4];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[4]=I;
                  K[5]=K[4];
                  v,I=K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[5]=I;
                  K[8]=K[T[J+2]]+L[J];
                  local i,E,Q=f[J+2],l[J+1],J+1;
                  v,I=K[f[Q]],O(E,4294967295);
                  local Q,t,R=O(v,4294967295),O(I,65535),S(I,16);
                  v,E=O(Q,65535),S(Q,16);
                  Q=O(t*v+A(O(t*E+R*v,65535),16),4294967295);
                  I=nil;
                  repeat
                    v=Q%4294967296;
                    if v~=v then
                      I=0;
                      break;
                    end
                    I=v-v%1;
                  until true;
                  K[i]=I;
                  J=z[J+1]-2+2;
                else
                  local v,I=K[10];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[10]=I;
                  K[5]=B(K[d[J+2]],y[J+2]);
                  K[d[J+1]]=B(K[d[J+3]],l[J+3]);
                  K[5]=K[5]+K[6];
                  K[z[J+1]]=y[J+1]+K[f[J+3]];
                  K[6]=B(K[T[J+1]],L[J]);
                  K[8]=B(K[z[J+3]],l[J+2]);
                  K[9]=B(K[T[J]],y[J]);
                  K[8]=K[8]+K[9];
                  K[2]=B(K[2],150326317);
                  J=z[J+2]-3+3;
                end
              end
            else
              if c<38 then
                K[12]=K[d[J+1]]+d[J+3];
                K[d[J+2]]=w(y[J],K[12]);
                local v,I=L[J+3],K[11];
                local i,E=O(v,4294967295),O(I,4294967295);
                local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                i=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                t=nil;
                repeat
                  g=i%4294967296;
                  if g~=g then
                    t=0;
                    break;
                  end
                  t=g-g%1;
                until true;
                K[10]=t;
                K[8]=K[d[J+4]]+z[J+1];
                K[z[J+2]]=O(l[J+3],K[8]);
                v,i=l[J+2],K[z[J]];
                Q,t=O(v,4294967295),O(i,4294967295);
                R,i,g,I=O(Q,65535),S(Q,16),O(t,65535),S(t,16);
                E=O(R*g+A(O(R*I+i*g,65535),16),4294967295);
                I=nil;
                repeat
                  R=E%4294967296;
                  if R~=R then
                    I=0;
                    break;
                  end
                  I=R-R%1;
                until true;
                K[8]=I;
                K[f[J+3]]=K[T[J+4]]+K[8];
                K[f[J+1]]=K[9]+K[z[J+4]];
                Q,v=K[8];
                repeat
                  g=Q%4294967296;
                  if g~=g then
                    v=0;
                    break;
                  end
                  v=g-g%1;
                until true;
                K[8]=v;
                K[9]=K[T[J+1]];
                E,R=K[9];
                repeat
                  Q=E%4294967296;
                  if Q~=Q then
                    R=0;
                    break;
                  end
                  R=Q-Q%1;
                until true;
                K[9]=R;
                K[12]=K[9]+y[J+2];
                i,Q,v=f[J+4],K[12],O(86797455,4294967295);
                I,R,g=O(Q,4294967295),O(v,65535),S(v,16);
                v,E=O(I,65535),S(I,16);
                t=O(R*v+A(O(R*E+g*v,65535),16),4294967295);
                I=nil;
                repeat
                  v=t%4294967296;
                  if v~=v then
                    I=0;
                    break;
                  end
                  I=v-v%1;
                until true;
                K[i]=I;
                J=T[J]-4+4;
              else
                if c~=39 then
                  C=4;
                  K[5]=O(L[J+2],K[d[J+2]]);
                  local v,I=y[J],K[5];
                  local i,E=O(v,4294967295),O(I,4294967295);
                  local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                  E=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                  v=nil;
                  repeat
                    t=E%4294967296;
                    if t~=t then
                      v=0;
                      break;
                    end
                    v=t-t%1;
                  until true;
                  K[5]=v;
                  K[5]=K[11]+K[5];
                  K[d[J+1]]=K[10]+K[5];
                  g,E=K[5];
                  repeat
                    I=g%4294967296;
                    if I~=I then
                      E=0;
                      break;
                    end
                    E=I-I%1;
                  until true;
                  K[5]=E;
                  K[9]=K[9]*T[J];
                  K[T[J+1]]=K[9]+K[5];
                  K[5]=K[z[J+1]]/y[J+1];
                  K[5]=1+K[5];
                  K[8]=K[T[J+2]]-1023;
                  K[8]=2^K[8];
                  K[5]=K[5]*K[z[J]];
                  K[6]=2*K[6];
                  K[6]=1-K[6];
                  K[6]=K[6]*K[5];
                  K[5]=K[36];
                  Z,Y,b=K[C],K[5],K[6];
                  K[C]=Z(Y,b);
                  J=f[J+2]-2+2;
                else
                  Y,C,p,Z,e,q,D,r=1,6,6,2,r[9],r[8],r[5],r[6];
                  K[4]=m[y[J+1]][l[J]];
                  K[d[J+3]]=m[l[J+1]][y[J]];
                  K[8]=16;
                  b,K[C]=4,h(K[C](W(K,7,8)));
                  C=4;
                  K[d[J+1]]=K[d[J+2]];
                  G=K[p];
                  P=G.n;
                  j=Z+P-1;
                  G.n=j;
                  F(G,1,P,Z,G);
                  F(K,5,5,1,G);
                  P=h(K[C](W(G,1,G.n)));
                  F(P,1,Y,C,K);
                  K[z[J]]=K[f[J+3]];
                  K[f[J+2]]=B(K[5],0);
                  K[5]=L[J+3];
                  N=K[5];
                  K[5]=N;
                  J=T[J+3]-3+3;
                end
              end
            end
          else
            if c>=43 then
              if c<44 then
                C=5;
                K[5]=f[J];
                K[6]=91;
                K[7]=1;
                k=r;
                r,D,q={[6]=k,[8]=q,[9]=e,[5]=D},K[7]+0,K[6]+0;
                e=K[C]-D;
                J=z[J];
              else
                if c==45 then
                  e+=D;
                  C=if D<=0 then e>=q else e<=q;
                  if C then
                    K[T[J]]=e;
                    J=z[J];
                  else
                  end
                else
                  K[11]=B(K[11],0);
                  K[d[J+1]]=L[J];
                  K[z[J+1]]=K[2];
                  K[12]=K[T[J+1]]~=531593179;
                  J=(if K[12]then T[J]-1 else f[J]-1)+1;
                end
              end
            else
              if c<41 then
                K[d[J+2]]=y[J]+K[7];
                K[9]=K[5]+L[J+1];
                K[8]=w(y[J+1],K[9]);
                local k,v=l[J],K[8];
                local I,i=O(k,4294967295),O(v,4294967295);
                local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                v=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                R=nil;
                repeat
                  I=v%4294967296;
                  if I~=I then
                    R=0;
                    break;
                  end
                  R=I-I%1;
                until true;
                K[7]=R;
                K[5]=K[5]+L[J];
                K[5]=O(l[J+1],K[5]);
                k,t=L[J+2],K[5];
                i,R=O(k,4294967295),O(t,4294967295);
                E,v,Q,t=O(i,65535),S(i,16),O(R,65535),S(R,16);
                R=O(E*Q+A(O(E*t+v*Q,65535),16),4294967295);
                k=nil;
                repeat
                  E=R%4294967296;
                  if E~=E then
                    k=0;
                    break;
                  end
                  k=E-E%1;
                until true;
                K[5]=k;
                K[5]=K[d[J+1]]+K[5];
                K[5]=K[6]+K[5];
                K[2]=B(K[2],421390178);
                J=f[J+2]-2+2;
              else
                if c~=42 then
                else
                  N=K[d[J+2]];
                  local c,k,v=d[J+3],l[J+2],K[4];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local k,E,Q,t=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  i=O(k*Q+A(O(k*t+E*Q,65535),16),4294967295);
                  E=nil;
                  repeat
                    k=i%4294967296;
                    if k~=k then
                      E=0;
                      break;
                    end
                    E=k-k%1;
                  until true;
                  K[c]=E;
                  K[d[J+1]]=K[f[J+2]]+K[z[J+3]];
                  K[4]=K[8]+K[z[J+2]];
                  i,E,t=T[J+3],K[4];
                  repeat
                    v=E%4294967296;
                    if v~=v then
                      t=0;
                      break;
                    end
                    t=v-v%1;
                  until true;
                  K[i]=t;
                  K[7]=K[7]*67108864;
                  K[4]=K[7]+K[4];
                  K[4]=K[T[J]]/l[J+1];
                  K[4]=f[J]+K[4];
                  J=f[J+1]-3+3;
                end
              end
            end
          end
        end
      end
      J=J+1;
    end;
  else
    J=H;
  end
  local H;
  if a==222 then
    H=a;
    while true do
      local c=d[J];
      if c>=26 then
        if c<39 then
          if c>=32 then
            if c>=35 then
              if c>=37 then
                if c==38 then
                  Z,C=T[J],f[J]+1;
                  for k=1,z[J],1 do
                    Z=O(B(Z,(A(Z,13))),536870911);
                    Z=B(Z,(S(Z,13)));
                    Z=O(B(Z,(A(Z,14))),536870911);
                    T[C]=B(T[C],(O(S(Z,0),127)));
                    f[C]=B(f[C],(O(S(Z,7),127)));
                    z[C]=B(z[C],(O(S(Z,14),127)));
                    d[C]=B(d[C],(O(S(Z,21),127)));
                    C=C+1;
                  end;
                  d[J]=26;
                else
                  K[12]=K[8]+y[J+1];
                  K[d[J+1]]=w(y[J+2],K[d[J+2]]);
                  local k,v=L[J+2],K[T[J]];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local k,E,Q,t=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  I=O(k*Q+A(O(k*t+E*Q,65535),16),4294967295);
                  v=nil;
                  repeat
                    E=I%4294967296;
                    if E~=E then
                      v=0;
                      break;
                    end
                    v=E-E%1;
                  until true;
                  K[10]=v;
                  K[8]=K[8]+y[J];
                  K[13]=K[2];
                  K[13]=B(K[z[J+1]],0);
                  K[13]=l[J+1];
                  N=K[13];
                  J=z[J]-2+2;
                end
              else
                J=if c==36 then f[J]else f[J];
              end
            else
              if c>=33 then
                if c==34 then
                  K[4]=B(K[d[J+3]],y[J+1]);
                  K[5]=B(K[5],l[J+3]);
                  K[4]=K[4]+K[5];
                  K[4]=y[J+3]+K[d[J+2]];
                  K[5]=B(K[6],L[J]);
                  K[6]=B(K[7],y[J+2]);
                  K[9]=N;
                  local k,v,I=d[J+1],K[9];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[2]=B(K[f[J]],K[9]);
                  K[T[J+1]]=B(K[8],L[J+3]);
                  J=z[J+2]-3+3;
                else
                  K[10]=L[J+1];
                  N=K[d[J+1]];
                  K[9]=K[5]+l[J+3];
                  K[d[J+3]]=w(L[J+3],K[9]);
                  local k,v=l[J],J+2;
                  local I,i=K[d[v]],O(k,4294967295);
                  local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                  v,k=O(E,65535),S(E,16);
                  E=O(Q*v+A(O(Q*k+t*v,65535),16),4294967295);
                  t=nil;
                  repeat
                    I=E%4294967296;
                    if I~=I then
                      t=0;
                      break;
                    end
                    t=I-I%1;
                  until true;
                  K[7]=t;
                  K[T[J+1]]=K[5]+y[J+1];
                  K[f[J]]=B(l[J+2],K[5]);
                  E,t=K[5],O(415261822,4294967295);
                  i,k,Q=O(E,4294967295),O(t,65535),S(t,16);
                  I,v=O(i,65535),S(i,16);
                  E=O(k*I+A(O(k*v+Q*I,65535),16),4294967295);
                  v=nil;
                  repeat
                    Q=E%4294967296;
                    if Q~=Q then
                      v=0;
                      break;
                    end
                    v=Q-Q%1;
                  until true;
                  K[5]=v;
                  K[z[J]]=K[7]+K[5];
                  K[5]=K[6]+K[5];
                  Q,i=K[5];
                  repeat
                    t=Q%4294967296;
                    if t~=t then
                      i=0;
                      break;
                    end
                    i=t-t%1;
                  until true;
                  K[5]=i;
                  J=z[J+2]-3+3;
                end
              else
                local k,v,I=d[J+3],l[J+3],J+1;
                local i,E=K[d[I]],O(v,4294967295);
                local Q,t,R=O(i,4294967295),O(E,65535),S(E,16);
                v,E=O(Q,65535),S(Q,16);
                Q=O(t*v+A(O(t*E+R*v,65535),16),4294967295);
                v=nil;
                repeat
                  i=Q%4294967296;
                  if i~=i then
                    v=0;
                    break;
                  end
                  v=i-i%1;
                until true;
                K[k]=v;
                K[9]=K[11]+K[d[J+2]];
                K[9]=K[10]+K[9];
                i,E,R=T[J],K[9];
                repeat
                  t=E%4294967296;
                  if t~=t then
                    R=0;
                    break;
                  end
                  R=t-t%1;
                until true;
                K[i]=R;
                v,I=K[f[J+1]];
                repeat
                  i=v%4294967296;
                  if i~=i then
                    I=0;
                    break;
                  end
                  I=i-i%1;
                until true;
                K[5]=I;
                K[12]=K[5]+L[J+3];
                Q,R=L[J+2],K[12];
                t,E=O(Q,4294967295),O(R,4294967295);
                Q,k,R,i=O(t,65535),S(t,16),O(E,65535),S(E,16);
                E=O(Q*R+A(O(Q*i+k*R,65535),16),4294967295);
                i=nil;
                repeat
                  t=E%4294967296;
                  if t~=t then
                    i=0;
                    break;
                  end
                  i=t-t%1;
                until true;
                K[11]=i;
                K[10]=398037245+K[11];
                K[13]=K[T[J+1]]+y[J+2];
                K[12]=w(y[J],K[13]);
                R,t,v=z[J+1],l[J+2],K[12];
                E,i=O(t,4294967295),O(v,4294967295);
                v,t,I,Q=O(E,65535),S(E,16),O(i,65535),S(i,16);
                i=O(v*I+A(O(v*Q+t*I,65535),16),4294967295);
                E=nil;
                repeat
                  k=i%4294967296;
                  if k~=k then
                    E=0;
                    break;
                  end
                  E=k-k%1;
                until true;
                K[R]=E;
                J=z[J]-3+3;
              end
            end
          else
            if c<29 then
              if c>=27 then
                if c~=28 then
                  K[d[J+3]]=K[d[J+2]]+l[J+1];
                  local k,v=l[J+2],K[12];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  k=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  R=nil;
                  repeat
                    Q=k%4294967296;
                    if Q~=Q then
                      R=0;
                      break;
                    end
                    R=Q-Q%1;
                  until true;
                  K[11]=R;
                  K[d[J+1]]=L[J+1]+K[11];
                  K[13]=K[9]+y[J+2];
                  K[f[J+3]]=N;
                  v,k=K[T[J+3]];
                  repeat
                    t=v%4294967296;
                    if t~=t then
                      k=0;
                      break;
                    end
                    k=t-t%1;
                  until true;
                  K[14]=k;
                  K[2]=B(K[2],K[14]);
                  K[12]=w(L[J],K[13]);
                  k,i=l[J],K[12];
                  E,R=O(k,4294967295),O(i,4294967295);
                  t,I,i,Q=O(E,65535),S(E,16),O(R,65535),S(R,16);
                  R=O(t*i+A(O(t*Q+I*i,65535),16),4294967295);
                  E=nil;
                  repeat
                    t=R%4294967296;
                    if t~=t then
                      E=0;
                      break;
                    end
                    E=t-t%1;
                  until true;
                  K[11]=E;
                  K[f[J+1]]=K[9]+y[J];
                  K[9]=O(L[J+2],K[9]);
                  J=z[J+3]-3+3;
                else
                  local k,v=K[2];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[4]=v;
                  K[2]=B(K[4],y[J]);
                  K[4]=L[J];
                  N=K[4];
                  J=T[J];
                end
              else
              end
            else
              if c<30 then
                K[d[J+3]]=B(y[J+3],K[6]);
                local k,v=l[J],K[6];
                local I,i=O(k,4294967295),O(v,4294967295);
                local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                i=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                R=nil;
                repeat
                  t=i%4294967296;
                  if t~=t then
                    R=0;
                    break;
                  end
                  R=t-t%1;
                until true;
                K[6]=R;
                K[6]=K[8]+K[d[J+2]];
                K[6]=K[7]+K[d[J+1]];
                k,i=K[6];
                repeat
                  v=k%4294967296;
                  if v~=v then
                    i=0;
                    break;
                  end
                  i=v-v%1;
                until true;
                K[6]=i;
                K[T[J+3]]=K[4];
                I,k,v=f[J+1],K[7];
                repeat
                  t=k%4294967296;
                  if t~=t then
                    v=0;
                    break;
                  end
                  v=t-t%1;
                until true;
                K[I]=v;
                K[10]=K[7]+L[J+3];
                v,R=l[J+2],K[10];
                i,E=O(v,4294967295),O(R,4294967295);
                k,t,v,Q=O(i,65535),S(i,16),O(E,65535),S(E,16);
                R=O(k*v+A(O(k*Q+t*v,65535),16),4294967295);
                i=nil;
                repeat
                  v=R%4294967296;
                  if v~=v then
                    i=0;
                    break;
                  end
                  i=v-v%1;
                until true;
                K[9]=i;
                K[8]=L[J+2]+K[9];
                K[11]=K[T[J+1]]+y[J];
                J=f[J+2]-3+3;
              else
                if c~=31 then
                  K[10]=N;
                  local k,v=K[10];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[10]=v;
                  K[2]=B(K[d[J+2]],K[d[J+1]]);
                  v,k=K[f[J+2]];
                  repeat
                    local I=v%4294967296;
                    if I~=I then
                      k=0;
                      break;
                    end
                    k=I-I%1;
                  until true;
                  K[5]=k;
                  K[9]=K[9]*67108864;
                  K[5]=K[f[J+1]]+K[5];
                  K[5]=K[T[J+2]]/L[J+1];
                  K[5]=1+K[T[J+1]];
                  K[8]=K[8]-1023;
                  J=z[J]-2+2;
                else
                  local k,v,I=d[J+1],K[7];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[2]=B(K[2],K[7]);
                  K[7]=K[4];
                  k,v=K[7];
                  repeat
                    I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[7]=v;
                  K[10]=K[7]+l[J];
                  v,k=L[J+2],K[10];
                  local I,i=O(v,4294967295),O(k,4294967295);
                  local k,E,Q,t=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  v=O(k*Q+A(O(k*t+E*Q,65535),16),4294967295);
                  E=nil;
                  repeat
                    t=v%4294967296;
                    if t~=t then
                      E=0;
                      break;
                    end
                    E=t-t%1;
                  until true;
                  K[9]=E;
                  K[8]=l[J+2]+K[9];
                  K[d[J+2]]=K[7]+y[J+1];
                  K[T[J+1]]=w(L[J],K[11]);
                  J=f[J+2]-2+2;
                end
              end
            end
          end
        else
          if c<46 then
            if c>=42 then
              if c<44 then
                if c==43 then
                  K[12]=w(L[J+4],K[13]);
                  local k,v=L[J+3],K[12];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  i=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  E=nil;
                  repeat
                    t=i%4294967296;
                    if t~=t then
                      E=0;
                      break;
                    end
                    E=t-t%1;
                  until true;
                  K[11]=E;
                  K[9]=K[d[J+3]]+l[J+2];
                  K[9]=O(l[J+1],K[9]);
                  E,Q,R=d[J+4],L[J+2],J+2;
                  t,k=K[d[R]],O(Q,4294967295);
                  i,R,v=O(t,4294967295),O(k,65535),S(k,16);
                  t,I=O(i,65535),S(i,16);
                  i=O(R*t+A(O(R*I+v*t,65535),16),4294967295);
                  R=nil;
                  repeat
                    v=i%4294967296;
                    if v~=v then
                      R=0;
                      break;
                    end
                    R=v-v%1;
                  until true;
                  K[E]=R;
                  K[d[J+1]]=K[11]+K[z[J+1]];
                  K[9]=K[10]+K[9];
                  t,E,v=f[J+4],K[9];
                  repeat
                    R=E%4294967296;
                    if R~=R then
                      v=0;
                      break;
                    end
                    v=R-R%1;
                  until true;
                  K[t]=v;
                  K[10]=K[f[J+1]];
                  K[f[J+3]]=B(K[T[J+4]],0);
                  K[10]=l[J+3];
                  N=K[10];
                  E,I=K[5];
                  repeat
                    t=E%4294967296;
                    if t~=t then
                      I=0;
                      break;
                    end
                    I=t-t%1;
                  until true;
                  K[5]=I;
                  K[12]=K[f[J+2]]+y[J];
                  J=T[J]-4+4;
                else
                  K[6]=K[d[J+2]]+K[7];
                  K[d[J+4]]=K[d[J+3]]+K[6];
                  K[d[J+5]]=K[4]+K[d[J+1]];
                  local k,v,I=T[J+1],K[z[J]];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[5]=K[z[J+1]];
                  I,v,k=z[J+3],K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      k=0;
                      break;
                    end
                    k=i-i%1;
                  until true;
                  K[I]=k;
                  K[8]=K[5]+y[J+2];
                  I,v,k=f[J+3],L[J+5],K[8];
                  local i,E=O(v,4294967295),O(k,4294967295);
                  local Q,t,R,g=O(i,65535),S(i,16),O(E,65535),S(E,16);
                  v=O(Q*R+A(O(Q*g+t*R,65535),16),4294967295);
                  R=nil;
                  repeat
                    i=v%4294967296;
                    if i~=i then
                      R=0;
                      break;
                    end
                    R=i-i%1;
                  until true;
                  K[I]=R;
                  K[6]=y[J+4]+K[7];
                  K[z[J+2]]=K[5]+y[J+1];
                  K[T[J+3]]=w(l[J+4],K[9]);
                  t,E=l[J],K[8];
                  g,I=O(t,4294967295),O(E,4294967295);
                  i,R,t,Q=O(g,65535),S(g,16),O(I,65535),S(I,16);
                  g=O(i*t+A(O(i*Q+R*t,65535),16),4294967295);
                  Q=nil;
                  repeat
                    k=g%4294967296;
                    if k~=k then
                      Q=0;
                      break;
                    end
                    Q=k-k%1;
                  until true;
                  K[7]=Q;
                  K[5]=K[5]+y[J];
                  K[z[J+4]]=O(l[J+5],K[5]);
                  J=J+5;
                end
              else
                if c~=45 then
                  K[10]=w(y[J],K[11]);
                  local k,v=d[J+1],J+4;
                  local I,i=K[d[v]],O(k,4294967295);
                  local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                  I,k=O(E,65535),S(E,16);
                  v=O(Q*I+A(O(Q*k+t*I,65535),16),4294967295);
                  t=nil;
                  repeat
                    Q=v%4294967296;
                    if Q~=Q then
                      t=0;
                      break;
                    end
                    t=Q-Q%1;
                  until true;
                  K[9]=t;
                  K[7]=K[d[J+2]]+L[J+3];
                  K[d[J+3]]=B(y[J+1],K[7]);
                  t,E=L[J+2],K[7];
                  I,i=O(t,4294967295),O(E,4294967295);
                  E,Q,t,v=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  k=O(E*t+A(O(E*v+Q*t,65535),16),4294967295);
                  i=nil;
                  repeat
                    v=k%4294967296;
                    if v~=v then
                      i=0;
                      break;
                    end
                    i=v-v%1;
                  until true;
                  K[7]=i;
                  K[z[J]]=K[9]+K[7];
                  K[7]=K[f[J+4]]+K[7];
                  E,k=K[7];
                  repeat
                    Q=E%4294967296;
                    if Q~=Q then
                      k=0;
                      break;
                    end
                    k=Q-Q%1;
                  until true;
                  K[7]=k;
                  v,i=K[4];
                  repeat
                    I=v%4294967296;
                    if I~=I then
                      i=0;
                      break;
                    end
                    i=I-I%1;
                  until true;
                  K[4]=i;
                  K[10]=K[z[J+1]]+l[J+1];
                  k,i,E=T[J+2],l[J+3],J+4;
                  v,I=K[T[E]],O(i,4294967295);
                  Q,t,E=O(v,4294967295),O(I,65535),S(I,16);
                  v,i=O(Q,65535),S(Q,16);
                  I=O(t*v+A(O(t*i+E*v,65535),16),4294967295);
                  Q=nil;
                  repeat
                    t=I%4294967296;
                    if t~=t then
                      Q=0;
                      break;
                    end
                    Q=t-t%1;
                  until true;
                  K[k]=Q;
                  K[8]=y[J+3]+K[9];
                  J=f[J+2]-4+4;
                else
                  local k,v=L[J+1],K[12];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  I=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  i=nil;
                  repeat
                    t=I%4294967296;
                    if t~=t then
                      i=0;
                      break;
                    end
                    i=t-t%1;
                  until true;
                  K[11]=i;
                  K[10]=y[J+1]+K[11];
                  K[13]=K[5]+L[J];
                  K[d[J+3]]=w(y[J+2],K[13]);
                  E,R=l[J],J+2;
                  i,t=K[d[R]],O(E,4294967295);
                  Q,v,E=O(i,4294967295),O(t,65535),S(t,16);
                  t,i=O(Q,65535),S(Q,16);
                  I=O(v*t+A(O(v*i+E*t,65535),16),4294967295);
                  v=nil;
                  repeat
                    t=I%4294967296;
                    if t~=t then
                      v=0;
                      break;
                    end
                    v=t-t%1;
                  until true;
                  K[11]=v;
                  K[d[J+1]]=K[5]+l[J+1];
                  K[f[J+3]]=B(L[J+2],K[5]);
                  i,E,v=z[J+3],l[J+2],K[5];
                  R,Q=O(E,4294967295),O(v,4294967295);
                  E,k,t,v=O(R,65535),S(R,16),O(Q,65535),S(Q,16);
                  R=O(E*t+A(O(E*v+k*t,65535),16),4294967295);
                  E=nil;
                  repeat
                    I=R%4294967296;
                    if I~=I then
                      E=0;
                      break;
                    end
                    E=I-I%1;
                  until true;
                  K[i]=E;
                  K[5]=K[11]+K[5];
                  K[5]=K[10]+K[T[J+3]];
                  J=f[J]-3+3;
                end
              end
            else
              if c>=40 then
                if c==41 then
                  H=f[J];
                  J=z[J]+1;
                  break;
                else
                  K[10]=w(l[J+3],K[11]);
                  local k,v=y[J+2],J+3;
                  local I,i=K[d[v]],O(k,4294967295);
                  local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                  I,k=O(E,65535),S(E,16);
                  v=O(Q*I+A(O(Q*k+t*I,65535),16),4294967295);
                  I=nil;
                  repeat
                    E=v%4294967296;
                    if E~=E then
                      I=0;
                      break;
                    end
                    I=E-E%1;
                  until true;
                  K[9]=I;
                  K[6]=K[6]+39468336;
                  K[6]=O(l[J+1],K[d[J+2]]);
                  E,t=l[J],J+1;
                  k,v=K[d[t]],O(E,4294967295);
                  Q,t,E=O(k,4294967295),O(v,65535),S(v,16);
                  I,i=O(Q,65535),S(Q,16);
                  v=O(t*I+A(O(t*i+E*I,65535),16),4294967295);
                  Q=nil;
                  repeat
                    k=v%4294967296;
                    if k~=k then
                      Q=0;
                      break;
                    end
                    Q=k-k%1;
                  until true;
                  K[6]=Q;
                  K[6]=K[f[J]]+K[6];
                  K[z[J+3]]=K[f[J+1]]+K[6];
                  k,E=K[T[J+2]];
                  repeat
                    t=k%4294967296;
                    if t~=t then
                      E=0;
                      break;
                    end
                    E=t-t%1;
                  until true;
                  K[6]=E;
                  K[8]=K[z[J+1]];
                  v,t=K[f[J+3]];
                  repeat
                    k=v%4294967296;
                    if k~=k then
                      t=0;
                      break;
                    end
                    t=k-k%1;
                  until true;
                  K[8]=t;
                  K[11]=K[8]+L[J+2];
                  J+=3;
                end
              else
                J=f[J];
              end
            end
          else
            if c<49 then
              if c>=47 then
                if c==48 then
                  K[d[J+2]]=K[4]*K[d[J+1]];
                  K[5]=2*K[5];
                  K[5]=1-K[5];
                  K[4]=K[5]*K[4];
                  K[7]=K[25]~=K[T[J]];
                  K[4]=K[f[J+2]];
                  K[4]=B(K[f[J+1]],z[J+2]);
                  K[4]=L[J];
                  N=K[f[J]];
                  J=(if K[7]then z[J+1]-2 else T[J+2]-2)+2;
                else
                  K[8]=B(K[9],y[J+3]);
                  K[9]=B(K[d[J+3]],l[J+1]);
                  K[8]=K[d[J+2]]+K[9];
                  K[6]=K[6]+K[8];
                  K[5]=K[5]+K[6];
                  local k,v,I=d[J+1],K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[6]=K[5];
                  I,k,v=T[J],K[T[J+2]];
                  repeat
                    local i=k%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[I]=v;
                  K[10]=K[6]+39468336;
                  I,v=L[J+1],K[10];
                  local i,E=O(I,4294967295),O(v,4294967295);
                  local I,Q,t,R=O(i,65535),S(i,16),O(E,65535),S(E,16);
                  k=O(I*t+A(O(I*R+Q*t,65535),16),4294967295);
                  v=nil;
                  repeat
                    R=k%4294967296;
                    if R~=R then
                      v=0;
                      break;
                    end
                    v=R-R%1;
                  until true;
                  K[9]=v;
                  K[f[J]]=L[J]+K[z[J+3]];
                  K[11]=K[6]+39468336;
                  J=T[J+3]-3+3;
                end
              else
                K[12]=K[9]+l[J];
                local k,v,I=d[J+1],y[J+1],K[12];
                local i,E=O(v,4294967295),O(I,4294967295);
                local v,Q,t,R=O(i,65535),S(i,16),O(E,65535),S(E,16);
                I=O(v*t+A(O(v*R+Q*t,65535),16),4294967295);
                Q=nil;
                repeat
                  v=I%4294967296;
                  if v~=v then
                    Q=0;
                    break;
                  end
                  Q=v-v%1;
                until true;
                K[k]=Q;
                K[10]=T[J+1]+K[z[J+1]];
                K[13]=K[9]+y[J];
                J=z[J]-1+1;
              end
            else
              if c<51 then
                if c~=50 then
                  J=z[J];
                else
                  K[4]=m[y[J+1]];
                  K[2]=B(K[2],d[J+2]);
                  K[d[J+1]]=s[14];
                  K[6]=s[21];
                  K[8]=s[112];
                  K[9]=s[d[J+3]];
                  K[10]=s[T[J+2]];
                  local k,v,I=f[J+3],K[f[J]];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  I,k=K[6];
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      k=0;
                      break;
                    end
                    k=v-v%1;
                  until true;
                  K[6]=k;
                  I,k=K[8];
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      k=0;
                      break;
                    end
                    k=v-v%1;
                  until true;
                  K[8]=k;
                  k,v=K[z[J]];
                  repeat
                    I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[9]=v;
                  I,k,v=T[J+3],K[10];
                  repeat
                    local i=k%4294967296;
                    if i~=i then
                      v=0;
                      break;
                    end
                    v=i-i%1;
                  until true;
                  K[I]=v;
                  K[5]=B(K[5],L[J+1]);
                  K[6]=B(K[6],y[J+2]);
                  J=z[J+2]-3+3;
                end
              else
                if c==52 then
                  C,Z={...},d[J+1];
                  F(C,1,3,Z,K);
                  K[4]=l[J+1];
                  N=K[4];
                  K[2]=B(y[J],l[J]);
                  K[z[J]]=s[14];
                  K[5]=s[21];
                  K[6]=s[112];
                  K[7]=s[z[J+1]];
                  J=J+1;
                else
                  C=4;
                  local k,v=K[5];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[5]=v;
                  K[d[J+3]]=K[9]*67108864;
                  K[d[J+2]]=K[9]+K[d[J+1]];
                  K[T[J+3]]=K[T[J]]/l[J+1];
                  K[f[J+2]]=1+K[5];
                  K[f[J+1]]=K[8]-z[J+2];
                  K[f[J]]=2^K[8];
                  K[z[J+1]]=K[5]*K[8];
                  K[6]=2*K[6];
                  K[6]=1-K[6];
                  K[6]=K[6]*K[5];
                  K[5]=K[z[J]];
                  Z,Y,b=K[C],K[5],K[6];
                  K[C]=Z(Y,b);
                  K[7]=not K[4];
                  J=z[J+3]-3+3;
                end
              end
            end
          end
        end
      else
        if c>=13 then
          if c>=19 then
            if c<22 then
              if c<20 then
                K[d[J+2]]=K[4];
                local k,v=K[d[J+4]];
                repeat
                  local I=k%4294967296;
                  if I~=I then
                    v=0;
                    break;
                  end
                  v=I-I%1;
                until true;
                K[6]=v;
                K[2]=B(K[2],d[J+1]);
                K[9]=K[6]+L[J];
                k,v=L[J+4],J+3;
                local I,i=K[d[v]],O(k,4294967295);
                local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                I,v=O(E,65535),S(E,16);
                E=O(Q*I+A(O(Q*v+t*I,65535),16),4294967295);
                k=nil;
                repeat
                  I=E%4294967296;
                  if I~=I then
                    k=0;
                    break;
                  end
                  k=I-I%1;
                until true;
                K[8]=k;
                K[z[J+1]]=524531838+K[8];
                K[10]=K[z[J+3]]+l[J+1];
                K[9]=w(l[J+4],K[T[J+2]]);
                v,Q=l[J+3],K[9];
                k,t=O(v,4294967295),O(Q,4294967295);
                Q,i,v,E=O(k,65535),S(k,16),O(t,65535),S(t,16);
                k=O(Q*v+A(O(Q*E+i*v,65535),16),4294967295);
                i=nil;
                repeat
                  Q=k%4294967296;
                  if Q~=Q then
                    i=0;
                    break;
                  end
                  i=Q-Q%1;
                until true;
                K[8]=i;
                K[f[J+1]]=K[f[J+3]]+y[J];
                J=f[J+2]-4+4;
              else
                if c==21 then
                  J=if K[z[J]]then f[J]else T[J];
                else
                  K[4]=m[L[J+2]];
                  K[5]=s[14];
                  K[d[J+2]]=s[d[J+1]];
                  K[8]=s[112];
                  K[9]=s[15];
                  K[10]=s[T[J+1]];
                  K[2]=B(K[2],T[J]);
                  local k,v=K[5];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[5]=v;
                  K[11]=K[2];
                  K[11]=B(K[11],T[J+2]);
                  K[11]=L[J];
                  J=f[J]-2+2;
                end
              end
            else
              if c>=24 then
                if c==25 then
                  local k,v,I=d[J+4],l[J+2],J+1;
                  local i,E=K[d[I]],O(v,4294967295);
                  local v,Q,t=O(i,4294967295),O(E,65535),S(E,16);
                  i,E=O(v,65535),S(v,16);
                  I=O(Q*i+A(O(Q*E+t*i,65535),16),4294967295);
                  i=nil;
                  repeat
                    E=I%4294967296;
                    if E~=E then
                      i=0;
                      break;
                    end
                    i=E-E%1;
                  until true;
                  K[k]=i;
                  K[d[J+3]]=K[d[J+2]]+K[4];
                  K[4]=K[8]+K[4];
                  i,I=K[4];
                  repeat
                    k=i%4294967296;
                    if k~=k then
                      I=0;
                      break;
                    end
                    I=k-k%1;
                  until true;
                  K[4]=I;
                  K[7]=K[7]*f[J];
                  K[T[J+1]]=K[7]+K[4];
                  K[4]=K[4]/L[J];
                  K[4]=f[J+1]+K[4];
                  K[6]=K[6]-1023;
                  K[6]=f[J+3]^K[6];
                  K[4]=K[4]*K[T[J+3]];
                  K[z[J+3]]=2*K[5];
                  K[5]=1-K[z[J+4]];
                  K[4]=K[f[J+4]]*K[4];
                  K[7]=K[24]~=K[T[J]];
                  J=z[J+1]-4+4;
                else
                  K[7]=y[J]+K[8];
                  K[10]=K[d[J+2]]+l[J+1];
                  K[9]=w(L[J],K[d[J+3]]);
                  local k,v=L[J+2],K[9];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  i=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  E=nil;
                  repeat
                    t=i%4294967296;
                    if t~=t then
                      E=0;
                      break;
                    end
                    E=t-t%1;
                  until true;
                  K[8]=E;
                  K[6]=K[6]+y[J+3];
                  K[6]=B(L[J+1],K[6]);
                  t,i,R=d[J+1],y[J+1],K[6];
                  v,I=O(i,4294967295),O(R,4294967295);
                  k,R,E,Q=O(v,65535),S(v,16),O(I,65535),S(I,16);
                  i=O(k*E+A(O(k*Q+R*E,65535),16),4294967295);
                  k=nil;
                  repeat
                    I=i%4294967296;
                    if I~=I then
                      k=0;
                      break;
                    end
                    k=I-I%1;
                  until true;
                  K[t]=k;
                  K[6]=K[8]+K[6];
                  K[6]=K[T[J+2]]+K[6];
                  t,i=K[6];
                  repeat
                    k=t%4294967296;
                    if k~=k then
                      i=0;
                      break;
                    end
                    i=k-k%1;
                  until true;
                  K[6]=i;
                  K[7]=N;
                  J=T[J+3]-3+3;
                end
              else
                if c==23 then
                  K[d[J+3]]=B(K[d[J+4]],y[J+4]);
                  K[7]=B(K[8],l[J+3]);
                  K[d[J+1]]=K[d[J+2]]+K[7];
                  K[z[J+3]]=K[5]+K[T[J+1]];
                  K[6]=K[2];
                  K[6]=B(K[6],0);
                  K[f[J+1]]=L[J];
                  N=K[6];
                  K[4]=K[4]+K[f[J+3]];
                  local k,v,I=z[J+4],K[4];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[5]=K[4];
                  k,v,I=z[J+1],K[5];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[T[J]]=K[5]+L[J+2];
                  I,v=K[8],O(415261821,4294967295);
                  local i,E,Q=O(I,4294967295),O(v,65535),S(v,16);
                  v,I=O(i,65535),S(i,16);
                  i=O(E*v+A(O(E*I+Q*v,65535),16),4294967295);
                  k=nil;
                  repeat
                    v=i%4294967296;
                    if v~=v then
                      k=0;
                      break;
                    end
                    k=v-v%1;
                  until true;
                  K[7]=k;
                  K[T[J+2]]=y[J]+K[f[J+2]];
                  J=T[J+4]-4+4;
                else
                  C=4;
                  K[8]=2^K[8];
                  K[d[J+1]]=K[d[J+2]]*K[8];
                  K[6]=f[J+2]*K[6];
                  K[6]=1-K[6];
                  K[6]=K[6]*K[5];
                  K[5]=K[T[J+1]];
                  Z,Y,b=K[C],K[5],K[6];
                  K[C]=Z(Y,b);
                  K[7]=not K[4];
                  local k,v,I=z[J+2],K[2];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  K[2]=B(K[4],l[J+2]);
                  K[4]=N;
                  K[4]=K[4]+173850417;
                  H=f[J];
                  J=f[J+1]+1;
                  break;
                end
              end
            end
          else
            if c<16 then
              if c>=14 then
                if c~=15 then
                  J=T[J];
                else
                  local k,v=K[6];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[6]=v;
                  K[2]=B(K[d[J+3]],325461795);
                  K[10]=K[d[J+2]]+55037738;
                  v,k=y[J+1],K[10];
                  local I,i=O(v,4294967295),O(k,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  I=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  Q=nil;
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      Q=0;
                      break;
                    end
                    Q=v-v%1;
                  until true;
                  K[9]=Q;
                  K[d[J+1]]=l[J+2]+K[9];
                  K[11]=K[6]+55037738;
                  K[10]=w(L[J],K[z[J+3]]);
                  v,E,Q=f[J],l[J+1],K[10];
                  i,k=O(E,4294967295),O(Q,4294967295);
                  Q,I,R,E=O(i,65535),S(i,16),O(k,65535),S(k,16);
                  t=O(Q*R+A(O(Q*E+I*R,65535),16),4294967295);
                  i=nil;
                  repeat
                    R=t%4294967296;
                    if R~=R then
                      i=0;
                      break;
                    end
                    i=R-R%1;
                  until true;
                  K[v]=i;
                  K[13]=N;
                  t,I,i=T[J],K[13];
                  repeat
                    E=I%4294967296;
                    if E~=E then
                      i=0;
                      break;
                    end
                    i=E-E%1;
                  until true;
                  K[t]=i;
                  K[f[J+2]]=K[13]~=438282765;
                  J=(if not K[13]then f[J+3]-3 else z[J+2]-3)+3;
                end
              else
                Z,C=(B(f[J],(O(B(N,(O(S(N,29),7))),536870911)))),T[J]+1;
                for k=1,z[J],1 do
                  Z=O(B(Z,(A(Z,13))),536870911);
                  Z=B(Z,(S(Z,13)));
                  Z=O(B(Z,(A(Z,14))),536870911);
                  T[C]=B(T[C],(O(S(Z,0),127)));
                  f[C]=B(f[C],(O(S(Z,7),127)));
                  z[C]=B(z[C],(O(S(Z,14),127)));
                  d[C]=B(d[C],(O(S(Z,21),127)));
                  C=C+1;
                end;
                d[J]=26;
              end
            else
              if c<17 then
                K[6]=K[d[J+1]]+K[6];
                local k,v=K[6];
                repeat
                  local I=k%4294967296;
                  if I~=I then
                    v=0;
                    break;
                  end
                  v=I-I%1;
                until true;
                K[6]=v;
                K[8]=K[5];
                v,k=K[8];
                repeat
                  local I=v%4294967296;
                  if I~=I then
                    k=0;
                    break;
                  end
                  k=I-I%1;
                until true;
                K[8]=k;
                K[11]=K[8]+l[J];
                local k,I,i=T[J+1],K[11],O(30288931,4294967295);
                local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                v,i=O(E,65535),S(E,16);
                E=O(Q*v+A(O(Q*i+t*v,65535),16),4294967295);
                I=nil;
                repeat
                  v=E%4294967296;
                  if v~=v then
                    I=0;
                    break;
                  end
                  I=v-v%1;
                until true;
                K[k]=I;
                K[9]=L[J]+K[10];
                K[13]=N;
                I,t=K[13];
                repeat
                  v=I%4294967296;
                  if v~=v then
                    t=0;
                    break;
                  end
                  t=v-v%1;
                until true;
                K[13]=t;
                K[13]=K[13]==319007627;
                J=z[J+1]-1+1;
              else
                if c~=18 then
                  local k,v=L[J+2],K[11];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  k=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  I=nil;
                  repeat
                    t=k%4294967296;
                    if t~=t then
                      I=0;
                      break;
                    end
                    I=t-t%1;
                  until true;
                  K[10]=I;
                  K[9]=l[J+6]+K[d[J+2]];
                  K[d[J+3]]=K[8]+L[J];
                  K[11]=w(l[J+1],K[d[J+1]]);
                  t,Q=l[J+5],J+5;
                  v,k=K[d[Q]],O(t,4294967295);
                  R,Q,E=O(v,4294967295),O(k,65535),S(k,16);
                  v,t=O(R,65535),S(R,16);
                  R=O(Q*v+A(O(Q*t+E*v,65535),16),4294967295);
                  E=nil;
                  repeat
                    I=R%4294967296;
                    if I~=I then
                      E=0;
                      break;
                    end
                    E=I-I%1;
                  until true;
                  K[10]=E;
                  K[8]=K[8]+l[J];
                  K[d[J+6]]=O(l[J+3],K[d[J+4]]);
                  t,Q,i=T[J+4],y[J+3],K[8];
                  v,R=O(Q,4294967295),O(i,4294967295);
                  Q,k,i,E=O(v,65535),S(v,16),O(R,65535),S(R,16);
                  R=O(Q*i+A(O(Q*E+k*i,65535),16),4294967295);
                  v=nil;
                  repeat
                    E=R%4294967296;
                    if E~=E then
                      v=0;
                      break;
                    end
                    v=E-E%1;
                  until true;
                  K[t]=v;
                  K[f[J]]=K[z[J+3]]+K[f[J+1]];
                  K[z[J+4]]=K[9]+K[8];
                  I,k=K[8];
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      k=0;
                      break;
                    end
                    k=v-v%1;
                  until true;
                  K[8]=k;
                  K[f[J+5]]=K[T[J+2]];
                  K[9]=B(K[f[J+4]],0);
                  K[9]=y[J+2];
                  N=K[9];
                  K[9]=K[z[J+6]];
                  i,E=K[9];
                  repeat
                    k=i%4294967296;
                    if k~=k then
                      E=0;
                      break;
                    end
                    E=k-k%1;
                  until true;
                  K[9]=E;
                  J=f[J+6]-6+6;
                else
                  K[11]=K[d[J+2]]+y[J];
                  K[12]=l[J+2];
                  N=K[12];
                  K[10]=w(L[J+3],K[11]);
                  local k,v=L[J],K[10];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  i=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  E=nil;
                  repeat
                    Q=i%4294967296;
                    if Q~=Q then
                      E=0;
                      break;
                    end
                    E=Q-Q%1;
                  until true;
                  K[9]=E;
                  K[4]=K[4]+L[J+1];
                  K[4]=O(y[J+2],K[4]);
                  i,k=l[J],K[4];
                  v,R=O(i,4294967295),O(k,4294967295);
                  E,t,k,i=O(v,65535),S(v,16),O(R,65535),S(R,16);
                  I=O(E*k+A(O(E*i+t*k,65535),16),4294967295);
                  k=nil;
                  repeat
                    R=I%4294967296;
                    if R~=R then
                      k=0;
                      break;
                    end
                    k=R-R%1;
                  until true;
                  K[4]=k;
                  K[4]=K[9]+K[4];
                  K[d[J+3]]=K[8]+K[4];
                  R,E,k=d[J+1],K[4];
                  repeat
                    t=E%4294967296;
                    if t~=t then
                      k=0;
                      break;
                    end
                    k=t-t%1;
                  until true;
                  K[R]=k;
                  K[7]=K[7]*67108864;
                  K[4]=K[7]+K[4];
                  K[4]=K[4]/y[J+1];
                  K[f[J+3]]=z[J+2]+K[4];
                  K[6]=K[6]-1023;
                  K[T[J+1]]=2^K[6];
                  J=T[J+3]-3+3;
                end
              end
            end
          end
        else
          if c>=6 then
            if c<9 then
              if c>=7 then
                if c==8 then
                  K[4]=s[d[J+1]];
                  K[d[J+2]]=s[21];
                  K[6]=s[112];
                  K[d[J+3]]=s[15];
                  K[z[J+3]]=s[T[J+2]];
                  local k,v=K[4];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[4]=v;
                  local I,i,E=T[J+1],K[5];
                  repeat
                    v=i%4294967296;
                    if v~=v then
                      E=0;
                      break;
                    end
                    E=v-v%1;
                  until true;
                  K[I]=E;
                  i,I=K[6];
                  repeat
                    k=i%4294967296;
                    if k~=k then
                      I=0;
                      break;
                    end
                    I=k-k%1;
                  until true;
                  K[6]=I;
                  v,k,E=f[J+2],K[f[J]];
                  repeat
                    i=k%4294967296;
                    if i~=i then
                      E=0;
                      break;
                    end
                    E=i-i%1;
                  until true;
                  K[v]=E;
                  i,I=K[z[J+1]];
                  repeat
                    E=i%4294967296;
                    if E~=E then
                      I=0;
                      break;
                    end
                    I=E-E%1;
                  until true;
                  K[8]=I;
                  K[4]=B(K[z[J+2]],y[J+1]);
                  K[5]=B(K[5],L[J]);
                  K[4]=K[4]+K[5];
                  K[4]=l[J+3]+K[4];
                  K[5]=B(K[6],l[J]);
                  J=f[J+3]-3+3;
                else
                  J=f[J];
                end
              else
                local k,v=L[J],J+1;
                local I,i=K[d[v]],O(k,4294967295);
                local E,Q,t=O(I,4294967295),O(i,65535),S(i,16);
                i,k=O(E,65535),S(E,16);
                E=O(Q*i+A(O(Q*k+t*i,65535),16),4294967295);
                Q=nil;
                repeat
                  I=E%4294967296;
                  if I~=I then
                    Q=0;
                    break;
                  end
                  Q=I-I%1;
                until true;
                K[9]=Q;
                K[7]=K[7]+y[J+2];
                K[7]=B(L[J+2],K[7]);
                K[11]=K[2];
                K[11]=B(K[d[J+2]],T[J+1]);
                K[11]=l[J];
                N=K[11];
                Q,I=L[J+1],K[7];
                v,t=O(Q,4294967295),O(I,4294967295);
                I,k,i,Q=O(v,65535),S(v,16),O(t,65535),S(t,16);
                E=O(I*i+A(O(I*Q+k*i,65535),16),4294967295);
                I=nil;
                repeat
                  t=E%4294967296;
                  if t~=t then
                    I=0;
                    break;
                  end
                  I=t-t%1;
                until true;
                K[7]=I;
                J=f[J]-2+2;
              end
            else
              if c<11 then
                if c==10 then
                  K[6]=K[d[J+1]]+55037738;
                  K[6]=B(L[J],K[6]);
                  local k,v=l[J],J+1;
                  local I,i=K[z[v]],O(k,4294967295);
                  local v,E,Q=O(I,4294967295),O(i,65535),S(i,16);
                  k,i=O(v,65535),S(v,16);
                  I=O(E*k+A(O(E*i+Q*k,65535),16),4294967295);
                  v=nil;
                  repeat
                    Q=I%4294967296;
                    if Q~=Q then
                      v=0;
                      break;
                    end
                    v=Q-Q%1;
                  until true;
                  K[6]=v;
                  K[6]=K[9]+K[6];
                  J=J+1;
                else
                  local k,v=L[J+1],K[5];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  k=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  v=nil;
                  repeat
                    Q=k%4294967296;
                    if Q~=Q then
                      v=0;
                      break;
                    end
                    v=Q-Q%1;
                  until true;
                  K[5]=v;
                  K[5]=K[7]+K[5];
                  K[5]=K[6]+K[5];
                  v,t,R=d[J+2],K[5];
                  repeat
                    i=t%4294967296;
                    if i~=i then
                      R=0;
                      break;
                    end
                    R=i-i%1;
                  until true;
                  K[v]=R;
                  K[6]=K[4];
                  Q,R=K[6];
                  repeat
                    v=Q%4294967296;
                    if v~=v then
                      R=0;
                      break;
                    end
                    R=v-v%1;
                  until true;
                  K[6]=R;
                  K[10]=K[2];
                  K[d[J+1]]=B(K[10],0);
                  K[z[J+2]]=y[J+2];
                  N=K[10];
                  K[9]=K[6]+l[J+2];
                  E,k=l[J+1],K[9];
                  i,v=O(E,4294967295),O(k,4294967295);
                  R,I,k,E=O(i,65535),S(i,16),O(v,65535),S(v,16);
                  v=O(R*k+A(O(R*E+I*k,65535),16),4294967295);
                  R=nil;
                  repeat
                    i=v%4294967296;
                    if i~=i then
                      R=0;
                      break;
                    end
                    R=i-i%1;
                  until true;
                  K[8]=R;
                  J=f[J]-2+2;
                end
              else
                if c~=12 then
                  K[5]=K[5]+K[d[J+3]];
                  K[5]=L[J+1]+K[5];
                  K[6]=B(K[8],L[J+3]);
                  K[8]=B(K[d[J+1]],L[J]);
                  K[d[J+2]]=B(K[f[J]],y[J+1]);
                  K[z[J+2]]=K[T[J+3]]+K[9];
                  K[6]=K[6]+K[8];
                  K[5]=K[f[J+2]]+K[6];
                  local k,v=K[T[J]];
                  repeat
                    local I=k%4294967296;
                    if I~=I then
                      v=0;
                      break;
                    end
                    v=I-I%1;
                  until true;
                  K[5]=v;
                  K[6]=K[5];
                  J=f[J+3]-3+3;
                else
                  C,Z,Y,b=z[J],T[J],B(N,O(S(N,14),262143),(O(S(N,28),15))),f[J];
                  p=Z<16384 and 7 or(Z<2097152 and 14 or 21);
                  G,P=S(Z,p),O(Z,A(1,p)-1);
                  z[J]=B(C,67,(O(S(Y,14),127)));
                  d[J]=B(G,108,(O(S(Y,21),127)));
                  f[J]=B(b,70,(O(S(Y,7),127)));
                  T[J]=B(P,37,(O(Y,127)));
                  J=J-1;
                end
              end
            end
          else
            if c>=3 then
              if c>=4 then
                if c==5 then
                  K[7]=K[d[J+4]]+K[7];
                  K[d[J+2]]=K[8]+K[7];
                  local k,v,I=d[J+3],K[7];
                  repeat
                    local i=v%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[k]=I;
                  k,I=K[4];
                  repeat
                    v=k%4294967296;
                    if v~=v then
                      I=0;
                      break;
                    end
                    I=v-v%1;
                  until true;
                  K[4]=I;
                  K[d[J+1]]=K[4]+l[J+1];
                  I,k=l[J+4],J+4;
                  local i,E=K[z[k]],O(I,4294967295);
                  k,I,v=O(i,4294967295),O(E,65535),S(E,16);
                  E,i=O(k,65535),S(k,16);
                  k=O(I*E+A(O(I*i+v*E,65535),16),4294967295);
                  I=nil;
                  repeat
                    i=k%4294967296;
                    if i~=i then
                      I=0;
                      break;
                    end
                    I=i-i%1;
                  until true;
                  K[9]=I;
                  K[8]=y[J+3]+K[9];
                  K[z[J]]=K[4]+L[J+2];
                  K[10]=w(L[J+1],K[11]);
                  I,i=y[J+1],J+4;
                  E,v=K[f[i]],O(I,4294967295);
                  I,i,k=O(E,4294967295),O(v,65535),S(v,16);
                  E,v=O(I,65535),S(I,16);
                  I=O(i*E+A(O(i*v+k*E,65535),16),4294967295);
                  k=nil;
                  repeat
                    v=I%4294967296;
                    if v~=v then
                      k=0;
                      break;
                    end
                    k=v-v%1;
                  until true;
                  K[9]=k;
                  K[4]=K[4]+y[J];
                  K[4]=O(L[J+3],K[4]);
                  J=T[J+2]-4+4;
                else
                  K[8]=O(l[J+2],K[d[J+1]]);
                  local w,k,v=d[J+2],L[J+2],K[8];
                  local I,i=O(k,4294967295),O(v,4294967295);
                  local E,Q,t,R=O(I,65535),S(I,16),O(i,65535),S(i,16);
                  I=O(E*t+A(O(E*R+Q*t,65535),16),4294967295);
                  t=nil;
                  repeat
                    R=I%4294967296;
                    if R~=R then
                      t=0;
                      break;
                    end
                    t=R-R%1;
                  until true;
                  K[w]=t;
                  K[8]=K[10]+K[8];
                  K[f[J+1]]=K[9]+K[8];
                  k,t=K[8];
                  repeat
                    Q=k%4294967296;
                    if Q~=Q then
                      t=0;
                      break;
                    end
                    t=Q-Q%1;
                  until true;
                  K[8]=t;
                  K[9]=K[5];
                  v,I=K[9];
                  repeat
                    R=v%4294967296;
                    if R~=R then
                      I=0;
                      break;
                    end
                    I=R-R%1;
                  until true;
                  K[9]=I;
                  K[11]=K[2];
                  K[f[J]]=K[11]~=338352920;
                  J=(if K[11]then z[J]-2 else f[J+2]-2)+2;
                end
              else
                N=K[11];
                local w,k,v=d[J+2],K[d[J+1]];
                repeat
                  local I=k%4294967296;
                  if I~=I then
                    v=0;
                    break;
                  end
                  v=I-I%1;
                until true;
                K[w]=v;
                v,k=K[8];
                repeat
                  w=v%4294967296;
                  if w~=w then
                    k=0;
                    break;
                  end
                  k=w-w%1;
                until true;
                K[8]=k;
                v,w=K[9];
                repeat
                  k=v%4294967296;
                  if k~=k then
                    w=0;
                    break;
                  end
                  w=k-k%1;
                until true;
                K[9]=w;
                v,k=K[10];
                repeat
                  w=v%4294967296;
                  if w~=w then
                    k=0;
                    break;
                  end
                  k=w-w%1;
                until true;
                K[10]=k;
                K[5]=B(K[T[J+1]],L[J+1]);
                K[6]=B(K[6],l[J]);
                K[5]=K[5]+K[6];
                K[5]=y[J]+K[5];
                K[6]=B(K[8],L[J]);
                J=f[J+1]-2+2;
              end
            else
              if c<1 then
                K[8]=s[34];
                local s,w,k=d[J+1],K[f[J]];
                repeat
                  local v=w%4294967296;
                  if v~=v then
                    k=0;
                    break;
                  end
                  k=v-v%1;
                until true;
                K[s]=k;
                s,w=K[5];
                repeat
                  k=s%4294967296;
                  if k~=k then
                    w=0;
                    break;
                  end
                  w=k-k%1;
                until true;
                K[5]=w;
                w,k=K[z[J+1]];
                repeat
                  s=w%4294967296;
                  if s~=s then
                    k=0;
                    break;
                  end
                  k=s-s%1;
                until true;
                K[6]=k;
                w,k=K[7];
                repeat
                  s=w%4294967296;
                  if s~=s then
                    k=0;
                    break;
                  end
                  k=s-s%1;
                until true;
                K[7]=k;
                k,s=K[8];
                repeat
                  w=k%4294967296;
                  if w~=w then
                    s=0;
                    break;
                  end
                  s=w-w%1;
                until true;
                K[8]=s;
                K[10]=K[2];
                K[10]=B(K[10],0);
                K[T[J+1]]=l[J];
                N=K[f[J+1]];
                J=z[J]-1+1;
              else
                if c==2 then
                  K[4]=m[l[J+1]];
                  K[d[J+1]]=K[z[J+1]](K[24]);
                  K[7]=K[4]~=y[J];
                  J=f[J+1]-1+1;
                else
                  K[5]=K[d[J+2]]+l[J];
                  K[5]=O(L[J+2],K[5]);
                  local s,c,w=d[J+1],L[J+1],K[5];
                  local k,v=O(c,4294967295),O(w,4294967295);
                  local I,i,E,Q=O(k,65535),S(k,16),O(v,65535),S(v,16);
                  c=O(I*E+A(O(I*Q+i*E,65535),16),4294967295);
                  w=nil;
                  repeat
                    Q=c%4294967296;
                    if Q~=Q then
                      w=0;
                      break;
                    end
                    w=Q-Q%1;
                  until true;
                  K[s]=w;
                  E,I=K[2];
                  repeat
                    c=E%4294967296;
                    if c~=c then
                      I=0;
                      break;
                    end
                    I=c-c%1;
                  until true;
                  K[12]=I;
                  K[z[J]]=B(K[12],0);
                  K[f[J+2]]=l[J+2];
                  N=K[12];
                  K[5]=K[11]+K[f[J]];
                  K[5]=K[10]+K[5];
                  J=J+2;
                end
              end
            end
          end
        end
      end
      J=J+1;
    end;
  else
    H=a;
  end
  if H==234 then
    while true do
      local s,H=d[J];
      if s>=14 then
        if s<21 then
          if s>=17 then
            if s>=19 then
              if s==20 then
                C=4;
                K[4]=o[z[J+1]];
                K[d[J+1]]=#K[4];
                K[4]=1;
                K[6]=1;
                K[f[J+1]]=305419896;
                H=r;
                r,D,q={[6]=H,[8]=q,[9]=e,[5]=D},K[6]+0,K[5]+0;
                e=K[C]-D;
                J=T[J]-1+1;
              else
                J=if K[f[J]]then z[J]else T[J];
              end
            else
              if s~=18 then
                K[31]=K[23];
                Z=K[d[J+1]];
                K[31]=Z;
                K[30]=Z[y[J+1]];
                K[30]=K[30](K[31],K[32]);
                K[35]=o[z[J+2]];
                Z=K[35];
                K[35]=Z;
                K[34]=Z[L[J+3]];
                C=34;
                K[d[J+2]]=K[32]-1;
                K[4]=K[4]%K[24];
                K[36]=K[d[J+3]]+1;
                Z,Y,b=K[C],K[35],K[36];
                K[C]=Z(Y,b);
                K[z[J+1]]=K[30]+K[34];
                K[f[J]]=K[f[J+2]]%256;
                K[5]=m[l[J+2]][l[J]];
                K[27]=m[y[J+3]][l[J+3]];
                J=T[J+1]-3+3;
              else
                C=27;
                K[29]=7;
                Z=K[C];
                Y,K[C]=1,Z(K[28],K[29]);
                C=27;
                K[4]=K[27];
                K[d[J+1]]=m[l[J+1]][L[J+1]];
                K[29]=l[J];
                b,K[C]=28,h(K[C](W(K,28,29)));
                C=28;
                K[28]=K[5];
                K[d[J+2]]=K[f[J+2]];
                K[f[J]]=K[27];
                Z=T[J+2];
                p=C+Z;
                G=K[p];
                P=G.n;
                j=Z+P-1;
                G.n=j;
                F(G,1,P,Z,G);
                F(K,29,p-1,1,G);
                p=h(K[C](W(G,1,G.n)));
                F(p,1,Y,C,K);
                K[6]=K[28]%256;
                K[z[J]]=K[2];
                K[7]=B(K[4],L[J+2]);
                K[4]=o[f[J+1]];
                J=J+2;
              end
            end
          else
            if s>=15 then
              if s==16 then
                local a,c,w=T[J],B(z[J],(O(B(N,(O(S(N,29),7))),536870911))),n[6];
                local k=B(w[a],187638924);
                w[a]=k;
                a,w=n[5],k+1;
                k=V(a,w);
                local n,v;
                if k<128 then
                  n,v=k,w+1;
                else
                  local I=V(a,w+1);
                  if I<128 then
                    n,v=(k-128)*128+I,w+2;
                  else
                    local i=V(a,w+2);
                    if i<128 then
                      n,v=(k-128)*16384+(I-128)+i*128,w+3;
                    else
                      local E=V(a,w+3);
                      n,v=k-128+(I-128)*2097152+(i-128)*128+E%128*16384+(E-E%128)*2097152,w+4;
                    end
                  end
                end
                w,k=c*16843009,v+n;
                local I=k-n%4;
                for n=v,I-1,4 do
                  _(a,n,(B(X(a,n),w)));
                end;
                for n=I,k-1,1 do
                  x(a,n,(B(V(a,n),c)));
                end;
                T[J]=166;
                z[J]=15;
                f[J]=172;
                d[J]=11;
              else
                H=r;
                r,C={[6]=H,[8]=q,[9]=e,[5]=D},f[J];
                D,q=K[C+2]+0,K[C+1]+0;
                e=K[C]-D;
                J=T[J];
              end
            else
              K[f[J]]=m[L[J]][l[J]];
              return K[4](K[9]);
            end
          end
        else
          if s>=24 then
            if s<26 then
              if s==25 then
                K[4]=y[J];
                N=K[T[J]];
                J=z[J];
              else
                e,q,D,r=r[9],r[8],r[5],r[6];
                K[d[J+1]]=o[T[J+1]];
                K[24]=#K[d[J+2]];
                K[21]={};
                K[4]=K[T[J+2]];
                K[4]=B(K[4],z[J+2]);
                K[4]=L[J];
                N=K[z[J+1]];
                K[5]=y[J+2];
                K[6]=y[J+1];
                J=J+2;
              end
            else
              if s==27 then
                e,q,D=r[9],r[8],r[5];
                r=r[6];
              else
                K[f[J]]=o[z[J]];
              end
            end
          else
            if s>=22 then
              if s==23 then
                K[d[J+1]]=m[L[J+1]];
                K[T[J]]=K[4](K[25]);
                K[7]=K[f[J]]~=l[J+1];
                J=z[J]-1+1;
              else
                K[z[J]]=T[J];
                K[f[J]]=252;
                K[6]=1;
              end
            else
              K[d[J+1]]=N;
              local n,a,c=z[J+1],K[4];
              repeat
                local w=a%4294967296;
                if w~=w then
                  c=0;
                  break;
                end
                c=w-w%1;
              until true;
              K[n]=c;
              K[2]=B(K[z[J]],K[4]);
              K[4]=o[T[J]];
              K[4](y[J+1]);
              J=T[J+1]-1+1;
            end
          end
        end
      else
        if s<7 then
          if s<3 then
            if s>=1 then
              if s==2 then
                K[z[J]](l[J]);
                J=f[J];
              else
                e,q,D,r=r[9],r[8],r[5],r[6];
                J=f[J];
              end
            else
              Z,C=T[J],f[J]+1;
              for n=1,z[J],1 do
                Z=O(B(Z,(A(Z,13))),536870911);
                Z=B(Z,(S(Z,13)));
                Z=O(B(Z,(A(Z,14))),536870911);
                T[C]=B(T[C],(O(S(Z,0),127)));
                z[C]=B(z[C],(O(S(Z,7),127)));
                f[C]=B(f[C],(O(S(Z,14),127)));
                d[C]=B(d[C],(O(S(Z,21),127)));
                C=C+1;
              end;
              d[J]=11;
            end
          else
            if s>=5 then
              if s==6 then
                e+=D;
                C=if D<=0 then e>=q else e<=q;
                if C then
                  K[T[J]]=e;
                  J=z[J];
                else
                end
              else
                Y,Z,C=0,16,d[J+1];
                b=K[C];
                F(K,C+1,C+Z,1,b);
                K[4]=m[L[J+1]][L[J]];
                K[5]=#K[23];
                K[T[J+1]]=K[5]*2;
                K[6]=N;
                local n,a=K[6];
                repeat
                  local c=n%4294967296;
                  if c~=c then
                    a=0;
                    break;
                  end
                  a=c-c%1;
                until true;
                K[6]=a;
                K[2]=B(K[2],K[f[J+1]]);
                K[9]=K[4](K[5]);
                J=f[J]-1+1;
              end
            else
              if s==4 then
                p=30;
                K[4]=m[L[J+3]][l[J]];
                K[27]=m[y[J+1]][y[J+3]];
                K[29]=5;
                K[27]=K[27](K[28],K[29]);
                K[d[J+3]]=o[z[J]];
                C,Z=d[J+2],K[d[J+1]];
                K[C+1]=Z;
                K[C]=Z[l[J+1]];
                Z,Y=2,z[J+2];
                K[30]=h(K[30](W(K,31,32)));
                K[28]=K[4];
                K[29]=K[27];
                C,Y=28,z[J+1];
                b,G=C+Y-1,K[p];
                P=G.n;
                j=Z+P-1;
                G.n=j;
                F(G,1,P,Z,G);
                F(K,29,29,1,G);
                Z=h(K[C](W(G,1,G.n)));
                F(Z,1,Y,C,K);
                J=T[J+3]-3+3;
              else
                J=T[J];
              end
            end
          end
        else
          if s<10 then
            if s>=8 then
              if s~=9 then
                C=4;
                K[5]=K[d[J+2]];
                Z,Y,b,p=K[C],K[5],K[6],K[7];
                K[C]=Z(Y,b,p);
                K[5]=K[d[J+1]]*2;
                K[6]=K[f[J+2]]-1;
                K[7]=K[4]//f[J];
                K[T[J]]=K[7]+1;
                K[z[J+2]]=K[z[J+1]][K[7]];
                K[9][K[T[J+1]]]=K[7];
                K[4]=K[4]%16;
                K[4]=K[4]+1;
                K[4]=K[f[J+1]][K[4]];
                K[T[J+2]][K[5]]=K[4];
                J=z[J]-2+2;
              else
                K[7]=L[J];
                K[8]=l[J+4];
                K[d[J+4]]=L[J+4];
                K[10]=L[J+2];
                K[11]=l[J+1];
                K[12]=l[J];
                K[13]=L[J+3];
                K[d[J+1]]=l[J+2];
                K[15]=L[J+1];
                K[16]=y[J+2];
                K[17]=y[J+1];
                K[18]=y[J];
                K[d[J+2]]=y[J+3];
                K[20]=y[J+4];
                K[4]=K[21];
                J=T[J+3]-4+4;
              end
            else
              C=4;
              K[5]=#K[23];
              K[4]=1;
              K[6]=1;
              H=r;
              r,D,q={[6]=H,[8]=q,[9]=e,[5]=D},K[6]+0,K[5]+0;
              e=K[C]-D;
              J=T[J];
            end
          else
            if s>=12 then
              if s==13 then
                C,Z,Y,b=z[J],B(N,O(S(N,14),262143),(O(S(N,28),15))),T[J],f[J];
                p=C<16384 and 7 or(C<2097152 and 14 or 21);
                G,P=O(C,A(1,p)-1),S(C,p);
                T[J]=B(Y,111,(O(Z,127)));
                z[J]=B(G,92,(O(S(Z,7),127)));
                f[J]=B(b,27,(O(S(Z,14),127)));
                d[J]=B(P,77,(O(S(Z,21),127)));
                J=J-1;
              else
                Z,C=(B(z[J],(O(B(N,(O(S(N,29),7))),536870911)))),T[J]+1;
                for l=1,f[J],1 do
                  Z=O(B(Z,(A(Z,13))),536870911);
                  Z=B(Z,(S(Z,13)));
                  Z=O(B(Z,(A(Z,14))),536870911);
                  T[C]=B(T[C],(O(S(Z,0),127)));
                  z[C]=B(z[C],(O(S(Z,7),127)));
                  f[C]=B(f[C],(O(S(Z,14),127)));
                  d[C]=B(d[C],(O(S(Z,21),127)));
                  C=C+1;
                end;
                d[J]=11;
              end
            else
              if s~=11 then
                local s,l,L=f[J],K[4];
                repeat
                  local y=l%4294967296;
                  if y~=y then
                    L=0;
                    break;
                  end
                  L=y-y%1;
                until true;
                K[s]=L;
                K[4]=K[4]~=481503624;
                J=if not K[4]then T[J]else z[J];
              else
              end
            end
          end
        end
      end
      J=J+1;
    end;
  end
end
