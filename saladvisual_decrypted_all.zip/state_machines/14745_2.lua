-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[14745] / function #2
-- offset 154183..196257 (42074 bytes, type=state-machine)

function(...)
  local a,d,P;
  local Z,G=750581545;
  local Y,e,j=927017889;
  local C=S(l);
  local l;
  local N,q,b,D,p,r=1772298987;
  if J==236 then
    D,p,r=n,L,J;
    while true do
      local K=f[D];
      if K<46 then
        if K>=23 then
          if K<34 then
            if K<28 then
              if K<25 then
                if K==24 then
                  p+=1;
                  C[p]=m[O(H[D],(B(O(D,f[D]),127)))];
                else
                  p+=1;
                  C[p]=Z;
                end
              else
                if K<26 then
                  if C[p] then
                    D=O(H[D],114);
                  else
                    p=p-1;
                  end
                else
                  if K==27 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]>=q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=A(C[p],q);
                  end
                end
              end
            else
              if K>=31 then
                if K<32 then
                  p+=1;
                  C[p]=f;
                else
                  if K~=33 then
                    q,G,l=H[D]+1,H[D+1],H[D+2];
                    for o=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      H[q]=O(H[q],(B(F(G,0),127)));
                      f[q]=O(f[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    f[D]=39;
                    D=D+2;
                  else
                    q,G,l=p-1,p-2,C[p];
                    a,P=C[q],C[G];
                    C[p]=a;
                    C[q]=P;
                    C[G]=l;
                  end
                end
              else
                if K>=29 then
                  if K==30 then
                    Z=C[p];
                    p=p-1;
                  else
                    D,p=if C[p]then O(H[D],(B(f[D],127)))else D,p-1;
                  end
                else
                  q,G=O(H[D],(B(O(f[D],D),127))),C[p];
                  p-=1;
                  l,a=p-q,C[p];
                  P=a.n;
                  e=q-1+P;
                  a.n=e;
                  h(a,1,P,q,a);
                  h(C,l+1,p-1,1,a);
                  C[l]=W(C[l](V(a,1,a.n)));
                  p=l;
                end
              end
            end
          else
            if K>=40 then
              if K<43 then
                if K>=41 then
                  if K~=42 then
                    C[p-O(H[D],(B(O(r,D,104),127)))]=C[p];
                    p-=1;
                  else
                    p+=1;
                    C[p]=C[O(H[D],(B(O(r,f[D]),127)))];
                  end
                else
                  q=m[O(H[D],(B(O(f[D],D,r),127)))];
                  p+=1;
                  C[p]=q[4][q[6]];
                end
              else
                if K<44 then
                  D,p=if not C[p]then O(H[D],(B(O(38,f[D],r),127)))else D,p-1;
                else
                  if K~=45 then
                    q=O(H[D],(B(f[D],127)));
                    G=p-q+1;
                    h(C,G,p,L+1,C);
                    p=L+q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]==q;
                  end
                end
              end
            else
              if K<37 then
                if K<35 then
                  if not C[p] then
                    D=O(H[D],(B(O(f[D],119),127)));
                  else
                    p=p-1;
                  end
                else
                  if K~=36 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]>q;
                  else
                    Y=C[p];
                    p=p-1;
                  end
                end
              else
                if K>=38 then
                  if K==39 then
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]%q;
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=w(C[p],q);
                end
              end
            end
          end
        else
          if K>=11 then
            if K<17 then
              if K<14 then
                if K>=12 then
                  if K==13 then
                    if C[p] then
                      p-=1;
                      D=O(H[D],(B(O(f[D],r),127)));
                    else
                    end
                  else
                    q,G=m[O(H[D],(B(O(f[D],115,D),127)))],C[p];
                    p-=1;
                    q[4][q[6]]=G;
                  end
                else
                  q,p=C[p],L+1;
                  C[L+1]=q;
                end
              else
                if K<15 then
                  q=C[p];
                  p+=1;
                  C[p]=q;
                else
                  if K~=16 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]-q;
                  else
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                  end
                end
              end
            else
              if K<20 then
                if K>=18 then
                  if K==19 then
                    C[p]=_(C[p]);
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]..q;
                  end
                else
                  q,G,l=p-1,p-2,C[p];
                  a,P=C[q],C[G];
                  C[p]=P;
                  C[q]=l;
                  C[G]=a;
                end
              else
                if K>=21 then
                  if K~=22 then
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p=p-1;
                  else
                    p+=1;
                    C[p]=O(H[D],(B(f[D],127)));
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]<q;
                end
              end
            end
          else
            if K>=5 then
              if K<8 then
                if K<6 then
                  N=C[p];
                  p=p-1;
                else
                  if K~=7 then
                    D=if not C[p]then O(H[D],(B(O(27,f[D],r),127)))else D;
                  else
                    C[p]=not C[p];
                  end
                end
              else
                if K>=9 then
                  if K==10 then
                    local o,c=C[p];
                    repeat
                      local t=o%4294967296;
                      if t~=t then
                        c=0;
                        break;
                      end
                      c=t-t%1;
                    until true;
                    C[p]=c;
                  else
                    p+=1;
                    C[p]=y;
                  end
                else
                  p+=1;
                  C[p]=N;
                end
              end
            else
              if K>=2 then
                if K<3 then
                  p+=1;
                  C[p]=z[D];
                else
                  if K==4 then
                    q,G=H[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                    l=q<16384 and 7 or(q<2097152 and 14 or 21);
                    a,P=F(q,l),B(q,w(1,l)-1);
                    f[D]=O(a,95,(B(F(G,7),127)));
                    H[D]=O(P,81,(B(G,127)));
                    D=D-1;
                  else
                    q,G=O(H[D],(B(O(75,f[D]),127))),C[p];
                    p-=1;
                    l=p-q;
                    C[l]=W(C[l](V(C,l+1,p)));
                    p=l;
                  end
                end
              else
                if K==1 then
                  q,G=O(H[D],(B(O(83,r),127))),C[p];
                  p-=1;
                  l,a=p-q,C[p];
                  P=a.n;
                  e=q-1+P;
                  a.n=e;
                  h(a,1,P,q,a);
                  h(C,l+1,p-1,1,a);
                  j,p=W(C[l](V(a,1,a.n))),l+G-1;
                  h(j,1,G,l,C);
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]^q;
                end
              end
            end
          end
        end
      else
        if K<69 then
          if K<57 then
            if K<51 then
              if K<48 then
                local o=D;
                if K==47 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]/q;
                else
                  r=C[p];
                  p-=1;
                  D=O(H[o],92)+1;
                  break;
                end
              else
                if K<49 then
                  q,G,l=H[D]+1,O(H[D+1],(B(O(Z,(B(F(Z,29),7))),536870911))),H[D+2];
                  for o=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    H[q]=O(H[q],(B(F(G,0),127)));
                    f[q]=O(f[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  f[D]=39;
                  D=D+2;
                else
                  if K==50 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]~=q;
                  else
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                  end
                end
              end
            else
              if K>=54 then
                if K>=55 then
                  if K~=56 then
                    if d then
                      for o in X,d,nil do
                        if d then
                          local c=d[o];
                          if c then
                            c[4]=c;
                            c[5]=C[o];
                            c[6]=5;
                            d[o]=nil;
                          end
                        end
                      end;
                    end
                    if b then
                      for o,c in X,b,nil do
                        local t=c[5];
                        if b then
                          c=b[o];
                          if c then
                            local R=S(t);
                            h(C,o,o+t-1,1,R);
                            c[4]=R;
                            c[6]=1;
                            b[o]=nil;
                          end
                        end
                      end;
                    end
                    q=O(H[D],(B(O(f[D],D),127)));
                    if q==0 then
                      return;
                    end
                    return V(C,p-q+1,p);
                  else
                    q=C[p];
                    p-=1;
                    C[p]=B(C[p],q);
                  end
                else
                  q,G,l=H[D]+1,O(H[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),H[D+2];
                  for o=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    H[q]=O(H[q],(B(F(G,0),127)));
                    f[q]=O(f[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  f[D]=39;
                  D=D+2;
                end
              else
                if K<52 then
                  p+=1;
                  C[p]=Y;
                else
                  if K==53 then
                    p+=1;
                    C[p]=x[z[D]];
                  else
                    p+=1;
                    C[p]=H[D];
                  end
                end
              end
            end
          else
            if K<63 then
              if K<60 then
                if K>=58 then
                  if K~=59 then
                    q=O(H[D],14);
                    G={n=q};
                    h(C,p-q+1,p,1,G);
                    p=p-q+1;
                    C[p]=G;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=O(C[p],q);
                  end
                else
                  p=p-O(H[D],(B(O(D,f[D]),127)));
                end
              else
                if K<61 then
                  q,G,l=C[p],C[p-1],C[p-2];
                  p-=2;
                  l[G]=q;
                else
                  if K~=62 then
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p=p-1;
                  else
                    local o;
                    local c=z[D];
                    if c then
                      local t=#c/3;
                      if t>0 then
                        o={};
                        local R,g=d,b;
                        for u=1,t,1 do
                          local t=(u-1)*3;
                          local U,M=c[t+3],c[t+2];
                          if U==2 then
                            R=if not R then{}else R;
                            local sP=R[M];
                            if not sP then
                              sP={[4]=C,[6]=M};
                              R[M]=sP;
                            else
                            end
                            o[u]=sP;
                          else
                            if U==1 then
                              o[u]=C[M];
                            else
                              if U==3 then
                                o[u]=m[M];
                              else
                                if U==0 then
                                  g=if not g then{}else g;
                                  local U=g[M];
                                  if not U then
                                    U={[5]=c[t+1],[6]=M,[4]=C};
                                    g[M]=U;
                                  else
                                  end
                                  o[u]=U;
                                else
                                end
                              end
                            end
                          end
                        end;
                        d,b=R,g;
                      else
                      end
                    else
                    end
                    C[p]=C[p](nil,o);
                    q=o;
                  end
                end
              end
            else
              if K<66 then
                if K<64 then
                  q,G,l=H[D]+1,O(H[D+1],(B(O(N,(B(F(N,29),7))),536870911))),H[D+2];
                  for o=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    H[q]=O(H[q],(B(F(G,0),127)));
                    f[q]=O(f[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  f[D]=39;
                  D=D+2;
                else
                  if K==65 then
                    q,G=C[p],C[p-1];
                    C[p-1]=G[q];
                    C[p]=G;
                  else
                    D=O(H[D],(B(O(r,f[D]),127)));
                  end
                end
              else
                if K<67 then
                  D=if C[p]then O(H[D],(B(O(81,f[D]),127)))else D;
                else
                  if K==68 then
                    q=p-1;
                    G=C[q];
                    C[q]=C[p];
                    C[p]=G;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<=q;
                  end
                end
              end
            end
          end
        else
          if K<81 then
            if K<75 then
              if K>=72 then
                if K>=73 then
                  if K~=74 then
                    p+=1;
                    C[p]=C[H[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[H[D]];
                  else
                    C[p]=#C[p];
                  end
                else
                  p+=1;
                  C[p]=s[O(H[D],(B(O(r,f[D]),127)))];
                end
              else
                if K>=70 then
                  if K==71 then
                    C[O(H[D],46)]=C[p];
                    p=p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]+q;
                  end
                else
                  q=C[p];
                  p-=1;
                  local o,c=B(C[p],4294967295),B(q,4294967295);
                  local t,R,g,u=B(o,65535),F(o,16),B(c,65535),F(c,16);
                  o=B(t*g+w(B(t*u+R*g,65535),16),4294967295);
                  u=nil;
                  repeat
                    g=o%4294967296;
                    if g~=g then
                      u=0;
                      break;
                    end
                    u=g-g%1;
                  until true;
                  C[p]=u;
                end
              end
            else
              if K>=78 then
                if K>=79 then
                  if K~=80 then
                    q,G=H[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                    l=q<2097152 and 7 or 14;
                    a,P=F(q,l),B(q,w(1,l)-1);
                    H[D]=O(P,73,(B(G,127)));
                    f[D]=O(a,42,(B(F(G,7),127)));
                    D=D-1;
                  else
                    q,G=O(H[D],(B(O(f[D],r,4),127))),C[p];
                    p-=1;
                    l=p-q;
                    a,p=W(C[l](V(C,l+1,p))),l+G-1;
                    h(a,1,G,l,C);
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=F(C[p],q);
                end
              else
                if K<76 then
                  q=C[p];
                  D,p=q,p-1;
                else
                  if K~=77 then
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[H[D]]=C[p];
                    p=p-1;
                  else
                    p+=1;
                    C[p]=nil;
                  end
                end
              end
            end
          else
            if K>=87 then
              if K>=90 then
                if K<91 then
                  q={...};
                  h(q,1,O(H[D],(B(O(D,r),127))),1,C);
                else
                  if K==92 then
                    q=C[p-O(H[D],(B(O(f[D],56),127)))];
                    p+=1;
                    C[p]=q;
                  else
                    q,G=O(H[D],(B(O(84,f[D]),127))),C[p];
                    p-=1;
                    l=C[p-G];
                    h(C,p-G+1,p,q+1,l);
                    p=p-G;
                  end
                end
              else
                if K>=88 then
                  if K==89 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p][q];
                  else
                    q=H[D];
                    local o,c,t=F(q,8),B(q,255),y[6];
                    local R=O(t[o],187638924);
                    t[o]=R;
                    o,t=y[5],R+1;
                    R=k(o,t);
                    local g,u;
                    if R<128 then
                      g,u=R,t+1;
                    else
                      local U=k(o,t+1);
                      if U<128 then
                        g,u=(R-128)*128+U,t+2;
                      else
                        local M=k(o,t+2);
                        if M<128 then
                          g,u=(R-128)*16384+(U-128)+M*128,t+3;
                        else
                          local sP=k(o,t+3);
                          g,u=R-128+(U-128)*2097152+(M-128)*128+sP%128*16384+(sP-sP%128)*2097152,t+4;
                        end
                      end
                    end
                    t,R=c*16843009,u+g;
                    local U=R-g%4;
                    for g=u,U-1,4 do
                      v(o,g,(O(I(o,g),t)));
                    end;
                    for t=U,R-1,1 do
                      i(o,t,(O(k(o,t),c)));
                    end;
                    H[D]=253;
                    f[D]=39;
                  end
                else
                  p=p-1;
                end
              end
            else
              if K>=84 then
                if K<85 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]//q;
                else
                  if K==86 then
                    p+=1;
                    C[p]={};
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]*q;
                  end
                end
              else
                if K<82 then
                  q,G,l=C[p],C[p-1],C[p-2];
                  p-=3;
                  l[G]=q;
                else
                  if K==83 then
                    if not C[p] then
                      p-=1;
                      D=O(H[D],(B(r,127)));
                    else
                    end
                  else
                    p+=1;
                    C[p]=H;
                  end
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  else
    p,D,r=L,n,J;
  end
  if r==253 then
    while true do
      local n=H[D];
      if n<47 then
        if n>=23 then
          if n<35 then
            if n>=29 then
              if n>=32 then
                if n>=33 then
                  if n==34 then
                    q=C[p];
                    D,p=q,p-1;
                  else
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                  end
                else
                  r=C[p];
                  p-=1;
                  D=O(f[D],(B(H[D],127)))+1;
                  break;
                end
              else
                if n<30 then
                  q=C[p-O(f[D],96)];
                  p+=1;
                  C[p]=q;
                else
                  if n~=31 then
                    q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                    l=q<2097152 and 7 or 14;
                    a,P=F(q,l),B(q,w(1,l)-1);
                    H[D]=O(a,125,(B(F(G,7),127)));
                    f[D]=O(P,97,(B(G,127)));
                    D=D-1;
                  else
                    if not C[p] then
                      p-=1;
                      D=O(f[D],(B(O(109,H[D]),127)));
                    else
                    end
                  end
                end
              end
            else
              if n>=26 then
                if n>=27 then
                  if n~=28 then
                    D=if not C[p]then O(f[D],(B(r,127)))else D;
                  else
                    q,G=O(f[D],(B(D,127))),C[p];
                    p-=1;
                    l=p-q;
                    a,p=W(C[l](V(C,l+1,p))),l+G-1;
                    h(a,1,G,l,C);
                  end
                else
                  q,G=m[O(f[D],(B(O(D,H[D],r),127)))],C[p];
                  p-=1;
                  q[4][q[6]]=G;
                end
              else
                if n>=24 then
                  if n~=25 then
                    q=C[p];
                    p-=1;
                    C[p]=w(C[p],q);
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p][q];
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]<=q;
                end
              end
            end
          else
            if n>=41 then
              if n<44 then
                if n>=42 then
                  if n==43 then
                    p+=1;
                    C[p]=f[D];
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]~=q;
                  end
                else
                  if C[p] then
                    D=O(f[D],(B(O(r,31,H[D]),127)));
                  else
                    p=p-1;
                  end
                end
              else
                if n>=45 then
                  if n~=46 then
                    q=f[D];
                    local J,K,o=F(q,8),B(q,255),y[6];
                    local c=O(o[J],187638924);
                    o[J]=c;
                    o,J=y[5],c+1;
                    c=k(o,J);
                    local t,R;
                    if c<128 then
                      t,R=c,J+1;
                    else
                      local g=k(o,J+1);
                      if g<128 then
                        t,R=(c-128)*128+g,J+2;
                      else
                        local u=k(o,J+2);
                        if u<128 then
                          t,R=(c-128)*16384+(g-128)+u*128,J+3;
                        else
                          local U=k(o,J+3);
                          t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,J+4;
                        end
                      end
                    end
                    J,c=K*16843009,R+t;
                    local g=c-t%4;
                    for t=R,g-1,4 do
                      v(o,t,(O(I(o,t),J)));
                    end;
                    for J=g,c-1,1 do
                      i(o,J,(O(k(o,J),K)));
                    end;
                    f[D]=245;
                    H[D]=53;
                  else
                    q,G=C[p],C[p-1];
                    C[p-1]=G[q];
                    C[p]=G;
                  end
                else
                  q,G,l=f[D]+1,f[D+1],f[D+2];
                  for J=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=53;
                  D=D+2;
                end
              end
            else
              if n<38 then
                if n<36 then
                  if not C[p] then
                    D=O(f[D],(B(O(r,H[D],39),127)));
                  else
                    p=p-1;
                  end
                else
                  if n==37 then
                    D=if C[p]then O(f[D],(B(O(H[D],3),127)))else D;
                  else
                    q=p-1;
                    G=C[q];
                    C[q]=C[p];
                    C[p]=G;
                  end
                end
              else
                if n>=39 then
                  if n==40 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]>=q;
                  else
                    Z=C[p];
                    p=p-1;
                  end
                else
                  p+=1;
                  C[p]=s[O(f[D],(B(D,127)))];
                end
              end
            end
          end
        else
          if n<11 then
            if n>=5 then
              if n<8 then
                if n>=6 then
                  if n~=7 then
                    q=C[p];
                    p-=1;
                    local J,K=B(C[p],4294967295),B(q,4294967295);
                    local o,c,t,R=B(J,65535),F(J,16),B(K,65535),F(K,16);
                    J=B(o*t+w(B(o*R+c*t,65535),16),4294967295);
                    K=nil;
                    repeat
                      o=J%4294967296;
                      if o~=o then
                        K=0;
                        break;
                      end
                      K=o-o%1;
                    until true;
                    C[p]=K;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]==q;
                  end
                else
                  q,G,l,a,P=C[p],C[p-1],C[p-2],C[p-3],E(Q);
                  P(s,a,l,G);
                  l,G=nil,nil;
                  local J;
                  J,P=P,p-3;
                  C[P]=J;
                  C[P+1]=l;
                  C[P+2]=G;
                  C[P+3]=q;
                  C[P+4]=O(f[D],(B(O(r,H[D],D),127)));
                  p,a=P+4,P;
                end
              else
                if n<9 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]-q;
                else
                  if n==10 then
                    C[p]=_(C[p]);
                  else
                    q,G,l=C[p],C[p-1],C[p-2];
                    p-=3;
                    l[G]=q;
                  end
                end
              end
            else
              if n>=2 then
                if n<3 then
                  q,G,l=f[D]+1,O(f[D+1],(B(O(N,(B(F(N,29),7))),536870911))),f[D+2];
                  for J=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=53;
                  D=D+2;
                else
                  if n~=4 then
                    C[O(f[D],(B(O(H[D],r,115),127)))]=C[p];
                    p=p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=B(C[p],q);
                  end
                end
              else
                if n==1 then
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p=p-1;
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]/q;
                end
              end
            end
          else
            if n<17 then
              if n>=14 then
                if n<15 then
                  D=O(f[D],(B(O(80,H[D],r),127)));
                else
                  if n~=16 then
                    p+=1;
                    C[p]=O(f[D],(B(D,127)));
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]%q;
                  end
                end
              else
                if n<12 then
                  q,G,l,a,P=C[p-4],C[p-3],C[p-2],C[p-1],C[p];
                  local J,K=q();
                  if J then
                    C[p-2]=l;
                    if P~=0 then
                      for o=1,a,1 do
                        C[P+o-1]=K[o];
                      end;
                    else
                      h(K,1,a,p+1,C);
                      p+=a;
                    end
                    D=O(f[D],(B(O(r,H[D],82),127)));
                  else
                    p=p-5;
                  end
                  e,j=J,K;
                else
                  if n~=13 then
                    D,p=if not C[p]then O(f[D],(B(O(H[D],r),127)))else D,p-1;
                  else
                    q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                    l=q<16384 and 7 or(q<2097152 and 14 or 21);
                    a,P=B(q,w(1,l)-1),F(q,l);
                    H[D]=O(P,83,(B(F(G,7),127)));
                    f[D]=O(a,16,(B(G,127)));
                    D=D-1;
                  end
                end
              end
            else
              if n<20 then
                if n>=18 then
                  if n==19 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]>q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]*q;
                  end
                else
                  q,G=O(f[D],(B(O(D,106,H[D]),127))),C[p];
                  p-=1;
                  l=C[p-G];
                  h(C,p-G+1,p,q+1,l);
                  p=p-G;
                end
              else
                if n<21 then
                  q,G=O(f[D],(B(O(r,D),127))),C[p];
                  p-=1;
                  l,a=p-q,C[p];
                  P=a.n;
                  e=q-1+P;
                  a.n=e;
                  h(a,1,P,q,a);
                  h(C,l+1,p-1,1,a);
                  j,p=W(C[l](V(a,1,a.n))),l+G-1;
                  h(j,1,G,l,C);
                else
                  if n~=22 then
                    C[p]=#C[p];
                  else
                    q=C[p];
                    p+=1;
                    C[p]=q;
                  end
                end
              end
            end
          end
        end
      else
        if n>=70 then
          if n<82 then
            if n>=76 then
              if n<79 then
                if n>=77 then
                  if n~=78 then
                    local J,K=C[p];
                    repeat
                      local o=J%4294967296;
                      if o~=o then
                        K=0;
                        break;
                      end
                      K=o-o%1;
                    until true;
                    C[p]=K;
                  else
                    p+=1;
                    C[p]=C[O(f[D],(B(O(121,r),127)))];
                  end
                else
                  p-=O(f[D],(B(H[D],127)));
                end
              else
                if n>=80 then
                  if n~=81 then
                    q,G=O(f[D],(B(O(D,r,H[D]),127))),C[p];
                    p-=1;
                    l=p-q;
                    C[l]=W(C[l](V(C,l+1,p)));
                    p=l;
                  else
                    q,G,l=f[D]+1,O(f[D+1],(B(O(Z,(B(F(Z,29),7))),536870911))),f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=53;
                    D=D+2;
                  end
                else
                  p+=1;
                  C[p]=f;
                end
              end
            else
              if n<73 then
                if n>=71 then
                  if n~=72 then
                    p+=1;
                    C[p]=C;
                  else
                    q=p-O(f[D],12);
                    G=C[q];
                    C[q]=C[p];
                    C[p]=G;
                  end
                else
                  q=O(f[D],(B(O(Y,(B(F(Y,29),7))),536870911)));
                  local J,K,o=F(q,8),B(q,255),y[6];
                  local c=O(o[J],187638924);
                  o[J]=c;
                  o,J=y[5],c+1;
                  c=k(o,J);
                  local t,R;
                  if c<128 then
                    t,R=c,J+1;
                  else
                    local g=k(o,J+1);
                    if g<128 then
                      t,R=(c-128)*128+g,J+2;
                    else
                      local u=k(o,J+2);
                      if u<128 then
                        t,R=(c-128)*16384+(g-128)+u*128,J+3;
                      else
                        local U=k(o,J+3);
                        t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,J+4;
                      end
                    end
                  end
                  J,c=K*16843009,R+t;
                  local g=c-t%4;
                  for t=R,g-1,4 do
                    v(o,t,(O(I(o,t),J)));
                  end;
                  for J=g,c-1,1 do
                    i(o,J,(O(k(o,J),K)));
                  end;
                  f[D]=227;
                  H[D]=53;
                end
              else
                if n>=74 then
                  if n==75 then
                    p+=1;
                    C[p]=x[T[D]];
                  else
                    local J;
                    local K=T[D];
                    if K then
                      local o=#K/3;
                      if o>0 then
                        J={};
                        local c,t=d,b;
                        for R=1,o,1 do
                          local o=(R-1)*3;
                          local g,u=K[o+3],K[o+2];
                          if g==2 then
                            c=if not c then{}else c;
                            local U=c[u];
                            if not U then
                              U={[4]=C,[6]=u};
                              c[u]=U;
                            else
                            end
                            J[R]=U;
                          else
                            if g==1 then
                              J[R]=C[u];
                            else
                              if g==3 then
                                J[R]=m[u];
                              else
                                if g==0 then
                                  t=if not t then{}else t;
                                  local g=t[u];
                                  if not g then
                                    g={[5]=K[o+1],[6]=u,[4]=C};
                                    t[u]=g;
                                  else
                                  end
                                  J[R]=g;
                                else
                                end
                              end
                            end
                          end
                        end;
                        d,b=c,t;
                      else
                      end
                    else
                    end
                    C[p]=C[p](nil,J);
                    q=J;
                  end
                else
                  q,G,l=f[D]+1,O(f[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),f[D+2];
                  for J=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=53;
                  D=D+2;
                end
              end
            end
          else
            if n>=88 then
              if n>=91 then
                if n<92 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]..q;
                else
                  if n~=93 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]^q;
                  else
                    C[p-1]=C[O(f[D],(B(O(r,64),127)))+C[p]];
                    p=p-1;
                  end
                end
              else
                if n<89 then
                  C[p]=not C[p];
                else
                  if n==90 then
                    N=C[p];
                    p=p-1;
                  else
                    C[O(f[D],(B(O(r,D),127)))+C[p-1]]=C[p];
                    p=p-2;
                  end
                end
              end
            else
              if n<85 then
                if n>=83 then
                  if n==84 then
                    p+=1;
                    C[p]=T[D];
                  else
                    D,p=if C[p]then O(f[D],(B(O(r,87,H[D]),127)))else D,p-1;
                  end
                else
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p=p-1;
                end
              else
                if n<86 then
                  q,p=C[p],L+1;
                  C[L+1]=q;
                else
                  if n==87 then
                    p+=1;
                    C[p]=N;
                  else
                    p+=1;
                    C[p]=y;
                  end
                end
              end
            end
          end
        else
          if n<58 then
            if n<52 then
              if n>=49 then
                if n>=50 then
                  if n~=51 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<q;
                  else
                    q=C[p];
                    p-=1;
                    for J=O(f[D],(B(O(D,55,H[D]),127))),O(f[D],(B(O(D,55,H[D]),127)))+q-1,1 do
                      C[J]=nil;
                    end;
                  end
                else
                  C[p-O(f[D],(B(O(101,r),127)))]=C[p];
                  p=p-1;
                end
              else
                if n~=48 then
                  q=m[O(f[D],(B(r,127)))];
                  p+=1;
                  C[p]=q[4][q[6]];
                else
                  q=C[p];
                  p-=1;
                  C[p]=O(C[p],q);
                end
              end
            else
              if n<55 then
                if n>=53 then
                  if n==54 then
                    p+=1;
                    C[p]={};
                  else
                  end
                else
                  p-=1;
                end
              else
                if n<56 then
                  local J=O(f[D],(B(O(D,99),127)));
                  if d then
                    local K=d[J];
                    if K then
                      K[4]=K;
                      K[5]=C[J];
                      K[6]=5;
                      d[J]=nil;
                    end
                  end
                else
                  if n==57 then
                    q,G,l=C[p],C[p-1],C[p-2];
                    p-=2;
                    l[G]=q;
                  else
                    p+=1;
                    C[p]=Z;
                  end
                end
              end
            end
          else
            if n<64 then
              if n>=61 then
                if n<62 then
                  Y=C[p];
                  p=p-1;
                else
                  if n==63 then
                    p+=1;
                    C[p]=Y;
                  else
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                  end
                end
              else
                if n<59 then
                  if C[p] then
                    p-=1;
                    D=O(f[D],(B(H[D],127)));
                  else
                  end
                else
                  if n==60 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]//q;
                  else
                    q=O(f[D],(B(O(D,H[D],47),127)));
                    G=p-q+1;
                    h(C,G,p,L+1,C);
                    p=L+q;
                  end
                end
              end
            else
              if n>=67 then
                if n>=68 then
                  if n==69 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]+q;
                  else
                    p+=1;
                    C[p]=m[O(f[D],(B(O(54,D,H[D]),127)))];
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=A(C[p],q);
                end
              else
                if n<65 then
                  p+=1;
                  C[p]=H;
                else
                  if n~=66 then
                    p+=1;
                    C[p]=nil;
                  else
                    if d then
                      for n in X,d,nil do
                        if d then
                          local J=d[n];
                          if J then
                            J[4]=J;
                            J[5]=C[n];
                            J[6]=5;
                            d[n]=nil;
                          end
                        end
                      end;
                    end
                    if b then
                      for n,J in X,b,nil do
                        local K=J[5];
                        if b then
                          J=b[n];
                          if J then
                            local o=S(K);
                            h(C,n,n+K-1,1,o);
                            J[4]=o;
                            J[6]=1;
                            b[n]=nil;
                          end
                        end
                      end;
                    end
                    q=O(f[D],(B(H[D],127)));
                    if q==0 then
                      return;
                    end
                    return V(C,p-q+1,p);
                  end
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  else
  end
  if r==72 then
    while true do
      local n=H[D];
      if n<44 then
        if n<22 then
          if n<11 then
            if n>=5 then
              if n<8 then
                if n<6 then
                  q,G,l=C[p],C[p-1],C[p-2];
                  p-=3;
                  l[G]=q;
                else
                  if n~=7 then
                    Z=C[p];
                    p=p-1;
                  else
                    q,G=O(f[D],(B(H[D],127))),C[p];
                    p-=1;
                    l,a=p-q,C[p];
                    P=a.n;
                    e=q-1+P;
                    a.n=e;
                    h(a,1,P,q,a);
                    h(C,l+1,p-1,1,a);
                    j,p=W(C[l](V(a,1,a.n))),l+G-1;
                    h(j,1,G,l,C);
                  end
                end
              else
                if n>=9 then
                  if n==10 then
                    if not C[p] then
                      D=O(f[D],(B(O(50,H[D],r),127)));
                    else
                      p=p-1;
                    end
                  else
                    q=C[p];
                    p+=1;
                    C[p]=q;
                  end
                else
                  q=p-1;
                  G=C[q];
                  C[q]=C[p];
                  C[p]=G;
                end
              end
            else
              if n>=2 then
                if n>=3 then
                  if n==4 then
                    C[f[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[f[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[f[D]]=C[p];
                    p-=1;
                    D+=1;
                    C[f[D]]=C[p];
                    p=p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]==q;
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]~=q;
                end
              else
                local J=D;
                if n==1 then
                  p+=1;
                  C[p]=O(f[J],(B(r,127)));
                else
                  r=C[p];
                  p-=1;
                  D=O(f[J],(B(O(H[J],78),127)))+1;
                  break;
                end
              end
            end
          else
            if n<16 then
              if n>=13 then
                if n>=14 then
                  if n~=15 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]>=q;
                  else
                    q=C[p-O(f[D],(B(O(100,D,H[D]),127)))];
                    p+=1;
                    C[p]=q;
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=w(C[p],q);
                end
              else
                if n==12 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]*q;
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]>q;
                end
              end
            else
              if n>=19 then
                if n>=20 then
                  if n==21 then
                    C[O(f[D],(B(D,127)))]=C[p];
                    p=p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]-q;
                  end
                else
                  if C[p] then
                    D=O(f[D],(B(O(107,H[D]),127)));
                  else
                    p=p-1;
                  end
                end
              else
                if n<17 then
                  p-=1;
                else
                  if n~=18 then
                    p+=1;
                    C[p]=C[O(f[D],85)];
                  else
                    if d then
                      for J in X,d,nil do
                        if d then
                          local K=d[J];
                          if K then
                            K[4]=K;
                            K[5]=C[J];
                            K[6]=5;
                            d[J]=nil;
                          end
                        end
                      end;
                    end
                    if b then
                      for J,K in X,b,nil do
                        local o=K[5];
                        if b then
                          K=b[J];
                          if K then
                            local c=S(o);
                            h(C,J,J+o-1,1,c);
                            K[4]=c;
                            K[6]=1;
                            b[J]=nil;
                          end
                        end
                      end;
                    end
                    q=O(f[D],(B(H[D],127)));
                    if q==0 then
                      return;
                    end
                    return V(C,p-q+1,p);
                  end
                end
              end
            end
          end
        else
          if n<33 then
            if n>=27 then
              if n<30 then
                if n<28 then
                  q=C[p];
                  p-=1;
                  local J,K=B(C[p],4294967295),B(q,4294967295);
                  local o,c,t,R=B(J,65535),F(J,16),B(K,65535),F(K,16);
                  K=B(o*t+w(B(o*R+c*t,65535),16),4294967295);
                  c=nil;
                  repeat
                    R=K%4294967296;
                    if R~=R then
                      c=0;
                      break;
                    end
                    c=R-R%1;
                  until true;
                  C[p]=c;
                else
                  if n~=29 then
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                    D+=1;
                    p+=1;
                    C[p]=C[f[D]];
                  else
                    q,G,l=f[D]+1,O(f[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=86;
                    D=D+2;
                  end
                end
              else
                if n<31 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]%q;
                else
                  if n~=32 then
                    q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                    l=q<16384 and 7 or(q<2097152 and 14 or 21);
                    a,P=B(q,w(1,l)-1),F(q,l);
                    f[D]=O(a,62,(B(G,127)));
                    H[D]=O(P,121,(B(F(G,7),127)));
                    D=D-1;
                  else
                    if not C[p] then
                      p-=1;
                      D=O(f[D],(B(r,127)));
                    else
                    end
                  end
                end
              end
            else
              if n<24 then
                if n==23 then
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p=p-1;
                else
                  C[p-O(f[D],(B(H[D],127)))]=C[p];
                  p=p-1;
                end
              else
                if n>=25 then
                  if n~=26 then
                    q,G,l=f[D]+1,O(f[D+1],(B(O(N,(B(F(N,29),7))),536870911))),f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=86;
                    D=D+2;
                  else
                    D=if not C[p]then O(f[D],(B(O(r,44,H[D]),127)))else D;
                  end
                else
                  p+=1;
                  C[p]=C[f[D]];
                  D+=1;
                  p+=1;
                  C[p]=C[f[D]];
                  D+=1;
                  p+=1;
                  C[p]=C[f[D]];
                end
              end
            end
          else
            if n<38 then
              if n<35 then
                if n~=34 then
                  p+=1;
                  C[p]=f[D];
                else
                  q=O(f[D],(B(O(Z,(B(F(Z,29),7))),536870911)));
                  local J,K,o=F(q,8),B(q,255),y[6];
                  local c=O(o[J],187638924);
                  o[J]=c;
                  o,J=y[5],c+1;
                  c=k(o,J);
                  local t,R;
                  if c<128 then
                    t,R=c,J+1;
                  else
                    local g=k(o,J+1);
                    if g<128 then
                      t,R=(c-128)*128+g,J+2;
                    else
                      local u=k(o,J+2);
                      if u<128 then
                        t,R=(c-128)*16384+(g-128)+u*128,J+3;
                      else
                        local U=k(o,J+3);
                        t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,J+4;
                      end
                    end
                  end
                  c,J=K*16843009,R+t;
                  local g=J-t%4;
                  for t=R,g-1,4 do
                    v(o,t,(O(I(o,t),c)));
                  end;
                  for c=g,J-1,1 do
                    i(o,c,(O(k(o,c),K)));
                  end;
                  f[D]=172;
                  H[D]=86;
                end
              else
                if n>=36 then
                  if n==37 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<q;
                  else
                    p+=1;
                    C[p]=m[O(f[D],(B(O(H[D],62,r),127)))];
                  end
                else
                  q=O(f[D],(B(O(Y,(B(F(Y,29),7))),536870911)));
                  local J,K,o=F(q,8),B(q,255),y[6];
                  local c=O(o[J],187638924);
                  o[J]=c;
                  J,o=y[5],c+1;
                  c=k(J,o);
                  local t,R;
                  if c<128 then
                    t,R=c,o+1;
                  else
                    local g=k(J,o+1);
                    if g<128 then
                      t,R=(c-128)*128+g,o+2;
                    else
                      local u=k(J,o+2);
                      if u<128 then
                        t,R=(c-128)*16384+(g-128)+u*128,o+3;
                      else
                        local U=k(J,o+3);
                        t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,o+4;
                      end
                    end
                  end
                  c,o=K*16843009,R+t;
                  local g=o-t%4;
                  for t=R,g-1,4 do
                    v(J,t,(O(I(J,t),c)));
                  end;
                  for c=g,o-1,1 do
                    i(J,c,(O(k(J,c),K)));
                  end;
                  f[D]=206;
                  H[D]=86;
                end
              end
            else
              if n<41 then
                if n>=39 then
                  if n~=40 then
                    q,G=O(f[D],(B(O(H[D],114,D),127))),C[p];
                    p-=1;
                    l=C[p-G];
                    h(C,p-G+1,p,q+1,l);
                    p=p-G;
                  else
                    q,G=O(f[D],(B(O(D,H[D],22),127))),C[p];
                    p-=1;
                    l=p-q;
                    a,p=W(C[l](V(C,l+1,p))),l+G-1;
                    h(a,1,G,l,C);
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=A(C[p],q);
                end
              else
                if n>=42 then
                  if n==43 then
                    q=C[p];
                    D,p=q,p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<=q;
                  end
                else
                  p+=1;
                  C[p]=C[f[D]];
                  D+=1;
                  p+=1;
                  C[p]=C[f[D]];
                end
              end
            end
          end
        end
      else
        if n<66 then
          if n>=55 then
            if n>=60 then
              if n>=63 then
                if n>=64 then
                  if n~=65 then
                    q=C[p];
                    p-=1;
                    C[p]=B(C[p],q);
                  else
                    p+=1;
                    C[p]={};
                  end
                else
                  p+=1;
                  C[p]=f;
                end
              else
                if n<61 then
                  p+=1;
                  C[p]=H;
                else
                  if n~=62 then
                    p+=1;
                    C[p]=N;
                  else
                    C[p]=_(C[p]);
                  end
                end
              end
            else
              if n<57 then
                if n==56 then
                  p+=1;
                  C[p]=T[D];
                else
                  p+=1;
                  C[p]=Y;
                end
              else
                if n>=58 then
                  if n==59 then
                    D,p=if not C[p]then O(f[D],(B(O(111,H[D],r),127)))else D,p-1;
                  else
                    p=p-O(f[D],(B(O(78,D),127)));
                  end
                else
                  local J,K=T[D];
                  if J then
                    local o=#J/3;
                    if o>0 then
                      K={};
                      local c,t=d,b;
                      for R=1,o,1 do
                        local o=(R-1)*3;
                        local g,u=J[o+3],J[o+2];
                        if g==2 then
                          c=if not c then{}else c;
                          local U=c[u];
                          if not U then
                            U={[4]=C,[6]=u};
                            c[u]=U;
                          else
                          end
                          K[R]=U;
                        else
                          if g==1 then
                            K[R]=C[u];
                          else
                            if g==3 then
                              K[R]=m[u];
                            else
                              if g==0 then
                                t=if not t then{}else t;
                                local g=t[u];
                                if not g then
                                  g={[5]=J[o+1],[6]=u,[4]=C};
                                  t[u]=g;
                                else
                                end
                                K[R]=g;
                              else
                              end
                            end
                          end
                        end
                      end;
                      d,b=c,t;
                    else
                    end
                  else
                  end
                  C[p]=C[p](nil,K);
                  q=K;
                end
              end
            end
          else
            if n>=49 then
              if n>=52 then
                if n>=53 then
                  D=if n==54 then if C[p]then O(f[D],(B(O(103,H[D]),127)))else D else O(f[D],(B(O(14,r,H[D]),127)));
                else
                  q,G=O(f[D],(B(O(D,114,H[D]),127))),C[p];
                  p-=1;
                  l=p-q;
                  C[l]=W(C[l](V(C,l+1,p)));
                  p=l;
                end
              else
                if n>=50 then
                  if n==51 then
                    p+=1;
                    C[p]=y;
                  else
                    q=O(f[D],(B(O(N,(B(F(N,29),7))),536870911)));
                    local J,K,o=F(q,8),B(q,255),y[6];
                    local c=O(o[J],187638924);
                    o[J]=c;
                    o,J=y[5],c+1;
                    c=k(o,J);
                    local t,R;
                    if c<128 then
                      t,R=c,J+1;
                    else
                      local g=k(o,J+1);
                      if g<128 then
                        t,R=(c-128)*128+g,J+2;
                      else
                        local u=k(o,J+2);
                        if u<128 then
                          t,R=(c-128)*16384+(g-128)+u*128,J+3;
                        else
                          local U=k(o,J+3);
                          t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,J+4;
                        end
                      end
                    end
                    J,c=K*16843009,R+t;
                    local g=c-t%4;
                    for t=R,g-1,4 do
                      v(o,t,(O(I(o,t),J)));
                    end;
                    for J=g,c-1,1 do
                      i(o,J,(O(k(o,J),K)));
                    end;
                    f[D]=82;
                    H[D]=86;
                  end
                else
                  local J,K=C[p];
                  repeat
                    local o=J%4294967296;
                    if o~=o then
                      K=0;
                      break;
                    end
                    K=o-o%1;
                  until true;
                  C[p]=K;
                end
              end
            else
              if n<46 then
                if n==45 then
                  D,p=if C[p]then O(f[D],(B(O(37,r),127)))else D,p-1;
                else
                  if C[p] then
                    p-=1;
                    D=O(f[D],(B(O(r,56),127)));
                  else
                  end
                end
              else
                if n<47 then
                  p+=1;
                  C[p]=x[T[D]];
                else
                  if n==48 then
                    q=m[O(f[D],(B(O(H[D],27),127)))];
                    p+=1;
                    C[p]=q[4][q[6]];
                  else
                    q=O(f[D],99);
                    G=p-q+1;
                    h(C,G,p,L+1,C);
                    p=L+q;
                  end
                end
              end
            end
          end
        else
          if n<77 then
            if n<71 then
              if n<68 then
                if n~=67 then
                  q=C[p];
                  p-=1;
                  C[p]=O(C[p],q);
                else
                  p+=1;
                  C[p]=s[O(f[D],(B(r,127)))];
                end
              else
                if n>=69 then
                  if n~=70 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]..q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]+q;
                  end
                else
                  Y=C[p];
                  p=p-1;
                end
              end
            else
              if n<74 then
                if n>=72 then
                  if n~=73 then
                    C[p]=#C[p];
                  else
                    local J=O(f[D],(B(O(D,r),127)));
                    if d then
                      local K=d[J];
                      if K then
                        K[4]=K;
                        K[5]=C[J];
                        K[6]=5;
                        d[J]=nil;
                      end
                    end
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p][q];
                end
              else
                if n<75 then
                  C[f[D]]=C[p];
                  p-=1;
                  D+=1;
                  C[f[D]]=C[p];
                  p=p-1;
                else
                  if n~=76 then
                    C[p]=not C[p];
                  else
                    p+=1;
                    C[p]=Z;
                  end
                end
              end
            end
          else
            if n<83 then
              if n>=80 then
                if n>=81 then
                  if n~=82 then
                    N=C[p];
                    p=p-1;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=F(C[p],q);
                  end
                else
                  q,G,l=f[D]+1,f[D+1],f[D+2];
                  for J=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=86;
                  D=D+2;
                end
              else
                if n<78 then
                  q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                  l=q<2097152 and 7 or 14;
                  a,P=F(q,l),B(q,w(1,l)-1);
                  f[D]=O(P,61,(B(G,127)));
                  H[D]=O(a,31,(B(F(G,7),127)));
                  D=D-1;
                else
                  if n==79 then
                    p+=1;
                    C[p]=nil;
                  else
                    q=f[D];
                    local J,K,o=F(q,8),B(q,255),y[6];
                    local c=O(o[J],187638924);
                    o[J]=c;
                    J,o=y[5],c+1;
                    c=k(J,o);
                    local t,R;
                    if c<128 then
                      t,R=c,o+1;
                    else
                      local g=k(J,o+1);
                      if g<128 then
                        t,R=(c-128)*128+g,o+2;
                      else
                        local u=k(J,o+2);
                        if u<128 then
                          t,R=(c-128)*16384+(g-128)+u*128,o+3;
                        else
                          local U=k(J,o+3);
                          t,R=c-128+(g-128)*2097152+(u-128)*128+U%128*16384+(U-U%128)*2097152,o+4;
                        end
                      end
                    end
                    c,o=K*16843009,R+t;
                    local g=o-t%4;
                    for t=R,g-1,4 do
                      v(J,t,(O(I(J,t),c)));
                    end;
                    for c=g,o-1,1 do
                      i(J,c,(O(k(J,c),K)));
                    end;
                    f[D]=35;
                    H[D]=86;
                  end
                end
              end
            else
              if n>=86 then
                if n>=87 then
                  if n~=88 then
                    C[p]=-C[p];
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]//q;
                  end
                else
                end
              else
                if n<84 then
                  q,G,l=f[D]+1,O(f[D+1],(B(O(Z,(B(F(Z,29),7))),536870911))),f[D+2];
                  for J=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=86;
                  D=D+2;
                else
                  if n==85 then
                    q,G=C[p],C[p-1];
                    C[p-1]=G[q];
                    C[p]=G;
                  else
                    q,p=C[p],L+1;
                    C[L+1]=q;
                  end
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  else
  end
  if r==133 then
    while true do
      local n=H[D];
      if n<41 then
        if n<20 then
          if n<10 then
            if n<5 then
              if n>=2 then
                if n<3 then
                  p+=1;
                  C[p]=Z;
                else
                  if n==4 then
                    p+=1;
                    C[p]=x[T[D]];
                  else
                    q,G,l=f[D]+1,O(f[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=46;
                    D=D+2;
                  end
                end
              else
                if n~=1 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]/q;
                else
                  p+=1;
                  C[p]=O(f[D],(B(O(110,r,H[D]),127)));
                end
              end
            else
              if n<7 then
                if n==6 then
                  D,p=if C[p]then O(f[D],(B(O(r,H[D],45),127)))else D,p-1;
                else
                  if not C[p] then
                    p-=1;
                    D=O(f[D],(B(O(r,H[D],32),127)));
                  else
                  end
                end
              else
                if n<8 then
                  p+=1;
                  C[p]=H;
                else
                  if n~=9 then
                    D=if not C[p]then O(f[D],(B(O(H[D],96,r),127)))else D;
                  else
                    q,G,l=f[D]+1,O(f[D+1],(B(O(Z,(B(F(Z,29),7))),536870911))),f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=46;
                    D=D+2;
                  end
                end
              end
            end
          else
            if n>=15 then
              if n<17 then
                if n==16 then
                  q=C[p];
                  p-=1;
                  C[p]=A(C[p],q);
                else
                  C[p]=_(C[p]);
                end
              else
                if n<18 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]>=q;
                else
                  if n~=19 then
                    p+=1;
                    C[p]=C[O(f[D],(B(O(61,r),127)))];
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]-q;
                  end
                end
              end
            else
              if n<12 then
                if n~=11 then
                  p+=1;
                  C[p]=Y;
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]*q;
                end
              else
                if n<13 then
                  q,G=O(f[D],(B(O(D,r),127))),C[p];
                  p-=1;
                  l=p-q;
                  a,p=W(C[l](V(C,l+1,p))),l+G-1;
                  h(a,1,G,l,C);
                else
                  if n~=14 then
                    p=p-O(f[D],(B(H[D],127)));
                  else
                    q,G,l,a,P=C[p],C[p-1],C[p-2],C[p-3],E(Q);
                    P(s,a,l,G);
                    local J;
                    J,P,l,G=P,p-3,nil,nil;
                    C[P]=J;
                    C[P+1]=l;
                    C[P+2]=G;
                    C[P+3]=q;
                    C[P+4]=O(f[D],(B(O(H[D],r,D),127)));
                    p,a=P+4,P;
                  end
                end
              end
            end
          end
        else
          if n>=30 then
            if n<35 then
              if n>=32 then
                if n<33 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]>q;
                else
                  if n~=34 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]//q;
                  else
                    q=m[O(f[D],(B(O(H[D],51,r),127)))];
                    p+=1;
                    C[p]=q[4][q[6]];
                  end
                end
              else
                if n~=31 then
                  local J;
                  local K=T[D];
                  if K then
                    local o=#K/3;
                    if o>0 then
                      J={};
                      local c,_=d,b;
                      for x=1,o,1 do
                        local o=(x-1)*3;
                        local E,Q=K[o+3],K[o+2];
                        if E==2 then
                          c=if not c then{}else c;
                          local t=c[Q];
                          if not t then
                            t={[4]=C,[6]=Q};
                            c[Q]=t;
                          else
                          end
                          J[x]=t;
                        else
                          if E==1 then
                            J[x]=C[Q];
                          else
                            if E==3 then
                              J[x]=m[Q];
                            else
                              if E==0 then
                                _=if not _ then{}else _;
                                local E=_[Q];
                                if not E then
                                  E={[5]=K[o+1],[6]=Q,[4]=C};
                                  _[Q]=E;
                                else
                                end
                                J[x]=E;
                              else
                              end
                            end
                          end
                        end
                      end;
                      d,b=c,_;
                    else
                    end
                  else
                  end
                  C[p]=C[p](nil,J);
                  q=J;
                else
                  C[p]=#C[p];
                end
              end
            else
              if n>=38 then
                if n<39 then
                  q,G=O(f[D],(B(O(D,r,H[D]),127))),C[p];
                  p-=1;
                  l,a=p-q,C[p];
                  P=a.n;
                  e=q-1+P;
                  a.n=e;
                  h(a,1,P,q,a);
                  h(C,l+1,p-1,1,a);
                  j,p=W(C[l](V(a,1,a.n))),l+G-1;
                  h(j,1,G,l,C);
                else
                  if n~=40 then
                    C[p-O(f[D],(B(O(H[D],78,r),127)))]=C[p];
                    p-=1;
                  else
                    p+=1;
                    C[p]={};
                  end
                end
              else
                if n>=36 then
                  if n==37 then
                    q=p-O(f[D],24);
                    G=C[q];
                    C[q]=C[p];
                    C[p]=G;
                  else
                    if d then
                      for J in X,d,nil do
                        if d then
                          local K=d[J];
                          if K then
                            K[4]=K;
                            K[5]=C[J];
                            K[6]=5;
                            d[J]=nil;
                          end
                        end
                      end;
                    end
                    if b then
                      for J,K in X,b,nil do
                        local o=K[5];
                        if b then
                          K=b[J];
                          if K then
                            local c=S(o);
                            h(C,J,J+o-1,1,c);
                            K[4]=c;
                            K[6]=1;
                            b[J]=nil;
                          end
                        end
                      end;
                    end
                    q=O(f[D],(B(O(r,H[D],85),127)));
                    if q==0 then
                      return;
                    end
                    return V(C,p-q+1,p);
                  end
                else
                  p+=1;
                  C[p]=N;
                end
              end
            end
          else
            if n<25 then
              if n<22 then
                if n~=21 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]+q;
                else
                  q=C[p];
                  p-=1;
                  C[p]=B(C[p],q);
                end
              else
                if n>=23 then
                  if n==24 then
                    C[p]=not C[p];
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<q;
                  end
                else
                  q=O(f[D],(B(O(r,H[D]),127)));
                  G=p-q+1;
                  h(C,G,p,L+1,C);
                  p=L+q;
                end
              end
            else
              if n>=27 then
                if n>=28 then
                  if n~=29 then
                    if not C[p] then
                      D=O(f[D],(B(O(r,H[D]),127)));
                    else
                      p=p-1;
                    end
                  else
                    q=C[p];
                    p-=1;
                    local J,K=B(C[p],4294967295),B(q,4294967295);
                    local o,c,_,x=B(J,65535),F(J,16),B(K,65535),F(K,16);
                    K=B(o*_+w(B(o*x+c*_,65535),16),4294967295);
                    J=nil;
                    repeat
                      o=K%4294967296;
                      if o~=o then
                        J=0;
                        break;
                      end
                      J=o-o%1;
                    until true;
                    C[p]=J;
                  end
                else
                  p+=1;
                  C[p]=f[D];
                end
              else
                if n==26 then
                  p+=1;
                  C[p]=nil;
                else
                  q=C[p-O(f[D],(B(D,127)))];
                  p+=1;
                  C[p]=q;
                end
              end
            end
          end
        end
      else
        if n>=62 then
          if n<72 then
            if n>=67 then
              if n<69 then
                if n==68 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]~=q;
                else
                  D=if C[p]then O(f[D],(B(O(H[D],36,r),127)))else D;
                end
              else
                if n>=70 then
                  if n==71 then
                    C[O(f[D],(B(O(126,r,H[D]),127)))]=C[p];
                    p=p-1;
                  else
                    q,G,l=f[D]+1,f[D+1],f[D+2];
                    for J=1,l,1 do
                      G=B(O(G,(w(G,13))),536870911);
                      G=O(G,(F(G,13)));
                      G=B(O(G,(w(G,14))),536870911);
                      f[q]=O(f[q],(B(F(G,0),127)));
                      H[q]=O(H[q],(B(F(G,7),127)));
                      q=q+1;
                    end;
                    H[D]=46;
                    D=D+2;
                  end
                else
                  q=C[p];
                  p-=1;
                  C[p]=F(C[p],q);
                end
              end
            else
              if n<64 then
                if n==63 then
                  local J,K=C[p];
                  repeat
                    local o=J%4294967296;
                    if o~=o then
                      K=0;
                      break;
                    end
                    K=o-o%1;
                  until true;
                  C[p]=K;
                else
                  q=f[D];
                  local J,K,o=F(q,8),B(q,255),y[6];
                  local c=O(o[J],187638924);
                  o[J]=c;
                  J,o=y[5],c+1;
                  c=k(J,o);
                  local _,x;
                  if c<128 then
                    _,x=c,o+1;
                  else
                    local E=k(J,o+1);
                    if E<128 then
                      _,x=(c-128)*128+E,o+2;
                    else
                      local Q=k(J,o+2);
                      if Q<128 then
                        _,x=(c-128)*16384+(E-128)+Q*128,o+3;
                      else
                        local t=k(J,o+3);
                        _,x=c-128+(E-128)*2097152+(Q-128)*128+t%128*16384+(t-t%128)*2097152,o+4;
                      end
                    end
                  end
                  o,c=K*16843009,x+_;
                  local E=c-_%4;
                  for _=x,E-1,4 do
                    v(J,_,(O(I(J,_),o)));
                  end;
                  for o=E,c-1,1 do
                    i(J,o,(O(k(J,o),K)));
                  end;
                  f[D]=43;
                  H[D]=46;
                end
              else
                if n>=65 then
                  if n~=66 then
                    p+=1;
                    C[p]=s[O(f[D],(B(D,127)))];
                  else
                    q,G=O(Z,B(F(Z,14),262143),(B(F(Z,28),15))),f[D];
                    l=G<2097152 and 7 or 14;
                    a,P=F(G,l),B(G,w(1,l)-1);
                    f[D]=O(P,83,(B(q,127)));
                    H[D]=O(a,55,(B(F(q,7),127)));
                    D=D-1;
                  end
                else
                  q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                  l=q<16384 and 7 or(q<2097152 and 14 or 21);
                  a,P=F(q,l),B(q,w(1,l)-1);
                  H[D]=O(a,17,(B(F(G,7),127)));
                  f[D]=O(P,67,(B(G,127)));
                  D=D-1;
                end
              end
            end
          else
            if n>=77 then
              if n<80 then
                if n<78 then
                  q,G=C[p],C[p-1];
                  C[p-1]=G[q];
                  C[p]=G;
                else
                  if n==79 then
                    p+=1;
                    C[p]=T[D];
                  else
                    q,G=O(f[D],(B(O(D,47),127))),C[p];
                    p-=1;
                    l=C[p-G];
                    h(C,p-G+1,p,q+1,l);
                    p=p-G;
                  end
                end
              else
                if n>=81 then
                  if n~=82 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]..q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=w(C[p],q);
                  end
                else
                  p+=1;
                  C[p]=y;
                end
              end
            else
              if n>=74 then
                if n<75 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p][q];
                else
                  if n~=76 then
                    q,G,l=C[p],C[p-1],C[p-2];
                    p-=3;
                    l[G]=q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]==q;
                  end
                end
              else
                if n~=73 then
                  q=C[p];
                  p+=1;
                  C[p]=q;
                else
                  q,G,l=f[D]+1,O(f[D+1],(B(O(N,(B(F(N,29),7))),536870911))),f[D+2];
                  for s=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    f[q]=O(f[q],(B(F(G,0),127)));
                    H[q]=O(H[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  H[D]=46;
                  D=D+2;
                end
              end
            end
          end
        else
          if n<51 then
            if n<46 then
              if n>=43 then
                if n<44 then
                  Z=C[p];
                  p=p-1;
                else
                  if n~=45 then
                    p=p-1;
                  else
                    Y=C[p];
                    p=p-1;
                  end
                end
              else
                if n==42 then
                  q,G=m[O(f[D],(B(O(37,D,r),127)))],C[p];
                  p-=1;
                  q[4][q[6]]=G;
                else
                  if C[p] then
                    p-=1;
                    D=O(f[D],(B(O(96,r),127)));
                  else
                  end
                end
              end
            else
              if n<48 then
                if n==47 then
                  q,G,l,a,P=C[p-4],C[p-3],C[p-2],C[p-1],C[p];
                  local s,J=q();
                  if s then
                    C[p-2]=l;
                    if P~=0 then
                      for K=1,a,1 do
                        C[P+K-1]=J[K];
                      end;
                    else
                      h(J,1,a,p+1,C);
                      p+=a;
                    end
                    D=O(f[D],(B(O(r,76),127)));
                  else
                    p=p-5;
                  end
                  e,j=s,J;
                else
                end
              else
                if n>=49 then
                  if n~=50 then
                    if C[p] then
                      D=O(f[D],(B(O(82,H[D],r),127)));
                    else
                      p=p-1;
                    end
                  else
                    q,G=O(f[D],(B(O(r,H[D]),127))),C[p];
                    p-=1;
                    l=p-q;
                    C[l]=W(C[l](V(C,l+1,p)));
                    p=l;
                  end
                else
                  D,p=if not C[p]then O(f[D],(B(O(66,H[D]),127)))else D,p-1;
                end
              end
            end
          else
            if n<56 then
              if n<53 then
                if n~=52 then
                  p+=1;
                  C[p]=f;
                else
                  q=C[p];
                  p-=1;
                  C[p]=O(C[p],q);
                end
              else
                if n>=54 then
                  if n==55 then
                    q=C[p];
                    p-=1;
                    C[p]=C[p]%q;
                  else
                    q=C[p];
                    p-=1;
                    C[p]=C[p]<=q;
                  end
                else
                  D=O(f[D],(B(O(r,55,H[D]),127)));
                end
              end
            else
              if n<59 then
                local s=D;
                if n<57 then
                  N=C[p];
                  p=p-1;
                else
                  if n==58 then
                    p+=1;
                    C[p]=m[O(f[s],(B(r,127)))];
                  else
                    r=C[p];
                    p-=1;
                    D=O(f[s],(B(O(43,H[s]),127)))+1;
                    break;
                  end
                end
              else
                if n<60 then
                  q=p-1;
                  G=C[q];
                  C[q]=C[p];
                  C[p]=G;
                else
                  if n~=61 then
                    q,p=C[p],L+1;
                    C[L+1]=q;
                  else
                    q=C[p];
                    D,p=q,p-1;
                  end
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  else
  end
  if r==60 then
    while true do
      local s=f[D];
      if s>=23 then
        if s>=35 then
          if s<41 then
            if s>=38 then
              if s>=39 then
                if s==40 then
                  q=C[p];
                  p-=1;
                  C[p]=O(C[p],q);
                else
                  q=p-1;
                  G=C[q];
                  C[q]=C[p];
                  C[p]=G;
                end
              else
                Z=C[p];
                p=p-1;
              end
            else
              if s<36 then
                q=C[p];
                D,p=q,p-1;
              else
                local n=p;
                if s==37 then
                  r,p=C[n],n-1;
                  D=O(H[D],46)+1;
                  break;
                else
                  q,G=H[D],O(N,B(F(N,14),262143),(B(F(N,28),15)));
                  l=q<16384 and 7 or(q<2097152 and 14 or 21);
                  a,P=B(q,w(1,l)-1),F(q,l);
                  f[D]=O(P,20,(B(F(G,7),127)));
                  H[D]=O(a,15,(B(G,127)));
                  D-=1;
                end
              end
            end
          else
            if s<44 then
              if s<42 then
              else
                if s==43 then
                  q=m[O(H[D],(B(O(r,D),127)))];
                  p+=1;
                  C[p]=q[4][q[6]];
                else
                  if d then
                    for n in X,d,nil do
                      if d then
                        local J=d[n];
                        if J then
                          J[4]=J;
                          J[5]=C[n];
                          J[6]=5;
                          d[n]=nil;
                        end
                      end
                    end;
                  end
                  if b then
                    for n,J in X,b,nil do
                      local e=J[5];
                      if b then
                        J=b[n];
                        if J then
                          local j,K=n+e-1,S(e);
                          h(C,n,j,1,K);
                          J[4]=K;
                          J[6]=1;
                          b[n]=nil;
                        end
                      end
                    end;
                  end
                  q=O(H[D],(B(O(D,f[D]),127)));
                  if q==0 then
                    return;
                  end
                  return V(C,p-q+1,p);
                end
              end
            else
              if s>=45 then
                if s==46 then
                  q,G=O(H[D],(B(O(33,r,D),127))),C[p];
                  p-=1;
                  l=p-q;
                  a,p=W(C[l](V(C,l+1,p))),l+G-1;
                  h(a,1,G,l,C);
                else
                  p+=1;
                  C[p]=N;
                end
              else
                q=C[p];
                p-=1;
                C[p]=C[p]..q;
              end
            end
          end
        else
          if s>=29 then
            if s<32 then
              if s>=30 then
                if s==31 then
                  p+=1;
                  C[p]=Z;
                else
                  local n;
                  local J=z[D];
                  if J then
                    local e=#J/3;
                    if e>0 then
                      n={};
                      local j,K=d,b;
                      for o=1,e,1 do
                        local e=(o-1)*3;
                        local c,_=J[e+3],J[e+2];
                        if c==2 then
                          j=if not j then{}else j;
                          local x=j[_];
                          if not x then
                            x={[4]=C,[6]=_};
                            j[_]=x;
                          else
                          end
                          n[o]=x;
                        else
                          if c==1 then
                            n[o]=C[_];
                          else
                            if c==3 then
                              n[o]=m[_];
                            else
                              if c==0 then
                                K=if not K then{}else K;
                                local c=K[_];
                                if not c then
                                  c={[5]=J[e+1],[6]=_,[4]=C};
                                  K[_]=c;
                                else
                                end
                                n[o]=c;
                              else
                              end
                            end
                          end
                        end
                      end;
                      d,b=j,K;
                    else
                    end
                  else
                  end
                  C[p]=C[p](nil,n);
                  q=n;
                end
              else
                q=C[p];
                p-=1;
                C[p]=A(C[p],q);
              end
            else
              if s<33 then
                q,G,l=H[D]+1,O(H[D+1],(B(O(N,(B(F(N,29),7))),536870911))),H[D+2];
                for n=1,l,1 do
                  G=B(O(G,(w(G,13))),536870911);
                  G=O(G,(F(G,13)));
                  G=B(O(G,(w(G,14))),536870911);
                  H[q]=O(H[q],(B(F(G,0),127)));
                  f[q]=O(f[q],(B(F(G,7),127)));
                  q=q+1;
                end;
                f[D]=41;
                D=D+2;
              else
                if s~=34 then
                  local n,J=C[p];
                  repeat
                    local e=n%4294967296;
                    if e~=e then
                      J=0;
                      break;
                    end
                    J=e-e%1;
                  until true;
                  C[p]=J;
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]+q;
                end
              end
            end
          else
            if s<26 then
              if s>=24 then
                if s~=25 then
                  q=C[p-O(H[D],(B(O(r,38),127)))];
                  p+=1;
                  C[p]=q;
                else
                  p=p-O(H[D],(B(O(D,f[D],r),127)));
                end
              else
                q=C[p];
                p-=1;
                C[p]=C[p]//q;
              end
            else
              if s<27 then
                q,G,l=H[D]+1,O(H[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),H[D+2];
                for n=1,l,1 do
                  G=B(O(G,(w(G,13))),536870911);
                  G=O(G,(F(G,13)));
                  G=B(O(G,(w(G,14))),536870911);
                  H[q]=O(H[q],(B(F(G,0),127)));
                  f[q]=O(f[q],(B(F(G,7),127)));
                  q=q+1;
                end;
                f[D]=41;
                D=D+2;
              else
                if s~=28 then
                  q,G,l=H[D]+1,H[D+1],H[D+2];
                  for n=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    H[q]=O(H[q],(B(F(G,0),127)));
                    f[q]=O(f[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  f[D]=41;
                  D=D+2;
                else
                  p+=1;
                  C[p]=Y;
                end
              end
            end
          end
        end
      else
        if s<11 then
          if s<5 then
            if s>=2 then
              if s>=3 then
                if s~=4 then
                  p+=1;
                  C[p]=O(H[D],(B(O(r,f[D]),127)));
                else
                  p-=1;
                end
              else
                p+=1;
                C[p]=f;
              end
            else
              if s~=1 then
                p+=1;
                C[p]=m[O(H[D],(B(f[D],127)))];
              else
                p+=1;
                C[p]=y;
              end
            end
          else
            if s>=8 then
              if s<9 then
                C[O(H[D],(B(f[D],127)))]=C[p];
                p=p-1;
              else
                if s==10 then
                  D,p=if not C[p]then O(H[D],76)else D,p-1;
                else
                  q,G,l=H[D]+1,O(H[D+1],(B(O(Z,(B(F(Z,29),7))),536870911))),H[D+2];
                  for n=1,l,1 do
                    G=B(O(G,(w(G,13))),536870911);
                    G=O(G,(F(G,13)));
                    G=B(O(G,(w(G,14))),536870911);
                    H[q]=O(H[q],(B(F(G,0),127)));
                    f[q]=O(f[q],(B(F(G,7),127)));
                    q=q+1;
                  end;
                  f[D]=41;
                  D=D+2;
                end
              end
            else
              if s>=6 then
                if s~=7 then
                  p+=1;
                  C[p]=H;
                else
                  q=C[p];
                  p+=1;
                  C[p]=q;
                end
              else
                p+=1;
                C[p]=C[O(H[D],(B(O(f[D],D,54),127)))];
              end
            end
          end
        else
          if s<17 then
            if s>=14 then
              if s>=15 then
                if s~=16 then
                  Y=C[p];
                  p=p-1;
                else
                  p+=1;
                  C[p]=H[D];
                end
              else
                N=C[p];
                p=p-1;
              end
            else
              if s>=12 then
                if s==13 then
                  q=H[D];
                  local n,J,e=F(q,8),B(q,255),y[6];
                  local j=O(e[n],187638924);
                  e[n]=j;
                  n,e=y[5],j+1;
                  j=k(n,e);
                  local K,o;
                  if j<128 then
                    K,o=j,e+1;
                  else
                    local c=k(n,e+1);
                    if c<128 then
                      K,o=(j-128)*128+c,e+2;
                    else
                      local A=k(n,e+2);
                      if A<128 then
                        K,o=(j-128)*16384+(c-128)+A*128,e+3;
                      else
                        local _=k(n,e+3);
                        K,o=j-128+(c-128)*2097152+(A-128)*128+_%128*16384+(_-_%128)*2097152,e+4;
                      end
                    end
                  end
                  e,j=J*16843009,o+K;
                  local c=j-K%4;
                  for K=o,c-1,4 do
                    v(n,K,(O(I(n,K),e)));
                  end;
                  for e=c,j-1,1 do
                    i(n,e,(O(k(n,e),J)));
                  end;
                  H[D]=236;
                  f[D]=41;
                else
                  D=O(H[D],(B(O(f[D],r,30),127)));
                end
              else
                q=O(H[D],(B(O(D,15,r),127)));
                G=p-q+1;
                h(C,G,p,L+1,C);
                p=L+q;
              end
            end
          else
            if s>=20 then
              if s>=21 then
                if s~=22 then
                  p+=1;
                  C[p]=nil;
                else
                  q,p=C[p],L+1;
                  C[L+1]=q;
                end
              else
                C[p-O(H[D],(B(D,127)))]=C[p];
                p=p-1;
              end
            else
              if s<18 then
                p+=1;
                C[p]=z[D];
              else
                if s==19 then
                  q=C[p];
                  p-=1;
                  C[p]=C[p]-q;
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]<=q;
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  else
  end
  if r==90 then
    while true do
      local s=H[D];
      if s>=18 then
        if s>=27 then
          if s>=31 then
            if s<33 then
              if s==32 then
                p+=1;
                C[p]=N;
              else
                p+=1;
                C[p]=nil;
              end
            else
              if s<34 then
                if d then
                  for z in X,d,nil do
                    if d then
                      local n=d[z];
                      if n then
                        n[4]=n;
                        n[5]=C[z];
                        n[6]=5;
                        d[z]=nil;
                      end
                    end
                  end;
                end
                if b then
                  for z,n in X,b,nil do
                    local J=n[5];
                    if b then
                      n=b[z];
                      if n then
                        local e,j=z+J,S(J);
                        h(C,z,e-1,1,j);
                        n[4]=j;
                        n[6]=1;
                        b[z]=nil;
                      end
                    end
                  end;
                end
                q=C[p];
                p-=1;
                G=p-q;
                return C[G](V(C,G+1,p));
              elseif s==35 then
                p+=1;
                C[p]=y;
              else
                q=C[p];
                p-=1;
                C[p]=O(C[p],q);
              end
            end
          else
            if s>=29 then
              if s~=30 then
                q=C[p];
                p+=1;
                C[p]=q;
              else
                q,G=C[p],C[p-1];
                C[p-1]=G[q];
                C[p]=G;
              end
            else
              if s~=28 then
                q=f[D];
                local z,n,J=F(q,8),B(q,255),y[6];
                local e=O(J[z],187638924);
                J[z]=e;
                z,J=y[5],e+1;
                e=k(z,J);
                local y,j;
                if e<128 then
                  y,j=e,J+1;
                else
                  local N=k(z,J+1);
                  if N<128 then
                    y,j=(e-128)*128+N,J+2;
                  else
                    local K=k(z,J+2);
                    if K<128 then
                      y,j=(e-128)*16384+(N-128)+K*128,J+3;
                    else
                      local o=k(z,J+3);
                      y,j=e-128+(N-128)*2097152+(K-128)*128+o%128*16384+(o-o%128)*2097152,J+4;
                    end
                  end
                end
                J,e=n*16843009,j+y;
                local N=e-y%4;
                for y=j,N-1,4 do
                  v(z,y,(O(I(z,y),J)));
                end;
                for y=N,e-1,1 do
                  i(z,y,(O(k(z,y),n)));
                end;
                f[D]=221;
                H[D]=7;
              else
                if d then
                  for y in X,d,nil do
                    if d then
                      local z=d[y];
                      if z then
                        z[4]=z;
                        z[5]=C[y];
                        z[6]=5;
                        d[y]=nil;
                      end
                    end
                  end;
                end
                if b then
                  for y,z in X,b,nil do
                    local n=z[5];
                    if b then
                      z=b[y];
                      if z then
                        local J=S(n);
                        h(C,y,y+n-1,1,J);
                        z[4]=J;
                        z[6]=1;
                        b[y]=nil;
                      end
                    end
                  end;
                end
                q=O(f[D],(B(O(H[D],r),127)));
                if q==0 then
                  return;
                end
                return V(C,p-q+1,p);
              end
            end
          end
        else
          if s>=22 then
            if s<24 then
              if s==23 then
                p=p-O(f[D],(B(O(H[D],D),127)));
              else
                q,G=O(f[D],3),C[p];
                p-=1;
                l=p-q;
                a,p=W(C[l](V(C,l+1,p))),l+G-1;
                h(a,1,G,l,C);
              end
            else
              if s>=25 then
                if s==26 then
                  D=O(f[D],(B(O(r,20,H[D]),127)));
                else
                  q=C[p];
                  p-=1;
                  C[p]=C[p]+q;
                end
              else
                p+=1;
                C[p]=f[D];
              end
            end
          else
            if s<20 then
              if s==19 then
                q=C[p];
                D,p=q,p-1;
              else
                C[O(f[D],38)]=C[p];
                p=p-1;
              end
            else
              if s==21 then
                p+=1;
                C[p]=Z;
              else
                p+=1;
                C[p]=O(f[D],(B(O(H[D],r),127)));
              end
            end
          end
        end
      else
        if s<9 then
          if s>=4 then
            if s<6 then
              if s~=5 then
                p+=1;
                C[p]=H;
              else
                q=C[p];
                p-=1;
                C[p]=C[p]-q;
              end
            else
              if s<7 then
                p+=1;
                C[p]=T[D];
              else
                if s~=8 then
                else
                  q,G=f[D],O(Z,B(F(Z,14),262143),(B(F(Z,28),15)));
                  l=q<16384 and 7 or(q<2097152 and 14 or 21);
                  a,P=F(q,l),B(q,w(1,l)-1);
                  f[D]=O(P,82,(B(G,127)));
                  H[D]=O(a,110,(B(F(G,7),127)));
                  D=D-1;
                end
              end
            end
          else
            if s>=2 then
              if s~=3 then
                p+=1;
                C[p]=C[O(f[D],(B(H[D],127)))];
              else
                q,G,l=f[D]+1,O(f[D+1],(B(O(Y,(B(F(Y,29),7))),536870911))),f[D+2];
                for y=1,l,1 do
                  G=B(O(G,(w(G,13))),536870911);
                  G=O(G,(F(G,13)));
                  G=B(O(G,(w(G,14))),536870911);
                  f[q]=O(f[q],(B(F(G,0),127)));
                  H[q]=O(H[q],(B(F(G,7),127)));
                  q=q+1;
                end;
                H[D]=7;
                D=D+2;
              end
            else
              if s==1 then
                p+=1;
                C[p]=Y;
              else
                p+=1;
                C[p]=m[O(f[D],21)];
              end
            end
          end
        else
          if s<13 then
            if s>=11 then
              if s==12 then
                local y;
                local z=T[D];
                if z then
                  local T=#z/3;
                  if T>0 then
                    y={};
                    local n,J=d,b;
                    for a=1,T,1 do
                      local T=(a-1)*3;
                      local P,Z=z[T+3],z[T+2];
                      if P==2 then
                        n=if not n then{}else n;
                        local Y=n[Z];
                        if not Y then
                          Y={[4]=C,[6]=Z};
                          n[Z]=Y;
                        else
                        end
                        y[a]=Y;
                      else
                        if P==1 then
                          y[a]=C[Z];
                        else
                          if P==3 then
                            y[a]=m[Z];
                          else
                            if P==0 then
                              J=if not J then{}else J;
                              local P=J[Z];
                              if not P then
                                P={[5]=z[T+1],[6]=Z,[4]=C};
                                J[Z]=P;
                              else
                              end
                              y[a]=P;
                            else
                            end
                          end
                        end
                      end
                    end;
                    d,b=n,J;
                  else
                  end
                else
                end
                C[p]=C[p](nil,y);
                q=y;
              else
                q,G,l=f[D]+1,f[D+1],f[D+2];
                for y=1,l,1 do
                  G=B(O(G,(w(G,13))),536870911);
                  G=O(G,(F(G,13)));
                  G=B(O(G,(w(G,14))),536870911);
                  f[q]=O(f[q],(B(F(G,0),127)));
                  H[q]=O(H[q],(B(F(G,7),127)));
                  q=q+1;
                end;
                H[D]=7;
                D=D+2;
              end
            else
              if s~=10 then
                q=C[p];
                p-=1;
                C[p]=C[p][q];
              else
                q,p=C[p],L+1;
                C[L+1]=q;
              end
            end
          else
            if s<15 then
              if s~=14 then
                D,p=if not C[p]then O(f[D],(B(O(r,H[D]),127)))else D,p-1;
              else
                local l,L=C[p];
                repeat
                  local y=l%4294967296;
                  if y~=y then
                    L=0;
                    break;
                  end
                  L=y-y%1;
                until true;
                C[p]=L;
              end
            else
              if s<16 then
                q=C[p];
                p-=1;
                C[p]=C[p]..q;
              else
                if s~=17 then
                  q=C[p-O(f[D],(B(r,127)))];
                  p+=1;
                  C[p]=q;
                else
                  p+=1;
                  C[p]=f;
                end
              end
            end
          end
        end
      end
      D=D+1;
    end;
  end
end
