-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4132] / function #0
-- offset 3128514..3202201 (73687 bytes, type=state-machine)

function(s,l,L,y,z,T,n,n,J,H,H,f,a,d,P,Z,Z)
  local Z,G,Y,e,j,C,N,q,b,D,p,r,K,o,c,m,S,O,B=s[104],s[98],s[53],s[79],s[97],s[3],s[20],s[36],s[22],s[85],s[78],s[102],s[70],s[49],s[88],s[46],s.hS,s.GS,s[48];
  return function(A,A)
    local w,F,h,W,V,_,X,x,k,v,I,i,E,Q,t,R,g,u,U=Z,G,Y,e,j,C,N,q,b,D,p,r,K,o,c,m,S,O,B;
    return function(...)
      local Z,G,Y,e,j,C,N,q,b,D;
      local p,r=1900472160;
      local K,o=3529230225;
      local c=w(J);
      local J,m,S,O,B;
      if d==112 then
        O,B=H,d;
        while true do
          local M,sP=z[O];
          if M<103 then
            if M>=51 then
              if M<77 then
                if M<64 then
                  if M<57 then
                    if M<54 then
                      if M>=52 then
                        if M==53 then
                          C=A[P[O]];
                          c[T[O]]=C[4][C[6]][c[a[O]]];
                        else
                          c[a[O]][c[P[O]]]=l[O];
                        end
                      else
                        c[a[O]]=c[P[O]]>=c[T[O]];
                      end
                    else
                      if M<55 then
                        c[P[O]]=c[T[O]]<=a[O];
                      elseif M==56 then
                        c[T[O]]=P[O]^c[a[O]];
                      else
                        c[T[O]]=c[P[O]][a[O]];
                      end
                    end
                  else
                    if M<60 then
                      if M>=58 then
                        if M==59 then
                          local lP,LP,yP=T[O],W(P[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];
                          local zP=W(yP[lP],187638924);
                          yP[lP]=zP;
                          lP,yP=n[5],zP+1;
                          zP=V(lP,yP);
                          local TP,nP;
                          if zP<128 then
                            TP,nP=zP,yP+1;
                          else
                            local JP=V(lP,yP+1);
                            if JP<128 then
                              TP,nP=(zP-128)*128+JP,yP+2;
                            else
                              local HP=V(lP,yP+2);
                              if HP<128 then
                                TP,nP=(zP-128)*16384+(JP-128)+HP*128,yP+3;
                              else
                                local fP=V(lP,yP+3);
                                TP,nP=zP-128+(JP-128)*2097152+(HP-128)*128+fP%128*16384+(fP-fP%128)*2097152,yP+4;
                              end
                            end
                          end
                          yP,zP=LP*16843009,nP+TP;
                          local JP=zP-TP%4;
                          for TP=nP,JP-1,4 do
                            _(lP,TP,(W(X(lP,TP),yP)));
                          end;
                          for yP=JP,zP-1,1 do
                            x(lP,yP,(W(V(lP,yP),LP)));
                          end;
                          T[O]=55;
                          P[O]=57;
                          a[O]=120;
                          z[O]=118;
                        else
                          c[T[O]]=-c[a[O]];
                        end
                      else
                        O=if not(c[P[O]]<=c[T[O]])then a[O]else O;
                      end
                    else
                      if M<62 then
                        if M~=61 then
                          c[a[O]]=n;
                          c[a[O+1]]=a;
                          c[P[O+2]]=z;
                          O+=2;
                        else
                          local lP,LP,yP=a[O],c[T[O]],c[P[O]];
                          local zP,TP=h(LP,4294967295),h(yP,4294967295);
                          local LP,yP,nP,JP=h(zP,65535),F(zP,16),h(TP,65535),F(TP,16);
                          zP=h(LP*nP+k(h(LP*JP+yP*nP,65535),16),4294967295);
                          nP=nil;
                          repeat
                            LP=zP%4294967296;
                            if LP~=LP then
                              nP=0;
                              break;
                            end
                            nP=LP-LP%1;
                          until true;
                          c[lP]=nP;
                        end
                      else
                        if M~=63 then
                          c[a[O]]=c[P[O]]==c[T[O]];
                        else
                          c[P[O]]=v(c[a[O]],c[T[O]]);
                        end
                      end
                    end
                  end
                else
                  if M>=70 then
                    if M<73 then
                      if M>=71 then
                        if M==72 then
                          C,Z,r=a[O],T[O],P[O];
                          N=c[C];
                          I(c,C+1,C+Z,r+1,N);
                        else
                          for lP=T[O],a[O],1 do
                            c[lP]=nil;
                          end;
                        end
                      else
                        c[T[O]]=c[P[O]][c[a[O]]];
                      end
                    else
                      if M<75 then
                        if M==74 then
                          c[T[O]]=W(y[O],c[P[O]]);
                        else
                          c[a[O]](l[O],i(c[P[O]],1,c[P[O]].n));
                        end
                      else
                        if M~=76 then
                          c[T[O]][c[a[O]]]=P[O];
                        else
                          C=A[a[O]];
                          C[4][C[6]]=l[O];
                        end
                      end
                    end
                  else
                    if M<67 then
                      if M>=65 then
                        if M==66 then
                          O=if c[a[O]]then T[O]else P[O];
                        else
                          c[P[O]](c[T[O]],y[O]);
                        end
                      else
                        c[P[O]][l[O]]=y[O];
                      end
                    else
                      if M>=68 then
                        if M==69 then
                          O=if T[O]<c[P[O]]then a[O]else O;
                        else
                          C,Z,r=T[O],P[O],a[O];
                          N=C+Z;
                          S=c[N];
                          m=S.n;
                          Y=Z+m-1;
                          S.n=Y;
                          I(S,1,m,Z,S);
                          I(c,C+1,N-1,1,S);
                          c[C]=E(c[C](i(S,1,S.n)));
                        end
                      else
                        c[T[O]]=s;
                      end
                    end
                  end
                end
              else
                if M>=90 then
                  if M>=96 then
                    if M>=99 then
                      if M>=101 then
                        if M==102 then
                          c[T[O]]();
                        else
                          C,Z,r=T[O],a[O],P[O];
                          N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));
                          I(m,1,r,C,c);
                        end
                      else
                        if M==100 then
                          c[P[O]]=c[T[O]]/a[O];
                        else
                          local lP,LP,yP=T[O],W(P[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];
                          local zP=W(yP[lP],187638924);
                          yP[lP]=zP;
                          yP,lP=n[5],zP+1;
                          zP=V(yP,lP);
                          local TP,nP;
                          if zP<128 then
                            TP,nP=zP,lP+1;
                          else
                            local JP=V(yP,lP+1);
                            if JP<128 then
                              TP,nP=(zP-128)*128+JP,lP+2;
                            else
                              local HP=V(yP,lP+2);
                              if HP<128 then
                                TP,nP=(zP-128)*16384+(JP-128)+HP*128,lP+3;
                              else
                                local fP=V(yP,lP+3);
                                TP,nP=zP-128+(JP-128)*2097152+(HP-128)*128+fP%128*16384+(fP-fP%128)*2097152,lP+4;
                              end
                            end
                          end
                          lP,zP=LP*16843009,nP+TP;
                          local JP=zP-TP%4;
                          for TP=nP,JP-1,4 do
                            _(yP,TP,(W(X(yP,TP),lP)));
                          end;
                          for lP=JP,zP-1,1 do
                            x(yP,lP,(W(V(yP,lP),LP)));
                          end;
                          T[O]=162;
                          P[O]=195;
                          a[O]=16;
                          z[O]=118;
                        end
                      end
                    else
                      if M>=97 then
                        if M==98 then
                          C,Z,r=P[O],{...},a[O];
                          I(Z,1,C-1,r,c);
                          c[r+C-1]=E(Q(C,...));
                        else
                          c[a[O]]=c[P[O]]+T[O];
                        end
                      else
                        c[P[O]][c[a[O]]]=c[T[O]];
                      end
                    end
                  else
                    if M>=93 then
                      if M<94 then
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP=w(LP);
                                I(c,Q,Q+LP-1,1,yP);
                                lP[4]=yP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return y[O];
                      elseif M==95 then
                        c[a[O]][P[O]]=l[O];
                      else
                        sP=D;
                        D,C,Z={[5]=e,[8]=G,[6]=sP,[9]=J},T[O],R(g);
                        Z(s,c[C],c[C+1],c[C+2]);
                        O,J=P[O],Z;
                      end
                    else
                      if M>=91 then
                        if M~=92 then
                          c[T[O]]=c[P[O]]+c[a[O]];
                        else
                          c[a[O]](l[O],f[O]);
                        end
                      else
                        C,Z,r=a[O],P[O],T[O];
                        N,S=C+r-1,C+Z;
                        m=c[S];
                        Y=m.n;
                        b=Z+Y-1;
                        m.n=b;
                        I(m,1,Y,Z,m);
                        I(c,C+1,S-1,1,m);
                        o=E(c[C](i(m,1,m.n)));
                        I(o,1,r,C,c);
                      end
                    end
                  end
                else
                  if M>=83 then
                    if M>=86 then
                      if M<88 then
                        if M==87 then
                          c[T[O]]=c[a[O]]*f[O];
                        else
                          c[P[O]]=c[a[O]]%c[T[O]];
                        end
                      elseif M==89 then
                        c[a[O]]=s[T[O]];
                      else
                        c[T[O]][f[O]]=c[a[O]];
                      end
                    else
                      if M<84 then
                        c[P[O]]=A[a[O]][l[O]];
                      else
                        if M~=85 then
                          O=if not c[T[O]]then a[O]else P[O];
                        else
                          c[a[O]]=v(f[O],c[T[O]]);
                        end
                      end
                    end
                  else
                    if M>=80 then
                      if M<81 then
                        A[a[O]][f[O]]=l[O];
                      elseif M==82 then
                        c[T[O]]=u[y[O]];
                      else
                        c[a[O]]=c[P[O]]==T[O];
                      end
                    else
                      if M<78 then
                        C=a[O];
                        local Q,lP,LP=J();
                        if Q then
                          c[C+1]=lP;
                          c[C+2]=LP;
                          O=P[O];
                        else
                        end
                        Z,r,N=Q,lP,LP;
                      else
                        if M==79 then
                          A[T[O]][c[P[O]]]=y[O];
                        else
                          c[a[O]]=c[T[O]]>f[O];
                        end
                      end
                    end
                  end
                end
              end
            else
              if M<25 then
                if M<12 then
                  if M>=6 then
                    if M<9 then
                      if M>=7 then
                        if M~=8 then
                          c[P[O]]=c[a[O]]/l[O];
                        else
                          c[a[O]]=c[P[O]]>T[O];
                        end
                      else
                        Z,C=(W(P[O],(h(W(p,(h(F(p,29),7))),536870911)))),T[O]+1;
                        for Q=1,a[O],1 do
                          Z=h(W(Z,(k(Z,13))),536870911);
                          Z=W(Z,(F(Z,13)));
                          Z=h(W(Z,(k(Z,14))),536870911);
                          T[C]=W(T[C],(h(F(Z,0),127)));
                          P[C]=W(P[C],(h(F(Z,7),127)));
                          a[C]=W(a[C],(h(F(Z,14),127)));
                          z[C]=W(z[C],(h(F(Z,21),127)));
                          C=C+1;
                        end;
                        z[O]=118;
                      end
                    else
                      if M<10 then
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP,zP=Q+LP-1,w(LP);
                                I(c,Q,yP,1,zP);
                                lP[4]=zP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]](c[T[O]]);
                      elseif M~=11 then
                        c[a[O]]=h(c[T[O]],c[P[O]]);
                      else
                        c[a[O]]=c[T[O]]<=c[P[O]];
                      end
                    end
                  else
                    if M>=3 then
                      if M>=4 then
                        if M~=5 then
                          c[T[O]](c[a[O]]);
                        else
                          c[T[O]]=c[a[O]]*c[P[O]];
                        end
                      else
                        c[T[O]]=f[O]..c[a[O]];
                      end
                    else
                      if M>=1 then
                        if M==2 then
                          Z,C=T[O],a[O]+1;
                          for Q=1,P[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            T[C]=W(T[C],(h(F(Z,0),127)));
                            P[C]=W(P[C],(h(F(Z,7),127)));
                            a[C]=W(a[C],(h(F(Z,14),127)));
                            z[C]=W(z[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          z[O]=118;
                        else
                          O=if not(P[O]<c[T[O]])then a[O]else O;
                        end
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP=w(LP);
                                I(c,Q,Q+LP-1,1,yP);
                                lP[4]=yP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]];
                      end
                    end
                  end
                else
                  if M<18 then
                    if M>=15 then
                      if M>=16 then
                        if M==17 then
                          c[P[O]]=c[a[O]]/c[T[O]];
                        else
                          local Q=P[O];
                          if j then
                            local lP=j[Q];
                            if lP then
                              lP[4]=lP;
                              lP[5]=c[Q];
                              lP[6]=5;
                              j[Q]=nil;
                            end
                          end
                        end
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP,zP=Q+LP,w(LP);
                                I(c,Q,yP-1,1,zP);
                                lP[4]=zP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[T[O]](c[P[O]],c[a[O]]);
                      end
                    else
                      if M<13 then
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP=w(LP);
                                I(c,Q,Q+LP-1,1,yP);
                                lP[4]=yP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]](i(c[a[O]],1,c[a[O]].n));
                      elseif M==14 then
                        C=A[T[O]];
                        C[4][C[6]][c[P[O]]]=c[a[O]];
                      else
                        c[T[O]]=y[O]~=c[P[O]];
                      end
                    end
                  else
                    if M<21 then
                      if M>=19 then
                        if M~=20 then
                          local Q,lP,LP=P[O],c[T[O]];
                          repeat
                            local yP=lP%4294967296;
                            if yP~=yP then
                              LP=0;
                              break;
                            end
                            LP=yP-yP%1;
                          until true;
                          c[Q]=LP;
                        else
                          c[a[O]]=c[T[O]]-c[P[O]];
                        end
                      else
                        c[a[O]]=c[T[O]]>c[P[O]];
                      end
                    else
                      if M<23 then
                        if M==22 then
                          Z,C=(W(P[O],(h(W(K,(h(F(K,29),7))),536870911)))),T[O]+1;
                          for Q=1,a[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            T[C]=W(T[C],(h(F(Z,0),127)));
                            P[C]=W(P[C],(h(F(Z,7),127)));
                            a[C]=W(a[C],(h(F(Z,14),127)));
                            z[C]=W(z[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          z[O]=118;
                        else
                          c[a[O]]=K;
                        end
                      else
                        if M==24 then
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local lP=j[Q];
                                if lP then
                                  lP[4]=lP;
                                  lP[5]=c[Q];
                                  lP[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,lP in t,q,nil do
                              local LP=lP[5];
                              if q then
                                lP=q[Q];
                                if lP then
                                  local yP,zP=Q+LP-1,w(LP);
                                  I(c,Q,yP,1,zP);
                                  lP[4]=zP;
                                  lP[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return;
                        else
                          c[T[O]]=c[a[O]]<P[O];
                        end
                      end
                    end
                  end
                end
              else
                if M<38 then
                  if M<31 then
                    if M>=28 then
                      if M<29 then
                        c[T[O]]=c[a[O]]<c[P[O]];
                      elseif M==30 then
                        c[P[O]]=W(c[T[O]],y[O]);
                      else
                        c[P[O]+c[a[O]]]=c[T[O]];
                      end
                    else
                      if M<26 then
                        c[P[O]]=E(c[T[O]](y[O]));
                      else
                        if M==27 then
                          J+=e;
                          C=if e<=0 then J>=G else J<=G;
                          if C then
                            c[a[O]]=J;
                            O=P[O];
                          else
                          end
                        else
                          c[T[O]]=c[P[O]]+y[O];
                        end
                      end
                    end
                  else
                    if M>=34 then
                      if M>=36 then
                        if M==37 then
                          c[T[O]]=c[a[O]]<=f[O];
                        else
                          c[a[O]]=f[O]+c[T[O]];
                        end
                      elseif M~=35 then
                        A[P[O]][l[O]]=c[a[O]];
                      else
                        c[a[O]][f[O]]=T[O];
                      end
                    else
                      if M<32 then
                        O=if c[P[O]]~=l[O]then a[O]else O;
                      else
                        local Q=O;
                        if M~=33 then
                          c[a[Q]]=h(c[T[Q]],P[Q]);
                        else
                          B=a[Q];
                          O=P[Q]+1;
                          break;
                        end
                      end
                    end
                  end
                else
                  if M<44 then
                    if M>=41 then
                      if M<42 then
                        c[P[O]]=c[a[O]]..l[O];
                      elseif M~=43 then
                        c[T[O]][a[O]]=c[P[O]];
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local lP=j[Q];
                              if lP then
                                lP[4]=lP;
                                lP[5]=c[Q];
                                lP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,lP in t,q,nil do
                            local LP=lP[5];
                            if q then
                              lP=q[Q];
                              if lP then
                                local yP,zP=Q+LP,w(LP);
                                I(c,Q,yP-1,1,zP);
                                lP[4]=zP;
                                lP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[a[O]]();
                      end
                    else
                      if M<39 then
                        C=A[P[O]];
                        c[T[O]]=C[4][C[6]];
                      else
                        if M==40 then
                          local Q,lP,LP=a[O],f[O],l[O];
                          local yP,zP=h(lP,4294967295),h(LP,4294967295);
                          local LP,TP,nP,JP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);
                          zP=h(LP*nP+k(h(LP*JP+TP*nP,65535),16),4294967295);
                          lP=nil;
                          repeat
                            JP=zP%4294967296;
                            if JP~=JP then
                              lP=0;
                              break;
                            end
                            lP=JP-JP%1;
                          until true;
                          c[Q]=lP;
                        else
                          c[P[O]]=c[a[O]](l[O]);
                        end
                      end
                    end
                  else
                    if M>=47 then
                      if M>=49 then
                        if M==50 then
                          c[T[O]]=#c[P[O]];
                        else
                          c[P[O]]=c[a[O]];
                        end
                      else
                        if M==48 then
                          local Q,lP,LP=T[O],c[P[O]],a[O];
                          local yP,zP=h(lP,4294967295),h(LP,4294967295);
                          local TP,nP,JP,HP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);
                          lP=h(TP*JP+k(h(TP*HP+nP*JP,65535),16),4294967295);
                          JP=nil;
                          repeat
                            LP=lP%4294967296;
                            if LP~=LP then
                              JP=0;
                              break;
                            end
                            JP=LP-LP%1;
                          until true;
                          c[Q]=JP;
                        else
                          O=if c[a[O]]==T[O]then P[O]else O;
                        end
                      end
                    else
                      if M>=45 then
                        if M~=46 then
                          c[T[O]]=c[P[O]]%y[O];
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local lP=j[Q];
                                if lP then
                                  lP[4]=lP;
                                  lP[5]=c[Q];
                                  lP[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,lP in t,q,nil do
                              local LP=lP[5];
                              if q then
                                lP=q[Q];
                                if lP then
                                  local yP,zP=Q+LP-1,w(LP);
                                  I(c,Q,yP,1,zP);
                                  lP[4]=zP;
                                  lP[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[T[O]],c[a[O]];
                        end
                      else
                        c[T[O]]=a[O]*c[P[O]];
                      end
                    end
                  end
                end
              end
            end
          else
            if M>=154 then
              if M>=180 then
                if M>=193 then
                  if M<199 then
                    if M<196 then
                      if M>=194 then
                        if M~=195 then
                          c[T[O]]=P[O];
                        else
                          c[T[O]]={};
                        end
                      else
                        O=if c[P[O]]<T[O]then a[O]else O;
                      end
                    else
                      if M>=197 then
                        if M==198 then
                          c[a[O]]=h(c[P[O]],l[O]);
                        else
                          sP=D;
                          D,C={[5]=e,[8]=G,[6]=sP,[9]=J},T[O];
                          e,G=c[C+2]+0,c[C+1]+0;
                          J=c[C]-e;
                          O=P[O];
                        end
                      else
                        c[T[O]]=a[O]+c[P[O]];
                      end
                    end
                  else
                    if M>=202 then
                      if M<204 then
                        if M~=203 then
                          O=if c[T[O]]==f[O]then a[O]else O;
                        else
                          c[T[O]]=P;
                        end
                      else
                        if M~=205 then
                          c[P[O]]=E(c[T[O]]());
                        else
                          c[P[O]]=c[a[O]]();
                        end
                      end
                    else
                      if M<200 then
                        c[P[O]]=W(a[O],c[T[O]]);
                      elseif M~=201 then
                        c[P[O]]=c[T[O]](i(c[a[O]],1,c[a[O]].n));
                      else
                        c[P[O]]=y[O];
                      end
                    end
                  end
                else
                  if M>=186 then
                    if M<189 then
                      if M>=187 then
                        if M==188 then
                          c[T[O]](c[a[O]],i(c[P[O]],1,c[P[O]].n));
                        else
                          c[T[O]](f[O],c[a[O]]);
                        end
                      else
                        c[a[O]][T[O]]=P[O];
                      end
                    else
                      if M<191 then
                        if M~=190 then
                          C=A[a[O]];
                          C[4][C[6]]=c[P[O]];
                        else
                          c[T[O]]=U(c[P[O]]);
                        end
                      else
                        if M==192 then
                          C,Z,r=a[O],T[O],P[O];
                          N,S=c[C],C+Z;
                          m=c[S];
                          I(c,C+1,S-1,r+1,N);
                          I(m,1,m.n,r+Z,N);
                        else
                          c[T[O]](y[O]);
                        end
                      end
                    end
                  else
                    if M>=183 then
                      if M>=184 then
                        if M==185 then
                          c[P[O]]=c[a[O]]*T[O];
                        else
                          c[T[O]]=c[P[O]]>=a[O];
                        end
                      else
                        O=if c[a[O]]~=P[O]then T[O]else O;
                      end
                    else
                      if M<181 then
                        C=a[O];
                        r=C+T[O];
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local sP=j[Q];
                              if sP then
                                sP[4]=sP;
                                sP[5]=c[Q];
                                sP[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,sP in t,q,nil do
                            local lP=sP[5];
                            if q then
                              sP=q[Q];
                              if sP then
                                local LP,yP=Q+lP,w(lP);
                                I(c,Q,LP-1,1,yP);
                                sP[4]=yP;
                                sP[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[C](i(c,C+1,r));
                      elseif M~=182 then
                        c[P[O]]=w(a[O]);
                      else
                        c[T[O]],c[P[O]]=c[a[O]]();
                      end
                    end
                  end
                end
              else
                if M>=167 then
                  if M<173 then
                    if M<170 then
                      if M>=168 then
                        if M==169 then
                          c[a[O]]=A[P[O]][c[T[O]]];
                        else
                          c[T[O]]=T;
                        end
                      else
                        c[P[O]]=p;
                      end
                    else
                      if M>=171 then
                        O=if M==172 then if not(c[T[O]]<c[a[O]])then P[O]else O else if c[a[O]]<c[P[O]]then T[O]else O;
                      else
                        c[a[O]]=T[O]-c[P[O]];
                      end
                    end
                  else
                    if M<176 then
                      if M<174 then
                        C,Z,r,N=T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],P[O];
                        S=C<16384 and 7 or(C<2097152 and 14 or 21);
                        m,Y=F(C,S),h(C,k(1,S)-1);
                        z[O]=W(m,18,(h(F(Z,21),127)));
                        a[O]=W(r,115,(h(F(Z,14),127)));
                        T[O]=W(Y,24,(h(Z,127)));
                        P[O]=W(N,87,(h(F(Z,7),127)));
                        O=O-1;
                      else
                        if M~=175 then
                          O=c[P[O]];
                        else
                          c[a[O]]=W(c[P[O]],c[T[O]]);
                        end
                      end
                    else
                      if M>=178 then
                        if M==179 then
                          c[a[O]]=c[T[O]]//c[P[O]];
                        else
                          c[P[O]]=c[T[O]]~=y[O];
                        end
                      elseif M==177 then
                        c[P[O]]=v(c[a[O]],l[O]);
                      else
                        c[P[O]]=c[T[O]]-a[O];
                      end
                    end
                  end
                else
                  if M<160 then
                    if M>=157 then
                      if M>=158 then
                        if M~=159 then
                          C=A[a[O]];
                          c[P[O]]=C[4][C[6]][l[O]];
                        else
                          c[a[O]]=F(c[T[O]],P[O]);
                        end
                      else
                        C=A[a[O]];
                        C[4][C[6]][f[O]]=c[T[O]];
                      end
                    else
                      if M<155 then
                        O=if c[P[O]]~=c[T[O]]then a[O]else O;
                      else
                        if M~=156 then
                          p=c[a[O]];
                        else
                          c[P[O]]=l[O]==c[a[O]];
                        end
                      end
                    end
                  else
                    if M>=163 then
                      if M<165 then
                        if M~=164 then
                          c[a[O]]=A[P[O]];
                        else
                          O=if c[a[O]]<=T[O]then P[O]else O;
                        end
                      else
                        if M~=166 then
                          local Q,sP,lP=a[O],P[O],n[6];
                          local LP=W(lP[Q],187638924);
                          lP[Q]=LP;
                          lP,Q=n[5],LP+1;
                          LP=V(lP,Q);
                          local yP,zP;
                          if LP<128 then
                            yP,zP=LP,Q+1;
                          else
                            local TP=V(lP,Q+1);
                            if TP<128 then
                              yP,zP=(LP-128)*128+TP,Q+2;
                            else
                              local nP=V(lP,Q+2);
                              if nP<128 then
                                yP,zP=(LP-128)*16384+(TP-128)+nP*128,Q+3;
                              else
                                local JP=V(lP,Q+3);
                                yP,zP=LP-128+(TP-128)*2097152+(nP-128)*128+JP%128*16384+(JP-JP%128)*2097152,Q+4;
                              end
                            end
                          end
                          LP,Q=sP*16843009,zP+yP;
                          local TP=Q-yP%4;
                          for yP=zP,TP-1,4 do
                            _(lP,yP,(W(X(lP,yP),LP)));
                          end;
                          for LP=TP,Q-1,1 do
                            x(lP,LP,(W(V(lP,LP),sP)));
                          end;
                          a[O]=200;
                          P[O]=148;
                          T[O]=142;
                          z[O]=118;
                        else
                          c[P[O]]=c[a[O]]==l[O];
                        end
                      end
                    else
                      if M<161 then
                        c[T[O]]=u[y[O]][f[O]];
                      elseif M~=162 then
                        c[T[O]]=c[P[O]]%a[O];
                      else
                        c[T[O]](c[a[O]],c[P[O]]);
                      end
                    end
                  end
                end
              end
            else
              if M<128 then
                if M>=115 then
                  if M<121 then
                    if M>=118 then
                      if M>=119 then
                        if M==120 then
                          c[a[O]]=E(c[P[O]](i(c[T[O]],1,c[T[O]].n)));
                        else
                          c[a[O]]=not c[T[O]];
                        end
                      end
                    else
                      if M>=116 then
                        if M~=117 then
                          K=c[a[O]];
                        else
                          c[P[O]]=W(c[T[O]],a[O]);
                        end
                      else
                        c[T[O]]=c[P[O]]//a[O];
                      end
                    end
                  else
                    if M<124 then
                      if M>=122 then
                        if M==123 then
                          c[T[O]]=c[P[O]](c[a[O]]);
                        else
                          c[a[O]]=c[T[O]]~=c[P[O]];
                        end
                      else
                        c[a[O]]=c[T[O]]..c[P[O]];
                      end
                    elseif M>=126 then
                      if M~=127 then
                        c[P[O]]=z;
                      else
                        c[a[O]]=c[P[O]]-l[O];
                      end
                    elseif M~=125 then
                      c[a[O]]=n;
                    else
                      s[y[O]]=f[O];
                    end
                  end
                else
                  if M>=109 then
                    if M<112 then
                      if M>=110 then
                        if M==111 then
                          c[P[O]](i(c[a[O]],1,c[a[O]].n));
                        else
                          c[T[O]]=W(f[O],y[O]);
                        end
                      else
                        O=c[a[O]];
                      end
                    else
                      if M<113 then
                        local Q;
                        local sP=l[O];
                        if sP then
                          local lP=#sP/3;
                          if lP>0 then
                            Q={};
                            local LP,yP=j,q;
                            for zP=1,lP,1 do
                              local lP=(zP-1)*3;
                              local TP,nP=sP[lP+3],sP[lP+2];
                              if TP==2 then
                                LP=if not LP then{}else LP;
                                local JP=LP[nP];
                                if not JP then
                                  JP={[4]=c,[6]=nP};
                                  LP[nP]=JP;
                                else
                                end
                                Q[zP]=JP;
                              else
                                if TP==1 then
                                  Q[zP]=c[nP];
                                else
                                  if TP==3 then
                                    Q[zP]=A[nP];
                                  else
                                    if TP==0 then
                                      yP=if not yP then{}else yP;
                                      local TP=yP[nP];
                                      if not TP then
                                        TP={[5]=sP[lP+1],[6]=nP,[4]=c};
                                        yP[nP]=TP;
                                      else
                                      end
                                      Q[zP]=TP;
                                    else
                                    end
                                  end
                                end
                              end
                            end;
                            j,q=LP,yP;
                          else
                          end
                        else
                        end
                        c[P[O]]=y[O](nil,Q);
                        C=Q;
                      else
                        if M~=114 then
                          O=if T[O]<=c[a[O]]then P[O]else O;
                        else
                          c[T[O]]=A[P[O]][a[O]];
                        end
                      end
                    end
                  else
                    if M>=106 then
                      if M>=107 then
                        if M==108 then
                          c[a[O]]=h(f[O],c[T[O]]);
                        else
                          c[T[O]]=P[O];
                          c[T[O+1]]=P[O+1];
                          c[T[O+2]]=P[O+2];
                          c[T[O+3]]=P[O+3];
                          O+=3;
                        end
                      else
                        local Q,sP,lP=T[O],a[O],c[P[O]];
                        local LP,yP=h(sP,4294967295),h(lP,4294967295);
                        local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);
                        sP=h(lP*TP+k(h(lP*nP+zP*TP,65535),16),4294967295);
                        TP=nil;
                        repeat
                          yP=sP%4294967296;
                          if yP~=yP then
                            TP=0;
                            break;
                          end
                          TP=yP-yP%1;
                        until true;
                        c[Q]=TP;
                      end
                    else
                      if M>=104 then
                        if M==105 then
                          C,Z,r,N=P[O],T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O];
                          S=C<2097152 and 7 or 14;
                          m,Y=h(C,k(1,S)-1),F(C,S);
                          T[O]=W(Z,20,(h(r,127)));
                          z[O]=W(Y,86,(h(F(r,21),127)));
                          a[O]=W(N,73,(h(F(r,14),127)));
                          P[O]=W(m,95,(h(F(r,7),127)));
                          O=O-1;
                        else
                          c[a[O]]=E(c[P[O]](c[T[O]]));
                        end
                      else
                        c[a[O]]=f[O]+l[O];
                      end
                    end
                  end
                end
              else
                if M>=141 then
                  if M<147 then
                    if M<144 then
                      if M<142 then
                        C,Z=a[O],c[P[O]];
                        c[C+1]=Z;
                        c[C]=Z[l[O]];
                      else
                        if M==143 then
                          c[P[O]]=c[T[O]]~=a[O];
                        else
                          C,Z,r=a[O],P[O],T[O];
                          N=C+Z;
                          c[C]=E(c[C](i(c,C+1,N)));
                        end
                      end
                    else
                      if M<145 then
                        O=if c[a[O]]<f[O]then T[O]else O;
                      else
                        if M~=146 then
                          O=if not(c[P[O]]<T[O])then a[O]else O;
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local sP=j[Q];
                                if sP then
                                  sP[4]=sP;
                                  sP[5]=c[Q];
                                  sP[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,sP in t,q,nil do
                              local lP=sP[5];
                              if q then
                                sP=q[Q];
                                if sP then
                                  local LP=w(lP);
                                  I(c,Q,Q+lP-1,1,LP);
                                  sP[4]=LP;
                                  sP[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[P[O]](y[O],i(c[T[O]],1,c[T[O]].n));
                        end
                      end
                    end
                  else
                    if M<150 then
                      if M<148 then
                        A[a[O]][c[T[O]]]=c[P[O]];
                      elseif M==149 then
                        c[a[O]]=a;
                      else
                        c[a[O]]=h(T[O],c[P[O]]);
                      end
                    else
                      if M<152 then
                        if M==151 then
                          c[T[O]]=k(c[P[O]],a[O]);
                        else
                          C,Z={...},a[O];
                          I(C,1,P[O],Z,c);
                        end
                      else
                        if M~=153 then
                          c[a[O]]=f[O]*c[T[O]];
                        else
                          O=T[O];
                        end
                      end
                    end
                  end
                else
                  if M<134 then
                    if M<131 then
                      if M<129 then
                        C=c[T[O]];
                        c[P[O]]=E(i(C,a[O],C.n));
                      else
                        if M~=130 then
                          c[P[O]]=c;
                        else
                          C=A[P[O]];
                          C[4][C[6]][c[T[O]]]=y[O];
                        end
                      end
                    else
                      if M<132 then
                        s[P[O]]=c[a[O]];
                      elseif M==133 then
                        local Q,sP,lP=T[O],y[O],c[P[O]];
                        local LP,yP=h(sP,4294967295),h(lP,4294967295);
                        local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);
                        yP=h(lP*TP+k(h(lP*nP+zP*TP,65535),16),4294967295);
                        sP=nil;
                        repeat
                          TP=yP%4294967296;
                          if TP~=TP then
                            sP=0;
                            break;
                          end
                          sP=TP-TP%1;
                        until true;
                        c[Q]=sP;
                      else
                        c[P[O]]=v(T[O],c[a[O]]);
                      end
                    end
                  else
                    if M>=137 then
                      if M>=139 then
                        if M==140 then
                          J,G=D[9],D[8];
                          e,D=D[5],D[6];
                        else
                          A[T[O]][y[O]]=P[O];
                        end
                      else
                        if M~=138 then
                          O=if not(c[T[O]]<=a[O])then P[O]else O;
                        else
                          c[T[O]]=s[f[O]];
                        end
                      end
                    else
                      if M<135 then
                        O=if c[T[O]]==c[P[O]]then a[O]else O;
                      else
                        if M==136 then
                          c[T[O]]=c[P[O]][y[O]];
                        else
                          c[a[O]]=c[P[O]]<l[O];
                        end
                      end
                    end
                  end
                end
              end
            end
          end
          O=O+1;
        end;
      else
        O,B=H,d;
      end
      if B==139 then
        while true do
          local H,d=P[O];
          if H>=99 then
            if H<149 then
              if H<124 then
                if H<111 then
                  if H>=105 then
                    if H>=108 then
                      if H>=109 then
                        if H==110 then
                          C,Z,r=a[O],z[O],T[O];
                          N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));
                          I(m,1,r,C,c);
                        else
                          C=z[O];
                          r=C+T[O];
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP=w(sP);
                                  I(c,Q,Q+sP-1,1,lP);
                                  M[4]=lP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[C](i(c,C+1,r));
                        end
                      else
                        c[a[O]]=E(c[z[O]](c[T[O]]));
                      end
                    else
                      if H>=106 then
                        if H==107 then
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP,LP=Q+sP,w(sP);
                                  I(c,Q,lP-1,1,LP);
                                  M[4]=LP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[T[O]](i(c[z[O]],1,c[z[O]].n));
                        else
                          c[a[O]]=l[O]..c[z[O]];
                        end
                      else
                        J,G,e=D[9],D[8],D[5];
                        D=D[6];
                      end
                    end
                  else
                    if H>=102 then
                      if H<103 then
                        c[a[O]]=l[O]-c[z[O]];
                      elseif H~=104 then
                        c[a[O]][z[O]]=l[O];
                      else
                        c[a[O]]=c[T[O]]-z[O];
                      end
                    elseif H>=100 then
                      if H==101 then
                        c[a[O]]=w(T[O]);
                      else
                        c[z[O]][y[O]]=c[T[O]];
                      end
                    else
                      c[a[O]]=c[z[O]]*T[O];
                    end
                  end
                else
                  if H<117 then
                    if H<114 then
                      if H>=112 then
                        if H~=113 then
                          c[a[O]]=c[z[O]]*c[T[O]];
                        else
                          c[T[O]](y[O]);
                        end
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local M=j[Q];
                              if M then
                                M[4]=M;
                                M[5]=c[Q];
                                M[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,M in t,q,nil do
                            local sP=M[5];
                            if q then
                              M=q[Q];
                              if M then
                                local lP,LP=Q+sP-1,w(sP);
                                I(c,Q,lP,1,LP);
                                M[4]=LP;
                                M[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[a[O]](c[z[O]]);
                      end
                    else
                      if H>=115 then
                        if H~=116 then
                          C=A[a[O]];
                          c[T[O]]=C[4][C[6]][c[z[O]]];
                        else
                          O=if a[O]<c[z[O]]then T[O]else O;
                        end
                      else
                        c[T[O]]=c[z[O]]();
                      end
                    end
                  else
                    if H>=120 then
                      if H<122 then
                        if H==121 then
                          c[z[O]+c[a[O]]]=c[T[O]];
                        else
                          c[z[O]]=c[T[O]][a[O]];
                        end
                      elseif H~=123 then
                        s[T[O]]=c[z[O]];
                      else
                        c[a[O]]=z;
                      end
                    else
                      if H<118 then
                        c[z[O]][l[O]]=y[O];
                      else
                        if H==119 then
                          c[T[O]]=c[z[O]]<=y[O];
                        else
                          O=if not(a[O]<=c[T[O]])then z[O]else O;
                        end
                      end
                    end
                  end
                end
              else
                if H>=136 then
                  if H>=142 then
                    if H>=145 then
                      if H<147 then
                        if H~=146 then
                          O=if c[z[O]]<l[O]then a[O]else O;
                        else
                          c[T[O]]=c[z[O]](c[a[O]]);
                        end
                      else
                        if H==148 then
                          Z,C=z[O],a[O]+1;
                          for Q=1,T[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            T[C]=W(T[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            z[C]=W(z[C],(h(F(Z,14),127)));
                            P[C]=W(P[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          P[O]=44;
                        else
                          local Q,M,sP=T[O],W(a[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];
                          local lP=W(sP[Q],187638924);
                          sP[Q]=lP;
                          sP,Q=n[5],lP+1;
                          lP=V(sP,Q);
                          local LP,yP;
                          if lP<128 then
                            LP,yP=lP,Q+1;
                          else
                            local zP=V(sP,Q+1);
                            if zP<128 then
                              LP,yP=(lP-128)*128+zP,Q+2;
                            else
                              local TP=V(sP,Q+2);
                              if TP<128 then
                                LP,yP=(lP-128)*16384+(zP-128)+TP*128,Q+3;
                              else
                                local nP=V(sP,Q+3);
                                LP,yP=lP-128+(zP-128)*2097152+(TP-128)*128+nP%128*16384+(nP-nP%128)*2097152,Q+4;
                              end
                            end
                          end
                          Q,lP=M*16843009,yP+LP;
                          local zP=lP-LP%4;
                          for LP=yP,zP-1,4 do
                            _(sP,LP,(W(X(sP,LP),Q)));
                          end;
                          for Q=zP,lP-1,1 do
                            x(sP,Q,(W(V(sP,Q),M)));
                          end;
                          T[O]=84;
                          a[O]=187;
                          z[O]=209;
                          P[O]=44;
                        end
                      end
                    else
                      if H<143 then
                        c[T[O]]=z[O];
                      elseif H==144 then
                        c[T[O]](c[a[O]],i(c[z[O]],1,c[z[O]].n));
                      else
                        c[z[O]]=W(c[T[O]],c[a[O]]);
                      end
                    end
                  else
                    if H<139 then
                      if H<137 then
                        C=T[O];
                        local Q,M,sP=J();
                        if Q then
                          c[C+1]=M;
                          c[C+2]=sP;
                          O=a[O];
                        else
                        end
                        Z,r,N=Q,M,sP;
                      else
                        if H~=138 then
                          O=if c[z[O]]<=c[T[O]]then a[O]else O;
                        else
                          c[z[O]](l[O],i(c[a[O]],1,c[a[O]].n));
                        end
                      end
                    else
                      if H<140 then
                        c[z[O]]=c[T[O]]<=a[O];
                      elseif H~=141 then
                        c[a[O]]=c[z[O]]<c[T[O]];
                      else
                        c[z[O]]=c[T[O]]/a[O];
                      end
                    end
                  end
                else
                  if H<130 then
                    if H<127 then
                      if H>=125 then
                        if H==126 then
                          c[z[O]]=A[a[O]];
                        else
                          c[a[O]]=c[T[O]]>=c[z[O]];
                        end
                      else
                        c[a[O]]=c[T[O]]==z[O];
                      end
                    else
                      if H<128 then
                        O=if not(c[z[O]]<c[a[O]])then T[O]else O;
                      else
                        if H~=129 then
                          c[T[O]]=W(a[O],c[z[O]]);
                        else
                          C,Z,r=T[O],a[O],z[O];
                          N=C+Z;
                          S=c[N];
                          m=S.n;
                          Y=Z+m-1;
                          S.n=Y;
                          I(S,1,m,Z,S);
                          I(c,C+1,N-1,1,S);
                          c[C]=E(c[C](i(S,1,S.n)));
                        end
                      end
                    end
                  else
                    if H>=133 then
                      if H>=134 then
                        if H~=135 then
                          O=if c[z[O]]then a[O]else T[O];
                        else
                          local Q,M,sP=z[O],c[T[O]],c[a[O]];
                          local lP,LP=h(M,4294967295),h(sP,4294967295);
                          local M,yP,zP,TP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                          sP=h(M*zP+k(h(M*TP+yP*zP,65535),16),4294967295);
                          LP=nil;
                          repeat
                            zP=sP%4294967296;
                            if zP~=zP then
                              LP=0;
                              break;
                            end
                            LP=zP-zP%1;
                          until true;
                          c[Q]=LP;
                        end
                      else
                        c[T[O]](y[O],L[O]);
                      end
                    else
                      if H>=131 then
                        if H==132 then
                          c[z[O]]=c[a[O]](i(c[T[O]],1,c[T[O]].n));
                        else
                          c[T[O]]=c[a[O]]>=L[O];
                        end
                      else
                        d=D;
                        D,C,Z={[5]=e,[8]=G,[6]=d,[9]=J},z[O],R(g);
                        Z(s,c[C],c[C+1],c[C+2]);
                        O,J=T[O],Z;
                      end
                    end
                  end
                end
              end
            else
              if H<174 then
                if H<161 then
                  local Q=O;
                  if H>=155 then
                    if H<158 then
                      if H<156 then
                        c[T[Q]]=L[Q];
                      elseif H~=157 then
                        c[T[Q]]=c[z[Q]]==y[Q];
                      else
                        c[z[Q]]=y[Q]+l[Q];
                      end
                    else
                      if H>=159 then
                        if H==160 then
                          c[z[Q]]=W(y[Q],l[Q]);
                        else
                          c[z[Q]]=h(l[Q],c[a[Q]]);
                        end
                      else
                        C=A[z[Q]];
                        C[4][C[6]]=c[a[Q]];
                      end
                    end
                  else
                    if H<152 then
                      if H>=150 then
                        if H==151 then
                          C,Z=z[Q],c[a[Q]];
                          c[C+1]=Z;
                          c[C]=Z[l[Q]];
                        else
                          c[T[Q]]=a[Q]==c[z[Q]];
                        end
                      else
                        if j then
                          for M in t,j,nil do
                            if j then
                              local sP=j[M];
                              if sP then
                                sP[4]=sP;
                                sP[5]=c[M];
                                sP[6]=5;
                                j[M]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for M,sP in t,q,nil do
                            local lP=sP[5];
                            if q then
                              sP=q[M];
                              if sP then
                                local LP,yP=M+lP-1,w(lP);
                                I(c,M,LP,1,yP);
                                sP[4]=yP;
                                sP[6]=1;
                                q[M]=nil;
                              end
                            end
                          end;
                        end
                        return c[z[Q]](c[T[Q]],i(c[a[Q]],1,c[a[Q]].n));
                      end
                    else
                      if H>=153 then
                        if H~=154 then
                          B=a[Q];
                          O=z[Q]+1;
                          break;
                        else
                          c[T[Q]]=c[z[Q]];
                        end
                      else
                        c[T[Q]]=c[a[Q]]>=z[Q];
                      end
                    end
                  end
                else
                  if H<167 then
                    if H>=164 then
                      if H>=165 then
                        if H==166 then
                          c[T[O]]=W(c[a[O]],z[O]);
                        else
                          local Q,M,sP=T[O],W(a[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];
                          local lP=W(sP[Q],187638924);
                          sP[Q]=lP;
                          sP,Q=n[5],lP+1;
                          lP=V(sP,Q);
                          local LP,yP;
                          if lP<128 then
                            LP,yP=lP,Q+1;
                          else
                            local zP=V(sP,Q+1);
                            if zP<128 then
                              LP,yP=(lP-128)*128+zP,Q+2;
                            else
                              local TP=V(sP,Q+2);
                              if TP<128 then
                                LP,yP=(lP-128)*16384+(zP-128)+TP*128,Q+3;
                              else
                                local nP=V(sP,Q+3);
                                LP,yP=lP-128+(zP-128)*2097152+(TP-128)*128+nP%128*16384+(nP-nP%128)*2097152,Q+4;
                              end
                            end
                          end
                          Q,lP=M*16843009,yP+LP;
                          local zP=lP-LP%4;
                          for LP=yP,zP-1,4 do
                            _(sP,LP,(W(X(sP,LP),Q)));
                          end;
                          for Q=zP,lP-1,1 do
                            x(sP,Q,(W(V(sP,Q),M)));
                          end;
                          T[O]=139;
                          a[O]=137;
                          z[O]=38;
                          P[O]=44;
                        end
                      else
                        c[z[O]]=c[T[O]]/y[O];
                      end
                    else
                      if H<162 then
                        local Q,M,sP=a[O],c[z[O]],l[O];
                        local lP,LP=h(M,4294967295),h(sP,4294967295);
                        local sP,yP,zP,TP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                        lP=h(sP*zP+k(h(sP*TP+yP*zP,65535),16),4294967295);
                        M=nil;
                        repeat
                          sP=lP%4294967296;
                          if sP~=sP then
                            M=0;
                            break;
                          end
                          M=sP-sP%1;
                        until true;
                        c[Q]=M;
                      else
                        if H==163 then
                          O=if T[O]<=c[z[O]]then a[O]else O;
                        else
                          A[a[O]][c[T[O]]]=c[z[O]];
                        end
                      end
                    end
                  else
                    if H>=170 then
                      if H<172 then
                        if H==171 then
                          c[T[O]]=k(c[z[O]],a[O]);
                        else
                          c[z[O]]=u[y[O]];
                        end
                      else
                        if H==173 then
                          c[T[O]]=c[a[O]]~=c[z[O]];
                        else
                          O=if c[a[O]]==c[T[O]]then z[O]else O;
                        end
                      end
                    else
                      if H>=168 then
                        if H~=169 then
                          c[z[O]]=h(c[T[O]],a[O]);
                        else
                          c[T[O]]=y[O]+c[z[O]];
                        end
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local M=j[Q];
                              if M then
                                M[4]=M;
                                M[5]=c[Q];
                                M[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,M in t,q,nil do
                            local sP=M[5];
                            if q then
                              M=q[Q];
                              if M then
                                local lP=w(sP);
                                I(c,Q,Q+sP-1,1,lP);
                                M[4]=lP;
                                M[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[a[O]](c[z[O]],l[O]);
                      end
                    end
                  end
                end
              else
                if H>=186 then
                  if H<192 then
                    if H>=189 then
                      if H<190 then
                        c[a[O]]=c[z[O]]%T[O];
                      else
                        if H==191 then
                          O=if not(L[O]<c[a[O]])then T[O]else O;
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP=w(sP);
                                  I(c,Q,Q+sP-1,1,lP);
                                  M[4]=lP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return L[O],c[a[O]];
                        end
                      end
                    else
                      if H>=187 then
                        if H~=188 then
                          C,Z,r=a[O],z[O],T[O];
                          N=c[C];
                          I(c,C+1,C+Z,r+1,N);
                        else
                          C,Z,r,N=z[O],T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O];
                          S=Z<16384 and 7 or(Z<2097152 and 14 or 21);
                          m,Y=h(Z,k(1,S)-1),F(Z,S);
                          z[O]=W(C,97,(h(F(r,14),127)));
                          a[O]=W(N,120,(h(F(r,7),127)));
                          P[O]=W(Y,123,(h(F(r,21),127)));
                          T[O]=W(m,59,(h(r,127)));
                          O=O-1;
                        end
                      else
                        c[z[O]]=c[T[O]]<y[O];
                      end
                    end
                  else
                    if H<195 then
                      if H>=193 then
                        if H~=194 then
                          O=if not c[T[O]]then a[O]else z[O];
                        else
                          A[z[O]][l[O]]=a[O];
                        end
                      else
                        c[a[O]]=v(l[O],c[z[O]]);
                      end
                    else
                      if H<197 then
                        if H~=196 then
                          c[a[O]]=c[z[O]]-l[O];
                        else
                          O=c[a[O]];
                        end
                      else
                        if H~=198 then
                          A[T[O]][c[a[O]]]=L[O];
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP=w(sP);
                                  I(c,Q,Q+sP-1,1,lP);
                                  M[4]=lP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return l[O];
                        end
                      end
                    end
                  end
                else
                  if H>=180 then
                    if H<183 then
                      if H>=181 then
                        if H~=182 then
                          c[T[O]]=c[a[O]]..c[z[O]];
                        else
                          p=c[z[O]];
                        end
                      else
                        O=if c[a[O]]<=T[O]then z[O]else O;
                      end
                    else
                      if H<184 then
                        c[a[O]]=c[z[O]]*l[O];
                      elseif H~=185 then
                        c[a[O]](i(c[T[O]],1,c[T[O]].n));
                      else
                        c[T[O]][c[z[O]]]=y[O];
                      end
                    end
                  else
                    if H>=177 then
                      if H>=178 then
                        if H==179 then
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP=w(sP);
                                  I(c,Q,Q+sP-1,1,lP);
                                  M[4]=lP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return;
                        else
                          local Q,M,sP=T[O],c[a[O]];
                          repeat
                            local lP=M%4294967296;
                            if lP~=lP then
                              sP=0;
                              break;
                            end
                            sP=lP-lP%1;
                          until true;
                          c[Q]=sP;
                        end
                      else
                        c[z[O]]=c[a[O]]/c[T[O]];
                      end
                    elseif H>=175 then
                      if H==176 then
                        local Q,M,sP=a[O],L[O],c[T[O]];
                        local lP,LP=h(M,4294967295),h(sP,4294967295);
                        local M,sP,yP,zP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                        lP=h(M*yP+k(h(M*zP+sP*yP,65535),16),4294967295);
                        sP=nil;
                        repeat
                          yP=lP%4294967296;
                          if yP~=yP then
                            sP=0;
                            break;
                          end
                          sP=yP-yP%1;
                        until true;
                        c[Q]=sP;
                      else
                        c[z[O]]=n;
                      end
                    else
                      c[a[O]]=c[T[O]]>z[O];
                    end
                  end
                end
              end
            end
          else
            if H<49 then
              if H<24 then
                if H<12 then
                  if H<6 then
                    if H>=3 then
                      if H<4 then
                        local Q,M,sP=T[O],c[a[O]],z[O];
                        local lP,LP=h(M,4294967295),h(sP,4294967295);
                        local yP,zP,TP,nP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                        sP=h(yP*TP+k(h(yP*nP+zP*TP,65535),16),4294967295);
                        LP=nil;
                        repeat
                          M=sP%4294967296;
                          if M~=M then
                            LP=0;
                            break;
                          end
                          LP=M-M%1;
                        until true;
                        c[Q]=LP;
                      else
                        if H~=5 then
                          Z,C=(W(a[O],(h(W(p,(h(F(p,29),7))),536870911)))),T[O]+1;
                          for Q=1,z[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            T[C]=W(T[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            z[C]=W(z[C],(h(F(Z,14),127)));
                            P[C]=W(P[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          P[O]=44;
                        else
                          c[a[O]]=c[T[O]]~=L[O];
                        end
                      end
                    else
                      if H>=1 then
                        if H==2 then
                          c[a[O]]=c[z[O]]+T[O];
                        else
                          c[T[O]]=W(y[O],c[z[O]]);
                        end
                      else
                        O=c[T[O]];
                      end
                    end
                  else
                    if H>=9 then
                      if H<10 then
                        K=c[z[O]];
                      else
                        if H~=11 then
                          O=if c[z[O]]<a[O]then T[O]else O;
                        else
                          c[T[O]](L[O],c[a[O]]);
                        end
                      end
                    else
                      if H<7 then
                        c[z[O]]=c[a[O]]%l[O];
                      else
                        if H==8 then
                          d=D;
                          D,C={[5]=e,[8]=G,[6]=d,[9]=J},z[O];
                          e,G=c[C+2]+0,c[C+1]+0;
                          J=c[C]-e;
                          O=T[O];
                        else
                          C,Z,r=T[O],a[O],z[O];
                          N=C+Z;
                          c[C]=E(c[C](i(c,C+1,N)));
                        end
                      end
                    end
                  end
                else
                  if H>=18 then
                    if H>=21 then
                      if H>=22 then
                        if H==23 then
                          c[z[O]]=U(c[T[O]]);
                        else
                          c[T[O]]=A[z[O]][a[O]];
                        end
                      else
                        c[T[O]]=h(a[O],c[z[O]]);
                      end
                    elseif H>=19 then
                      if H==20 then
                        c[T[O]]=P;
                      else
                        c[T[O]]=a[O]^c[z[O]];
                      end
                    else
                      c[T[O]]=c[a[O]]+L[O];
                    end
                  else
                    if H>=15 then
                      if H>=16 then
                        if H~=17 then
                          c[T[O]]=T;
                        else
                          c[T[O]]=c[z[O]]<a[O];
                        end
                      else
                        c[z[O]]=c[T[O]]>c[a[O]];
                      end
                    else
                      if H>=13 then
                        if H==14 then
                          O=if c[a[O]]==T[O]then z[O]else O;
                        else
                          c[z[O]]=F(c[a[O]],T[O]);
                        end
                      else
                        c[z[O]]=c[T[O]]+c[a[O]];
                      end
                    end
                  end
                end
              else
                if H>=36 then
                  if H>=42 then
                    if H>=45 then
                      if H>=47 then
                        if H~=48 then
                          if j then
                            for d in t,j,nil do
                              if j then
                                local Q=j[d];
                                if Q then
                                  Q[4]=Q;
                                  Q[5]=c[d];
                                  Q[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,Q in t,q,nil do
                              local M=Q[5];
                              if q then
                                Q=q[d];
                                if Q then
                                  local sP=w(M);
                                  I(c,d,d+M-1,1,sP);
                                  Q[4]=sP;
                                  Q[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return c[T[O]];
                        else
                          c[z[O]]=c[a[O]]-c[T[O]];
                        end
                      else
                        if H~=46 then
                          O=if c[T[O]]==y[O]then z[O]else O;
                        else
                          c[a[O]](c[z[O]],c[T[O]]);
                        end
                      end
                    else
                      if H>=43 then
                        if not(H==44) then
                          A[z[O]][y[O]]=c[T[O]];
                        end
                      else
                        O=if c[a[O]]<c[T[O]]then z[O]else O;
                      end
                    end
                  else
                    if H<39 then
                      if H<37 then
                        C=A[T[O]];
                        C[4][C[6]][c[z[O]]]=a[O];
                      else
                        if H==38 then
                          local d,Q,M=a[O],T[O],c[z[O]];
                          local sP,lP=h(Q,4294967295),h(M,4294967295);
                          local Q,M,LP,yP=h(sP,65535),F(sP,16),h(lP,65535),F(lP,16);
                          lP=h(Q*LP+k(h(Q*yP+M*LP,65535),16),4294967295);
                          yP=nil;
                          repeat
                            sP=lP%4294967296;
                            if sP~=sP then
                              yP=0;
                              break;
                            end
                            yP=sP-sP%1;
                          until true;
                          c[d]=yP;
                        else
                          c[a[O]][T[O]]=c[z[O]];
                        end
                      end
                    else
                      if H<40 then
                        c[a[O]]=c[T[O]]//z[O];
                      elseif H~=41 then
                        c[z[O]]=c[T[O]]..y[O];
                      else
                        c[T[O]]=y[O]*c[z[O]];
                      end
                    end
                  end
                else
                  if H>=30 then
                    if H<33 then
                      if H<31 then
                        local d,Q,M=T[O],L[O],y[O];
                        local sP,lP=h(Q,4294967295),h(M,4294967295);
                        local Q,LP,yP,zP=h(sP,65535),F(sP,16),h(lP,65535),F(lP,16);
                        M=h(Q*yP+k(h(Q*zP+LP*yP,65535),16),4294967295);
                        zP=nil;
                        repeat
                          LP=M%4294967296;
                          if LP~=LP then
                            zP=0;
                            break;
                          end
                          zP=LP-LP%1;
                        until true;
                        c[d]=zP;
                      else
                        if H==32 then
                          C=A[z[O]];
                          C[4][C[6]]=y[O];
                        else
                          c[T[O]]=s;
                        end
                      end
                    else
                      if H>=34 then
                        if H==35 then
                          c[T[O]][c[z[O]]]=c[a[O]];
                        else
                          c[z[O]]=T[O]*c[a[O]];
                        end
                      else
                        c[z[O]]=A[T[O]][c[a[O]]];
                      end
                    end
                  else
                    if H<27 then
                      if H<25 then
                        c[z[O]]=h(c[a[O]],l[O]);
                      else
                        if H==26 then
                          C=A[T[O]];
                          C[4][C[6]][c[a[O]]]=c[z[O]];
                        else
                          c[T[O]]=k(c[a[O]],c[z[O]]);
                        end
                      end
                    else
                      if H>=28 then
                        if H~=29 then
                          c[T[O]]=h(c[a[O]],c[z[O]]);
                        else
                          c[z[O]]=a;
                        end
                      else
                        O=T[O];
                      end
                    end
                  end
                end
              end
            else
              if H>=74 then
                if H>=86 then
                  if H>=92 then
                    if H>=95 then
                      if H>=97 then
                        if H==98 then
                          c[z[O]]=#c[a[O]];
                        else
                          c[z[O]]={};
                        end
                      else
                        if H==96 then
                          c[a[O]]=u[L[O]][l[O]];
                        else
                          J+=e;
                          C=if e<=0 then J>=G else J<=G;
                          if C then
                            c[a[O]]=J;
                            O=z[O];
                          else
                          end
                        end
                      end
                    else
                      if H>=93 then
                        if H~=94 then
                          c[z[O]]=n;
                          c[z[O+1]]=a;
                          c[a[O+2]]=z;
                          O+=2;
                        else
                          c[a[O]]=c[z[O]]>l[O];
                        end
                      else
                        local d;
                        local Q=L[O];
                        if Q then
                          local M=#Q/3;
                          if M>0 then
                            d={};
                            local sP,lP=j,q;
                            for LP=1,M,1 do
                              local M=(LP-1)*3;
                              local yP,zP=Q[M+3],Q[M+2];
                              if yP==2 then
                                sP=if not sP then{}else sP;
                                local TP=sP[zP];
                                if not TP then
                                  TP={[4]=c,[6]=zP};
                                  sP[zP]=TP;
                                else
                                end
                                d[LP]=TP;
                              else
                                if yP==1 then
                                  d[LP]=c[zP];
                                else
                                  if yP==3 then
                                    d[LP]=A[zP];
                                  else
                                    if yP==0 then
                                      lP=if not lP then{}else lP;
                                      local yP=lP[zP];
                                      if not yP then
                                        yP={[5]=Q[M+1],[6]=zP,[4]=c};
                                        lP[zP]=yP;
                                      else
                                      end
                                      d[LP]=yP;
                                    else
                                    end
                                  end
                                end
                              end
                            end;
                            j,q=sP,lP;
                          else
                          end
                        else
                        end
                        c[T[O]]=y[O](nil,d);
                        C=d;
                      end
                    end
                  else
                    if H<89 then
                      if H>=87 then
                        if H==88 then
                          local d=a[O];
                          if j then
                            local Q=j[d];
                            if Q then
                              Q[4]=Q;
                              Q[5]=c[d];
                              Q[6]=5;
                              j[d]=nil;
                            end
                          end
                        else
                          c[a[O]]=A[z[O]][l[O]];
                        end
                      else
                        c[z[O]]=c[a[O]][l[O]];
                      end
                    else
                      if H>=90 then
                        if H==91 then
                          c[T[O]]=c[a[O]]<=c[z[O]];
                        else
                          C=T[O];
                          Z,r,N,S=c[C],c[C+1],c[C+2],c[C+3];
                          c[C]=Z(r,N,S);
                        end
                      else
                        c[T[O]]=-c[a[O]];
                      end
                    end
                  end
                else
                  if H>=80 then
                    if H<83 then
                      if H<81 then
                        O=if c[a[O]]~=T[O]then z[O]else O;
                      else
                        if H==82 then
                          c[a[O]]=c[z[O]]~=T[O];
                        else
                          c[T[O]]=s[a[O]];
                        end
                      end
                    else
                      if H>=84 then
                        if H==85 then
                          O=if c[z[O]]~=c[T[O]]then a[O]else O;
                        else
                          c[a[O]]=p;
                        end
                      else
                        O=if c[T[O]]~=y[O]then z[O]else O;
                      end
                    end
                  else
                    if H<77 then
                      if H>=75 then
                        if H==76 then
                          c[T[O]][c[z[O]]]=a[O];
                        else
                          c[z[O]]=c[a[O]][c[T[O]]];
                        end
                      else
                        c[T[O]]=v(a[O],c[z[O]]);
                      end
                    else
                      if H<78 then
                        C=A[T[O]];
                        c[z[O]]=C[4][C[6]][y[O]];
                      else
                        if H~=79 then
                          c[T[O]]=not c[a[O]];
                        else
                          c[z[O]](c[T[O]]);
                        end
                      end
                    end
                  end
                end
              else
                if H<61 then
                  if H>=55 then
                    if H<58 then
                      if H<56 then
                        A[a[O]][l[O]]=L[O];
                      elseif H~=57 then
                        c[z[O]]=T[O]%c[a[O]];
                      else
                        c[a[O]]();
                      end
                    elseif H<59 then
                      c[T[O]]=c[a[O]]%c[z[O]];
                    elseif H~=60 then
                      c[z[O]][y[O]]=T[O];
                    else
                      c[T[O]]=a[O]+c[z[O]];
                    end
                  else
                    if H<52 then
                      if H<50 then
                        c[a[O]]=z[O]-c[T[O]];
                      else
                        if H~=51 then
                          C=T[O];
                          Z,r,N=c[C],c[C+1],c[C+2];
                          c[C]=Z(r,N);
                        else
                          C=A[a[O]];
                          c[z[O]]=C[4][C[6]];
                        end
                      end
                    else
                      if H>=53 then
                        if H~=54 then
                          c[T[O]]=W(c[z[O]],y[O]);
                        else
                          c[z[O]]=K;
                        end
                      else
                        O=if not(a[O]<c[z[O]])then T[O]else O;
                      end
                    end
                  end
                else
                  if H<67 then
                    if H>=64 then
                      if H<65 then
                        local d,Q,M=a[O],z[O],n[6];
                        local sP=W(M[d],187638924);
                        M[d]=sP;
                        d,M=n[5],sP+1;
                        sP=V(d,M);
                        local lP,LP;
                        if sP<128 then
                          lP,LP=sP,M+1;
                        else
                          local yP=V(d,M+1);
                          if yP<128 then
                            lP,LP=(sP-128)*128+yP,M+2;
                          else
                            local zP=V(d,M+2);
                            if zP<128 then
                              lP,LP=(sP-128)*16384+(yP-128)+zP*128,M+3;
                            else
                              local TP=V(d,M+3);
                              lP,LP=sP-128+(yP-128)*2097152+(zP-128)*128+TP%128*16384+(TP-TP%128)*2097152,M+4;
                            end
                          end
                        end
                        M,sP=Q*16843009,LP+lP;
                        local yP=sP-lP%4;
                        for lP=LP,yP-1,4 do
                          _(d,lP,(W(X(d,lP),M)));
                        end;
                        for M=yP,sP-1,1 do
                          x(d,M,(W(V(d,M),Q)));
                        end;
                        a[O]=65;
                        z[O]=191;
                        T[O]=63;
                        P[O]=44;
                      elseif H~=66 then
                        c[z[O]]=s[y[O]];
                      else
                        c[z[O]]=c[a[O]]==c[T[O]];
                      end
                    else
                      if H>=62 then
                        if H~=63 then
                          c[z[O]]=c[T[O]]//c[a[O]];
                        else
                          C,Z,r=a[O],z[O],T[O];
                          N,S=C+r-1,C+Z;
                          m=c[S];
                          Y=m.n;
                          b=Z+Y-1;
                          m.n=b;
                          I(m,1,Y,Z,m);
                          I(c,C+1,S-1,1,m);
                          o=E(c[C](i(m,1,m.n)));
                          I(o,1,r,C,c);
                        end
                      else
                        c[z[O]]=v(c[a[O]],l[O]);
                      end
                    end
                  else
                    if H<70 then
                      if H>=68 then
                        if H~=69 then
                          C,Z,r,N=T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],z[O];
                          S=C<2097152 and 7 or 14;
                          m,Y=F(C,S),h(C,k(1,S)-1);
                          a[O]=W(r,69,(h(F(Z,7),127)));
                          T[O]=W(Y,73,(h(Z,127)));
                          z[O]=W(N,79,(h(F(Z,14),127)));
                          P[O]=W(m,10,(h(F(Z,21),127)));
                          O=O-1;
                        else
                          c[z[O]]=v(c[T[O]],c[a[O]]);
                        end
                      else
                        for d=a[O],T[O],1 do
                          c[d]=nil;
                        end;
                      end
                    else
                      if H<72 then
                        if H==71 then
                          c[z[O]](c[T[O]],y[O]);
                        else
                          c[z[O]]=c[a[O]](l[O]);
                        end
                      else
                        if H~=73 then
                          Z,C=(W(a[O],(h(W(K,(h(F(K,29),7))),536870911)))),T[O]+1;
                          for H=1,z[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            T[C]=W(T[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            z[C]=W(z[C],(h(F(Z,14),127)));
                            P[C]=W(P[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          P[O]=44;
                        else
                          c[z[O]]=n;
                          c[z[O+1]]=a;
                          c[a[O+2]]=z;
                          c[T[O+3]]=T;
                          c[T[O+4]]=P;
                          O=O+4;
                        end
                      end
                    end
                  end
                end
              end
            end
          end
          O=O+1;
        end;
      else
      end
      if B==7 then
        while true do
          local H,d=z[O];
          if H<95 then
            if H>=47 then
              if H<71 then
                if H>=59 then
                  if H<65 then
                    if H<62 then
                      if H<60 then
                        O=if c[a[O]]==T[O]then P[O]else O;
                      else
                        if H==61 then
                          c[T[O]]=y[O]-c[P[O]];
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP,LP=Q+sP,w(sP);
                                  I(c,Q,lP-1,1,LP);
                                  M[4]=LP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return;
                        end
                      end
                    else
                      if H<63 then
                        c[T[O]]=n;
                        c[T[O+1]]=a;
                        c[a[O+2]]=z;
                        O+=2;
                      else
                        if H==64 then
                          c[a[O]]=W(c[T[O]],P[O]);
                        else
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP=w(sP);
                                  I(c,Q,Q+sP-1,1,lP);
                                  M[4]=lP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[T[O]];
                        end
                      end
                    end
                  else
                    if H<68 then
                      if H<66 then
                        c[P[O]]=c[T[O]]//a[O];
                      else
                        if H~=67 then
                          C,Z,r=T[O],a[O],P[O];
                          N=c[C];
                          I(c,C+1,C+Z,r+1,N);
                        else
                          c[a[O]][f[O]]=T[O];
                        end
                      end
                    else
                      if H<69 then
                        c[P[O]]=c[a[O]]>=c[T[O]];
                      else
                        if H~=70 then
                          C=A[a[O]];
                          c[P[O]]=C[4][C[6]];
                        else
                          c[a[O]](c[T[O]]);
                        end
                      end
                    end
                  end
                else
                  if H>=53 then
                    if H<56 then
                      if H>=54 then
                        if H~=55 then
                          c[P[O]]=h(y[O],c[T[O]]);
                        else
                          c[T[O]]=c[P[O]](i(c[a[O]],1,c[a[O]].n));
                        end
                      else
                        local Q;
                        local M=f[O];
                        if M then
                          local sP=#M/3;
                          if sP>0 then
                            Q={};
                            local lP,LP=j,q;
                            for yP=1,sP,1 do
                              local sP=(yP-1)*3;
                              local zP,TP=M[sP+3],M[sP+2];
                              if zP==2 then
                                lP=if not lP then{}else lP;
                                local nP=lP[TP];
                                if not nP then
                                  nP={[4]=c,[6]=TP};
                                  lP[TP]=nP;
                                else
                                end
                                Q[yP]=nP;
                              else
                                if zP==1 then
                                  Q[yP]=c[TP];
                                else
                                  if zP==3 then
                                    Q[yP]=A[TP];
                                  else
                                    if zP==0 then
                                      LP=if not LP then{}else LP;
                                      local zP=LP[TP];
                                      if not zP then
                                        zP={[5]=M[sP+1],[6]=TP,[4]=c};
                                        LP[TP]=zP;
                                      else
                                      end
                                      Q[yP]=zP;
                                    else
                                    end
                                  end
                                end
                              end
                            end;
                            j,q=lP,LP;
                          else
                          end
                        else
                        end
                        c[a[O]]=l[O](nil,Q);
                        C=Q;
                      end
                    else
                      if H>=57 then
                        if H==58 then
                          c[T[O]]=c[a[O]]-P[O];
                        else
                          d=D;
                          D,C={[5]=e,[8]=G,[6]=d,[9]=J},a[O];
                          e,G=c[C+2]+0,c[C+1]+0;
                          J=c[C]-e;
                          O=P[O];
                        end
                      else
                        c[T[O]]=c[P[O]]..c[a[O]];
                      end
                    end
                  else
                    if H>=50 then
                      if H>=51 then
                        if H==52 then
                          C=T[O];
                          local Q,M,sP=J();
                          if Q then
                            c[C+1]=M;
                            c[C+2]=sP;
                            O=P[O];
                          else
                          end
                          Z,r,N=Q,M,sP;
                        else
                          c[a[O]]=c[T[O]]<c[P[O]];
                        end
                      else
                        O=if c[a[O]]then P[O]else T[O];
                      end
                    else
                      if H>=48 then
                        if H~=49 then
                          C=A[P[O]];
                          C[4][C[6]][l[O]]=y[O];
                        else
                          c[P[O]]=#c[T[O]];
                        end
                      else
                        c[T[O]]=c[a[O]](f[O]);
                      end
                    end
                  end
                end
              else
                if H<83 then
                  if H>=77 then
                    if H>=80 then
                      if H<81 then
                        c[a[O]]=c[T[O]]~=c[P[O]];
                      elseif H==82 then
                        c[T[O]]=c[a[O]]<=f[O];
                      else
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local M=j[Q];
                              if M then
                                M[4]=M;
                                M[5]=c[Q];
                                M[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,M in t,q,nil do
                            local sP=M[5];
                            if q then
                              M=q[Q];
                              if M then
                                local lP=w(sP);
                                I(c,Q,Q+sP-1,1,lP);
                                M[4]=lP;
                                M[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[a[O]](c[P[O]],l[O]);
                      end
                    else
                      if H<78 then
                        Z,C=P[O],a[O]+1;
                        for Q=1,T[O],1 do
                          Z=h(W(Z,(k(Z,13))),536870911);
                          Z=W(Z,(F(Z,13)));
                          Z=h(W(Z,(k(Z,14))),536870911);
                          P[C]=W(P[C],(h(F(Z,0),127)));
                          a[C]=W(a[C],(h(F(Z,7),127)));
                          T[C]=W(T[C],(h(F(Z,14),127)));
                          z[C]=W(z[C],(h(F(Z,21),127)));
                          C=C+1;
                        end;
                        z[O]=22;
                      else
                        if H~=79 then
                          C=a[O];
                          r=C+T[O];
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP,LP=Q+sP-1,w(sP);
                                  I(c,Q,lP,1,LP);
                                  M[4]=LP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[C](i(c,C+1,r));
                        else
                          C,Z,r=P[O],T[O],a[O];
                          N,S=C+r-1,C+Z;
                          m=c[S];
                          Y=m.n;
                          b=Z+Y-1;
                          m.n=b;
                          I(m,1,Y,Z,m);
                          I(c,C+1,S-1,1,m);
                          o=E(c[C](i(m,1,m.n)));
                          I(o,1,r,C,c);
                        end
                      end
                    end
                  else
                    if H<74 then
                      if H>=72 then
                        if H~=73 then
                          C,Z,r,N=T[O],a[O],P[O],W(p,h(F(p,14),262143),(h(F(p,28),15)));
                          S=C<16384 and 7 or(C<2097152 and 14 or 21);
                          m,Y=h(C,k(1,S)-1),F(C,S);
                          a[O]=W(Z,112,(h(F(N,7),127)));
                          T[O]=W(m,95,(h(F(N,14),127)));
                          P[O]=W(r,5,(h(N,127)));
                          z[O]=W(Y,73,(h(F(N,21),127)));
                          O=O-1;
                        else
                          local Q,M=f[O];
                          if Q then
                            local sP=#Q/3;
                            if sP>0 then
                              M={};
                              local lP,LP=j,q;
                              for yP=1,sP,1 do
                                local sP=(yP-1)*3;
                                local zP,TP=Q[sP+3],Q[sP+2];
                                if zP==2 then
                                  lP=if not lP then{}else lP;
                                  local nP=lP[TP];
                                  if not nP then
                                    nP={[4]=c,[6]=TP};
                                    lP[TP]=nP;
                                  else
                                  end
                                  M[yP]=nP;
                                else
                                  if zP==1 then
                                    M[yP]=c[TP];
                                  else
                                    if zP==3 then
                                      M[yP]=A[TP];
                                    else
                                      if zP==0 then
                                        LP=if not LP then{}else LP;
                                        local zP=LP[TP];
                                        if not zP then
                                          zP={[5]=Q[sP+1],[6]=TP,[4]=c};
                                          LP[TP]=zP;
                                        else
                                        end
                                        M[yP]=zP;
                                      else
                                      end
                                    end
                                  end
                                end
                              end;
                              j,q=lP,LP;
                            else
                            end
                          else
                          end
                          c[T[O]]=c[a[O]](nil,M);
                          C=M;
                        end
                      else
                        c[a[O]]={};
                      end
                    else
                      if H<75 then
                        c[T[O]]=c[P[O]];
                      else
                        O=if H~=76 then if not(c[T[O]]<c[P[O]])then a[O]else O else if not(a[O]<=c[P[O]])then T[O]else O;
                      end
                    end
                  end
                else
                  if H<89 then
                    if H<86 then
                      if H>=84 then
                        if H~=85 then
                          c[a[O]]=c[T[O]]<=c[P[O]];
                        else
                          c[P[O]]=P;
                        end
                      else
                        c[P[O]]=k(c[T[O]],a[O]);
                      end
                    else
                      if H<87 then
                        c[a[O]](f[O],c[T[O]]);
                      else
                        if H~=88 then
                          Z,C=(W(a[O],(h(W(p,(h(F(p,29),7))),536870911)))),P[O]+1;
                          for Q=1,T[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            P[C]=W(P[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            T[C]=W(T[C],(h(F(Z,14),127)));
                            z[C]=W(z[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          z[O]=22;
                        else
                          Z,C=(W(a[O],(h(W(K,(h(F(K,29),7))),536870911)))),P[O]+1;
                          for Q=1,T[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            P[C]=W(P[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            T[C]=W(T[C],(h(F(Z,14),127)));
                            z[C]=W(z[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          z[O]=22;
                        end
                      end
                    end
                  else
                    if H<92 then
                      if H<90 then
                        c[a[O]]=W(c[P[O]],l[O]);
                      else
                        if H~=91 then
                          C=c[T[O]];
                          c[a[O]]=E(i(C,P[O],C.n));
                        else
                          c[a[O]]=s[P[O]];
                        end
                      end
                    else
                      if H<93 then
                        c[P[O]]=c[a[O]][c[T[O]]];
                      else
                        if H==94 then
                          c[T[O]]=-c[a[O]];
                        else
                          O=P[O];
                        end
                      end
                    end
                  end
                end
              end
            else
              if H>=23 then
                if H<35 then
                  if H>=29 then
                    if H>=32 then
                      if H>=33 then
                        if H==34 then
                          c[P[O]]=h(T[O],c[a[O]]);
                        else
                          J,G=D[9],D[8];
                          e,D=D[5],D[6];
                        end
                      else
                        A[P[O]][y[O]]=T[O];
                      end
                    else
                      if H<30 then
                        A[T[O]][c[P[O]]]=y[O];
                      else
                        if H==31 then
                          O=if not(c[a[O]]<=c[T[O]])then P[O]else O;
                        else
                          C,Z,r=P[O],T[O],a[O];
                          N,S=c[C],C+Z;
                          m=c[S];
                          I(c,C+1,S-1,r+1,N);
                          I(m,1,m.n,r+Z,N);
                        end
                      end
                    end
                  else
                    if H>=26 then
                      if H>=27 then
                        if H==28 then
                          c[T[O]]=h(c[a[O]],c[P[O]]);
                        else
                          O=if not(f[O]<c[T[O]])then a[O]else O;
                        end
                      else
                        C,Z,r=a[O],T[O],P[O];
                        N=C+Z;
                        c[C]=E(c[C](i(c,C+1,N)));
                      end
                    else
                      if H>=24 then
                        if H~=25 then
                          c[P[O]]=u[l[O]];
                        else
                          C=P[O];
                          Z,r,N,S=c[C],c[C+1],c[C+2],c[C+3];
                          c[C]=Z(r,N,S);
                        end
                      else
                        local Q,M,sP=P[O],W(a[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];
                        local lP=W(sP[Q],187638924);
                        sP[Q]=lP;
                        sP,Q=n[5],lP+1;
                        lP=V(sP,Q);
                        local LP,yP;
                        if lP<128 then
                          LP,yP=lP,Q+1;
                        else
                          local zP=V(sP,Q+1);
                          if zP<128 then
                            LP,yP=(lP-128)*128+zP,Q+2;
                          else
                            local TP=V(sP,Q+2);
                            if TP<128 then
                              LP,yP=(lP-128)*16384+(zP-128)+TP*128,Q+3;
                            else
                              local nP=V(sP,Q+3);
                              LP,yP=lP-128+(zP-128)*2097152+(TP-128)*128+nP%128*16384+(nP-nP%128)*2097152,Q+4;
                            end
                          end
                        end
                        lP,Q=M*16843009,yP+LP;
                        local zP=Q-LP%4;
                        for LP=yP,zP-1,4 do
                          _(sP,LP,(W(X(sP,LP),lP)));
                        end;
                        for lP=zP,Q-1,1 do
                          x(sP,lP,(W(V(sP,lP),M)));
                        end;
                        P[O]=138;
                        a[O]=57;
                        T[O]=137;
                        z[O]=22;
                      end
                    end
                  end
                else
                  if H<41 then
                    if H<38 then
                      if H>=36 then
                        if H==37 then
                          c[P[O]]=l[O];
                        else
                          c[a[O]]=v(l[O],c[P[O]]);
                        end
                      else
                        c[P[O]]=F(c[T[O]],a[O]);
                      end
                    elseif H<39 then
                      c[T[O]]=v(c[P[O]],c[a[O]]);
                    elseif H~=40 then
                      c[a[O]]=p;
                    else
                      c[P[O]](c[T[O]],i(c[a[O]],1,c[a[O]].n));
                    end
                  else
                    if H<44 then
                      if H>=42 then
                        if H~=43 then
                          O=if c[T[O]]~=y[O]then P[O]else O;
                        else
                          c[P[O]]=c[a[O]]%c[T[O]];
                        end
                      else
                        c[T[O]]=c[a[O]]%P[O];
                      end
                    else
                      if H<45 then
                        c[a[O]]=c[P[O]][T[O]];
                      else
                        if H==46 then
                          local Q,M,sP=T[O],c[P[O]],c[a[O]];
                          local lP,LP=h(M,4294967295),h(sP,4294967295);
                          local sP,yP,zP,TP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                          LP=h(sP*zP+k(h(sP*TP+yP*zP,65535),16),4294967295);
                          zP=nil;
                          repeat
                            M=LP%4294967296;
                            if M~=M then
                              zP=0;
                              break;
                            end
                            zP=M-M%1;
                          until true;
                          c[Q]=zP;
                        else
                          O=if c[P[O]]~=c[a[O]]then T[O]else O;
                        end
                      end
                    end
                  end
                end
              else
                if H>=11 then
                  if H>=17 then
                    if H<20 then
                      if H>=18 then
                        if H==19 then
                          c[P[O]]=y[O]..c[T[O]];
                        else
                          K=c[T[O]];
                        end
                      else
                        local Q,M,sP=P[O],T[O],y[O];
                        local lP,LP=h(M,4294967295),h(sP,4294967295);
                        local yP,zP,TP,nP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                        sP=h(yP*TP+k(h(yP*nP+zP*TP,65535),16),4294967295);
                        M=nil;
                        repeat
                          LP=sP%4294967296;
                          if LP~=LP then
                            M=0;
                            break;
                          end
                          M=LP-LP%1;
                        until true;
                        c[Q]=M;
                      end
                    else
                      if H<21 then
                        c[a[O]]=c[P[O]]();
                      else
                        O=if H~=22 then if not c[T[O]]then a[O]else P[O]else O;
                      end
                    end
                  else
                    if H<14 then
                      if H>=12 then
                        if H==13 then
                          c[T[O]]=c[a[O]]<=P[O];
                        else
                          local Q,M,sP=a[O],P[O],c[T[O]];
                          local lP,LP=h(M,4294967295),h(sP,4294967295);
                          local M,sP,yP,zP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                          lP=h(M*yP+k(h(M*zP+sP*yP,65535),16),4294967295);
                          LP=nil;
                          repeat
                            zP=lP%4294967296;
                            if zP~=zP then
                              LP=0;
                              break;
                            end
                            LP=zP-zP%1;
                          until true;
                          c[Q]=LP;
                        end
                      else
                        A[P[O]][l[O]]=c[a[O]];
                      end
                    elseif H>=15 then
                      if H~=16 then
                        c[T[O]]=c[a[O]]-c[P[O]];
                      else
                        c[a[O]]=c[P[O]]~=T[O];
                      end
                    else
                      c[T[O]]=u[f[O]][y[O]];
                    end
                  end
                else
                  if H>=5 then
                    if H>=8 then
                      if H<9 then
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local M=j[Q];
                              if M then
                                M[4]=M;
                                M[5]=c[Q];
                                M[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,M in t,q,nil do
                            local sP=M[5];
                            if q then
                              M=q[Q];
                              if M then
                                local lP,LP=Q+sP,w(sP);
                                I(c,Q,lP-1,1,LP);
                                M[4]=LP;
                                M[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return c[T[O]],i(c[P[O]],1,c[P[O]].n);
                      elseif H==10 then
                        C,Z,r=T[O],P[O],a[O];
                        N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));
                        I(m,1,r,C,c);
                      else
                        c[T[O]]=P[O]-c[a[O]];
                      end
                    else
                      if H>=6 then
                        if H==7 then
                          c[P[O]]=v(c[a[O]],l[O]);
                        else
                          O=if not(c[a[O]]<l[O])then P[O]else O;
                        end
                      else
                        c[P[O]]=c[T[O]](c[a[O]]);
                      end
                    end
                  else
                    if H>=2 then
                      if H>=3 then
                        if H~=4 then
                          O=if c[P[O]]<c[T[O]]then a[O]else O;
                        else
                          local Q,M,sP=P[O],y[O],c[T[O]];
                          local lP,LP=h(M,4294967295),h(sP,4294967295);
                          local sP,yP,zP,TP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                          M=h(sP*zP+k(h(sP*TP+yP*zP,65535),16),4294967295);
                          zP=nil;
                          repeat
                            TP=M%4294967296;
                            if TP~=TP then
                              zP=0;
                              break;
                            end
                            zP=TP-TP%1;
                          until true;
                          c[Q]=zP;
                        end
                      else
                        local Q,M,sP=T[O],f[O],y[O];
                        local lP,LP=h(M,4294967295),h(sP,4294967295);
                        local yP,zP,TP,nP=h(lP,65535),F(lP,16),h(LP,65535),F(LP,16);
                        M=h(yP*TP+k(h(yP*nP+zP*TP,65535),16),4294967295);
                        sP=nil;
                        repeat
                          zP=M%4294967296;
                          if zP~=zP then
                            sP=0;
                            break;
                          end
                          sP=zP-zP%1;
                        until true;
                        c[Q]=sP;
                      end
                    else
                      if H~=1 then
                        c[a[O]]=c[P[O]]<T[O];
                      else
                        c[P[O]]=c[T[O]]%y[O];
                      end
                    end
                  end
                end
              end
            end
          else
            if H>=143 then
              if H>=167 then
                if H>=179 then
                  if H<185 then
                    if H>=182 then
                      if H<183 then
                        O=c[a[O]];
                      else
                        if H==184 then
                          if j then
                            for Q in t,j,nil do
                              if j then
                                local M=j[Q];
                                if M then
                                  M[4]=M;
                                  M[5]=c[Q];
                                  M[6]=5;
                                  j[Q]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for Q,M in t,q,nil do
                              local sP=M[5];
                              if q then
                                M=q[Q];
                                if M then
                                  local lP,LP=Q+sP-1,w(sP);
                                  I(c,Q,lP,1,LP);
                                  M[4]=LP;
                                  M[6]=1;
                                  q[Q]=nil;
                                end
                              end
                            end;
                          end
                          return c[P[O]],c[T[O]],c[a[O]];
                        else
                          C=A[a[O]];
                          c[T[O]]=C[4][C[6]][f[O]];
                        end
                      end
                    else
                      if H>=180 then
                        if H~=181 then
                          O=if c[P[O]]<a[O]then T[O]else O;
                        else
                          c[a[O]]=c[T[O]]/f[O];
                        end
                      else
                        c[P[O]]=c[a[O]]*l[O];
                      end
                    end
                  else
                    if H<188 then
                      if H<186 then
                        c[T[O]]=c[a[O]][f[O]];
                      elseif H~=187 then
                        c[a[O]]=c[T[O]]<f[O];
                      else
                        local Q,M,sP=a[O],P[O],n[6];
                        local lP=W(sP[Q],187638924);
                        sP[Q]=lP;
                        Q,sP=n[5],lP+1;
                        lP=V(Q,sP);
                        local LP,yP;
                        if lP<128 then
                          LP,yP=lP,sP+1;
                        else
                          local zP=V(Q,sP+1);
                          if zP<128 then
                            LP,yP=(lP-128)*128+zP,sP+2;
                          else
                            local TP=V(Q,sP+2);
                            if TP<128 then
                              LP,yP=(lP-128)*16384+(zP-128)+TP*128,sP+3;
                            else
                              local nP=V(Q,sP+3);
                              LP,yP=lP-128+(zP-128)*2097152+(TP-128)*128+nP%128*16384+(nP-nP%128)*2097152,sP+4;
                            end
                          end
                        end
                        sP,lP=M*16843009,yP+LP;
                        local zP=lP-LP%4;
                        for LP=yP,zP-1,4 do
                          _(Q,LP,(W(X(Q,LP),sP)));
                        end;
                        for sP=zP,lP-1,1 do
                          x(Q,sP,(W(V(Q,sP),M)));
                        end;
                        a[O]=249;
                        P[O]=198;
                        T[O]=199;
                        z[O]=22;
                      end
                    else
                      if H>=189 then
                        if H~=190 then
                          O=if c[a[O]]~=P[O]then T[O]else O;
                        else
                          c[a[O]]=c[P[O]]==T[O];
                        end
                      else
                        c[T[O]]=n;
                        c[T[O+1]]=a;
                        c[a[O+2]]=z;
                        c[P[O+3]]=T;
                        c[P[O+4]]=P;
                        O+=4;
                      end
                    end
                  end
                else
                  if H<173 then
                    if H>=170 then
                      if H<171 then
                        local Q,M,sP=T[O],c[P[O]];
                        repeat
                          local lP=M%4294967296;
                          if lP~=lP then
                            sP=0;
                            break;
                          end
                          sP=lP-lP%1;
                        until true;
                        c[Q]=sP;
                      elseif H~=172 then
                        if j then
                          for Q in t,j,nil do
                            if j then
                              local M=j[Q];
                              if M then
                                M[4]=M;
                                M[5]=c[Q];
                                M[6]=5;
                                j[Q]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for Q,M in t,q,nil do
                            local sP=M[5];
                            if q then
                              M=q[Q];
                              if M then
                                local lP,LP=Q+sP-1,w(sP);
                                I(c,Q,lP,1,LP);
                                M[4]=LP;
                                M[6]=1;
                                q[Q]=nil;
                              end
                            end
                          end;
                        end
                        return f[O],c[a[O]];
                      else
                        c[T[O]]=c[a[O]]>=P[O];
                      end
                    elseif H<168 then
                      for Q=P[O],a[O],1 do
                        c[Q]=nil;
                      end;
                    elseif H~=169 then
                      c[a[O]]=c[P[O]]>l[O];
                    else
                      c[T[O]]=not c[P[O]];
                    end
                  elseif H<176 then
                    if H>=174 then
                      if H~=175 then
                        c[T[O]]=c[a[O]]+f[O];
                      else
                        c[T[O]]=c[a[O]]//c[P[O]];
                      end
                    else
                      c[P[O]],c[T[O]]=c[a[O]]();
                    end
                  elseif H<177 then
                    c[a[O]]=z;
                  elseif H~=178 then
                    c[T[O]]=W(c[a[O]],c[P[O]]);
                  else
                    c[T[O]+c[P[O]]]=c[a[O]];
                  end
                end
              else
                if H>=155 then
                  if H<161 then
                    if H<158 then
                      if H>=156 then
                        if H~=157 then
                          B=P[O];
                          O=a[O]+1;
                          break;
                        else
                          O=if c[P[O]]==c[a[O]]then T[O]else O;
                        end
                      else
                        c[a[O]]=c[P[O]]*T[O];
                      end
                    else
                      if H>=159 then
                        if H==160 then
                          c[T[O]]=P[O];
                        else
                          c[a[O]](l[O],i(c[P[O]],1,c[P[O]].n));
                        end
                      else
                        c[T[O]](c[a[O]],c[P[O]]);
                      end
                    end
                  else
                    if H<164 then
                      if H<162 then
                        c[P[O]](y[O],l[O]);
                      elseif H~=163 then
                        c[a[O]]=E(c[P[O]]());
                      else
                        c[P[O]]=c[T[O]]>c[a[O]];
                      end
                    else
                      if H<165 then
                        d=D;
                        D,C,Z={[5]=e,[8]=G,[6]=d,[9]=J},P[O],R(g);
                        Z(s,c[C],c[C+1],c[C+2]);
                        O,J=T[O],Z;
                      else
                        if H~=166 then
                          c[a[O]]=h(c[T[O]],P[O]);
                        else
                          c[T[O]][y[O]]=c[P[O]];
                        end
                      end
                    end
                  end
                else
                  if H>=149 then
                    if H<152 then
                      if H<150 then
                        C=A[a[O]];
                        C[4][C[6]]=f[O];
                      else
                        if H~=151 then
                          c[T[O]]=c[a[O]]+P[O];
                        else
                          A[P[O]][l[O]]=y[O];
                        end
                      end
                    else
                      if H<153 then
                        c[T[O]]=c[P[O]]/c[a[O]];
                      elseif H==154 then
                        if j then
                          for d in t,j,nil do
                            if j then
                              local Q=j[d];
                              if Q then
                                Q[4]=Q;
                                Q[5]=c[d];
                                Q[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,Q in t,q,nil do
                            local M=Q[5];
                            if q then
                              Q=q[d];
                              if Q then
                                local sP=w(M);
                                I(c,d,d+M-1,1,sP);
                                Q[4]=sP;
                                Q[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return f[O];
                      else
                        c[T[O]]=c[a[O]]..f[O];
                      end
                    end
                  else
                    if H>=146 then
                      if H>=147 then
                        if H==148 then
                          c[a[O]]=c[T[O]]>P[O];
                        else
                          c[a[O]]=l[O]+c[P[O]];
                        end
                      else
                        c[P[O]]=T[O]+c[a[O]];
                      end
                    elseif H<144 then
                      c[a[O]]=U(c[T[O]]);
                    elseif H~=145 then
                      if j then
                        for d in t,j,nil do
                          if j then
                            local Q=j[d];
                            if Q then
                              Q[4]=Q;
                              Q[5]=c[d];
                              Q[6]=5;
                              j[d]=nil;
                            end
                          end
                        end;
                      end
                      if q then
                        for d,Q in t,q,nil do
                          local M=Q[5];
                          if q then
                            Q=q[d];
                            if Q then
                              local sP=w(M);
                              I(c,d,d+M-1,1,sP);
                              Q[4]=sP;
                              Q[6]=1;
                              q[d]=nil;
                            end
                          end
                        end;
                      end
                      return c[a[O]],c[T[O]];
                    else
                      c[a[O]]=A[T[O]][P[O]];
                    end
                  end
                end
              end
            else
              if H<119 then
                if H>=107 then
                  if H<113 then
                    if H<110 then
                      if H>=108 then
                        if H~=109 then
                          c[a[O]](l[O]);
                        else
                          c[P[O]](c[T[O]],y[O]);
                        end
                      else
                        c[T[O]][c[P[O]]]=c[a[O]];
                      end
                    elseif H<111 then
                      c[a[O]]=c[P[O]]+c[T[O]];
                    elseif H~=112 then
                      c[P[O]][a[O]]=l[O];
                    else
                      if j then
                        for d in t,j,nil do
                          if j then
                            local Q=j[d];
                            if Q then
                              Q[4]=Q;
                              Q[5]=c[d];
                              Q[6]=5;
                              j[d]=nil;
                            end
                          end
                        end;
                      end
                      if q then
                        for d,Q in t,q,nil do
                          local M=Q[5];
                          if q then
                            Q=q[d];
                            if Q then
                              local sP=w(M);
                              I(c,d,d+M-1,1,sP);
                              Q[4]=sP;
                              Q[6]=1;
                              q[d]=nil;
                            end
                          end
                        end;
                      end
                      return c[P[O]](c[a[O]]);
                    end
                  else
                    if H<116 then
                      if H>=114 then
                        if H~=115 then
                          c[T[O]]=W(y[O],c[P[O]]);
                        else
                          c[a[O]]=c[T[O]]==c[P[O]];
                        end
                      else
                        O=if T[O]<c[a[O]]then P[O]else O;
                      end
                    else
                      if H>=117 then
                        if H~=118 then
                          c[P[O]]=T;
                        else
                          O=if not(a[O]<c[T[O]])then P[O]else O;
                        end
                      else
                        c[a[O]]=E(c[T[O]](c[P[O]]));
                      end
                    end
                  end
                else
                  if H<101 then
                    if H>=98 then
                      if H>=99 then
                        if H~=100 then
                          J+=e;
                          C=if e<=0 then J>=G else J<=G;
                          if C then
                            c[a[O]]=J;
                            O=P[O];
                          else
                          end
                        else
                          c[a[O]]=c[T[O]]==f[O];
                        end
                      else
                        c[T[O]]=n;
                      end
                    else
                      if H>=96 then
                        if H~=97 then
                          p=c[T[O]];
                        else
                          C=a[O];
                          Z,r,N=c[C],c[C+1],c[C+2];
                          c[C]=Z(r,N);
                        end
                      else
                        c[a[O]]=W(T[O],c[P[O]]);
                      end
                    end
                  else
                    if H<104 then
                      if H>=102 then
                        if H==103 then
                          C,Z,r,N=W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],T[O],P[O];
                          S=Z<2097152 and 7 or 14;
                          m,Y=h(Z,k(1,S)-1),F(Z,S);
                          z[O]=W(Y,101,(h(F(C,21),127)));
                          a[O]=W(m,10,(h(F(C,7),127)));
                          P[O]=W(N,77,(h(C,127)));
                          T[O]=W(r,119,(h(F(C,14),127)));
                          O=O-1;
                        else
                          c[T[O]]=K;
                        end
                      else
                        c[a[O]](i(c[T[O]],1,c[T[O]].n));
                      end
                    else
                      if H>=105 then
                        if H~=106 then
                          c[P[O]]=A[T[O]];
                        else
                          C,Z,r=a[O],P[O],T[O];
                          N=C+Z;
                          S=c[N];
                          m=S.n;
                          Y=Z+m-1;
                          S.n=Y;
                          I(S,1,m,Z,S);
                          I(c,C+1,N-1,1,S);
                          c[C]=E(c[C](i(S,1,S.n)));
                        end
                      else
                        C=A[T[O]];
                        c[a[O]]=C[4][C[6]][c[P[O]]];
                      end
                    end
                  end
                end
              else
                if H<131 then
                  if H>=125 then
                    if H>=128 then
                      if H>=129 then
                        if H~=130 then
                          local d,Q,M=T[O],c[a[O]],P[O];
                          local sP,lP=h(Q,4294967295),h(M,4294967295);
                          local Q,LP,yP,zP=h(sP,65535),F(sP,16),h(lP,65535),F(lP,16);
                          sP=h(Q*yP+k(h(Q*zP+LP*yP,65535),16),4294967295);
                          zP=nil;
                          repeat
                            M=sP%4294967296;
                            if M~=M then
                              zP=0;
                              break;
                            end
                            zP=M-M%1;
                          until true;
                          c[d]=zP;
                        else
                          if j then
                            for d in t,j,nil do
                              if j then
                                local Q=j[d];
                                if Q then
                                  Q[4]=Q;
                                  Q[5]=c[d];
                                  Q[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,Q in t,q,nil do
                              local M=Q[5];
                              if q then
                                Q=q[d];
                                if Q then
                                  local sP=w(M);
                                  I(c,d,d+M-1,1,sP);
                                  Q[4]=sP;
                                  Q[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return c[a[O]],f[O];
                        end
                      else
                        c[a[O]]=A[P[O]][c[T[O]]];
                      end
                    elseif H<126 then
                      A[T[O]][c[a[O]]]=c[P[O]];
                    elseif H~=127 then
                      c[P[O]]=v(T[O],c[a[O]]);
                    else
                      c[P[O]]=c[T[O]]*c[a[O]];
                    end
                  else
                    if H<122 then
                      if H<120 then
                        O=if c[T[O]]<f[O]then a[O]else O;
                      else
                        if H==121 then
                          c[T[O]]=A[a[O]][f[O]];
                        else
                          c[T[O]][f[O]]=y[O];
                        end
                      end
                    else
                      if H>=123 then
                        if H==124 then
                          c[T[O]]=a;
                        else
                          c[a[O]]=c[P[O]]-l[O];
                        end
                      else
                        c[T[O]]();
                      end
                    end
                  end
                else
                  if H<137 then
                    if H>=134 then
                      if H<135 then
                        c[P[O]][c[T[O]]]=a[O];
                      else
                        if H==136 then
                          local d,Q,M=P[O],W(a[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];
                          local sP=W(M[d],187638924);
                          M[d]=sP;
                          M,d=n[5],sP+1;
                          sP=V(M,d);
                          local lP,LP;
                          if sP<128 then
                            lP,LP=sP,d+1;
                          else
                            local yP=V(M,d+1);
                            if yP<128 then
                              lP,LP=(sP-128)*128+yP,d+2;
                            else
                              local zP=V(M,d+2);
                              if zP<128 then
                                lP,LP=(sP-128)*16384+(yP-128)+zP*128,d+3;
                              else
                                local TP=V(M,d+3);
                                lP,LP=sP-128+(yP-128)*2097152+(zP-128)*128+TP%128*16384+(TP-TP%128)*2097152,d+4;
                              end
                            end
                          end
                          d,sP=Q*16843009,LP+lP;
                          local yP=sP-lP%4;
                          for lP=LP,yP-1,4 do
                            _(M,lP,(W(X(M,lP),d)));
                          end;
                          for d=yP,sP-1,1 do
                            x(M,d,(W(V(M,d),Q)));
                          end;
                          P[O]=186;
                          a[O]=86;
                          T[O]=21;
                          z[O]=22;
                        else
                          C,Z=T[O],c[a[O]];
                          c[C+1]=Z;
                          c[C]=Z[f[O]];
                        end
                      end
                    else
                      if H<132 then
                        c[P[O]]=c[a[O]]~=l[O];
                      elseif H~=133 then
                        local d=P[O];
                        if j then
                          local Q=j[d];
                          if Q then
                            Q[4]=Q;
                            Q[5]=c[d];
                            Q[6]=5;
                            j[d]=nil;
                          end
                        end
                      else
                        c[P[O]]=a[O]*c[T[O]];
                      end
                    end
                  else
                    if H>=140 then
                      if H>=141 then
                        if H==142 then
                          C=A[T[O]];
                          C[4][C[6]]=c[P[O]];
                        else
                          O=if a[O]<=c[T[O]]then P[O]else O;
                        end
                      else
                        c[P[O]]=c[T[O]]/a[O];
                      end
                    else
                      if H>=138 then
                        if H~=139 then
                          c[a[O]][c[P[O]]]=l[O];
                        else
                          c[T[O]]=P[O]^c[a[O]];
                        end
                      else
                        O=if c[P[O]]==l[O]then a[O]else O;
                      end
                    end
                  end
                end
              end
            end
          end
          O=O+1;
        end;
      else
      end
      if B==231 then
        while true do
          local l=T[O];
          if l>=100 then
            local H;
            if l>=150 then
              if l<175 then
                if l<162 then
                  if l>=156 then
                    if l<159 then
                      if l<157 then
                        c[P[O]]=c[a[O]]%L[O];
                      elseif l==158 then
                        c[a[O]]=f[O]..c[z[O]];
                      else
                        s[P[O]]=c[z[O]];
                      end
                    elseif l>=160 then
                      if l~=161 then
                        c[a[O]]=v(c[P[O]],L[O]);
                      else
                        if j then
                          for d in t,j,nil do
                            if j then
                              local B=j[d];
                              if B then
                                B[4]=B;
                                B[5]=c[d];
                                B[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,B in t,q,nil do
                            local Q=B[5];
                            if q then
                              B=q[d];
                              if B then
                                local M,sP=d+Q-1,w(Q);
                                I(c,d,M,1,sP);
                                B[4]=sP;
                                B[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return c[a[O]](c[P[O]],i(c[z[O]],1,c[z[O]].n));
                      end
                    else
                      c[a[O]]=c[z[O]]<=P[O];
                    end
                  elseif l>=153 then
                    if l>=154 then
                      if l==155 then
                        c[a[O]]=c[P[O]]>=z[O];
                      else
                        c[P[O]]=c[a[O]]..c[z[O]];
                      end
                    else
                      A[P[O]][c[z[O]]]=y[O];
                    end
                  elseif l>=151 then
                    if l==152 then
                      c[z[O]](c[a[O]]);
                    else
                      if j then
                        for d in t,j,nil do
                          if j then
                            local B=j[d];
                            if B then
                              B[4]=B;
                              B[5]=c[d];
                              B[6]=5;
                              j[d]=nil;
                            end
                          end
                        end;
                      end
                      if q then
                        for d,B in t,q,nil do
                          local Q=B[5];
                          if q then
                            B=q[d];
                            if B then
                              local M,sP=d+Q-1,w(Q);
                              I(c,d,M,1,sP);
                              B[4]=sP;
                              B[6]=1;
                              q[d]=nil;
                            end
                          end
                        end;
                      end
                      return L[O],f[O],c[a[O]];
                    end
                  else
                    if j then
                      for d in t,j,nil do
                        if j then
                          local B=j[d];
                          if B then
                            B[4]=B;
                            B[5]=c[d];
                            B[6]=5;
                            j[d]=nil;
                          end
                        end
                      end;
                    end
                    if q then
                      for d,B in t,q,nil do
                        local Q=B[5];
                        if q then
                          B=q[d];
                          if B then
                            local M,sP=d+Q-1,w(Q);
                            I(c,d,M,1,sP);
                            B[4]=sP;
                            B[6]=1;
                            q[d]=nil;
                          end
                        end
                      end;
                    end
                    return L[O];
                  end
                else
                  if l>=168 then
                    if l>=171 then
                      if l<173 then
                        if l~=172 then
                          c[a[O]]=c[P[O]]==L[O];
                        else
                          C,Z,r=a[O],z[O],P[O];
                          N=C+Z;
                          c[C]=E(c[C](i(c,C+1,N)));
                        end
                      else
                        if l~=174 then
                          c[a[O]]=c[z[O]]<f[O];
                        else
                          c[P[O]]=c[z[O]]==c[a[O]];
                        end
                      end
                    else
                      if l<169 then
                        c[P[O]]=#c[a[O]];
                      elseif l==170 then
                        c[P[O]]=L[O];
                      else
                        c[z[O]]=c[a[O]]>c[P[O]];
                      end
                    end
                  else
                    if l>=165 then
                      if l>=166 then
                        if l~=167 then
                          if j then
                            for d in t,j,nil do
                              if j then
                                local B=j[d];
                                if B then
                                  B[4]=B;
                                  B[5]=c[d];
                                  B[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,B in t,q,nil do
                              local Q=B[5];
                              if q then
                                B=q[d];
                                if B then
                                  local M,sP=d+Q-1,w(Q);
                                  I(c,d,M,1,sP);
                                  B[4]=sP;
                                  B[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return L[O],c[P[O]];
                        else
                          c[P[O]]=c[a[O]][z[O]];
                        end
                      else
                        C,Z,r=z[O],P[O],a[O];
                        N,S=C+r-1,C+Z;
                        m=c[S];
                        Y=m.n;
                        b=Z+Y-1;
                        m.n=b;
                        I(m,1,Y,Z,m);
                        I(c,C+1,S-1,1,m);
                        o=E(c[C](i(m,1,m.n)));
                        I(o,1,r,C,c);
                      end
                    else
                      if l<163 then
                        c[a[O]]=c[P[O]]/L[O];
                      else
                        if l==164 then
                          c[P[O]]=c[z[O]]<=c[a[O]];
                        else
                          H=D;
                          D,C={[5]=e,[8]=G,[6]=H,[9]=J},a[O];
                          e,G=c[C+2]+0,c[C+1]+0;
                          J=c[C]-e;
                          O=z[O];
                        end
                      end
                    end
                  end
                end
              else
                if l>=187 then
                  if l>=193 then
                    if l>=196 then
                      if l>=198 then
                        if l==199 then
                          O=if c[z[O]]==c[P[O]]then a[O]else O;
                        else
                          c[z[O]]=c[a[O]](c[P[O]]);
                        end
                      else
                        if l~=197 then
                          if j then
                            for d in t,j,nil do
                              if j then
                                local b=j[d];
                                if b then
                                  b[4]=b;
                                  b[5]=c[d];
                                  b[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,b in t,q,nil do
                              local o=b[5];
                              if q then
                                b=q[d];
                                if b then
                                  local B,Q=d+o-1,w(o);
                                  I(c,d,B,1,Q);
                                  b[4]=Q;
                                  b[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return c[a[O]](f[O],c[z[O]]);
                        else
                          O=if c[P[O]]then a[O]else z[O];
                        end
                      end
                    else
                      if l<194 then
                        c[a[O]](L[O]);
                        c[P[O+1]]=n;
                        c[P[O+2]]=a;
                        c[a[O+3]]=z;
                        O+=3;
                      else
                        if l==195 then
                          c[a[O]]=L[O]+c[P[O]];
                        else
                          local d,b,o=z[O],W(a[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];
                          local B=W(o[d],187638924);
                          o[d]=B;
                          d,o=n[5],B+1;
                          B=V(d,o);
                          local Q,M;
                          if B<128 then
                            Q,M=B,o+1;
                          else
                            local sP=V(d,o+1);
                            if sP<128 then
                              Q,M=(B-128)*128+sP,o+2;
                            else
                              local lP=V(d,o+2);
                              if lP<128 then
                                Q,M=(B-128)*16384+(sP-128)+lP*128,o+3;
                              else
                                local LP=V(d,o+3);
                                Q,M=B-128+(sP-128)*2097152+(lP-128)*128+LP%128*16384+(LP-LP%128)*2097152,o+4;
                              end
                            end
                          end
                          B,o=b*16843009,M+Q;
                          local sP=o-Q%4;
                          for Q=M,sP-1,4 do
                            _(d,Q,(W(X(d,Q),B)));
                          end;
                          for B=sP,o-1,1 do
                            x(d,B,(W(V(d,B),b)));
                          end;
                          z[O]=55;
                          a[O]=63;
                          P[O]=63;
                          T[O]=1;
                        end
                      end
                    end
                  else
                    if l>=190 then
                      if l<191 then
                        c[a[O]][c[P[O]]]=L[O];
                      elseif l==192 then
                        local d,b,o=a[O],c[z[O]];
                        repeat
                          local B=b%4294967296;
                          if B~=B then
                            o=0;
                            break;
                          end
                          o=B-B%1;
                        until true;
                        c[d]=o;
                      else
                        c[a[O]]=c[z[O]]..f[O];
                      end
                    elseif l<188 then
                      c[z[O]]=k(c[a[O]],P[O]);
                    elseif l~=189 then
                      c[z[O]]=c[P[O]][c[a[O]]];
                    else
                      c[P[O]](y[O],c[z[O]]);
                    end
                  end
                else
                  if l>=181 then
                    if l<184 then
                      if l>=182 then
                        O=if l==183 then if not(y[O]<c[P[O]])then z[O]else O else if c[P[O]]~=a[O]then z[O]else O;
                      else
                        C,Z,r=a[O],z[O],P[O];
                        N=C+Z;
                        S=c[N];
                        m=S.n;
                        Y=Z+m-1;
                        S.n=Y;
                        I(S,1,m,Z,S);
                        I(c,C+1,N-1,1,S);
                        c[C]=E(c[C](i(S,1,S.n)));
                      end
                    else
                      if l>=185 then
                        if l==186 then
                          c[P[O]]=c[z[O]]*c[a[O]];
                        else
                          c[P[O]]=z[O]^c[a[O]];
                        end
                      else
                        Z,C=P[O],a[O]+1;
                        for d=1,z[O],1 do
                          Z=h(W(Z,(k(Z,13))),536870911);
                          Z=W(Z,(F(Z,13)));
                          Z=h(W(Z,(k(Z,14))),536870911);
                          z[C]=W(z[C],(h(F(Z,0),127)));
                          a[C]=W(a[C],(h(F(Z,7),127)));
                          P[C]=W(P[C],(h(F(Z,14),127)));
                          T[C]=W(T[C],(h(F(Z,21),127)));
                          C=C+1;
                        end;
                        T[O]=1;
                      end
                    end
                  else
                    if l>=178 then
                      if l<179 then
                        local d,b,o=a[O],c[P[O]],c[z[O]];
                        local B,Q=h(b,4294967295),h(o,4294967295);
                        local b,M,sP,lP=h(B,65535),F(B,16),h(Q,65535),F(Q,16);
                        o=h(b*sP+k(h(b*lP+M*sP,65535),16),4294967295);
                        sP=nil;
                        repeat
                          M=o%4294967296;
                          if M~=M then
                            sP=0;
                            break;
                          end
                          sP=M-M%1;
                        until true;
                        c[d]=sP;
                      elseif l==180 then
                        c[a[O]][f[O]]=L[O];
                      else
                        c[a[O]]=v(z[O],c[P[O]]);
                      end
                    else
                      if l<176 then
                        C,Z=a[O],c[z[O]];
                        c[C+1]=Z;
                        c[C]=Z[f[O]];
                      else
                        if l==177 then
                          C=A[P[O]];
                          C[4][C[6]][L[O]]=a[O];
                        else
                          c[P[O]]=c[a[O]]*L[O];
                        end
                      end
                    end
                  end
                end
              end
            else
              if l>=125 then
                if l>=137 then
                  if l<143 then
                    if l<140 then
                      if l>=138 then
                        if l~=139 then
                          c[a[O]]=-c[z[O]];
                        else
                          c[P[O]]=s[a[O]];
                        end
                      else
                        O=c[P[O]];
                      end
                    else
                      if l<141 then
                        C=z[O];
                        r=C+P[O];
                        if j then
                          for d in t,j,nil do
                            if j then
                              local b=j[d];
                              if b then
                                b[4]=b;
                                b[5]=c[d];
                                b[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,b in t,q,nil do
                            local o=b[5];
                            if q then
                              b=q[d];
                              if b then
                                local B=w(o);
                                I(c,d,d+o-1,1,B);
                                b[4]=B;
                                b[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return c[C](i(c,C+1,r));
                      elseif l==142 then
                        local d,b,o=z[O],y[O],c[P[O]];
                        local B,Q=h(b,4294967295),h(o,4294967295);
                        local o,M,sP,lP=h(B,65535),F(B,16),h(Q,65535),F(Q,16);
                        b=h(o*sP+k(h(o*lP+M*sP,65535),16),4294967295);
                        B=nil;
                        repeat
                          sP=b%4294967296;
                          if sP~=sP then
                            B=0;
                            break;
                          end
                          B=sP-sP%1;
                        until true;
                        c[d]=B;
                      else
                        s[y[O]]=c[z[O]];
                      end
                    end
                  else
                    if l>=146 then
                      if l<148 then
                        if l==147 then
                          O=if not(c[a[O]]<=c[P[O]])then z[O]else O;
                        else
                          if j then
                            for d in t,j,nil do
                              if j then
                                local b=j[d];
                                if b then
                                  b[4]=b;
                                  b[5]=c[d];
                                  b[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,b in t,q,nil do
                              local o=b[5];
                              if q then
                                b=q[d];
                                if b then
                                  local B,Q=d+o-1,w(o);
                                  I(c,d,B,1,Q);
                                  b[4]=Q;
                                  b[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return y[O],c[z[O]],c[P[O]];
                        end
                      else
                        if l==149 then
                          if j then
                            for d in t,j,nil do
                              if j then
                                local b=j[d];
                                if b then
                                  b[4]=b;
                                  b[5]=c[d];
                                  b[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,b in t,q,nil do
                              local o=b[5];
                              if q then
                                b=q[d];
                                if b then
                                  local B=w(o);
                                  I(c,d,d+o-1,1,B);
                                  b[4]=B;
                                  b[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return c[a[O]],c[P[O]],c[z[O]];
                        else
                          c[P[O]]=W(c[a[O]],c[z[O]]);
                        end
                      end
                    else
                      if l<144 then
                        for d=P[O],a[O],1 do
                          c[d]=nil;
                        end;
                      elseif l==145 then
                        C,Z=P[O],a[O];
                        r=C+Z;
                        N=c[r];
                        S=N.n;
                        if j then
                          for d in t,j,nil do
                            if j then
                              local b=j[d];
                              if b then
                                b[4]=b;
                                b[5]=c[d];
                                b[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,b in t,q,nil do
                            local o=b[5];
                            if q then
                              b=q[d];
                              if b then
                                local B=w(o);
                                I(c,d,d+o-1,1,B);
                                b[4]=B;
                                b[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        N.n=Z+S-1;
                        I(N,1,S,Z,N);
                        I(c,C+1,r-1,1,N);
                        return c[C](i(N,1,N.n));
                      else
                        if j then
                          for d in t,j,nil do
                            if j then
                              local b=j[d];
                              if b then
                                b[4]=b;
                                b[5]=c[d];
                                b[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,b in t,q,nil do
                            local o=b[5];
                            if q then
                              b=q[d];
                              if b then
                                local B,Q=d+o-1,w(o);
                                I(c,d,B,1,Q);
                                b[4]=Q;
                                b[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]](c[z[O]]);
                      end
                    end
                  end
                else
                  if l>=131 then
                    if l<134 then
                      if l>=132 then
                        if l==133 then
                          local d=a[O];
                          if j then
                            local b=j[d];
                            if b then
                              b[4]=b;
                              b[5]=c[d];
                              b[6]=5;
                              j[d]=nil;
                            end
                          end
                        else
                          c[z[O]]=P;
                        end
                      else
                        if j then
                          for d in t,j,nil do
                            if j then
                              local b=j[d];
                              if b then
                                b[4]=b;
                                b[5]=c[d];
                                b[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,b in t,q,nil do
                            local o=b[5];
                            if q then
                              b=q[d];
                              if b then
                                local B=w(o);
                                I(c,d,d+o-1,1,B);
                                b[4]=B;
                                b[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]],L[O];
                      end
                    elseif l>=135 then
                      if l~=136 then
                        c[z[O]](c[a[O]],c[P[O]]);
                      else
                        c[a[O]]=f[O]-c[z[O]];
                      end
                    else
                      c[P[O]]=U(c[a[O]]);
                    end
                  else
                    if l<128 then
                      if l>=126 then
                        if l==127 then
                          O=if c[P[O]]<z[O]then a[O]else O;
                        else
                          C=A[P[O]];
                          C[4][C[6]]=c[a[O]];
                        end
                      else
                        c[P[O]]=z[O]-c[a[O]];
                      end
                    else
                      if l<129 then
                        O=if not(P[O]<c[z[O]])then a[O]else O;
                      else
                        if l~=130 then
                          c[a[O]]=p;
                        else
                          if j then
                            for d in t,j,nil do
                              if j then
                                local b=j[d];
                                if b then
                                  b[4]=b;
                                  b[5]=c[d];
                                  b[6]=5;
                                  j[d]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for d,b in t,q,nil do
                              local o=b[5];
                              if q then
                                b=q[d];
                                if b then
                                  local B=w(o);
                                  I(c,d,d+o-1,1,B);
                                  b[4]=B;
                                  b[6]=1;
                                  q[d]=nil;
                                end
                              end
                            end;
                          end
                          return c[P[O]],y[O],c[z[O]];
                        end
                      end
                    end
                  end
                end
              else
                if l>=112 then
                  if l>=118 then
                    if l>=121 then
                      if l<123 then
                        if l~=122 then
                          C=A[a[O]];
                          C[4][C[6]][L[O]]=f[O];
                        else
                          local d,b,o=P[O],z[O],n[6];
                          local B=W(o[d],187638924);
                          o[d]=B;
                          o,d=n[5],B+1;
                          B=V(o,d);
                          local Q,U;
                          if B<128 then
                            Q,U=B,d+1;
                          else
                            local M=V(o,d+1);
                            if M<128 then
                              Q,U=(B-128)*128+M,d+2;
                            else
                              local sP=V(o,d+2);
                              if sP<128 then
                                Q,U=(B-128)*16384+(M-128)+sP*128,d+3;
                              else
                                local lP=V(o,d+3);
                                Q,U=B-128+(M-128)*2097152+(sP-128)*128+lP%128*16384+(lP-lP%128)*2097152,d+4;
                              end
                            end
                          end
                          B,d=b*16843009,U+Q;
                          local M=d-Q%4;
                          for Q=U,M-1,4 do
                            _(o,Q,(W(X(o,Q),B)));
                          end;
                          for B=M,d-1,1 do
                            x(o,B,(W(V(o,B),b)));
                          end;
                          P[O]=57;
                          z[O]=154;
                          a[O]=215;
                          T[O]=1;
                        end
                      else
                        if l==124 then
                          c[P[O]]=A[a[O]][c[z[O]]];
                        else
                          c[a[O]]=v(f[O],c[z[O]]);
                        end
                      end
                    else
                      if l<119 then
                        c[P[O]]();
                      elseif l==120 then
                        local d,b,o=z[O],y[O],f[O];
                        local B,Q=h(b,4294967295),h(o,4294967295);
                        local b,o,U,M=h(B,65535),F(B,16),h(Q,65535),F(Q,16);
                        Q=h(b*U+k(h(b*M+o*U,65535),16),4294967295);
                        b=nil;
                        repeat
                          U=Q%4294967296;
                          if U~=U then
                            b=0;
                            break;
                          end
                          b=U-U%1;
                        until true;
                        c[d]=b;
                      else
                        if j then
                          for d in t,j,nil do
                            if j then
                              local b=j[d];
                              if b then
                                b[4]=b;
                                b[5]=c[d];
                                b[6]=5;
                                j[d]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for d,b in t,q,nil do
                            local o=b[5];
                            if q then
                              b=q[d];
                              if b then
                                local B=w(o);
                                I(c,d,d+o-1,1,B);
                                b[4]=B;
                                b[6]=1;
                                q[d]=nil;
                              end
                            end
                          end;
                        end
                        return y[O],L[O];
                      end
                    end
                  else
                    if l<115 then
                      if l>=113 then
                        if l==114 then
                          c[P[O]]=W(y[O],c[z[O]]);
                        else
                          c[z[O]]=c[P[O]]>=y[O];
                        end
                      else
                        local d;
                        local b=L[O];
                        if b then
                          local o=#b/3;
                          if o>0 then
                            d={};
                            local B,Q=j,q;
                            for U=1,o,1 do
                              local o=(U-1)*3;
                              local M,sP=b[o+3],b[o+2];
                              if M==2 then
                                B=if not B then{}else B;
                                local lP=B[sP];
                                if not lP then
                                  lP={[4]=c,[6]=sP};
                                  B[sP]=lP;
                                else
                                end
                                d[U]=lP;
                              else
                                if M==1 then
                                  d[U]=c[sP];
                                else
                                  if M==3 then
                                    d[U]=A[sP];
                                  else
                                    if M==0 then
                                      Q=if not Q then{}else Q;
                                      local M=Q[sP];
                                      if not M then
                                        M={[5]=b[o+1],[6]=sP,[4]=c};
                                        Q[sP]=M;
                                      else
                                      end
                                      d[U]=M;
                                    else
                                    end
                                  end
                                end
                              end
                            end;
                            j,q=B,Q;
                          else
                          end
                        else
                        end
                        c[a[O]]=f[O](nil,d);
                        C=d;
                      end
                    else
                      if l>=116 then
                        if l==117 then
                          c[P[O]][y[O]]=z[O];
                        else
                          c[a[O]]=z;
                        end
                      else
                        local d,b,o=z[O],a[O],c[P[O]];
                        local B,Q=h(b,4294967295),h(o,4294967295);
                        local o,U,M,sP=h(B,65535),F(B,16),h(Q,65535),F(Q,16);
                        B=h(o*M+k(h(o*sP+U*M,65535),16),4294967295);
                        b=nil;
                        repeat
                          U=B%4294967296;
                          if U~=U then
                            b=0;
                            break;
                          end
                          b=U-U%1;
                        until true;
                        c[d]=b;
                      end
                    end
                  end
                else
                  if l<106 then
                    if l<103 then
                      if l<101 then
                        c[a[O]]=W(c[P[O]],z[O]);
                      else
                        if l~=102 then
                          C=c[P[O]];
                          c[z[O]]=E(i(C,a[O],C.n));
                        else
                          c[a[O]]=c[z[O]]%P[O];
                        end
                      end
                    else
                      if l>=104 then
                        if l~=105 then
                          O=if c[P[O]]~=c[a[O]]then z[O]else O;
                        else
                          H=D;
                          D,C,Z={[5]=e,[8]=G,[6]=H,[9]=J},z[O],R(g);
                          Z(s,c[C],c[C+1],c[C+2]);
                          O,J=a[O],Z;
                        end
                      else
                        local H,d,b=z[O],W(a[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];
                        local o=W(b[H],187638924);
                        b[H]=o;
                        H,b=n[5],o+1;
                        o=V(H,b);
                        local B,Q;
                        if o<128 then
                          B,Q=o,b+1;
                        else
                          local R=V(H,b+1);
                          if R<128 then
                            B,Q=(o-128)*128+R,b+2;
                          else
                            local g=V(H,b+2);
                            if g<128 then
                              B,Q=(o-128)*16384+(R-128)+g*128,b+3;
                            else
                              local U=V(H,b+3);
                              B,Q=o-128+(R-128)*2097152+(g-128)*128+U%128*16384+(U-U%128)*2097152,b+4;
                            end
                          end
                        end
                        b,o=d*16843009,Q+B;
                        local R=o-B%4;
                        for B=Q,R-1,4 do
                          _(H,B,(W(X(H,B),b)));
                        end;
                        for b=R,o-1,1 do
                          x(H,b,(W(V(H,b),d)));
                        end;
                        z[O]=143;
                        a[O]=3;
                        P[O]=245;
                        T[O]=1;
                      end
                    end
                  else
                    if l>=109 then
                      if l>=110 then
                        if l~=111 then
                          C,Z,r,N=W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],P[O],z[O];
                          S=Z<16384 and 7 or(Z<2097152 and 14 or 21);
                          m,Y=h(Z,k(1,S)-1),F(Z,S);
                          T[O]=W(Y,97,(h(F(C,21),127)));
                          z[O]=W(N,46,(h(C,127)));
                          a[O]=W(m,29,(h(F(C,7),127)));
                          P[O]=W(r,5,(h(F(C,14),127)));
                          O=O-1;
                        else
                          c[a[O]]=c[P[O]]//c[z[O]];
                        end
                      else
                        c[P[O]]=c[z[O]]/a[O];
                      end
                    else
                      if l>=107 then
                        if l==108 then
                          c[a[O]]=c[z[O]]();
                        else
                          c[P[O]]=h(c[a[O]],L[O]);
                        end
                      else
                        c[z[O]]=c[a[O]]>P[O];
                      end
                    end
                  end
                end
              end
            end
          else
            if l<50 then
              if l>=25 then
                if l<37 then
                  if l>=31 then
                    if l>=34 then
                      if l>=35 then
                        if l~=36 then
                          if j then
                            for H in t,j,nil do
                              if j then
                                local d=j[H];
                                if d then
                                  d[4]=d;
                                  d[5]=c[H];
                                  d[6]=5;
                                  j[H]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for H,d in t,q,nil do
                              local b=d[5];
                              if q then
                                d=q[H];
                                if d then
                                  local o,B=H+b-1,w(b);
                                  I(c,H,o,1,B);
                                  d[4]=B;
                                  d[6]=1;
                                  q[H]=nil;
                                end
                              end
                            end;
                          end
                          C=a[O];
                          return i(c,C,C+z[O]-1);
                        else
                          c[P[O]]=c[a[O]]~=z[O];
                        end
                      else
                        C,Z,r=a[O],P[O],z[O];
                        N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));
                        I(m,1,r,C,c);
                      end
                    else
                      if l>=32 then
                        if l~=33 then
                          u[f[O]]=c[z[O]];
                        else
                          c[P[O]][a[O]]=L[O];
                        end
                      else
                        c[z[O]]=T;
                      end
                    end
                  else
                    if l>=28 then
                      if l<29 then
                        local H,d,b=P[O],a[O],L[O];
                        local o,B=h(d,4294967295),h(b,4294967295);
                        local d,b,V,_=h(o,65535),F(o,16),h(B,65535),F(B,16);
                        B=h(d*V+k(h(d*_+b*V,65535),16),4294967295);
                        b=nil;
                        repeat
                          d=B%4294967296;
                          if d~=d then
                            b=0;
                            break;
                          end
                          b=d-d%1;
                        until true;
                        c[H]=b;
                      else
                        if l~=30 then
                          c[P[O]]=n;
                        else
                          J,G=D[9],D[8];
                          e,D=D[5],D[6];
                        end
                      end
                    else
                      if l>=26 then
                        if l~=27 then
                          O=if not(c[z[O]]<c[a[O]])then P[O]else O;
                        else
                          c[z[O]]=A[P[O]];
                        end
                      else
                        Z,C=(W(a[O],(h(W(p,(h(F(p,29),7))),536870911)))),z[O]+1;
                        for H=1,P[O],1 do
                          Z=h(W(Z,(k(Z,13))),536870911);
                          Z=W(Z,(F(Z,13)));
                          Z=h(W(Z,(k(Z,14))),536870911);
                          z[C]=W(z[C],(h(F(Z,0),127)));
                          a[C]=W(a[C],(h(F(Z,7),127)));
                          P[C]=W(P[C],(h(F(Z,14),127)));
                          T[C]=W(T[C],(h(F(Z,21),127)));
                          C=C+1;
                        end;
                        T[O]=1;
                      end
                    end
                  end
                else
                  if l<43 then
                    if l>=40 then
                      if l<41 then
                        c[P[O]]=z[O]+c[a[O]];
                      elseif l==42 then
                        c[P[O]][c[a[O]]]=z[O];
                      else
                        c[a[O]]=c[P[O]]<z[O];
                      end
                    elseif l>=38 then
                      if l==39 then
                        local H,d,b=a[O],c[P[O]],z[O];
                        local D,o=h(d,4294967295),h(b,4294967295);
                        local B,V,_,X=h(D,65535),F(D,16),h(o,65535),F(o,16);
                        d=h(B*_+k(h(B*X+V*_,65535),16),4294967295);
                        o=nil;
                        repeat
                          b=d%4294967296;
                          if b~=b then
                            o=0;
                            break;
                          end
                          o=b-b%1;
                        until true;
                        c[H]=o;
                      else
                        c[z[O]]=v(c[P[O]],c[a[O]]);
                      end
                    else
                      c[P[O]]=h(y[O],c[z[O]]);
                    end
                  else
                    if l>=46 then
                      if l>=48 then
                        if l==49 then
                          c[a[O]]=c[P[O]]<c[z[O]];
                        else
                          A[a[O]][f[O]]=z[O];
                        end
                      elseif l==47 then
                        c[z[O]]=c[P[O]]~=y[O];
                      else
                        c[P[O]]=h(c[a[O]],c[z[O]]);
                      end
                    else
                      if l>=44 then
                        if l~=45 then
                          c[z[O]]=c[a[O]+c[P[O]]];
                        else
                          C=z[O];
                          local H,d,b=J();
                          if H then
                            c[C+1]=d;
                            c[C+2]=b;
                            O=P[O];
                          else
                          end
                          Z,r,N=H,d,b;
                        end
                      else
                        O=if c[P[O]]<=c[z[O]]then a[O]else O;
                      end
                    end
                  end
                end
              else
                if l<12 then
                  if l<6 then
                    if l<3 then
                      if l>=1 then
                        if l==2 then
                          c[P[O]]=n;
                          c[P[O+1]]=a;
                          c[a[O+2]]=z;
                          c[z[O+3]]=T;
                          c[z[O+4]]=P;
                          O+=4;
                        else
                        end
                      else
                        c[a[O]]=c[z[O]]~=c[P[O]];
                      end
                    else
                      if l<4 then
                        c[z[O]]=c[P[O]]-a[O];
                      elseif l==5 then
                        c[z[O]]=c[P[O]](y[O]);
                      else
                        c[a[O]]=s[f[O]];
                      end
                    end
                  else
                    if l<9 then
                      if l<7 then
                        c[a[O]]=c[z[O]]>=c[P[O]];
                      else
                        if l==8 then
                          c[P[O]]=u[L[O]];
                        else
                          C,Z,r,N=z[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],P[O];
                          S=N<2097152 and 7 or 14;
                          m,Y=h(N,k(1,S)-1),F(N,S);
                          T[O]=W(Y,82,(h(F(Z,21),127)));
                          P[O]=W(m,75,(h(F(Z,14),127)));
                          a[O]=W(r,46,(h(F(Z,7),127)));
                          z[O]=W(C,72,(h(Z,127)));
                          O=O-1;
                        end
                      end
                    else
                      if l<10 then
                        c[P[O]]=E(c[z[O]]());
                      else
                        if l==11 then
                          c[P[O]](c[z[O]],y[O]);
                        else
                          p=c[P[O]];
                        end
                      end
                    end
                  end
                else
                  if l<18 then
                    if l<15 then
                      if l<13 then
                        c[a[O]]=A[P[O]][L[O]];
                      else
                        if l~=14 then
                          A[P[O]][y[O]]=c[z[O]];
                        else
                          O=if c[P[O]]==y[O]then z[O]else O;
                        end
                      end
                    else
                      if l<16 then
                        if j then
                          for s in t,j,nil do
                            if j then
                              local n=j[s];
                              if n then
                                n[4]=n;
                                n[5]=c[s];
                                n[6]=5;
                                j[s]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for s,n in t,q,nil do
                            local H=n[5];
                            if q then
                              n=q[s];
                              if n then
                                local d,Y=s+H-1,w(H);
                                I(c,s,d,1,Y);
                                n[4]=Y;
                                n[6]=1;
                                q[s]=nil;
                              end
                            end
                          end;
                        end
                        return c[z[O]](i(c[a[O]],1,c[a[O]].n));
                      elseif l==17 then
                        c[P[O]]=c[a[O]]*z[O];
                      else
                        A[z[O]][c[P[O]]]=c[a[O]];
                      end
                    end
                  else
                    if l>=21 then
                      if l<23 then
                        if l~=22 then
                          c[P[O]](c[a[O]],i(c[z[O]],1,c[z[O]].n));
                        else
                          c[P[O]]={};
                        end
                      elseif l==24 then
                        if j then
                          for s in t,j,nil do
                            if j then
                              local n=j[s];
                              if n then
                                n[4]=n;
                                n[5]=c[s];
                                n[6]=5;
                                j[s]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for s,n in t,q,nil do
                            local H=n[5];
                            if q then
                              n=q[s];
                              if n then
                                local d=w(H);
                                I(c,s,s+H-1,1,d);
                                n[4]=d;
                                n[6]=1;
                                q[s]=nil;
                              end
                            end
                          end;
                        end
                        return c[P[O]];
                      else
                        c[P[O]]=c[z[O]]+y[O];
                      end
                    else
                      if l>=19 then
                        if l==20 then
                          C,Z,r=P[O],a[O],z[O];
                          N,S=c[C],C+Z;
                          m=c[S];
                          I(c,C+1,S-1,r+1,N);
                          I(m,1,m.n,r+Z,N);
                        else
                          C=A[z[O]];
                          c[P[O]]=C[4][C[6]];
                        end
                      else
                        c[P[O]]=a;
                      end
                    end
                  end
                end
              end
            else
              if l<75 then
                if l<62 then
                  if l>=56 then
                    if l<59 then
                      if l<57 then
                        O=z[O];
                      else
                        if l~=58 then
                          A[a[O]][L[O]]=f[O];
                        else
                          c[a[O]]=c[z[O]]/c[P[O]];
                        end
                      end
                    else
                      if l>=60 then
                        if l==61 then
                          O=if not c[a[O]]then P[O]else z[O];
                        else
                          c[a[O]]=P[O]*c[z[O]];
                        end
                      else
                        c[P[O]][c[z[O]]]=c[a[O]];
                      end
                    end
                  else
                    if l<53 then
                      if l<51 then
                        c[z[O]]=F(c[P[O]],a[O]);
                      else
                        if l~=52 then
                          C,Z,r=z[O],a[O],P[O];
                          N=c[C];
                          I(c,C+1,C+Z,r+1,N);
                        else
                          c[z[O]]=u[f[O]][y[O]];
                        end
                      end
                    else
                      if l>=54 then
                        if l~=55 then
                          K=c[P[O]];
                        else
                          c[a[O]]=c[P[O]]==z[O];
                        end
                      else
                        if j then
                          for s in t,j,nil do
                            if j then
                              local n=j[s];
                              if n then
                                n[4]=n;
                                n[5]=c[s];
                                n[6]=5;
                                j[s]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for s,n in t,q,nil do
                            local H=n[5];
                            if q then
                              n=q[s];
                              if n then
                                local d,Y=s+H,w(H);
                                I(c,s,d-1,1,Y);
                                n[4]=Y;
                                n[6]=1;
                                q[s]=nil;
                              end
                            end
                          end;
                        end
                        return c[z[O]](c[a[O]],c[P[O]]);
                      end
                    end
                  end
                else
                  if l>=68 then
                    if l>=71 then
                      if l<73 then
                        if l==72 then
                          c[P[O]]=c[z[O]]+c[a[O]];
                        else
                          c[z[O]](y[O],f[O]);
                        end
                      else
                        if l~=74 then
                          J+=e;
                          C=if e<=0 then J>=G else J<=G;
                          if C then
                            c[a[O]]=J;
                            O=P[O];
                          else
                          end
                        else
                          if j then
                            for s in t,j,nil do
                              if j then
                                local n=j[s];
                                if n then
                                  n[4]=n;
                                  n[5]=c[s];
                                  n[6]=5;
                                  j[s]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for s,n in t,q,nil do
                              local J=n[5];
                              if q then
                                n=q[s];
                                if n then
                                  local H,d=s+J-1,w(J);
                                  I(c,s,H,1,d);
                                  n[4]=d;
                                  n[6]=1;
                                  q[s]=nil;
                                end
                              end
                            end;
                          end
                          return c[a[O]],c[P[O]];
                        end
                      end
                    else
                      if l<69 then
                        O=if c[P[O]]==a[O]then z[O]else O;
                      else
                        if l==70 then
                          Z,C=(W(a[O],(h(W(K,(h(F(K,29),7))),536870911)))),z[O]+1;
                          for s=1,P[O],1 do
                            Z=h(W(Z,(k(Z,13))),536870911);
                            Z=W(Z,(F(Z,13)));
                            Z=h(W(Z,(k(Z,14))),536870911);
                            z[C]=W(z[C],(h(F(Z,0),127)));
                            a[C]=W(a[C],(h(F(Z,7),127)));
                            P[C]=W(P[C],(h(F(Z,14),127)));
                            T[C]=W(T[C],(h(F(Z,21),127)));
                            C=C+1;
                          end;
                          T[O]=1;
                        else
                          c[a[O]]=c[z[O]]//P[O];
                        end
                      end
                    end
                  else
                    if l>=65 then
                      if l>=66 then
                        if l~=67 then
                          c[z[O]]=W(c[P[O]],y[O]);
                        else
                          C=A[a[O]];
                          c[z[O]]=C[4][C[6]][f[O]];
                        end
                      else
                        c[z[O]]=c[P[O]]%c[a[O]];
                      end
                    else
                      if l<63 then
                        c[P[O]]=c[z[O]]-y[O];
                      else
                        if l==64 then
                          c[a[O]]=P[O];
                        else
                          C=A[P[O]];
                          C[4][C[6]]=y[O];
                        end
                      end
                    end
                  end
                end
              else
                if l>=87 then
                  if l>=93 then
                    if l>=96 then
                      if l>=98 then
                        if l==99 then
                          if j then
                            for s in t,j,nil do
                              if j then
                                local T=j[s];
                                if T then
                                  T[4]=T;
                                  T[5]=c[s];
                                  T[6]=5;
                                  j[s]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for s,T in t,q,nil do
                              local n=T[5];
                              if q then
                                T=q[s];
                                if T then
                                  local J=w(n);
                                  I(c,s,s+n-1,1,J);
                                  T[4]=J;
                                  T[6]=1;
                                  q[s]=nil;
                                end
                              end
                            end;
                          end
                          return c[z[O]](c[P[O]],y[O]);
                        else
                          if j then
                            for s in t,j,nil do
                              if j then
                                local T=j[s];
                                if T then
                                  T[4]=T;
                                  T[5]=c[s];
                                  T[6]=5;
                                  j[s]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for s,T in t,q,nil do
                              local n=T[5];
                              if q then
                                T=q[s];
                                if T then
                                  local J=w(n);
                                  I(c,s,s+n-1,1,J);
                                  T[4]=J;
                                  T[6]=1;
                                  q[s]=nil;
                                end
                              end
                            end;
                          end
                          return c[z[O]],f[O],y[O];
                        end
                      elseif l==97 then
                        c[z[O]]=F(c[P[O]],c[a[O]]);
                      else
                        if j then
                          for s in t,j,nil do
                            if j then
                              local T=j[s];
                              if T then
                                T[4]=T;
                                T[5]=c[s];
                                T[6]=5;
                                j[s]=nil;
                              end
                            end
                          end;
                        end
                        if q then
                          for s,T in t,q,nil do
                            local n=T[5];
                            if q then
                              T=q[s];
                              if T then
                                local J=w(n);
                                I(c,s,s+n-1,1,J);
                                T[4]=J;
                                T[6]=1;
                                q[s]=nil;
                              end
                            end
                          end;
                        end
                        return L[O],c[P[O]],y[O];
                      end
                    elseif l>=94 then
                      if l~=95 then
                        c[P[O]][y[O]]=c[z[O]];
                      else
                        c[P[O]]=h(c[a[O]],z[O]);
                      end
                    else
                      c[P[O]]=E(c[z[O]](i(c[a[O]],1,c[a[O]].n)));
                    end
                  else
                    if l<90 then
                      if l>=88 then
                        if l~=89 then
                          c[P[O]][z[O]]=c[a[O]];
                        else
                          O=if c[P[O]]~=L[O]then a[O]else O;
                        end
                      else
                        c[a[O]](L[O]);
                      end
                    else
                      if l>=91 then
                        if l==92 then
                          c[a[O]](L[O],i(c[P[O]],1,c[P[O]].n));
                        else
                          c[z[O]]=h(a[O],c[P[O]]);
                        end
                      else
                        c[z[O]]=c[a[O]]-c[P[O]];
                      end
                    end
                  end
                else
                  if l<81 then
                    if l<78 then
                      if l>=76 then
                        if l==77 then
                          c[z[O]](i(c[a[O]],1,c[a[O]].n));
                        else
                          c[P[O]]=c[z[O]](i(c[a[O]],1,c[a[O]].n));
                        end
                      else
                        u[f[O]]=L[O];
                      end
                    elseif l>=79 then
                      if l==80 then
                        c[a[O]]=c[z[O]][f[O]];
                      else
                        c[P[O]]=K;
                      end
                    else
                      c[a[O]]=E(c[P[O]](c[z[O]]));
                    end
                  else
                    if l<84 then
                      if l>=82 then
                        if l==83 then
                          C=A[P[O]];
                          c[z[O]]=C[4][C[6]][c[a[O]]];
                        else
                          if j then
                            for s in t,j,nil do
                              if j then
                                local y=j[s];
                                if y then
                                  y[4]=y;
                                  y[5]=c[s];
                                  y[6]=5;
                                  j[s]=nil;
                                end
                              end
                            end;
                          end
                          if q then
                            for s,y in t,q,nil do
                              local T=y[5];
                              if q then
                                y=q[s];
                                if y then
                                  local n=w(T);
                                  I(c,s,s+T-1,1,n);
                                  y[4]=n;
                                  y[6]=1;
                                  q[s]=nil;
                                end
                              end
                            end;
                          end
                          return;
                        end
                      else
                        c[P[O]]=not c[z[O]];
                      end
                    else
                      if l<85 then
                        c[a[O]]=c[z[O]]+P[O];
                      elseif l~=86 then
                        c[a[O]]=c[P[O]]>L[O];
                      else
                        c[a[O]]=c[P[O]];
                      end
                    end
                  end
                end
              end
            end
          end
          O=O+1;
        end;
      end
    end;
  end;
end
