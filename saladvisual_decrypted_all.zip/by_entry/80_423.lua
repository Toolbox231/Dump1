-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #423
-- offset 3422210..3422623 (413 bytes, type=code)

local function gP(uP)
  local JC,HC,fC=s[87](),lC[l[464]][l[636]]/y[29],j(LC)[l[636]]+l[310];
  local aC=JC[l[1346]][l[23]](yC[l[1072]],uP);
  if not aC or HC<=l[393]or fC<=HC then
    return;
  end
  uP,fC=l[1158]+(aC-l[229])*_P,lC[l[1690]][l[636]];
  if uP<fC then
    lC[l[1690]]=JC[l[1689]][l[772]](l[393],JC[l[35]][l[850]](uP-l[1158],l[393]));
  elseif uP+l[1660]>fC+HC then
    lC[l[1690]]=JC[l[1689]][l[772]](l[393],uP+l[1596]--[[__newindex]]-HC);
  end
end
