-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #60
-- offset 3277401..3277893 (492 bytes, type=code)

function(X)
  local Q,t,R=s[87](),not k;
  if t then
    R=t;
  else
    local k=S;
    R=k>l[393];
  end
  if R then
    return;
  end
  t=E;
  if t then
    R=E;
    if X~=R then
      return;
    end
  elseif X[l[1317]]~=Q[l[128]][l[1317]][l[765]] then
    return;
  end
  local k,g,u=X[l[948]]-v,Q[l[1459]][l[772]],i;
  R,t,X=u[l[1437]][l[1609]],Q[l[35]][l[499]],i;
  local v,U=t(X[l[1437]][l[1485]]+k[l[1437]]),i;
  t,X,u=U[l[636]][l[1609]],Q[l[35]][l[499]],i;
  local i,Q=g(R,v,t,X(u[l[636]][l[1485]]+k[l[636]])),E;
  if Q then
    x[l[948]]=i;
  else
    P(x,I,{[l[948]]=i});
  end
end
