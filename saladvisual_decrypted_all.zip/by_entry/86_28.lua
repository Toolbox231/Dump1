-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #28
-- offset 3217068..3217298 (230 bytes, type=code)

local function c(m)
  if m.__ready then
    return m.__ready;
  end
  local S,O={},pairs;
  for B,A in O(K)do
    local O=m.files[B];
    if not O then
      return nil;
    end
    B=J;
    local w=B.asset(O);
    if not w then
      return nil;
    end
    S[A]=w;
  end;
  m.__ready=S;
  return S;
end
