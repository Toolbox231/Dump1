-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #136
-- offset 3306242..3306556 (314 bytes, type=code)

local function LP()
  local TP={};
  local nP,HP=s[87](),y[9]:GetMouseLocation();
  c[l[948]]=nP[l[1459]][l[588]](HP[l[1437]],HP[l[636]]);
  HP=not y[18][l[583]]and y[9][l[643]]==nP[l[128]][l[643]][l[1081]];
  if c[l[1324]]==HP then
    c[l[1324]]=not HP;
  end
  if y[9][l[1181]]~=HP then
    TP[1]=y[9];
    TP[2]=l[1181];
    TP[1][TP[2]]=HP;
  end
end
