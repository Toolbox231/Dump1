-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[11150] / function #1
-- offset 3258278..3258579 (301 bytes, type=code)

function(s,s,l,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  local z=s[4];
  local T=s[5];
  return function()
    local s=1;
    while true do
      local n=s<=0;
      if n then
        return;
      else
        local n,J=true;
        l[4][l[6]]=n;
        local l,l=L[4][L[6]][nil];
        y[4][y[6]](323027964,4);
        local l,L=352990097;
        z[4][z[6]]=l;
        T[4][T[6]]();
        s=0;
      end
    end;
  end;
end
