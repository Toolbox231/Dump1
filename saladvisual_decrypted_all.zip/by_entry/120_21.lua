-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #21
-- offset 3653237..3653456 (219 bytes, type=code)

local function x(v,I)
  local i=v:FindFirstChild(I,true);
  if i and(i:IsA("BasePart")) then
    return i;
  end
  for i,E in ipairs(C[I]or{})do
    i=v:FindFirstChild(E,true);
    if i and(i:IsA("BasePart")) then
      return i;
    end
  end;
  return nil;
end
