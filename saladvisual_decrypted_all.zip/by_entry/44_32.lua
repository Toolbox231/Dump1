-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #32
-- offset 3623130..3623340 (210 bytes, type=code)

function(y)
  if type(y)~="string"or y=="" then
    s.Style=nil;
    s.Game=nil;
    S();
    return;
  end
  if Z[y]and m(y) then
    s.Style=y;
    s.Game=nil;
  elseif K and K.ById[y]and m(y,K.ById[y].label) then
    s.Game=y;
  else
    s.Game=nil;
  end
  S();
end
