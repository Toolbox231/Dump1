-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #910
-- offset 3571537..3571897 (360 bytes, type=code)

local function m()
  local S=not K;
  if S then
    K=C:tab({[l[572]]=l[28],[l[13]]=l[240]});
    local O=K;
    local B,A=O[l[1674]],K;
    A[l[1674]]=function(O)
      local A=s[87]();
      if B then
        B(O);
      end
      if not O then
        return;
      end
      A[l[1022]][l[1061]](function()
        local O,B=s[87](),c or o[l[788]];
        q=l[383];
        if B then
          O[l[1146]](function()
            B:select();
          end);
        end
        q=l[1329];
      end);
    end;
  end
  S=K;
  return S;
end
