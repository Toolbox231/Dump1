-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #598
-- offset 3487739..3488038 (299 bytes, type=code)

function(n)
  local r=s[87]();
  local function A(w)
    for V,V in y[5](F)do
      if V[l[572]]==w then
        return l[383];
      end
    end;
    return l[1329];
  end
  if not p[l[1693]] then
    return n==l[1746]or A(n);
  end
  for p in r[l[409]][l[78]](n,l[397])do
    if not A(r[l[409]][l[56]](p,l[381])) then
      return l[1329];
    end
  end;
  return l[383];
end
