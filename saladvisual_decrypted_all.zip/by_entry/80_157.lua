-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #157
-- offset 3314990..3315386 (396 bytes, type=code)

local function CP(NP,qP)
  if NP[l[331]]or not NP[l[1600]]and not qP then
    return;
  end
  NP[l[331]]=qP and l[383]or l[1329];
  NP[l[1600]]=l[1329];
  local qP=NP[l[266]][l[1569]];
  b(NP[l[266]],l[120],q,function(bP)
    NP[l[266]][l[1569]]=qP+(l[229]-qP)*bP;
    if bP<l[229] then
      return;
    end
    if NP[l[331]] then
      if NP[l[266]]and NP[l[266]][l[382]] then
        NP[l[266]]:Destroy();
      end
      return;
    end
    NP[l[266]][l[1324]]=l[1329];
  end);
end
