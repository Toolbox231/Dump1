-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #759
-- offset 3537692..3538212 (520 bytes, type=code)

local function B()
  local zP=s[87]();
  if C then
    local JP,HP,fP={},l[1646],t and l[1296]or(yP and l[804]or l[229]);
    JP[HP]=fP;
    P(C,H,JP);
    HP,fP,JP={},l[747],t and l[229]or(yP and l[1296]or l[874]);
    HP[fP]=JP;
    P(R,H,HP);
    P(g,H,{[l[2]]=t and l[393]or l[229],[l[1639]]=zP[l[1459]][l[588]](t and l[310]or l[1158],t and l[310]or l[1158])});
  end
  if u then
    P(u,H,{[l[2]]=yP and l[393]or l[1431],[l[936]]=yP and c[l[1095]]or c[l[1379]]});
  end
  P(sP,H,{[l[916]]=(t or yP)and l[393]or l[615],[l[510]]=(t or yP)and c[l[1095]]or c[l[1379]]});
end
