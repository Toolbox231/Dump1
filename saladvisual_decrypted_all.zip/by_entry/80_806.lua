-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #806
-- offset 3551927..3552968 (1041 bytes, type=code)

local function z(T)
  local T={};
  local n=s[87]();
  if x then
    n[l[1146]](function()
      x[l[405]]=l[1329];
    end);
  end
  n[l[1146]](y[18][l[3]],y[18]);
  n[l[1146]](y[18][l[742]],y[18]);
  local J,H=n[l[1346]][l[822]](y[18][l[1438]]);
  for f,f in y[3],J,H do
    n[l[1146]](function()
      f:kill();
    end);
  end;
  n[l[1346]][l[267]](y[18][l[1438]]);
  T[1]=y[18];
  T[2]=l[630];
  T[3]=l[1329];
  T[1][T[2]]=T[3];
  T[4]=y[18];
  T[5]=l[1478];
  T[6]=(y[18][l[1478]]or l[393])+l[229];
  T[4][T[5]]=T[6];
  T[7]=y[18];
  T[8]=l[1334];
  T[9]=l[1329];
  T[7][T[8]]=T[9];
  T[10]=y[18];
  T[11]=l[921];
  T[12]=l[1329];
  T[10][T[11]]=T[12];
  S=l[393];
  T[13]=y[18];
  T[14]=l[1429];
  T[15]=l[1329];
  T[13][T[14]]=T[15];
  T[16]=y[18];
  T[17]=l[583];
  T[18]=l[1329];
  T[16][T[17]]=T[18];
  n[l[1146]](TP);
  n[l[1146]](lP,nil);
  n[l[1146]](U);
  n[l[1346]][l[267]](M);
  n[l[1346]][l[267]](m);
  n[l[1346]][l[267]](y[18][l[1294]]);
  n[l[1346]][l[267]](y[18][l[752]]);
  for T,T in y[3],y[18][l[673]],nil do
    n[l[1146]](function()
      T:Disconnect();
    end);
  end;
  n[l[1346]][l[267]](y[18][l[673]]);
  n[l[1346]][l[267]](y[18][l[769]]);
  if x then
    n[l[1146]](function()
      x:Destroy();
    end);
  end
end
