-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #63
-- offset 3239007..3239238 (231 bytes, type=code)

local function S(_)
  local k=string.match(tostring(_ or""),"(%d+)");
  _=not k;
  if _ then
    local _;
    local _=d;
    _.new({Title="Models",Content="Invalid ID",Duration=4});
    return;
  end
  U({Name="Model "..k,Id=k,Kind="asset",User=true});
  q();
  sP();
end
