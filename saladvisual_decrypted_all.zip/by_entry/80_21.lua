-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #21
-- offset 3269949..3270384 (435 bytes, type=code)

local function b()
  local D=j or e[l[1569]]>l[984]or not e[l[382]];
  if D then
    return;
  end
  j=l[383];
  N={[l[641]]=e[l[1646]],[l[897]]=e[l[43]],[l[63]]=e[l[711]]};
  C[l[1535]]=e[l[1535]];
  local p,r=l[1646],N;
  C[p]=r[l[641]];
  p,r=l[43],N;
  C[p]=r[l[897]];
  r,p=l[711],N;
  C[r]=p[l[63]];
  p,D=e:GetChildren();
  for r,r in y[3],p,D do
    if q(r) then
      r[l[382]]=C;
    end
  end;
  e[l[1646]]=l[229];
  e[l[43]]=l[1329];
  D,p=l[711],N;
  e[D]=p[l[63]]+l[229];
  C[l[1324]]=e[l[1324]];
end
