-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #856
-- offset 3562722..3562995 (273 bytes, type=code)

local function b(K,o)
  o=o or{};
  local c,m=r(l[405]);
  K=c:toggle({[l[572]]=m,[l[950]]=o[l[1380]]and l[383]or l[1329],[l[925]]=l[383],[l[1013]]=o[l[1315]],[l[1617]]=e(o[l[1315]],o[l[1683]])});
  q[l[947]]=K;
  D=P(K);
  c=D;
  if c then
    m=D;
    m[l[1324]]=l[1329];
  end
  return Y(K,o[l[1315]]);
end
