-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #692
-- offset 3515523..3516176 (653 bytes, type=code)

local function r(B,A,w)
  local F=s[87]();
  local V=a;
  local k=l[1742];
  local i={};
  i[l[1150]]=f();
  i[l[1016]]=F[l[1689]][l[772]](w and l[229]or l[393],l[659]);
  i[l[948]]=F[l[1459]][l[772]](w and l[229]or l[393],B,l[659],l[393]);
  i[l[1639]]=F[l[1459]][l[588]](l[1243],l[1243]);
  i[l[1535]]=C[l[675]];
  i[l[1646]]=l[229];
  i[l[1418]]=l[393];
  i[l[1451]]=y[30](A);
  i[l[936]]=C[l[1379]];
  i[l[2]]=l[986];
  i[l[1557]]=F[l[128]][l[1557]][l[220]];
  i[l[711]]=l[1513];
  local B=V(k,i,T);
  D(B,l[1158]);
  d(B[l[1538]],function()
    P(B,H,{[l[2]]=l[393],[l[936]]=C[l[1095]],[l[1646]]=l[615]});
  end);
  d(B[l[1628]],function()
    P(B,H,{[l[2]]=l[986],[l[936]]=C[l[1379]],[l[1646]]=l[229]});
  end);
  return B;
end
