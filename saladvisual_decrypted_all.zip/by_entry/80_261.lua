-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #261
-- offset 3372650..3372985 (335 bytes, type=code)

local function EP()
  local uP=s[87]();
  for nC=l[229],#tP,l[229]do
    local JC=tP[nC];
    nC=_P[l[649]]==JC[l[572]];
    P(JC[l[1615]],n,{[l[916]]=nC and l[393]or(JC[l[892]]and l[874]or l[323]),[l[510]]=nC and R[l[1095]]or R[l[1379]]});
    if nC and fC then
      P(fC,H,{[l[948]]=uP[l[1459]][l[772]](l[659]*(JC[l[590]]-l[229]),l[59],l[393],l[59])});
    end
  end;
end
