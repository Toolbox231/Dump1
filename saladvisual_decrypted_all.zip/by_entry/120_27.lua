-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #27
-- offset 3655613..3655823 (210 bytes, type=code)

function()
  local t,R=pcall(function()
    local g;
    local g,u=T,T;
    return g.id(u.file("particles/comet_bloom.png"));
  end);
  k=false;
  local T;
  local T=z[4][z[6]]and t;
  if T then
    O=R;
  end
  t=not O;
  if t then
    v=os.clock()+5;
  end
end
