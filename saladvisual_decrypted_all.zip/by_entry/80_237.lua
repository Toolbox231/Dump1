-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #237
-- offset 3353167..3353955 (788 bytes, type=code)

local function AP(wP)
  local FP=s[87]();
  if wP==l[1747]or wP==l[863] then
    if not SP[l[863]] then
      local hP=a(l[1439],{[l[1150]]=f(),[l[948]]=FP[l[1459]][l[588]](l[393],BP),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[229],-BP),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=FP[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[303]},KP);
      local BP=a(l[755],{[l[407]]=FP[l[128]][l[407]][l[537]],[l[536]]=FP[l[740]][l[772]](l[393],l[551])},hP);
      d(BP:GetPropertyChangedSignal(l[996]),function()
        local FP=s[87]();
        hP[l[392]]=FP[l[1459]][l[588]](l[393],j(BP)[l[636]]+l[786]);
      end);
      local BP,FP=l[863],{[l[1594]--[[__index]]]=hP,[l[305]]={}};
      FP[l[668]],SP[BP]=l[393],FP;
      SP[l[229]][l[1594]--[[__index]]][l[1324]]=l[1329];
      SP[l[59]][l[1594]--[[__index]]][l[1324]]=l[1329];
    end
    return SP[l[863]];
  end
  return SP[(wP==l[1316]or wP==l[59])and l[59]or l[229]];
end
