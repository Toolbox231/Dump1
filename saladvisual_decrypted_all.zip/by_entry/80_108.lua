-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #108
-- offset 3292765..3293104 (339 bytes, type=code)

local function i(Q)
  local t={};
  local g=s[87]();
  if g[l[40]](y[14])~=l[1712] then
    return l[1329],l[1063];
  end
  local u,zP=g[l[1146]](Q[l[806]],Q);
  if not u or g[l[40]](zP)~=l[409]or zP==l[1746] then
    return l[1329],l[1302];
  end
  t[1]=s[70](g[l[1146]](y[14],zP));
  u=t[1][1];
  Q=t[1][2];
  if not u then
    return l[1329],g[l[1130]](Q);
  end
  return l[383],#zP;
end
