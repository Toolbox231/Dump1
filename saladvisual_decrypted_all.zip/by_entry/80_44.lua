-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #44
-- offset 3274326..3274558 (232 bytes, type=code)

local function m(S)
  local O=s[87]();
  local B=O[l[40]](y[2])==l[1346]and y[2][l[142]]or O[l[1469]]()[l[428]];
  if O[l[40]](B)~=l[1712] then
    return{};
  end
  local A,w=O[l[1146]](B,S);
  if A and O[l[40]](w)==l[1346] then
    return w;
  end
  return{};
end
