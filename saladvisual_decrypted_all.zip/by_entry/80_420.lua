-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #420
-- offset 3421758..3422209 (451 bytes, type=code)

local function nC()
  local JC=UP[l[1569]];
  local HC=yC[l[404]]and l[393]or l[229];
  local fC=gP[l[500]];
  local aC=yC[l[404]]and l[1510]or l[393];
  b(UP,yC[l[404]]and l[894]or l[304],yC[l[404]]and N or q,function(dC)
    local PC=JC+(HC-JC)*dC;
    UP[l[1569]]=PC;
    if RP then
      RP[l[1646]]=PC;
      uP[l[747]]=l[615]+l[411]*PC;
    end
    if dC>=l[229] then
      UP[l[1324]]=yC[l[404]];
      if RP then
        RP[l[1324]]=yC[l[404]];
      end
    end
  end);
  b(gP,l[1431],N,function(uP)
    gP[l[500]]=fC+(aC-fC)*uP;
  end);
end
