-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #724
-- offset 3525241..3525859 (618 bytes, type=code)

local function J(h,Q)
  local zP,PP=s[87](),dP or not y[18][l[630]];
  if PP then
    return;
  end
  Q=Q and l[383]or l[1329];
  if u[l[1600]]==Q then
    return;
  end
  u[l[1600]]=Q;
  PP=aP;
  aP=PP+l[229];
  local ZP=aP;
  y[18]:chime(Q and l[1600]or l[914]);
  PP=eP;
  if PP then
    h=eP;
    h[l[1118]]=E[l[2]];
  end
  if Q then
    CP(l[229]);
    o[l[1324]]=l[383];
    zP[l[1022]][l[1061]](LP);
    b(o,l[894],N,function(h)
      CP(l[229]-h);
    end);
  else
    b(o,l[304],q,function(h)
      CP(h);
      if h>=l[229] then
        o[l[1324]]=l[1329];
        CP(l[393]);
      end
    end);
    zP[l[1022]][l[1330]](l[304],function()
      local h=ZP==aP and not u[l[1600]]and not dP;
      if h then
        GP();
      end
    end);
  end
  if Y[l[1617]] then
    I(Y[l[1617]],Q);
  end
end
