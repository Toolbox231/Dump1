-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #23
-- offset 3602134..3602367 (233 bytes, type=code)

local function E(Q,t,R,g)
  local u,U=t-Q,i();
  U.BackgroundColor3=R;
  U.BackgroundTransparency=0;
  U.Position=UDim2.fromOffset((Q.X+t.X)/2,(Q.Y+t.Y)/2);
  U.Size=UDim2.fromOffset(u.Magnitude+g*0.5,g);
  U.Rotation=math.deg(math.atan2(u.Y,u.X));
end
