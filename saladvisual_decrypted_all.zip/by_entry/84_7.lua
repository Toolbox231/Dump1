-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #7
-- offset 3664997..3665271 (274 bytes, type=code)

local function q(b,D)
  local p,r=pcall(function()
    local K=b:FindFirstChildOfClass("Animator");
    return K and K:GetPlayingAnimationTracks()or b:GetPlayingAnimationTracks();
  end);
  if not p then
    return;
  end
  for b,b in ipairs(r)do
    if b~=D then
      pcall(function()
        b:Stop(0);
      end);
    end
  end;
end
