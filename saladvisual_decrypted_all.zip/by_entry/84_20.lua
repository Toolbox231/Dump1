-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #20
-- offset 3667041..3667453 (412 bytes, type=code)

local function B(w,F)
  for h,W in ipairs(w:GetChildren())do
    if W:IsA("Animation") then
      h=N(W.AnimationId);
      if h then
        local w=(F.."."..W.Name):split(".");
        local V;
        for _ in(F.."."..W.Name):gmatch("[^.]+")do
          local X=_:lower();
          V=if X:find("r15",1,true)then"R15"else if X:find("r6",1,true)then"R6"else V;
        end;
        A[#A+1]={category=w[#w-1],name=w[#w],id=h,rig=V};
      end
    elseif #W:GetChildren()>0 then
      B(W,F.."."..W.Name);
    end
  end;
end
