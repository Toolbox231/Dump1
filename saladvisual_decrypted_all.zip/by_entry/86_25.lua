-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #25
-- offset 3215295..3215784 (489 bytes, type=code)

function(m)
  if p[m] then
    m=p[m];
    K({shader_preset=m});
  else
  end
  local p=m=="Off";
  if p then
    local p=y;
    p.ShaderLighting=nil;
    p=y;
    local S=p.ApplyLighting;
    if S then
      p=y;
      p.ApplyLighting();
    end
    K({shader_bloom=false,shader_rays=false,shader_blur=false,shader_grade=false,shader_atmosphere=false});
    f.Enabled=false;
    a.Enabled=false;
    d.Enabled=false;
    P.Enabled=false;
    Z.On=false;
    Z.Glare,Z.Decay=0,q(106,112,125);
    Z.Offset=nil;
    C();
    o(nil);
    p=y;
    S=p.ApplyGrade;
    if S then
      pcall(y.ApplyGrade);
    end
    return;
  end
  T(m);
end
