-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #40
-- offset 3273457..3274046 (589 bytes, type=code)

local function m(S)
  local O={};
  local B,A=s[87](),c;
  if A then
    return nil;
  end
  local w=l[1329];
  local F,h=l[1329];
  B[l[1022]][l[281]](function()
    local W=s[87]();
    local V,_=W[l[1146]](S);
    W=not F;
    if W then
      h=V and _ or nil;
      w=l[383];
    end
  end);
  A=B[l[655]][l[1587]]()+l[1525];
  while true do
    local S=not w and y[18][l[630]]~=l[1329];
    if not(S and B[l[655]][l[1587]]()<A) then
      break;
    end
    B[l[1022]][l[153]](l[182]);
  end;
  A=not w or y[18][l[630]]==l[1329];
  if A then
    F=l[383];
    B=not w and y[18][l[630]]~=l[1329];
    if B then
      c=l[383];
      O[1]=y[18];
      O[2]=l[1032];
      O[3]=l[847];
      O[1][O[2]]=O[3];
    end
    return nil;
  end
  return h;
end
