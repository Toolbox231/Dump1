-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #690
-- offset 3513480..3513801 (321 bytes, type=code)

local function n(G)
  local Y=s[87]();
  local j=Y[l[1469]]();
  local C={j[l[1507]]and j[l[1507]][l[1055]],j[l[904]]and j[l[904]][l[1744]]and j[l[904]][l[1744]][l[1055]],j[l[1744]]and j[l[1744]][l[1055]]};
  for p,r in y[3],C,nil do
    if Y[l[40]](r)==l[1712] then
      p,j=Y[l[1146]](r,G);
      if p and j then
        return j;
      end
    end
  end;
  return nil;
end
