-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #355
-- offset 3399223..3399423 (200 bytes, type=code)

local function zC()
  local TC=wP[l[850]]-wP[l[457]];
  local nC=TC>l[393]and(gP[l[1019]]-wP[l[457]])/TC or l[393];
  IP[l[1420]]=lC(gP[l[1019]]);
  local TC,JC=UP and J or n,{};
  JC[l[1639]]=yC(nC);
  P(tP,TC,JC);
end
