-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #468
-- offset 3444975..3445406 (431 bytes, type=code)

local function FP()
  local xP,vP,RP,gP,uP=s[87](),G(YP),e(YP),G(kP),e(kP);
  local UP,nC=gP[l[1437]]-vP[l[1437]]+uP[l[1437]]-aP,lC[l[771]]and gP[l[636]]-vP[l[636]]-l[1158]or gP[l[636]]-vP[l[636]]+uP[l[636]]+l[1158];
  UP=if UP+aP>RP[l[1437]]-l[930]then RP[l[1437]]-l[930]-aP else UP;
  QP[l[948]]=xP[l[1459]][l[588]](xP[l[35]][l[499]](xP[l[35]][l[850]](UP,l[930])+l[659]),xP[l[35]][l[499]](nC+l[659]));
  if EP then
    EP[l[948]]=QP[l[948]];
  end
end
