-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #394
-- offset 3411043..3411264 (221 bytes, type=code)

function(lC)
  local LC=s[87]();
  vP[l[1639]]=LC[l[1459]][l[772]](l[229],l[1026],l[393],LC[l[35]][l[499]](RP+(gP-RP)*lC+l[659]));
  WP[l[1639]]=LC[l[1459]][l[772]](l[229],l[393],l[393],LC[l[35]][l[499]](uP+(UP-uP)*lC+l[659]));
end
