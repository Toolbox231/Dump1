-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #46
-- offset 3608876..3609568 (692 bytes, type=code)

function(L)
  local a=not q.Visible;
  if a then
    o=1/0;
    return;
  end
  a=n;
  local N=a.NeedsRefresh and not V;
  if N then
    pcall(n.Refresh);
  end
  N=n;
  local S,O=N.PaintPending;
  if S then
    N=n;
    O=N.Paint;
  else
    O=S;
  end
  if O then
    pcall(n.Paint);
  end
  O=f and os.clock()-e>0.4 and not Z.configApplying;
  if O then
    f=false;
    pcall(n.Refresh);
  end
  o+=L;
  O=T.AbsoluteSize;
  S=o>0.3 or s~=J or m~=j or O~=C or A~=D or w~=r or F~=K;
  if S then
    J,j,C,D,r,K,o=s,m,O,A,w,F,0;
    k();
    R();
  end
  z+=L;
  a=H and 0.35+math.sin(z*2)*0.06 or 1;
  O=G.ImageTransparency+(a-G.ImageTransparency)*math.min(L*6,1);
  O=if not H and 1-O<0.001 then 1 else O;
  if G.ImageTransparency~=O then
    G.ImageTransparency=O;
  end
  S=G.ImageColor3~=Y;
  if S then
    G.ImageColor3=Y;
  end
end
