-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[106] / function #6
-- offset 3636610..3637046 (436 bytes, type=code)

local function L(j,C,N)
  if j:IsA("BasePart")and C:IsA("BasePart")and j.Name~="HumanoidRootPart"and j.Transparency<1 then
    N[#N+1]={source=j,clone=C,baseTransparency=j.Transparency};
  end
  local q={};
  for b,D in ipairs(j:GetChildren())do
    b=D.ClassName.."\0"..D.Name;
    q[b]=(q[b]or 0)+1;
    local j=q[b];
    for q,q in ipairs(C:GetChildren())do
      if q.ClassName==D.ClassName and q.Name==D.Name then
        j-=1;
        if j==0 then
          L(D,q,N);
          break;
        end
      else
      end
    end;
  end;
end
