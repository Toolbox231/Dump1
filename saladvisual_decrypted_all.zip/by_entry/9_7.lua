-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #7
-- offset 3630049..3630357 (308 bytes, type=code)

local function F()
  local h;
  local h=z[4][z[6]]and P and Z and m();
  if not h then
    return;
  end
  h=a:FindFirstChild("PlayerGui");
  local W=h and(h:FindFirstChild("GameTopbar"));
  h=W and(W:FindFirstChild("Crosshair"));
  W=h and(h:IsA("GuiObject"));
  if W then
    if A[h]==nil then
      A[h]=h.Visible;
    end
    Y=h;
    h.Visible=false;
  end
end
