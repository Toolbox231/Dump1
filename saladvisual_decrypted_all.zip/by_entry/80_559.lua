-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #559
-- offset 3477522..3477765 (243 bytes, type=code)

local function V()
  local IP=s[87]();
  if not ZC[l[572]] then
    return;
  end
  y[18]:chime(l[1320]);
  local GC=ZC[l[1466]][l[81]];
  IP[l[1022]][l[281]](p[l[1669]],ZC[l[572]],B,GC[l[1437]]+ZC[l[1466]][l[160]][l[1437]]*l[659],GC[l[636]]+l[310],ZC[l[1466]]);
end
