-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #766
-- offset 3541077..3541575 (498 bytes, type=code)

local function Y(R)
  local zP=s[87]();
  if not A[l[630]] then
    return;
  end
  local JP,HP=E[l[81]],E[l[160]];
  if HP[l[1437]]<=l[393] then
    return;
  end
  local fP=j+(B-j)*zP[l[35]][l[819]]((R-JP[l[1437]])/HP[l[1437]],l[393],l[229]);
  R=zP[l[35]][l[819]](j+zP[l[35]][l[499]]((fP-j)/h+l[659])*h,j,B);
  if Q>l[393] then
    fP=l[730]^Q;
    R=zP[l[35]][l[499]](R*fP+l[659])/fP;
  else
  end
  JP=t;
  if R==JP then
    return;
  end
  t=R;
  yP();
  HP=zP[l[40]](C[l[1617]])==l[1712];
  if HP then
    I(function(j)
      if A[l[630]] then
        C[l[1617]](j);
      end
    end,t);
  end
end
