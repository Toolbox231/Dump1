-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #448
-- offset 3433733..3434061 (328 bytes, type=code)

local function QP()
  P(wP,H,{[l[1646]]=EP and l[393]or l[841]});
  P(XP,H,{[l[747]]=EP and l[330]or l[1373]});
  P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
  P(kP,H,{[l[916]]=EP and l[393]or l[986],[l[510]]=EP and R[l[1095]]or R[l[1379]]});
  if vP then
    P(vP,H,{[l[2]]=EP and l[393]or l[986],[l[936]]=EP and R[l[1095]]or R[l[1379]]});
  end
end
