-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #48
-- offset 3661145..3661499 (354 bytes, type=code)

local function H()
  local f={};
  for a,a in ipairs(l)do
    local Z,G,j=J[a];
    if z then
      Z,G,j=z.Art("builtin/aura/"..a,J[a]);
    else
    end
    local J,q=#f+1,{name=a,label=a,image=Z,rect=G,rectsize=j};
    q.id,f[J]=not G and tonumber(e[a])or nil,q;
  end;
  for J,J in ipairs(z and z.Catalog or{})do
    if J.kind~="Trail"and J.kind~="Cosmetic" then
      f[#f+1]=z.Row(J);
    end
  end;
  return f;
end
