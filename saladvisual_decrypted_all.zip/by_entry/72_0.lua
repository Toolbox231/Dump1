-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[72] / function #0
-- offset 3700841..3701337 (496 bytes, type=code)

function(s,s,s,s)
  return function(s,s)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    return function()
      local s,s;
      local s=l[4][l[6]]or L[4][L[6]];
      if not s then
        return;
      end
      local n;
      s=y;
      local y=s();
      if not y then
        return;
      end
      local n,J,H=l[4][l[6]];
      if n then
        s=nil;
        s,J=z,y.WalkSpeed~=z;
      else
        J=n;
      end
      if J then
        n=z;
        y.WalkSpeed=n;
      end
      J=L[4][L[6]];
      if J then
        if not y.UseJumpPower then
          y.UseJumpPower=true;
        end
        local l;
        n=T;
        s=y.JumpPower~=n;
        if s then
          local s=T;
          y.JumpPower=s;
        end
      end
    end;
  end;
end
