-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #23
-- offset 3213370..3213848 (478 bytes, type=code)

local function o(c)
  local m;
  if c then
    local S=y;
    m=S.SkyLabel;
  else
    m=c;
  end
  local S;
  if m then
    local O=y;
    S=O.SkyLabel(c);
  else
    S=m;
  end
  m=y;
  local O,B=m.Sky;
  if O then
    m=y;
    B=m.Sky.Box;
  else
    B=O;
  end
  c=B or"Off";
  m=c~="Off"and c~=T and c~=S;
  if m then
    T=nil;
    O=y;
    O.PresetSky=nil;
  elseif S then
    T=S;
    B=y;
    B.PresetSky=S;
    local m=c~=S;
    if m then
      local c=y;
      c.SetSkyBox(S);
      K({sky_box=S});
    end
  else
    local c=T;
    if c then
      T=nil;
      local T=y;
      T.PresetSky=nil;
      T=y;
      T.SetSkyBox("Off");
      K({sky_box="Off"});
    end
  end
end
