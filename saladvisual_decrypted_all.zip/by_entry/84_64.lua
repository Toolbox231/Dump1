-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #64
-- offset 3679176..3679551 (375 bytes, type=code)

local function q(b)
  b=b:lower();
  local D=l.EmoteCatalog;
  if b~="" then
    local p,r=b:match("^%d+$"),{};
    for K,K in ipairs(D)do
      if p then
        if tostring(K.id)==b then
          r[#r+1]=K;
        end
      else
        local p,o=j(K.name):lower(),true;
        for c in b:gmatch("%S+")do
          if not p:find(c,1,true) then
            o=false;
            break;
          end
        end;
        if o then
          r[#r+1]=K;
        end
      end
    end;
    l._emoteFilteredList=r;
  else
    l._emoteFilteredList=D;
  end
end
