-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #109
-- offset 3293136..3293478 (342 bytes, type=code)

local function i(Q)
  local t=s[87]();
  if t[l[40]](y[15])~=l[1712] then
    return l[1329],l[1696];
  end
  local g,u=t[l[1146]](y[15]);
  if not g or t[l[40]](u)~=l[409]or u==l[1746] then
    return l[1329],l[1030];
  end
  local g,zP=t[l[1146]](Q[l[324]],Q,u);
  if not g or t[l[40]](zP)~=l[1346] then
    return l[1329],l[446];
  end
  Q[l[1583]]=u;
  Q[l[518]]=zP;
  return l[383];
end
