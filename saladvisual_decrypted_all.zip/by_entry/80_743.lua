-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #743
-- offset 3528253..3528476 (223 bytes, type=code)

function(n,J)
  if not u[l[1600]]or not u[l[1273]]or not R:IsFocused() then
    return;
  end
  J=z(n[l[880]--[[readu32]]]);
  if J==l[579]or J==l[944]or J==l[367]or J==l[1460]or J==l[1436]or J==l[1492]or J==l[701]or J==l[877] then
    g(l[1556]..J);
  end
end
