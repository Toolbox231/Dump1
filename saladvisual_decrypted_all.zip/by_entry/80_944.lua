-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #944
-- offset 3579932..3580522 (590 bytes, type=code)

local function z(n,J)
  n=s[87]();
  J=J or{};
  local G=C:tab({[l[572]]=J[l[1150]]or l[367],[l[13]]=T[l[810]](J[l[79]])});
  if J[l[911]]and G[l[1466]]and G[l[1466]][l[382]] then
    G[l[1466]][l[382]][l[537]]=l[823];
  end
  local j=G[l[1674]];
  G[l[1674]]=function(D)
    if j then
      j(D);
    end
    if D then
      b(G);
    end
  end;
  local j={[l[113]]=G,[l[1150]]=J[l[1150]],[l[901]]=d(G)};
  local function J(D,p)
    p=p or{};
    D={[l[572]]=p[l[1150]]or l[146],[l[1132]]=H(p[l[948]])};
    return a(G:section(D));
  end
  j[l[157]]=J;
  local function J(D)
    if D and G[l[199]] then
      G:select();
    end
  end
  j[l[1629]]=J;
  n[l[1346]][l[968]](P[l[256]],j);
  return f(j);
end
