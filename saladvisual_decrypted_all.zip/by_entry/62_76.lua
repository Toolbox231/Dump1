-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #76
-- offset 3241573..3241802 (229 bytes, type=code)

local function T()
  for K,_ in pairs(G)do
    if K.Parent then
      pcall(function()
        K.LocalTransparencyModifier=_;
      end);
    end
  end;
  for K,_ in pairs(q)do
    if K.Parent then
      pcall(function()
        K.Enabled=_;
      end);
    end
  end;
  table.clear(G);
  table.clear(q);
end
