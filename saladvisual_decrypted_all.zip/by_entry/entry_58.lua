local __fn_0 = function(s,s,s,s)
  return function(s,s,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    local f=s[9];
    local a=s[10];
    local d=s[11];
    local P=s[12];
    local Z=s[13];
    local G=s[14];
    local Y=s[15];
    local e=s[16];
    local j=s[17];
    local C=s[18];
    local N=s[19];
    local q=s[20];
    local b=s[21];
    local D=s[22];
    local p=s[23];
    local r=s[24];
    local K=s[25];
    local o=s[26];
    local c=s[27];
    local m=s[28];
    local S=s[29];
    local O=s[30];
    local B=s[31];
    local A=s[32];
    local w=s[33];
    local F=s[34];
    local h=s[35];
    return function(s)
      local W;
      local W,V,V=l[4][l[6]];
      if W then
        local l=L;
        V=l.On;
      else
        V=W;
      end
      if not V then
        return;
      end
      local l;
      V=y;
      local l,_,X=V.position,y;
      l=if _.playing then l+(os.clock()-z[4][z[6]])else l;
      V=y;
      W=V.duration>0;
      if W then
        V=nil;
        V,l=y,math.min(l,y.duration);
      else
      end
      local z;
      V=T;
      _=V();
      local z;
      W=n;
      W.BackgroundColor3=_;
      local z;
      V=J;
      V.BackgroundColor3=_;
      W,V=J,y;
      W.Visible=V.duration>0;
      local z;
      local z,T=H;
      W=f;
      z.Visible=W.Image=="";
      z=H;
      z.ImageColor3=_;
      z=y;
      W=z.duration>0;
      if W then
        V,z=n;
        z,V.Size=y,UDim2.fromScale(math.clamp(l/y.duration,0,1),1);
      else
        local T=n;
        T.Size=UDim2.fromScale(0,1);
      end
      local T;
      local T,n=a;
      z=d;
      T.Text=z(l);
      local n;
      V,T,W=P,d,y;
      V.Text=T(W.duration);
      V=y;
      local n,J=V.title or"";
      V=n~=Z[4][Z[6]];
      if V then
        Z[4][Z[6]]=n;
        local J;
        z=G;
        z.Text=n;
      end
      W=y;
      z,n=W.status or"",y;
      local J,H=n.artist or"";
      W=Y;
      W.Text=J~=""and J or z;
      local H;
      local H,a=e;
      H.Text=string.upper(j[4][j[6]])..(z~=""and J~=""and" / "..z or"");
      J=e;
      J.TextColor3=_;
      local a;
      n,V=C,y;
      z=n(V.artwork);
      local a;
      H=z~=N[4][N[6]];
      if H then
        local a;
        n,T=q,f;
        n.Image=T.Image;
        J=q;
        J.ImageTransparency=0;
        N[4][N[6]]=z;
        V=f;
        V.Image=z;
        W=f;
        W.ImageTransparency=1;
        local a;
        local a,d=b,f;
        a:Create(d,TweenInfo.new(0.35),{ImageTransparency=0}):Play();
        d,a=b,q;
        d:Create(a,TweenInfo.new(0.35),{ImageTransparency=1}):Play();
      end
      local f;
      W=D;
      W.setGlyph(y.playing and"pause"or"play");
      local f;
      H=p;
      H.setEnabled(y.canSkipPrevious);
      local f;
      z=r;
      z.setEnabled(y.canSkipNext);
      local f;
      H,T=K,y;
      H.Active=T.canSeek;
      local f;
      V=os.clock()-o[4][o[6]]>=0.25;
      if V then
        o[4][o[6]]=os.clock();
      end
      local f;
      local f,a,a,a=V and not c[4][c[6]];
      if f then
        n=m;
        W,J=n.Flags.music_spot,m;
        H,T=J.Flags.music_x,m;
        local a,d=T.Flags.music_y,false;
        if W then
          z=W:GetValue();
          z=if type(z)=="table"then z[1]else z;
          local P,Z=type(z)=="string";
          if P then
            local G=S;
            Z=G[z];
          else
            Z=P;
          end
          P=nil;
          if Z then
            local G=L;
            P=z~=G.Spot;
          else
            P=Z;
          end
          if P then
            Z=L;
            Z.Spot=z;
            d=true;
          else
          end
        else
        end
        if H then
          local P=tonumber(H:GetValue());
          local Z;
          if P then
            local G=L;
            Z=P~=G.OffsetX;
          else
            Z=P;
          end
          if Z then
            local Z=L;
            Z.OffsetX=P;
            d=true;
          else
          end
        else
        end
        if a then
          local P=tonumber(a:GetValue());
          local Z;
          if P then
            local G=L;
            Z=P~=G.OffsetY;
          else
            Z=P;
          end
          if Z then
            local Z=L;
            Z.OffsetY=P;
            d=true;
          else
          end
        else
        end
        if d then
          local d;
          a=O;
          a();
          B[4][B[6]]();
        end
      end
      local a;
      z=V and not A[4][A[6]];
      if z then
        H=m;
        T,f=H.Flags.music_lyrics_spot,m;
        V,n=f.Flags.music_lyrics_x,m;
        W,J=n.Flags.music_lyrics_y,false;
        if T then
          local f=T:GetValue();
          f=if type(f)=="table"then f[1]else f;
          local a,d=type(f)=="string";
          if a then
            local P=S;
            d=P[f];
          else
            d=a;
          end
          a=nil;
          if d then
            local P=L;
            a=f~=P.LyricsSpot;
          else
            a=d;
          end
          if a then
            d=L;
            d.LyricsSpot=f;
            local f=L;
            f.LyricsPlaced=true;
            J=true;
          else
          end
        else
        end
        if V then
          local f=tonumber(V:GetValue());
          local a;
          if f then
            local d=L;
            a=f~=d.LyricsX;
          else
            a=f;
          end
          if a then
            local a=L;
            a.LyricsX=f;
            a=L;
            a.LyricsPlaced=true;
            J=true;
          else
          end
        else
        end
        if W then
          local f=tonumber(W:GetValue());
          local a;
          if f then
            local d=L;
            a=f~=d.LyricsY;
          else
            a=f;
          end
          if a then
            local a=L;
            a.LyricsY=f;
            a=L;
            a.LyricsPlaced=true;
            J=true;
          else
          end
        else
        end
        if J then
          B[4][B[6]]();
        end
      end
      local J;
      V=w;
      V();
      local J;
      n=F;
      n(l,math.min(s,0.1));
      W=L;
      n=W.Visualizer;
      if n then
        local l,L,n=os.clock()*6,ipairs;
        z=h;
        for n,J in L(z)do
          s=J.Visible;
          if s then
            T=y;
            H=T.playing and 5+math.abs(math.sin(l+n*0.9))*11 or 4;
            J.Size=UDim2.fromOffset(3,H);
            J.BackgroundColor3=_;
          end
        end;
      end
    end;
  end;
end;
local __fn_1 = function(s,s,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  local z=s[4];
  local T=s[5];
  local n=s[6];
  local J=s[7];
  local H=s[8];
  local f=s[9];
  local a=s[10];
  local d=s[11];
  local P=s[12];
  local Z=s[13];
  local G=s[14];
  local Y=s[15];
  local e=s[16];
  local j=s[17];
  local C=s[18];
  local N=s[19];
  local q=s[20];
  local b=s[21];
  local D=s[22];
  local p=s[23];
  local r=s[24];
  local K=s[25];
  local o=s[26];
  local c=s[27];
  local m=s[28];
  local S=s[29];
  local O=s[30];
  local B=s[31];
  local A=s[32];
  local w=s[33];
  local F=s[34];
  local h=s[35];
  return function(s)
    local W;
    local W,V,V=l[4][l[6]];
    if W then
      local l=L;
      V=l.On;
    else
      V=W;
    end
    if not V then
      return;
    end
    local l;
    V=y;
    local l,_,X=V.position,y;
    l=if _.playing then l+(os.clock()-z[4][z[6]])else l;
    V=y;
    W=V.duration>0;
    if W then
      V=nil;
      V,l=y,math.min(l,y.duration);
    else
    end
    local z;
    V=T;
    _=V();
    local z;
    W=n;
    W.BackgroundColor3=_;
    local z;
    V=J;
    V.BackgroundColor3=_;
    W,V=J,y;
    W.Visible=V.duration>0;
    local z;
    local z,T=H;
    W=f;
    z.Visible=W.Image=="";
    z=H;
    z.ImageColor3=_;
    z=y;
    W=z.duration>0;
    if W then
      V,z=n;
      z,V.Size=y,UDim2.fromScale(math.clamp(l/y.duration,0,1),1);
    else
      local T=n;
      T.Size=UDim2.fromScale(0,1);
    end
    local T;
    local T,n=a;
    z=d;
    T.Text=z(l);
    local n;
    V,T,W=P,d,y;
    V.Text=T(W.duration);
    V=y;
    local n,J=V.title or"";
    V=n~=Z[4][Z[6]];
    if V then
      Z[4][Z[6]]=n;
      local J;
      z=G;
      z.Text=n;
    end
    W=y;
    z,n=W.status or"",y;
    local J,H=n.artist or"";
    W=Y;
    W.Text=J~=""and J or z;
    local H;
    local H,a=e;
    H.Text=string.upper(j[4][j[6]])..(z~=""and J~=""and" / "..z or"");
    J=e;
    J.TextColor3=_;
    local a;
    n,V=C,y;
    z=n(V.artwork);
    local a;
    H=z~=N[4][N[6]];
    if H then
      local a;
      n,T=q,f;
      n.Image=T.Image;
      J=q;
      J.ImageTransparency=0;
      N[4][N[6]]=z;
      V=f;
      V.Image=z;
      W=f;
      W.ImageTransparency=1;
      local a;
      local a,d=b,f;
      a:Create(d,TweenInfo.new(0.35),{ImageTransparency=0}):Play();
      d,a=b,q;
      d:Create(a,TweenInfo.new(0.35),{ImageTransparency=1}):Play();
    end
    local f;
    W=D;
    W.setGlyph(y.playing and"pause"or"play");
    local f;
    H=p;
    H.setEnabled(y.canSkipPrevious);
    local f;
    z=r;
    z.setEnabled(y.canSkipNext);
    local f;
    H,T=K,y;
    H.Active=T.canSeek;
    local f;
    V=os.clock()-o[4][o[6]]>=0.25;
    if V then
      o[4][o[6]]=os.clock();
    end
    local f;
    local f,a,a,a=V and not c[4][c[6]];
    if f then
      n=m;
      W,J=n.Flags.music_spot,m;
      H,T=J.Flags.music_x,m;
      local a,d=T.Flags.music_y,false;
      if W then
        z=W:GetValue();
        z=if type(z)=="table"then z[1]else z;
        local P,Z=type(z)=="string";
        if P then
          local G=S;
          Z=G[z];
        else
          Z=P;
        end
        P=nil;
        if Z then
          local G=L;
          P=z~=G.Spot;
        else
          P=Z;
        end
        if P then
          Z=L;
          Z.Spot=z;
          d=true;
        else
        end
      else
      end
      if H then
        local P=tonumber(H:GetValue());
        local Z;
        if P then
          local G=L;
          Z=P~=G.OffsetX;
        else
          Z=P;
        end
        if Z then
          local Z=L;
          Z.OffsetX=P;
          d=true;
        else
        end
      else
      end
      if a then
        local P=tonumber(a:GetValue());
        local Z;
        if P then
          local G=L;
          Z=P~=G.OffsetY;
        else
          Z=P;
        end
        if Z then
          local Z=L;
          Z.OffsetY=P;
          d=true;
        else
        end
      else
      end
      if d then
        local d;
        a=O;
        a();
        B[4][B[6]]();
      end
    end
    local a;
    z=V and not A[4][A[6]];
    if z then
      H=m;
      T,f=H.Flags.music_lyrics_spot,m;
      V,n=f.Flags.music_lyrics_x,m;
      W,J=n.Flags.music_lyrics_y,false;
      if T then
        local f=T:GetValue();
        f=if type(f)=="table"then f[1]else f;
        local a,d=type(f)=="string";
        if a then
          local P=S;
          d=P[f];
        else
          d=a;
        end
        a=nil;
        if d then
          local P=L;
          a=f~=P.LyricsSpot;
        else
          a=d;
        end
        if a then
          d=L;
          d.LyricsSpot=f;
          local f=L;
          f.LyricsPlaced=true;
          J=true;
        else
        end
      else
      end
      if V then
        local f=tonumber(V:GetValue());
        local a;
        if f then
          local d=L;
          a=f~=d.LyricsX;
        else
          a=f;
        end
        if a then
          local a=L;
          a.LyricsX=f;
          a=L;
          a.LyricsPlaced=true;
          J=true;
        else
        end
      else
      end
      if W then
        local f=tonumber(W:GetValue());
        local a;
        if f then
          local d=L;
          a=f~=d.LyricsY;
        else
          a=f;
        end
        if a then
          local a=L;
          a.LyricsY=f;
          a=L;
          a.LyricsPlaced=true;
          J=true;
        else
        end
      else
      end
      if J then
        B[4][B[6]]();
      end
    end
    local J;
    V=w;
    V();
    local J;
    n=F;
    n(l,math.min(s,0.1));
    W=L;
    n=W.Visualizer;
    if n then
      local l,L,n=os.clock()*6,ipairs;
      z=h;
      for n,J in L(z)do
        s=J.Visible;
        if s then
          T=y;
          H=T.playing and 5+math.abs(math.sin(l+n*0.9))*11 or 4;
          J.Size=UDim2.fromOffset(3,H);
          J.BackgroundColor3=_;
        end
      end;
    end
  end;
end;
local __fn_2 = function(s)
  local W;
  local W,V,V=l[4][l[6]];
  if W then
    local l=L;
    V=l.On;
  else
    V=W;
  end
  if not V then
    return;
  end
  local l;
  V=y;
  local l,_,X=V.position,y;
  l=if _.playing then l+(os.clock()-z[4][z[6]])else l;
  V=y;
  W=V.duration>0;
  if W then
    V=nil;
    V,l=y,math.min(l,y.duration);
  else
  end
  local z;
  V=T;
  _=V();
  local z;
  W=n;
  W.BackgroundColor3=_;
  local z;
  V=J;
  V.BackgroundColor3=_;
  W,V=J,y;
  W.Visible=V.duration>0;
  local z;
  local z,T=H;
  W=f;
  z.Visible=W.Image=="";
  z=H;
  z.ImageColor3=_;
  z=y;
  W=z.duration>0;
  if W then
    V,z=n;
    z,V.Size=y,UDim2.fromScale(math.clamp(l/y.duration,0,1),1);
  else
    local T=n;
    T.Size=UDim2.fromScale(0,1);
  end
  local T;
  local T,n=a;
  z=d;
  T.Text=z(l);
  local n;
  V,T,W=P,d,y;
  V.Text=T(W.duration);
  V=y;
  local n,J=V.title or"";
  V=n~=Z[4][Z[6]];
  if V then
    Z[4][Z[6]]=n;
    local J;
    z=G;
    z.Text=n;
  end
  W=y;
  z,n=W.status or"",y;
  local J,H=n.artist or"";
  W=Y;
  W.Text=J~=""and J or z;
  local H;
  local H,a=e;
  H.Text=string.upper(j[4][j[6]])..(z~=""and J~=""and" / "..z or"");
  J=e;
  J.TextColor3=_;
  local a;
  n,V=C,y;
  z=n(V.artwork);
  local a;
  H=z~=N[4][N[6]];
  if H then
    local a;
    n,T=q,f;
    n.Image=T.Image;
    J=q;
    J.ImageTransparency=0;
    N[4][N[6]]=z;
    V=f;
    V.Image=z;
    W=f;
    W.ImageTransparency=1;
    local a;
    local a,d=b,f;
    a:Create(d,TweenInfo.new(0.35),{ImageTransparency=0}):Play();
    d,a=b,q;
    d:Create(a,TweenInfo.new(0.35),{ImageTransparency=1}):Play();
  end
  local f;
  W=D;
  W.setGlyph(y.playing and"pause"or"play");
  local f;
  H=p;
  H.setEnabled(y.canSkipPrevious);
  local f;
  z=r;
  z.setEnabled(y.canSkipNext);
  local f;
  H,T=K,y;
  H.Active=T.canSeek;
  local f;
  V=os.clock()-o[4][o[6]]>=0.25;
  if V then
    o[4][o[6]]=os.clock();
  end
  local f;
  local f,a,a,a=V and not c[4][c[6]];
  if f then
    n=m;
    W,J=n.Flags.music_spot,m;
    H,T=J.Flags.music_x,m;
    local a,d=T.Flags.music_y,false;
    if W then
      z=W:GetValue();
      z=if type(z)=="table"then z[1]else z;
      local P,Z=type(z)=="string";
      if P then
        local G=S;
        Z=G[z];
      else
        Z=P;
      end
      P=nil;
      if Z then
        local G=L;
        P=z~=G.Spot;
      else
        P=Z;
      end
      if P then
        Z=L;
        Z.Spot=z;
        d=true;
      else
      end
    else
    end
    if H then
      local P=tonumber(H:GetValue());
      local Z;
      if P then
        local G=L;
        Z=P~=G.OffsetX;
      else
        Z=P;
      end
      if Z then
        local Z=L;
        Z.OffsetX=P;
        d=true;
      else
      end
    else
    end
    if a then
      local P=tonumber(a:GetValue());
      local Z;
      if P then
        local G=L;
        Z=P~=G.OffsetY;
      else
        Z=P;
      end
      if Z then
        local Z=L;
        Z.OffsetY=P;
        d=true;
      else
      end
    else
    end
    if d then
      local d;
      a=O;
      a();
      B[4][B[6]]();
    end
  end
  local a;
  z=V and not A[4][A[6]];
  if z then
    H=m;
    T,f=H.Flags.music_lyrics_spot,m;
    V,n=f.Flags.music_lyrics_x,m;
    W,J=n.Flags.music_lyrics_y,false;
    if T then
      local f=T:GetValue();
      f=if type(f)=="table"then f[1]else f;
      local a,d=type(f)=="string";
      if a then
        local P=S;
        d=P[f];
      else
        d=a;
      end
      a=nil;
      if d then
        local P=L;
        a=f~=P.LyricsSpot;
      else
        a=d;
      end
      if a then
        d=L;
        d.LyricsSpot=f;
        local f=L;
        f.LyricsPlaced=true;
        J=true;
      else
      end
    else
    end
    if V then
      local f=tonumber(V:GetValue());
      local a;
      if f then
        local d=L;
        a=f~=d.LyricsX;
      else
        a=f;
      end
      if a then
        local a=L;
        a.LyricsX=f;
        a=L;
        a.LyricsPlaced=true;
        J=true;
      else
      end
    else
    end
    if W then
      local f=tonumber(W:GetValue());
      local a;
      if f then
        local d=L;
        a=f~=d.LyricsY;
      else
        a=f;
      end
      if a then
        local a=L;
        a.LyricsY=f;
        a=L;
        a.LyricsPlaced=true;
        J=true;
      else
      end
    else
    end
    if J then
      B[4][B[6]]();
    end
  end
  local J;
  V=w;
  V();
  local J;
  n=F;
  n(l,math.min(s,0.1));
  W=L;
  n=W.Visualizer;
  if n then
    local l,L,n=os.clock()*6,ipairs;
    z=h;
    for n,J in L(z)do
      s=J.Visible;
      if s then
        T=y;
        H=T.playing and 5+math.abs(math.sin(l+n*0.9))*11 or 4;
        J.Size=UDim2.fromOffset(3,H);
        J.BackgroundColor3=_;
      end
    end;
  end
end;