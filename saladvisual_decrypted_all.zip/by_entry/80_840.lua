-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #840
-- offset 3559195..3560007 (812 bytes, type=code)

local function d(Z,G)
  local Y,e=s[87](),Z and Z[l[266]];
  if Y[l[1703]](e)~=l[1089] then
    return Z;
  end
  local j,C;
  for N,N in Y[l[1471]](e:GetChildren())do
    if N:IsA(l[1070])and not j then
      j=N;
    else
      C=if N:IsA(l[211])and N[l[656]]then N else C;
    end
  end;
  if G then
    if j then
      j[l[1324]]=l[1329];
    end
    if C then
      C[l[1639]]=Y[l[1459]][l[772]](l[229],l[1026],l[393],l[1243]);
    end
    return Z;
  end
  if j then
    j[l[510]]=J[l[131]][l[1095]];
    j[l[916]]=l[841];
    G=j[l[993]][l[1437]];
    G=if G<=l[393]then#j[l[1420]]*l[1092]else G;
    local N=Y[l[35]][l[819]]((G+l[558])/Y[l[35]][l[850]](l[229],e[l[160]][l[1437]]),l[1431],l[1419]);
    j[l[1639]]=Y[l[1459]][l[772]](N,l[1519],l[229],l[393]);
    if C then
      C[l[1639]]=Y[l[1459]][l[772]](l[229]-N,l[66],l[393],l[1243]);
    end
  elseif C then
    C[l[1639]]=Y[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]);
  end
  return Z;
end
