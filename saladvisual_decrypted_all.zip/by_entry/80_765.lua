-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #765
-- offset 3540687..3541076 (389 bytes, type=code)

local function yP()
  local zP,JP=s[87](),B-j;
  local HP,fP,aP,dP=JP>l[393]and(t-j)/JP or l[393],l[1420],Q>l[393]and zP[l[409]][l[846]](l[1213]..Q..l[347],t);
  if aP then
    dP=aP;
  else
    local JP,aP,PP=zP[l[1130]],zP[l[35]][l[499]],t;
    dP=(JP(aP(PP+l[659])));
  end
  Y[fP]=dP..zP[l[1130]](C[l[26]]or l[1387]);
  R[l[1639]]=zP[l[1459]][l[772]](HP,zP[l[35]][l[499]](l[1158]*(l[229]-HP)+l[659]),l[229],l[393]);
end
