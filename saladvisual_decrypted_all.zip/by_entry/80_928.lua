-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #928
-- offset 3576950..3577532 (582 bytes, type=code)

function()
  local A=s[87]();
  local w=A[l[409]][l[56]](B:GetValue()or l[1746],l[381])or l[1746];
  if A[l[409]][l[56]](w,l[698]) then
    if A[l[40]](T[l[148]])~=l[1712] then
      S(l[461],l[383]);
      return;
    end
    local F,h=T[l[148]](w);
    if F then
      B:SetValue(l[1746]);
      S(l[432]);
    else
      S(A[l[1130]](h),l[383]);
    end
    return;
  end
  local F,h;
  if w~=l[1746] then
    local W=J:thaw(w);
    if W then
      F,h=J:apply(W)==l[383],J[l[171]]and J[l[171]][l[1290]]and J[l[171]][l[1290]][l[229]];
    else
      F,h=l[1329],l[1279];
    end
    if F then
      B:SetValue(l[1746]);
    end
  else
    F,h=J:clipboardLoad();
  end
  S(F and l[432]or A[l[1130]](h or l[51]),not F);
end
