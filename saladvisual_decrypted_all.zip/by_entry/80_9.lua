-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #9
-- offset 3262499..3262720 (221 bytes, type=code)

function(z)
  local T={};
  local n=s[87]();
  for J=#y[19],l[229],l[715]do
    local H=y[19][J];
    if H==z or n[l[1703]](H)~=l[1089]or not H[l[382]] then
      n[l[1346]][l[1357]](y[19],J);
    end
  end;
  T[1]=y[19];
  T[2]=#y[19]+l[229];
  T[1][T[2]]=z;
end
