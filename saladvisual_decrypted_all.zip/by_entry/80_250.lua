-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #250
-- offset 3361346..3362045 (699 bytes, type=code)

local function hP(XP)
  XP=XP and l[383]or l[1329];
  if wP[l[1273]]==XP then
    return;
  end
  wP[l[1273]]=XP;
  if XP then
    WP[l[1324]]=l[383];
  end
  b(VP,l[304],XP and N or q,function(xP)
    local kP,vP,IP=s[87](),e(_P)[l[636]],XP and xP or l[229]-xP;
    local iP=kP[l[35]][l[499]](vP*IP+l[659]);
    WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
    VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
    _P[l[948]]=kP[l[1459]][l[588]](l[393],-kP[l[35]][l[499]](kP[l[35]][l[457]](l[352],vP)*(l[229]-IP)+l[659]));
    if xP>=l[229] then
      _P[l[948]]=kP[l[1459]][l[772]]();
      WP[l[1324]]=XP;
      if XP then
        WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
        VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
      end
    end
  end);
end
