-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #298
-- offset 3379752..3380155 (403 bytes, type=code)

function(F,fP)
  local aP=s[87]();
  if fP or y[18][l[1333]]or not _P[l[230]]or not y[18][l[630]] then
    return;
  end
  if F[l[1317]]~=aP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
    return;
  end
  if not WP[l[649]] then
    WP[l[1498]](l[383]);
    return;
  end
  if _P[l[649]]==l[259] then
    if _P[l[1273]] then
      return;
    end
    _P[l[1273]]=l[383];
    WP[l[1498]](l[383]);
  else
    _P[l[1273]]=not _P[l[1273]];
    WP[l[1498]](_P[l[1273]]);
  end
end
