-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #256
-- offset 3366689..3366920 (231 bytes, type=code)

local function UP(MP)
  local sC,lC=s[87](),uP;
  uP=lC+l[229];
  local lC,LC=l[211],{[l[1150]]=f(),[l[1639]]=sC[l[1459]][l[772]](l[229],l[393],l[393],MP),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=uP,[l[711]]=l[489]};
  return a(lC,LC,gP);
end
