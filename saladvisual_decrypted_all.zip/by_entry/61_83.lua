-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #83
-- offset 130321..130646 (325 bytes, type=code)

local function B(A,w)
  w=w or l;
  local F=w[A];
  if not F then
    return;
  end
  w[A]=nil;
  F.alive=false;
  for A,A in ipairs(F.tasks)do
    pcall(task.cancel,A);
  end;
  for A,A in ipairs(F.conns)do
    pcall(function()
      A:Disconnect();
    end);
  end;
  for A=#F.undo,1,-1 do
    pcall(F.undo[A]);
  end;
  for A,A in ipairs(F.made)do
    pcall(function()
      A:Destroy();
    end);
  end;
end
