-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #90
-- offset 3286576..3286859 (283 bytes, type=code)

function()
  local i,t=s[87](),{x};
  for u in y[3],y[18][l[1029]],nil do
    if u[l[382]] then
      t[#t+l[229]]=u;
    end
  end;
  local u=l[393];
  for U,U in y[5](t)do
    local t,M=U:GetDescendants();
    for U,U in y[3],t,M do
      i[l[1146]](g,U);
      u+=l[229];
      if u%l[1651]==l[393] then
        i[l[1022]][l[153]]();
      end
    end;
  end;
end
