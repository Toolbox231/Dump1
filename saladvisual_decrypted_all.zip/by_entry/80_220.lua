-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #220
-- offset 3346747..3352382 (5635 bytes, type=code)

local function DP(pP,KP,oP)
  local cP=s[87]();
  local mP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=cP[l[1459]][l[588]](l[730],l[906]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[1274],l[393],l[919]),[l[1535]]=cP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1158]},pP);
  D(mP,l[1158]);
  local SP=a(l[211],{[l[1150]]=f(),[l[1639]]=cP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=cP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1249]},mP);
  D(SP,l[1158]);
  local OP,BP=l[1622],{[l[1630]]=cP[l[1262]][l[772]](cP[l[360]][l[772]](l[229],l[229],l[229]))};
  BP[l[747]]=cP[l[1197]][l[772]]({cP[l[677]][l[772]](l[393],l[393]),cP[l[677]][l[772]](l[229],l[229])});
  a(OP,BP,SP);
  SP=a(l[211],{[l[1150]]=f(),[l[1639]]=cP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=cP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1249]},mP);
  D(SP,l[1158]);
  OP,BP=l[1622],{[l[1630]]=cP[l[1262]][l[772]](cP[l[360]][l[772]]()),[l[500]]=l[117]};
  BP[l[747]]=cP[l[1197]][l[772]]({cP[l[677]][l[772]](l[393],l[229]),cP[l[677]][l[772]](l[229],l[393])});
  a(OP,BP,SP);
  a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},mP);
  local AP=a(l[211],{[l[1150]]=f(),[l[1016]]=cP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=cP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1596]--[[__newindex]]},mP);
  SP,OP=l[1112],{};
  OP[l[1182]]=cP[l[740]][l[772]](l[229],l[393]);
  a(SP,OP,AP);
  a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},AP);
  local wP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=cP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=cP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1158]},pP);
  D(wP,l[303]);
  a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},wP);
  OP={};
  for FP=l[393],l[1158],l[229]do
    cP[l[1346]][l[968]](OP,cP[l[527]][l[772]](FP/l[1158],cP[l[360]][l[149]](FP/l[1158],l[229],l[229])));
  end;
  SP,BP=l[1622],{};
  BP[l[1630]]=cP[l[1262]][l[772]](OP);
  a(SP,BP,wP);
  local BP=a(l[211],{[l[1150]]=f(),[l[1016]]=cP[l[1689]][l[772]](l[659],l[659]),[l[948]]=cP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=cP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1596]--[[__newindex]]},wP);
  OP,SP=l[1112],{};
  SP[l[1182]]=cP[l[740]][l[772]](l[229],l[393]);
  a(OP,SP,BP);
  a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},BP);
  local SP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=cP[l[1459]][l[588]](l[730],l[1201]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[865],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[437]]=cP[l[128]][l[437]][l[1381]],[l[1420]]=p(KP[l[1409]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[1158]},pP);
  D(SP,l[303]);
  local OP={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
  OP[l[434]],OP[l[900]],OP[l[999]]=cP[l[360]][l[1412]](KP[l[1409]]);
  local function cP(FP,hP)
    local WP=s[87]();
    local VP,_P,XP=WP[l[360]][l[149]](OP[l[434]],OP[l[900]],OP[l[999]]),WP[l[1459]][l[1368]](OP[l[900]],l[229]-OP[l[999]]),WP[l[1459]][l[772]](OP[l[434]],l[393],l[659],l[393]);
    if hP then
      AP[l[948]]=_P;
      BP[l[948]]=XP;
      AP[l[1535]]=VP;
      mP[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229]);
      if KP[l[275]] then
        KP[l[275]][l[1535]]=VP;
      end
    else
      P(AP,n,{[l[948]]=_P,[l[1535]]=VP});
      P(BP,n,{[l[948]]=XP});
      P(mP,n,{[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229])});
      if KP[l[275]] then
        P(KP[l[275]],n,{[l[1535]]=VP});
      end
    end
    if not SP:IsFocused() then
      SP[l[1420]]=p(VP);
    end
    KP[l[1328]](VP,FP);
  end
  local KP=(function()
    local BP=pP[l[382]];
    while BP and BP~=x do
      local pP=l[1439];
      if BP:IsA(pP) then
        return BP;
      end
      BP=BP[l[382]];
    end;
  end)();
  local function pP()
    if not OP[l[259]] then
      return;
    end
    OP[l[259]]=l[1329];
    OP[l[700]]=nil;
    if OP[l[1731]] then
      OP[l[1731]]:Disconnect();
      OP[l[1731]]=nil;
    end
    if KP then
      KP[l[1195]]=l[383];
    end
    O(l[715]);
  end
  local function BP()
    local AP=s[87]();
    if OP[l[259]]and OP[l[700]] then
      local FP,hP=AP[l[1146]](function()
        OP[l[700]]();
        cP(l[383],l[383]);
      end);
      if not FP then
        pP();
        AP[l[972]](l[1752]..AP[l[1130]](hP));
      end
    end
  end
  local function AP(FP,hP)
    d(FP[l[956]],pP);
    d(FP[l[1558]],function(WP)
      local VP=s[87]();
      if WP[l[1317]]~=VP[l[128]][l[1317]][l[1356]]and WP[l[1317]]~=VP[l[128]][l[1317]][l[239]] then
        return;
      end
      if OP[l[259]] then
        return;
      end
      OP[l[259]]=l[383];
      OP[l[700]]=hP;
      OP[l[225]]=WP;
      O(l[229]);
      OP[l[1731]]=B(WP,pP);
      if KP then
        KP[l[1195]]=l[1329];
      end
      BP();
    end);
    d(FP[l[412]],function(KP)
      local FP=s[87]();
      if KP[l[1317]]==FP[l[128]][l[1317]][l[1356]]or KP[l[1317]]==FP[l[128]][l[1317]][l[239]]and KP==OP[l[225]] then
        pP();
      end
    end);
  end
  AP(mP,function()
    local KP,FP,hP,WP=s[87](),mP[l[81]],mP[l[160]],v(OP[l[225]]);
    OP[l[900]]=KP[l[35]][l[819]]((WP[l[1437]]-FP[l[1437]])/KP[l[35]][l[850]](hP[l[1437]],l[229]),l[393],l[229]);
    OP[l[999]]=l[229]-KP[l[35]][l[819]]((WP[l[636]]-FP[l[636]])/KP[l[35]][l[850]](hP[l[636]],l[229]),l[393],l[229]);
  end);
  AP(wP,function()
    local KP,mP,AP=s[87](),wP[l[81]],wP[l[160]];
    OP[l[434]]=KP[l[35]][l[819]]((v(OP[l[225]])[l[1437]]-mP[l[1437]])/KP[l[35]][l[850]](AP[l[1437]],l[229]),l[393],l[229]);
  end);
  d(y[9][l[412]],function(KP)
    local mP=s[87]();
    if KP[l[1317]]==mP[l[128]][l[1317]][l[1356]]or KP[l[1317]]==mP[l[128]][l[1317]][l[239]]and KP==OP[l[225]] then
      pP();
    end
  end);
  d(y[9][l[233]],function(pP)
    local KP=s[87]();
    if not OP[l[259]] then
      return;
    end
    if pP[l[1317]]==KP[l[128]][l[1317]][l[765]]or pP[l[1317]]==KP[l[128]][l[1317]][l[239]] then
      if pP[l[1317]]==KP[l[128]][l[1317]][l[239]]and pP~=OP[l[225]] then
        return;
      end
      BP();
    end
  end);
  d(SP[l[722]],function()
    local pP,KP=s[87](),r(SP[l[1420]]);
    if KP then
      OP[l[434]],OP[l[900]],OP[l[999]]=pP[l[360]][l[1412]](KP);
    end
    cP(l[383]);
  end);
  local function pP(KP)
    local mP=s[87]();
    OP[l[434]],OP[l[900]],OP[l[999]]=mP[l[360]][l[1412]](KP);
    cP(l[383]);
  end
  oP[l[391]]=pP;
  cP(l[1329],l[383]);
end
