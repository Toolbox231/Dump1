-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #229
-- offset 3351183..3351477 (294 bytes, type=code)

function()
  local KP,FP,hP,WP=s[87](),mP[l[81]],mP[l[160]],v(OP[l[225]]);
  OP[l[900]]=KP[l[35]][l[819]]((WP[l[1437]]-FP[l[1437]])/KP[l[35]][l[850]](hP[l[1437]],l[229]),l[393],l[229]);
  OP[l[999]]=l[229]-KP[l[35]][l[819]]((WP[l[636]]-FP[l[636]])/KP[l[35]][l[850]](hP[l[636]],l[229]),l[393],l[229]);
end
