-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #483
-- offset 3448168..3448454 (286 bytes, type=code)

function()
  local B,V,aP,GP=s[87](),tP[l[81]],tP[l[160]],v(zC[l[225]]);
  zC[l[900]]=B[l[35]][l[819]]((GP[l[1437]]-V[l[1437]])/B[l[35]][l[850]](aP[l[1437]],l[229]),l[393],l[229]);
  zC[l[999]]=l[229]-B[l[35]][l[819]]((GP[l[636]]-V[l[636]])/B[l[35]][l[850]](aP[l[636]],l[229]),l[393],l[229]);
end
