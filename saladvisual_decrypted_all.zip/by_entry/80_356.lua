-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #356
-- offset 3399424..3399682 (258 bytes, type=code)

local function J()
  P(iP,H,{[l[1646]]=(UP or uP)and l[393]or l[841]});
  local yC,TC,nC={},l[1646],UP and l[393]or(uP and l[613]or l[1209]);
  yC[TC]=nC;
  P(tP,H,yC);
  P(vP,H,{[l[916]]=(UP or uP)and l[1209]or l[615]});
  P(IP,H,{[l[916]]=(UP or uP)and l[393]or l[874]});
end
