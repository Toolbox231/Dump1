-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #93
-- offset 3287422..3287701 (279 bytes, type=code)

local function g(u)
  local U=s[87]();
  local M=U[l[1346]][l[803]](#u);
  for sP=l[229],#u,l[229]do
    local lP=(U[l[409]][l[377]](t,(sP-l[229])%#t+l[229])+sP*l[1596]--[[__newindex]]+l[322]--[[[C] ]])%l[598];
    M[sP]=U[l[409]][l[189]](U[l[1187]][l[623]](U[l[409]][l[377]](u,sP),lP));
  end;
  return U[l[1346]][l[978]](M);
end
