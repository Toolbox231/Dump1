-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #7
-- offset 3645269..3645528 (259 bytes, type=code)

local function O(B,A)
  B.Parent=A;
  A=y;
  A.FxDepth(B,false);
  if c then
    c(B);
  end
  D.particles[#D.particles+1]={emitter=B,rate=B.Rate,bright=B.Brightness,size=B.Size,color=B.Color,speed=B.Speed,rotation=B.RotSpeed,life=B.Lifetime,emission=B.LightEmission};
  return B;
end
