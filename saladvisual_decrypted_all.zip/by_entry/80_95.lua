-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #95
-- offset 3288406..3288982 (576 bytes, type=code)

local function i(u)
  local U=s[87]();
  u=U[l[409]][l[1710]](u,l[475],l[1746]);
  local M,sP={},l[229];
  while sP<#u do
    local lP,LP=l[393],l[393];
    for yP=l[393],l[863],l[229]do
      local zP=U[l[409]][l[1724]](u,sP+yP,sP+yP);
      if zP==l[313]or zP==l[1746] then
        lP,LP=lP*l[1167],LP+l[229];
      else
        lP=lP*l[1167]+(Q[zP]or l[393]);
      end
    end;
    M[#M+l[229]]=U[l[409]][l[189]](U[l[35]][l[499]](lP/l[546])%l[598]);
    if LP<l[59] then
      M[#M+l[229]]=U[l[409]][l[189]](U[l[35]][l[499]](lP/l[598])%l[598]);
    end
    if LP<l[229] then
      M[#M+l[229]]=U[l[409]][l[189]](lP%l[598]);
    end
    sP+=l[786];
  end;
  return U[l[1346]][l[978]](M);
end
