-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #353
-- offset 3398774..3399089 (315 bytes, type=code)

local function LC(yC)
  local zC=s[87]();
  yC=zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
  yC=if XP>l[393]then wP[l[457]]+zC[l[35]][l[499]]((yC-wP[l[457]])/XP+l[659])*XP else yC;
  yC=if xP>l[393]then zC[l[1382]](zC[l[409]][l[846]](l[1213]..xP..l[347],yC))or yC else yC;
  return zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
end
