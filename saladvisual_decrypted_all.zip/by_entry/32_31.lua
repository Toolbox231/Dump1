-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #31
-- offset 235081..235603 (522 bytes, type=code)

local function q(_)
  local X,x=D.CFrame:VectorToObjectSpace(_.CFrame.LookVector),{};
  for k,v in ipairs(Z)do
    if C.Picked[v] then
      local I,i=#x+1,{name=v};
      i.dot,i.order,x[I]=b[v]:Dot(X),k,i;
    end
  end;
  table.sort(x,function(b,X)
    if math.abs(b.dot-X.dot)<1.0E-4 then
      return b.order<X.order;
    end
    return b.dot>X.dot;
  end);
  table.clear(y);
  for b=1,math.min(W,#x),1 do
    y[x[b].name]=true;
  end;
  for b,X in pairs(T)do
    if not y[b] then
      P(X);
      T[b]=nil;
    end
  end;
  table.clear(r);
  for b=1,math.min(W,#x),1 do
    _=x[b].name;
    if not T[_] then
      r[#r+1]=_;
    end
  end;
end
