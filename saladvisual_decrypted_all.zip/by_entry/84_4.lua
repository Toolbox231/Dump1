-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #4
-- offset 3664529..3664828 (299 bytes, type=code)

local function j(C)
  local N=tostring(C or""):gsub("[_]+"," "):gsub("%s+"," "):match("^%s*(.-)%s*$")or"";
  if N==""or N:match("^%[%d+%]$") then
    return"Untitled";
  end
  return(N:gsub("(%a[%w']*)",function(C)
    if C:match("^%l")and not C:match("%u") then
      return C:sub(1,1):upper()..C:sub(2);
    end
    return C;
  end));
end
