-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #788
-- offset 3549954..3550376 (422 bytes, type=code)

local function j()
  local q=s[87]();
  if not w[l[630]] then
    return;
  end
  w[l[630]]=l[1329];
  O(l[715]);
  if w[l[1731]] then
    q[l[1146]](function()
      w[l[1731]]:Disconnect();
    end);
    w[l[1731]]=nil;
  end
  if w[l[344]] then
    q[l[1146]](function()
      w[l[344]]:Disconnect();
    end);
    w[l[344]]=nil;
  end
  q[l[1146]](function()
    B:ReleaseFocus(l[1329]);
  end);
  local q=z==w;
  if q then
    z=nil;
  end
  e(function()
    local e=s[87]();
    e[l[1146]](function()
      C:Destroy();
    end);
  end);
end
