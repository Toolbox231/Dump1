-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #774
-- offset 3542874..3543398 (524 bytes, type=code)

local function e(j)
  local C,r=s[87](),j[l[1317]];
  if not A[l[630]]or C[l[655]][l[1587]]()-Y<l[874] then
    return l[1329];
  end
  if r~=C[l[128]][l[1317]][l[1356]]and r~=C[l[128]][l[1317]][l[321]--[[-1]]]and r~=C[l[128]][l[1317]][l[239]]and r~=C[l[128]][l[1317]][l[72]] then
    return l[1329];
  end
  if r==C[l[128]][l[1317]][l[239]] then
    local Y,C,r=v(j),i[l[81]],i[l[160]];
    return Y[l[1437]]<C[l[1437]]-l[786]or Y[l[636]]<C[l[636]]-l[786]or Y[l[1437]]>C[l[1437]]+r[l[1437]]+l[786]or Y[l[636]]>C[l[636]]+r[l[636]]+l[786];
  end
  return not W(i,l[786]);
end
