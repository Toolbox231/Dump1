-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #23
-- offset 233547..233840 (293 bytes, type=code)

local function Y()
  local O,F=B(),m;
  if O==F then
    return;
  end
  m=O;
  S=m/s;
  for s,B in pairs(T)do
    F,O=ipairs,B.stars;
    for h,h in F(O)do
      h.home=h.aim*m;
      h.anchor.Position=h.home;
    end;
    s=B.title;
    if s then
      B.title.seat.Position=B.title.aim*m;
    end
  end;
  for s,s in ipairs(G)do
    s.seat.Position=s.aim*m;
  end;
  q();
end
