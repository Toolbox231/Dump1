-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #87
-- offset 3285866..3286163 (297 bytes, type=code)

local function g(u)
  local U=s[87]();
  if not(u:IsA(l[1070])or u:IsA(l[192])or u:IsA(l[1400]--[[-1]])) then
    return;
  end
  local M=t[u];
  if M==nil then
    M=u[l[437]];
    t[u]=M;
  else
  end
  local t=E[M];
  if not t then
    return;
  end
  local E=Q;
  if E then
    u[l[526]]=U[l[437]][l[772]](Q,t);
  elseif u[l[437]]~=M then
    u[l[437]]=M;
  end
end
