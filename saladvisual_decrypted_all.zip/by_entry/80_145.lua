-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #145
-- offset 3308254..3308595 (341 bytes, type=code)

local function LP(nP,HP)
  local fP=s[87]();
  local aP,dP=fP[l[1146]](function()
    local PP=s[87]();
    local ZP,GP=PP[l[128]][l[437]][l[1381]],s[70](PP[l[1689]][l[772]](l[1304],l[1304]));
    return y[8]:GetTextSize(nP,HP,ZP,s:ZT(GP));
  end);
  if aP and dP then
    return fP[l[35]][l[139]](dP[l[1437]]);
  end
  return fP[l[35]][l[139]](#fP[l[1130]](nP)*HP*l[1419]);
end
