-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #118
-- offset 3298026..3298584 (558 bytes, type=code)

local function t(g,u)
  local zP,TP=s[87](),y[18][l[1091]];
  if not TP then
    return l[1329];
  end
  if not u then
    if zP[l[40]](zP[l[1496]])==l[1712]and zP[l[40]](zP[l[255]])==l[1712]and zP[l[199]](l[59],zP[l[1146]](zP[l[1496]],TP))==l[383] then
      zP[l[1146]](zP[l[255]],TP);
    end
    return l[383];
  end
  g=zP[l[409]][l[56]](TP,l[292]);
  if g and zP[l[40]](zP[l[215]])==l[1712]and zP[l[40]](zP[l[1528]])==l[1712]and not zP[l[199]](l[59],zP[l[1146]](zP[l[215]],g)) then
    zP[l[1146]](zP[l[1528]],g);
  end
  return zP[l[40]](zP[l[611]])==l[1712]and zP[l[1146]](zP[l[611]],TP,u)or l[1329];
end
