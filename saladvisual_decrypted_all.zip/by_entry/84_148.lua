-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #148
-- offset 3695004..3695743 (739 bytes, type=code)

function()
  local n,H=task,function()
    local f,a=0,"";
    while f<6 do
      f+=1;
      local f,d=("https://games.roblox.com/v1/games/%d/servers/Public?sortOrder=Desc&limit=100"):format(game.PlaceId)..(a~=""and"&cursor="..a or""),y;
      local y=d.download(f);
      f,d=pcall(function()
        return T:JSONDecode(y);
      end);
      if not(f and type(d)=="table"and type(d.data)=="table") then
        return J(false,"server list unavailable");
      end
      local y,T=ipairs,d.data;
      for f,Z in y(T)do
        f=Z.id~=game.JobId and(tonumber(Z.playing)or 0)<(tonumber(Z.maxPlayers)or 0);
        if f then
          local function y()
            l:TeleportToPlaceInstance(game.PlaceId,Z.id,z);
          end
          if pcall(y) then
            return;
          end
        end
      end;
      if type(d.nextPageCursor)~="string" then
        break;
      end
      a=d.nextPageCursor;
    end;
    J(false,"No open servers");
  end;
  n.spawn(H);
end
