-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #79
-- offset 3683112..3683352 (240 bytes, type=code)

local function x()
  local Q=I or not l.Alive or not W.Parent;
  if Q then
    return false;
  end
  Q=W;
  while Q do
    if Q:IsA("GuiObject")and not Q.Visible then
      return false;
    end
    if Q:IsA("ScreenGui") then
      return Q.Enabled;
    end
    Q=Q.Parent;
  end;
  return false;
end
