-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #41
-- offset 120817..122487 (1670 bytes, type=code)

local function o(c,m)
  local S=c[1];
  if not m then
    if not c.tinted then
      return;
    end
    c.tinted=false;
    if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail")or S:IsA("Light")or S:IsA("Smoke") then
      S.Color=c.color;
    elseif S:IsA("Decal") then
      S.Color3=c.color;
    elseif S:IsA("BasePart") then
      S.Color=c.color;
      if c.texture then
        S.TextureID=c.texture;
      end
    elseif S:IsA("Fire") then
      S.Color,S.SecondaryColor=c.color,c.color2;
    elseif S:IsA("Sparkles") then
      S.SparkleColor=c.color;
    elseif S:IsA("Highlight") then
      S.FillColor,S.OutlineColor=c.color,c.color2;
    end
    return;
  end
  if not c.tinted then
    c.tinted=true;
    if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail")or S:IsA("Light")or S:IsA("Smoke") then
      c.color=S.Color;
    elseif S:IsA("Decal") then
      c.color=S.Color3;
    elseif S:IsA("BasePart") then
      c.color=S.Color;
      if S:IsA("MeshPart") then
        c.texture=S.TextureID;
      end
    elseif S:IsA("Fire") then
      c.color,c.color2=S.Color,S.SecondaryColor;
    elseif S:IsA("Sparkles") then
      c.color=S.SparkleColor;
    elseif S:IsA("Highlight") then
      c.color,c.color2=S.FillColor,S.OutlineColor;
    end
  end
  local O=m.Keypoints[1].Value;
  if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail") then
    if S.Color~=m then
      S.Color=m;
    end
  elseif S:IsA("Decal") then
    if S.Color3~=O then
      S.Color3=O;
    end
  elseif S:IsA("BasePart") then
    if S.Color~=O then
      S.Color=O;
    end
    if c.texture and S.TextureID~="" then
      S.TextureID="";
    end
  elseif S:IsA("Fire") then
    if S.Color~=O then
      S.Color=O;
      S.SecondaryColor=O;
    end
  elseif S:IsA("Sparkles") then
    if S.SparkleColor~=O then
      S.SparkleColor=O;
    end
  elseif S:IsA("Highlight") then
    if S.FillColor~=O then
      S.FillColor=O;
      S.OutlineColor=O;
    end
  elseif S:IsA("Light")or S:IsA("Smoke") then
    if S.Color~=O then
      S.Color=O;
    end
  end
end
