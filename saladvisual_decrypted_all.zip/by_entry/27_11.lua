-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #11
-- offset 19858..20360 (502 bytes, type=code)

local function K(m)
  local S=l;
  local O=S.camera();
  if not O then
    return nil;
  end
  local B,A=O.CFrame,C;
  C=A%#j+1;
  q+=N;
  A=j[C]*a:NextNumber(0.85,1.15);
  S=A*0.7;
  O=math.sqrt(a:NextNumber(0.05,1))*S;
  local j,C,N=B.Position+B.LookVector*A+B.RightVector*math.cos(q)*O+B.UpVector*math.sin(q)*O*0.6,P[a:NextInteger(1,6)],s.Life*a:NextNumber(0.7,1.35);
  return{pts={j},sx={},sy={},son={},sfar={},head=j,dir=C,goal=C,turn=1,run=0,leg=a:NextNumber(3,9),life=N,age=m and a:NextNumber(0,N*0.8)or 0,phase=a:NextNumber(0,1)};
end
