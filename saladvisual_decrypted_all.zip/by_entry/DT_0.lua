-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[DT] / function #0
-- offset 244690..262702 (18012 bytes, type=code)

function(s,l,L,y)
  local z;
  local T,n,J,H,f,a,d,P,Z,G,Y,e,j,C,N,q,b,D,p,r,K,o,c,m,S,O,B,A=s[18],s[97],s[3],s._T,s[20],s.rT,s[79],s.sT,s[104],s[36],s[123],s[125],s[55],s[118],s.DT,s[33],s[99],s[53],s[98],s.I,s[93],s[385],s[91],s[9964],s[73],s[105],33;
  local w;
  local F,h,W,V,_,X,x,k,v,I,i,E=l,L,y;
  while true do
    if B<=17 then
      if B<=8 then
        if B<=3 then
          B,A,W,X=s:AT(A,i,v,k,x,W,X,B);
        elseif B<=5 then
          B,W,_,X=s:HT(X,_,k,x,W,B);
        elseif B<=6 then
          y=A[5];
          z=F;
          B,A,h=z[4]and 26 or 1,y,7;
        else
          B,_=s:cT(B,v,x,V,X,W,_);
        end
      elseif B<=12 then
        B,W,x,k=s:pT(B,k,x,I,W,v);
      else
        B,F,h,W,X,x,k=s:dT(B,x,_,X,h,W,v,F,V,k);
      end
    elseif B<=26 then
      if B<=21 then
        B,h,W,I=s:LT(V,h,x,W,z,v,B,X,_,k,I);
      elseif B<=23 then
        B,h,_,X=s:wT(B,E,I,h,v,_,X,x,V);
      elseif B<=24 then
        w=z[6];
        l={__index=function(L,y)
          local Q,t=17;
          local R,g,u,U,M,sP,lP,LP,yP,zP,TP,nP,JP,HP=L,y;
          while true do
            local fP,aP,dP;
            if Q<=97 then
              L,y=nil;
              if Q<=48 then
                if Q<=23 then
                  if Q<=11 then
                    if Q<=5 then
                      if Q<=2 then
                        if Q<=0 then
                          Q=not(129<lP)and 45 or 62;
                        elseif Q<=1 then
                          local PP=t[1];
                          Q,t=181,PP;
                        else
                          Q=not not(U<2147483648)and 95 or 60;
                        end
                      elseif Q<=3 then
                        local PP,ZP,GP=T(u,1+lP%M,lP%M+2),lP+1,1+0;
                        local YP={t,ZP-GP,nil,sP+0,GP};
                        Q,t,lP=195,YP,PP;
                      elseif Q<=4 then
                        local PP=n(TP,3+U);
                        local ZP,GP,YP,eP,jP=sP-128,(lP-128)*2097152,128*(LP-128),PP%128*16384,PP-PP%128;
                        local PP,CP,NP=ZP+2097152*jP,GP+eP;
                        NP,Q,U=YP+(PP+CP),84,4+U;
                        sP=NP;
                      else
                        local PP,ZP,GP,YP=16384*(U-128),M-128,sP*128;
                        YP,Q,u=PP+GP+ZP,25,3+u;
                        U=YP;
                      end
                    elseif Q<=8 then
                      if Q<=6 then
                        Q,u=29,1+u;
                      elseif Q<=7 then
                        local PP=n(lP,2+u);
                        Q,sP=not not(128<=PP)and 55 or 5,PP;
                      else
                        local PP=n(sP,U+2);
                        Q,LP=128>PP and 19 or 109,PP;
                      end
                    elseif Q<=9 then
                      local PP=n(lP,U+3);
                      local ZP,GP,YP,eP,jP=M-128,(sP-128)*2097152,(LP-128)*128,16384*(PP%128),PP-PP%128;
                      local PP,CP,NP=eP+jP*2097152,YP+GP;
                      NP,Q,U=PP+(CP+ZP),65,4+U;
                      M=NP;
                    elseif Q<=10 then
                      local PP,ZP,GP,YP=(U-128)*16384,M-128,128*lP;
                      YP,Q,u=ZP+PP+GP,29,3+u;
                      U=YP;
                    else
                      local PP,ZP,GP=U+1,(226+u)%256,0;
                      local GP=f(lP,PP+0);
                      J(H,0,(d(a[ZP],GP,3806520034)));
                      PP=P[ZP];
                      Q,U=28,f(H,sP);
                    end
                  elseif Q<=17 then
                    if Q<=14 then
                      if Q<=12 then
                        local PP,PP=U+1;
                        do
                          PP=true;
                        end;
                        Q=PP and 41 or 54;
                      elseif Q<=13 then
                        local PP=n(lP,3+M);
                        local ZP,GP,YP,eP,jP=sP-128,(LP-128)*2097152,(yP-128)*128,16384*(PP%128),PP%128;
                        local CP,NP,qP=(PP-jP)*2097152,GP+YP;
                        qP,Q,M=NP+(ZP+CP)+eP,57,M+4;
                        sP=qP;
                      else
                        Q=not(185<lP)and 91 or 187;
                      end
                    elseif Q<=15 then
                      local PP,ZP=Z(sP),1+0;
                      local GP=1-ZP;
                      local YP={ZP,sP+0,nil,t,GP};
                      Q,t,lP=134,YP,PP;
                    elseif Q<=16 then
                      local PP,ZP,GP=U+1,101,145;
                      local YP,eP=0,((119+u)%256*ZP+GP)%256;
                      Q,u,U,M,LP,yP,zP,TP,nP,JP,HP=156,PP,119,ZP,GP,YP,eP,G,H,n(lP,YP+PP),d;
                    else
                      local PP=R[0][g];
                      local ZP,GP,YP=w[PP],z,0;
                      local w=GP[5];
                      local eP,jP=n(w,ZP),ZP+1;
                      if not(eP>102) then
                        Q,u,U,M,sP,lP,LP=42,PP,ZP,GP,YP,w,eP;
                      else
                        Q,u,U,M,sP,lP=116,PP,ZP,YP,w,eP;
                      end
                    end
                  elseif Q<=20 then
                    if Q<=18 then
                      local w=t[2];
                      Q,t=112,w;
                    elseif Q<=19 then
                      local w,PP,ZP,GP=(M-128)*16384,lP-128,LP*128;
                      GP,Q,U=PP+(ZP+w),69,3+U;
                      M=GP;
                    else
                      local w,PP,ZP,GP=16384*(M-128),sP-128,LP*128;
                      GP,Q,U=ZP+(w+PP),142,U+3;
                      M=GP;
                    end
                  elseif Q<=21 then
                    local w;
                    sP,Q,w=128*(sP-128)+lP,137,U+2;
                  elseif Q<=22 then
                    local w,w=U+1;
                    do
                      w=true;
                    end;
                    Q=w and 137 or 156;
                  else
                    local w=n(TP,U+2);
                    Q,zP=w<128 and 39 or 121,w;
                  end
                elseif Q<=35 then
                  if Q<=29 then
                    if Q<=26 then
                      if Q<=24 then
                        local w=n(lP,1+u);
                        Q,M=not(w<128)and 74 or 196,w;
                      elseif Q<=25 then
                        Q,U=28,Y(lP,u,U);
                      else
                        local Y=n(lP,3+u);
                        local w,PP,ZP,GP,YP=U-128,(M-128)*2097152,128*(sP-128),Y%128*16384,Y%128;
                        local eP,jP,CP=2097152*(Y-YP),w+GP;
                        CP,Q,u=jP+(eP+PP+ZP),56,u+4;
                        U=CP;
                      end
                    elseif Q<=27 then
                      Q,U=84,U+1;
                    elseif Q<=28 then
                      R[g]=U;
                      Q=143;
                    else
                      local Y,w,w=n(sP,u),u+1,e(U);
                      j(w,0,Y);
                      Q,U=28,w;
                    end
                  elseif Q<=32 then
                    if Q<=30 then
                      local Y=U+1;
                      local j=n(sP,Y);
                      Q,U,M=not(j>=128)and 120 or 70,Y,j;
                    elseif Q<=31 then
                      local Y,j,w=t[3],t[5],t[2];
                      local R,g=Y+j,j<=0;
                      Y,j=R>=w,R<=w;
                      w=g and Y or not g and j;
                      t[3]=R;
                      if w then
                        Q,lP=53,R;
                      else
                        Q=49;
                      end
                    else
                      local Y,j,w=1+U,(u+86)%256,0;
                      J(H,0,(d(f(sP,0+Y),1448498774,a[j])));
                      Y=P[j];
                      Q,U=28,C(H,M);
                    end
                  elseif Q<=33 then
                    local Y,j,C,w=1+U,(u+116)%256,1953789044,0;
                    local R=f(lP,Y+w);
                    J(H,w,(d(a[j],R,C)));
                    Q,u,U,M=129,Y,j,C;
                  elseif Q<=34 then
                    local Y,j,j=U+1,0,(145+101*((59+u)%256))%256;
                    G(H,0,(d(59,n(sP,0+Y),j)));
                    Q,U=28,n(H,M);
                  else
                    local Y=n(lP,1+U);
                    if not(128>Y) then
                      Q,LP=59,Y;
                    else
                      Q,lP=21,Y;
                    end
                  end
                elseif Q<=41 then
                  if Q<=38 then
                    if Q<=36 then
                      local Y=n(lP,3+U);
                      local j,C,w,R,g=sP-128,(LP-128)*2097152,128*(yP-128),16384*(Y%128),Y%128;
                      local PP,ZP,GP,YP,eP=2097152*(Y-g),C+w,R+j;
                      YP,eP,Q=ZP+(PP+GP),4+U,137;
                      sP=YP;
                    elseif Q<=37 then
                      local Y=1+U;
                      local j=n(lP,Y);
                      Q,U,M=not not(j>=128)and 73 or 169,Y,j;
                    else
                      u[M+1]=LP;
                      u[3+M]=sP;
                      u[2+M]=lP;
                      Q=173;
                    end
                  elseif Q<=39 then
                    local Y,j,C,w=(LP-128)*16384,yP-128,zP*128;
                    w,Q,U=j+C+Y,153,U+3;
                    LP=w;
                  elseif Q<=40 then
                    local Y,j,C=1+U,101,145;
                    local w,R=0,(C+(u+17)%256*j)%256;
                    Q,u,U,lP,LP,yP,zP,TP,nP,JP,HP=103,Y,17,j,C,w,R,G,H,n(sP,Y+w),d;
                  else
                    L=0;
                    local Y=1+0;
                    local j=1-Y;
                    local C={nil,sP+0,Y,j,t};
                    Q,t,U=165,C,L;
                  end
                elseif Q<=44 then
                  if Q<=42 then
                    Q=not(LP<=60)and 151 or 108;
                  elseif Q<=43 then
                    local Y=n(TP,1+U);
                    Q,lP=not not(Y>=128)and 78 or 182,Y;
                  else
                    Q,U,u=29,128*(U-128)+M,2+u;
                  end
                elseif Q<=46 then
                  if Q<=45 then
                    Q=129==lP and 68 or 30;
                  else
                    local Y=N(s,M,u,166);
                    Q,U=28,Y;
                  end
                elseif Q<=47 then
                  Q,M,U=142,128*(M-128)+sP,U+2;
                else
                  Q,U,u=25,(U-128)*128+M,u+2;
                end
              elseif Q<=72 then
                if Q<=60 then
                  if Q<=54 then
                    if Q<=51 then
                      if Q<=49 then
                        local Y,j=t[4],n(TP,M);
                        Q,t,u=not(128>j)and 98 or 124,Y,j;
                      elseif Q<=50 then
                        Q=lP>181 and 40 or 135;
                      else
                        local Y,j,C,N=U+1,(u+231)%256,3890735079,0;
                        J(H,N,(d(C,f(sP,N+Y),a[j])));
                        local w=P[j];
                        N=4;
                        Q,u,U,lP,LP=174,Y,C,w,N;
                      end
                    elseif Q<=52 then
                      local Y=n(TP,3);
                      local j,C,N,w;
                      j,C,N,w,Q=u-128,2097152*(U-128),(M-128)*128,Y%128*16384,94;
                      u,U=C+((Y-Y%128)*2097152+w)+(N+j),4;
                    elseif Q<=53 then
                      fP=(zP+yP*u)%256;
                      G(TP,lP,(d(LP,n(sP,U+lP),fP)));
                      Q,u=31,fP;
                    else
                      local Y,j,C,N=16384*(U-128),M-128,128*sP;
                      N,Q,u=Y+C+j,56,u+3;
                      U=N;
                    end
                  elseif Q<=57 then
                    if Q<=55 then
                      local Y=n(lP,3+u);
                      local j,C,N,w,R,g=U-128,(M-128)*2097152,(sP-128)*128,16384*(Y%128),Y%128;
                      g,Q,u=j+(2097152*(Y-R)+w+C)+N,25,u+4;
                      U=g;
                    elseif Q<=56 then
                      local Y=Z(U,n(lP,u),1+u);
                      Q,U=28,Y;
                    else
                      local Y=U(u,sP,M);
                      Q,U=28,Y;
                    end
                  elseif Q<=58 then
                    local Y=n(lP,U+1);
                    Q,sP=not not(128<=Y)and 104 or 166,Y;
                  elseif Q<=59 then
                    local Y=n(lP,U+2);
                    if Y<128 then
                      Q,lP=168,Y;
                    else
                      Q,yP=36,Y;
                    end
                  else
                    local Y=U-4294967296;
                    Q,U=95,Y;
                  end
                elseif Q<=66 then
                  if Q<=63 then
                    if Q<=61 then
                      Q=not(lP<150)and 51 or 34;
                    elseif Q<=62 then
                      Q=not(136>=lP)and 61 or 178;
                    else
                      local Y;
                      sP,Q,Y=sP+128*(lP-128),41,2+U;
                    end
                  elseif Q<=64 then
                    Q,lP,U=76,(lP-128)*128+LP,U+2;
                  elseif Q<=65 then
                    local Y,j=101,145;
                    y=(146+u)%256;
                    local C,N,w=e(M),2459079314,M-M%4;
                    local R,g=w-1,4+0;
                    local PP=0-g;
                    local ZP={R+0,g,t,PP,nil};
                    Q,t,u,sP,LP,yP,zP,TP,nP,JP=145,ZP,y,146,q,Y,j,C,N,w;
                  else
                    local Y,j=Z(3*u),1+0;
                    local C=1-j;
                    local N={u+0,t,C,j,nil};
                    Q,t,u=173,N,Y;
                  end
                elseif Q<=69 then
                  if Q<=67 then
                    Q,U=136,1+U;
                  elseif Q<=68 then
                    local Y,j,C,N=1+U,(u+11)%256,185273099,0;
                    J(H,N,(d(f(sP,N+Y),a[j],C)));
                    local w=P[j];
                    N=4;
                    Q,u,U,lP,LP,yP,zP,TP,nP,JP=127,Y,C,w,N,J,H,f(sP,N+Y),a[w],d;
                  else
                    local Y,j=101,145;
                    aP=(146+u)%256;
                    local C,N,w=e(M),2459079314,M-M%4;
                    local R,g=w-1,4+0;
                    local PP=0-g;
                    local ZP={g,R+0,t,nil,PP};
                    Q,t,u,lP,LP,yP,zP,TP,nP,JP=93,ZP,aP,146,q,Y,j,C,N,w;
                  end
                elseif Q<=70 then
                  local Y=n(sP,U+1);
                  Q,lP=not not(128<=Y)and 8 or 139,Y;
                elseif Q<=71 then
                  local Y,j,C=1+U,(u+152)%256,0;
                  local C=f(sP,Y+0);
                  J(H,0,(d(a[j],C,2560137368)));
                  Y=P[j];
                  Q,U=28,b(H,M);
                else
                  local Y=n(lP,U+1);
                  Q,sP=not(128>Y)and 111 or 140,Y;
                end
              elseif Q<=84 then
                if Q<=78 then
                  if Q<=75 then
                    if Q<=73 then
                      local Y=n(lP,U+1);
                      Q,sP=not(128>Y)and 131 or 47,Y;
                    elseif Q<=74 then
                      local Y=n(lP,u+2);
                      Q,sP=128>Y and 54 or 26,Y;
                    else
                      local Y=t[3];
                      Q,t=180,Y;
                    end
                  elseif Q<=76 then
                    local Y,j=101,145;
                    fP=(138+u)%256;
                    local C,N,w=e(lP),2324335242,lP-lP%4;
                    local R,g=w-1,4+0;
                    local PP=0-g;
                    local ZP={R+0,t,g,PP,nil};
                    Q,t,u,LP,yP,zP,TP,nP,JP=105,ZP,fP,138,Y,j,C,N,w;
                  elseif Q<=77 then
                    local Y=t[2];
                    Q,t,U=28,Y,u;
                  else
                    local Y=n(TP,U+2);
                    Q,LP=not(128>Y)and 4 or 184,Y;
                  end
                elseif Q<=81 then
                  if Q<=79 then
                    local Y=n(sP,2+u);
                    Q,lP=not(Y<128)and 192 or 10,Y;
                  elseif Q<=80 then
                    y=(yP*u+zP)%256;
                    G(TP,M,(d(sP,n(lP,U+M),y)));
                    Q,u=106,y;
                  else
                    local Y=f(lP,U+HP);
                    J(TP,HP,(d(a[u],nP,Y)));
                    y=P[u];
                    Q,u=145,y;
                  end
                elseif Q<=82 then
                  local y;
                  y,Q=(u-128)*16384,94;
                  u,U=U-128+(y+M*128),3;
                elseif Q<=83 then
                  local y,Y,j,C=(M-128)*16384,sP-128,LP*128;
                  C,Q,U=y+j+Y,136,U+3;
                  M=C;
                else
                  local y,Y,j=D(3,sP),p(sP,2),1715;
                  if not(0~=y) then
                    Q,sP,lP=188,y,Y;
                  else
                    Q,sP,lP,LP=38,y,Y,j;
                  end
                end
              elseif Q<=90 then
                if Q<=87 then
                  if Q<=85 then
                    local y=t[5];
                    Q,t=28,y;
                  elseif Q<=86 then
                    aP=(zP+u*yP)%256;
                    G(TP,nP,(d(lP,n(sP,U+nP),aP)));
                    Q,u=125,aP;
                  else
                    local y=1+U;
                    local Y=n(lP,y);
                    Q,U,M=not not(Y>=128)and 72 or 90,y,Y;
                  end
                elseif Q<=88 then
                  local y=n(sP,1+U);
                  if not(128>y) then
                    Q,LP=110,y;
                  else
                    Q,sP=63,y;
                  end
                elseif Q<=89 then
                  Q,u=25,u+1;
                else
                  Q,U=65,U+1;
                end
              elseif Q<=93 then
                if Q<=91 then
                  Q=not(175<lP)and 119 or 50;
                elseif Q<=92 then
                  local y=n(sP,1+u);
                  Q,M=not(128<=y)and 44 or 79,y;
                else
                  local y,Y,j=t[5],t[1],t[2];
                  local C,N=y+Y,Y<=0;
                  Y,y=C>=j,C<=j;
                  j=N and Y or not N and y;
                  t[5]=C;
                  if j then
                    Q,HP=146,C;
                  else
                    Q=154;
                  end
                end
              elseif Q<=95 then
                if Q<=94 then
                  if not(u>0) then
                    Q,U=28,r;
                  else
                    Q=66;
                  end
                else
                  Q,U=28,U*4294967296+u;
                end
              elseif Q<=96 then
                local y=1+U;
                local Y=n(lP,y);
                Q,u,U=not(Y<128)and 24 or 175,y,Y;
              else
                L=1+U;
                Q,U=195,L;
              end
            elseif Q<=146 then
              if Q<=121 then
                if Q<=109 then
                  if Q<=103 then
                    if Q<=100 then
                      if Q<=98 then
                        local L=n(TP,1);
                        Q,U=not not(128<=L)and 149 or 161,L;
                      elseif Q<=99 then
                        local L,y,Y=t[5],t[2],t[4];
                        local j,C=L+y,y<=0;
                        y,L=j>=Y,j<=Y;
                        Y=C and y or not C and L;
                        t[5]=j;
                        if Y then
                          Q,HP=113,j;
                        else
                          Q=1;
                        end
                      else
                        Q,sP,M=57,128*(sP-128)+lP,2+M;
                      end
                    elseif Q<=101 then
                      Q=not not(T(u,LP%M+1,LP%M+2)~=lP)and 195 or 97;
                    elseif Q<=102 then
                      Q=not(75<LP)and 193 or 118;
                    else
                      TP(nP,yP,(HP(U,JP,zP)));
                      local L=1;
                      G(H,L,(d((lP*zP+LP)%256,n(sP,L+u),U)));
                      Q,U=28,K(H,M);
                    end
                  elseif Q<=106 then
                    if Q<=104 then
                      local L=n(lP,2+U);
                      Q,LP=not not(L>=128)and 190 or 83,L;
                    elseif Q<=105 then
                      local L,y,T=t[4],t[3],t[1];
                      local Y,j=L+y,y<=0;
                      L,y=Y>=T,Y<=T;
                      T=j and L or not j and y;
                      t[4]=Y;
                      if T then
                        Q,HP=114,Y;
                      else
                        Q=18;
                      end
                    else
                      local L,y,T=t[1],t[3],t[2];
                      local Y,j=L+y,y<=0;
                      y,L=Y>=T,Y<=T;
                      T=j and y or not j and L;
                      t[1]=Y;
                      if T then
                        Q,M=80,Y;
                      else
                        Q=130;
                      end
                    end
                  elseif Q<=107 then
                    Q=not not(LP<=66)and 16 or 37;
                  elseif Q<=108 then
                    Q=not(42>=LP)and 164 or 183;
                  else
                    local L=n(sP,U+3);
                    local y,T,Y,j,C,N=M-128,2097152*(lP-128),(LP-128)*128,16384*(L%128),L%128;
                    N,Q,U=T+(2097152*(L-C)+(y+Y)+j),69,4+U;
                    M=N;
                  end
                elseif Q<=115 then
                  if Q<=112 then
                    if Q<=110 then
                      local L=n(sP,U+2);
                      if L<128 then
                        Q,sP=177,L;
                      else
                        Q,yP=147,L;
                      end
                    elseif Q<=111 then
                      local L=n(lP,U+2);
                      Q,LP=not(128>L)and 9 or 150,L;
                    else
                      local L,y=lP-1,1+0;
                      local T=JP-y;
                      local Y={nil,L+0,T,t,y};
                      Q,t=31,Y;
                    end
                  elseif Q<=113 then
                    J(TP,HP,(d(f(lP,U+HP),a[u],nP)));
                    dP=P[u];
                    Q,u=99,dP;
                  elseif Q<=114 then
                    J(TP,HP,(d(nP,f(sP,HP+U),a[u])));
                    fP=P[u];
                    Q,u=105,fP;
                  else
                    Q,U=153,U+1;
                  end
                elseif Q<=118 then
                  if Q<=116 then
                    Q=not not(150<lP)and 14 or 0;
                  elseif Q<=117 then
                    local L=n(lP,u+1);
                    Q,M=not(128<=L)and 48 or 7,L;
                  else
                    Q=LP<102 and 11 or 46;
                  end
                elseif Q<=119 then
                  local L,y,y=1+U,0,(101*((180+u)%256)+145)%256;
                  G(H,0,(d(y,180,(n(sP,L+0)))));
                  L=-n(H,M);
                  Q,U=28,L;
                elseif Q<=120 then
                  Q,U=69,1+U;
                else
                  local L=n(TP,3+U);
                  local y,T,Y,j,C=LP-128,(yP-128)*2097152,(zP-128)*128,L%128*16384,L-L%128;
                  local L,N,D=2097152*C+T,j+y;
                  D,Q,U=Y+(L+N),153,U+4;
                  LP=D;
                end
              elseif Q<=133 then
                if Q<=127 then
                  if Q<=124 then
                    if Q<=122 then
                      local L,y=M-1,1+0;
                      local T={nil,JP-y,t,L+0,y};
                      Q,t=125,T;
                    elseif Q<=123 then
                      local L=n(TP,U+1);
                      Q,yP=128>L and 191 or 23,L;
                    else
                      Q,U=94,1;
                    end
                  elseif Q<=125 then
                    local L,y,T=t[2],t[5],t[4];
                    local Y,j=L+y,y<=0;
                    y,L=Y>=T,Y<=T;
                    T=j and y or not j and L;
                    t[2]=Y;
                    if T then
                      Q,nP=86,Y;
                    else
                      Q=185;
                    end
                  elseif Q<=126 then
                    local L=t[1];
                    Q,t=165,L;
                  else
                    yP(zP,LP,(JP(nP,TP,U)));
                    local L,y=P[lP],8;
                    J(H,y,(d(U,f(sP,y+u),a[L])));
                    local y,y=P[L],o(b(H,M),b(H,4),(b(H,8)));
                    Q,U=28,y;
                  end
                elseif Q<=130 then
                  if Q<=128 then
                    Q=not(lP>250)and 194 or 71;
                  elseif Q<=129 then
                    local L,y=P[U],4;
                    local T=f(lP,y+u);
                    J(H,y,(d(a[L],M,T)));
                    y=P[L];
                    Q,U=28,c(H,sP);
                  else
                    local L=t[5];
                    Q,t,U=28,L,LP(TP);
                  end
                elseif Q<=131 then
                  local L=n(lP,U+2);
                  Q,LP=128>L and 20 or 162,L;
                elseif Q<=132 then
                  local L=n(lP,1+M);
                  if not(L>=128) then
                    Q,lP=100,L;
                  else
                    Q,LP=141,L;
                  end
                else
                  local L=1+U;
                  local y,T,T=n(lP,L),L+1,U+2;
                  L=n(lP,T);
                  Q,u,U,M=not not(128<=L)and 58 or 67,y,T,L;
                end
              elseif Q<=139 then
                if Q<=136 then
                  if Q<=134 then
                    local L,y,T=t[5],t[1],t[2];
                    local Y,j=L+y,y<=0;
                    y,L=Y>=T,Y<=T;
                    T=j and y or not j and L;
                    t[5]=Y;
                    if T then
                      Q,LP=172,Y;
                    else
                      Q=152;
                    end
                  elseif Q<=135 then
                    local L,y,y=1+U,0,(145+101*((u+79)%256))%256;
                    G(H,0,(d(y,n(sP,L+0),79)));
                    L=not(n(H,M)==54);
                    Q,U=28,L;
                  else
                    local L=n(lP,U);
                    Q,sP=not(L<128)and 35 or 22,L;
                  end
                elseif Q<=137 then
                  local L,y=Z(M),1+0;
                  local T=1-y;
                  local Z={M+0,T,y,t,nil};
                  Q,t,U=163,Z,L;
                elseif Q<=138 then
                  J(H,LP,(d(f(lP,LP+u),U,a[M])));
                  local L,L=P[M],m(b(H,sP),(b(H,4)));
                  Q,U=28,L;
                else
                  Q,M,U=69,lP+128*(M-128),2+U;
                end
              elseif Q<=142 then
                if Q<=140 then
                  Q,M,U=65,(M-128)*128+sP,U+2;
                elseif Q<=141 then
                  local L=n(lP,M+2);
                  if not not(L>=128) then
                    Q,yP=13,L;
                  else
                    Q,lP=186,L;
                  end
                else
                  local L,y=101,145;
                  dP=(u+146)%256;
                  local T,Z,Y=e(M),2459079314,M-M%4;
                  local e,j=Y-1,4+0;
                  local C=0-j;
                  local N={t,j,nil,e+0,C};
                  Q,t,u,sP,LP,yP,zP,TP,nP,JP=99,N,dP,146,q,L,y,T,Z,Y;
                end
              elseif Q<=144 then
                if Q<=143 then
                  return U;
                else
                  Q=60~=LP and 33 or 133;
                end
              elseif Q<=145 then
                local L,y,T=t[4],t[2],t[1];
                local Z,Y=L+y,y<=0;
                L,y=Z>=T,Z<=T;
                T=Y and L or not Y and y;
                t[4]=Z;
                if T then
                  Q,HP=81,Z;
                else
                  Q=75;
                end
              else
                J(TP,HP,(d(nP,f(sP,HP+U),a[u])));
                aP=P[u];
                Q,u=93,aP;
              end
            elseif Q<=171 then
              if Q<=158 then
                if Q<=152 then
                  if Q<=149 then
                    if Q<=147 then
                      local L=n(sP,U+3);
                      local y,T,Z,Y,e,j,C=lP-128,2097152*(LP-128),(yP-128)*128,16384*(L%128),L%128;
                      j,C,Q=y+((L-e)*2097152+Z)+(Y+T),4+U,41;
                      sP=j;
                    elseif Q<=148 then
                      local L=n(sP,1+U);
                      Q,LP=not(128<=L)and 64 or 155,L;
                    else
                      local L=n(TP,2);
                      Q,M=not(L>=128)and 82 or 52,L;
                    end
                  elseif Q<=150 then
                    local L,y,T,Z=(M-128)*16384,sP-128,LP*128;
                    Z,Q,U=L+(T+y),65,3+U;
                    M=Z;
                  elseif Q<=151 then
                    Q=not not(LP>71)and 102 or 107;
                  else
                    local L=t[4];
                    U[M]=lP;
                    Q,t=163,L;
                  end
                elseif Q<=155 then
                  if Q<=153 then
                    local L=1+LP;
                    Q,LP=38,L;
                  elseif Q<=154 then
                    local L=t[3];
                    Q,t=122,L;
                  else
                    local L=n(sP,2+U);
                    Q,yP=not(128<=L)and 167 or 176,L;
                  end
                elseif Q<=156 then
                  TP(nP,yP,(HP(zP,U,JP)));
                  local L=1;
                  G(H,L,(d((LP+M*zP)%256,n(lP,u+L),U)));
                  Q,U=28,S(H,sP);
                elseif Q<=157 then
                  dP=(u*yP+zP)%256;
                  G(TP,nP,(d(n(lP,U+nP),sP,dP)));
                  Q,u=170,dP;
                else
                  local L,y,T,Z=U+1,(63+u)%256,1061109567,0;
                  local G=f(lP,Z+L);
                  J(H,Z,(d(a[y],T,G)));
                  G=P[y];
                  Z=4;
                  Q,u,U,M,LP=138,L,T,G,Z;
                end
              elseif Q<=164 then
                if Q<=161 then
                  if Q<=159 then
                    local L=t[4];
                    Q,t=28,L;
                  elseif Q<=160 then
                    Q,U=76,U+1;
                  else
                    Q,u,U=94,(u-128)*128+U,2;
                  end
                elseif Q<=162 then
                  local L=n(lP,U+3);
                  local y,T,Z,G,Y,e=M-128,(sP-128)*2097152,(LP-128)*128,L%128*16384,L%128;
                  e,Q,U=2097152*(L-Y)+(Z+y)+(G+T),142,U+4;
                  M=e;
                elseif Q<=163 then
                  local L,y,T=t[2],t[3],t[1];
                  local Z,G=L+y,y<=0;
                  y,L=Z>=T,Z<=T;
                  T=G and y or not G and L;
                  t[2]=Z;
                  if T then
                    Q,M=15,Z;
                  else
                    Q=159;
                  end
                else
                  Q=not not(LP>55)and 144 or 87;
                end
              elseif Q<=167 then
                if Q<=165 then
                  local L,y,T=t[4],t[3],t[2];
                  local Z,G=L+y,y<=0;
                  L,y=Z>=T,Z<=T;
                  T=G and L or not G and y;
                  t[4]=Z;
                  if T then
                    Q,lP=3,Z;
                  else
                    Q=85;
                  end
                elseif Q<=166 then
                  Q,M,U=136,128*(M-128)+sP,2+U;
                else
                  local L,y,T,Z=16384*(lP-128),LP-128,yP*128;
                  Z,Q,U=L+T+y,76,U+3;
                  lP=Z;
                end
              elseif Q<=169 then
                if Q<=168 then
                  local L,y,T,Z,G=16384*(sP-128),LP-128,lP*128;
                  Z,G,Q=L+T+y,3+U,137;
                  sP=Z;
                else
                  Q,U=142,U+1;
                end
              elseif Q<=170 then
                local L,y,T=t[5],t[1],t[4];
                local Z,G=L+y,y<=0;
                L,y=Z>=T,Z<=T;
                T=G and L or not G and y;
                t[5]=Z;
                if T then
                  Q,nP=157,Z;
                else
                  Q=189;
                end
              else
                local L,y=(M-1)*3,n(TP,U);
                Q,M,sP=not not(y>=128)and 43 or 27,L,y;
              end
            elseif Q<=183 then
              if Q<=177 then
                if Q<=174 then
                  if Q<=172 then
                    lP[LP]=d(LP*M,u);
                    Q=134;
                  elseif Q<=173 then
                    local L,y,T=t[3],t[4],t[1];
                    local Z,G=L+y,y<=0;
                    L,y=Z>=T,Z<=T;
                    T=G and L or not G and y;
                    t[3]=Z;
                    if T then
                      Q,M=171,Z;
                    else
                      Q=77;
                    end
                  else
                    local L=f(sP,u+LP);
                    J(H,LP,(d(U,a[lP],L)));
                    local L,L,y=P[lP],f(H,M),f(H,4);
                    if y==0 then
                      Q,U=28,L;
                    else
                      Q,u,U=2,L,y;
                    end
                  end
                elseif Q<=175 then
                  Q,u=56,u+1;
                elseif Q<=176 then
                  local L=n(sP,3+U);
                  local y,T,J,H,f=lP-128,(LP-128)*2097152,(yP-128)*128,L%128*16384,L%128;
                  local a,d,P=(L-f)*2097152,T+J;
                  P,Q,U=d+(y+(H+a)),76,4+U;
                  lP=P;
                else
                  local L,y,T,J,H=(lP-128)*16384,LP-128,128*sP;
                  J,H,Q=y+T+L,3+U,41;
                  sP=J;
                end
              elseif Q<=180 then
                if Q<=178 then
                  local L=U+1;
                  local y=n(sP,L);
                  Q,U,lP=y<128 and 160 or 148,L,y;
                elseif Q<=179 then
                  Q,M=57,1+M;
                else
                  local L,y=M-1,1+0;
                  local T={JP-y,L+0,y,nil,t};
                  Q,t=106,T;
                end
              elseif Q<=181 then
                local L,y=M-1,1+0;
                local T=JP-y;
                local J={y,t,nil,L+0,T};
                Q,t=170,J;
              elseif Q<=182 then
                Q,sP,U=84,lP+128*(sP-128),2+U;
              else
                Q=not(42~=LP)and 158 or 96;
              end
            elseif Q<=189 then
              if Q<=186 then
                if Q<=184 then
                  local L,y,T,J=(sP-128)*16384,lP-128,128*LP;
                  J,Q,U=T+(y+L),84,U+3;
                  sP=J;
                elseif Q<=185 then
                  local L,y,T=t[3],LP(TP),M+U;
                  local J=n(sP,T);
                  if 128>J then
                    Q,t,u,U,sP=12,L,y,T,J;
                  else
                    Q,t,u,U,lP=88,L,y,T,J;
                  end
                else
                  local L,y,T,J=(sP-128)*16384,LP-128,lP*128;
                  J,Q,M=T+(L+y),57,M+3;
                  sP=J;
                end
              elseif Q<=187 then
                Q=not(196>=lP)and 128 or 32;
              elseif Q<=188 then
                local L=n(TP,U);
                Q,LP=not not(128<=L)and 123 or 115,L;
              else
                local L,y,T=t[2],LP(TP),U+M;
                local J=n(lP,T);
                Q,t,u,U,M,sP=not(J<128)and 132 or 179,L,y,O,T,J;
              end
            elseif Q<=192 then
              if Q<=190 then
                local L=n(lP,3+U);
                local y,T,J,H,f=M-128,(sP-128)*2097152,(LP-128)*128,L%128*16384,L%128;
                local a,d,P=(L-f)*2097152,T+H;
                P,Q,U=d+(y+a+J),136,U+4;
                M=P;
              elseif Q<=191 then
                Q,LP,U=153,128*(LP-128)+yP,U+2;
              else
                local L=n(sP,u+3);
                local y,T,J,H,f=U-128,(M-128)*2097152,(lP-128)*128,16384*(L%128),L%128;
                local a,d,P=2097152*(L-f),T+y+H;
                P,Q,u=a+d+J,29,u+4;
                U=P;
              end
            elseif Q<=194 then
              if Q<=193 then
                local L=U+1;
                local y=n(lP,L);
                Q,u,U=not(128>y)and 117 or 89,L,y;
              else
                local L=1+U;
                local y=n(sP,L);
                Q,u,U=y<128 and 6 or 92,L,y;
              end
            elseif Q<=195 then
              local L,y,T=t[2],t[5],t[4];
              local n,J=L+y,y<=0;
              L,y=n>=T,n<=T;
              T=J and L or not J and y;
              t[2]=n;
              if T then
                Q,LP=101,n;
              else
                Q=126;
              end
            else
              Q,U,u=56,M+128*(U-128),2+u;
            end
          end;
        end};
        z[7]=l;
        B,W=19,l;
      else
        B,W,x=s:fT(B,z,W,k,x);
      end
    elseif B<=30 then
      if B<=28 then
        local l,L,y=s:TT(A,B,X);
        if l==2 then
          B,X=L,y;
        elseif l==1 then
          return F,h;
        end
      else
        B,_,X,E=s:yT(E,V,_,B,k,X,x,A);
      end
    elseif B<=32 then
      B,A,h,W,x,k,v,I,i=s:tT(x,i,A,h,X,B,v,W,I,k);
    else
      B,W,V,_,X,k=s:nT(V,x,v,W,h,B,F,X,_,k);
    end
  end;
end
