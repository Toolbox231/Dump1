-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[5] / function #6
-- offset 38717..38966 (249 bytes, type=code)

function()
  local e=N.rows;
  local q=#e;
  for b=1,q,1 do
    local q;
    local q=L;
    q(e[b]);
  end;
  table.clear(e);
  table.clear(N.shown);
  table.clear(N.cpos);
  table.clear(N.csize);
  table.clear(N.ccol);
  N.head=nil;
  N.pos=nil;
  N.cf=nil;
  N.fov=nil;
  N.vx=nil;
  N.vy=nil;
  N.col=nil;
end
