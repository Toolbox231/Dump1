-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #11
-- offset 3614413..3614660 (247 bytes, type=code)

local function p(r)
  r=r or s;
  local K=1-math.clamp(r.Bright/100,0.05,1);
  return NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.12,K),NumberSequenceKeypoint.new(0.55,K+(1-K)*0.35),NumberSequenceKeypoint.new(1,1)});
end
