-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #23
-- offset 3620386..3620636 (250 bytes, type=code)

function()
  if not(s.On and s.Style and Z[s.Style]and(s.Target=="Self"or s.Target=="All")) then
    return nil;
  end
  return{s=s.Style,a=s.Color:ToHex(),b=s.Color2:ToHex(),r=s.Rainbow==true,z=s.Size,l=s.Life,n=s.Rate,g=s.Bright,m=s.Amount,w=s.Always==true};
end
