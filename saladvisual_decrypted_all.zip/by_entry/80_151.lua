-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #151
-- offset 3313283..3313623 (340 bytes, type=code)

local function dP()
  local YP,jP=y[18][l[1648]]and#ZP>l[393],GP;
  if YP==jP then
    return;
  end
  GP=YP;
  eP();
  if YP then
    HP[l[1324]]=l[383];
  end
  local jP=HP[l[1569]];
  local CP=YP and l[393]or l[229];
  b(HP,YP and l[1431]or l[120],YP and N or q,function(YP)
    HP[l[1569]]=jP+(CP-jP)*YP;
    local jP=YP>=l[229]and not GP;
    if jP then
      HP[l[1324]]=l[1329];
    end
  end);
end
