-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #60
-- offset 3677629..3677904 (275 bytes, type=code)

function()
  if not l.Alive then
    return;
  end
  l.Alive=false;
  l.OnStateChange=nil;
  l.ResetEmote();
  D();
  local C,q=p(),z;
  local D=q.Character;
  local q,p=D and(D:FindFirstChildOfClass("Humanoid")),D and(D:FindFirstChild("Animate"));
  if C and q and p then
    b(q,p);
  end
  l.PackName="Default";
end
