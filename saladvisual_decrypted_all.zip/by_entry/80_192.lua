-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #192
-- offset 3330947..3331295 (348 bytes, type=code)

local function t(R)
  local g,u=s[87](),l[393];
  for yP=l[229],#E,l[229]do
    local JP=E[yP];
    yP=JP[l[351]];
    if yP and yP[l[382]] then
      local HP=g[l[1459]][l[588]](l[393],u);
      if JP==R or JP[l[1662]]==nil then
        yP[l[948]]=HP;
      elseif JP[l[1662]]~=u then
        P(yP,H,{[l[948]]=HP});
      end
      JP[l[1662]]=u;
      u+=(JP[l[1754]]or yP[l[1639]][l[636]][l[1485]])+l[930];
    else
    end
  end;
end
