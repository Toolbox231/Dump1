-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #770
-- offset 3541930..3542255 (325 bytes, type=code)

function(B)
  local h,I=s[87](),not A[l[630]]or not u;
  if I then
    return;
  end
  if B[l[1317]]~=h[l[128]][l[1317]][l[765]]and B[l[1317]]~=h[l[128]][l[1317]][l[239]] then
    return;
  end
  I=B[l[1317]]==h[l[128]][l[1317]][l[239]]and B~=sP;
  if I then
    return;
  end
  I,B=h[l[1146]](Y,j(sP));
  if not I then
    LP();
    h[l[972]](l[125]..h[l[1130]](B));
  end
end
