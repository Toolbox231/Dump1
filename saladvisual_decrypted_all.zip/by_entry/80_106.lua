-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #106
-- offset 3290887..3291695 (808 bytes, type=code)

local function yP(zP)
  local TP,nP=s[87](),{};
  for JP,HP in y[3],y[18][l[752]],nil do
    JP=y[18][l[1294]][HP];
    if JP and not(zP[l[1207]]and zP[l[1207]][HP]) then
      local zP=U(JP[l[506]]);
      local fP;
      if TP[l[1703]](zP)==l[360] then
        fP=l[1073];
        zP=(p(zP));
      else
        if TP[l[40]](zP)==l[268] then
          fP=l[1118];
          zP=zP and l[1337]or l[121];
        else
          if TP[l[40]](zP)==l[384]and zP==zP and TP[l[35]][l[1575]](zP)<l[94] then
            fP=l[668];
            zP=TP[l[1130]](zP);
          else
            if TP[l[40]](zP)==l[409] then
              fP=l[900];
            else
              if zP==nil and JP[l[415]]==l[230] then
                fP=l[900];
                zP=l[605];
              else
              end
            end
          end
        end
      end
      if fP then
        nP[#nP+l[229]]=l[1327]..Q(HP)..l[214]..fP..l[214]..Q(zP);
      end
    end
  end;
  for zP,JP in y[3],y[18][l[131]],nil do
    if TP[l[1703]](JP)==l[360] then
      nP[#nP+l[229]]=l[1659]..Q(zP)..l[481]..p(JP);
    end
  end;
  return l[249]..t(g(TP[l[1346]][l[978]](nP,l[222])));
end
