-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #418
-- offset 3421154..3421602 (448 bytes, type=code)

local function EP()
  local sC,nC,JC,HC,fC=s[87](),G(YP),e(YP),G(vP),e(vP);
  local aC,dC=HC[l[1437]]-nC[l[1437]],yC[l[771]]and HC[l[636]]-nC[l[636]]-l[1158]or HC[l[636]]-nC[l[636]]+fC[l[636]]+l[1158];
  aC=if aC+yC[l[559]]>JC[l[1437]]-l[930]then sC[l[35]][l[850]](l[930],HC[l[1437]]-nC[l[1437]]+fC[l[1437]]-yC[l[559]])else aC;
  UP[l[948]]=sC[l[1459]][l[588]](sC[l[35]][l[499]](aC+l[659]),sC[l[35]][l[499]](dC+l[659]));
  if RP then
    RP[l[948]]=UP[l[948]];
  end
end
