-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #101
-- offset 3289539..3289932 (393 bytes, type=code)

local function M()
  local sP=s[87]();
  if sP[l[40]](sP[l[215]])~=l[1712]or sP[l[40]](sP[l[1528]])~=l[1712] then
    return l[1329];
  end
  local lP=l[1746];
  for LP in sP[l[409]][l[78]](sP[l[409]][l[1710]](y[18][l[354]],l[365],l[532]),l[1360])do
    lP=lP==l[1746]and LP or lP..l[532]..LP;
    if not U(sP[l[215]],lP) then
      U(sP[l[1528]],lP);
    end
    if not U(sP[l[215]],lP) then
      return l[1329];
    end
  end;
  return lP~=l[1746];
end
