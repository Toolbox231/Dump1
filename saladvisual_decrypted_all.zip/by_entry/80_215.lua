-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #215
-- offset 3340709..3341151 (442 bytes, type=code)

local function DP()
  local pP={};
  local rP,KP=s[87](),qP[l[160]];
  if KP[l[1437]]>l[229]and KP[l[636]]>l[229] then
    pP[1]=bP;
    pP[2]=l[1639];
    pP[3]=(rP[l[1459]][l[588]](rP[l[35]][l[499]](KP[l[1437]]/y[29]+l[659]),rP[l[35]][l[499]](KP[l[636]]/y[29]+l[659])));
    pP[1][pP[2]]=pP[3];
  else
    local pP=dP[l[1639]];
    bP[l[1639]]=rP[l[1459]][l[588]](rP[l[35]][l[850]](pP[l[1437]][l[1485]]-u-l[913],l[229]),rP[l[35]][l[850]](pP[l[636]][l[1485]]-l[913],l[229]));
  end
end
