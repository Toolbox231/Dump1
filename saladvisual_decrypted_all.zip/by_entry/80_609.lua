-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #609
-- offset 3494153..3494875 (722 bytes, type=code)

local function vP(IP)
  local iP,EP,QP=s[87](),IP:GetDescendants();
  for tP,RP in y[3],EP,QP do
    tP=l[1635];
    if RP:IsA(tP) then
      RP[l[82]]=l[383];
      RP[l[1127]]=l[1329];
      RP[l[1219]]=l[383];
      RP[l[1312]]=l[1329];
      RP[l[1391]]=l[393];
    else
      IP=l[1266];
      if RP:IsA(IP) then
        local IP=RP:FindFirstChildOfClass(l[401]);
        if IP then
          IP:Destroy();
        end
        iP[l[1146]](function()
          local IP=s[87]();
          RP[l[702]]=IP[l[128]][l[1034]][l[31]];
          RP[l[873]]=IP[l[128]][l[1227]][l[1005]];
          RP[l[287]]=l[393];
          RP[l[736]]=l[393];
          RP[l[1233]]=l[1329];
          RP[l[47]]=l[1329];
          RP[l[1008]]=l[1329];
          RP[l[1374]]=l[1329];
          RP[l[540]]=RP[l[1698]];
        end);
      elseif RP:IsA(l[778])or RP:IsA(l[1058])or RP:IsA(l[1260])or RP:IsA(l[1245])or RP:IsA(l[1661])or RP:IsA(l[1000]) then
        RP:Destroy();
      end
    end
  end;
end
