-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #332
-- offset 3391841..3396316 (4475 bytes, type=code)

local function BP(wP,WP)
  wP=s[87]();
  WP=X(WP,{[l[572]]=l[524],[l[950]]=l[1329],[l[925]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
  fP[l[668]]+=l[229];
  local VP,_P,XP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
  local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},VP);
  local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[829],l[829]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},xP);
  D(VP,l[786]);
  local kP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[874]},VP);
  local vP=a;
  local IP=l[859];
  local iP={};
  iP[l[1150]]=f();
  iP[l[1016]]=wP[l[1689]][l[772]](l[659],l[659]);
  iP[l[948]]=wP[l[1459]][l[1368]](l[659],l[659]);
  iP[l[1639]]=wP[l[1459]][l[588]](l[1158],l[1158]);
  iP[l[1646]]=l[229];
  iP[l[1451]]=y[30](l[1411]);
  iP[l[936]]=R[l[641]];
  iP[l[2]]=l[229];
  iP[l[1557]]=wP[l[128]][l[1557]][l[220]];
  iP[l[711]]=l[1092];
  local EP=vP(IP,iP,VP);
  local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=wP[l[1459]][l[588]](l[910],l[393]),[l[1639]]=wP[l[1459]][l[772]](l[229],WP[l[925]]and l[132]or l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=wP[l[128]][l[437]][l[1381]],[l[1420]]=WP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=wP[l[128]][l[164]][l[1021]],[l[1634]]=wP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
  local IP=a(l[1742],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},xP);
  local iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[59],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[1243],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},xP);
  local QP=WP[l[925]];
  if QP then
    local tP=a;
    local RP=l[1742];
    local gP={};
    gP[l[1150]]=f();
    gP[l[1016]]=wP[l[1689]][l[772]](l[229],l[659]);
    gP[l[948]]=wP[l[1459]][l[772]](l[229],l[66],l[659],l[393]);
    gP[l[1639]]=wP[l[1459]][l[588]](l[884],l[884]);
    gP[l[1535]]=R[l[1466]];
    gP[l[1646]]=l[229];
    gP[l[1418]]=l[393];
    gP[l[1451]]=y[30](l[1456]);
    gP[l[936]]=R[l[1379]];
    gP[l[2]]=l[615];
    gP[l[1557]]=wP[l[128]][l[1557]][l[220]];
    gP[l[711]]=l[730];
    QP=tP(RP,gP,xP);
  end
  local tP,RP,gP=IP,iP,QP or nil;
  if gP then
    D(gP,l[1158]);
  end
  local IP,iP,QP=wP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
  QP[l[572]]=WP[l[572]];
  IP(iP,QP);
  local wP={[l[266]]=xP,[l[404]]=l[1329]};
  local IP=l[1329];
  if gP then
    local QP=NP(xP,WP[l[572]],_P,XP);
    wP[l[1085]]=QP;
    wP[l[925]]=QP[l[429]];
    local function NP(uP,uP)
      QP:setopen(uP);
    end
    wP[l[691]]=NP;
    d(gP[l[445]],function()
      QP:setopen(not QP[l[404]]);
      y[18]:chime(l[1352]);
    end);
    d(gP[l[1538]],function()
      P(gP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
    end);
    d(gP[l[1628]],function()
      P(gP,H,{[l[2]]=l[615],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
    end);
  end
  local function NP()
    local QP,gP,uP,UP=s[87](),{},l[1646],wP[l[404]]and l[1296]or(IP and l[804]or l[229]);
    gP[uP]=UP;
    P(VP,H,gP);
    UP,gP,uP={},l[747],wP[l[404]]and l[229]or(IP and l[1296]or l[874]);
    UP[gP]=uP;
    P(kP,H,UP);
    P(EP,H,{[l[2]]=wP[l[404]]and l[393]or l[229],[l[1639]]=QP[l[1459]][l[588]](wP[l[404]]and l[310]or l[1158],wP[l[404]]and l[310]or l[1158])});
    P(vP,H,{[l[916]]=wP[l[404]]and l[393]or l[615],[l[510]]=wP[l[404]]and R[l[1095]]or R[l[1379]]});
  end
  local function VP(kP,kP,vP)
    kP=kP and l[383]or l[1329];
    if wP[l[404]]==kP and not y[18][l[921]] then
      return;
    end
    wP[l[404]]=kP;
    NP();
    if wP[l[1686]] then
      wP[l[1686]]:sync(kP);
      wP[l[1686]]:lit(kP);
    end
    if not vP then
      y[18]:chime(kP and l[404]or l[676]);
      if WP[l[1617]] then
        I(WP[l[1617]],kP);
      end
    end
  end
  wP[l[1255]]=VP;
  local function VP(kP)
    return wP[l[404]];
  end
  wP[l[506]]=VP;
  d(tP[l[445]],function()
    wP:set(not wP[l[404]]);
  end);
  d(RP[l[445]],function()
    wP:set(not wP[l[404]]);
  end);
  d(RP[l[1538]],function()
    IP=l[383];
    NP();
  end);
  d(RP[l[1628]],function()
    IP=l[1329];
    NP();
  end);
  if WP[l[950]] then
    wP[l[404]]=l[383];
    NP();
  end
  iP=WP[l[1013]]or hP..l[1074]..WP[l[572]];
  local NP=SP(xP,WP[l[572]],_P,XP,{[l[1463]]=iP,[l[103]]=l[1499],[l[649]]=l[383],[l[1498]]=function(WP)
    wP:set(WP);
  end,[l[194]]=function()
    wP:set(not wP[l[404]]);
  end,[l[1386]]=function()
    return wP[l[404]];
  end});
  wP[l[1686]]=NP;
  NP:lit(wP[l[404]]);
  d(tP[l[861]],function()
    if not NP:flip() then
      return;
    end
    y[18]:chime(l[1352]);
  end);
  d(RP[l[861]],function()
    if not NP:flip() then
      return;
    end
    y[18]:chime(l[1352]);
  end);
  y[18]:hook(iP,l[524],function()
    return wP[l[404]];
  end,function(NP)
    wP:set(NP==l[383]or NP==l[1102]or NP==l[229]);
  end);
  return wP;
end
