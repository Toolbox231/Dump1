-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #886
-- offset 3567534..3568273 (739 bytes, type=code)

local function P(Z)
  local G=s[87]();
  if not T[l[826]] then
    return Z;
  end
  Z=G[l[964]][l[227]];
  local Y=Z and Z[l[952]]or G[l[1689]][l[772]](l[1493],l[958]);
  G[l[1146]](function()
    local j=s[87]();
    local C=j[l[1469]]()[l[1265]];
    local N=j[l[1703]](C)==l[1689];
    if N then
      Y=C;
    end
  end);
  Z=J[l[1581]];
  Z=if G[l[40]](Z)~=l[384]or Z<=l[393]then l[229]else Z;
  local j,C=G[l[1458]]:GetService(l[1408]--[[nparams]]):GetGuiInset()[l[636]],G[l[35]][l[850]](Y[l[1437]]-l[829],l[1592]);
  local N,q=G[l[35]][l[850]](Y[l[636]]-j-l[1249],l[710]),G[l[35]][l[819]](G[l[35]][l[499]](Y[l[1437]]*l[156]),G[l[35]][l[457]](l[253],C),G[l[35]][l[457]](l[1709],C));
  C=G[l[35]][l[819]](N,G[l[35]][l[457]](l[667],N),l[218]);
  return G[l[1459]][l[588]](G[l[35]][l[499]](q/Z),G[l[35]][l[499]](C/Z));
end
