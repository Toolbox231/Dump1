-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #128
-- offset 3302504..3302747 (243 bytes, type=code)

local function aP(dP,PP)
  dP=s[87]();
  if not y[18][l[27]]or y[18][l[1334]] then
    return;
  end
  local ZP,GP=fP[PP]or fP[l[1320]],HP;
  HP=GP%#JP+l[229];
  PP=JP[HP];
  PP[l[1301]]=ZP[l[229]];
  PP[l[1110]]=ZP[l[59]];
  PP[l[105]]=l[393];
  dP[l[1146]](PP[l[363]],PP);
end
