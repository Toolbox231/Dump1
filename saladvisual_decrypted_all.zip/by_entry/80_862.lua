-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #862
-- offset 3563825..3564062 (237 bytes, type=code)

local function d(P,P)
  P=P or{};
  local Z=P[l[1683]];
  local G,b=r(l[1630]);
  return Y(G:color({[l[572]]=P[l[1150]]or b,[l[950]]=P[l[1380]],[l[1013]]=P[l[1315]],[l[1617]]=e(P[l[1315]],Z and function(G)
    Z(G,P[l[747]]);
  end or nil)}),P[l[1315]]);
end
