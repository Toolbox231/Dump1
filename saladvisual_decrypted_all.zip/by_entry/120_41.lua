-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #41
-- offset 3659613..3660108 (495 bytes, type=code)

local function s(J,H)
  local j=J.Character;
  if not j or not j.Parent then
    if H.char then
      m(H);
      H.char=nil;
    end
    return;
  end
  local q=H.wantKey;
  if H.char==j and H.key==q then
    return;
  end
  m(H);
  H.char=j;
  H.key=q;
  local m,O,F,V=H.generation,ipairs,H.want;
  for V,x in O(F)do
    V=not z[4][z[6]]or A[J]~=H or H.generation~=m or J.Character~=j;
    if V then
      return;
    end
    V=y[x];
    q=V and x~="Comet";
    if q then
      D=H;
      pcall(V,j,m,H);
      D=b;
    end
  end;
  O=z[4][z[6]]and A[J]==H and H.generation==m and J.Character==j;
  if O then
    w(H);
  end
end
