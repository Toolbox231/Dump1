-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #845
-- offset 3561572..3561777 (205 bytes, type=code)

local function e(j,C)
  local function N(q,...)
    local b=s[87]();
    if C then
      C(q,...);
    end
    local C=T[l[414]];
    if C then
      local D=T[l[831]]and T[l[831]][l[1334]];
      b[l[1146]](C,q,j,not Y and not D);
    end
  end
  return N;
end
