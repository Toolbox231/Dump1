-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #122
-- offset 138964..139413 (449 bytes, type=code)

function(T,n)
  n=type(n)=="table"and n or{};
  local Z,Y=a[T]or{},true;
  for j,p in pairs(n)do
    if j=="color" then
      if not q(Z[j],p) then
        Y=false;
        break;
      end
    elseif Z[j]~=p then
      Y=false;
      break;
    end
  end;
  if Y then
    for j in pairs(Z)do
      if n[j]==nil then
        Y=false;
        break;
      end
    end;
  else
  end
  if Y then
    return;
  end
  a[T]=table.clone(n);
  for n,n in pairs(l)do
    if n.group==T then
      D(n);
    end
  end;
  for n,n in pairs(f)do
    for a,a in pairs(n.worn)do
      if a.group==T then
        D(a);
      end
    end;
  end;
end
