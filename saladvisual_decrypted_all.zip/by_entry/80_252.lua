-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #252
-- offset 3362134..3362350 (216 bytes, type=code)

function()
  local BP,FP=s[87](),e(_P)[l[636]];
  if not wP[l[1273]] then
    return;
  end
  WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
  if not C[VP] then
    VP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
  end
end
