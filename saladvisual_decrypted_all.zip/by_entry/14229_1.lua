-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[14229] / function #1
-- offset 3626537..3627201 (664 bytes, type=code)

function(s,s)
  local l=s[1];
  local L=s[2];
  return function()
    local s=3;
    while true do
      local y,z=s<=1;
      if y then
        local y=s<=0;
        if y then
          local y;
          L[4][L[6]]=(1*L[4][L[6]]+172700894)%268435456;
          l[4][l[6]]=(458213*l[4][l[6]]+74377499)%268435456;
          l[4][l[6]],s=(481461*l[4][l[6]]+3246443)%268435456,2;
        else
          return;
        end
      else
        local L=s<=2;
        if L then
          l[4][l[6]]=(588337*l[4][l[6]]+203876361)%268435456;
          l[4][l[6]]=(357699*l[4][l[6]]+31265881)%268435456;
          l[4][l[6]],s=(136033*l[4][l[6]]+49253271)%268435456,1;
        else
          l[4][l[6]]=(913407*l[4][l[6]]+126512365)%268435456;
          l[4][l[6]]=(170231*l[4][l[6]]+183431175)%268435456;
          l[4][l[6]],s=(838247*l[4][l[6]]+83613565)%268435456,0;
        end
      end
    end;
  end;
end
