-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #825
-- offset 3557057..3557594 (537 bytes, type=code)

local function z(f,a)
  local d=s[87]();
  if d[l[1703]](f)~=l[1089] then
    return;
  end
  local P=J[l[567]--[[info]]][T[l[810]](a)];
  if not P then
    f[l[1420]]=l[1746];
    return;
  end
  f[l[1420]]=l[1746];
  a=f:FindFirstChild(l[79]);
  if not a then
    a=d[l[1089]][l[772]](l[859]);
    a[l[1150]]=l[79];
    a[l[1646]]=l[229];
    a[l[1016]]=d[l[1689]][l[772]](l[659],l[659]);
    a[l[948]]=d[l[1459]][l[1368]](l[659],l[659]);
    a[l[1639]]=d[l[1459]][l[1368]](l[731],l[731]);
    a[l[1557]]=d[l[128]][l[1557]][l[220]];
    a[l[382]]=f;
  else
  end
  a[l[1451]]=l[1440]..P;
  a[l[936]]=f[l[510]];
  a[l[711]]=f[l[711]];
end
