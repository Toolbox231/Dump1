-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #152
-- offset 3695815..3696034 (219 bytes, type=code)

function()
  if setclipboard and pcall(setclipboard,(("roblox://experiences/start?placeId=%d&gameInstanceId=%s"):format(game.PlaceId,game.JobId))) then
    J(true,"join link copied");
  else
    J(false,"No clipboard support");
  end
end
