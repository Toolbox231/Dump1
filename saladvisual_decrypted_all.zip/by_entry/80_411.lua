-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #411
-- offset 3418890..3419964 (1074 bytes, type=code)

local function MP(sC,nC)
  local JC,HC,fC,aC=s[87](),NP(sC[l[572]]),sC[l[892]]or yC[l[1072]][TC]==sC,nC and n or H;
  local NP,dC,PC,ZC=sC[l[1466]],{},l[1646],HC and l[922]or(fC and l[330]or l[229]);
  dC[PC]=ZC;
  P(NP,aC,dC);
  ZC,nC=sC[l[1473]],{};
  nC[l[747]]=HC and l[509]or l[229];
  P(ZC,aC,nC);
  nC,PC=sC[l[1642]],{};
  PC[l[1646]]=HC and l[1432]or l[229];
  P(nC,aC,PC);
  P(sC[l[451]],aC,{[l[1639]]=JC[l[1459]][l[772]](l[393],l[863],l[393],HC and l[750]or l[393]),[l[1646]]=HC and l[1296]or l[229]});
  P(sC[l[1615]],aC,{[l[916]]=HC and l[393]or(fC and l[263]or l[323]),[l[510]]=HC and R[l[1095]]or R[l[1379]]});
  if BP[l[1693]] then
    nC,NP=sC[l[595]],{};
    NP[l[1646]]=HC and l[1296]or l[229];
    P(nC,aC,NP);
    local NP,nC,GC,YC=sC[l[741]],{},l[747],HC and l[229]or(fC and l[1296]or l[1431]);
    nC[GC]=YC;
    P(NP,aC,nC);
    PC,nC=sC[l[1572]],{[l[2]]=HC and l[393]or l[229]};
    nC[l[1639]]=JC[l[1459]][l[588]](HC and l[730]or l[786],HC and l[730]or l[786]);
    P(PC,aC,nC);
  else
    dC,ZC=sC[l[1040]],{[l[2]]=HC and l[393]or l[229]};
    ZC[l[1639]]=JC[l[1459]][l[588]](HC and l[310]or l[1092],HC and l[310]or l[1092]);
    P(dC,aC,ZC);
  end
end
