-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #232
-- offset 3351846..3352088 (242 bytes, type=code)

function(pP)
  local KP=s[87]();
  if not OP[l[259]] then
    return;
  end
  if pP[l[1317]]==KP[l[128]][l[1317]][l[765]]or pP[l[1317]]==KP[l[128]][l[1317]][l[239]] then
    if pP[l[1317]]==KP[l[128]][l[1317]][l[239]]and pP~=OP[l[225]] then
      return;
    end
    BP();
  end
end
