-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #665
-- offset 3509790..3510737 (947 bytes, type=code)

local function j(A,V)
  A=s[87]();
  V=X(V,{[l[572]]=l[1724],[l[13]]=l[1746],[l[1658]]=l[1746]});
  local t=G(F,V,l[229],#sP[l[245]]+l[229]);
  local G,F=n(o[l[572]]..l[1074]..V[l[572]]);
  local n={[l[572]]=V[l[572]],[l[178]]=G,[l[1466]]=t[l[1466]]};
  local function V(zP,zP)
    return F:section(zP);
  end
  n[l[146]]=V;
  local function V(zP,zP)
    return F:color(zP);
  end
  n[l[1409]]=V;
  local function V(zP,zP)
    return F:configs(zP);
  end
  n[l[963]]=V;
  local function V(zP,zP)
    return F:clone(zP);
  end
  n[l[822]]=V;
  local function V(zP,zP)
    return F:gallery(zP);
  end
  n[l[484]]=V;
  n[l[1674]]=function(V)
    t[l[406]](V);
    if V then
      G[l[382]]=qP;
      G[l[1324]]=l[383];
      F[l[811]]();
    else
      G[l[1324]]=l[1329];
      G[l[382]]=bP;
      F[l[86]]();
    end
  end;
  local function G(F)
    J(n);
  end
  n[l[199]]=G;
  d(t[l[974]][l[445]],function()
    J(n);
  end);
  A[l[1346]][l[968]](sP[l[245]],n);
  if not R[l[1324]] then
    R[l[1324]]=l[383];
    w[l[183]](l[658]);
    P(R,H,{[l[2]]=l[615]});
  end
  if o[l[1600]]and not sP[l[1600]] then
    sP:setopen(l[383]);
  end
  return n;
end
