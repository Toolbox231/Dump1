-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #544
-- offset 3471045..3471913 (868 bytes, type=code)

local function TC(nC)
  local JC=s[87]();
  if JC[l[40]](nC)==l[409] then
    if nC==l[1746] then
      return nil;
    end
    return{[l[572]]=nC,[l[1094]]=nC};
  end
  if JC[l[40]](nC)~=l[1346] then
    return nil;
  end
  local HC=nC[l[572]]or nC[l[1150]]or nC[l[1094]]or nC[l[1053]]or nC[l[1463]]or nC[l[1554]];
  if HC==nil then
    return nil;
  end
  HC=JC[l[1130]](HC);
  local fC,aC=JC[l[1382]](nC[l[1463]]or nC[l[1554]]or nC[l[568]]or nC[l[584]]or nC[l[1191]]or nC[l[1199]]or nC[l[1428]]or nC[l[707]]or nC[l[1675]]),nC[l[1736]]or nC[l[1451]]or nC[l[13]]or nC[l[79]]or nC[l[103]]or nC[l[798]]or nC[l[1035]];
  return{[l[572]]=HC,[l[1094]]=JC[l[1130]](nC[l[1062]]or nC[l[1389]]or nC[l[1094]]or nC[l[1053]]or HC),[l[1463]]=fC,[l[103]]=(JC[l[40]](aC)==l[409]or JC[l[40]](aC)==l[384])and aC or nil,[l[83]]=JC[l[1703]](nC[l[83]])==l[1689]and nC[l[83]]or nil,[l[297]]=JC[l[1703]](nC[l[297]])==l[1689]and nC[l[297]]or nil};
end
