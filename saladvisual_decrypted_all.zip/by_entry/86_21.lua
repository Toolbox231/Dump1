-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #21
-- offset 3213050..3213361 (311 bytes, type=code)

local function K(o)
  local c=l;
  local m=c.Lib;
  local c,S=m.quiet,m.configApplying;
  m.quiet=true;
  m.configApplying=true;
  local O,B=pcall(function()
    for A,w in pairs(o)do
      local o=m.pool[A];
      if o then
        o.set(w);
      end
    end;
  end);
  m.quiet=c;
  m.configApplying=S;
  S=not O;
  if S then
    local o;
    O=T;
    O("shader preset: "..tostring(B));
  end
end
