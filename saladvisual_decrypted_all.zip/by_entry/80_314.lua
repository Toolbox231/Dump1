-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #314
-- offset 3384492..3384745 (253 bytes, type=code)

function(BP)
  if BP==nil then
    if FP[l[1626]]~=nil then
      local wP=FP[l[1626]];
      FP[l[1626]]=nil;
      if fP[l[1600]]~=wP then
        fP:setopen(wP);
      end
    end
    return;
  end
  if BP and not fP[l[1600]] then
    if FP[l[1626]]==nil then
      FP[l[1626]]=l[1329];
    end
    fP:setopen(l[383]);
  end
end
