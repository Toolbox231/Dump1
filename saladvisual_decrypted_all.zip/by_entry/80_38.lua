-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #38
-- offset 3272247..3272620 (373 bytes, type=code)

local function r(K)
  local o=s[87]();
  if o[l[40]](K)~=l[409] then
    return nil;
  end
  local c=o[l[409]][l[1710]](K,l[16],l[1746]);
  c=if#c==l[863]then o[l[409]][l[1710]](c,l[564],l[236])else c;
  if #c~=l[1158] then
    return nil;
  end
  K=o[l[1382]](c,l[829]);
  if not K then
    return nil;
  end
  return o[l[360]][l[353]](o[l[35]][l[499]](K/l[546])%l[598],o[l[35]][l[499]](K/l[598])%l[598],K%l[598]);
end
