-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #469
-- offset 3445407..3445741 (334 bytes, type=code)

local function xP()
  local vP=QP[l[1569]];
  local RP=lC[l[404]]and l[393]or l[229];
  b(QP,lC[l[404]]and l[894]or l[304],lC[l[404]]and N or q,function(gP)
    local uP=vP+(RP-vP)*gP;
    QP[l[1569]]=uP;
    if EP then
      EP[l[1646]]=uP;
      GP[l[747]]=l[615]+l[411]*uP;
    end
    if gP>=l[229] then
      QP[l[1324]]=lC[l[404]];
      if EP then
        EP[l[1324]]=lC[l[404]];
      end
    end
  end);
end
