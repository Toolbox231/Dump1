-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #608
-- offset 3493814..3494152 (338 bytes, type=code)

local function kP(vP,IP,iP)
  local EP,QP=vP:GetChildren(),IP:GetChildren();
  for vP=l[229],#EP,l[229]do
    local tP,RP=EP[vP],QP[vP];
    RP=if not RP or RP[l[1150]]~=tP[l[1150]]or RP[l[657]]~=tP[l[657]]then IP:FindFirstChild(tP[l[1150]])else RP;
    if RP then
      if tP:IsA(l[1635])and RP:IsA(l[1635]) then
        iP[#iP+l[229]]={tP,RP};
      end
      kP(tP,RP,iP);
    end
  end;
end
