-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #273
-- offset 3375820..3376052 (232 bytes, type=code)

local function BP(FP)
  FP=s[87]();
  local hP=FP[l[655]][l[1587]]();
  FP=hP-fP;
  if FP<l[874] then
    return l[1329];
  end
  fP=hP;
  if _P[l[404]]and(W(IP,l[59])or kP and W(kP,l[59])) then
    return l[1329];
  end
  _P:setopen(not _P[l[404]]);
  return l[383];
end
