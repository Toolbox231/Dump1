-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #914
-- offset 3571898..3572181 (283 bytes, type=code)

local function K(S,O)
  local B,A=s[87](),not o[S];
  if A then
    local A=m();
    local m=A:sub({[l[572]]=S,[l[13]]=O});
    local O=m[l[1674]];
    if not B[l[1346]][l[23]](Y,A) then
      B[l[1346]][l[968]](Y,A);
    end
    m[l[1674]]=function(B)
      if O then
        O(B);
      end
      if B then
        c=m;
        b(A);
      end
    end;
    o[S]=m;
  end
  return o[S];
end
