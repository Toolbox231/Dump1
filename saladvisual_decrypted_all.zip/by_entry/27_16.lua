-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #16
-- offset 21970..22422 (452 bytes, type=code)

local function C(N,q,m,S)
  local O=G;
  if not O then
    return false;
  end
  local B,A,w,F=m-N,S-q,1,0;
  for h=1,4,1 do
    S,m,O=h==1;
    if S then
      m,O=-B,N-G.X;
    else
      local S=h==2;
      if S then
        m,O=B,Y.X-N;
      else
        local N=h==3;
        if N then
          m,O=-A,q-G.Y;
        else
          m,O=A,Y.Y-q;
        end
      end
    end
    if m==0 then
      if O<0 then
        return false;
      end
    else
      h=O/m;
      if m<0 then
        if h>w then
          return false;
        end
        F=if h>F then h else F;
      else
        if h<F then
          return false;
        end
        w=if h<w then h else w;
      end
    end
  end;
  return true;
end
