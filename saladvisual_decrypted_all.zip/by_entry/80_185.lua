-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #185
-- offset 3329492..3329891 (399 bytes, type=code)

function(t)
  local R=s[87]();
  if t[l[1317]]~=R[l[128]][l[1317]][l[1356]]and t[l[1317]]~=R[l[128]][l[1317]][l[239]] then
    return;
  end
  local g=E;
  local u=g;
  E=nil;
  local E,yP=not u;
  if E then
    yP=E;
  else
    g=S;
    yP=g>l[393];
  end
  if yP then
    return;
  end
  yP=(t[l[948]]-u)[l[945]]>l[930]or R[l[655]][l[1587]]()-Q>l[509];
  if yP then
    return;
  end
  for E,E in y[3],y[18][l[769]],nil do
    R[l[1146]](function()
      E:toggle();
    end);
  end;
end
