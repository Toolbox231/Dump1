-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #504
-- offset 3452785..3453441 (656 bytes, type=code)

local function V(fP,aP)
  local GP=s[87]();
  local NP=a;
  local SP=l[1742];
  local BP={};
  BP[l[1150]]=f();
  BP[l[1016]]=GP[l[1689]][l[772]](l[229],l[659]);
  BP[l[948]]=GP[l[1459]][l[772]](l[229],fP,l[393],l[1413]);
  BP[l[1639]]=GP[l[1459]][l[588]](l[1707],l[1707]);
  BP[l[1535]]=R[l[1466]];
  BP[l[1646]]=l[229];
  BP[l[1418]]=l[393];
  BP[l[1451]]=y[30](aP);
  BP[l[936]]=R[l[1379]];
  BP[l[2]]=l[986];
  BP[l[1557]]=GP[l[128]][l[1557]][l[220]];
  BP[l[711]]=l[1092];
  local fP=NP(SP,BP,w);
  D(fP,l[303]);
  d(fP[l[1538]],function()
    P(fP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
  end);
  d(fP[l[1628]],function()
    P(fP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
  end);
  return fP;
end
