-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[81] / function #0
-- offset 3640602..3640897 (295 bytes, type=code)

function(s,s,s)
  return function(s,s,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    return function()
      local s;
      local s=l;
      if not s.On then
        return;
      end
      local l,T=pairs;
      s=L;
      for L,T in l(s)do
        local s=L.Parent;
        if s then
          local s;
          local s=y;
          pcall(s,L,T);
        else
          local s;
          local s=z;
          s(L);
        end
      end;
    end;
  end;
end
