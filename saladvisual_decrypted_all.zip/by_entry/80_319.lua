-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #319
-- offset 3385132..3385416 (284 bytes, type=code)

function(NP,NP)
  local xP,kP,vP,IP=s[87](),aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
  aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=wP,WP,VP;
  local wP,WP=xP[l[1146]](fP[XP],fP,NP);
  aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=kP,vP,IP;
  if not wP then
    xP[l[279]](WP,l[59]);
  end
  xP[l[1346]][l[1357]](FP[l[12]]);
  return WP;
end
