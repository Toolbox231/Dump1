-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[124] / function #0
-- offset 3076870..3077481 (611 bytes, type=code)

function(s,l,l)
  return function(l,l,L,L)
    local L=l[1];
    return function(l,y)
      local z=l[13];
      for z=1,y,2 do
        for y=1,32,4 do
          local T,n=y-1;
          local n,J=s:qS(L,T),y+1-1;
          T,z=s:qS(L,J),y+2-1;
          local J,H=s:qS(L,z),y+3-1;
          local z,f,a,d=s:qS(L,H),l[n],l[T],l[J];
          y=l[z];
          f=(f+a)%4294967296;
          H=s[79](y,f);
          y=s[85](s[22](H,16),(s[98](H,16)))%4294967296;
          d=(d+y)%4294967296;
          H=s[79](a,d);
          a=s[85](s[22](H,12),(s[98](H,20)))%4294967296;
          f=s[53](f+a,4294967295);
          H=s[79](y,f);
          y=s[85](s[22](H,8),(s[98](H,24)))%4294967296;
          d=(d+y)%4294967296;
          H=s[79](a,d);
          a=s[85](s[22](H,7),(s[98](H,25)))%4294967296;
          l[n]=f;
          l[T]=a;
          l[J]=d;
          l[z]=y;
        end;
      end;
    end;
  end;
end
