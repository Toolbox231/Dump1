-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #18
-- offset 3207429..3207668 (239 bytes, type=code)

local function N(q,b)
  q=b=="bloom";
  if q then
    local q=f;
    return q;
  else
    local q=b=="rays";
    if q then
      local q=a;
      return q;
    else
      local q=b=="blur";
      if q then
        local q=d;
        return q;
      else
        local q=b=="grade";
        if q then
          local q=P;
          return q;
        end
      end
    end
  end
end
