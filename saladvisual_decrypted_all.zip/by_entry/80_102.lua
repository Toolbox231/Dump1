-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #102
-- offset 3289933..3290222 (289 bytes, type=code)

local function sP(lP)
  local LP=s[87]();
  if LP[l[40]](lP)~=l[409] then
    return nil;
  end
  lP=LP[l[409]][l[56]](lP,l[381])or l[1746];
  lP=LP[l[409]][l[1710]](lP,l[1236],l[1746]);
  if #lP==l[393]or#lP>l[633]or lP==l[241]or lP==l[1056]or lP:find(l[129])or lP:match(l[767]) then
    return nil;
  end
  return lP;
end
