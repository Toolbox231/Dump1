-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #473
-- offset 3445906..3446308 (402 bytes, type=code)

local function gP()
  local uP=S;
  if uP>l[393] then
    FP();
    return;
  end
  if not LP[l[1600]]or not KP[l[1324]]or not XP[l[1324]] then
    lC:setopen(l[1329]);
    return;
  end
  local XP,UP,nC,JC,HC,fC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],kP[l[81]],kP[l[160]];
  uP=HC[l[636]]+fC[l[636]]*l[659];
  if uP<XP[l[636]]or uP>XP[l[636]]+UP[l[636]]or uP<nC[l[636]]or uP>nC[l[636]]+JC[l[636]] then
    lC:setopen(l[1329]);
    return;
  end
  FP();
end
