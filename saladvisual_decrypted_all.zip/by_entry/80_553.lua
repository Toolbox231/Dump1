-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #553
-- offset 3473625..3474433 (808 bytes, type=code)

local function aC(dC,PC)
  if not dC[l[1466]][l[1324]]and not PC then
    return;
  end
  local ZC=dC[l[572]]~=nil and V(dC[l[572]]);
  local V,GC=dC[l[892]]and not ZC,ZC and l[1422]or l[1250];
  local YC,eC,jC,CC,NC,qC=ZC and l[1209]or(V and l[323]or l[229]),ZC and l[615]or(V and l[1419]or l[229]),ZC and R[l[98]]or R[l[966]],ZC and l[393]or(V and l[841]or l[330]),ZC and R[l[1095]]or R[l[1379]],ZC and l[393]or(V and l[629]or l[120]);
  dC[l[1040]][l[1324]]=ZC;
  if PC then
    dC[l[1466]][l[1646]]=GC;
    dC[l[1642]][l[1646]]=YC;
    dC[l[1473]][l[747]]=eC;
    dC[l[1473]][l[1630]]=jC;
    dC[l[1615]][l[916]]=CC;
    dC[l[1615]][l[510]]=NC;
    dC[l[748]][l[2]]=qC;
    return;
  end
  P(dC[l[1466]],H,{[l[1646]]=GC});
  P(dC[l[1642]],H,{[l[1646]]=YC});
  P(dC[l[1473]],H,{[l[747]]=eC,[l[1630]]=jC});
  P(dC[l[1615]],H,{[l[916]]=CC,[l[510]]=NC});
  P(dC[l[748]],H,{[l[2]]=qC});
end
