-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #119
-- offset 3298615..3299024 (409 bytes, type=code)

local function g(u,zP)
  local TP=s[87]();
  zP=sP(zP);
  if not zP or TP[l[40]](TP[l[611]])~=l[1712]or not M() then
    return nil;
  end
  local M,nP=TP[l[1146]](y[18][l[806]],y[18]);
  if not M or TP[l[40]](nP)~=l[409] then
    return nil;
  end
  if not TP[l[1146]](TP[l[611]],lP(zP),nP) then
    return nil;
  end
  if TP[l[40]](TP[l[1216]])==l[1712] then
    u,M=TP[l[1146]](TP[l[1216]],lP(zP));
    if not u or M~=nP then
      return nil;
    end
  end
  return zP;
end
