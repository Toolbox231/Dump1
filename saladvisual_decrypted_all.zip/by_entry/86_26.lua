-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #26
-- offset 3216854..3217059 (205 bytes, type=code)

local function o(c)
  return(tostring(c or""):gsub("[_%-]+"," "):gsub("(%l)(%u)","%1 %2"):gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$",""):gsub("(%a)([%w']*)",function(c,m)
    return c:upper()..m:lower();
  end));
end
