-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #857
-- offset 3563008..3563424 (416 bytes, type=code)

local function P(b,D)
  b=s[87]();
  D=D or{};
  local K,o=r(l[1122]);
  local c=K:slider({[l[572]]=o,[l[457]]=b[l[1382]](D[l[946]])or l[393],[l[850]]=b[l[1382]](D[l[1641]])or l[856],[l[950]]=D[l[1380]],[l[109]]=G(D),[l[26]]=b[l[40]](D[l[252]])==l[409]and D[l[252]]or l[1746],[l[1013]]=D[l[1315]],[l[1617]]=e(D[l[1315]],D[l[1683]])});
  Z(c,b[l[1382]](D[l[946]])or l[393],b[l[1382]](D[l[1641]])or l[856]);
  return Y(c,D[l[1315]]);
end
