-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #16
-- offset 3666016..3666239 (223 bytes, type=code)

local function p()
  local r,K=C,false;
  for o,c in pairs(r)do
    K=if o.Parent and o.AnimationId~=c then if pcall(function()
      local r=o.Parent;
      o.AnimationId=c;
      o.Parent=nil;
      o.Parent=r;
    end)then true else K else K;
  end;
  C={};
  return K;
end
