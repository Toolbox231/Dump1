-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #828
-- offset 3557724..3557932 (208 bytes, type=code)

local function z(f)
  local a=s[87]();
  for d,d in a[l[1471]](J[l[278]]:GetDescendants())do
    if d:IsA(l[1070])and d[l[1420]]==l[1397] then
      d[l[1420]]=a[l[1130]](f or l[1746]);
      return l[383];
    end
  end;
  return l[1329];
end
