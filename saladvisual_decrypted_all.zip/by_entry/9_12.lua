-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #12
-- offset 3630740..3631040 (300 bytes, type=code)

local function Y(V)
  local _=a:GetMouse();
  local X;
  local X=z[4][z[6]]and P and Z and V and m();
  if X then
    A();
    V=G==nil;
    if V then
      G=_.Icon;
    end
    if _.Icon~="" then
      _.Icon="";
    end
    F();
  else
    W();
    local A,V=G~=nil;
    if A then
      local X;
      local X=T;
      V=not X.Lib.cursor;
    else
      V=A;
    end
    if V then
      _.Icon=G;
    end
    G=nil;
    h();
  end
end
