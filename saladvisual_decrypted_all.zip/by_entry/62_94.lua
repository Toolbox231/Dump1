-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #94
-- offset 3244278..3244578 (300 bytes, type=code)

function()
  m();
  o+=1;
  b.On=false;
  Q,t,X,x=false,false,false,false;
  r+=1;
  local s=O;
  if s then
    pcall(function()
      O:Disconnect();
    end);
    O=nil;
  end
  s=W;
  if s then
    W:Disconnect();
    W=nil;
  end
  s=V;
  if s then
    V:Disconnect();
    V=nil;
  end
  v();
  f();
  H();
  for s,s in pairs(p)do
    pcall(function()
      s:Destroy();
    end);
  end;
  table.clear(p);
end
