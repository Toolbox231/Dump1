-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #117
-- offset 138004..138302 (298 bytes, type=code)

function()
  local F=d.ById[S];
  local h=F and Y(F.g);
  local Y,F=h and h[S];
  h=Y and y[4][y[6]]and o.busy[S]==Z and o.want[S]==A and o.char==c and c.Parent;
  if h then
    p(S,Y,c,A,o.worn,j,function()
      return f[j]==o and o.busy[S]==Z and not o.worn[S]and o.want[S]==A and o.char==c and c.Parent~=nil;
    end);
  end
end
