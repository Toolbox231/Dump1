-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #241
-- offset 3358390..3359383 (993 bytes, type=code)

local function XP(xP)
  local kP={};
  local vP,IP=s[87](),BP;
  if IP==xP then
    return;
  end
  BP=xP;
  for IP,IP in y[3],cP[l[1271]],nil do
    IP[l[1324]]=not xP;
  end;
  if xP then
    hP[l[1324]]=l[383];
    kP[1]=_P;
    kP[2]=l[1451];
    kP[3]=(y[30](l[898]));
    kP[1][kP[2]]=kP[3];
    P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[959],l[1435],l[393],l[941]),[l[916]]=l[393]});
    P(WP,H,{[l[747]]=l[615]});
    P(VP,H,{[l[1646]]=l[615]});
    P(_P,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
    vP[l[1022]][l[1330]](l[841],function()
      local cP=BP;
      if cP then
        hP:CaptureFocus();
      end
    end);
  else
    wP=vP[l[655]][l[1587]]();
    kP[4]=_P;
    kP[5]=l[1451];
    kP[6]=(y[30](l[4]));
    kP[4][kP[5]]=kP[6];
    hP:ReleaseFocus();
    if hP[l[1420]]~=l[1746] then
      hP[l[1420]]=l[1746];
    end
    P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[393],l[393],l[393],l[941]),[l[916]]=l[229]});
    P(WP,H,{[l[747]]=l[1017]});
    P(VP,H,{[l[1646]]=l[229]});
    P(_P,H,{[l[2]]=l[874],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
    vP[l[1022]][l[1330]](l[269],function()
      local cP=BP;
      if not cP then
        hP[l[1324]]=l[1329];
      end
    end);
  end
end
