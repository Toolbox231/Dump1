-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #38
-- offset 3659176..3659503 (327 bytes, type=code)

function(s,J,H)
  local j,O=not s;
  if j then
    O=j;
  else
    local F;
    local F=n;
    O=s==F;
  end
  if O then
    return;
  end
  O=A[s];
  if not O then
    O=q(H);
    A[s]=O;
  else
  end
  j=H or O.color;
  s=O.color~=j;
  O.color=j;
  j=table.concat(J or{},",");
  if O.wantKey~=j then
    O.generation=(O.generation or 0)+1;
    O.key=nil;
  elseif s then
    w(O);
  end
  O.want=J or{};
  O.wantKey=j;
end
