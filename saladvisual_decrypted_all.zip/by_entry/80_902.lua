-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #902
-- offset 3570481..3570791 (310 bytes, type=code)

local function p(r)
  local r,K=s[87](),C[l[897]];
  if r[l[40]](K)~=l[1346] then
    return nil;
  end
  for o,o in r[l[1471]](C[l[1206]])do
    if o==K then
      return r[l[1130]](o[l[572]]);
    end
    for c,c in r[l[1471]](o[l[245]]or{})do
      if c==K then
        return r[l[1130]](o[l[572]])..l[532]..r[l[1130]](c[l[572]]);
      end
    end;
  end;
  return nil;
end
