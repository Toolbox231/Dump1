-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #35
-- offset 3271672..3271920 (248 bytes, type=code)

function(o)
  local S=s[87]();
  if not D[l[382]] then
    m:Disconnect();
    if C[D]==m then
      C[D]=nil;
    end
    return;
  end
  c=S[l[35]][l[457]](c+o,p);
  S=c;
  if S<l[393] then
    K(l[393]);
    return;
  end
  K(r(c/p));
  o=c;
  if o>=p then
    m:Disconnect();
    if C[D]==m then
      C[D]=nil;
    end
  end
end
