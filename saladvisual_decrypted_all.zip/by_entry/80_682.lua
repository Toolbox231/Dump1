-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #682
-- offset 3512230..3512492 (262 bytes, type=code)

local function T(n,J)
  n=s[87]();
  if n[l[1703]](J)==l[802] then
    LP[l[1686]]=J;
    HP();
    return;
  end
  if n[l[40]](J)==l[409] then
    local G,Y=n[l[1146]](function()
      local j=s[87]();
      return j[l[128]][l[880]--[[readu32]]][J];
    end);
    if G and n[l[1703]](Y)==l[802] then
      LP[l[1686]]=Y;
      HP();
    end
  end
end
