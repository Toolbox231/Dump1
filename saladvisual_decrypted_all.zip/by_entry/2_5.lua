-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[2] / function #5
-- offset 3641845..3642227 (382 bytes, type=code)

local function L()
  local n=l;
  local J=n.WindowFrame;
  local H,f=J and J.Parent and J.Visible;
  if H then
    n=l;
    f=n.Lib.shown;
  else
    f=H;
  end
  if not f then
    return;
  end
  f,n,H=l,J.AbsolutePosition-l.ScreenGui.AbsolutePosition,J.AbsoluteSize;
  local l,f,a,d,P=n.X,n.Y,n.X+H.X,n.Y+H.Y;
  H=y;
  for y,P in pairs(H)do
    if y.Visible then
      n,J=pcall(z,y,P,l,f,a,d);
      if n and J then
        y.Visible=false;
      end
    end
  end;
end
