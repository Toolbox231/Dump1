-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #848
-- offset 3561902..3562313 (411 bytes, type=code)

local function Y(C,N,q)
  local b={[l[953]]=C};
  local function D(p)
    return C:get();
  end
  b[l[582]]=D;
  local function D(p,p)
    j(C[l[1255]],C,p);
  end
  b[l[1629]]=D;
  local function D(p,p)
    j(C[l[1255]],C,p);
  end
  b[l[21]]=D;
  local function j(D,p)
    D=s[87]();
    local r=D[l[40]](C)==l[1346]and D[l[713]](C,l[266]);
    if D[l[1703]](r)==l[1089] then
      r[l[1324]]=p and l[383]or l[1329];
    end
  end
  b[l[99]]=j;
  if q then
    q(b,C);
  end
  return a(N,f(b));
end
