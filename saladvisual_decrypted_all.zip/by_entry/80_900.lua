-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #900
-- offset 3570276..3570480 (204 bytes, type=code)

local function b(p)
  local r=s[87]();
  local K=r[l[1471]];
  for o,c in K(Y)do
    local K=c==p;
    o=K and q;
    if o then
      continue;
    end
    if c[l[1600]]~=K and c[l[1521]--[[0]]] then
      r[l[1146]](function()
        c:setopen(K);
      end);
    end
  end;
end
