-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #17
-- offset 22423..22683 (260 bytes, type=code)

local function N(q,m,S,O,B)
  if s.Glow then
    local A=D.take();
    A.From=q;
    A.To=m;
    A.Color=S;
    A.Thickness=math.max(1,O*3.2);
    A.Transparency=B*0.16;
    A.Visible=true;
  end
  local A=D.take();
  A.From=q;
  A.To=m;
  A.Color=S;
  A.Thickness=math.max(1,O);
  A.Transparency=B;
  A.Visible=true;
end
