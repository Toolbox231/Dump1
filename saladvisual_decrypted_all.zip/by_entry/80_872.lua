-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #872
-- offset 3565602..3566080 (478 bytes, type=code)

local function a(d)
  d=s[87]();
  local P=d[l[713]](q,l[947]);
  local Z=P and P[l[925]];
  if not Z then
    return C;
  end
  p();
  local P={[l[557]]=d[l[1488]]({[l[1577]]=C[l[557]][l[1577]]},{[l[533]]=Z}),[l[1691]]=C};
  local function d(G,G)
    return j(P,G);
  end
  P[l[1254]]=d;
  local function d(G,G)
    G=G or{};
    Z:button({[l[572]]=G[l[1150]]or l[1453],[l[13]]=G[l[79]]and T[l[810]](G[l[79]])or nil,[l[1617]]=G[l[1683]]});
    return{};
  end
  P[l[1003]]=d;
  P[l[557]]=Z;
  P[l[557]][l[1577]]=C[l[557]][l[1577]];
  return P;
end
