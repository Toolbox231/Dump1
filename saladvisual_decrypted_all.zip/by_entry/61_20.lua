-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #20
-- offset 113990..114277 (287 bytes, type=code)

local function G(j)
  local C={};
  for N,q in ipairs(Z)do
    N=j:FindFirstChild(q);
    if N and(N:IsA("BasePart")) then
      C[#C+1]=N;
    end
  end;
  if #C<=1 then
    for Z,Z in ipairs(j:GetChildren())do
      if Z:IsA("BasePart")and Z.Name~="HumanoidRootPart"and not table.find(C,Z) then
        C[#C+1]=Z;
      end
    end;
  end
  return C;
end
