-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #23
-- offset 3653476..3655254 (1778 bytes, type=code)

local function I(i,E,Q)
  Q,D=Q or D,b;
  local t,R,g=k(v),Q==b;
  local k=not t or not z[4][z[6]]or not i.Parent;
  if k then
    return;
  end
  k=nil;
  if R then
    local v=not N.On or E~=r;
    if v then
      k=v;
    else
      local v;
      local v=n;
      k=v.Character~=i;
    end
  else
    k=R;
  end
  if k then
    return;
  end
  if not R and(Q.char~=i or Q.generation~=E) then
    return;
  end
  R=D;
  k=R;
  D=Q;
  R=t:Clone();
  for v,v in ipairs(R:GetDescendants())do
    if v:IsA("LuaSourceContainer") then
      v:Destroy();
    end
  end;
  t,E=ipairs,s[70](R:GetChildren());
  for v,Q in t(s:ZT(E))do
    v=x(i,Q.Name)or F(i,"UpperTorso","Torso","HumanoidRootPart");
    if v then
      local F,x=ipairs,s[70](Q:GetChildren());
      for i,E in F(s:ZT(x))do
        E.Parent=v;
        D.borrowed[#D.borrowed+1]=E;
        i=E:GetDescendants();
        i[#i+1]=E;
        for s,F in ipairs(i)do
          E=F:IsA("ParticleEmitter");
          if E then
            O(F,F.Parent);
          else
            s=F:IsA("Light")or F:IsA("Beam")or F:IsA("Trail");
            if s then
              if c and(F:IsA("Beam")or F:IsA("Trail")) then
                c(F);
              end
              local s,c=D.accents,D.accents;
              local O,x=#c+1,{item=F,color=F.Color};
              x.brightness,s[O]=F:IsA("Light")and F.Brightness or 1,x;
            else
              local s=F:IsA("Fire");
              if s then
                D.accents[#D.accents+1]={item=F,color=F.Color,color2=F.SecondaryColor};
              else
                local s=F:IsA("Smoke");
                if s then
                  D.accents[#D.accents+1]={item=F,color=F.Color};
                else
                  local s=F:IsA("Sparkles");
                  if s then
                    D.accents[#D.accents+1]={item=F,color=F.SparkleColor};
                  else
                    local s=F:IsA("Highlight");
                    if s then
                      D.accents[#D.accents+1]={item=F,color=F.FillColor,color2=F.OutlineColor};
                    else
                      local s=F:IsA("Decal")and F.Transparency<1;
                      if s then
                        D.accents[#D.accents+1]={item=F,color=F.Color3};
                      else
                        local s=F:IsA("BasePart")and F.Transparency<1;
                        if s then
                          local s,c=D.accents,D.accents;
                          local O,x=#c+1,{item=F,color=F.Color};
                          x.texture,s[O]=F:IsA("MeshPart")and F.TextureID or nil,x;
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end;
      end;
    end
  end;
  R:Destroy();
  D=k;
end
