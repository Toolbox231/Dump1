-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[7] / function #0
-- offset 147114..148203 (1089 bytes, type=code)

function(s,s,s,s)
  return function(s,s)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    local f=s[9];
    local a=s[10];
    local d=s[11];
    return function(s)
      local P;
      local P=l;
      local l,Z,Z=P.ScreenGui.Parent;
      if l then
        P=L;
        Z=P.Parent;
      else
        Z=l;
      end
      if not Z then
        return;
      end
      local G,G;
      local G,Y,Y=y[4][y[6]]and z[4][z[6]];
      if G then
        P=T;
        Y=not P.Blocked;
      else
        Y=G;
      end
      P=nil;
      if Y then
        G=T;
        P=G.Opacity/100;
      else
        P=Y;
      end
      local e,j=P or 0;
      n[4][n[6]]+=(e-n[4][n[6]])*(1-math.exp(-18*math.max(s,0)));
      Z=math.abs(e-n[4][n[6]])<0.001;
      if Z then
        n[4][n[6]]=e;
      end
      P=L;
      P.Visible=y[4][y[6]]~=nil and n[4][n[6]]>0.001;
      local e;
      l=J[4][J[6]];
      if l then
        J[4][J[6]].ImageTransparency=1-math.clamp(n[4][n[6]],0,1);
      end
      G,P=not y[4][y[6]];
      if G then
        P=G;
      else
        Z=L;
        P=not Z.Visible;
      end
      if P then
        return;
      end
      local l;
      Y=H;
      Y();
      Y=not z[4][z[6]]or y[4][y[6]].frames<=1;
      if Y then
        return;
      end
      local l,l,L=T,y[4][y[6]].fps*T.Speed/100;
      f[4][f[6]]+=s;
      Y=math.floor(f[4][f[6]]*l);
      if Y<1 then
        return;
      end
      f[4][f[6]]-=Y/l;
      local l;
      a[4][a[6]]=(a[4][a[6]]+Y)%y[4][y[6]].frames;
      local l;
      s=d;
      s();
    end;
  end;
end
