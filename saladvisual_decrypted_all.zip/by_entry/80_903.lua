-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #903
-- offset 3570804..3571237 (433 bytes, type=code)

local function r(K,o)
  K=s[87]();
  if K[l[40]](o)~=l[409]or o==l[1746] then
    return l[1329];
  end
  local c,m=K[l[409]][l[56]](o,l[85]);
  c=c or o;
  for o,o in K[l[1471]](C[l[1206]])do
    if K[l[1130]](o[l[572]])==c then
      if m then
        for c,c in K[l[1471]](o[l[245]]or{})do
          if K[l[1130]](c[l[572]])==m then
            K[l[1146]](function()
              c[l[199]]();
            end);
            b(o);
            return l[383];
          end
        end;
      end
      K[l[1146]](function()
        o[l[199]]();
      end);
      return l[383];
    end
  end;
  return l[1329];
end
