local __fn_0 = function(s,l,L,y)
  local z,T,n,J,H,f,a,d=s[29],s[108],s[23],6,l,y,L;
  while true do
    if J<=3 then
      if J<=1 then
        if J<=0 then
          z(H,1);
          J=3;
        else
          z(H,0);
          J=3;
        end
      elseif J<=2 then
        y=f[a];
        if y then
          J,f,a,d=7,z,"LPH:",y;
        else
          J,f,a=5,z,"LPH:";
        end
      else
        return;
      end
    elseif J<=5 then
      if J<=4 then
        J=T(H,"[:]([%d]+)[\10\13:][^%w%W]*")and 2 or 1;
      else
        J,d=7,"?";
      end
    elseif J<=6 then
      J=n(H)=="string"and 4 or 0;
    else
      f(a..d..": "..H,0);
      J=3;
    end
  end;
end;