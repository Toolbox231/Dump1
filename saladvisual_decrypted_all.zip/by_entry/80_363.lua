-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #363
-- offset 3400793..3401075 (282 bytes, type=code)

function()
  local nC,JC,HC=s[87](),MP;
  if JC then
    local JC=MP;
    local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
    if fC then
      HC=fC;
    else
      JC=MP;
      HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
    end
  else
    HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
  end
  if not HC then
    iP();
  end
end
