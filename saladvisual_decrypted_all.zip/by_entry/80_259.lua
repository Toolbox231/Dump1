-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #259
-- offset 3372013..3372328 (315 bytes, type=code)

local function UP(aC)
  local dC=s[87]();
  aC=dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
  aC=if iP>l[393]then XP[l[457]]+dC[l[35]][l[499]]((aC-XP[l[457]])/iP+l[659])*iP else aC;
  aC=if EP>l[393]then dC[l[1382]](dC[l[409]][l[846]](l[1213]..EP..l[347],aC))or aC else aC;
  return dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
end
