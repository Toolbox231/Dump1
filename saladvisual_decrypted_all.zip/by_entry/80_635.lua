-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #635
-- offset 3500158..3500379 (221 bytes, type=code)

local function p(r,B)
  r=s[87]();
  if r[l[40]](B)~=l[1712] then
    return function()
    end;
  end
  r[l[1346]][l[968]](NP,B);
  return function()
    local r=s[87]();
    local A=r[l[1346]][l[23]](NP,B);
    if A then
      r[l[1346]][l[1357]](NP,A);
    end
  end;
end
