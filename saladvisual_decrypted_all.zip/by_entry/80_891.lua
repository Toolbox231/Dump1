-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #891
-- offset 3569018..3569603 (585 bytes, type=code)

local function Y(N)
  local q=s[87]();
  if q[l[1703]](N)~=l[1089] then
    return l[393];
  end
  local b=l[393];
  for D,p in q[l[1471]](N:GetDescendants())do
    if p:IsA(l[211])and p:GetAttribute(l[226]) then
      D=p:FindFirstChildWhichIsA(l[211]);
      if D and D[l[1347]]==q[l[128]][l[1347]][l[636]] then
        local N=D[l[160]][l[636]];
        if N>l[59]and p[l[160]][l[636]]<N-l[59] then
          p[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
          local D=p[l[382]];
          if D and D:IsA(l[211])and D[l[160]][l[636]]<N-l[59] then
            D[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
          end
          b+=l[229];
        else
        end
      else
      end
    else
    end
  end;
  return b;
end
