-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #7
-- offset 228926..229131 (205 bytes, type=code)

local function O(V)
  if _>=0.9999 then
    return V;
  end
  local X=math.acos(math.clamp(q:Dot(V),-1,1));
  if X<1.0E-5 then
    return q;
  end
  local x=math.sin(X);
  return(q*(math.sin((1-_)*X)/x)+V*(math.sin(_*X)/x)).Unit;
end
