-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #106
-- offset 136006..136212 (206 bytes, type=code)

function()
  local h=Y(o.g);
  local o,W=h and h[r];
  h=o and y[4][y[6]]and m[r]==A and J[r]==S and O==c;
  if h then
    p(r,o,c,S,nil,nil,function()
      local o=m[r]==A and O==c and J[r]==S and not l[r];
      return o;
    end);
  end
end
