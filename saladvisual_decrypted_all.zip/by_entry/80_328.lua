-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #328
-- offset 3390723..3391125 (402 bytes, type=code)

local function gP()
  local uP=S;
  if uP>l[393] then
    EP();
    return;
  end
  if not LP[l[1600]]or not KP[l[1324]]or not wP[l[1324]] then
    xP:setopen(l[1329]);
    return;
  end
  local UP,MP,sC,lC,LC,yC=VP[l[81]],VP[l[160]],_P[l[81]],_P[l[160]],wP[l[81]],wP[l[160]];
  uP=LC[l[636]]+yC[l[636]]*l[659];
  if uP<UP[l[636]]or uP>UP[l[636]]+MP[l[636]]or uP<sC[l[636]]or uP>sC[l[636]]+lC[l[636]] then
    xP:setopen(l[1329]);
    return;
  end
  EP();
end
