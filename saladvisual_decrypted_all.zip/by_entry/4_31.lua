-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #31
-- offset 3253524..3253765 (241 bytes, type=code)

local function J()
  local a={};
  for d in pairs(e)do
    if d.Name=="GunDrop"and d.Parent and not o(d) then
      local C=K(d);
      if C then
        local K,o=#a+1,{object=d,part=C};
        o.adorn,a[K]=(d:IsA("BasePart")or d:IsA("Model"))and d or C,o;
      end
    end
  end;
  return a;
end
