-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #822
-- offset 3555731..3555949 (218 bytes, type=code)

local function z(f)
  return{[l[772]]=function(f,a,d,P)
    local G=s[87]();
    J:notify({[l[1434]]=G[l[1130]](a or l[1746]),[l[13]]=T[l[810]](f or l[1177]),[l[440]]=d or l[786],[l[73]]=G[l[1703]](P)==l[360]and P or nil});
  end};
end
