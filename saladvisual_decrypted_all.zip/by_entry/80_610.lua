-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #610
-- offset 3494484..3494729 (245 bytes, type=code)

function()
  local IP=s[87]();
  RP[l[702]]=IP[l[128]][l[1034]][l[31]];
  RP[l[873]]=IP[l[128]][l[1227]][l[1005]];
  RP[l[287]]=l[393];
  RP[l[736]]=l[393];
  RP[l[1233]]=l[1329];
  RP[l[47]]=l[1329];
  RP[l[1008]]=l[1329];
  RP[l[1374]]=l[1329];
  RP[l[540]]=RP[l[1698]];
end
