-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #744
-- offset 3528492..3529394 (902 bytes, type=code)

function(z)
  local n=s[87]();
  if z[l[1317]]~=n[l[128]][l[1317]][l[1356]]and z[l[1317]]~=n[l[128]][l[1317]][l[239]] then
    return;
  end
  local J=JP;
  if J then
    return;
  end
  JP=l[383];
  O(l[229]);
  local B,A=y[9]:GetMouseLocation(),e(o);
  local w,F,h=A[l[1437]],A[l[636]],(n[l[964]][l[227]]and n[l[964]][l[227]][l[952]]or n[l[1689]][l[772]](l[1248],l[1704]))/y[29];
  P(yP,H,{[l[2]]=l[393],[l[936]]=C[l[1095]]});
  while true do
    J=JP and(y[9]:IsMouseButtonPressed(n[l[128]][l[1317]][l[1356]])or z[l[1101]]~=n[l[128]][l[1101]][l[912]]);
    if not J then
      break;
    end
    A=(y[9]:GetMouseLocation()-B)/y[29];
    o[l[1639]]=n[l[1459]][l[588]](n[l[35]][l[819]](w+A[l[1437]],Y[l[457]][l[1437]],n[l[35]][l[850]](Y[l[457]][l[1437]],h[l[1437]]-l[829])),n[l[35]][l[819]](F+A[l[636]],Y[l[457]][l[636]],n[l[35]][l[850]](Y[l[457]][l[636]],h[l[636]]-l[829])));
    n[l[1022]][l[153]]();
  end;
  JP=l[1329];
  O(l[715]);
  P(yP,H,{[l[2]]=l[323],[l[936]]=C[l[1379]]});
  i();
end
