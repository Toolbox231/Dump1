-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #114
-- offset 3296219..3296827 (608 bytes, type=code)

function()
  local dP,PP=s[87](),l[393];
  if dP[l[40]](g[l[131]])==l[1346] then
    local ZP={};
    for GP,YP in y[3],g[l[131]],nil do
      local eP=r(YP);
      if eP then
        ZP[GP]=eP;
      end
    end;
    if not HP() then
      return;
    end
    t:retheme(ZP);
    dP[l[1022]][l[153]]();
  end
  if dP[l[40]](g[l[516]])==l[1346] then
    for g,g in y[3],t[l[752]],nil do
      if not HP() then
        return;
      end
      local ZP,GP=t[l[1294]][g],nP[g];
      if ZP and GP~=nil then
        if not(t[l[1207]]and t[l[1207]][g]) then
          local nP,YP=dP[l[1146]](ZP[l[1255]],GP);
          if not nP then
            zP[#zP+l[229]]=g..l[1221]..dP[l[1130]](YP);
          end
        end
      end
      PP+=l[229];
      if PP%l[1158]==l[393] then
        dP[l[1022]][l[153]]();
      end
    end;
  end
end
