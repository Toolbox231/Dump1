-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #568
-- offset 3479962..3480358 (396 bytes, type=code)

local function IP()
  local PC,ZC=s[87](),e(A)[l[1437]]-vP*l[59];
  if ZC<l[1707] then
    return l[1329];
  end
  local GC=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC+kP)/(xP+kP)),l[229]);
  local xP=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC-kP*(GC-l[229]))/GC),l[1249]);
  ZC=GC==iP and xP==EP;
  if ZC then
    return l[1329];
  end
  iP,EP=GC,xP;
  xP=EP;
  QP=xP+l[558];
  tP=QP+kP;
  for xP=l[229],#WP,l[229]do
    V(WP[xP]);
  end;
  return l[383];
end
