-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #110
-- offset 3293510..3293979 (469 bytes, type=code)

local function Q(t)
  local g,u=s[87](),t[l[518]];
  if g[l[40]](u)~=l[1346] then
    local zP,TP=t:clipboardImport();
    if not zP then
      return l[1329],TP;
    end
    u=t[l[518]];
  else
  end
  local zP,TP=g[l[1146]](t[l[1328]],t,u);
  t[l[1583]],t[l[518]]=nil,nil;
  if not zP then
    local u,zP=l[171],{[l[502]]=l[1329]};
    zP[l[1290]],t[u]={g[l[1130]](TP)},zP;
    return l[1329],g[l[1130]](TP);
  end
  if TP~=l[383] then
    g=t[l[171]]and t[l[171]][l[1290]];
    return l[1329],g and g[l[229]]or l[217];
  end
  return l[383];
end
