-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #29
-- offset 3606136..3606352 (216 bytes, type=code)

local function x(v)
  local I=h();
  local i=I.right and I.edge-10 or I.edge+10;
  i=if v then I.right and I.edge-22 or I.edge+22 else i;
  p.AnchorPoint=Vector2.new(I.right and 0 or 1,0.5);
  return UDim2.fromOffset(i,I.mid),I;
end
