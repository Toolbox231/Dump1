-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #397
-- offset 3411460..3411765 (305 bytes, type=code)

local function WP(XP,vP,QP)
  XP=s[87]();
  if XP[l[40]](vP)~=l[409]or vP==tP[l[955]]and not y[18][l[921]] then
    return;
  end
  if not XP[l[1346]][l[23]](BP[l[1206]],vP) then
    return;
  end
  tP[l[955]]=vP;
  xP[l[1420]]=vP;
  for XP,XP in y[3],tP[l[1072]],nil do
    wP(XP);
  end;
  if not QP and BP[l[1617]] then
    I(BP[l[1617]],vP);
  end
end
