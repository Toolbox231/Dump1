-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #114
-- offset 137144..137532 (388 bytes, type=code)

function(j,o,c)
  local S,A=not j;
  if S then
    A=S;
  else
    local w;
    local w=n;
    A=j==w;
  end
  if A then
    return;
  end
  S=f[j];
  if not S then
    S={worn={},busy={},want={}};
    f[j]=S;
  else
  end
  A={};
  for n,j in ipairs(o or{})do
    n=type(j)=="table"and j.id or j;
    if d.ById[n] then
      A[n]=type(j)=="table"and j.group or"aura";
    end
  end;
  for n in pairs(S.busy)do
    if A[n]~=S.want[n] then
      S.busy[n]=nil;
    end
  end;
  S.want=A;
  S.tint=c;
end
