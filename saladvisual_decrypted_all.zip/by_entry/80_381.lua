-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #381
-- offset 3406403..3406726 (323 bytes, type=code)

local function wP(VP,VP,_P)
  local XP,xP=s[87](),VP;
  xP=if XP[l[40]](xP)==l[409]then XP[l[199]](l[59],XP[l[1146]](function()
    local kP=s[87]();
    return kP[l[128]][l[880]--[[readu32]]][VP];
  end))else xP;
  if XP[l[1703]](xP)~=l[802]or xP==iP[l[230]] then
    return;
  end
  iP[l[230]]=xP;
  NP();
  if not _P and BP[l[1617]] then
    I(BP[l[1617]],xP[l[1150]]);
  end
end
