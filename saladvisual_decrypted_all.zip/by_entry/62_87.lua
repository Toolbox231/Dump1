-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #87
-- offset 3242887..3243804 (917 bytes, type=code)

local function s(T,J,a,P,Z)
  local G,q=N[T];
  J=not z[4][z[6]]or not G;
  if J then
    return;
  end
  if typeof(Z)=="Instance"and Z:IsA("GuiObject") then
    local q,K=Z.AbsolutePosition,Z.AbsoluteSize;
    a=q.X+K.X-8;
    P=q.Y+20;
  else
  end
  local q={};
  if G.Id then
    q[#q+1]={icon="copy",name="Copy ID",callback=function()
      pcall(setclipboard,G.Id);
    end};
  end
  if G.User then
    q[#q+1]={icon="trash-2",name="Remove",callback=function()
      d(T);
    end};
  end
  local d,G=pcall(function()
    local K=n;
    local n,S=K.Lib,{name="VisualsModelOptions",title=T,icon="shirt",x=a,y=P,follow=Z,width=194,items=q};
    S.sliders={{name="Size",min=35,max=125,value=math.floor((b.Sizes[T]or 1)*100+0.5),suffix="%",callback=function(a)
      h(T,a/100);
    end},{name="Rotate",min=0,max=360,value=b.Rotations[T]or 0,suffix="\194\176",callback=function(a)
      c(T,a);
    end}};
    n:popup(S);
  end);
  J=not d;
  if J then
    local T;
    d=e;
    d("model options: "..tostring(G));
    warn("[visuals] model options: "..tostring(G));
  end
end
