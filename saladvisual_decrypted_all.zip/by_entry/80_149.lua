-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #149
-- offset 3312952..3313282 (330 bytes, type=code)

local function aP()
  local dP=s[87]();
  dP[l[1346]][l[933]](ZP,function(YP,jP)
    local CP,NP=PP[YP],PP[jP];
    if not CP or not NP then
      return l[1329];
    end
    if CP[l[1100]]~=NP[l[1100]] then
      return CP[l[1100]]<NP[l[1100]];
    end
    return CP[l[572]]<NP[l[572]];
  end);
  for YP=l[229],#ZP,l[229]do
    dP=PP[ZP[YP]];
    if dP then
      dP[l[266]][l[537]]=YP;
    end
  end;
end
