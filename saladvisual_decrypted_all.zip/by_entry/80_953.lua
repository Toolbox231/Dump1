-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #953
-- offset 3582449..3582702 (253 bytes, type=code)

function(d)
  local G=s[87]();
  if a then
    a(d);
  end
  if d then
    N(p[l[178]]);
  end
  local a=d and J and not H;
  if not a then
    return;
  end
  H=l[383];
  G[l[1022]][l[1061]](function()
    local a=s[87]();
    H=l[1329];
    q=l[383];
    a[l[1146]](function()
      J:select();
    end);
    q=l[1329];
  end);
end
