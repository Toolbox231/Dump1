-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[6306] / function #0
-- offset 46380..47419 (1039 bytes, type=code)

function(s,l,l,l,l,l,L,y,y,z,z,T,n,n,n,n)
  local n,J,H,f,a,d,P=s[104],s[41],s[88],s[78],s[70],s[102],s.CS;
  return function(Z,Z)
    local Z,G,Y,e,j,C,N=n,J,H,f,a,d,P;
    return function(...)
      local n=Z;
      local J,H,f,a=n(y),z;
      local y,z,d=Y,e,j;
      local P,Z,Y,e,j=G(function(...)
        while true do
          local G=l[H];
          if f then
            for l in y,f,nil do
              if f then
                local G=f[l];
                if G then
                  G[4]=G;
                  G[5]=J[l];
                  G[6]=5;
                  f[l]=nil;
                end
              end
            end;
          end
          if a then
            for l,G in y,a,nil do
              local q=G[5];
              if a then
                G=a[l];
                if G then
                  local b,D=l+q-1,n(q);
                  z(J,l,b,1,D);
                  G[4]=D;
                  G[6]=1;
                  a[l]=nil;
                end
              end
            end;
          end
          return false,true,d(T[H]);
        end;
      end,...);
      if P then
        if Z then
          if Y then
            return J[e](C(j,1,j.n));
          else
            return J[e](C(J,e+1,j));
          end
        elseif e then
          if Y then
            return C(e,1,e.n);
          else
            return C(J,e,j);
          end
        end
      else
        local l,T,d=f,a,J;
        if l then
          for J in y,l,nil do
            if l then
              local f=l[J];
              if f then
                f[4]=f;
                f[5]=d[J];
                f[6]=5;
                l[J]=nil;
              end
            end
          end;
        end
        if T then
          for J,f in y,T,nil do
            l=f[5];
            if T then
              f=T[J];
              if f then
                local y,a=J+l,n(l);
                z(d,J,y-1,1,a);
                f[4]=a;
                f[6]=1;
                T[J]=nil;
              end
            end
          end;
        end
        N(s,Z,H,L);
      end
    end;
  end;
end
