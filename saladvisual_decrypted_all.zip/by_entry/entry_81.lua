local __fn_0 = function(s,s,s)
  return function(s,s,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    return function()
      local s;
      local s=l;
      if not s.On then
        return;
      end
      local l,T=pairs;
      s=L;
      for L,T in l(s)do
        local s=L.Parent;
        if s then
          local s;
          local s=y;
          pcall(s,L,T);
        else
          local s;
          local s=z;
          s(L);
        end
      end;
    end;
  end;
end;
local __fn_1 = function(s,s,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  local z=s[4];
  return function()
    local s;
    local s=l;
    if not s.On then
      return;
    end
    local l,T=pairs;
    s=L;
    for L,T in l(s)do
      local s=L.Parent;
      if s then
        local s;
        local s=y;
        pcall(s,L,T);
      else
        local s;
        local s=z;
        s(L);
      end
    end;
  end;
end;