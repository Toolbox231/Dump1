-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #224
-- offset 3350461..3350667 (206 bytes, type=code)

local function BP()
  local AP=s[87]();
  if OP[l[259]]and OP[l[700]] then
    local FP,hP=AP[l[1146]](function()
      OP[l[700]]();
      cP(l[383],l[383]);
    end);
    if not FP then
      pP();
      AP[l[972]](l[1752]..AP[l[1130]](hP));
    end
  end
end
