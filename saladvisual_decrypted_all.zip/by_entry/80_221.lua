-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #221
-- offset 3349503..3350126 (623 bytes, type=code)

local function cP(FP,hP)
  local WP=s[87]();
  local VP,_P,XP=WP[l[360]][l[149]](OP[l[434]],OP[l[900]],OP[l[999]]),WP[l[1459]][l[1368]](OP[l[900]],l[229]-OP[l[999]]),WP[l[1459]][l[772]](OP[l[434]],l[393],l[659],l[393]);
  if hP then
    AP[l[948]]=_P;
    BP[l[948]]=XP;
    AP[l[1535]]=VP;
    mP[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229]);
    if KP[l[275]] then
      KP[l[275]][l[1535]]=VP;
    end
  else
    P(AP,n,{[l[948]]=_P,[l[1535]]=VP});
    P(BP,n,{[l[948]]=XP});
    P(mP,n,{[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229])});
    if KP[l[275]] then
      P(KP[l[275]],n,{[l[1535]]=VP});
    end
  end
  if not SP:IsFocused() then
    SP[l[1420]]=p(VP);
  end
  KP[l[1328]](VP,FP);
end
