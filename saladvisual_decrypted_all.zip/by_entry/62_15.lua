-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #15
-- offset 3228510..3228768 (258 bytes, type=code)

local function yP(zP)
  table.clear(v);
  local TP=zP and(zP:FindFirstChildOfClass("Humanoid"));
  if not TP then
    return;
  end
  local zP,nP=pcall(TP.GetAppliedDescription,TP);
  if zP and nP then
    for zP in string.gmatch(nP.HairAccessory or"","%d+")do
      v[zP]=true;
    end;
  end
end
