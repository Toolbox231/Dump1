-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #606
-- offset 3493395..3493610 (215 bytes, type=code)

local function XP(xP)
  local kP=s[87]();
  for vP=#NP,l[229],l[715]do
    local IP=NP[vP];
    if kP[l[40]](IP)~=l[1712] then
      kP[l[1346]][l[1357]](NP,vP);
    elseif not kP[l[1146]](IP,GP,xP) then
      kP[l[1346]][l[1357]](NP,vP);
    end
  end;
end
