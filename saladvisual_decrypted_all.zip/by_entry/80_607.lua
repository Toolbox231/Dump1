-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #607
-- offset 3493611..3493813 (202 bytes, type=code)

local function xP()
  local kP,vP=s[87](),OP;
  if vP then
    OP:Disconnect();
    OP=nil;
  end
  if GP[l[1160]] then
    GP[l[1160]]:Destroy();
    GP[l[1160]]=nil;
  end
  kP[l[1346]][l[267]](GP[l[934]]);
  GP[l[593]]=nil;
  oP=l[1329];
end
