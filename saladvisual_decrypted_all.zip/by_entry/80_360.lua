-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #360
-- offset 3400083..3400305 (222 bytes, type=code)

local function tP(yC)
  local TC,nC,JC=s[87](),iP[l[81]],iP[l[160]];
  if JC[l[1437]]<=l[393] then
    return gP[l[1019]];
  end
  return wP[l[457]]+(wP[l[850]]-wP[l[457]])*TC[l[35]][l[819]]((yC-nC[l[1437]])/JC[l[1437]],l[393],l[229]);
end
