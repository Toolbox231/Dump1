-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #573
-- offset 3483037..3483407 (370 bytes, type=code)

local function wP(XP)
  local xP=s[87]();
  xP[l[1346]][l[267]](F);
  local vP={};
  if xP[l[40]](XP)==l[1346] then
    for IP,iP in y[3],XP,nil do
      IP=TC(iP);
      if IP and not vP[IP[l[572]]] then
        vP[IP[l[572]]]=l[383];
        F[#F+l[229]]=IP;
      end
    end;
  end
  XP=p[l[1693]];
  if XP then
    for XP in y[3],hP,nil do
      if not vP[XP] then
        hP[XP]=nil;
      end
    end;
  else
    xP=fP and not vP[fP];
    if xP then
      fP=nil;
    end
  end
  V();
end
