-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #254
-- offset 3362418..3362746 (328 bytes, type=code)

local function BP()
  local wP=s[87]();
  for FP,hP in y[3],SP,nil do
    for SP,SP in y[3],hP[l[305]],nil do
      if SP[l[1273]] then
        FP=C[SP[l[1501]]];
        if FP then
          FP:Disconnect();
          C[SP[l[1501]]]=nil;
        end
        SP[l[675]][l[948]]=wP[l[1459]][l[772]]();
        SP[l[1501]][l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],e(SP[l[675]])[l[636]]);
      end
    end;
  end;
end
