-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #435
-- offset 3427389..3427822 (433 bytes, type=code)

local function WP(VP)
  local xP=s[87]();
  if y[18][l[1333]]or VP[l[1317]]~=xP[l[128]][l[1317]][l[1441]] then
    return;
  end
  local EP=VP[l[880]--[[readu32]]];
  VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1492]];
  if VP then
    uP(l[229]);
  else
    local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1436]];
    if VP then
      uP(l[715]);
    else
      local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1183]]or EP==xP[l[128]][l[880]--[[readu32]]][l[839]];
      if VP then
        _P(yC[l[1072]][TC]);
      elseif EP==xP[l[128]][l[880]--[[readu32]]][l[1739]] then
        PC();
      end
    end
  end
end
