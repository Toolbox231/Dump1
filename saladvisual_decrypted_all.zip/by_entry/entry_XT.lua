local __fn_0 = function(s,l,L,y,z,T,n,J,H,f)
  if n<=32 then
    local n,a=J[4],s[54](s[18](s.VS,5),s.IS,s.gS);
    local d,P,Z=s[12](a),#a-1,5+0;
    a=0-Z;
    return 20,{Z,P+0,nil,n,a},0,{},d,H,T;
  else
    local s=16384*(T-128);
    local T=y-128+(s+l*128);
    return 36,J,z,f,L,H+3,T;
  end
end;