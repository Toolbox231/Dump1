-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #466
-- offset 3444125..3444392 (267 bytes, type=code)

local function BP()
  local wP=s[87]();
  P(vP,H,{[l[747]]=(lC[l[404]]or TC)and l[393]or l[986]});
  P(xP,H,{[l[916]]=(lC[l[404]]or TC)and l[1209]or l[615]});
  P(kP,H,{[l[1639]]=wP[l[1459]][l[588]]((lC[l[404]]or TC)and l[688]or l[658],(lC[l[404]]or TC)and l[114]or l[829])});
end
