-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #85
-- offset 3242677..3242884 (207 bytes, type=code)

function()
  b.On=false;
  b.Pick=nil;
  local s=n;
  local T=s.Lib;
  local s,J=T.quiet,T.configApplying;
  T.quiet=true;
  T.configApplying=true;
  pcall(function()
    if w then
      w:set("");
    end
  end);
  T.quiet=s;
  T.configApplying=J;
  P();
end
