-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #24
-- offset 11920..12157 (237 bytes, type=code)

local function T(n,G,j)
  local m=os.clock();
  if n.lastCircleAt and m-n.lastCircleAt<=0.22 and n.lastCirclePosition and(G-n.lastCirclePosition).Magnitude<=5 then
    return false;
  end
  n.lastCircleAt=m;
  n.lastCirclePosition=G;
  c(G,j);
  return true;
end
