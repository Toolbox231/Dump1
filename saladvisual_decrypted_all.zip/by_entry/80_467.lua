-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #467
-- offset 3444393..3444974 (581 bytes, type=code)

local function wP(FP,xP)
  local vP=s[87]();
  local RP,gP,nC=vP[l[360]][l[149]](zC[l[434]],zC[l[900]],zC[l[999]]),vP[l[1459]][l[1368]](zC[l[900]],l[229]-zC[l[999]]),vP[l[1459]][l[772]](zC[l[434]],l[393],l[659],l[393]);
  if xP then
    uP[l[948]]=gP;
    UP[l[948]]=nC;
    uP[l[1535]]=RP;
    tP[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229]);
    kP[l[1535]]=RP;
  else
    P(uP,n,{[l[948]]=gP,[l[1535]]=RP});
    P(UP,n,{[l[948]]=nC});
    P(tP,n,{[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229])});
    P(kP,n,{[l[1535]]=RP});
  end
  if not MP:IsFocused() then
    MP[l[1420]]=p(RP);
  end
  lC[l[1409]]=RP;
  if FP then
    fC(RP);
  end
end
