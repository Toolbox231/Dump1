-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #4
-- offset 3246640..3246870 (230 bytes, type=code)

local function K(o)
  if o:IsA("BasePart") then
    return o;
  end
  if o:IsA("Model") then
    return o.PrimaryPart or o:FindFirstChildWhichIsA("BasePart",true);
  end
  return o:FindFirstChild("Handle")or o:FindFirstChildWhichIsA("BasePart",true);
end
