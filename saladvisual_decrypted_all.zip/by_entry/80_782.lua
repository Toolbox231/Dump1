-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #782
-- offset 3549233..3549500 (267 bytes, type=code)

local function f()
  P(v,H,{[l[1646]]=_ and l[393]or l[841]});
  P(h,H,{[l[747]]=_ and l[330]or l[1373]});
  P(V,H,{[l[1646]]=_ and l[804]or l[229]});
  local a,h,k={},l[916],_ and l[393]or(X and l[1296]or l[986]);
  a[h]=k;
  a[l[510]]=(_ or X)and c[l[1095]]or c[l[1379]];
  P(D,H,a);
end
