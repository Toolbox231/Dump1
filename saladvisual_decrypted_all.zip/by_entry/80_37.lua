-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #37
-- offset 3272044..3272246 (202 bytes, type=code)

local function p(r)
  local K=s[87]();
  return K[l[409]][l[846]](l[145],K[l[35]][l[499]](r[l[126]]*l[1682]+l[659]),K[l[35]][l[499]](r[l[1192]]*l[1682]+l[659]),K[l[35]][l[499]](r[l[1378]]*l[1682]+l[659]));
end
