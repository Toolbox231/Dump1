# Таблица опкодов внутреннего интерпретатора (девиртуализация)

Извлечено из дерева диспетчера (`if M<103 then …`) среза `3128823..3202193`
артефакта; скрипты: `tools/devirt_ops.py` (разбор дерева) + `tools/devirt_names.py`
(имена и семантика). Имена — вывод из кода обработчиков; сомнительные помечены «?»
в колонке «примечание».

| опкод | имя | код обработчика | примечание |
|---|---|---|---|
| 0 | `RETURN` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрывает апвалюи (j/q) и возвращает c[P[O]] |
| 1 | `JMPIF_NOTLT` | `O=if not(P[O]<c[T[O]])then a[O]else O` | O = (P[O] < c[T[O]]) and O or a[O] — условный переход |
| 2 | `DECODE_RUN` | `Z,C=T[O],a[O]+1;for Q=1,P[O],1 do Z=h(W(Z,(k(Z,13))),536870911);Z=W(Z,(F(Z,13)));Z=h(W(Z,(k(Z,14))),536870911);T[C]=W(T[C],(h(F(Z,0),127)));P[C]=W(…` | расшифровывает пачку инструкций (T/P/a/z) и переписывает z[O]=118 |
| 3 | `CONCAT_K` | `c[T[O]]=f[O]..c[a[O]]` | c[T] = f[O] .. c[a[O]] |
| 4 | `CALL_1_NORES` | `c[T[O]](c[a[O]])` | c[T](c[a]) |
| 5 | `MUL` | `c[T[O]]=c[a[O]]*c[P[O]]` | c[T]=c[a]*c[P] |
| 6 | `DECODE_RUN_B` | `Z,C=(W(P[O],(h(W(p,(h(F(p,29),7))),536870911)))),T[O]+1;for Q=1,a[O],1 do Z=h(W(Z,(k(Z,13))),536870911);Z=W(Z,(F(Z,13)));Z=h(W(Z,(k(Z,14))),5368709…` | хеш-декодер пачки инструкций (вариант B) |
| 7 | `DIV_K` | `c[P[O]]=c[a[O]]/l[O]` | c[P]=c[a]/l[O] |
| 8 | `GT_IMM` | `c[a[O]]=c[P[O]]>T[O]` | c[a]=c[P]>T[O] |
| 9 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 10 | `BITOP_AND` | `c[a[O]]=h(c[T[O]],c[P[O]])` | c[a]=h(c[T],c[P]) — побитовая операция |
| 11 | `LE` | `c[a[O]]=c[T[O]]<=c[P[O]]` | c[a]=c[T]<=c[P] |
| 12 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 13 | `NE_IMM` | `c[T[O]]=y[O]~=c[P[O]]` | c[T]=y[O]~=c[P] |
| 14 | `SETUPVAL_T` | `C=A[T[O]];C[4][C[6]][c[P[O]]]=c[a[O]]` | запись в апвалюй: A[T][4][6][c[P]]=c[a] |
| 15 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 16 | `CLOSE_LOCALS` | `local Q=P[O];if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end` | закрытие апвалюев при выходе из блока |
| 17 | `DIV` | `c[P[O]]=c[a[O]]/c[T[O]]` | c[P]=c[a]/c[T] |
| 18 | `GT` | `c[a[O]]=c[T[O]]>c[P[O]]` | c[a]=c[T]>c[P] |
| 19 | `TOINT` | `local Q,lP,LP=P[O],c[T[O]];repeat local yP=lP%4294967296;if yP~=yP then LP=0;break;end;LP=yP-yP%1;until true;c[Q]=LP` | приведение числа к целому (маска 2^32) |
| 20 | `SUB` | `c[a[O]]=c[T[O]]-c[P[O]]` | c[a]=c[T]-c[P] |
| 21 | `LOAD_K` | `c[a[O]]=K` | c[a]=K (специальный регистр) |
| 22 | `DECODE_RUN_C` | `Z,C=(W(P[O],(h(W(K,(h(F(K,29),7))),536870911)))),T[O]+1;for Q=1,a[O],1 do Z=h(W(Z,(k(Z,13))),536870911);Z=W(Z,(F(Z,13)));Z=h(W(Z,(k(Z,14))),5368709…` | хеш-декодер пачки инструкций (вариант C, через K) |
| 23 | `LT_IMM` | `c[T[O]]=c[a[O]]<P[O]` | c[T]=c[a]<P[O] |
| 24 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 25 | `CALL_K_1` | `c[P[O]]=E(c[T[O]](y[O]))` | c[P]=E(c[T](y[O])) — вызов с константой, 1 результат |
| 26 | `ADD_K` | `c[T[O]]=c[P[O]]+y[O]` | c[T]=c[P]+y[O] |
| 27 | `FORLOOP` | `J+=e;C=if e<=0 then J>=G else J<=G;if C then c[a[O]]=J;O=P[O];else end` | шаг числового for; c[a]=J, O=P[O] |
| 28 | `LT` | `c[T[O]]=c[a[O]]<c[P[O]]` | c[T]=c[a]<c[P] |
| 29 | `SETTABLE_OFF` | `c[P[O]+c[a[O]]]=c[T[O]]` | c[P[O]+c[a]]=c[T] |
| 30 | `BITXOR_K` | `c[P[O]]=W(c[T[O]],y[O])` | c[P]=W(c[T],y[O]) — побитовая операция с константой |
| 31 | `JMPNE_IMM` | `O=if c[P[O]]~=l[O]then a[O]else O` | O = (c[P]~=l[O]) and a[O] or O |
| 32 | `BITOP_BATCH` | `c[a[Q]]=h(c[T[Q]],P[Q])` | пакетная побитовая операция по диапазону (Q = индекс) |
| 33 | `LOOP_BREAK` | `B=a[Q];O=P[Q]+1;break` | выход из пакетной операции (B=a[Q]; O=P[Q]+1; break) |
| 34 | `SETUPVAL_TAB` | `A[P[O]][l[O]]=c[a[O]]` | A[P][l[O]]=c[a] |
| 35 | `SETFIELD_IMM` | `c[a[O]][f[O]]=T[O]` | c[a][f[O]]=T[O] |
| 36 | `ADD_K2` | `c[a[O]]=f[O]+c[T[O]]` | c[a]=f[O]+c[T] |
| 37 | `LE_K` | `c[T[O]]=c[a[O]]<=f[O]` | c[T]=c[a]<=f[O] |
| 38 | `GETUPVAL_FIELD` | `C=A[P[O]];c[T[O]]=C[4][C[6]]` | c[T]=A[P][4][6] — чтение апвалюя |
| 39 | `CALL_K_ARG` | `c[P[O]]=c[a[O]](l[O])` | c[P]=c[a](l[O]) |
| 40 | `HASH_BLOCK_A` | `local Q,lP,LP=a[O],f[O],l[O];local yP,zP=h(lP,4294967295),h(LP,4294967295);local LP,TP,nP,JP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);zP=h(LP*nP+k…` | хеш-блок (смешивание 32-битных полей) |
| 41 | `CONCAT_K2` | `c[P[O]]=c[a[O]]..l[O]` | c[P]=c[a]..l[O] |
| 42 | `SETTABLE_IMM_KEY` | `c[T[O]][a[O]]=c[P[O]]` | c[T][a[O]]=c[P] |
| 43 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 44 | `MUL_K` | `c[T[O]]=a[O]*c[P[O]]` | c[T]=a[O]*c[P] |
| 45 | `MOD_K` | `c[T[O]]=c[P[O]]%y[O]` | c[T]=c[P]%y[O] |
| 46 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 47 | `JMPEQ_IMM` | `O=if c[a[O]]==T[O]then P[O]else O` | O = (c[a]==T[O]) and P[O] or O |
| 48 | `HASH_BLOCK_B` | `local Q,lP,LP=T[O],c[P[O]],a[O];local yP,zP=h(lP,4294967295),h(LP,4294967295);local TP,nP,JP,HP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);lP=h(TP*J…` | хеш-блок (вариант) |
| 49 | `MOVE` | `c[P[O]]=c[a[O]]` | c[P]=c[a] |
| 50 | `LEN` | `c[T[O]]=#c[P[O]]` | c[T]=#c[P] |
| 51 | `GE` | `c[a[O]]=c[P[O]]>=c[T[O]]` | c[a]=c[P]>=c[T] |
| 52 | `SETTABLE_K` | `c[a[O]][c[P[O]]]=l[O]` | c[a][c[P]]=l[O] |
| 53 | `GETUPVAL_IDX` | `C=A[P[O]];c[T[O]]=C[4][C[6]][c[a[O]]]` | c[T]=A[P][4][6][c[a]] |
| 54 | `LE_K2` | `c[P[O]]=c[T[O]]<=a[O]` | c[P]=c[T]<=a[O] |
| 55 | `GETTABLE` | `c[T[O]]=c[P[O]][a[O]]` | c[T]=c[P][a[O]] |
| 56 | `POW` | `c[T[O]]=P[O]^c[a[O]]` | c[T]=P[O]^c[a] |
| 57 | `JMPLE` | `O=if not(c[P[O]]<=c[T[O]])then a[O]else O` | O = (c[P]<=c[T]) and O or a[O] |
| 58 | `UNM` | `c[T[O]]=-c[a[O]]` | c[T]=-c[a] |
| 59 | `HASH_UPVAL` | `local lP,LP,yP=T[O],W(P[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];local zP=W(yP[lP],187638924);yP[lP]=zP;lP,yP=n[5],zP+1;zP=V(lP,yP);local TP,nP;…` | хеш-получение через апвалюй (декодер константы) |
| 60 | `LOAD_TRIPLE` | `c[a[O]]=n;c[a[O+1]]=a;c[P[O+2]]=z;O+=2` | c[a]=n; c[a+1]=a; c[P+2]=z; O+=2 — загрузка внутренних таблиц VM |
| 61 | `FORPREP` | `local lP,LP,yP=a[O],c[T[O]],c[P[O]];local zP,TP=h(LP,4294967295),h(yP,4294967295);local LP,yP,nP,JP=h(zP,65535),F(zP,16),h(TP,65535),F(TP,16);zP=h(…` | подготовка числового for |
| 62 | `EQ` | `c[a[O]]=c[P[O]]==c[T[O]]` | c[a]=c[P]==c[T] |
| 63 | `BITSHIFT_A` | `c[P[O]]=v(c[a[O]],c[T[O]])` | c[P]=v(c[a],c[T]) — сдвиг |
| 64 | `SETFIELD_K` | `c[P[O]][l[O]]=y[O]` | c[P][l[O]]=y[O] |
| 65 | `CALL_K_CONST` | `c[P[O]](c[T[O]],y[O])` | c[P](c[T],y[O]) |
| 66 | `JMPIF` | `O=if c[a[O]]then T[O]else P[O]` | O = c[a] and T[O] or P[O] |
| 67 | `LOAD_S` | `c[T[O]]=s` | c[T]=s (служебная таблица) |
| 68 | `VARARG_MOVE` | `C,Z,r=T[O],P[O],a[O];N=C+Z;S=c[N];m=S.n;Y=Z+m-1;S.n=Y;I(S,1,m,Z,S);I(c,C+1,N-1,1,S);c[C]=E(c[C](i(S,1,S.n)))` | перепаковка регистров (vararg/аргументы) |
| 69 | `JMPLT_IMM` | `O=if T[O]<c[P[O]]then a[O]else O` | O = (T[O]<c[P]) and a[O] or O |
| 70 | `GETTABLE_REG` | `c[T[O]]=c[P[O]][c[a[O]]]` | c[T]=c[P][c[a]] |
| 71 | `CLEAR_RANGE` | `for lP=T[O],a[O],1 do c[lP]=nil;end` | обнуление диапазона регистров |
| 72 | `VARARG_SHIFT` | `C,Z,r=a[O],T[O],P[O];N=c[C];I(c,C+1,C+Z,r+1,N)` | сдвиг регистров/vararg |
| 73 | `CALL_SPREAD` | `c[a[O]](l[O],i(c[P[O]],1,c[P[O]].n))` | c[a](l[O], распакованный c[P]) |
| 74 | `BITOP_AND_K` | `c[T[O]]=W(y[O],c[P[O]])` | c[T]=W(y[O],c[P]) |
| 75 | `SETTABLE_IMM_VAL` | `c[T[O]][c[a[O]]]=P[O]` | c[T][c[a]]=P[O] |
| 76 | `SETUPVAL_RAW` | `C=A[a[O]];C[4][C[6]]=l[O]` | A[a][4][6]=l[O] |
| 77 | `CALL_MULTI` | `C=a[O];local Q,lP,LP=J();if Q then c[C+1]=lP;c[C+2]=LP;O=P[O];else end;Z,r,N=Q,lP,LP` | вызов с несколькими результатами (pcall-подобный) |
| 78 | `GT_K` | `c[a[O]]=c[T[O]]>f[O]` | c[a]=c[T]>f[O] |
| 79 | `SETUPVAL_TAB2` | `A[T[O]][c[P[O]]]=y[O]` | A[T][c[P]]=y[O] |
| 80 | `SETUPVAL_TAB3` | `A[a[O]][f[O]]=l[O]` | A[a][f[O]]=l[O] |
| 81 | `EQ_IMM` | `c[a[O]]=c[P[O]]==T[O]` | c[a]=c[P]==T[O] |
| 82 | `GETGLOBAL` | `c[T[O]]=u[y[O]]` | c[T]=u[y[O]] — чтение глобала из окружения |
| 83 | `GETTABUP` | `c[P[O]]=A[a[O]][l[O]]` | c[P]=A[a][l[O]] |
| 84 | `JMPIFNOT` | `O=if not c[T[O]]then a[O]else P[O]` | O = (not c[T]) and a[O] or P[O] |
| 85 | `BITSHIFT_B` | `c[a[O]]=v(f[O],c[T[O]])` | c[a]=v(f[O],c[T]) |
| 86 | `MOD` | `c[P[O]]=c[a[O]]%c[T[O]]` | c[P]=c[a]%c[T] |
| 87 | `MUL_K2` | `c[T[O]]=c[a[O]]*f[O]` | c[T]=c[a]*f[O] |
| 88 | `SETFIELD` | `c[T[O]][f[O]]=c[a[O]]` | c[T][f[O]]=c[a] |
| 89 | `LOAD_S2` | `c[a[O]]=s[T[O]]` | c[a]=s[T[O]] |
| 90 | `VARARG_TABLE` | `C,Z,r=a[O],P[O],T[O];N,S=C+r-1,C+Z;m=c[S];Y=m.n;b=Z+Y-1;m.n=b;I(m,1,Y,Z,m);I(c,C+1,S-1,1,m);o=E(c[C](i(m,1,m.n)));I(o,1,r,C,c)` | упаковка/сдвиг таблицы аргументов |
| 91 | `ADD` | `c[T[O]]=c[P[O]]+c[a[O]]` | c[T]=c[P]+c[a] |
| 92 | `CALL_K_2` | `c[a[O]](l[O],f[O])` | c[a](l[O],f[O]) |
| 93 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 94 | `CALL_FRAME` | `sP=D;D,C,Z={[5]=e,[8]=G,[6]=sP,[9]=J},T[O],R(g);Z(s,c[C],c[C+1],c[C+2]);O,J=P[O],Z` | вызов с сохранением кадра (e/G/J/D) — вход в Lua-функцию |
| 95 | `SETTABLE_K2` | `c[a[O]][P[O]]=l[O]` | c[a][P[O]]=l[O] |
| 96 | `SETTABLE` | `c[P[O]][c[a[O]]]=c[T[O]]` | c[P][c[a]]=c[T] |
| 97 | `ADD_IMM` | `c[a[O]]=c[P[O]]+T[O]` | c[a]=c[P]+T[O] |
| 98 | `CALL_VARARG` | `C,Z,r=P[O],{...},a[O];I(Z,1,C-1,r,c);c[r+C-1]=E(Q(C,...))` | вызов с упаковкой vararg |
| 99 | `HASH_UPVAL2` | `local lP,LP,yP=T[O],W(P[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];local zP=W(yP[lP],187638924);yP[lP]=zP;yP,lP=n[5],zP+1;zP=V(yP,lP);local TP,nP;…` | хеш-получение через апвалюй (вариант) |
| 100 | `DIV_K2` | `c[P[O]]=c[T[O]]/a[O]` | c[P]=c[T]/a[O] |
| 101 | `CALL_SHIFT` | `C,Z,r=T[O],a[O],P[O];N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));I(m,1,r,C,c)` | вызов со сдвигом результатов |
| 102 | `CALL_0_NORES` | `c[T[O]]()` | c[T]() |
| 103 | `ADD_IMM2` | `c[a[O]]=f[O]+l[O]` | c[a]=f[O]+l[O] |
| 104 | `CALL_1` | `c[a[O]]=E(c[P[O]](c[T[O]]))` | c[a]=E(c[P](c[T])) |
| 105 | `HASH_UPVAL3` | `C,Z,r,N=P[O],T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O];S=C<2097152 and 7 or 14;m,Y=h(C,k(1,S)-1),F(C,S);T[O]=W(Z,20,(h(r,127)));z[O]=W(Y,86,…` | хеш-получение (вариант с масками <16384/<2097152) |
| 106 | `FORPREP2` | `local Q,sP,lP=T[O],a[O],c[P[O]];local LP,yP=h(sP,4294967295),h(lP,4294967295);local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);sP=h(lP*T…` | подготовка for (вариант) |
| 107 | `MOVE_TRIPLE` | `c[T[O]]=P[O];c[T[O+1]]=P[O+1];c[T[O+2]]=P[O+2];c[T[O+3]]=P[O+3];O+=3` | c[T..T+3]=P[O..O+3]; O+=3 |
| 108 | `BITAND_2` | `c[a[O]]=h(f[O],c[T[O]])` | c[a]=h(f[O],c[T]) |
| 109 | `JMP_REG` | `O=c[a[O]]` | O=c[a] — косвенный переход |
| 110 | `BITXOR_KK` | `c[T[O]]=W(f[O],y[O])` | c[T]=W(f[O],y[O]) — свёртка двух констант |
| 111 | `CALL_SPREAD2` | `c[P[O]](i(c[a[O]],1,c[a[O]].n))` | c[P](распакованный c[a]) |
| 112 | `SPLIT3` | `local Q;local sP=l[O];if sP then local lP=#sP/3;if lP>0 then Q={};local LP,yP=j,q;for zP=1,lP,1 do local lP=(zP-1)*3;local TP,nP=sP[lP+3],sP[lP+2];…` | спец-операция: разбор строки/таблицы по 3 поля |
| 113 | `JMPLE_REG` | `O=if T[O]<=c[a[O]]then P[O]else O` | O = (T[O]<=c[a]) and P[O] or O |
| 114 | `GETTABUP2` | `c[T[O]]=A[P[O]][a[O]]` | c[T]=A[P][a[O]] |
| 115 | `IDIV` | `c[T[O]]=c[P[O]]//a[O]` | c[T]=c[P]//a[O] |
| 116 | `LOAD_K2` | `K=c[a[O]]` | K=c[a] — запись в спец-регистр |
| 117 | `BITSHIFT_C` | `c[P[O]]=W(c[T[O]],a[O])` | c[P]=W(c[T],a[O]) |
| 119 | `NOT` | `c[a[O]]=not c[T[O]]` | c[a]=not c[T] |
| 120 | `CALL_SPREAD3` | `c[a[O]]=E(c[P[O]](i(c[T[O]],1,c[T[O]].n)))` | c[a]=E(c[P](распакованный c[T])) |
| 121 | `CONCAT` | `c[a[O]]=c[T[O]]..c[P[O]]` | c[a]=c[T]..c[P] |
| 122 | `NE` | `c[a[O]]=c[T[O]]~=c[P[O]]` | c[a]=c[T]~=c[P] |
| 123 | `CALL_1_R` | `c[T[O]]=c[P[O]](c[a[O]])` | c[T]=c[P](c[a]) |
| 124 | `LOAD_N` | `c[a[O]]=n` | c[a]=n — загрузка внутреннего значения VM |
| 125 | `SET_S` | `s[y[O]]=f[O]` | s[y[O]]=f[O] |
| 126 | `LOAD_Z` | `c[P[O]]=z` | c[P]=z — загрузка массива опкодов |
| 127 | `SUB_K` | `c[a[O]]=c[P[O]]-l[O]` | c[a]=c[P]-l[O] |
| 128 | `SLICE_VARARG` | `C=c[T[O]];c[P[O]]=E(i(C,a[O],C.n))` | c[P]=E(c[T][a[O]..n]) — срез vararg |
| 129 | `LOAD_REGS` | `c[P[O]]=c` | c[P]=c — загрузка файла регистров |
| 130 | `SETTABUP` | `C=A[P[O]];C[4][C[6]][c[T[O]]]=y[O]` | A[P][4][6][c[T]]=y[O] |
| 131 | `SET_S2` | `s[P[O]]=c[a[O]]` | s[P[O]]=c[a] |
| 132 | `BITSHIFT_D` | `c[P[O]]=v(T[O],c[a[O]])` | c[P]=v(T[O],c[a]) |
| 133 | `FORPREP3` | `local Q,sP,lP=T[O],y[O],c[P[O]];local LP,yP=h(sP,4294967295),h(lP,4294967295);local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);yP=h(lP*T…` | подготовка for (вариант) |
| 134 | `JMPEQ` | `O=if c[T[O]]==c[P[O]]then a[O]else O` | O = (c[T]==c[P]) and a[O] or O |
| 135 | `LT_K` | `c[a[O]]=c[P[O]]<l[O]` | c[a]=c[P]<l[O] |
| 136 | `GETTABLE_K` | `c[T[O]]=c[P[O]][y[O]]` | c[T]=c[P][y[O]] |
| 137 | `JMPLE_IMM2` | `O=if not(c[T[O]]<=a[O])then P[O]else O` | O = (c[T]<=a[O]) and P[O] or O |
| 138 | `GET_S` | `c[T[O]]=s[f[O]]` | c[T]=s[f[O]] |
| 139 | `SETUPVAL_TAB4` | `A[T[O]][y[O]]=P[O]` | A[T][y[O]]=P[O] |
| 140 | `FRAME_RESTORE` | `J,G=D[9],D[8];e,D=D[5],D[6]` | восстановление кадра (J,G,e,D) — возврат из вызова |
| 141 | `PREP_CALL` | `C,Z=a[O],c[P[O]];c[C+1]=Z;c[C]=Z[l[O]]` | c[a+1]=c[P]; c[a]=c[P][l[O]] — метод-вызов |
| 142 | `CALL_SPREAD4` | `C,Z,r=a[O],P[O],T[O];N=C+Z;c[C]=E(c[C](i(c,C+1,N)))` | c[a]=E(c[a](распакованные)) |
| 143 | `NE_K` | `c[P[O]]=c[T[O]]~=a[O]` | c[P]=c[T]~=a[O] |
| 144 | `JMPLT_IMM2` | `O=if c[a[O]]<f[O]then T[O]else O` | O = (c[a]<f[O]) and T[O] or O |
| 145 | `JMPLT_IMM3` | `O=if not(c[P[O]]<T[O])then a[O]else O` | O = (c[P]<T[O]) and a[O] or O |
| 146 | `CLOSE_UPVALS` | `if j then for Q in t,j,nil do if j then local sP=j[Q];if sP then sP[4]=sP;sP[5]=c[Q];sP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,sP in t,q,nil…` | закрытие открытых апвалюев (вариант) |
| 147 | `SETTABUP2` | `A[a[O]][c[T[O]]]=c[P[O]]` | A[a][c[T]]=c[P] |
| 148 | `BITAND_3` | `c[a[O]]=h(T[O],c[P[O]])` | c[a]=h(T[O],c[P]) |
| 149 | `LOAD_A` | `c[a[O]]=a` | c[a]=a — загрузка массива операндов |
| 150 | `VARARG_PACK` | `C,Z={...},a[O];I(C,1,P[O],Z,c)` | упаковка {...} в регистры |
| 151 | `BITSHIFT_E` | `c[T[O]]=k(c[P[O]],a[O])` | c[T]=k(c[P],a[O]) |
| 152 | `MUL_K3` | `c[a[O]]=f[O]*c[T[O]]` | c[a]=f[O]*c[T] |
| 153 | `JMP` | `O=T[O]` | O=T[O] — прямой переход |
| 154 | `JMPNE` | `O=if c[P[O]]~=c[T[O]]then a[O]else O` | O = (c[P]~=c[T]) and a[O] or O |
| 155 | `SET_P` | `p=c[a[O]]` | p=c[a] — запись в спец-регистр p |
| 156 | `EQ_K` | `c[P[O]]=l[O]==c[a[O]]` | c[P]=l[O]==c[a] |
| 157 | `SETTABUP3` | `C=A[a[O]];C[4][C[6]][f[O]]=c[T[O]]` | A[a][4][6][f[O]]=c[T] |
| 158 | `GETTABUP3` | `C=A[a[O]];c[P[O]]=C[4][C[6]][l[O]]` | c[P]=A[a][4][6][l[O]] |
| 159 | `BITSHIFT_F` | `c[a[O]]=F(c[T[O]],P[O])` | c[a]=F(c[T],P[O]) |
| 160 | `GETIMPORT` | `c[T[O]]=u[y[O]][f[O]]` | c[T]=u[y[O]][f[O]] — глобал с полем (u=окружение) [подтверждено: падение nil.new] |
| 161 | `MOD_K2` | `c[T[O]]=c[P[O]]%a[O]` | c[T]=c[P]%a[O] |
| 162 | `CALL_2` | `c[T[O]](c[a[O]],c[P[O]])` | c[T](c[a],c[P]) |
| 163 | `GETUPVAL` | `c[a[O]]=A[P[O]]` | c[a]=A[P] — чтение апвалюя |
| 164 | `JMPLE_IMM3` | `O=if c[a[O]]<=T[O]then P[O]else O` | O = (c[a]<=T[O]) and P[O] or O |
| 165 | `HASH_UPVAL4` | `local Q,sP,lP=a[O],P[O],n[6];local LP=W(lP[Q],187638924);lP[Q]=LP;lP,Q=n[5],LP+1;LP=V(lP,Q);local yP,zP;if LP<128 then yP,zP=LP,Q+1;else local TP=V…` | хеш-получение через апвалюй (вариант) |
| 166 | `EQ_K2` | `c[P[O]]=c[a[O]]==l[O]` | c[P]=c[a]==l[O] |
| 167 | `LOAD_P` | `c[P[O]]=p` | c[P]=p |
| 168 | `LOAD_T` | `c[T[O]]=T` | c[T]=T — загрузка массива T |
| 169 | `GETUPVAL_FIELD2` | `c[a[O]]=A[P[O]][c[T[O]]]` | c[a]=A[P][c[T]] |
| 170 | `SUB_IMM` | `c[a[O]]=T[O]-c[P[O]]` | c[a]=T[O]-c[P] |
| 171 | `JMPLT_REG_ALT` | `if c[a[O]]<c[P[O]]then T[O]else O` | (if c[a]<c[P] then T[O] else O) |
| 172 | `JMPLT_REG` | `if not(c[T[O]]<c[a[O]])then P[O]else O` | (if not (c[T]<c[a]) then P[O] else O) |
| 173 | `HASH_BLOCK_C` | `C,Z,r,N=T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],P[O];S=C<16384 and 7 or(C<2097152 and 14 or 21);m,Y=F(C,S),h(C,k(1,S)-1);z[O]=W(m,18,(h(F(…` | хеш-блок (вариант) |
| 174 | `JMP_INDIRECT` | `O=c[P[O]]` | O=c[P] — косвенный переход |
| 175 | `BITOP_C` | `c[a[O]]=W(c[P[O]],c[T[O]])` | c[a]=W(c[P],c[T]) |
| 176 | `SUB_K2` | `c[P[O]]=c[T[O]]-a[O]` | c[P]=c[T]-a[O] |
| 177 | `BITSHIFT_G` | `c[P[O]]=v(c[a[O]],l[O])` | c[P]=v(c[a],l[O]) |
| 178 | `NE_K2` | `c[P[O]]=c[T[O]]~=y[O]` | c[P]=c[T]~=y[O] |
| 179 | `IDIV_REG` | `c[a[O]]=c[T[O]]//c[P[O]]` | c[a]=c[T]//c[P] |
| 180 | `CLOSE_UPVALS` | `C=a[O];r=C+T[O];if j then for Q in t,j,nil do if j then local sP=j[Q];if sP then sP[4]=sP;sP[5]=c[Q];sP[6]=5;j[Q]=nil;end;end;end;end;if q then for…` | закрытие открытых апвалюев (вариант) |
| 181 | `GET_W` | `c[P[O]]=w(a[O])` | c[P]=w(a[O]) — получение апвалюя/замыкания |
| 182 | `CALL_2_R` | `c[T[O]],c[P[O]]=c[a[O]]()` | c[T],c[P]=c[a]() — вызов, 2 результата |
| 183 | `JMPNE_IMM2` | `O=if c[a[O]]~=P[O]then T[O]else O` | O = (c[a]~=P[O]) and T[O] or O |
| 184 | `GE_K` | `c[T[O]]=c[P[O]]>=a[O]` | c[T]=c[P]>=a[O] |
| 185 | `MUL_K4` | `c[P[O]]=c[a[O]]*T[O]` | c[P]=c[a]*T[O] |
| 186 | `SETTABLE_IMM2` | `c[a[O]][T[O]]=P[O]` | c[a][T[O]]=P[O] |
| 187 | `CALL_K_3` | `c[T[O]](f[O],c[a[O]])` | c[T](f[O],c[a]) |
| 188 | `CALL_SPREAD5` | `c[T[O]](c[a[O]],i(c[P[O]],1,c[P[O]].n))` | c[T](c[a], распакованный c[P]) |
| 189 | `SETTABUP4` | `C=A[a[O]];C[4][C[6]]=c[P[O]]` | A[a][4][6]=c[P] |
| 190 | `TOINT2` | `c[T[O]]=U(c[P[O]])` | c[T]=U(c[P]) — приведение числа |
| 191 | `CALL_1_K` | `c[T[O]](y[O])` | c[T](y[O]) |
| 192 | `TABLE_SHIFT` | `C,Z,r=a[O],T[O],P[O];N,S=c[C],C+Z;m=c[S];I(c,C+1,S-1,r+1,N);I(m,1,m.n,r+Z,N)` | сдвиг элементов таблицы (vararg) |
| 193 | `JMPLT_IMM4` | `O=if c[P[O]]<T[O]then a[O]else O` | O = (c[P]<T[O]) and a[O] or O |
| 194 | `LOAD_P2` | `c[T[O]]=P[O]` | c[T]=P[O] |
| 195 | `NEWTABLE` | `c[T[O]]={}` | c[T]={} |
| 196 | `ADD_IMM3` | `c[T[O]]=a[O]+c[P[O]]` | c[T]=a[O]+c[P] |
| 197 | `FRAME_RESTORE2` | `sP=D;D,C={[5]=e,[8]=G,[6]=sP,[9]=J},T[O];e,G=c[C+2]+0,c[C+1]+0;J=c[C]-e;O=P[O]` | восстановление кадра (вариант) |
| 198 | `BITAND_4` | `c[a[O]]=h(c[P[O]],l[O])` | c[a]=h(c[P],l[O]) |
| 199 | `BITSHIFT_H` | `c[P[O]]=W(a[O],c[T[O]])` | c[P]=W(a[O],c[T]) |
| 200 | `CALL_SPREAD6` | `c[P[O]]=c[T[O]](i(c[a[O]],1,c[a[O]].n))` | c[P]=c[T](распакованный c[a]) |
| 201 | `LOAD_Y` | `c[P[O]]=y[O]` | c[P]=y[O] |
| 202 | `JMPEQ_IMM2` | `O=if c[T[O]]==f[O]then a[O]else O` | O = (c[T]==f[O]) and a[O] or O |
| 203 | `LOAD_P3` | `c[T[O]]=P` | c[T]=P — загрузка массива P |
| 205 | `CALL_0` | `c[P[O]]=c[a[O]]()` | c[P]=c[a]() — вызов без аргументов |

Всего опкодов: **204** (из них 204 с уверенной семантикой).
