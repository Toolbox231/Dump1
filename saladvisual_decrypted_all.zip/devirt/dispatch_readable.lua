-- ============================================================================
-- Читаемый диспетчер опкодов внутреннего интерпретатора payload'а (Luraph v15.1)
-- Сгенерировано tools/devirt_names.py из дерева `if M<103 then …`
-- (срез 3128823..3202193 артефакта = state_machines/4132_2.lua)
--
-- OPS[n] — обработчик опкода n. Переменные: c — регистры, O — счётчик команд,
-- z[O] — опкод, T/P/a/y/f/l — слоты операндов, u — окружение (глобалы),
-- A — апвалюи, j/q/t — учёт открытых апвалюев, s/p/n/K — служебные значения VM.
-- Подробнее — devirt/FORMAT.md.
-- ============================================================================

local OPS = {}

-- [0] RETURN — закрывает апвалюи (j/q) и возвращает c[P[O]]
OPS[0] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP=w(LP);
  I(c,Q,Q+LP-1,1,yP);
  lP[4]=yP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[P[O]]
end

-- [1] JMPIF_NOTLT — O = (P[O] < c[T[O]]) and O or a[O] — условный переход
OPS[1] = function()
  O=if not(P[O]<c[T[O]])then a[O]else O
end

-- [2] DECODE_RUN — расшифровывает пачку инструкций (T/P/a/z) и переписывает z[O]=118
OPS[2] = function()
  Z,C=T[O],a[O]+1;
  for Q=1,P[O],1 do Z=h(W(Z,(k(Z,13))),536870911);
  Z=W(Z,(F(Z,13)));
  Z=h(W(Z,(k(Z,14))),536870911);
  T[C]=W(T[C],(h(F(Z,0),127)));
  P[C]=W(P[C],(h(F(Z,7),127)));
  a[C]=W(a[C],(h(F(Z,14),127)));
  z[C]=W(z[C],(h(F(Z,21),127)));
  C=C+1;
  end;
  z[O]=118
end

-- [3] CONCAT_K — c[T] = f[O] .. c[a[O]]
OPS[3] = function()
  c[T[O]]=f[O]..c[a[O]]
end

-- [4] CALL_1_NORES — c[T](c[a])
OPS[4] = function()
  c[T[O]](c[a[O]])
end

-- [5] MUL — c[T]=c[a]*c[P]
OPS[5] = function()
  c[T[O]]=c[a[O]]*c[P[O]]
end

-- [6] DECODE_RUN_B — хеш-декодер пачки инструкций (вариант B)
OPS[6] = function()
  Z,C=(W(P[O],(h(W(p,(h(F(p,29),7))),536870911)))),T[O]+1;
  for Q=1,a[O],1 do Z=h(W(Z,(k(Z,13))),536870911);
  Z=W(Z,(F(Z,13)));
  Z=h(W(Z,(k(Z,14))),536870911);
  T[C]=W(T[C],(h(F(Z,0),127)));
  P[C]=W(P[C],(h(F(Z,7),127)));
  a[C]=W(a[C],(h(F(Z,14),127)));
  z[C]=W(z[C],(h(F(Z,21),127)));
  C=C+1;
  end;
  z[O]=118
end

-- [7] DIV_K — c[P]=c[a]/l[O]
OPS[7] = function()
  c[P[O]]=c[a[O]]/l[O]
end

-- [8] GT_IMM — c[a]=c[P]>T[O]
OPS[8] = function()
  c[a[O]]=c[P[O]]>T[O]
end

-- [9] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[9] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP,zP=Q+LP-1,w(LP);
  I(c,Q,yP,1,zP);
  lP[4]=zP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[P[O]](c[T[O]])
end

-- [10] BITOP_AND — c[a]=h(c[T],c[P]) — побитовая операция
OPS[10] = function()
  c[a[O]]=h(c[T[O]],c[P[O]])
end

-- [11] LE — c[a]=c[T]<=c[P]
OPS[11] = function()
  c[a[O]]=c[T[O]]<=c[P[O]]
end

-- [12] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[12] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP=w(LP);
  I(c,Q,Q+LP-1,1,yP);
  lP[4]=yP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[P[O]](i(c[a[O]],1,c[a[O]].n))
end

-- [13] NE_IMM — c[T]=y[O]~=c[P]
OPS[13] = function()
  c[T[O]]=y[O]~=c[P[O]]
end

-- [14] SETUPVAL_T — запись в апвалюй: A[T][4][6][c[P]]=c[a]
OPS[14] = function()
  C=A[T[O]];
  C[4][C[6]][c[P[O]]]=c[a[O]]
end

-- [15] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[15] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP,zP=Q+LP,w(LP);
  I(c,Q,yP-1,1,zP);
  lP[4]=zP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[T[O]](c[P[O]],c[a[O]])
end

-- [16] CLOSE_LOCALS — закрытие апвалюев при выходе из блока
OPS[16] = function()
  local Q=P[O];
  if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end
end

-- [17] DIV — c[P]=c[a]/c[T]
OPS[17] = function()
  c[P[O]]=c[a[O]]/c[T[O]]
end

-- [18] GT — c[a]=c[T]>c[P]
OPS[18] = function()
  c[a[O]]=c[T[O]]>c[P[O]]
end

-- [19] TOINT — приведение числа к целому (маска 2^32)
OPS[19] = function()
  local Q,lP,LP=P[O],c[T[O]];
  repeat local yP=lP%4294967296;
  if yP~=yP then LP=0;
  break;
  end;
  LP=yP-yP%1;
  until true;
  c[Q]=LP
end

-- [20] SUB — c[a]=c[T]-c[P]
OPS[20] = function()
  c[a[O]]=c[T[O]]-c[P[O]]
end

-- [21] LOAD_K — c[a]=K (специальный регистр)
OPS[21] = function()
  c[a[O]]=K
end

-- [22] DECODE_RUN_C — хеш-декодер пачки инструкций (вариант C, через K)
OPS[22] = function()
  Z,C=(W(P[O],(h(W(K,(h(F(K,29),7))),536870911)))),T[O]+1;
  for Q=1,a[O],1 do Z=h(W(Z,(k(Z,13))),536870911);
  Z=W(Z,(F(Z,13)));
  Z=h(W(Z,(k(Z,14))),536870911);
  T[C]=W(T[C],(h(F(Z,0),127)));
  P[C]=W(P[C],(h(F(Z,7),127)));
  a[C]=W(a[C],(h(F(Z,14),127)));
  z[C]=W(z[C],(h(F(Z,21),127)));
  C=C+1;
  end;
  z[O]=118
end

-- [23] LT_IMM — c[T]=c[a]<P[O]
OPS[23] = function()
  c[T[O]]=c[a[O]]<P[O]
end

-- [24] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[24] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP,zP=Q+LP-1,w(LP);
  I(c,Q,yP,1,zP);
  lP[4]=zP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return
end

-- [25] CALL_K_1 — c[P]=E(c[T](y[O])) — вызов с константой, 1 результат
OPS[25] = function()
  c[P[O]]=E(c[T[O]](y[O]))
end

-- [26] ADD_K — c[T]=c[P]+y[O]
OPS[26] = function()
  c[T[O]]=c[P[O]]+y[O]
end

-- [27] FORLOOP — шаг числового for; c[a]=J, O=P[O]
OPS[27] = function()
  J+=e;
  C=if e<=0 then J>=G else J<=G;
  if C then c[a[O]]=J;
  O=P[O];
  else end
end

-- [28] LT — c[T]=c[a]<c[P]
OPS[28] = function()
  c[T[O]]=c[a[O]]<c[P[O]]
end

-- [29] SETTABLE_OFF — c[P[O]+c[a]]=c[T]
OPS[29] = function()
  c[P[O]+c[a[O]]]=c[T[O]]
end

-- [30] BITXOR_K — c[P]=W(c[T],y[O]) — побитовая операция с константой
OPS[30] = function()
  c[P[O]]=W(c[T[O]],y[O])
end

-- [31] JMPNE_IMM — O = (c[P]~=l[O]) and a[O] or O
OPS[31] = function()
  O=if c[P[O]]~=l[O]then a[O]else O
end

-- [32] BITOP_BATCH — пакетная побитовая операция по диапазону (Q = индекс)
OPS[32] = function()
  c[a[Q]]=h(c[T[Q]],P[Q])
end

-- [33] LOOP_BREAK — выход из пакетной операции (B=a[Q]; O=P[Q]+1; break)
--   (фрагмент, не самостоятельный оператор)
--   B=a[Q];
--     O=P[Q]+1;
--     break

-- [34] SETUPVAL_TAB — A[P][l[O]]=c[a]
OPS[34] = function()
  A[P[O]][l[O]]=c[a[O]]
end

-- [35] SETFIELD_IMM — c[a][f[O]]=T[O]
OPS[35] = function()
  c[a[O]][f[O]]=T[O]
end

-- [36] ADD_K2 — c[a]=f[O]+c[T]
OPS[36] = function()
  c[a[O]]=f[O]+c[T[O]]
end

-- [37] LE_K — c[T]=c[a]<=f[O]
OPS[37] = function()
  c[T[O]]=c[a[O]]<=f[O]
end

-- [38] GETUPVAL_FIELD — c[T]=A[P][4][6] — чтение апвалюя
OPS[38] = function()
  C=A[P[O]];
  c[T[O]]=C[4][C[6]]
end

-- [39] CALL_K_ARG — c[P]=c[a](l[O])
OPS[39] = function()
  c[P[O]]=c[a[O]](l[O])
end

-- [40] HASH_BLOCK_A — хеш-блок (смешивание 32-битных полей)
OPS[40] = function()
  local Q,lP,LP=a[O],f[O],l[O];
  local yP,zP=h(lP,4294967295),h(LP,4294967295);
  local LP,TP,nP,JP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);
  zP=h(LP*nP+k(h(LP*JP+TP*nP,65535),16),4294967295);
  lP=nil;
  repeat JP=zP%4294967296;
  if JP~=JP then lP=0;
  break;
  end;
  lP=JP-JP%1;
  until true;
  c[Q]=lP
end

-- [41] CONCAT_K2 — c[P]=c[a]..l[O]
OPS[41] = function()
  c[P[O]]=c[a[O]]..l[O]
end

-- [42] SETTABLE_IMM_KEY — c[T][a[O]]=c[P]
OPS[42] = function()
  c[T[O]][a[O]]=c[P[O]]
end

-- [43] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[43] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP,zP=Q+LP,w(LP);
  I(c,Q,yP-1,1,zP);
  lP[4]=zP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[a[O]]()
end

-- [44] MUL_K — c[T]=a[O]*c[P]
OPS[44] = function()
  c[T[O]]=a[O]*c[P[O]]
end

-- [45] MOD_K — c[T]=c[P]%y[O]
OPS[45] = function()
  c[T[O]]=c[P[O]]%y[O]
end

-- [46] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[46] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP,zP=Q+LP-1,w(LP);
  I(c,Q,yP,1,zP);
  lP[4]=zP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[T[O]],c[a[O]]
end

-- [47] JMPEQ_IMM — O = (c[a]==T[O]) and P[O] or O
OPS[47] = function()
  O=if c[a[O]]==T[O]then P[O]else O
end

-- [48] HASH_BLOCK_B — хеш-блок (вариант)
OPS[48] = function()
  local Q,lP,LP=T[O],c[P[O]],a[O];
  local yP,zP=h(lP,4294967295),h(LP,4294967295);
  local TP,nP,JP,HP=h(yP,65535),F(yP,16),h(zP,65535),F(zP,16);
  lP=h(TP*JP+k(h(TP*HP+nP*JP,65535),16),4294967295);
  JP=nil;
  repeat LP=lP%4294967296;
  if LP~=LP then JP=0;
  break;
  end;
  JP=LP-LP%1;
  until true;
  c[Q]=JP
end

-- [49] MOVE — c[P]=c[a]
OPS[49] = function()
  c[P[O]]=c[a[O]]
end

-- [50] LEN — c[T]=#c[P]
OPS[50] = function()
  c[T[O]]=#c[P[O]]
end

-- [51] GE — c[a]=c[P]>=c[T]
OPS[51] = function()
  c[a[O]]=c[P[O]]>=c[T[O]]
end

-- [52] SETTABLE_K — c[a][c[P]]=l[O]
OPS[52] = function()
  c[a[O]][c[P[O]]]=l[O]
end

-- [53] GETUPVAL_IDX — c[T]=A[P][4][6][c[a]]
OPS[53] = function()
  C=A[P[O]];
  c[T[O]]=C[4][C[6]][c[a[O]]]
end

-- [54] LE_K2 — c[P]=c[T]<=a[O]
OPS[54] = function()
  c[P[O]]=c[T[O]]<=a[O]
end

-- [55] GETTABLE — c[T]=c[P][a[O]]
OPS[55] = function()
  c[T[O]]=c[P[O]][a[O]]
end

-- [56] POW — c[T]=P[O]^c[a]
OPS[56] = function()
  c[T[O]]=P[O]^c[a[O]]
end

-- [57] JMPLE — O = (c[P]<=c[T]) and O or a[O]
OPS[57] = function()
  O=if not(c[P[O]]<=c[T[O]])then a[O]else O
end

-- [58] UNM — c[T]=-c[a]
OPS[58] = function()
  c[T[O]]=-c[a[O]]
end

-- [59] HASH_UPVAL — хеш-получение через апвалюй (декодер константы)
OPS[59] = function()
  local lP,LP,yP=T[O],W(P[O],(h(W(p,(h(F(p,29),7))),536870911))),n[6];
  local zP=W(yP[lP],187638924);
  yP[lP]=zP;
  lP,yP=n[5],zP+1;
  zP=V(lP,yP);
  local TP,nP;
  if zP<128 then TP,nP=zP,yP+1;
  else local JP=V(lP,yP+1);
  if JP<128 then TP,nP=(zP-128)*128+JP,yP+2;
  else local HP=V(lP,yP+2);
  if HP<128 then TP,nP=(zP-128)*16384+(JP-128)+HP*128,yP+3;
  else local fP=V(lP,yP+3);
  TP,nP=zP-128+(JP-128)*2097152+(HP-128)*128+fP%128*16384+(fP-fP%128)*2097152,yP+4;
  end;
  end;
  end;
  yP,zP=LP*16843009,nP+TP;
  local JP=zP-TP%4;
  for TP=nP,JP-1,4 do _(lP,TP,(W(X(lP,TP),yP)));
  end;
  for yP=JP,zP-1,1 do x(lP,yP,(W(V(lP,yP),LP)));
  end;
  T[O]=55;
  P[O]=57;
  a[O]=120;
  z[O]=118
end

-- [60] LOAD_TRIPLE — c[a]=n; c[a+1]=a; c[P+2]=z; O+=2 — загрузка внутренних таблиц VM
OPS[60] = function()
  c[a[O]]=n;
  c[a[O+1]]=a;
  c[P[O+2]]=z;
  O+=2
end

-- [61] FORPREP — подготовка числового for
OPS[61] = function()
  local lP,LP,yP=a[O],c[T[O]],c[P[O]];
  local zP,TP=h(LP,4294967295),h(yP,4294967295);
  local LP,yP,nP,JP=h(zP,65535),F(zP,16),h(TP,65535),F(TP,16);
  zP=h(LP*nP+k(h(LP*JP+yP*nP,65535),16),4294967295);
  nP=nil;
  repeat LP=zP%4294967296;
  if LP~=LP then nP=0;
  break;
  end;
  nP=LP-LP%1;
  until true;
  c[lP]=nP
end

-- [62] EQ — c[a]=c[P]==c[T]
OPS[62] = function()
  c[a[O]]=c[P[O]]==c[T[O]]
end

-- [63] BITSHIFT_A — c[P]=v(c[a],c[T]) — сдвиг
OPS[63] = function()
  c[P[O]]=v(c[a[O]],c[T[O]])
end

-- [64] SETFIELD_K — c[P][l[O]]=y[O]
OPS[64] = function()
  c[P[O]][l[O]]=y[O]
end

-- [65] CALL_K_CONST — c[P](c[T],y[O])
OPS[65] = function()
  c[P[O]](c[T[O]],y[O])
end

-- [66] JMPIF — O = c[a] and T[O] or P[O]
OPS[66] = function()
  O=if c[a[O]]then T[O]else P[O]
end

-- [67] LOAD_S — c[T]=s (служебная таблица)
OPS[67] = function()
  c[T[O]]=s
end

-- [68] VARARG_MOVE — перепаковка регистров (vararg/аргументы)
OPS[68] = function()
  C,Z,r=T[O],P[O],a[O];
  N=C+Z;
  S=c[N];
  m=S.n;
  Y=Z+m-1;
  S.n=Y;
  I(S,1,m,Z,S);
  I(c,C+1,N-1,1,S);
  c[C]=E(c[C](i(S,1,S.n)))
end

-- [69] JMPLT_IMM — O = (T[O]<c[P]) and a[O] or O
OPS[69] = function()
  O=if T[O]<c[P[O]]then a[O]else O
end

-- [70] GETTABLE_REG — c[T]=c[P][c[a]]
OPS[70] = function()
  c[T[O]]=c[P[O]][c[a[O]]]
end

-- [71] CLEAR_RANGE — обнуление диапазона регистров
OPS[71] = function()
  for lP=T[O],a[O],1 do c[lP]=nil;
  end
end

-- [72] VARARG_SHIFT — сдвиг регистров/vararg
OPS[72] = function()
  C,Z,r=a[O],T[O],P[O];
  N=c[C];
  I(c,C+1,C+Z,r+1,N)
end

-- [73] CALL_SPREAD — c[a](l[O], распакованный c[P])
OPS[73] = function()
  c[a[O]](l[O],i(c[P[O]],1,c[P[O]].n))
end

-- [74] BITOP_AND_K — c[T]=W(y[O],c[P])
OPS[74] = function()
  c[T[O]]=W(y[O],c[P[O]])
end

-- [75] SETTABLE_IMM_VAL — c[T][c[a]]=P[O]
OPS[75] = function()
  c[T[O]][c[a[O]]]=P[O]
end

-- [76] SETUPVAL_RAW — A[a][4][6]=l[O]
OPS[76] = function()
  C=A[a[O]];
  C[4][C[6]]=l[O]
end

-- [77] CALL_MULTI — вызов с несколькими результатами (pcall-подобный)
OPS[77] = function()
  C=a[O];
  local Q,lP,LP=J();
  if Q then c[C+1]=lP;
  c[C+2]=LP;
  O=P[O];
  else end;
  Z,r,N=Q,lP,LP
end

-- [78] GT_K — c[a]=c[T]>f[O]
OPS[78] = function()
  c[a[O]]=c[T[O]]>f[O]
end

-- [79] SETUPVAL_TAB2 — A[T][c[P]]=y[O]
OPS[79] = function()
  A[T[O]][c[P[O]]]=y[O]
end

-- [80] SETUPVAL_TAB3 — A[a][f[O]]=l[O]
OPS[80] = function()
  A[a[O]][f[O]]=l[O]
end

-- [81] EQ_IMM — c[a]=c[P]==T[O]
OPS[81] = function()
  c[a[O]]=c[P[O]]==T[O]
end

-- [82] GETGLOBAL — c[T]=u[y[O]] — чтение глобала из окружения
OPS[82] = function()
  c[T[O]]=u[y[O]]
end

-- [83] GETTABUP — c[P]=A[a][l[O]]
OPS[83] = function()
  c[P[O]]=A[a[O]][l[O]]
end

-- [84] JMPIFNOT — O = (not c[T]) and a[O] or P[O]
OPS[84] = function()
  O=if not c[T[O]]then a[O]else P[O]
end

-- [85] BITSHIFT_B — c[a]=v(f[O],c[T])
OPS[85] = function()
  c[a[O]]=v(f[O],c[T[O]])
end

-- [86] MOD — c[P]=c[a]%c[T]
OPS[86] = function()
  c[P[O]]=c[a[O]]%c[T[O]]
end

-- [87] MUL_K2 — c[T]=c[a]*f[O]
OPS[87] = function()
  c[T[O]]=c[a[O]]*f[O]
end

-- [88] SETFIELD — c[T][f[O]]=c[a]
OPS[88] = function()
  c[T[O]][f[O]]=c[a[O]]
end

-- [89] LOAD_S2 — c[a]=s[T[O]]
OPS[89] = function()
  c[a[O]]=s[T[O]]
end

-- [90] VARARG_TABLE — упаковка/сдвиг таблицы аргументов
OPS[90] = function()
  C,Z,r=a[O],P[O],T[O];
  N,S=C+r-1,C+Z;
  m=c[S];
  Y=m.n;
  b=Z+Y-1;
  m.n=b;
  I(m,1,Y,Z,m);
  I(c,C+1,S-1,1,m);
  o=E(c[C](i(m,1,m.n)));
  I(o,1,r,C,c)
end

-- [91] ADD — c[T]=c[P]+c[a]
OPS[91] = function()
  c[T[O]]=c[P[O]]+c[a[O]]
end

-- [92] CALL_K_2 — c[a](l[O],f[O])
OPS[92] = function()
  c[a[O]](l[O],f[O])
end

-- [93] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[93] = function()
  if j then for Q in t,j,nil do if j then local lP=j[Q];
  if lP then lP[4]=lP;
  lP[5]=c[Q];
  lP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,lP in t,q,nil do local LP=lP[5];
  if q then lP=q[Q];
  if lP then local yP=w(LP);
  I(c,Q,Q+LP-1,1,yP);
  lP[4]=yP;
  lP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return y[O]
end

-- [94] CALL_FRAME — вызов с сохранением кадра (e/G/J/D) — вход в Lua-функцию
OPS[94] = function()
  sP=D;
  D,C,Z={[5]=e,[8]=G,[6]=sP,[9]=J},T[O],R(g);
  Z(s,c[C],c[C+1],c[C+2]);
  O,J=P[O],Z
end

-- [95] SETTABLE_K2 — c[a][P[O]]=l[O]
OPS[95] = function()
  c[a[O]][P[O]]=l[O]
end

-- [96] SETTABLE — c[P][c[a]]=c[T]
OPS[96] = function()
  c[P[O]][c[a[O]]]=c[T[O]]
end

-- [97] ADD_IMM — c[a]=c[P]+T[O]
OPS[97] = function()
  c[a[O]]=c[P[O]]+T[O]
end

-- [98] CALL_VARARG — вызов с упаковкой vararg
--   (фрагмент, не самостоятельный оператор)
--   C,Z,r=P[O],{...},a[O];
--     I(Z,1,C-1,r,c);
--     c[r+C-1]=E(Q(C,...))

-- [99] HASH_UPVAL2 — хеш-получение через апвалюй (вариант)
OPS[99] = function()
  local lP,LP,yP=T[O],W(P[O],(h(W(K,(h(F(K,29),7))),536870911))),n[6];
  local zP=W(yP[lP],187638924);
  yP[lP]=zP;
  yP,lP=n[5],zP+1;
  zP=V(yP,lP);
  local TP,nP;
  if zP<128 then TP,nP=zP,lP+1;
  else local JP=V(yP,lP+1);
  if JP<128 then TP,nP=(zP-128)*128+JP,lP+2;
  else local HP=V(yP,lP+2);
  if HP<128 then TP,nP=(zP-128)*16384+(JP-128)+HP*128,lP+3;
  else local fP=V(yP,lP+3);
  TP,nP=zP-128+(JP-128)*2097152+(HP-128)*128+fP%128*16384+(fP-fP%128)*2097152,lP+4;
  end;
  end;
  end;
  lP,zP=LP*16843009,nP+TP;
  local JP=zP-TP%4;
  for TP=nP,JP-1,4 do _(yP,TP,(W(X(yP,TP),lP)));
  end;
  for lP=JP,zP-1,1 do x(yP,lP,(W(V(yP,lP),LP)));
  end;
  T[O]=162;
  P[O]=195;
  a[O]=16;
  z[O]=118
end

-- [100] DIV_K2 — c[P]=c[T]/a[O]
OPS[100] = function()
  c[P[O]]=c[T[O]]/a[O]
end

-- [101] CALL_SHIFT — вызов со сдвигом результатов
OPS[101] = function()
  C,Z,r=T[O],a[O],P[O];
  N,S,m=C+r-1,C+Z,E(c[C](i(c,C+1,C+Z)));
  I(m,1,r,C,c)
end

-- [102] CALL_0_NORES — c[T]()
OPS[102] = function()
  c[T[O]]()
end

-- [103] ADD_IMM2 — c[a]=f[O]+l[O]
OPS[103] = function()
  c[a[O]]=f[O]+l[O]
end

-- [104] CALL_1 — c[a]=E(c[P](c[T]))
OPS[104] = function()
  c[a[O]]=E(c[P[O]](c[T[O]]))
end

-- [105] HASH_UPVAL3 — хеш-получение (вариант с масками <16384/<2097152)
OPS[105] = function()
  C,Z,r,N=P[O],T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O];
  S=C<2097152 and 7 or 14;
  m,Y=h(C,k(1,S)-1),F(C,S);
  T[O]=W(Z,20,(h(r,127)));
  z[O]=W(Y,86,(h(F(r,21),127)));
  a[O]=W(N,73,(h(F(r,14),127)));
  P[O]=W(m,95,(h(F(r,7),127)));
  O=O-1
end

-- [106] FORPREP2 — подготовка for (вариант)
OPS[106] = function()
  local Q,sP,lP=T[O],a[O],c[P[O]];
  local LP,yP=h(sP,4294967295),h(lP,4294967295);
  local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);
  sP=h(lP*TP+k(h(lP*nP+zP*TP,65535),16),4294967295);
  TP=nil;
  repeat yP=sP%4294967296;
  if yP~=yP then TP=0;
  break;
  end;
  TP=yP-yP%1;
  until true;
  c[Q]=TP
end

-- [107] MOVE_TRIPLE — c[T..T+3]=P[O..O+3]; O+=3
OPS[107] = function()
  c[T[O]]=P[O];
  c[T[O+1]]=P[O+1];
  c[T[O+2]]=P[O+2];
  c[T[O+3]]=P[O+3];
  O+=3
end

-- [108] BITAND_2 — c[a]=h(f[O],c[T])
OPS[108] = function()
  c[a[O]]=h(f[O],c[T[O]])
end

-- [109] JMP_REG — O=c[a] — косвенный переход
OPS[109] = function()
  O=c[a[O]]
end

-- [110] BITXOR_KK — c[T]=W(f[O],y[O]) — свёртка двух констант
OPS[110] = function()
  c[T[O]]=W(f[O],y[O])
end

-- [111] CALL_SPREAD2 — c[P](распакованный c[a])
OPS[111] = function()
  c[P[O]](i(c[a[O]],1,c[a[O]].n))
end

-- [112] SPLIT3 — спец-операция: разбор строки/таблицы по 3 поля
OPS[112] = function()
  local Q;
  local sP=l[O];
  if sP then local lP=#sP/3;
  if lP>0 then Q={};
  local LP,yP=j,q;
  for zP=1,lP,1 do local lP=(zP-1)*3;
  local TP,nP=sP[lP+3],sP[lP+2];
  if TP==2 then LP=if not LP then{}else LP;
  local JP=LP[nP];
  if not JP then JP={[4]=c,[6]=nP};
  LP[nP]=JP;
  else end;
  Q[zP]=JP;
  else if TP==1 then Q[zP]=c[nP];
  else if TP==3 then Q[zP]=A[nP];
  else if TP==0 then yP=if not yP then{}else yP;
  local TP=yP[nP];
  if not TP then TP={[5]=sP[lP+1],[6]=nP,[4]=c};
  yP[nP]=TP;
  else end;
  Q[zP]=TP;
  else end;
  end;
  end;
  end;
  end;
  j,q=LP,yP;
  else end;
  else end;
  c[P[O]]=y[O](nil,Q);
  C=Q
end

-- [113] JMPLE_REG — O = (T[O]<=c[a]) and P[O] or O
OPS[113] = function()
  O=if T[O]<=c[a[O]]then P[O]else O
end

-- [114] GETTABUP2 — c[T]=A[P][a[O]]
OPS[114] = function()
  c[T[O]]=A[P[O]][a[O]]
end

-- [115] IDIV — c[T]=c[P]//a[O]
OPS[115] = function()
  c[T[O]]=c[P[O]]//a[O]
end

-- [116] LOAD_K2 — K=c[a] — запись в спец-регистр
OPS[116] = function()
  K=c[a[O]]
end

-- [117] BITSHIFT_C — c[P]=W(c[T],a[O])
OPS[117] = function()
  c[P[O]]=W(c[T[O]],a[O])
end

-- [119] NOT — c[a]=not c[T]
OPS[119] = function()
  c[a[O]]=not c[T[O]]
end

-- [120] CALL_SPREAD3 — c[a]=E(c[P](распакованный c[T]))
OPS[120] = function()
  c[a[O]]=E(c[P[O]](i(c[T[O]],1,c[T[O]].n)))
end

-- [121] CONCAT — c[a]=c[T]..c[P]
OPS[121] = function()
  c[a[O]]=c[T[O]]..c[P[O]]
end

-- [122] NE — c[a]=c[T]~=c[P]
OPS[122] = function()
  c[a[O]]=c[T[O]]~=c[P[O]]
end

-- [123] CALL_1_R — c[T]=c[P](c[a])
OPS[123] = function()
  c[T[O]]=c[P[O]](c[a[O]])
end

-- [124] LOAD_N — c[a]=n — загрузка внутреннего значения VM
OPS[124] = function()
  c[a[O]]=n
end

-- [125] SET_S — s[y[O]]=f[O]
OPS[125] = function()
  s[y[O]]=f[O]
end

-- [126] LOAD_Z — c[P]=z — загрузка массива опкодов
OPS[126] = function()
  c[P[O]]=z
end

-- [127] SUB_K — c[a]=c[P]-l[O]
OPS[127] = function()
  c[a[O]]=c[P[O]]-l[O]
end

-- [128] SLICE_VARARG — c[P]=E(c[T][a[O]..n]) — срез vararg
OPS[128] = function()
  C=c[T[O]];
  c[P[O]]=E(i(C,a[O],C.n))
end

-- [129] LOAD_REGS — c[P]=c — загрузка файла регистров
OPS[129] = function()
  c[P[O]]=c
end

-- [130] SETTABUP — A[P][4][6][c[T]]=y[O]
OPS[130] = function()
  C=A[P[O]];
  C[4][C[6]][c[T[O]]]=y[O]
end

-- [131] SET_S2 — s[P[O]]=c[a]
OPS[131] = function()
  s[P[O]]=c[a[O]]
end

-- [132] BITSHIFT_D — c[P]=v(T[O],c[a])
OPS[132] = function()
  c[P[O]]=v(T[O],c[a[O]])
end

-- [133] FORPREP3 — подготовка for (вариант)
OPS[133] = function()
  local Q,sP,lP=T[O],y[O],c[P[O]];
  local LP,yP=h(sP,4294967295),h(lP,4294967295);
  local lP,zP,TP,nP=h(LP,65535),F(LP,16),h(yP,65535),F(yP,16);
  yP=h(lP*TP+k(h(lP*nP+zP*TP,65535),16),4294967295);
  sP=nil;
  repeat TP=yP%4294967296;
  if TP~=TP then sP=0;
  break;
  end;
  sP=TP-TP%1;
  until true;
  c[Q]=sP
end

-- [134] JMPEQ — O = (c[T]==c[P]) and a[O] or O
OPS[134] = function()
  O=if c[T[O]]==c[P[O]]then a[O]else O
end

-- [135] LT_K — c[a]=c[P]<l[O]
OPS[135] = function()
  c[a[O]]=c[P[O]]<l[O]
end

-- [136] GETTABLE_K — c[T]=c[P][y[O]]
OPS[136] = function()
  c[T[O]]=c[P[O]][y[O]]
end

-- [137] JMPLE_IMM2 — O = (c[T]<=a[O]) and P[O] or O
OPS[137] = function()
  O=if not(c[T[O]]<=a[O])then P[O]else O
end

-- [138] GET_S — c[T]=s[f[O]]
OPS[138] = function()
  c[T[O]]=s[f[O]]
end

-- [139] SETUPVAL_TAB4 — A[T][y[O]]=P[O]
OPS[139] = function()
  A[T[O]][y[O]]=P[O]
end

-- [140] FRAME_RESTORE — восстановление кадра (J,G,e,D) — возврат из вызова
OPS[140] = function()
  J,G=D[9],D[8];
  e,D=D[5],D[6]
end

-- [141] PREP_CALL — c[a+1]=c[P]; c[a]=c[P][l[O]] — метод-вызов
OPS[141] = function()
  C,Z=a[O],c[P[O]];
  c[C+1]=Z;
  c[C]=Z[l[O]]
end

-- [142] CALL_SPREAD4 — c[a]=E(c[a](распакованные))
OPS[142] = function()
  C,Z,r=a[O],P[O],T[O];
  N=C+Z;
  c[C]=E(c[C](i(c,C+1,N)))
end

-- [143] NE_K — c[P]=c[T]~=a[O]
OPS[143] = function()
  c[P[O]]=c[T[O]]~=a[O]
end

-- [144] JMPLT_IMM2 — O = (c[a]<f[O]) and T[O] or O
OPS[144] = function()
  O=if c[a[O]]<f[O]then T[O]else O
end

-- [145] JMPLT_IMM3 — O = (c[P]<T[O]) and a[O] or O
OPS[145] = function()
  O=if not(c[P[O]]<T[O])then a[O]else O
end

-- [146] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[146] = function()
  if j then for Q in t,j,nil do if j then local sP=j[Q];
  if sP then sP[4]=sP;
  sP[5]=c[Q];
  sP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,sP in t,q,nil do local lP=sP[5];
  if q then sP=q[Q];
  if sP then local LP=w(lP);
  I(c,Q,Q+lP-1,1,LP);
  sP[4]=LP;
  sP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[P[O]](y[O],i(c[T[O]],1,c[T[O]].n))
end

-- [147] SETTABUP2 — A[a][c[T]]=c[P]
OPS[147] = function()
  A[a[O]][c[T[O]]]=c[P[O]]
end

-- [148] BITAND_3 — c[a]=h(T[O],c[P])
OPS[148] = function()
  c[a[O]]=h(T[O],c[P[O]])
end

-- [149] LOAD_A — c[a]=a — загрузка массива операндов
OPS[149] = function()
  c[a[O]]=a
end

-- [150] VARARG_PACK — упаковка {...} в регистры
--   (фрагмент, не самостоятельный оператор)
--   C,Z={...},a[O];
--     I(C,1,P[O],Z,c)

-- [151] BITSHIFT_E — c[T]=k(c[P],a[O])
OPS[151] = function()
  c[T[O]]=k(c[P[O]],a[O])
end

-- [152] MUL_K3 — c[a]=f[O]*c[T]
OPS[152] = function()
  c[a[O]]=f[O]*c[T[O]]
end

-- [153] JMP — O=T[O] — прямой переход
OPS[153] = function()
  O=T[O]
end

-- [154] JMPNE — O = (c[P]~=c[T]) and a[O] or O
OPS[154] = function()
  O=if c[P[O]]~=c[T[O]]then a[O]else O
end

-- [155] SET_P — p=c[a] — запись в спец-регистр p
OPS[155] = function()
  p=c[a[O]]
end

-- [156] EQ_K — c[P]=l[O]==c[a]
OPS[156] = function()
  c[P[O]]=l[O]==c[a[O]]
end

-- [157] SETTABUP3 — A[a][4][6][f[O]]=c[T]
OPS[157] = function()
  C=A[a[O]];
  C[4][C[6]][f[O]]=c[T[O]]
end

-- [158] GETTABUP3 — c[P]=A[a][4][6][l[O]]
OPS[158] = function()
  C=A[a[O]];
  c[P[O]]=C[4][C[6]][l[O]]
end

-- [159] BITSHIFT_F — c[a]=F(c[T],P[O])
OPS[159] = function()
  c[a[O]]=F(c[T[O]],P[O])
end

-- [160] GETIMPORT — c[T]=u[y[O]][f[O]] — глобал с полем (u=окружение) [подтверждено: падение nil.new]
OPS[160] = function()
  c[T[O]]=u[y[O]][f[O]]
end

-- [161] MOD_K2 — c[T]=c[P]%a[O]
OPS[161] = function()
  c[T[O]]=c[P[O]]%a[O]
end

-- [162] CALL_2 — c[T](c[a],c[P])
OPS[162] = function()
  c[T[O]](c[a[O]],c[P[O]])
end

-- [163] GETUPVAL — c[a]=A[P] — чтение апвалюя
OPS[163] = function()
  c[a[O]]=A[P[O]]
end

-- [164] JMPLE_IMM3 — O = (c[a]<=T[O]) and P[O] or O
OPS[164] = function()
  O=if c[a[O]]<=T[O]then P[O]else O
end

-- [165] HASH_UPVAL4 — хеш-получение через апвалюй (вариант)
OPS[165] = function()
  local Q,sP,lP=a[O],P[O],n[6];
  local LP=W(lP[Q],187638924);
  lP[Q]=LP;
  lP,Q=n[5],LP+1;
  LP=V(lP,Q);
  local yP,zP;
  if LP<128 then yP,zP=LP,Q+1;
  else local TP=V(lP,Q+1);
  if TP<128 then yP,zP=(LP-128)*128+TP,Q+2;
  else local nP=V(lP,Q+2);
  if nP<128 then yP,zP=(LP-128)*16384+(TP-128)+nP*128,Q+3;
  else local JP=V(lP,Q+3);
  yP,zP=LP-128+(TP-128)*2097152+(nP-128)*128+JP%128*16384+(JP-JP%128)*2097152,Q+4;
  end;
  end;
  end;
  LP,Q=sP*16843009,zP+yP;
  local TP=Q-yP%4;
  for yP=zP,TP-1,4 do _(lP,yP,(W(X(lP,yP),LP)));
  end;
  for LP=TP,Q-1,1 do x(lP,LP,(W(V(lP,LP),sP)));
  end;
  a[O]=200;
  P[O]=148;
  T[O]=142;
  z[O]=118
end

-- [166] EQ_K2 — c[P]=c[a]==l[O]
OPS[166] = function()
  c[P[O]]=c[a[O]]==l[O]
end

-- [167] LOAD_P — c[P]=p
OPS[167] = function()
  c[P[O]]=p
end

-- [168] LOAD_T — c[T]=T — загрузка массива T
OPS[168] = function()
  c[T[O]]=T
end

-- [169] GETUPVAL_FIELD2 — c[a]=A[P][c[T]]
OPS[169] = function()
  c[a[O]]=A[P[O]][c[T[O]]]
end

-- [170] SUB_IMM — c[a]=T[O]-c[P]
OPS[170] = function()
  c[a[O]]=T[O]-c[P[O]]
end

-- [171] JMPLT_REG_ALT — (if c[a]<c[P] then T[O] else O)
--   (фрагмент, не самостоятельный оператор)
--   if c[a[O]]<c[P[O]]then T[O]else O

-- [172] JMPLT_REG — (if not (c[T]<c[a]) then P[O] else O)
--   (фрагмент, не самостоятельный оператор)
--   if not(c[T[O]]<c[a[O]])then P[O]else O

-- [173] HASH_BLOCK_C — хеш-блок (вариант)
OPS[173] = function()
  C,Z,r,N=T[O],W(p,h(F(p,14),262143),(h(F(p,28),15))),a[O],P[O];
  S=C<16384 and 7 or(C<2097152 and 14 or 21);
  m,Y=F(C,S),h(C,k(1,S)-1);
  z[O]=W(m,18,(h(F(Z,21),127)));
  a[O]=W(r,115,(h(F(Z,14),127)));
  T[O]=W(Y,24,(h(Z,127)));
  P[O]=W(N,87,(h(F(Z,7),127)));
  O=O-1
end

-- [174] JMP_INDIRECT — O=c[P] — косвенный переход
OPS[174] = function()
  O=c[P[O]]
end

-- [175] BITOP_C — c[a]=W(c[P],c[T])
OPS[175] = function()
  c[a[O]]=W(c[P[O]],c[T[O]])
end

-- [176] SUB_K2 — c[P]=c[T]-a[O]
OPS[176] = function()
  c[P[O]]=c[T[O]]-a[O]
end

-- [177] BITSHIFT_G — c[P]=v(c[a],l[O])
OPS[177] = function()
  c[P[O]]=v(c[a[O]],l[O])
end

-- [178] NE_K2 — c[P]=c[T]~=y[O]
OPS[178] = function()
  c[P[O]]=c[T[O]]~=y[O]
end

-- [179] IDIV_REG — c[a]=c[T]//c[P]
OPS[179] = function()
  c[a[O]]=c[T[O]]//c[P[O]]
end

-- [180] CLOSE_UPVALS — закрытие открытых апвалюев (вариант)
OPS[180] = function()
  C=a[O];
  r=C+T[O];
  if j then for Q in t,j,nil do if j then local sP=j[Q];
  if sP then sP[4]=sP;
  sP[5]=c[Q];
  sP[6]=5;
  j[Q]=nil;
  end;
  end;
  end;
  end;
  if q then for Q,sP in t,q,nil do local lP=sP[5];
  if q then sP=q[Q];
  if sP then local LP,yP=Q+lP,w(lP);
  I(c,Q,LP-1,1,yP);
  sP[4]=yP;
  sP[6]=1;
  q[Q]=nil;
  end;
  end;
  end;
  end;
  return c[C](i(c,C+1,r))
end

-- [181] GET_W — c[P]=w(a[O]) — получение апвалюя/замыкания
OPS[181] = function()
  c[P[O]]=w(a[O])
end

-- [182] CALL_2_R — c[T],c[P]=c[a]() — вызов, 2 результата
OPS[182] = function()
  c[T[O]],c[P[O]]=c[a[O]]()
end

-- [183] JMPNE_IMM2 — O = (c[a]~=P[O]) and T[O] or O
OPS[183] = function()
  O=if c[a[O]]~=P[O]then T[O]else O
end

-- [184] GE_K — c[T]=c[P]>=a[O]
OPS[184] = function()
  c[T[O]]=c[P[O]]>=a[O]
end

-- [185] MUL_K4 — c[P]=c[a]*T[O]
OPS[185] = function()
  c[P[O]]=c[a[O]]*T[O]
end

-- [186] SETTABLE_IMM2 — c[a][T[O]]=P[O]
OPS[186] = function()
  c[a[O]][T[O]]=P[O]
end

-- [187] CALL_K_3 — c[T](f[O],c[a])
OPS[187] = function()
  c[T[O]](f[O],c[a[O]])
end

-- [188] CALL_SPREAD5 — c[T](c[a], распакованный c[P])
OPS[188] = function()
  c[T[O]](c[a[O]],i(c[P[O]],1,c[P[O]].n))
end

-- [189] SETTABUP4 — A[a][4][6]=c[P]
OPS[189] = function()
  C=A[a[O]];
  C[4][C[6]]=c[P[O]]
end

-- [190] TOINT2 — c[T]=U(c[P]) — приведение числа
OPS[190] = function()
  c[T[O]]=U(c[P[O]])
end

-- [191] CALL_1_K — c[T](y[O])
OPS[191] = function()
  c[T[O]](y[O])
end

-- [192] TABLE_SHIFT — сдвиг элементов таблицы (vararg)
OPS[192] = function()
  C,Z,r=a[O],T[O],P[O];
  N,S=c[C],C+Z;
  m=c[S];
  I(c,C+1,S-1,r+1,N);
  I(m,1,m.n,r+Z,N)
end

-- [193] JMPLT_IMM4 — O = (c[P]<T[O]) and a[O] or O
OPS[193] = function()
  O=if c[P[O]]<T[O]then a[O]else O
end

-- [194] LOAD_P2 — c[T]=P[O]
OPS[194] = function()
  c[T[O]]=P[O]
end

-- [195] NEWTABLE — c[T]={}
OPS[195] = function()
  c[T[O]]={}
end

-- [196] ADD_IMM3 — c[T]=a[O]+c[P]
OPS[196] = function()
  c[T[O]]=a[O]+c[P[O]]
end

-- [197] FRAME_RESTORE2 — восстановление кадра (вариант)
OPS[197] = function()
  sP=D;
  D,C={[5]=e,[8]=G,[6]=sP,[9]=J},T[O];
  e,G=c[C+2]+0,c[C+1]+0;
  J=c[C]-e;
  O=P[O]
end

-- [198] BITAND_4 — c[a]=h(c[P],l[O])
OPS[198] = function()
  c[a[O]]=h(c[P[O]],l[O])
end

-- [199] BITSHIFT_H — c[P]=W(a[O],c[T])
OPS[199] = function()
  c[P[O]]=W(a[O],c[T[O]])
end

-- [200] CALL_SPREAD6 — c[P]=c[T](распакованный c[a])
OPS[200] = function()
  c[P[O]]=c[T[O]](i(c[a[O]],1,c[a[O]].n))
end

-- [201] LOAD_Y — c[P]=y[O]
OPS[201] = function()
  c[P[O]]=y[O]
end

-- [202] JMPEQ_IMM2 — O = (c[T]==f[O]) and a[O] or O
OPS[202] = function()
  O=if c[T[O]]==f[O]then a[O]else O
end

-- [203] LOAD_P3 — c[T]=P — загрузка массива P
OPS[203] = function()
  c[T[O]]=P
end

-- [205] CALL_0 — c[P]=c[a]() — вызов без аргументов
OPS[205] = function()
  c[P[O]]=c[a[O]]()
end

return OPS
