#!/bin/sh
# Запуск payload'а «как есть» в песочнице Luau — одной командой, с отчётом в конце.
#
# Это запуск ОРИГИНАЛЬНОГО артефакта (не восстановленного кода) в mock-среде Roblox:
# payload проходит инициализацию (≈3 млн вызовов VM), декодирует строки и уходит
# в главный цикл мода. Сам восстановленный код отдельно запустить нельзя — почему,
# написано в RUN.md.
#
# Подготовка: собранный CLI Luau (в воркспейсе build/ не сохраняется):
#   git clone --depth 1 https://github.com/luau-lang/luau.git && cd luau && make -j2 config=release luau
#   export LUAU_BIN=$PWD/build/release/luau
#
# Запуск:            ./tools/run_payload.sh
# С событиями:       EVDRIVE=200 ./tools/run_payload.sh      # «стрелять» в сигналы в главном цикле
# Дольше в цикле:    IDXCAP=250 ./tools/run_payload.sh       # 250 — минимум для полной инициализации
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${WORK:-/home/user/work}"
ARTIFACT="${ARTIFACT:-/home/user/uploads/saladvisual_payload.lua.txt}"
LOG="${LOG:-$WORK/trace_run.log}"
LUAU_BIN="${LUAU_BIN:-$WORK/luau2/build/release/luau}"

if [ ! -x "$LUAU_BIN" ]; then
  echo "нет CLI Luau: $LUAU_BIN"
  echo "соберите: git clone --depth 1 https://github.com/luau-lang/luau.git && cd luau && make -j2 config=release luau"
  echo "затем: export LUAU_BIN=\$PWD/build/release/luau"
  exit 1
fi

: "${IDXCAP:=250}"; : "${AUTO:=1}"; : "${TICK:=1000}"; : "${CAP:=1000000000}"
: "${EVDRIVE:=0}"; : "${EVSTEP:=20000}"

echo "[1/3] сборка run.luau (IDXCAP=$IDXCAP AUTO=$AUTO EVDRIVE=$EVDRIVE)"
cd "$WORK"
IDXCAP=$IDXCAP AUTO=$AUTO TICK=$TICK CAP=$CAP EVDRIVE=$EVDRIVE EVSTEP=$EVSTEP IDXLOG=1 \
  STMT_FROM=3128700 STMT_TO=3202250 \
  TRACE_SKIP="eT,BT,UT,FT,JT,oT,OT,aT,zS,97,33" \
  python3 build_stmt.py >/dev/null

echo "[2/3] запуск payload'а в песочнице (таймаут 300 с)"
timeout 300 "$LUAU_BIN" run.luau > "$LOG" 2>&1 || true
echo "[3/3] отчёт:"
python3 - "$LOG" <<'PY'
import re, sys
txt = open(sys.argv[1], encoding='utf-8', errors='replace').read()
g = lambda tag: len(re.findall(r'^' + tag, txt, re.M))
status = re.search(r'^STATUS\t(.*)$', txt, re.M)
err = re.search(r'^ERR\t(.*)$', txt, re.M)
idxn = re.search(r'^IDXN\t(.*)$', txt, re.M)
auto = re.findall(r'^AUTO\t(\d+)\t(\S+)$', txt, re.M)
print('  строк в логе:      %d (%s)' % (txt.count('\n') + 1, sys.argv[1]))
print('  инициализация:     STATUS=%s%s' % (status.group(1) if status else '?',
                                            ('  ERR=' + err.group(1)) if err else ''))
hb = re.findall(r'^HB\t(\d+)', txt, re.M)
print('  вызовов VM:        %s (по счётчику HB)' % (hb and format(int(hb[-1]), ',d').replace(',', ' ') or '—'))
print('  констант прочитано: %d' % g(r'PR\t'))
print('  строк декодировано: %d' % g(r'(DECSTR|CHSTR|CCSTR|RSTR)\t'))
print('  буферов снято:     %d' % g(r'BUF\t'))
print('  событий «прострелено»: %d' % g(r'EVENT\t'))
if auto:
    print('  заглушки глобалов: ' + ', '.join('%s (%s)' % (n, k) for n, k in auto[:8]))
PY
