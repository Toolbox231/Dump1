import json, os

payload_path = '/home/user/uploads/saladvisual_payload.lua.txt'
prelude_path = '/home/user/work/prelude.luau'
out_path = '/home/user/work/run.luau'
spans_path = '/home/user/work/mark_spans2.json'

src = open(payload_path, encoding='utf-8').read()
prelude = open(prelude_path, encoding='utf-8').read()
spans = [x for x in json.load(open(spans_path)) if x]

if os.environ.get('MARK', '1') == '1':
    events = []
    for i, (s0, e0) in enumerate(spans):
        events.append((s0, 0, i))
        events.append((e0, 1, i))
    events.sort(key=lambda x: (x[0], x[1]))
    out = []
    pos = 0
    for p0, kind, i in events:
        out.append(src[pos:p0])
        out.append('__MARKF(%d,' % i if kind == 0 else ')')
        pos = p0
    out.append(src[pos:])
    body = ''.join(out)
else:
    body = src

patched = body.replace('return setmetatable(', 'return __WRAP(', 1)
assert patched != body

cfg = {
    'trace_cap': int(os.environ.get('TRACE_CAP', 0)),
    'trace_mode': os.environ.get('TRACE_MODE', 'full'),
    'total_cap': int(os.environ.get('TOTAL_CAP', 80000000)),
    'skip': [x for x in os.environ.get('TRACE_SKIP', '').split(',') if x],
    'follow': [x for x in os.environ.get('TRACE_FOLLOW', '').split(',') if x],
}
autosrc = os.environ.get('DECSTR_LOG')
auto_names = []
if autosrc and os.path.exists(autosrc):
    import re as _re
    for line in open(autosrc, encoding='utf-8', errors='replace'):
        for tag in ('DECSTR', 'CHSTR', 'CCSTR', 'RSTR'):
            if line.startswith(tag + '\t'):
                parts = line.rstrip('\n').split('\t')
                if len(parts) >= 3:
                    try:
                        auto_names.append(json.loads(parts[2]))
                    except Exception:
                        pass
auto_names = [x for x in dict.fromkeys(auto_names) if isinstance(x, str) and 0 < len(x) < 64]
autolua = '{' + ','.join(json.dumps(x) for x in auto_names) + '}'
skip_lua = '{' + ','.join('"%s"' % x for x in cfg['skip']) + '}'
follow_lua = '{' + ','.join('"%s"' % x for x in cfg['follow']) + '}'

EPILOGUE = '''
local function __finish()
    print("EVENTS\\t" .. tostring(__TOTAL) .. "\\tLOGGED\\t" .. tostring(__LOG_LINES))
    print("FINALCUR\\t" .. tostring(__CUR) .. "\\tN\\t" .. tostring(__CN))
    local last = {}
    local n = math.min(__CN, 96)
    for i = 1, n do last[i] = tostring(__CLOG[((__CN - n + i) % 256) + 1]) end
    print("CLOG\\t" .. table.concat(last, ","))
    local okf, errf = pcall(__DUMP_FRING)
    if not okf then print("FRINGFAIL\t" .. tostring(errf)) end
    local okb, errb = pcall(__DUMP_BUFFERS)
    if not okb then print("BUFFAIL\\t" .. tostring(errb)) end
    local okd, errd = pcall(__DUMP_DYN)
    if not okd then print("DYNFAIL\\t" .. tostring(errd)) end
end
local __ok, __err = xpcall(__chunk, function(e)
    return tostring(e) .. "\\nCUR\\t" .. tostring(__CUR) .. "\\n" .. tostring(debug.traceback(nil, 2))
end)
print("STATUS\\t" .. tostring(__ok))
print("ERR\\t" .. tostring(__err))
pcall(__finish)
'''

parts = [
    '__CFG = {trace_cap=%d, trace_mode="%s", total_cap=%d, skip=%s, follow=%s}\n'
    % (cfg['trace_cap'], cfg['trace_mode'], cfg['total_cap'], skip_lua, follow_lua),
    prelude,
    '__AUTOGLOBALS = %s\n' % autolua,
    'if __CFG.follow and #__CFG.follow > 0 then __FOLLOW_ON = true for _, _k in ipairs(__CFG.follow) do __FOLLOW[_k] = true end end\n',
    '\n-- ================= payload (instrumented) =================\n',
    'local __chunk = function(...)\n',
    patched,
    '\nend\n',
    EPILOGUE,
]
open(out_path, 'w', encoding='utf-8').write(''.join(parts))
print('wrote', out_path, os.path.getsize(out_path))
