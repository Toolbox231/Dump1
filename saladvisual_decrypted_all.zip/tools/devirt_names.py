#!/usr/bin/env python3
"""Именование опкодов и сборка артефактов девиртуализации.

Вход:    devirt/opcodes.json (автоматически извлечённые обработчики, tools/devirt_ops.py)
Выход:   devirt/opcode_table.md     — таблица: опкод, имя, семантика, обработчик
         devirt/dispatch_readable.lua — тот же диспетчер, но сгруппированный по опкодам и подписанный
         devirt/FORMAT.md           — модель виртуальной машины (регистры, операнды, фреймы)

Имена присвоены по семантике обработчиков: уверенные — обычным шрифтом, сомнительные
помечены «?». Спец-операции (работа с апвалюями, хеш-декодеры, упаковка vararg)
названы описательно.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEV = os.path.join(ROOT, 'devirt')

# опкод -> (имя, примечание)
NAMES = {
    0:   ('RETURN', 'закрывает апвалюи (j/q) и возвращает c[P[O]]'),
    1:   ('JMPIF_NOTLT', 'O = (P[O] < c[T[O]]) and O or a[O] — условный переход'),
    2:   ('DECODE_RUN', 'расшифровывает пачку инструкций (T/P/a/z) и переписывает z[O]=118'),
    3:   ('CONCAT_K', 'c[T] = f[O] .. c[a[O]]'),
    4:   ('CALL_1_NORES', 'c[T](c[a])'),
    5:   ('MUL', 'c[T]=c[a]*c[P]'),
    6:   ('DECODE_RUN_B', 'хеш-декодер пачки инструкций (вариант B)'),
    7:   ('DIV_K', 'c[P]=c[a]/l[O]'),
    8:   ('GT_IMM', 'c[a]=c[P]>T[O]'),
    9:   ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    10:  ('BITOP_AND', 'c[a]=h(c[T],c[P]) — побитовая операция'),
    11:  ('LE', 'c[a]=c[T]<=c[P]'),
    12:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    13:  ('NE_IMM', 'c[T]=y[O]~=c[P]'),
    14:  ('SETUPVAL_T', 'запись в апвалюй: A[T][4][6][c[P]]=c[a]'),
    15:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    16:  ('CLOSE_LOCALS', 'закрытие апвалюев при выходе из блока'),
    17:  ('DIV', 'c[P]=c[a]/c[T]'),
    18:  ('GT', 'c[a]=c[T]>c[P]'),
    19:  ('TOINT', 'приведение числа к целому (маска 2^32)'),
    20:  ('SUB', 'c[a]=c[T]-c[P]'),
    21:  ('LOAD_K', 'c[a]=K (специальный регистр)'),
    22:  ('DECODE_RUN_C', 'хеш-декодер пачки инструкций (вариант C, через K)'),
    23:  ('LT_IMM', 'c[T]=c[a]<P[O]'),
    24:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    25:  ('CALL_K_1', 'c[P]=E(c[T](y[O])) — вызов с константой, 1 результат'),
    26:  ('ADD_K', 'c[T]=c[P]+y[O]'),
    27:  ('FORLOOP', 'шаг числового for; c[a]=J, O=P[O]'),
    28:  ('LT', 'c[T]=c[a]<c[P]'),
    29:  ('SETTABLE_OFF', 'c[P[O]+c[a]]=c[T]'),
    30:  ('BITXOR_K', 'c[P]=W(c[T],y[O]) — побитовая операция с константой'),
    31:  ('JMPNE_IMM', 'O = (c[P]~=l[O]) and a[O] or O'),
    32:  ('BITOP_BATCH', 'пакетная побитовая операция по диапазону (Q = индекс)'),
    33:  ('LOOP_BREAK', 'выход из пакетной операции (B=a[Q]; O=P[Q]+1; break)'),
    34:  ('SETUPVAL_TAB', 'A[P][l[O]]=c[a]'),
    35:  ('SETFIELD_IMM', 'c[a][f[O]]=T[O]'),
    36:  ('ADD_K2', 'c[a]=f[O]+c[T]'),
    37:  ('LE_K', 'c[T]=c[a]<=f[O]'),
    38:  ('GETUPVAL_FIELD', 'c[T]=A[P][4][6] — чтение апвалюя'),
    39:  ('CALL_K_ARG', 'c[P]=c[a](l[O])'),
    40:  ('HASH_BLOCK_A', 'хеш-блок (смешивание 32-битных полей)'),
    41:  ('CONCAT_K2', 'c[P]=c[a]..l[O]'),
    42:  ('SETTABLE_IMM_KEY', 'c[T][a[O]]=c[P]'),
    43:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    44:  ('MUL_K', 'c[T]=a[O]*c[P]'),
    45:  ('MOD_K', 'c[T]=c[P]%y[O]'),
    46:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    47:  ('JMPEQ_IMM', 'O = (c[a]==T[O]) and P[O] or O'),
    48:  ('HASH_BLOCK_B', 'хеш-блок (вариант)'),
    49:  ('MOVE', 'c[P]=c[a]'),
    50:  ('LEN', 'c[T]=#c[P]'),
    51:  ('GE', 'c[a]=c[P]>=c[T]'),
    52:  ('SETTABLE_K', 'c[a][c[P]]=l[O]'),
    53:  ('GETUPVAL_IDX', 'c[T]=A[P][4][6][c[a]]'),
    54:  ('LE_K2', 'c[P]=c[T]<=a[O]'),
    55:  ('GETTABLE', 'c[T]=c[P][a[O]]'),
    56:  ('POW', 'c[T]=P[O]^c[a]'),
    57:  ('JMPLE', 'O = (c[P]<=c[T]) and O or a[O]'),
    58:  ('UNM', 'c[T]=-c[a]'),
    59:  ('HASH_UPVAL', 'хеш-получение через апвалюй (декодер константы)'),
    60:  ('LOAD_TRIPLE', 'c[a]=n; c[a+1]=a; c[P+2]=z; O+=2 — загрузка внутренних таблиц VM'),
    61:  ('FORPREP', 'подготовка числового for'),
    62:  ('EQ', 'c[a]=c[P]==c[T]'),
    63:  ('BITSHIFT_A', 'c[P]=v(c[a],c[T]) — сдвиг'),
    64:  ('SETFIELD_K', 'c[P][l[O]]=y[O]'),
    65:  ('CALL_K_CONST', 'c[P](c[T],y[O])'),
    66:  ('JMPIF', 'O = c[a] and T[O] or P[O]'),
    67:  ('LOAD_S', 'c[T]=s (служебная таблица)'),
    68:  ('VARARG_MOVE', 'перепаковка регистров (vararg/аргументы)'),
    69:  ('JMPLT_IMM', 'O = (T[O]<c[P]) and a[O] or O'),
    70:  ('GETTABLE_REG', 'c[T]=c[P][c[a]]'),
    71:  ('CLEAR_RANGE', 'обнуление диапазона регистров'),
    72:  ('VARARG_SHIFT', 'сдвиг регистров/vararg'),
    73:  ('CALL_SPREAD', 'c[a](l[O], распакованный c[P])'),
    74:  ('BITOP_AND_K', 'c[T]=W(y[O],c[P])'),
    75:  ('SETTABLE_IMM_VAL', 'c[T][c[a]]=P[O]'),
    76:  ('SETUPVAL_RAW', 'A[a][4][6]=l[O]'),
    77:  ('CALL_MULTI', 'вызов с несколькими результатами (pcall-подобный)'),
    78:  ('GT_K', 'c[a]=c[T]>f[O]'),
    79:  ('SETUPVAL_TAB2', 'A[T][c[P]]=y[O]'),
    80:  ('SETUPVAL_TAB3', 'A[a][f[O]]=l[O]'),
    81:  ('EQ_IMM', 'c[a]=c[P]==T[O]'),
    82:  ('GETGLOBAL', 'c[T]=u[y[O]] — чтение глобала из окружения'),
    83:  ('GETTABUP', 'c[P]=A[a][l[O]]'),
    84:  ('JMPIFNOT', 'O = (not c[T]) and a[O] or P[O]'),
    85:  ('BITSHIFT_B', 'c[a]=v(f[O],c[T])'),
    86:  ('MOD', 'c[P]=c[a]%c[T]'),
    87:  ('MUL_K2', 'c[T]=c[a]*f[O]'),
    88:  ('SETFIELD', 'c[T][f[O]]=c[a]'),
    89:  ('LOAD_S2', 'c[a]=s[T[O]]'),
    90:  ('VARARG_TABLE', 'упаковка/сдвиг таблицы аргументов'),
    91:  ('ADD', 'c[T]=c[P]+c[a]'),
    92:  ('CALL_K_2', 'c[a](l[O],f[O])'),
    93:  ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    94:  ('CALL_FRAME', 'вызов с сохранением кадра (e/G/J/D) — вход в Lua-функцию'),
    95:  ('SETTABLE_K2', 'c[a][P[O]]=l[O]'),
    96:  ('SETTABLE', 'c[P][c[a]]=c[T]'),
    97:  ('ADD_IMM', 'c[a]=c[P]+T[O]'),
    98:  ('CALL_VARARG', 'вызов с упаковкой vararg'),
    99:  ('HASH_UPVAL2', 'хеш-получение через апвалюй (вариант)'),
    100: ('DIV_K2', 'c[P]=c[T]/a[O]'),
    101: ('CALL_SHIFT', 'вызов со сдвигом результатов'),
    102: ('CALL_0_NORES', 'c[T]()'),
    103: ('ADD_IMM2', 'c[a]=f[O]+l[O]'),
    104: ('CALL_1', 'c[a]=E(c[P](c[T]))'),
    105: ('HASH_UPVAL3', 'хеш-получение (вариант с масками <16384/<2097152)'),
    106: ('FORPREP2', 'подготовка for (вариант)'),
    107: ('MOVE_TRIPLE', 'c[T..T+3]=P[O..O+3]; O+=3'),
    108: ('BITAND_2', 'c[a]=h(f[O],c[T])'),
    109: ('JMP_REG', 'O=c[a] — косвенный переход'),
    110: ('BITXOR_KK', 'c[T]=W(f[O],y[O]) — свёртка двух констант'),
    111: ('CALL_SPREAD2', 'c[P](распакованный c[a])'),
    112: ('SPLIT3', 'спец-операция: разбор строки/таблицы по 3 поля'),
    113: ('JMPLE_REG', 'O = (T[O]<=c[a]) and P[O] or O'),
    114: ('GETTABUP2', 'c[T]=A[P][a[O]]'),
    115: ('IDIV', 'c[T]=c[P]//a[O]'),
    116: ('LOAD_K2', 'K=c[a] — запись в спец-регистр'),
    117: ('BITSHIFT_C', 'c[P]=W(c[T],a[O])'),
    # 118 создаётся в рантайме (см. NAMES_EXTRA/примечание)
    119: ('NOT', 'c[a]=not c[T]'),
    120: ('CALL_SPREAD3', 'c[a]=E(c[P](распакованный c[T]))'),
    121: ('CONCAT', 'c[a]=c[T]..c[P]'),
    122: ('NE', 'c[a]=c[T]~=c[P]'),
    123: ('CALL_1_R', 'c[T]=c[P](c[a])'),
    124: ('LOAD_N', 'c[a]=n — загрузка внутреннего значения VM'),
    125: ('SET_S', 's[y[O]]=f[O]'),
    126: ('LOAD_Z', 'c[P]=z — загрузка массива опкодов'),
    127: ('SUB_K', 'c[a]=c[P]-l[O]'),
    128: ('SLICE_VARARG', 'c[P]=E(c[T][a[O]..n]) — срез vararg'),
    129: ('LOAD_REGS', 'c[P]=c — загрузка файла регистров'),
    130: ('SETTABUP', 'A[P][4][6][c[T]]=y[O]'),
    131: ('SET_S2', 's[P[O]]=c[a]'),
    132: ('BITSHIFT_D', 'c[P]=v(T[O],c[a])'),
    133: ('FORPREP3', 'подготовка for (вариант)'),
    134: ('JMPEQ', 'O = (c[T]==c[P]) and a[O] or O'),
    135: ('LT_K', 'c[a]=c[P]<l[O]'),
    136: ('GETTABLE_K', 'c[T]=c[P][y[O]]'),
    137: ('JMPLE_IMM2', 'O = (c[T]<=a[O]) and P[O] or O'),
    138: ('GET_S', 'c[T]=s[f[O]]'),
    139: ('SETUPVAL_TAB4', 'A[T][y[O]]=P[O]'),
    140: ('FRAME_RESTORE', 'восстановление кадра (J,G,e,D) — возврат из вызова'),
    141: ('PREP_CALL', 'c[a+1]=c[P]; c[a]=c[P][l[O]] — метод-вызов'),
    142: ('CALL_SPREAD4', 'c[a]=E(c[a](распакованные))'),
    143: ('NE_K', 'c[P]=c[T]~=a[O]'),
    144: ('JMPLT_IMM2', 'O = (c[a]<f[O]) and T[O] or O'),
    145: ('JMPLT_IMM3', 'O = (c[P]<T[O]) and a[O] or O'),
    146: ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    147: ('SETTABUP2', 'A[a][c[T]]=c[P]'),
    148: ('BITAND_3', 'c[a]=h(T[O],c[P])'),
    149: ('LOAD_A', 'c[a]=a — загрузка массива операндов'),
    150: ('VARARG_PACK', 'упаковка {...} в регистры'),
    151: ('BITSHIFT_E', 'c[T]=k(c[P],a[O])'),
    152: ('MUL_K3', 'c[a]=f[O]*c[T]'),
    153: ('JMP', 'O=T[O] — прямой переход'),
    154: ('JMPNE', 'O = (c[P]~=c[T]) and a[O] or O'),
    155: ('SET_P', 'p=c[a] — запись в спец-регистр p'),
    156: ('EQ_K', 'c[P]=l[O]==c[a]'),
    157: ('SETTABUP3', 'A[a][4][6][f[O]]=c[T]'),
    158: ('GETTABUP3', 'c[P]=A[a][4][6][l[O]]'),
    159: ('BITSHIFT_F', 'c[a]=F(c[T],P[O])'),
    160: ('GETIMPORT', 'c[T]=u[y[O]][f[O]] — глобал с полем (u=окружение) [подтверждено: падение nil.new]'),
    161: ('MOD_K2', 'c[T]=c[P]%a[O]'),
    162: ('CALL_2', 'c[T](c[a],c[P])'),
    163: ('GETUPVAL', 'c[a]=A[P] — чтение апвалюя'),
    164: ('JMPLE_IMM3', 'O = (c[a]<=T[O]) and P[O] or O'),
    165: ('HASH_UPVAL4', 'хеш-получение через апвалюй (вариант)'),
    166: ('EQ_K2', 'c[P]=c[a]==l[O]'),
    167: ('LOAD_P', 'c[P]=p'),
    168: ('LOAD_T', 'c[T]=T — загрузка массива T'),
    169: ('GETUPVAL_FIELD2', 'c[a]=A[P][c[T]]'),
    170: ('SUB_IMM', 'c[a]=T[O]-c[P]'),
    171: ('JMPLT_REG_ALT', '(if c[a]<c[P] then T[O] else O)'),
    172: ('JMPLT_REG', '(if not (c[T]<c[a]) then P[O] else O)'),
    173: ('HASH_BLOCK_C', 'хеш-блок (вариант)'),
    174: ('JMP_INDIRECT', 'O=c[P] — косвенный переход'),
    175: ('BITOP_C', 'c[a]=W(c[P],c[T])'),
    176: ('SUB_K2', 'c[P]=c[T]-a[O]'),
    177: ('BITSHIFT_G', 'c[P]=v(c[a],l[O])'),
    178: ('NE_K2', 'c[P]=c[T]~=y[O]'),
    179: ('IDIV_REG', 'c[a]=c[T]//c[P]'),
    180: ('CLOSE_UPVALS', 'закрытие открытых апвалюев (вариант)'),
    181: ('GET_W', 'c[P]=w(a[O]) — получение апвалюя/замыкания'),
    182: ('CALL_2_R', 'c[T],c[P]=c[a]() — вызов, 2 результата'),
    183: ('JMPNE_IMM2', 'O = (c[a]~=P[O]) and T[O] or O'),
    184: ('GE_K', 'c[T]=c[P]>=a[O]'),
    185: ('MUL_K4', 'c[P]=c[a]*T[O]'),
    186: ('SETTABLE_IMM2', 'c[a][T[O]]=P[O]'),
    187: ('CALL_K_3', 'c[T](f[O],c[a])'),
    188: ('CALL_SPREAD5', 'c[T](c[a], распакованный c[P])'),
    189: ('SETTABUP4', 'A[a][4][6]=c[P]'),
    190: ('TOINT2', 'c[T]=U(c[P]) — приведение числа'),
    191: ('CALL_1_K', 'c[T](y[O])'),
    192: ('TABLE_SHIFT', 'сдвиг элементов таблицы (vararg)'),
    193: ('JMPLT_IMM4', 'O = (c[P]<T[O]) and a[O] or O'),
    194: ('LOAD_P2', 'c[T]=P[O]'),
    195: ('NEWTABLE', 'c[T]={}'),
    196: ('ADD_IMM3', 'c[T]=a[O]+c[P]'),
    197: ('FRAME_RESTORE2', 'восстановление кадра (вариант)'),
    198: ('BITAND_4', 'c[a]=h(c[P],l[O])'),
    199: ('BITSHIFT_H', 'c[P]=W(a[O],c[T])'),
    200: ('CALL_SPREAD6', 'c[P]=c[T](распакованный c[a])'),
    201: ('LOAD_Y', 'c[P]=y[O]'),
    202: ('JMPEQ_IMM2', 'O = (c[T]==f[O]) and a[O] or O'),
    203: ('LOAD_P3', 'c[T]=P — загрузка массива P'),
    204: ('CALL_204', 'c[P]=E(c[T]()) — вызов, результат через E'),
    205: ('CALL_0', 'c[P]=c[a]() — вызов без аргументов'),
}

EXTRA = {
    '118': ('DECODE_SLOT', 'опкод СОЗДАЁТСЯ в рантайме: обработчики 2/6/22 переписывают '
                           'текущую инструкцию в z[O]=118 с операндами (T=55,P=57,a=120) — '
                           'самомодифицирующийся байткод; в дереве диспетчера ветви для 118 нет'),
}


def lua_ok(code, cli=None):
    """Проверяет, что фрагмент — самостоятельный оператор Luau (не выражение/обрывок)."""
    import subprocess
    cli = cli or os.environ.get('LUAU', '/home/user/work/luau2/build/release/luau')
    if not os.path.exists(cli):
        return True
    chunk = 'local c,u,s,p,n,K,z,T,P,a,y,f,l,O,j,q,t,A,E,i,I,v,V,W,F,k,h,U,w,e,G,J,d,D,B,Q,r,m,S,Y,I2,N=({})()\n' \
            'local f0 = function()\n%s\nend\n' % (code if code.rstrip().endswith('end') or ';' in code else code)
    src = 'local scene = nil\n' + 'local f = function()\n' + code + '\nend\n'
    lvl = ''
    while ('[%s[' % lvl) in src or (']%s]' % lvl) in src:
        lvl += '='
    open('/tmp/_h.luau', 'w', encoding='utf-8').write(
        'local src=[%s[\n%s\n]%s]\nlocal f,e=(loadstring or load)(src)\n'
        'print(f and "OK" or ("FAIL"))\n' % (lvl, src, lvl))
    r = subprocess.run([cli, '/tmp/_h.luau'], capture_output=True)
    return r.stdout.decode(errors='replace').startswith('OK')


def clean(code):
    c = re.sub(r'[ \t]+', ' ', code)
    c = re.sub(r'\n\s*', ' ', c).strip()
    return re.sub(r'\s*;?\s*$', '', c)


def main():
    ops = json.load(open(os.path.join(DEV, 'opcodes.json'), encoding='utf-8'))
    # для 0..3 берём обработчик из ГЛАВНОЙ лестницы (в файле есть замыкания с локальной M,
    # из-за которых в автоизвлечение попадали лишние кандидаты) — источники указаны вручную
    manual = {
        '0': 'if j then for Q in t,j,nil do if j then local lP=j[Q];if lP then lP[4]=lP;lP[5]=c[Q];lP[6]=5;j[Q]=nil;end;end;end;end;if q then for Q,lP in t,q,nil do local LP=lP[5];if q then lP=q[Q];if lP then local yP=w(LP);I(c,Q,Q+LP-1,1,yP);lP[4]=yP;lP[6]=1;q[Q]=nil;end;end;end;end;return c[P[O]];',
        '1': 'O=if not(P[O]<c[T[O]])then a[O]else O;',
        '2': 'Z,C=T[O],a[O]+1;for Q=1,P[O],1 do Z=h(W(Z,(k(Z,13))),536870911);Z=W(Z,(F(Z,13)));Z=h(W(Z,(k(Z,14))),536870911);T[C]=W(T[C],(h(F(Z,0),127)));P[C]=W(P[C],(h(F(Z,7),127)));a[C]=W(a[C],(h(F(Z,14),127)));z[C]=W(z[C],(h(F(Z,21),127)));C=C+1;end;z[O]=118;',
        '3': 'c[T[O]]=f[O]..c[a[O]];',
    }
    for k, code in manual.items():
        ops.setdefault(k, [])
        ops[k] = [code]

    rows = []
    for k in sorted(ops, key=lambda x: int(x)):
        name, note = NAMES.get(int(k), EXTRA.get(k, ('?', '')))
        code = clean(ops[k][0]) if ops[k] else ''
        rows.append((int(k), name, note, code))

    with open(os.path.join(DEV, 'opcode_table.md'), 'w', encoding='utf-8') as f:
        f.write('# Таблица опкодов внутреннего интерпретатора (девиртуализация)\n\n')
        f.write('Извлечено из дерева диспетчера (`if M<103 then …`) среза `3128823..3202193`\n'
                'артефакта; скрипты: `tools/devirt_ops.py` (разбор дерева) + `tools/devirt_names.py`\n'
                '(имена и семантика). Имена — вывод из кода обработчиков; сомнительные помечены «?»\n'
                'в колонке «примечание».\n\n')
        f.write('| опкод | имя | код обработчика | примечание |\n|---|---|---|---|\n')
        for k, name, note, code in rows:
            c = code.replace('|', '\\|')
            if len(c) > 150:
                c = c[:147] + '…'
            f.write('| %d | `%s` | `%s` | %s |\n' % (k, name, c, note))
        f.write('\nВсего опкодов: **%d** (из них %d с уверенной семантикой).\n'
                % (len(rows), sum(1 for r in rows if '?' not in r[1])))

    with open(os.path.join(DEV, 'dispatch_readable.lua'), 'w', encoding='utf-8') as f:
        f.write('-- ============================================================================\n'
                '-- Читаемый диспетчер опкодов внутреннего интерпретатора payload\'а (Luraph v15.1)\n'
                '-- Сгенерировано tools/devirt_names.py из дерева `if M<103 then …`\n'
                '-- (срез 3128823..3202193 артефакта = state_machines/4132_2.lua)\n'
                '--\n'
                '-- OPS[n] — обработчик опкода n. Переменные: c — регистры, O — счётчик команд,\n'
                '-- z[O] — опкод, T/P/a/y/f/l — слоты операндов, u — окружение (глобалы),\n'
                '-- A — апвалюи, j/q/t — учёт открытых апвалюев, s/p/n/K — служебные значения VM.\n'
                '-- Подробнее — devirt/FORMAT.md.\n'
                '-- ============================================================================\n\n'
                'local OPS = {}\n\n')
        skipped = 0
        for k, name, note, code in rows:
            body = re.sub(r';\s*', ';\n  ', code)
            if lua_ok(body):
                f.write('-- [%d] %s%s\n' % (k, name, (' — ' + note) if note else ''))
                f.write('OPS[%d] = function()\n  %s\nend\n\n' % (k, body))
            else:
                # фрагмент (выражение/обрывок пакетной операции) — цитируем как есть
                skipped += 1
                f.write('-- [%d] %s%s\n' % (k, name, (' — ' + note) if note else ''))
                f.write('--   (фрагмент, не самостоятельный оператор)\n')
                f.write('--   %s\n\n' % body.replace('\n', '\n--   '))
        f.write('return OPS\n')
    print('опкодов в таблице: %d (фрагментов: %d)' % (len(rows), skipped))
    print('-> devirt/opcode_table.md')
    print('-> devirt/dispatch_readable.lua')
    return 0


if __name__ == '__main__':
    sys.exit(main())
