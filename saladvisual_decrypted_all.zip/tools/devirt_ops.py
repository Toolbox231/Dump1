#!/usr/bin/env python3
"""Девиртуализация внутреннего интерпретатора payload'а: дерево опкодов.

Интерпретатор (срез 3128823..3202193 артефакта, `state_machines/4132_2.lua`) —
бинарное дерево сравнений по переменной-опкоду `M`. Скрипт берёт AST Luau
(luau-ast) и обходит `AstStatIf`, накапливая для каждой ветви множество
возможных значений M; листья дерева — обработчики опкодов.

Выход:
  devirt/opcodes.json    — опкод -> код обработчика
  devirt/opcodes_raw.txt — то же человекочитаемо
  devirt/opcode_table.md — сводная таблица (заполняется отдельно, см. README §13)

Запуск:
    /tmp/luau-ast interp.luau > interp_ast.json     # AST среза интерпретатора
    python3 tools/devirt_ops.py
"""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARTIFACT = '/home/user/uploads/saladvisual_payload.lua.txt'
SPAN = (3128823, 3202193)
LUAU_AST = os.environ.get('LUAU_AST', '/tmp/luau-ast')


class Src:
    def __init__(self, text):
        self.text = text
        self.base = [0]
        for line in text.split('\n'):
            self.base.append(self.base[-1] + len(line) + 1)

    def off(self, loc):
        l, c = map(int, loc.split(','))
        return self.base[l] + c

    def span(self, node):
        a, b = node['location'].split(' - ')
        return self.off(a), self.off(b)

    def txt(self, node):
        a, b = self.span(node)
        return self.text[a:b]


def cond_interval(text):
    """Множество значений M по тексту условия (пересечение всех сравнений с M)."""
    vals = set(range(-20, 600))
    for m in re.finditer(r'\bM\s*(<=|<|>=|>|==|~=)\s*(\d+)', text):
        op, n = m.group(1), int(m.group(2))
        if op == '<':
            vals &= {v for v in vals if v < n}
        elif op == '<=':
            vals &= {v for v in vals if v <= n}
        elif op == '>':
            vals &= {v for v in vals if v > n}
        elif op == '>=':
            vals &= {v for v in vals if v >= n}
        elif op == '==':
            vals &= {n} if n in vals else set()
        elif op == '~=':
            vals &= {v for v in vals if v != n}
    return vals


def mentions_m(text):
    return re.search(r'\bM\b(?!\s*[:,])', text) is not None


def walk(node, src, universe, out, depth=0, fn_depth=0):
    """Рекурсивный обход AST: узлы AstStatIf с условием по M разбираем по диапазонам,
    всё остальное обходим как есть (ищем такие узлы в любых вложенных конструкциях)."""
    if isinstance(node, list):
        for x in node:
            walk(x, src, universe, out, depth, fn_depth)
        return
    if not isinstance(node, dict):
        return
    t = node.get('type')
    if t in ('AstExprFunction', 'AstStatFunction', 'AstStatLocalFunction'):
        # ВАЖНО: внутрь ВЛОЖЕННЫХ функций не спускаемся — там есть свои локальные
        # с той же буквой M (замыкания мини-VM апвалюев), их сравнения попадали бы
        # в дерево диспетчера. Сама функция интерпретатора — уровень 0, её разбираем.
        if fn_depth >= 1:
            return
        for k, v in node.items():
            if k != 'location':
                walk(v, src, universe, out, depth, fn_depth + 1)
        return
    if t == 'AstExprIfElse':
        # Luau-if-выражение (`O = if cond then a else b`) — в дереве диспетчера такие
        # ветви тоже встречаются (`if M>=171 then O=if M==172 then ... else ...`).
        ctext = src.txt(node['condition'])
        if mentions_m(ctext):
            ci = cond_interval(ctext)
            for key, uni in (('trueExpr', universe & ci), ('falseExpr', universe - ci)):
                sub = node.get(key)
                if isinstance(sub, dict):
                    out.append((frozenset(uni), src.span(sub)))
            return
    if t == 'AstStatIf':
        ctext = src.txt(node['condition'])
        if mentions_m(ctext):
            ci = cond_interval(ctext)
            walk_body(node.get('thenbody'), src, universe & ci, out, depth + 1, fn_depth)
            eb = node.get('elsebody')
            if isinstance(eb, dict) and eb.get('type') == 'AstStatIf':
                walk(eb, src, universe - ci, out, depth, fn_depth)      # `else if` — тот же остаток
            elif isinstance(eb, dict):
                walk_body(eb, src, universe - ci, out, depth + 1, fn_depth)
            return
    for k, v in node.items():
        if k == 'location' or isinstance(v, (str, int, float, bool)) or v is None:
            continue
        walk(v, src, universe, out, depth)


def has_m_ifexpr(node, src):
    """Есть ли внутри узла if-ВЫРАЖЕНИЕ по M (такие ветви тоже часть диспетчера)."""
    if isinstance(node, list):
        return any(has_m_ifexpr(x, src) for x in node)
    if not isinstance(node, dict):
        return False
    if node.get('type') == 'AstExprIfElse' and mentions_m(src.txt(node['condition'])):
        return True
    return any(has_m_ifexpr(v, src) for k, v in node.items()
               if k != 'location' and not isinstance(v, (str, int, float, bool)) and v is not None)


def walk_body(body, src, universe, out, depth, fn_depth=0):
    """Тело ветви: если внутри снова ветвление по M — идём глубже, иначе это лист-обработчик."""
    if not isinstance(body, dict):
        return
    stmts = [s for s in (body.get('body') or []) if isinstance(s, dict)]
    inner = [s for s in stmts if s.get('type') == 'AstStatIf'
             and mentions_m(src.txt(s['condition']))]
    if not inner and has_m_ifexpr(stmts, src):
        # ветвление спрятано в if-выражении — спускаемся по операторам дальше
        for s in stmts:
            walk(s, src, universe, out, depth, fn_depth)
        return
    if not inner:
        a, b = src.span(body)
        out.append((frozenset(universe), (a, b)))
        return
    for s in stmts:
        if s in inner:
            walk(s, src, universe, out, depth, fn_depth)
        else:
            a, b = src.span(s)
            out.append((frozenset(universe), (a, b)))


def main():
    text = open(ARTIFACT, encoding='utf-8').read()
    seg = text[SPAN[0]:SPAN[1]]
    open('/tmp/interp.luau', 'w', encoding='utf-8').write('local f0 =\n' + seg + '\n')
    ast_path = '/tmp/interp_ast.json'
    r = subprocess.run([LUAU_AST, '/tmp/interp.luau'], capture_output=True)
    open(ast_path, 'wb').write(r.stdout)
    root = json.load(open(ast_path))['root']

    # ВАЖНО: офсеты AST — это координаты «строка,колонка» в обёрнутом файле
    # (`local f0 =\n<срез>`), поэтому Src строится по обёртке, а не по срезу.
    src = Src(open('/tmp/interp.luau', encoding='utf-8').read())
    out = []
    walk(root, src, set(range(-20, 600)), out)
    print('листьев:', len(out))

    ops = {}
    used = 0
    for vals, (a, b) in out:
        code = src.text[a:b].strip()
        if not code or code in ('end', ';'):
            continue
        # Лист-обработчик — это ветвь, где M уже определён точно (1..2 значения).
        # Широкие множества — это куски кода вне дерева диспетчера, их не берём.
        if len(vals) != 1:
            continue
        used += 1
        for v in vals:
            ops.setdefault(v, []).append(code)
    print('листьев-обработчиков (узкие ветви):', used)
    os.makedirs(os.path.join(ROOT, 'devirt'), exist_ok=True)
    json.dump({str(k): v for k, v in sorted(ops.items())},
              open(os.path.join(ROOT, 'devirt', 'opcodes.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    with open(os.path.join(ROOT, 'devirt', 'opcodes_raw.txt'), 'w', encoding='utf-8') as f:
        for k in sorted(ops):
            f.write('===== OPCODE %s =====\n' % k)
            for c in ops[k]:
                f.write(c + '\n\n')
    print('опкодов сопоставлено:', len(ops))
    if ops:
        print('диапазон:', min(ops), '..', max(ops))
        print('с несколькими обработчиками:', sum(1 for v in ops.values() if len(v) > 1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
