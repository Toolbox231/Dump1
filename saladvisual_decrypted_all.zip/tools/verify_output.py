#!/usr/bin/env python3
"""Проверка корректности восстановленного кода (payload/, state_machines/, by_entry/).

Два независимых теста для каждого файла:

1. ДРЕЙФ ТОКЕНОВ. Содержимое файла — это размеченный (отформатированный) срез
   исходного артефакта; офсеты записаны в шапке файла (`-- offset A..B`).
   Лексер сравнивает мультимножество токенов среза-источника и вывода.
   Любая потеря/добавление токена (например, выпавший `do ... end`) = ошибка.
   Так был найден баг форматтера: 17 файлов теряли блоки `do ... end`
   (в AST Luau это AstStatBlock с hasEnd=true), из-за чего локальные переменные
   «вылезали» в общую область и Luau выдавал
   `Out of local registers ... exceeded limit 200`.

2. ПАРСИНГ Luau. Каждый файл прогоняется через штатный парсер Luau
   (`loadstring`), т.е. проверяется, что восстановленный код — валидный Luau.

Запуск:
    python3 tools/verify_output.py [--root ..] [--luau /path/to/luau]
"""
import argparse, collections, glob, os, re, subprocess, sys

ANN = re.compile(r'--\[\[[^\]]*\]\]')

def strip_comments_and_strings(s):
    s = re.sub(r'--\[\[.*?\]\]', '', s, flags=re.S)
    s = re.sub(r'--[^\n]*', '', s)
    s = re.sub(r'\[\[.*?\]\]', '"S"', s, flags=re.S)
    s = re.sub(r'"[^"\n]*"', '"S"', s)
    s = re.sub(r"'[^'\n]*'", "'S'", s)
    return s

def tokens(s):
    return re.findall(r'[a-zA-Z_]\w*|\d+', strip_comments_and_strings(s))

def body_of(path):
    lines = ANN.sub('', open(path, encoding='utf-8').read()).split('\n')
    i = 0
    while i < len(lines) and (lines[i].startswith('--') or lines[i].strip() == ''):
        i += 1
    return '\n'.join(lines[i:])

def wrap_chunk(src):
    lvl = ''
    while ('[%s[' % lvl) in src or (']%s]' % lvl) in src:
        lvl += '='
    return ('local src=[%s[\n%s\n]%s]\n'
            'local f,e=(loadstring or load)(src)\n'
            'print(f and "OK" or ("FAIL "..tostring(e)))\n') % (lvl, src, lvl)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    ap.add_argument('--artifact', default='/home/user/uploads/saladvisual_payload.lua.txt')
    ap.add_argument('--luau', default='/home/user/work/luau2/build/release/luau')
    ap.add_argument('--no-parse', action='store_true', help='только аудит токенов')
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    files = []
    for sub in ('payload', 'state_machines', 'by_entry'):
        files += sorted(glob.glob(os.path.join(root, sub, '*.lua')))

    src_artifact = open(args.artifact, encoding='utf-8').read()
    drift, checked = [], 0
    for p in files:
        txt = open(p, encoding='utf-8').read()
        m = re.search(r'-- offset (\d+)\.\.(\d+) ', txt)
        if not m:
            continue
        a, b = int(m.group(1)), int(m.group(2))
        tr = collections.Counter(tokens(src_artifact[a:b]))
        tf = collections.Counter(tokens(body_of(p)))
        d = {k: tf.get(k, 0) - tr.get(k, 0) for k in set(tr) | set(tf) if tf.get(k, 0) != tr.get(k, 0)}
        checked += 1
        if d:
            drift.append((p, d))
    print('ДРЕЙФ ТОКЕНОВ: проверено файлов с офсетом %d, расхождений %d' % (checked, len(drift)))
    for p, d in drift[:10]:
        print('   ', p, dict(list(d.items())[:6]))
    if drift:
        print('   (by_entry-файлы — склейки нескольких функций, у них нет офсета в шапке;')
        print('    их корректность покрывается проверкой парсинга)')

    rc = 1 if drift else 0
    if args.no_parse:
        return rc

    ok, bad = 0, []
    for p in files:
        b = body_of(p).lstrip()
        chunk = ('local f0 = %s\nreturn f0\n' % b) if b.startswith('function') else b
        open('/tmp/_verify_chunk.luau', 'w', encoding='utf-8').write(wrap_chunk(chunk))
        r = subprocess.run([args.luau, '/tmp/_verify_chunk.luau'], capture_output=True, timeout=300)
        out = r.stdout.decode(errors='replace')
        if out.startswith('OK'):
            ok += 1
        else:
            bad.append((p, out.strip()[:120]))
    print('ПАРСИНГ Luau: файлов %d | OK %d | ошибок %d' % (len(files), ok, len(bad)))

    # единый расшифрованный файл (tools/build_decrypted.py)
    dec = os.path.join(root, 'saladvisual_decrypted.lua')
    if os.path.exists(dec):
        src = open(dec, encoding='utf-8').read()
        lvl = ''
        while ('[%s[' % lvl) in src or (']%s]' % lvl) in src:
            lvl += '='
        open('/tmp/_verify_dec.luau', 'w', encoding='utf-8').write(
            'local src=[%s[\n%s\n]%s]\nlocal f,e=(loadstring or load)(src)\n'
            'print(f and "PARSE OK" or ("FAIL "..tostring(e)))\n' % (lvl, src, lvl))
        r = subprocess.run([args.luau, '/tmp/_verify_dec.luau'], capture_output=True, timeout=600)
        o = r.stdout.decode(errors='replace')
        good = o.startswith('PARSE OK')
        print('СБОРНЫЙ ФАЙЛ saladvisual_decrypted.lua: %s (%.1f МБ, функций %d)'
              % ('OK' if good else 'ОШИБКА: ' + o.strip()[:120],
                 len(src) / 1048576.0, src.count('F["')))
        if not good:
            bad.append(('saladvisual_decrypted.lua', o.strip()[:120]))
    for p, e in bad[:10]:
        print('   ', p, '|', e)
    return rc or (1 if bad else 0)

def devirt_artifacts():
    """Наличие и базовая целостность артефактов девиртуализации."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, 'devirt')
    checks = [('opcode_table.md', 204), ('opcodes.json', 204), ('dispatch_readable.lua', 200),
              ('FORMAT.md', 10), ('mod_listing.txt', 100), ('mod_listing_singlerun.txt', 100)]
    bad = []
    for name, min_items in checks:
        f = os.path.join(d, name)
        n = 0
        if os.path.exists(f):
            txt = open(f, encoding='utf-8', errors='replace').read()
            n = txt.count('\n')
            if name.endswith('.md') and name.startswith('opcode'):
                n = txt.count('|')  # грубая мера: строки таблицы
            if n < min_items:
                bad.append('%s: мало содержимого (%d)' % (name, n))
            if name.startswith('mod_listing') and '::L' not in txt:
                bad.append('%s: нет меток ::L' % name)
        else:
            bad.append('%s: нет файла' % name)
    # запускаемый файл и расшифрованный образ: наличие + разбор Luau
    import subprocess as _sp
    run_f = os.path.join(root, 'saladvisual_run.luau')
    if not os.path.exists(run_f):
        bad.append('saladvisual_run.luau: нет файла')
    else:
        src = open(run_f, encoding='utf-8', errors='replace').read()
        if '__FREEZE' not in src or '__OPNAMES' not in src:
            bad.append('saladvisual_run.luau: нет встроенных блоков (__FREEZE/__OPNAMES)')
        lvl = ''
        while ('[%s[' % lvl) in src or (']%s]' % lvl) in src:
            lvl += '='
        open('/tmp/_verify_run.luau', 'w', encoding='utf-8').write(
            'local src=[%s[\n%s\n]%s]\nlocal f,e=(loadstring or load)(src)\n'
            'print(f and "PARSE OK" or ("FAIL "..tostring(e)))\n' % (lvl, src, lvl))
        luau = os.environ.get('LUAU_BIN', os.path.join(os.path.dirname(os.path.dirname(root)),
                                                      'work', 'luau2', 'build', 'release', 'luau'))
        if os.path.exists(luau):
            rr = _sp.run([luau, '/tmp/_verify_run.luau'], capture_output=True, timeout=600)
            o = rr.stdout.decode(errors='replace')
            if not o.startswith('PARSE OK'):
                bad.append('saladvisual_run.luau: не разбирается Luau: ' + o.strip()[:100])
    img = os.path.join(d, 'program_image.lua')
    if not os.path.exists(img):
        bad.append('devirt/program_image.lua: нет файла')
    else:
        txt = open(img, encoding='utf-8', errors='replace').read()
        n = txt.count('] = {')
        if n < 5000:
            bad.append('devirt/program_image.lua: мало инструкций (%d)' % n)

    # согласованность листингов: объединение >= одного прогона и одинаковый размер массива
    import re as _re
    info = {}
    for name in ('mod_listing.txt', 'mod_listing_singlerun.txt'):
        f = os.path.join(d, name)
        if os.path.exists(f):
            head = open(f, encoding='utf-8', errors='replace').read(400)
            m = _re.search(r'# инструкций: (\d+) \(массив содержит (\d+)\)', head)
            if m:
                info[name] = (int(m.group(1)), int(m.group(2)))
            else:
                bad.append('%s: шапка без размеров' % name)
    if len(info) == 2:
        (u, mu), (s1, ms) = info['mod_listing.txt'], info['mod_listing_singlerun.txt']
        if u < s1:
            bad.append('mod_listing.txt меньше, чем одномоментный листинг (%d < %d)' % (u, s1))
        if mu != ms:
            bad.append('размер массива в листингах расходится (%d vs %d)' % (mu, ms))
    print('DEVirt-АРТЕФАКТЫ: %s' % ('OK' if not bad else 'ОШИБКИ: ' + '; '.join(bad)))
    return not bad


if __name__ == '__main__':
    art = devirt_artifacts()
    rc = main()
    sys.exit(0 if (not rc and art) else 1)
