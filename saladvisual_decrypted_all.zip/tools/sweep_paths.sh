#!/bin/bash
# свип по значениям "времени" - собираем данные из разных веток payload
rm -f pr_merged.txt auto_merged.txt sweep_summary.txt
for T in 0 1 2 1000 1001 4242 12345 1750000000 2000000000; do
  TICK=$T AUTO=1 IDXLOG=1 PROBE=1 STMT_FROM=3128700 STMT_TO=3202250 \
    TRACE_SKIP="eT,BT,UT,FT,JT,oT,OT,aT,zS,97,33" python3 build_stmt.py >/dev/null 2>&1
  timeout 120 ./luau2/build/release/luau run.luau > trace_sweep.log 2>/dev/null
  PR=$(grep -c '^PR' trace_sweep.log); AUT=$(grep -c '^AUTO' trace_sweep.log)
  IDXN=$(grep -m1 '^IDXN' trace_sweep.log | cut -f2); ERR=$(grep -m1 '^ERR' trace_sweep.log | cut -c1-60)
  HB=$(grep -c '^HB' trace_sweep.log)
  printf "TICK=%-11s PR=%-4s AUTO=%-3s IDXN=%-6s HB=%-3s %s\n" "$T" "$PR" "$AUT" "${IDXN:-?}" "$HB" "$ERR" >> sweep_summary.txt
  grep '^PR' trace_sweep.log >> pr_merged.txt
  grep '^AUTO' trace_sweep.log | sed "s/^/T$T\t/" >> auto_merged.txt
done
sort -u pr_merged.txt -o pr_merged.txt
echo "=== СВОДКА ==="; cat sweep_summary.txt
echo "=== уникальных PR: $(wc -l < pr_merged.txt)"
