#!/bin/sh
# Прогон артефакта Luraph v15.1 в песочнице Luau с трассировкой.
#
# Подготовка (один раз):
#   git clone --depth 1 https://github.com/luau-lang/luau.git && cd luau && make -j2 config=release luau
#   export LUAU_BIN=$PWD/build/release/luau
#
# Запуск:
#   LUAU_BIN=/path/to/luau ./tools/run_sandbox.sh [artifact.lua] [out.log]
#
# Переменные окружения:
#   IDXCAP=200   остановиться после N обращений к ленивому пулу (тогда прогон завершается
#                штатно и эпилог дампит буферы/таблицы; при IDXCAP>=300 payload уходит
#                в бесконечный main-loop и данные теряются)
#   AUTO=1       авто-заглушки отсутствующих глобалов (без них падение на Path2DControlPoint)
#   SCAN=0       экспериментальный скан индексов пула (результата не даёт — пул это поток, не словарь)
#   TICK=1000    замороженное «время» (детерминизм прогона)
#   CAP=1e9      лимит вызовов маркированных функций
#   STMT_FROM / STMT_TO — окно инъекции маркеров операторов (по умолчанию: интерпретатор payload)
set -e
LUAU_BIN="${LUAU_BIN:-/home/user/work/luau2/build/release/luau}"
WORK="${WORK:-/home/user/work}"
ARTIFACT="${1:-/home/user/uploads/saladvisual_payload.lua.txt}"
OUT="${2:-$WORK/trace_pool.log}"

: "${IDXCAP:=200}"; : "${SCAN:=0}"; : "${AUTO:=1}"; : "${TICK:=1000}"; : "${CAP:=1000000000}"
: "${STMT_FROM:=3128700}"; : "${STMT_TO:=3202250}"
: "${FULLPOOL:=0}"; : "${FULLAT:=1}"

cd "$WORK"
echo "[run_sandbox] собираю run.luau (IDXCAP=$IDXCAP AUTO=$AUTO TICK=$TICK CAP=$CAP FULLPOOL=$FULLPOOL)"
IDXCAP=$IDXCAP SCAN=$SCAN AUTO=$AUTO TICK=$TICK CAP=$CAP IDXLOG=1 \
  FULLPOOL=$FULLPOOL FULLAT=$FULLAT \
  STMT_FROM=$STMT_FROM STMT_TO=$STMT_TO \
  TRACE_SKIP="eT,BT,UT,FT,JT,oT,OT,aT,zS,97,33" \
  python3 build_stmt.py

echo "[run_sandbox] запуск: $LUAU_BIN run.luau > $OUT"
exec "$LUAU_BIN" run.luau > "$OUT"
