import sys, os

payload_path = '/home/user/uploads/saladvisual_payload.lua.txt'
prelude_path = '/home/user/work/prelude.luau'
out_path = '/home/user/work/run.luau'

payload = open(payload_path, encoding='utf-8').read()
prelude = open(prelude_path, encoding='utf-8').read()

patched = payload.replace('return setmetatable(', 'return __WRAP(', 1)
assert patched != payload, 'wrap substitution failed'

cfg = {
    'trace_cap': int(os.environ.get('TRACE_CAP', 200000)),
    'trace_mode': os.environ.get('TRACE_MODE', 'full'),
    'total_cap': int(os.environ.get('TOTAL_CAP', 30000000)),
    'skip': [x for x in os.environ.get('TRACE_SKIP', '').split(',') if x],
    'follow': [x for x in os.environ.get('TRACE_FOLLOW', '').split(',') if x],
}
skip_lua = '{' + ','.join('"%s"' % x for x in cfg['skip']) + '}'
follow_lua = '{' + ','.join('"%s"' % x for x in cfg['follow']) + '}'
cfg['follow_lua'] = follow_lua

EPILOGUE = '''
local function __finish()
    print("EVENTS\\t" .. tostring(__TOTAL) .. "\\tLOGGED\\t" .. tostring(__LOG_LINES))
    local okb, errb = pcall(__DUMP_BUFFERS)
    if not okb then print("BUFFAIL\\t" .. tostring(errb)) end
    local okt, errt = pcall(__DUMP_TABLES)
    if not okt then print("TBLFAIL\\t" .. tostring(errt)) end
    local okr, errr = pcall(__DUMP_RING)
    if not okr then print("RINGFAIL\t" .. tostring(errr)) end
    local okd, errd = pcall(__DUMP_DYN)
    if not okd then print("DYNFAIL\\t" .. tostring(errd)) end
end
local __ok, __err = xpcall(__chunk, function(e)
    return tostring(e) .. "\\n" .. tostring(debug.traceback(nil, 2))
end)
print("STATUS\\t" .. tostring(__ok))
print("ERR\\t" .. tostring(__err))
pcall(__finish)
'''

parts = [
    '__CFG = {trace_cap=%d, trace_mode="%s", total_cap=%d, skip=%s, follow=%s}\n'
    % (cfg['trace_cap'], cfg['trace_mode'], cfg['total_cap'], skip_lua, follow_lua),
    prelude,
    'if __CFG.follow and #__CFG.follow > 0 then __FOLLOW_ON = true for _, _k in ipairs(__CFG.follow) do __FOLLOW[_k] = true end end\n',
    '\n-- ================= payload (wrapped) =================\n',
    'local __chunk = function(...)\n',
    patched,
    '\nend\n',
    EPILOGUE,
]
open(out_path, 'w', encoding='utf-8').write(''.join(parts))
print('wrote', out_path, os.path.getsize(out_path))
