"""Токенный форматтер Lua/Luau: разбивает «однострочный» вывод Luraph на читаемые строки.

Не парсит, а расставляет переводы строк/отступы по ключевым словам и ';',
корректно пропуская строки,长-строки и комментарии.
"""
import re

KEYWORD = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
OPEN_BRACKET = {'then': 1, 'do': 1, 'repeat': 1, 'else': 0}
CLOSE_BRACKET = {'end': 1, 'until': 1, 'else': 1, 'elseif': 1}


def tokenize(src):
    """(kind, text) где kind: name | num | str | punct | kw"""
    i, n = 0, len(src)
    out = []
    while i < n:
        c = src[i]
        if c == '\n' or c == ' ' or c == '\t' or c == '\r':
            i += 1
            continue
        if c == '-' and src.startswith('--', i):
            # comment: long or short
            m = re.match(r'--\[(=*)\[', src[i:])
            if m:
                close = ']' + m.group(1) + ']'
                j = src.find(close, i)
                j = n if j < 0 else j + len(close)
            else:
                j = src.find('\n', i)
                j = n if j < 0 else j
            out.append(('comment', src[i:j]))
            i = j
            continue
        if c in '"\'`':
            j = i + 1
            while j < n:
                if src[j] == '\\':
                    j += 2
                    continue
                if src[j] == c:
                    j += 1
                    break
                j += 1
            out.append(('str', src[i:j]))
            i = j
            continue
        if c == '[' and i + 1 < n and src[i + 1] in '[=':
            m = re.match(r'\[(=*)\[', src[i:])
            if m:
                close = ']' + m.group(1) + ']'
                j = src.find(close, i)
                j = n if j < 0 else j + len(close)
                out.append(('str', src[i:j]))
                i = j
                continue
        if c.isdigit() or (c == '.' and i + 1 < n and src[i + 1].isdigit()):
            m = re.match(r'0[xX][0-9a-fA-F]+|\d+(\.\d+)?([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?', src[i:])
            out.append(('num', m.group(0)))
            i += len(m.group(0))
            continue
        if c.isalpha() or c == '_':
            m = re.match(r'[A-Za-z_][A-Za-z0-9_]*', src[i:])
            out.append(('name', m.group(0)))
            i += len(m.group(0))
            continue
        # punctuation (longest first)
        for p in ('...', '::', '..=', '==', '~=', '<=', '>=', '//', '<<', '>>', '+=', '-=', '*=', '/=', '%=', '^=', '..', '->'):
            if src.startswith(p, i):
                out.append(('punct', p))
                i += len(p)
                break
        else:
            out.append(('punct', c))
            i += 1
    return out


BLOCK_OPEN = {'then', 'do', 'repeat'}
BLOCK_MID = {'else', 'elseif'}
BLOCK_CLOSE = {'end', 'until'}


def format_lua(src, indent_str='  ', max_inline=110):
    toks = tokenize(src)
    lines = []
    cur = ''
    depth = 0
    expect_block_close = 0
    pending_indent = 0

    def flush():
        nonlocal cur, pending_indent
        text = cur.rstrip()
        if text:
            lines.append(indent_str * pending_indent + text)
        cur = ''

    i = 0
    n = len(toks)
    last_kind = None
    while i < n:
        kind, text = toks[i]
        nxt = toks[i + 1][1] if i + 1 < n else ''
        nxtk = toks[i + 1][0] if i + 1 < n else ''

        if kind == 'comment':
            flush()
            lines.append(indent_str * depth + text)
            i += 1
            continue

        if kind == 'name' and text in BLOCK_CLOSE:
            # close current line, dedent, emit keyword
            flush()
            if text == 'elseif':
                depth = max(depth - 1, 0)
                lines.append(indent_str * depth + 'elseif ' + '')
                depth += 1
                cur = ''
                # continue with condition tokens on the same line
                i += 1
                # collect condition until 'then'
                buf = ''
                while i < n and not (toks[i][0] == 'name' and toks[i][1] == 'then'):
                    buf += toks[i][1]
                    i += 1
                if i < n:
                    buf += 'then'
                    i += 1
                lines[-1] = indent_str * (depth - 1) + 'elseif ' + buf
                continue
            depth = max(depth - 1 - 0, 0)
            if text == 'else':
                lines.append(indent_str * depth + 'else')
                depth += 1
            else:  # end / until
                if text == 'until':
                    # until <cond> on one line
                    buf = 'until'
                    i += 1
                    while i < n and not (toks[i][0] == 'name' and toks[i][1] in ('end', 'else', 'elseif', 'do')):
                        if toks[i][1] == ';':
                            break
                        buf += toks[i][1]
                        i += 1
                    lines.append(indent_str * depth + buf)
                    continue
                lines.append(indent_str * depth + 'end')
                i += 1
                # 'end' may be followed by ')' etc. -> handled by continuing loop
                # allow 'end)' composite on the same line
                if i < n and toks[i][1] in (')', ']', '}', ',', ';', '.', ':'):
                    lines[-1] = lines[-1] + toks[i][1]
                    i += 1
                continue
            i += 1
            continue

        if kind == 'name' and text in ('then', 'do', 'repeat'):
            cur += text
            flush()
            depth += 1
            i += 1
            continue

        if text == ';':
            cur += ';'
            flush()
            i += 1
            continue

        cur += text
        i += 1

    flush()
    return '\n'.join(lines)


if __name__ == '__main__':
    import sys
    s = open(sys.argv[1], encoding='utf-8', errors='replace').read()
    print(format_lua(s))
