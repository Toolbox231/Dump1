import json, os
payload_path='/home/user/uploads/saladvisual_payload.lua.txt'
prelude=open('/home/user/work/prelude.luau',encoding='utf-8').read()
src=open(payload_path,encoding='utf-8').read()
fnspans=[x for x in json.load(open('/home/user/work/mark_spans2.json')) if x]
stspans=json.load(open('/home/user/work/stmt_spans.json'))
FROM=int(os.environ.get('STMT_FROM','0')); TO=int(os.environ.get('STMT_TO', str(len(src))))
events=[]
for i,(s0,e0) in enumerate(fnspans):
    events.append((s0,0,'__MARKF(%d,'%i)); events.append((e0,1,')'))
skipped=0
for j,(s0,e0) in enumerate(stspans):
    if FROM<=s0<=TO:
        # после return/continue в том же блоке нельзя ставить оператор - пропускаем
        if j>0:
            pa,pb=stspans[j-1]
            gap=src[pb:s0]
            prev=src[pa:pb].lstrip()
            if gap.strip(' ;\t\r\n')=='' and (prev.startswith('return') or prev.startswith('continue')):
                skipped+=1
                continue
        events.append((s0,-1,'__STMT(%d);'%j))
if skipped: print('пропущено маркеров после return/continue:', skipped)
events.sort(key=lambda x:(x[0],x[1]))
out=[]; pos=0
for p0,kind,txt in events:
    out.append(src[pos:p0]); out.append(txt); pos=p0
out.append(src[pos:])
body=''.join(out)
patched=body.replace('return setmetatable(','return __WRAP(',1)
assert patched!=body
# --- инструментация мини-VM (ленивая таблица): лог __index ---------
ANCHOR_OPEN='l={__index=__MARKF(%d,function(L,y)'
ANCHOR_CLOSE='end;end;end)};z[7]=l;'
import re as _re2
_mopen=_re2.search(r'l=\{__index=__MARKF\((\d+),function\(L,y\)', patched)
if (os.environ.get('IDXLOG') or '') not in ('','0') and _mopen and patched.count(ANCHOR_CLOSE)==1:
    _idx=_mopen.group(1)
    patched=patched[:_mopen.start()] + 'l={__index=__VIS(__MARKF(' + _idx + ',function(L,y)' + patched[_mopen.end():]
    print('IDXLOG: мини-VM = маркер #' + _idx)
    patched=patched.replace(ANCHOR_CLOSE,'end;end;end))};z[7]=l;',1)
    print('IDXLOG: мини-VM обёрнут __VIS')
else:
    print('IDXLOG: выключен (env IDXLOG=1 чтобы включить)')


# --- дамп потока инструкций внутренней VM (IH=1): хук в сам интерпретатор -----
if os.environ.get('IH'):
    # маркеры операторов уже впрыснуты (__STMT), поэтому анкор — чтение опкода
    _A='local M,sP=z[O];'
    if patched.count(_A)==1:
        patched=patched.replace(_A, _A+'if __CFG and __CFG.ih then __IHOOK(z,T,P,a,y,f,l,O,M) end;',1)
        print('IH: хук в интерпретатор вставлен (после чтения опкода)')
    else:
        print('IH: анкор не найден (вхождений %d)' % patched.count(_A))

# --- ЗАМОРОЗКА (FREEZE=1): ставим расшифрованный образ и гасим декодеры пачек -----
if os.environ.get('FREEZE'):
    _A='local M,sP=z[O];'
    ins=('if __CFG and __CFG.freeze then '
         'if not __FROZEN then __FREEZE(z,T,P,a,y,f) end; '
         'if not (type(M)=="number" and M>=0 and M<=205) then __TRAP(O,M) end; end;')
    if patched.count(_A)==1:
        patched=patched.replace(_A, _A+ins,1)
        print('FREEZE: установка образа + ловушка вставлены')
    else:
        print('FREEZE: анкор не найден')
    # декодеры пачек -> в no-op (образ уже расшифрован): оборачиваем в if not __FROZEN then ... end
    import re as _re3
    # декодеры пачек гасим без регулярки: находим по характерным хвостам
    tails = ['z[O]=118;', 'P[O]=44;', 'z[O]=22;', 'T[O]=1;']
    cnt = 0
    for t in tails:
        i = patched.find(t)
        if i < 0:
            print('FREEZE: хвост %s не найден' % t)
            continue
        k = patched.rfind('Z,C=', max(0, i - 400), i)
        if k < 0:
            print('FREEZE: начало декодера для %s не найдено' % t)
            continue
        e = i + len(t)
        stmt = patched[k:e]
        patched = patched[:k] + 'if not __FROZEN then ' + stmt + ' end;' + patched[e:]
        cnt += 1
    print('FREEZE: декодеров обёрнуто: %d (их всего в артефакте 4)' % cnt)

# --- точечный зонд на месте краха: c[T[O]]=u[y[O]][f[O]] ---------
if os.environ.get('PROBE'):
    import re as _re
    A='if M<161 then c[T[O]]=u[y[O]][f[O]];'
    _pat=_re.compile(r'if M<161 then (__STMT\(\d+\);)?c\[T\[O\]\]=u\[y\[O\]\]\[f\[O\]\];')
    if len(_pat.findall(patched))==1:
        B=('local __pv,__pk=u[y[O]],f[O];'
           'if __pv==nil then '
           'print("GETNIL\\tO="..tostring(O).."\\ty="..tostring(y[O]).."\\tf="..tostring(__pk).."\\tM="..tostring(M).."\\tu="..tostring(u).."\\ttype="..type(u));'
           'pcall(function() for k,v in u do print("U\\t"..tostring(k).."\\t"..type(v).."\\t"..tostring(v):sub(1,70)) end end);'
           'pcall(function() local t={} for i=1,60 do t[#t+1]=tostring(u[i]) end print("UARR\\t"..table.concat(t,",")) end);'
           'end;c[T[O]]=__pv[__pk];')
        patched=_pat.sub(lambda m: 'if M<161 then ' + (m.group(1) or '') + B, patched, count=1)
        print('PROBE: зонд вставлен')
    else:
        print('PROBE: якорь не найден (count=%d)' % len(_pat.findall(patched)))
cfg={'skip':[x for x in os.environ.get('TRACE_SKIP','').split(',') if x]}
EPILOGUE='''
local function __finish()
    local okn, n = pcall(function() return __IHN end)
    print("SUMMARY\\tVM-событий=" .. tostring(__TOTAL)
        .. "\\tадресов программы исполнено=" .. tostring(okn and n or "?")
        .. "\\tмассивов-программ=" .. tostring(__IHZN or "?"))
    print("SUMMARY\\tрасшифрованная программа — devirt/mod_listing.txt; образ — devirt/program_image.lua")
    print("EVENTS\\t" .. tostring(__TOTAL))
    print("FINALCUR\\t" .. tostring(__CUR) .. "\\tSTMT\\t" .. tostring(__CURSTMT))
    local okb, errb = pcall(__DUMP_BUFFERS)
    if not okb then print("BUFFAIL\\t" .. tostring(errb)) end
    local okd, errd = pcall(__DUMP_DYN)
    if not okd then print("DYNFAIL\\t" .. tostring(errd)) end
    pcall(function() if __IDUMP then __IDUMP() end end)
    pcall(function() if __DUMP_IDX then __DUMP_IDX() end end)
    pcall(function() if __DUMP_POOLRES then __DUMP_POOLRES() end end)
    pcall(function() if __DUMP_FREQ then __DUMP_FREQ() end end)
end
local __ok, __err = xpcall(__chunk, function(e)
    pcall(function() __DUMP_MSTK("at-error") end)
    return tostring(e) .. "\\nCUR\\t" .. tostring(__CUR) .. "\\nSTMT\\t" .. tostring(__CURSTMT) .. "\\n" .. tostring(debug.traceback(nil, 2))
end)
print("STATUS\\t" .. tostring(__ok))
print("ERR\\t" .. tostring(__err))
pcall(__finish)
'''
skip_lua='{'+','.join('"%s"'%x for x in cfg['skip'])+'}'
auto_lua='true' if os.environ.get('AUTO') else 'false'
tick=int(os.environ.get('TICK','1000'))
call_cap=int(os.environ.get('CAP','3000000'))
vmid=int(os.environ.get('VMID','0')); vmcap=int(os.environ.get('VMCAP','0'))
idxcap=int(os.environ.get('IDXCAP','100000'))
idle=int(os.environ.get('IDLE','8'))
waitmax=int(os.environ.get('WAITMAX','3000'))
autocap=int(os.environ.get('AUTOCAP','400'))
scan=int(os.environ.get('SCAN','0'))
full=int(os.environ.get('FULLPOOL','0'))
fullat=int(os.environ.get('FULLAT','1'))
dumpmap=1 if os.environ.get('DUMPMAP') else 0
fromp=int(os.environ.get('FROMP','1'))
top=int(os.environ.get('TOP','0'))
skip=sorted(os.environ.get('SKIPKEYS','').split(',')) if os.environ.get('SKIPKEYS') else []
keylist=os.environ.get('KEYLIST','')
maxl=int(os.environ.get('MAXL','8'))
logn=int(os.environ.get('LOGN','600'))
evdrive=int(os.environ.get('EVDRIVE','0'))
evstep=int(os.environ.get('EVSTEP','20000'))
evat=int(os.environ.get('EVAT','0'))
ih=1 if (os.environ.get('IH') or '') not in ('','0') else 0
freeze=1 if os.environ.get('FREEZE') else 0
quiet=1 if (os.environ.get('QUIET') or '') not in ('','0') else 0
insread=1 if (os.environ.get('INSREAD') or '') not in ('','0') else 0
ihcap=int(os.environ.get('IHCAP','400000'))
spans_lua='{' + ','.join('[%d]={%d,%d}' % (i,a,b) for i,(a,b) in enumerate(fnspans)) + '}'
_skiplua='{' + ','.join('["%s"]=true' % k for k in skip) + '}'
_keylua='{' + ','.join(keylist.split(',')) + '}' if keylist else 'nil'
img_block = ''
_img_path = os.environ.get('IMAGE', '/home/user/deobfuscated/devirt/program_image.lua')
if os.path.exists(_img_path):
    img_block = '\n__IMAGE = (function()\n' + open(_img_path, encoding='utf-8').read() + '\nend)()\n'
opnames = ''
_opn = '/home/user/work/opnames.lua'
if os.path.exists(_opn):
    opnames = open(_opn, encoding='utf-8').read()
parts=['__SPANS = ' + spans_lua + '\n', opnames,'__CFG = {trace_cap=0, trace_mode="none", total_cap=200000000, skip=%s, follow={}, auto=%s, tick=%d, call_cap=%d, vmid=%d, vmcap=%d, idxcap=%d, idle=%d, waitmax=%d, autocap=%d, scan=%d, full=%d, fullat=%d, dumpmap=%d, fromp=%d, top=%d, skip=%s,keylist=%s,maxl=%d,logn=%d,evdrive=%d,evstep=%d,evat=%d,ih=%d,ihcap=%d,freeze=%d,quiet=%d,insreadable=%d}\n'%(skip_lua,auto_lua,tick,call_cap,vmid,vmcap,idxcap,idle,waitmax,autocap,scan,full,fullat,dumpmap,fromp,top,_skiplua,_keylua,maxl,logn,evdrive,evstep,evat,ih,ihcap,freeze,quiet,insread),
       img_block,
       prelude,
       '\nlocal __chunk = function(...)\n', patched, '\nend\n', EPILOGUE]
out_path = os.environ.get('OUT', '/home/user/work/run.luau')
hdr = os.environ.get('HDRFILE', '')
head = open(hdr, encoding='utf-8').read() if (hdr and os.path.exists(hdr)) else ''
open(out_path,'w',encoding='utf-8').write(head + ''.join(parts))
print('wrote %s %d' % (out_path, os.path.getsize(out_path)))
