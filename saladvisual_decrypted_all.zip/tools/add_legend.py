#!/usr/bin/env python3
"""Обновление карты пула и вставка компактной легенды в шапку recovered_payload.lua.

Порядок применения:
    1) python3 tools/pool_sweep.py --keys ...        # добить пул (см. pool_sweep.py)
    2) python3 luraph_deob_151.py <артефакт> -o . --ast ast.json --runtime-log trace.log
    3) python3 tools/annotate_pool.py --dir payload && ... --dir by_entry && ... recovered_payload.lua
    4) python3 tools/add_legend.py                   # ЭТОТ скрипт (последним!)

Легенда ставится после аннотирования, чтобы аннотатор не дописывал комментарии внутрь неё.
В шапке — только самые «горячие» записи пула (по числу ссылок), полная карта в pool_map.json.
"""
import argparse, collections, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=ROOT)
    ap.add_argument('--top', type=int, default=60, help='сколько записей показать в легенде')
    args = ap.parse_args()

    root = args.root
    pool = json.load(open(os.path.join(root, 'pool_map.json'), encoding='utf-8'))
    pool = {int(k): v for k, v in pool.items()}

    # сколько раз каждый индекс встречается в восстановленном коде
    use = collections.Counter()
    for sub in ('payload', 'by_entry', 'state_machines'):
        for p in os.listdir(os.path.join(root, sub)):
            if not p.endswith('.lua'):
                continue
            txt = open(os.path.join(root, sub, p), encoding='utf-8').read()
            for m in re.finditer(r'\bl\[(\d+)\]', txt):
                use[int(m.group(1))] += 1
    top = use.most_common(args.top)

    lines = ['--', '-- Пул констант: разрешено %d записей (из %d ссылок в коде — %d разрешено).'
             % (len(pool), sum(use.values()), sum(1 for i in use if i in pool)),
             '-- Полная карта — pool_map.json; здесь самые частые:']
    for idx, cnt in top:
        val = str(pool.get(idx, '?'))
        val = val[:48].replace('\n', '\\n')
        lines.append('--   l[%d]\t×%-6d = %r' % (idx, cnt, val))
    legend = '\n'.join(lines) + '\n'

    p = os.path.join(root, 'recovered_payload.lua')
    s = open(p, encoding='utf-8').read()
    if '-- Полная карта — pool_map.json' in s:          # идемпотентность: убрать старую легенду
        s = re.sub(r'--\n-- Пул констант:.*?--   l\[\d+\]\t×[^\n]*\n', '', s, count=1, flags=re.S)
    head, sep, rest = s.partition('\n\n')
    open(p, 'w', encoding='utf-8').write(head + '\n' + legend + sep + rest)
    print('легенда обновлена: %d записей в карте, %d показано, файл %d байт'
          % (len(pool), len(top), len(head) + 1 + len(legend) + len(sep) + len(rest)))

if __name__ == '__main__':
    sys.exit(main())
