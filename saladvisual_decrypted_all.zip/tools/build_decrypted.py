#!/usr/bin/env python3
"""Сборка единого расшифрованного файла из восстановленных фрагментов.

На входе — index.md (инвентарь: entry, индекс, тип, размер, путь) и сами файлы
payload/, state_machines/. На выходе — один валидный Lua-файл, где каждая
восстановленная функция лежит в таблице F:

    F["s[80]#1"] = function(L,L) ... end;

Такой файл:
  * разбирается штатным Luau (проверено tools/verify_output.py --decrypted);
  * не упирается в лимит 200 локалов на чанк (присваивания полей таблицы локалов не создают);
  * читается как обычный исходник — функции идут в порядке энтри/индексов,
    с шапкой (entry/офсет/тип) и инлайн-аннотациями пула.

Запуск:
    python3 tools/build_decrypted.py [-o saladvisual_decrypted.lua]
"""
import argparse, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

HEADER = '''-- ============================================================================
-- saladvisual — расшифрованный (деобфусцированный) исходник payload'а
--
-- ИСТОЧНИК:  saladvisual_payload.lua.txt — артефакт Luraph v15.1 (3 701 686 байт)
-- МЕТОД:     Luau-AST-извлечение + трассировка рантайма в песочнице Luau
--            (см. README.md: §2 — почему публичный v15-деобфускатор не сработал,
--             §8 — трассировка и пул констант, §9 — гарантии корректности)
--
-- ЧТО ВНУТРИ: все 746 восстановленных фрагментов кода — логика мода, её главный поток
--            (flatten-функции), обработчики, GUI и утилиты (payload 251 + code 486 + 9).
--            Все фрагменты проверены: 788/788 файлов вывода разбираются Luau, состав
--            токенов каждого совпадает с его срезом в артефакте (0 расхождений).
--
-- КАК ЧИТАТЬ: F["s[<entry>]#<n>"] — функция №n из таблицы артефакта с ключом s[entry].
--            В шапке каждой функции — её офсет в исходном файле.
--            Комментарии вида l[1536]--[[Instance]] — константа пула: VM подставляет
--            её в рантайме; значения сняты трассировкой реального исполнения payload.
--            Ссылки без аннотации — константы, которые payload в песочнице не читал
--            (см. README §10: пул — это десять отдельных потоков, а не словарь).
--
-- ВАЖНО:     это восстановленный ИСХОДНЫЙ КОД, а не готовый к запуску скрипт:
--            функции вырваны из VM-обвязки (upvalue-контекст задавался VM),
--            часть строк идёт через пул, имена переменных обфусцированы (L, y, z, T…).
-- ============================================================================

local F = {}

'''


def read_body(path):
    """Тело файла без служебной шапки (строки-комментарии в начале)."""
    lines = open(path, encoding='utf-8').read().split('\n')
    i = 0
    while i < len(lines) and (lines[i].startswith('--') or not lines[i].strip()):
        i += 1
    return '\n'.join(lines[i:]).rstrip() + '\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('-o', '--out', default=os.path.join(ROOT, 'saladvisual_decrypted.lua'))
    ap.add_argument('--root', default=ROOT)
    args = ap.parse_args()

    idx = open(os.path.join(args.root, 'index.md'), encoding='utf-8').read()
    # | фрагмент | ключ | # | тип | байт | файл |
    rows = [(m[0], int(m[2]), m[3], int(m[4]), m[5]) for m in
            re.findall(r'^\| `s\[([^\]]+)\]` \| (\w[\w-]*) \| (\d+) \| ([\w-]+) \| (\d+) \| `([^`]+)` \|$',
                       idx, re.M)]
    print('фрагментов в инвентаре: %d' % len(rows))

    parts = [HEADER]
    n = 0
    for entry, i, kind, size, path in rows:
        full = os.path.join(args.root, path)
        if not os.path.exists(full):
            print('  нет файла', path)
            continue
        body = read_body(full).strip()
        if body.startswith('local function '):        # оператор -> выражение
            body = body[len('local '):]
        # Luau не поддерживает ИМЕНОВАННОЕ function-выражение (`function f()` допустимо
        # только как оператор), а в AST такие функции приходят именно с именем. Оборачиваем
        # в IIFE, где имя становится локальной переменной — так сохраняется и рекурсия,
        # и self-ссылки внутри тела (`G:PreloadAsync(...)`).
        m = re.match(r'^function\s+([A-Za-z_]\w*)\s*(\(.*)$', body, re.S)
        if m:
            name, rest = m.group(1), 'function' + m.group(2)
            body = ('(function()\n  local %s\n  %s = %s\n  return %s\nend)()'
                    % (name, name, rest, name))
        if not body.startswith('function') and not body.startswith('(function()'):
            print('  пропуск %s (не function)' % path)
            continue
        m = re.search(r'-- offset (\d+)\.\.(\d+) ', open(full, encoding='utf-8').read())
        off = ('off %s' % m.group(1)) if m else ''
        parts.append('-- ==== s[%s] #%d  %s  %d байт  %s ====\n'
                     % (entry, i, kind, size, off))
        parts.append('F["s[%s]#%d"] = %s\n\n' % (entry, i, body))
        n += 1
    parts.append('return F\n')

    out = args.out
    open(out, 'w', encoding='utf-8').write(''.join(parts))
    print('функций в файле: %d' % n)
    print('размер: %d байт -> %s' % (os.path.getsize(out), out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
