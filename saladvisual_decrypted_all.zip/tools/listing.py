#!/usr/bin/env python3
"""Листинг программы, которую исполняет внутренняя VM payload'а.

Вход:  лог песочницы с дампом инструкций (`DST`-строки, см. prelude.luau → __IDUMP)
       + таблица опкодов (devirt/opcodes.json)
Выход: devirt/mod_listing.txt — читаемый листинг (адрес, имя опкода, операнды, метки переходов)
       devirt/mod_stats.md    — статистика: покрытие, гистограмма, сверка с трассой исполнения

Рендер операндов делается автоматически: из кода обработчика берётся его шаблон,
подстановки вида `T[O]` заменяются на значения операндов из дампа.

Запуск:
    python3 tools/listing.py --log /home/user/work/trace_dump.log
"""
import argparse, collections, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# имена опкодов (см. tools/devirt_names.py — здесь только короткие для листинга)
import importlib.util
spec = importlib.util.spec_from_file_location('devirt_names', os.path.join(HERE, 'devirt_names.py'))
devirt_names = importlib.util.module_from_spec(spec)
spec.loader.exec_module(devirt_names)
NAMES = dict(devirt_names.NAMES)
for _k, _v in devirt_names.EXTRA.items():
    NAMES.setdefault(int(_k), _v)


def template(handler):
    """Превращает код обработчика в шаблон с плейсхолдерами вместо операндов."""
    t = handler
    for slot in ('T', 'P', 'a', 'y', 'f', 'l'):
        t = re.sub(r'\b%s\[O\]' % slot, '{%s}' % slot, t)
    t = re.sub(r'\b([TPafly])\[O \+ 1\]', lambda m: '{%s+1}' % m.group(1), t)
    t = re.sub(r'\s+', ' ', t).strip().rstrip(';')
    return t


def render(tpl, op, entries):
    def rep(m):
        key = m.group(1)
        if key.endswith('+1'):
            base = key[:-2]
            v = entries.get(base)
            return ('%s+1' % v) if isinstance(v, (int, float)) else '?'
        v = entries.get(key)
        return str(v) if v is not None else '?'
    out = re.sub(r'\{([TPaflyt]\+?1?)\}', rep, tpl)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--log', default='/home/user/work/trace_dump.log')
    ap.add_argument('--single', action='store_true',
                    help='не объединять, а читать один прогон (самосогласованный снимок)')
    ap.add_argument('--var-from', default=None,
                    help='glob с логами DST для оценки вариантности опкодов между прогонами')
    ap.add_argument('--ins', default=None, help='лог с трассой исполнения (INS) для сверки')
    args = ap.parse_args()

    ops = json.load(open(os.path.join(ROOT, 'devirt', 'opcodes.json'), encoding='utf-8'))
    tpl = {}
    for k, v in ops.items():
        if v:
            tpl[int(k)] = template(re.sub(r'\s+', ' ', v[0]))
    manual = {0: 'return c[P] (закрытие апвалюев)', 1: 'jmp если not (P < c[T])',
              2: 'DECODE: расшифровать пачку инструкций', 3: 'c[T] = f .. c[a]'}
    for k, v in manual.items():
        tpl.setdefault(k, v)

    ins = {}
    prog = {}
    for line in open(args.log, encoding='utf-8', errors='replace'):
        if line.startswith('DST\t'):
            p = line.rstrip('\n').split('\t')
            i, op = int(p[1]), int(p[2])

            def val(x):
                if x in ('nil', ''):
                    return None
                try:
                    f = float(x)
                    return int(f) if f == int(f) else f
                except ValueError:
                    return x
            prog[i] = (op, {'T': val(p[3]), 'P': val(p[4]), 'a': val(p[5]),
                            'y': val(p[6]), 'f': val(p[7])})

    # метки = цели переходов: собираем их из готовой расшифровки инструкций
    targets = set()
    rendered = {}
    for i, (op, e) in prog.items():
        text = render(tpl.get(op, '?'), op, e)
        if op in (2, 6, 22):     # декодеры пачки инструкций
            cnt, start = e.get('P'), e.get('a')
            if isinstance(cnt, int) and isinstance(start, int):
                text = 'DECODE %d инструкций (индексы %d..%d), seed=%s' % (cnt, start + 1, start + cnt, e.get('T'))
        if len(text) > 150:
            text = text[:147] + ' …'
        rendered[i] = text
        if 'O=' in text or 'O =' in text:
            for m in re.finditer(r'O=(?:if [^\n]*?then )?(\d+)(?:else|$)', text):
                v = int(m.group(1))
                if 1 <= v <= 100000:
                    targets.add(v)

    lines = []
    total_hi = None
    for _line in open(args.log, encoding='utf-8', errors='replace'):
        if _line.startswith('IDUMP\tlen='):
            total_hi = int(_line.strip().split('=')[1])
    lines.append('# Листинг программы внутренней VM (payload saladvisual, Luraph v15.1)')
    lines.append('# инструкций: %d (массив содержит %s)' % (len(prog), total_hi))
    if args.single:
        lines.append('# режим: один прогон — самосогласованный снимок байткода в момент останова')
    else:
        lines.append('# режим: объединение снимков нескольких прогонов (максимальное покрытие);')
        lines.append('#   часть адресов перекодируется по ходу работы — см. devirt/mod_variants.txt;')
        lines.append('#   самосогласованный снимок одного прогона — devirt/mod_listing_singlerun.txt')
    lines.append('# оформление: адрес | опкод | расшифровка; опкод по devirt/opcode_table.md; операнды — T/P/a/y/f')
    lines.append('# метки ::L<n>:: — цели переходов; DECODE_RUN — расшифровка очередной порции кода')
    lines.append('')
    prev = None
    for i in sorted(prog):
        if prev is not None and i != prev + 1:
            lines.append('')
        prev = i
        op, e = prog[i]
        if i in targets:
            lines.append('::L%d::' % i)
        name = NAMES.get(op, ('OP_%d' % op, ''))[0]
        lines.append('%6d  %-16s %s' % (i, name, rendered[i]))

    os.makedirs(os.path.join(ROOT, 'devirt'), exist_ok=True)
    out = os.path.join(ROOT, 'devirt',
                       'mod_listing_singlerun.txt' if args.single else 'mod_listing.txt')
    open(out, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')

    # статистика
    hist = collections.Counter(op for op, _ in prog.values())
    stats = ['# Программа внутренней VM: статистика', '',
             '* инструкций в массиве: %s' % total_hi,
             '* расшифровано: %d (%.1f%%)' % (len(prog), 100.0 * len(prog) / (total_hi or len(prog))),
             '* различных опкодов: %d' % len(hist), '',
             '## Топ-20 опкодов', '', '| опкод | имя | раз |', '|---|---|---|']
    for op, n in hist.most_common(20):
        stats.append('| %d | `%s` | %d |' % (op, NAMES.get(op, ('OP_%d' % op, ''))[0], n))
    # сверка с трассой исполнения
    if args.ins and os.path.exists(args.ins):
        # наблюдения по индексам: индекс -> множество опкодов, встреченных при исполнении
        obs = collections.defaultdict(set)
        for line in open(args.ins, encoding='utf-8', errors='replace'):
            if line.startswith('INS\t'):
                p = line.rstrip('\n').split('\t')
                try:
                    obs[int(p[2])].add(int(p[3]))
                except (ValueError, IndexError):
                    continue
        both = [i for i in obs if i in prog]
        agree = [i for i in both if prog[i][0] in obs[i]]
        dis = [i for i in both if prog[i][0] not in obs[i]]
        # разбор расхождений: само-перезапись (в дампе код 118 = DECODE_SLOT) против прочих
        rew = [i for i in dis if prog[i][0] == 118]
        other = [i for i in dis if prog[i][0] != 118]
        stats += ['', '## Сверка с трассой исполнения', '',
                  '* индексов, встречавшихся при исполнении и попавших в дамп: %d' % len(both),
                  '* из них опкод дампа совпал с наблюдённым хотя бы раз: %d' % len(agree),
                  '* расхождений: %d — из них %d само-перезаписанных (дамп: 118 `DECODE_SLOT`;'
                  ' в исполнении: %s), прочих: %d'
                  % (len(dis), len(rew),
                     ', '.join(sorted({str(o) for i in rew for o in obs[i]})), len(other))]
        if other:
            stats += ['', 'Прочие расхождения — это адреса перекодировки (см. раздел вариантности',
                      'ниже): снимок и наблюдение относятся к разным моментам работы.', '',
                      'Прочие расхождения (индекс: в дампе -> наблюдено):', '']
            for i in sorted(other)[:24]:
                stats.append('* %d: %d -> %s'
                             % (i, prog[i][0], ', '.join(str(x) for x in sorted(obs[i]))))
    # вариантность опкодов между прогонами (код перекодируется во время работы)
    if args.var_from:
        import glob as _glob
        per = collections.defaultdict(set)
        for f in _glob.glob(args.var_from):
            for line in open(f, encoding='utf-8', errors='replace'):
                if line.startswith('DST\t'):
                    p2 = line.rstrip('\n').split('\t')
                    per[int(p2[1])].add(int(p2[2]))
        var = {i: v for i, v in per.items() if len(v) > 1}
        if var:
            vo = os.path.join(ROOT, 'devirt', 'mod_variants.txt')
            lines_v = ['# Индексы, опкод которых различался между прогонами (перекодируемые области)',
                       '# формат: индекс: опкоды, встреченные в разных снимках']
            for i in sorted(var):
                lines_v.append('%d: %s' % (i, ', '.join(str(x) for x in sorted(var[i]))))
            open(vo, 'w', encoding='utf-8').write('\n'.join(lines_v) + '\n')
            top = sorted(var, key=lambda i: -len(var[i]))[:8]
            stats += ['', '## Вариантность между прогонами', '',
                      '* индексов, где разные прогоны дали разные опкоды: %d (%.1f%% от расшифрованных)'
                      % (len(var), 100.0 * len(var) / max(1, len(prog))),
                      '* значит эти области код перекодирует по ходу работы; листинг — объединение снимков,',
                      '  а `devirt/mod_variants.txt` перечисляет такие индексы',
                      '* максимум вариантов: %s' % ', '.join('%d -> {%s}' % (i, ', '.join(str(x) for x in sorted(var[i]))) for i in top)]
    # покрытие: непрерывные участки расшифрованного кода
    idxs = sorted(prog)
    runs = []
    for i in idxs:
        if runs and i == runs[-1][1] + 1:
            runs[-1][1] = i
        else:
            runs.append([i, i])
    stats += ['', '## Расшифрованные участки', '']
    for a, b in runs:
        if b - a >= 20:
            stats.append('* %d..%d (%d инструкций)' % (a, b, b - a + 1))
    stats.append('')
    st_out = os.path.join(ROOT, 'devirt',
                          'mod_stats_singlerun.md' if args.single else 'mod_stats.md')
    open(st_out, 'w', encoding='utf-8').write('\n'.join(stats))
    open(os.path.join(ROOT, 'devirt', 'mod_stats_latest.txt'), 'w', encoding='utf-8').write(
        '\n'.join([os.path.basename(out), os.path.basename(st_out)]))
    print('инструкций: %d (из %s), опкодов разных: %d' % (len(prog), total_hi, len(hist)))
    print('-> devirt/%s, devirt/%s' % (os.path.basename(out), os.path.basename(st_out)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
