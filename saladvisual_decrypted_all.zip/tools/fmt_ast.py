"""AST-форматтер Luau: печатает дерево операторов (spans из luau-ast) как читаемый код."""
import re


class Fmt:
    def __init__(self, src):
        self.src = src
        self.lines = []

    def text(self, s, e):
        return self.src[s:e]

    def span(self, node):
        a, b = node['location'].split(' - ')
        return self.off(*map(int, a.split(','))), self.off(*map(int, b.split(',')))

    def off(self, l, c):
        # однострочный файл-артефакт: смещение = позиция в строке (кэшируется)
        if not hasattr(self, '_linebase'):
            self._linebase = []
            base = 0
            for ln in self.src.split('\n'):
                self._linebase.append(base)
                base += len(ln) + 1
        if l >= len(self._linebase):
            return len(self.src)
        return self._linebase[l] + c

    def emit(self, indent, text):
        text = text.strip()
        if text:
            self.lines.append('  ' * indent + text)

    # ---------- statements ----------
    def block(self, body, indent=0):
        if not body or body.get('type') != 'AstStatBlock':
            return
        for st in body['body']:
            self.stmt(st, indent)

    def stmt(self, st, indent=0):
        t = st.get('type')
        s, e = self.span(st)
        if t == 'AstStatIf':
            self.do_if(st, indent)
        elif t == 'AstStatWhile':
            bs = self.span(st['body'])[0]
            self.emit(indent, self.text(s, bs) or ('while %s do' % self.text(*self.span(st['condition']))))
            self.block(st['body'], indent + 1)
            self.emit(indent, self.tail(st))
        elif t == 'AstStatRepeat':
            self.emit(indent, 'repeat')
            self.block(st['body'], indent + 1)
            self.emit(indent, self.text(self.span(st['body'])[1], e))
        elif t == 'AstStatFor':
            bs = self.span(st['body'])[0]
            self.emit(indent, self.text(s, bs))
            self.block(st['body'], indent + 1)
            self.emit(indent, self.tail(st))
        elif t == 'AstStatForIn':
            bs = self.span(st['body'])[0]
            self.emit(indent, self.text(s, bs))
            self.block(st['body'], indent + 1)
            self.emit(indent, self.tail(st))
        elif t == 'AstStatLocalFunction':
            fn = st['func']
            bs = self.span(fn['body'])[0]
            self.emit(indent, self.text(s, bs))
            self.block(fn['body'], indent + 1)
            self.emit(indent, self.tail(fn))
        elif t == 'AstStatBlock':
            # ВАЖНО: `do ... end` в AST Luau — это AstStatBlock с hasEnd=true.
            # Раньше такие блоки просто разворачивались (терялись сами `do`/`end`),
            # из-за чего локальные переменные «выезжали» в общую область видимости
            # и Luau ругался 'Out of local registers ... exceeded limit 200'.
            body = st.get('body') or []
            if st.get('hasEnd'):
                if body:
                    bs = self.span(body[0])[0]
                    self.emit(indent, self.text(s, bs).strip() or 'do')
                    self.block(st, indent + 1)
                    be = self.span(body[-1])[1]
                    self.emit(indent, self.text(be, e).strip() or 'end')
                else:
                    self.emit(indent, 'do end')
            else:
                self.block(st, indent)
        elif t == 'AstStatFunction':
            fn = st['func']
            bs = self.span(fn['body'])[0]
            self.emit(indent, self.text(s, bs))
            self.block(fn['body'], indent + 1)
            self.emit(indent, self.tail(fn))
        else:
            self.simple(st, indent)

    def tail(self, node):
        s, e = self.span(node)
        body = node.get('body')
        if body is None:
            return self.text(s, e)
        bs, be = self.span(body)
        return self.text(be, e).strip() or 'end'

    def do_if(self, st, indent, keyword='if', emit_end=True):
        cond = self.text(*self.span(st['condition']))
        self.emit(indent, '%s %s then' % (keyword, cond))
        self.block(st['thenbody'], indent + 1)
        eb = st.get('elsebody')
        if eb:
            if eb.get('type') == 'AstStatIf':
                self.do_if(eb, indent, 'elseif', emit_end=False)
            else:
                self.emit(indent, 'else')
                self.block(eb, indent + 1)
        if emit_end:
            self.emit(indent, 'end')

    # ---------- simple statements (могут содержать функции) ----------
    def direct_functions(self, node):
        out = []

        def walk(n):
            if isinstance(n, dict):
                if n.get('type') == 'AstExprFunction':
                    out.append(n)
                    return
                for v in n.values():
                    walk(v)
            elif isinstance(n, list):
                for v in n:
                    walk(v)
        for v in (node.get('list') or []):
            walk(v)
        for k, v in node.items():
            if k in ('list',):
                continue
            walk(v)
        out.sort(key=lambda f: self.span(f)[0])
        return out

    def simple(self, st, indent):
        s, e = self.span(st)
        fns = [f for f in self.direct_functions(st)
               if f is not st and self.span(f)[0] >= s and self.span(f)[1] <= e]
        fns = sorted({self.span(f)[0]: f for f in fns}.values(), key=lambda f: self.span(f)[0])
        if not fns:
            self.emit(indent, self.text(s, e))
            return
        cur = s
        pending = ''
        for f in fns:
            fs, fe = self.span(f)
            bs, be = self.span(f['body'])
            pending += self.text(cur, bs)
            self.emit(indent, pending)
            self.block(f['body'], indent + 1)
            pending = self.text(be, fe)   # 'end'
            cur = fe
        pending += self.text(cur, e)
        self.emit(indent, pending)


def format_range(src, node):
    f = Fmt(src)
    t = node.get('type')
    if t == 'AstExprFunction':
        s, e = f.span(node)
        bs, be = f.span(node['body'])
        f.emit(0, f.text(s, bs))
        f.block(node['body'], 1)
        f.emit(0, f.text(be, e).strip() or 'end')
    elif t == 'AstStatBlock':
        f.block(node, 0)
    else:
        f.stmt(node, 0)
    return '\n'.join(f.lines)
