#!/usr/bin/env python3
"""Резолвер пула Lua-констант для вывода luraph_deob_151.py.

В восстановленном коде Luraph v15.1 обращения к пулу выглядят как `l[NNNN]`,
где `l` — таблица констант, собранная VM в рантайме. Имена/строки для части
индексов добываются трассировкой (см. tools/run_sandbox.sh и pool_map.json).

Использование:
    python3 annotate_pool.py <файл.lua> [<файл2.lua> ...]
    python3 annotate_pool.py --dir payload/
    python3 annotate_pool.py --map pool_map.json --count payload/   # только статистика

Аннотация встраивается инлайн-комментарием и НЕ ломает синтаксис:
    y[110]=l[753];   ->   y[110]=l[753]--[["TextLabel"]];
Повторный запуск идемпотентен.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_MAP = os.path.join(os.path.dirname(HERE), 'pool_map.json')

def load_map(path):
    with open(path, encoding='utf-8') as f:
        m = json.load(f)
    # приводим ключи к int, значения к строкам
    out = {}
    for k, v in m.items():
        try:
            out[int(k)] = v if isinstance(v, str) else str(v)
        except ValueError:
            continue
    return out

def annotate_text(text, pool):
    """Вставляет инлайн-комментарий с разрешённым значением после l[NNNN]."""
    stats = {'hits': 0, 'miss': 0, 'refs': 0}
    out = []
    pos = 0
    for m in re.finditer(r'\bl\[(\d+)\](?!--\[\[)', text):
        out.append(text[pos:m.start()])
        idx = int(m.group(1))
        stats['refs'] += 1
        if idx in pool:
            stats['hits'] += 1
            # ВАЖНО: внутри длинного комментария --[[...]] значение не должно
            # содержать закрывающей пары ]] и не должно оканчиваться на ']' — иначе
            # комментарий закрывается раньше и остаётся висячая ']' (ошибка синтаксиса).
            val = str(pool[idx]).replace('\n', '\\n').replace(']]', '] ]')
            if len(val) > 60:
                val = val[:57] + '...'
            if val.endswith(']'):
                val += ' '
            out.append('l[%d]--[[%s]]' % (idx, val))
        else:
            stats['miss'] += 1
            out.append(m.group(0))
        pos = m.end()
    out.append(text[pos:])
    return ''.join(out), stats


def process(path, pool, count_only=False):
    with open(path, encoding='utf-8') as f:
        text = f.read()
    new, st = annotate_text(text, pool)
    if not count_only and new != text:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(new)
    return st

def main():
    args = sys.argv[1:]
    pool_path = DEFAULT_MAP
    count_only = False
    targets = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == '--map':
            i += 1; pool_path = args[i]
        elif a == '--count':
            count_only = True
        elif a == '--dir':
            i += 1
            d = args[i]
            targets += [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.endswith('.lua')]
        else:
            targets.append(a)
        i += 1
    if not targets:
        print(__doc__)
        return 1
    pool = load_map(pool_path)
    print('карта пула: %d записей (%s)' % (len(pool), pool_path))
    tot = {'hits': 0, 'miss': 0, 'refs': 0}
    for t in targets:
        st = process(t, pool, count_only)
        for k in tot:
            tot[k] += st[k]
        print('  %-52s ссылок=%d  разрешено=%d  (%.1f%%)' %
              (t, st['refs'], st['hits'], 100.0 * st['hits'] / max(st['refs'], 1)))
    print('ИТОГО: ссылок %d, разрешено %d (%.2f%%), неизвестно %d' %
          (tot['refs'], tot['hits'], 100.0 * tot['hits'] / max(tot['refs'], 1), tot['miss']))
    return 0

if __name__ == '__main__':
    sys.exit(main())
