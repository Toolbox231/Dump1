#!/usr/bin/env python3
"""Добивание пула Luraph: свип по явному списку ключей с бисекцией «залипших».

Зачем: полный свип пула (tools/run_sandbox.sh с FULLPOOL=N) идёт по всем 9582 ключам
карты L[0], но некоторые ключи уводят декодер-мини-VM в бесконечный цикл — процесс
приходится убивать, и остаток пула остаётся неразрешённым.

Здесь то же самое делается порциями: каждая порция ключей передаётся в run.luau через
env KEYLIST (список ключей), запускается с таймаутом, а если процесс не успел —
порция делится пополам (бисекция), пока не останется один ключ. Так один «залипший»
ключ не мешает декодировать остальные.

Прелюдия печатает по одному ключу строку с паддингом (~4 КБ), из-за чего блок вывода
сбрасывается на каждом ключе — видно, на каком именно ключе декодер встал.

Использование:
    python3 tools/pool_sweep.py --keys pool_missing.json            # только нужные ключи
    python3 tools/pool_sweep.py --all                               # все нерешённые
    python3 tools/pool_sweep.py --keys pool_missing.json --out pool_full_raw.json
"""
import argparse, json, os, re, subprocess, sys, time

WORK = '/home/user/work'
LUAU = '/home/user/work/luau2/build/release/luau'
LOG = os.path.join(WORK, 'pool_sweep_batch.log')

BUILD_ENV = dict(
    FULLPOOL='20000', IDXCAP='60', AUTO='1', IDXLOG='1', TICK='1000',
    CAP='1000000000', STMT_FROM='3128700', STMT_TO='3202250',
    TRACE_SKIP='eT,BT,UT,FT,JT,oT,OT,aT,zS,97,33',
)


def parse_log(text):
    """FP / FPERR / FPKEY-записи -> (значения, ошибки, был ли свип запущен)."""
    vals, errs, started = {}, set(), 'FPBATCH' in text
    for line in text.split('\n'):
        if line.startswith('FP\t'):
            p = line.split('\t')
            if len(p) >= 4:
                k, t, v = p[1], p[2], '\t'.join(p[3:])
                if t == 'number':
                    try:
                        v = float(v) if ('.' in v or 'e' in v.lower()) else int(v)
                    except ValueError:
                        pass
                elif t == 'boolean':
                    v = (v == 'true')
                elif t == 'table':
                    continue
                vals[k] = v
        elif line.startswith('FPERR\t'):
            errs.add(line.split('\t')[1])
    return vals, errs, started


def run_batch(keys, timeout):
    env = dict(os.environ, **BUILD_ENV)
    env['KEYLIST'] = ','.join(str(k) for k in keys)
    b = subprocess.run([sys.executable, 'build_stmt.py'], cwd=WORK, env=env,
                       capture_output=True, timeout=180)
    if b.returncode != 0:
        print(b.stderr.decode()[-400:])
        raise SystemExit('build_stmt.py упал')
    with open(LOG, 'wb') as fh:
        p = subprocess.Popen([LUAU, 'run.luau'], cwd=WORK, stdout=fh, stderr=subprocess.STDOUT)
    t0 = time.time()
    started = done = False
    while time.time() - t0 < timeout:
        if p.poll() is not None:
            break
        try:
            txt = open(LOG, 'rb').read().decode('utf-8', 'replace')
        except OSError:
            txt = ''
        if 'FULLPOOL_END' in txt:
            done = True
            break
        time.sleep(0.25)
    if p.poll() is None:
        p.kill()
    p.wait()
    txt = open(LOG, 'rb').read().decode('utf-8', 'replace')
    vals, errs, started = parse_log(txt)
    return vals, errs, (done or started and len(vals) + len(errs) >= len(keys))


def sweep(keys, timeout, stuck=None, depth=0, budget=None):
    """Рекурсивная бисекция: при таймауте делим порцию пополам."""
    stuck = stuck if stuck is not None else []
    if not keys or (budget and time.time() > budget):
        return {}, set(), stuck
    vals, errs, ok = run_batch(keys, timeout)
    tag = ' ' * depth + ('порция %d..%d' % (keys[0], keys[-1]) if len(keys) > 1 else 'ключ %d' % keys[0])
    print('%s: +%d значений, %d ошибок%s' % (tag, len(vals), len(errs), '' if ok else ' [не завершилось — бисекция]'), flush=True)
    if ok or len(keys) == 1:
        if not ok:
            stuck.append(keys[0])
        return vals, errs, stuck
    mid = len(keys) // 2
    v1, e1, stuck = sweep(keys[:mid], timeout, stuck, depth + 1, budget)
    v2, e2, stuck = sweep(keys[mid:], timeout, stuck, depth + 1, budget)
    v1.update(v2)
    return v1, e1 | e2, stuck


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--keys', help='JSON-файл со списком ключей (или через запятую)')
    ap.add_argument('--all', action='store_true', help='все нерешённые ключи из pool_map_offsets.json')
    ap.add_argument('--out', default=os.path.join(WORK, 'pool_full_raw.json'))
    ap.add_argument('--chunk', type=int, default=50)
    ap.add_argument('--timeout', type=int, default=75)
    ap.add_argument('--max-minutes', type=int, default=0, help='0 = без ограничения')
    args = ap.parse_args()

    res = json.load(open(args.out, encoding='utf-8'))
    known = set(res)
    if args.all:
        allk = json.load(open(os.path.join(WORK, 'pool_map_offsets.json'), encoding='utf-8'))
        todo = [int(k) for k in allk if str(k) not in known]
    else:
        raw = args.keys
        if raw and os.path.exists(raw):
            todo = [int(x) for x in json.load(open(raw, encoding='utf-8'))]
        else:
            todo = [int(x) for x in (raw or '').split(',') if x.strip()]
    todo = [k for k in todo if str(k) not in known]
    print('к добиванию: %d ключей (уже есть %d)' % (len(todo), len(res)), flush=True)

    budget = (time.time() + args.max_minutes * 60) if args.max_minutes else None
    stuck_all = []
    for i in range(0, len(todo), args.chunk):
        part = todo[i:i + args.chunk]
        if budget and time.time() > budget:
            print('бюджет времени исчерпан, осталось %d ключей' % (len(todo) - i), flush=True)
            break
        vals, errs, stuck_all = sweep(part, args.timeout, stuck_all, 0, budget)
        res.update(vals)
        json.dump(res, open(args.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1, sort_keys=True)
        print('  всего в базе: %d | залипло: %s' % (len(res), stuck_all), flush=True)
    print('готово: %d значений, залипших ключей %d: %s' % (len(res), len(stuck_all), stuck_all))
    return 0


if __name__ == '__main__':
    sys.exit(main())
