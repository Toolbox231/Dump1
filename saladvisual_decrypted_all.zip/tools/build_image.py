#!/usr/bin/env python3
"""Образ расшифрованной программы мода → Lua-модуль.

Вход:  лог песочницы с дампом (DST-строки: индекс, опкод, T, P, a, y, f; см. __IDUMP
       в work/prelude.luau). Для «запускаемого» файла нужен дамп ОДНОГО прогона —
       он самосогласован (в объединённом дампе смешаны состояния разных прогонов).
Выход: devirt/program_image.lua — модуль `return {n=..., [адрес]={op, T, P, a, y, f}}`.

Дальше этот модуль подключает saladvisual_run.luau: VM при старте ставит образ в свои
массивы (z, T, P, a, y, f) и отключает расшифровку — то есть исполняет уже
расшифрованную программу, а не расшифровывает её на ходу.

Запуск:
    python3 tools/build_image.py --log /home/user/work/trace_ih_250.log \
        --out devirt/program_image.lua
"""
import argparse, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def fmt(v):
    """Только то, что можно записать в Lua-литерал. Строки — в кавычках."""
    if v is None or v == 'nil':
        return 'nil'
    if v in ('true', 'false'):
        return v
    try:
        f = float(v)
        if str(v).strip() == '' or str(v).lower() in ('nan', 'inf', '-inf'):
            return 'nil'
        if f == int(f) and abs(f) < 1e15:
            return str(int(f))
        return repr(f)
    except (TypeError, ValueError):
        pass
    if isinstance(v, str):
        # служебные строки дампа вида 'table: 0x...' / 'function: 0x...' — не значения
        if ': 0x' in v or v.startswith('<'):
            return 'nil'
        escaped = v.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
        return '"' + escaped + '"'
    return 'nil'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--log', required=True, help='лог с DST-строками (один прогон)')
    ap.add_argument('--out', default=os.path.join(ROOT, 'devirt', 'program_image.lua'))
    ap.add_argument('--decoded-limit', type=int, default=205,
                    help='какие опкоды считать расшифрованными (0..N)')
    args = ap.parse_args()

    rows = {}
    nl = 0
    for line in open(args.log, encoding='utf-8', errors='replace'):
        if line.startswith('IDUMP\tlen='):
            nl = int(line.strip().split('=')[1])
        elif line.startswith('DST\t'):
            p = line.rstrip('\n').split('\t')
            try:
                i, op = int(p[1]), int(p[2])
            except (ValueError, IndexError):
                continue
            if i in rows:
                continue
            rows[i] = (op, p[3:8])

    # образ должен быть последовательным: обрезаем до первого «не-кода»
    # (метки 118 = слоты расшифровки и всё, что вне 0..N, исполнять нельзя)
    body = []
    for i in sorted(rows):
        op, ops = rows[i]
        if not (0 <= op <= args.decoded_limit):
            continue
        body.append((i, op, ops))

    lines = []
    lines.append('-- ===== образ программы внутренней VM (расшифрован) =====')
    lines.append('-- Источник: дамп работающей VM в песочнице (см. tools/build_image.py).')
    lines.append('-- Формат: [адрес] = {опкод, T, P, a, y, f} — операнды в параллельных массивах.')
    lines.append('-- Всего в массиве VM: %s; здесь расшифровано: %d.' % (nl, len(body)))
    lines.append('-- Полное человекочитаемое представление — devirt/mod_listing.txt.')
    lines.append('return {')
    lines.append('  n = %s,' % nl)
    for i, op, ops in body:
        lines.append('  [%d] = {%d, %s},' % (i, op, ', '.join(fmt(x) for x in ops)))
    lines.append('}')
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    open(args.out, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('образ: %d инструкций -> %s (%.1f КБ)'
          % (len(body), args.out, os.path.getsize(args.out) / 1024.0))
    print('не расшифровано (не попало в образ): %d из %s' % (nl - len(body), nl))


if __name__ == '__main__':
    main()
