-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #716
-- offset 3523702..3524526 (824 bytes, type=payload)

local function LP()
  local zP,NP=s[87](),sP or PP or dP or not y[18][l[630]]or not u[l[1600]];
  if NP then
    return;
  end
  Q[l[1420]]=l[288]..u[l[24]];
  Q[l[1324]]=l[383];
  NP=aP;
  PP=l[383];
  local bP=n(u[l[24]]);
  local n=NP~=aP or dP or not y[18][l[630]]or not u[l[1600]];
  if n then
    if bP then
      zP[l[1146]](function()
        bP:Close();
      end);
    end
    return;
  end
  PP=l[1329];
  if not bP then
    Q[l[1420]]=l[1497]..u[l[24]]..l[1541];
    return;
  end
  sP=bP;
  u[l[1273]]=l[383];
  zP[l[1146]](function()
    ZP[#ZP+l[229]]=bP[l[1450]]:Connect(function(PP)
      local DP=sP;
      if DP==bP then
        qP(PP);
      end
    end);
  end);
  zP[l[1146]](function()
    ZP[#ZP+l[229]]=bP[l[1140]]:Connect(function()
      local PP=sP;
      if PP==bP then
        GP();
        Q[l[1420]]=l[1523];
      end
    end);
  end);
  NP,n=J();
  g(l[573]..zP[l[35]][l[819]](zP[l[35]][l[499]](Y[l[1610]]),l[229],l[1632]));
  g(l[635]..NP..l[214]..n);
  g(l[1620]..u[l[1590]]);
  YP(l[888]);
end
