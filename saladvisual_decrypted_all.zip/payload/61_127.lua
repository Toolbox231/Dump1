-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #127
-- offset 139953..140524 (571 bytes, type=payload)

function()
  local a=n;
  if a~="idle" then
    return;
  end
  n="loading";
  task.spawn(function()
    local a;
    local a=z;
    local Z=a.body("fxatlas/index.json");
    local Y,j=pcall(function()
      return game:GetService("HttpService"):JSONDecode(Z);
    end);
    a=not(Y and type(j)=="table"and type(j.map)=="table"and type(j.sheets)=="table");
    if a then
      n="idle";
      return;
    end
    local Z,q,D={},ipairs,j.sheets;
    for p,r in q(D)do
      local q;
      a=y[4][y[6]];
      if not a then
        return;
      end
      Y=z;
      Z[p]=Y.asset(r);
    end;
    d.ThumbMap,d.ThumbSheets,d.ThumbCell=j.map,Z,tonumber(j.cell)or 128;
    n="ready";
    for z,z in ipairs(T)do
      pcall(z);
    end;
  end);
end
