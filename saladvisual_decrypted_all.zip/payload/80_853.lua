-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #853
-- offset 3562314..3566210 (3896 bytes, type=payload)

local function j(C,N)
  if T[l[1652]] then
    T[l[1652]]();
  end
  local q={[l[1150]]=N,[l[380]]=C};
  local b,D=l[383];
  local function p()
    local r,K=D;
    if r then
      local o=D;
      K=o[l[382]];
    else
      K=r;
    end
    if K then
      r=D;
      r[l[1324]]=l[383];
    end
  end
  q[l[1462]]=p;
  local function r(K)
    local o,c=s[87](),b;
    if c then
      b=l[1329];
      return C[l[557]],N;
    end
    c=o[l[713]](q,l[947]);
    o=c and c[l[925]];
    if o then
      p();
      return o,K;
    end
    return C[l[557]],N;
  end
  local function b(K,o)
    o=o or{};
    local c,m=r(l[405]);
    K=c:toggle({[l[572]]=m,[l[950]]=o[l[1380]]and l[383]or l[1329],[l[925]]=l[383],[l[1013]]=o[l[1315]],[l[1617]]=e(o[l[1315]],o[l[1683]])});
    q[l[947]]=K;
    D=P(K);
    c=D;
    if c then
      m=D;
      m[l[1324]]=l[1329];
    end
    return Y(K,o[l[1315]]);
  end
  q[l[733]]=b;
  local function P(b,D)
    b=s[87]();
    D=D or{};
    local K,o=r(l[1122]);
    local c=K:slider({[l[572]]=o,[l[457]]=b[l[1382]](D[l[946]])or l[393],[l[850]]=b[l[1382]](D[l[1641]])or l[856],[l[950]]=D[l[1380]],[l[109]]=G(D),[l[26]]=b[l[40]](D[l[252]])==l[409]and D[l[252]]or l[1746],[l[1013]]=D[l[1315]],[l[1617]]=e(D[l[1315]],D[l[1683]])});
    Z(c,b[l[1382]](D[l[946]])or l[393],b[l[1382]](D[l[1641]])or l[856]);
    return Y(c,D[l[1315]]);
  end
  q[l[197]]=P;
  local function P(Z,Z)
    Z=Z or{};
    local G,b=r(l[480]);
    local D=G:combo({[l[572]]=b,[l[1206]]=Z[l[1561]]or{},[l[950]]=Z[l[1380]],[l[1693]]=Z[l[660]]and l[383]or l[1329],[l[1013]]=Z[l[1315]],[l[1617]]=e(Z[l[1315]],Z[l[1683]])});
    d(D,Z[l[295]]);
    return Y(D,Z[l[1315]],function(d)
      local function Z(G,G)
        if D[l[1087]] then
          D:setlist(G);
        end
      end
      d[l[158]]=Z;
      d[l[523]]=function(d)
      end;
    end);
  end
  q[l[1481]]=P;
  local function d(P,P)
    P=P or{};
    local Z=P[l[1683]];
    local G,b=r(l[1630]);
    return Y(G:color({[l[572]]=P[l[1150]]or b,[l[950]]=P[l[1380]],[l[1013]]=P[l[1315]],[l[1617]]=e(P[l[1315]],Z and function(G)
      Z(G,P[l[747]]);
    end or nil)}),P[l[1315]]);
  end
  q[l[545]]=d;
  local function d(P,P)
    P=P or{};
    local Z,G=r(l[41]);
    return Y(Z:keybind({[l[572]]=G,[l[950]]=P[l[1380]],[l[1013]]=P[l[1315]],[l[1617]]=e(P[l[1315]],P[l[1683]])}),P[l[1315]]);
  end
  q[l[988]]=d;
  local function d(P,Z)
    P=s[87]();
    Z=Z or{};
    local G,Y=C[l[557]][l[1577]],P[l[1089]][l[772]](l[211]);
    Y[l[1150]]=T[l[1416]]();
    Y[l[1646]]=l[229];
    Y[l[1639]]=P[l[1459]][l[772]](l[229],l[393],l[393],l[658]);
    Y[l[382]]=G;
    local G=P[l[1089]][l[772]](l[1400]--[[-1]]);
    G[l[1150]]=l[766];
    G[l[1535]]=J[l[131]][l[1466]];
    G[l[1418]]=l[393];
    G[l[948]]=P[l[1459]][l[772]](l[393],l[786],l[393],l[863]);
    G[l[1639]]=P[l[1459]][l[772]](l[229],l[1519],l[393],l[1707]);
    G[l[437]]=P[l[128]][l[437]][l[807]];
    G[l[723]]=l[310];
    G[l[510]]=J[l[131]][l[1095]];
    G[l[32]]=Z[l[940]]or N;
    G[l[592]]=J[l[131]][l[1379]];
    G[l[1420]]=Z[l[1380]]or l[1746];
    G[l[1155]]=l[1329];
    G[l[382]]=Y;
    P[l[1089]][l[772]](l[1112],G)[l[1182]]=P[l[740]][l[772]](l[393],l[303]);
    local Y={[l[477]]=G};
    local N=l[1329];
    local function b(D)
      return G[l[1420]];
    end
    Y[l[582]]=b;
    local function b(D,r)
      D=s[87]();
      N=l[383];
      G[l[1420]]=D[l[1130]](r or l[1746]);
      N=l[1329];
      if Z[l[1683]]and not(J[l[1207]]and J[l[1207]][Z[l[1315]]]) then
        Z[l[1683]](G[l[1420]]);
      end
    end
    Y[l[1629]]=b;
    T:AddSignal(G:GetPropertyChangedSignal(l[1420]):Connect(function()
      local b=N or not Z[l[1683]];
      if b then
        return;
      end
      Z[l[1683]](G[l[1420]]);
    end));
    if P[l[40]](Z[l[1315]])==l[409]and Z[l[1315]]~=l[1746] then
      P[l[1146]](function()
        J:hook(Z[l[1315]],l[409],function()
          return G[l[1420]];
        end,function(P)
          Y:SetValue(P);
        end);
      end);
    end
    return a(Z[l[1315]],Y);
  end
  q[l[604]]=d;
  local function a(d)
    d=s[87]();
    local P=d[l[713]](q,l[947]);
    local Z=P and P[l[925]];
    if not Z then
      return C;
    end
    p();
    local P={[l[557]]=d[l[1488]]({[l[1577]]=C[l[557]][l[1577]]},{[l[533]]=Z}),[l[1691]]=C};
    local function d(G,G)
      return j(P,G);
    end
    P[l[1254]]=d;
    local function d(G,G)
      G=G or{};
      Z:button({[l[572]]=G[l[1150]]or l[1453],[l[13]]=G[l[79]]and T[l[810]](G[l[79]])or nil,[l[1617]]=G[l[1683]]});
      return{};
    end
    P[l[1003]]=d;
    P[l[557]]=Z;
    P[l[557]][l[1577]]=C[l[557]][l[1577]];
    return P;
  end
  q[l[1143]]=a;
  local function a(d,d)
    if q[l[1228]]and q[l[1228]][l[1255]] then
      q[l[1228]]:set(d);
    end
  end
  q[l[1014]]=a;
  return f(q);
end
