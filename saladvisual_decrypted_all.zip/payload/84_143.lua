-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #143
-- offset 3694465..3694684 (219 bytes, type=payload)

function()
  task.wait(0.6);
  local s;
  local s=G[4][G[6]]and H.On;
  if s then
    local s=z;
    local n=s.CameraMaxZoomDistance~=2048;
    if n then
      local s,n=z;
      n,H.Max,H.Min=z,s.CameraMaxZoomDistance,z.CameraMinZoomDistance;
    end
    a();
  end
end
