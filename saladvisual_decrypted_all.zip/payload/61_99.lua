-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #99
-- offset 132931..135772 (2841 bytes, type=payload)

local function p(o,c,A,F,h,W,V)
  local _,X=c.trees,c.scripts;
  if c.mode=="rig" then
    local x=A:FindFirstChild("UpperTorso")~=nil and(c.r15 or c.r6)or(c.r6 or c.r15);
    _,X={},x and x.scripts or{};
    for k,v in ipairs(x and x.limbs or{})do
      _[k]=v;
    end;
    if c.aura then
      _[#_+1]=c.aura;
    end
  else
  end
  local x,k={map={},refs={},char=A,limbKids={}},{};
  for v,I in ipairs(_)do
    v=f(I,x);
    if v then
      k[#k+1]=v;
    end
  end;
  local f,_=V and not V()or h and not A.Parent or not h and(A~=C()or J[o]~=F);
  V=f or not y[4][y[6]];
  if V then
    for _,_ in ipairs(k)do
      pcall(function()
        _:Destroy();
      end);
    end;
    for _,_ in ipairs(x.limbKids)do
      pcall(function()
        _[1]:Destroy();
      end);
    end;
    return;
  end
  local _,v,I,i={item=c,char=A,made={},conns={},undo={},tasks={},roots={},worn={},transforms={},alive=true,scripts=X,group=F,guest=h~=nil},c.kind=="Trail"and"Trail_"or"Aura_",{},{};
  for X,E in ipairs(k)do
    if c.mode=="parts"and E:IsA("BasePart") then
      X=E.Name;
      f,F=e(A,X);
      if not f then
        f,F=e(A,"HumanoidRootPart");
      else
      end
      if f then
        V=f.CFrame*F*E.CFrame:Inverse();
        for Q,Q in ipairs(s(E))do
          Q.CFrame=V*Q.CFrame;
        end;
        E.Transparency=1;
        E.Name=v..X;
        _.roots[X]=E;
        I[#I+1]={E,f,F};
      else
        E:Destroy();
      end
    elseif c.mode=="rig"and E:IsA("BasePart") then
      local X=e(A,"HumanoidRootPart");
      if X then
        E.Name="Aura";
        local Q=Instance.new("Attachment");
        Q.Name="AuraMount";
        Q.Parent=E;
        Q=X:FindFirstChildOfClass("Attachment");
        local t=Q and Q.CFrame or CFrame.new();
        for Q,Q in ipairs(s(E))do
          Q.CFrame=X.CFrame*t*E.CFrame:Inverse()*Q.CFrame;
        end;
        E.Transparency=1;
        I[#I+1]={E,X,t,true};
      else
        E:Destroy();
      end
    elseif c.mode=="attach"and E:IsA("Attachment") then
      local X,Q=e(A,"Torso");
      if X then
        E.CFrame=Q*E.CFrame;
        E.Name=c.kind=="Trail"and"Trail"or"AuraAttachment";
        I[#I+1]={E,X};
      else
        E:Destroy();
      end
    elseif c.mode=="trail"and E:IsA("Trail") then
      local X,Q=e(A,"Torso");
      if X then
        local e,A,t=tonumber(c.width)or 1,Instance.new("Attachment"),Instance.new("Attachment");
        A.Name="LeftTrail";
        t.Name="RightTrail";
        A.CFrame,t.CFrame=Q*CFrame.new(-e,0,0),Q*CFrame.new(e,0,0);
        A.Parent=X;
        t.Parent=X;
        E.Attachment0=A;
        E.Attachment1=t;
        _.made[#_.made+1]=A;
        _.made[#_.made+1]=t;
        I[#I+1]={E,X};
      else
        E:Destroy();
      end
    else
      E:Destroy();
    end
  end;
  for e,A in ipairs(x.limbKids)do
    e,f,k=A[1],A[2],A[3];
    if k then
      A=f.CFrame*k:Inverse();
      for X,X in ipairs(s(e))do
        X.CFrame=A*X.CFrame;
      end;
    end
    if e:IsA("Attachment") then
      V=f:FindFirstChild(e.Name);
      if V and(V:IsA("Attachment")) then
        e.CFrame=V.CFrame;
      end
    end
    _.roots[f.Name]=f;
  end;
  for s,s in ipairs(x.refs)do
    local e=x.map[s[3]];
    if e then
      pcall(function()
        s[1][s[2]]=e;
      end);
    end
  end;
  for s,s in ipairs(x.limbKids)do
    s[1].Parent=s[2];
    _.made[#_.made+1]=s[1];
    i[#i+1]=s[1];
  end;
  for s,s in ipairs(I)do
    F,f,v,V=s[1],s[2],s[3],s[4];
    F.Parent=f;
    if v then
      x=Instance.new("Weld");
      x.Name="Weld";
      x.Part0=f;
      x.Part1=F;
      x.C0,x.C1=v,CFrame.new();
      x.Parent=F;
    end
    _.made[#_.made+1]=F;
    i[#i+1]=F;
  end;
  _.worn=i;
  r(_);
  S(_,i);
  (h or l)[o]=_;
  D(_);
  w(c,_,W);
end
