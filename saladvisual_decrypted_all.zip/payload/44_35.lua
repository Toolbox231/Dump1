-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #35
-- offset 3623492..3623750 (258 bytes, type=payload)

function()
  local y;
  local y=J[4][J[6]];
  if not y then
    return;
  end
  local z={};
  for T,d in ipairs(e)do
    T=Z[d];
    local P,Z=pcall(C,T);
    if P and type(Z)=="string"and Z~="" then
      z[d]=Z;
    end
    task.wait();
  end;
  y=J[4][J[6]];
  if y then
    pcall(function()
      l:setdata(L(z));
    end);
  end
end
