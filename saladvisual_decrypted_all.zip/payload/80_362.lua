-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #362
-- offset 3400481..3401164 (683 bytes, type=payload)

function(yC)
  local TC={};
  local nC=s[87]();
  if yC[l[1317]]~=nC[l[128]][l[1317]][l[1356]]and yC[l[1317]]~=nC[l[128]][l[1317]][l[239]] then
    return;
  end
  local JC=UP;
  if JC then
    return;
  end
  UP=l[383];
  MP=yC[l[1317]]==nC[l[128]][l[1317]][l[239]]and yC or nil;
  JC=sC;
  if JC then
    sC:Disconnect();
  end
  TC[1]=(y[10][l[756]]:Connect(function()
    local nC,JC,HC=s[87](),MP;
    if JC then
      local JC=MP;
      local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
      if fC then
        HC=fC;
      else
        JC=MP;
        HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
      end
    else
      HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
    end
    if not HC then
      iP();
    end
  end));
  sC=TC[1];
  O(l[229]);
  J();
  VP[l[1195]]=l[1329];
  y[18]:chime(l[1320]);
  gP:set(tP(IP(yC)));
end
