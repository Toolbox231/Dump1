-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #65
-- offset 127702..128098 (396 bytes, type=payload)

function()
  local B=w:GetState();
  if B==Enum.HumanoidStateType.Dead or not(F.Parent and c.Parent) then
    h:Disconnect();
    return;
  end
  local w=B==Enum.HumanoidStateType.Running;
  if F.Enabled~=w then
    F.Enabled=w;
  end
  if c.Enabled~=w then
    c.Enabled=w;
  end
  B=math.min((A.AssemblyLinearVelocity*Vector3.new(1,0,1)).Magnitude*2,m);
  B=B<=3 and 0 or B;
  if F.Rate~=B then
    F.Rate=B;
  end
  if c.Rate~=B then
    c.Rate=B;
  end
end
