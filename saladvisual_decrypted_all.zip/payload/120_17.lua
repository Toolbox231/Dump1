-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #17
-- offset 3652084..3652537 (453 bytes, type=payload)

local function X(x)
  local k=F(x,"HumanoidRootPart");
  if not k then
    return;
  end
  local x,v=h(k,CFrame.new(0,-3,0)),Instance.new("ParticleEmitter");
  v.LightInfluence=1;
  v.LockedToPart=true;
  v.LightEmission=1;
  v.Color=ColorSequence.new(N.Color);
  v.Speed=NumberRange.new(0.01,0.01);
  v.Size=NumberSequence.new(6,10);
  v.RotSpeed=NumberRange.new(360,360);
  v.Rate=1;
  v.Texture="rbxassetid://8553497052";
  v.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  O(v,x);
end
