-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #2
-- offset 197666..205889 (8223 bytes, type=payload)

function()
  local s;
  local s=l;
  local a=s.WorldFX;
  local d,P={On=false,Count=20,Rate=150,Speed=100,Length=100,Size=100,Life=4,Distance=260,Preset="Perseids",Head=Color3.fromRGB(255,249,230),Tail=Color3.fromRGB(140,185,255),Fireballs=true,Stars=true,HeadSize=14,Active=0,Allocated=0,ThroughWalls=false},l;
  P.Starfall=d;
  local Z={"Perseids","Leonids","Gentle Shower"};
  local G,Y,e={Perseids={direction=Vector3.new(0.92,-0.62,0.28).Unit,speed=76,spread=0.12},Leonids={direction=Vector3.new(-0.75,-0.9,0.45).Unit,speed=108,spread=0.1},["Gentle Shower"]={direction=Vector3.new(0.4,-0.85,-0.3).Unit,speed=48,spread=0.16}},80,96;
  local j,C,N,q,b,D,p,r=Random.new(),{},{},{};
  local K,o,c,m,S=0,false;
  for O=0,e,1 do
    P=O/e;
    N[O]=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.35,1-P*0.12),NumberSequenceKeypoint.new(0.75,1-P*0.72),NumberSequenceKeypoint.new(0.96,1-P*0.98),NumberSequenceKeypoint.new(1,1-P*0.45)});
    q[O]=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.65,1-P*0.1),NumberSequenceKeypoint.new(0.93,1-P*0.28),NumberSequenceKeypoint.new(1,1-P*0.08)});
  end;
  local O,B,A;
  local function w(F)
    local h=b and b.Parent;
    if h then
      return true;
    end
    local W;
    h=L;
    local W,V=h.asset("trail/bloom.png")or"",L;
    local _,X=V.asset("particles/p_glow.png")or"rbxasset://textures/particles/sparkles_main.dds",L;
    local L,x=X.asset("particles/star_user.png")or _;
    X=not y[4][y[6]]or not d.On or F~=K;
    if X then
      return false;
    end
    O,B,A=W,_,L;
    b=Instance.new("Part");
    b.Name="VisualsStarfall";
    W,V,X=b,b,b;
    b.Anchored=true;
    W.CanCollide=false;
    V.CanTouch=false;
    X.CanQuery=false;
    F,_,h,V=b,b,b,Vector3.new(1.0,1.0,1.0);
    F.Transparency=1;
    _.CastShadow=false;
    h.Size=V;
    local L;
    local L,h=z;
    F=T;
    b:SetAttribute(L,F);
    _=b;
    _.Parent=workspace;
    return true;
  end
  local function L()
    local z=Instance.new("Attachment");
    local T,F=Instance.new("Attachment"),b;
    z.Parent,T.Parent=F,F;
    local function h(W)
      local V=Instance.new("Beam");
      V.Attachment0=z;
      V.Attachment1=T;
      V.FaceCamera=true;
      V.LightInfluence=0;
      V.LightEmission=1;
      V.Texture=W;
      V.TextureSpeed=0;
      V.Segments=8;
      W=nil;
      W,V.Width0,V.Enabled=b,0,false;
      V.Parent=W;
      return V;
    end
    F=Instance.new("BillboardGui");
    F.Adornee,F.AlwaysOnTop=T,d.ThroughWalls;
    F.LightInfluence=0;
    local W,V=UDim2.fromScale(1,1),b;
    F.Size=W;
    F.Enabled=false;
    F.Parent=V;
    V=Instance.new("ImageLabel");
    V.BackgroundTransparency,V.Size=1,UDim2.fromScale(1,1);
    V.Image=B;
    V.Parent=F;
    W=Instance.new("ImageLabel");
    W.BackgroundTransparency,W.Size=1,UDim2.fromScale(0.85,0.85);
    W.AnchorPoint,W.Position=Vector2.new(0.5,0.5),UDim2.fromScale(0.5,0.5);
    W.Image=A;
    W.Rotation=15;
    W.Parent=F;
    local B={tail=z,nose=T,line=h(""),haze=h(O),card=F,blob=V,star=W,busy=false};
    return B;
  end
  local function z(T)
    T.busy,T.line.Enabled,T.haze.Enabled,T.card.Enabled=false,false,false,false;
  end
  local function T(O)
    local B,A,F=math.floor(a.Number(d.Count,20,1,Y)),0;
    for h,h in ipairs(C)do
      if h.busy then
        A=A+1;
      else
        F=if not F then h else F;
      end
    end;
    if not F or A>=B then
      return false;
    end
    local B,A=G[d.Preset]or G.Perseids,O.CFrame.LookVector;
    local G,h=math.atan2(A.Z,A.X)+j:NextNumber(-1.45,1.45),d.Distance*j:NextNumber(0.7,1.2);
    F.origin=O.CFrame.Position+Vector3.new(math.cos(G)*h,h*j:NextNumber(0.5,1),math.sin(G)*h);
    G=Vector3.new(j:NextNumber(-B.spread,B.spread),j:NextNumber(-0.06,0.06),j:NextNumber(-B.spread,B.spread));
    F.velocity=(B.direction+G).Unit*B.speed*j:NextNumber(0.85,1.15);
    F.fire=d.Fireballs and j:NextNumber()<0.07;
    F.mass=F.fire and j:NextNumber(1.7,2.2)or j:NextNumber(0.45,1.1);
    F.life=d.Life*j:NextNumber(0.85,1.15)*(F.fire and 1.2 or 1);
    F.age=0;
    F.travel=0;
    F.busy=true;
    return true;
  end
  local function G(O)
    local B;
    local B=not y[4][y[6]]or not d.On or not b or not b.Parent;
    if B then
      return;
    end
    local A;
    B=n;
    local A=B.camera();
    if not A then
      return;
    end
    O=math.clamp(O,0,0.1);
    B=A.CFrame.Position;
    local F=r and(B-r).Magnitude>d.Distance*2;
    if F then
      for h,h in ipairs(C)do
        z(h);
      end;
      p=0;
    end
    r=B;
    F=math.floor(a.Number(d.Count,20,1,Y));
    for h=1,math.min(3,F-#C),1 do
      C[#C+1]=L();
    end;
    d.Allocated=#C;
    local L=c;
    local h,W=L~=d.Head;
    if h then
      W=h;
    else
      L=m;
      W=L~=d.Tail;
    end
    if W then
      local V,_,X=d.Head,d.Tail,ColorSequence.new(d.Tail,d.Head);
      c,m,S=V,_,X;
    end
    p-=O;
    h=p<=0;
    if h then
      T(A);
      p=60/d.Rate*j:NextNumber(0.8,1.2);
    end
    A,h=ipairs,0;
    for T,j in A(C)do
      W=j.busy;
      if W then
        h+=1;
        L=h>F;
        if L then
          z(j);
          h-=1;
        else
          j.age=j.age+O;
          j.travel=j.travel+O*d.Speed/100;
          T=a.MeteorPoint(j.origin,j.velocity,j.travel);
          local L=a.Smooth((T.Y-B.Y-10)/40);
          local c=j.age>=j.life or L<=0;
          if c then
            z(j);
            h-=1;
          else
            local c,m=a.Envelope(j.age,j.life,0.1,0.32)*L,math.min(j.travel*j.velocity.Magnitude,(30+j.mass*22)*d.Length/100);
            local L=j.travel-m/j.velocity.Magnitude;
            m=a.MeteorPoint(j.origin,j.velocity,L);
            j.nose.WorldCFrame=a.Frame(T,j.velocity+Vector3.new(0,-3.6*j.travel,0));
            j.tail.WorldCFrame=a.Frame(m,j.velocity+Vector3.new(0,-3.6*L,0));
            local O,B,A,F=math.floor(math.clamp(c,0,1)*e+0.5),0.55*j.mass*d.Size/100,(T-m).Magnitude/3,j.colors~=S;
            if F then
              local T,e,F,W,V,_=j.line,j.haze,j.blob,S,S,d.Head;
              T.Color=W;
              e.Color=V;
              F.ImageColor3=_;
              j.star.ImageColor3=d.Head;
              j.colors=S;
            end
            if j.level~=O then
              j.line.Transparency,j.haze.Transparency=N[O],q[O];
              j.level=O;
            end
            j.line.Width1,j.haze.Width1=B,B*3.4;
            j.line.CurveSize0,j.line.CurveSize1=A,A;
            j.haze.CurveSize0,j.haze.CurveSize1=A,A;
            j.line.Enabled,j.haze.Enabled,j.card.Enabled=c>0.005,c>0.005,c>0.005;
            A=n;
            A.FxDepth(j.line,d.ThroughWalls);
            L=n;
            L.FxDepth(j.haze,d.ThroughWalls);
            j.card.AlwaysOnTop=d.ThroughWalls;
            m=d.HeadSize*(j.fire and 1.35 or 1);
            j.card.Size=UDim2.fromOffset(m,m);
            O,L=j.blob,d.Stars and 0.35 or(j.fire and 0.9 or 0.72);
            O.ImageTransparency=1-c*L;
            j.star.ImageTransparency=d.Stars and 1-c*0.95 or 1;
          end
        end
      else
      end
    end;
    d.Active=h;
  end
  local function L()
    K+=1;
    o,r,p=false,nil,0;
    local T=D;
    if T then
      D:Disconnect();
      D=nil;
    end
    for T,T in ipairs(C)do
      z(T);
    end;
    d.Active=0;
  end
  local function z()
    local T;
    local T=D or o or not y[4][y[6]]or not d.On;
    if T then
      return;
    end
    o=true;
    local T=K;
    task.spawn(function()
      local n,e=pcall(w,T);
      local j=K;
      if T~=j then
        return;
      end
      o=false;
      if not n then
        L();
        warn("[visuals] Starfall: "..tostring(e));
        return;
      end
      j=not e or not y[4][y[6]]or not d.On;
      if j then
        return;
      end
      p=0;
      local y;
      e=J;
      D=e.RenderStepped:Connect(G);
    end);
  end
  local y;
  P=H;
  s=P.Starfall:AddLabel("Starfall");
  s:AddToggle({Default=false,Flag="starfall",Callback=function(y)
    d.On=y==true;
    if d.On then
      z();
    else
      L();
    end
  end});
  s:AddColorPicker({Default=d.Head,Flag="starfall_head",Callback=function(y)
    d.Head=y;
  end});
  P=H;
  P.Starfall:AddLabel("Shower Preset"):AddDropdown({Default="Perseids",Values=Z,Flag="starfall_preset",Callback=function(y)
    d.Preset=table.find(Z,y)and y or"Perseids";
  end});
  P=H;
  P.Starfall:AddLabel("Max Stars"):AddSlider({Min=1,Max=Y,Default=20,Rounding=0,Size=100,Flag="starfall_count",Callback=function(y)
    d.Count=a.Number(y,20,1,Y);
  end});
  P=H;
  local y,z=P.Starfall:AddLabel("Spawn Rate"),{Min=2,Max=600,Default=150,Rounding=0,Type="/min",Size=100,Flag="starfall_rate"};
  z.Callback=function(T)
    d.Rate=a.Number(T,150,2,600);
    p=0;
  end;
  y:AddSlider(z);
  P=s:AddOption(1);
  P:AddLabel("Tail Color"):AddColorPicker({Default=d.Tail,Flag="starfall_tail",Callback=function(s)
    d.Tail=s;
  end});
  y={{"Travel Speed","starfall_speed",20,250,100,"%",function(s)
    d.Speed=a.Number(s,100,20,250);
  end},{"Tail Length","starfall_length",20,260,100,"%",function(s)
    d.Length=a.Number(s,100,20,260);
  end},{"Size","starfall_size",20,250,100,"%",function(s)
    d.Size=a.Number(s,100,20,250);
  end},{"Lifetime","starfall_life",1,12,4,"s",function(s)
    d.Life=a.Number(s,4,1,12);
  end},{"Sky Distance","starfall_distance",100,500,260,"",function(s)
    d.Distance=a.Number(s,260,100,500);
  end}};
  for s,s in ipairs(y)do
    P:AddLabel(s[1]):AddSlider({Min=s[3],Max=s[4],Default=s[5],Type=s[6],Rounding=0,Size=100,Flag=s[2],Callback=s[7]});
  end;
  P:AddLabel("Bright Meteors"):AddToggle({Default=true,Flag="starfall_fireballs",Callback=function(s)
    d.Fireballs=s;
  end});
  P:AddLabel("Star Heads"):AddToggle({Default=true,Flag="starfall_stars",Callback=function(s)
    d.Stars=s;
  end});
  P:AddLabel("Head Size"):AddSlider({Min=3,Max=64,Default=14,Rounding=0,Type="px",Size=100,Flag="starfall_head_size",Callback=function(s)
    d.HeadSize=a.Number(s,14,3,64);
  end});
  local s,z=l;
  y=f;
  s.ClearStarfall=y("starfall",function()
    d.On=false;
    L();
    local s=b;
    if s then
      b:Destroy();
      b=nil;
    end
    table.clear(C);
    d.Allocated=0;
  end);
end
