-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #80
-- offset 3683353..3685264 (1911 bytes, type=payload)

local function Q()
  local t=Instance.new("TextButton");
  t.Name="CatalogCard";
  t.ClipsDescendants=true;
  t.BackgroundColor3=r;
  t.BorderSizePixel=0;
  t.ZIndex=21;
  t.AutoButtonColor=false;
  t.Text="";
  Instance.new("UICorner",t).CornerRadius=UDim.new(0,6);
  local R=Instance.new("UIStroke",t);
  R.Color=m;
  R.Thickness=1;
  R.Transparency=0.45;
  local g,u=Instance.new("UIScale",t),Instance.new("ImageLabel",t);
  u.Name="Thumb";
  u.ZIndex=22;
  u.BackgroundTransparency=1;
  u.ScaleType=Enum.ScaleType.Fit;
  u.Size,u.Position=UDim2.new(1,-16,0,D-44),UDim2.fromOffset(8,7);
  local U=Instance.new("TextLabel",t);
  U.Name="Title";
  U.ZIndex=23;
  U.BackgroundTransparency=1;
  local M=n;
  U.FontFace=M.BuiltInRegular;
  U.TextSize=12;
  U.TextColor3=c;
  U.TextWrapped,U.TextTruncate=false,Enum.TextTruncate.AtEnd;
  U.TextXAlignment=Enum.TextXAlignment.Center;
  U.Size,U.Position=UDim2.new(1,-10,0,16),UDim2.fromOffset(5,D-26);
  M=Instance.new("TextLabel",t);
  M.Name,M.Text,M.Font="Favorite","\226\152\133",Enum.Font.GothamBold;
  M.ZIndex=24;
  M.TextSize=17;
  M.BackgroundTransparency=1;
  M.TextColor3=Color3.fromRGB(255,211,104);
  M.TextTransparency=1;
  M.Position,M.Size=UDim2.fromOffset(5,3),UDim2.fromOffset(20,20);
  local sP=Instance.new("Frame",t);
  sP.Name="ActiveDot";
  sP.ZIndex=24;
  sP.BorderSizePixel=0;
  sP.AnchorPoint,sP.Position=Vector2.new(1,0),UDim2.new(1,-7,0,8);
  sP.Size=UDim2.fromOffset(7,7);
  sP.BackgroundColor3=T;
  sP.BackgroundTransparency=1;
  Instance.new("UICorner",sP).CornerRadius=UDim.new(1,0);
  local T={card=t,img=u,label=U,stroke=R,scale=g,dot=sP,star=M,active=0,hover=0,favorite=0,pulse=0};
  local function R()
    T.hovered=true;
  end
  t.MouseEnter:Connect(R);
  local function R()
    T.hovered=false;
  end
  t.MouseLeave:Connect(R);
  local function R()
    if not T.entry or not x() then
      return;
    end
    local g,u=T.entry,T.key;
    T.pulse=1;
    h.onClick(g,u);
  end
  t.MouseButton1Click:Connect(R);
  local function R()
    if T.entry and x()and h.onFav then
      h.onFav(T.entry,T.key);
    end
  end
  t.MouseButton2Click:Connect(R);
  return T;
end
