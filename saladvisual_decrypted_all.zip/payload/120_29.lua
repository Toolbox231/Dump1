-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #29
-- offset 3655829..3657638 (1809 bytes, type=payload)

local function T(k)
  local v;
  local v=z[4][z[6]];
  if not v then
    return;
  end
  v=not(N.On and N.Types.Comet)and F<=0;
  if v then
    E();
    return;
  end
  local t;
  v=n;
  local t=v.Character;
  local R,g=t and(t:FindFirstChild("UpperTorso")or t:FindFirstChild("Torso")or t:FindFirstChild("HumanoidRootPart")),y;
  v=g.camera();
  local y,u,U=N.On and N.Types.Comet and R and R:IsA("BasePart")and v,math.clamp,F;
  F=u(U+(y and k or-k)/0.35,0,1);
  u=not R or not v or F<=0;
  if u then
    g=F<=0 and not(N.On and N.Types.Comet);
    if g then
      E();
    else
      i();
    end
    return;
  end
  j+=k;
  g=j;
  if g<0.03333333333333333 then
    return;
  end
  j%=0.03333333333333333;
  g=L;
  if not g.Visibility.Part(v,R,t) then
    i();
    return;
  end
  g=O;
  if not g then
    Q();
    i();
    return;
  end
  g,k,y=math.clamp(math.floor(N.TrailLength),20,300),math.max(1.5,(v.CFrame.Position-R.Position).Magnitude),DateTime.now().UnixTimestampMillis;
  u,t=math.clamp(N.BloomSize*N.Size*v.ViewportSize.Y/720/k,1,160),I;
  U=t~=N.Color;
  I=N.Color;
  k,t=g-1,0;
  for j=0,k,1 do
    local k=0.1*(y-j*1.5*300/g*N.TrailStep)/(30/N.Speed);
    local I,i,M=math.sin(k)*N.Radius,math.cos(k)*N.Radius,j/g;
    local g,sP,lP=math.max(1,u*(1-M)^1.1),math.clamp,F;
    k=sP(lP*(1-M*M)*0.4*N.Glow*0.5,0,0.95);
    for u=1,3,1 do
      sP=u==1 and Vector3.new(I,i,-i)or u==2 and Vector3.new(-I,I,-i)or Vector3.new(-I,-I,i);
      t+=1;
      lP=c[t];
      u=not lP;
      if u then
        lP=Instance.new("ImageLabel");
        lP.Name="VisualsCometBloom";
        lP.BackgroundTransparency=1;
        lP.BorderSizePixel=0;
        local I,i=Vector2.new(0.5,0.5),O;
        lP.AnchorPoint=I;
        lP.Image=i;
        lP.ImageColor3=N.Color;
        lP.Parent=s;
        c[t]=lP;
      else
      end
      if U then
        lP.ImageColor3=N.Color;
      end
      M,u=v:WorldToViewportPoint(R.Position+sP);
      lP.Visible=u and M.Z>0 and k>0.005;
      if lP.Visible then
        lP.Position,lP.Size=UDim2.fromOffset(M.X,M.Y),UDim2.fromOffset(g,g);
        lP.ImageTransparency=1-k;
        lP.Rotation=(y/5+j*5)%180;
      end
    end;
  end;
  for s=#c,t+1,-1 do
    c[s]:Destroy();
    c[s]=nil;
  end;
end
