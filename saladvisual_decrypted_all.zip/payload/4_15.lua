-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #15
-- offset 3248750..3249275 (525 bytes, type=payload)

local function S(B,A,w)
  B.NativeActive=true;
  if not B.NativeAdded then
    B.NativeAdded=A.DescendantAdded:Connect(function(F)
      if B.NativeActive then
        O(B,A,B.AuraPart or w,F);
      end
    end);
    B.NativeSweep=0;
  end
  local F=os.clock();
  if F<B.NativeSweep then
    return;
  end
  B.NativeSweep=F+0.25;
  for F,h in pairs(B.Native or{})do
    if not F.Parent or not F:IsDescendantOf(A) then
      h.Connection:Disconnect();
      if F.Parent then
        pcall(function()
          F[h.Property]=h.Value;
        end);
      end
      B.Native[F]=nil;
    end
  end;
  for F,F in ipairs(A:GetDescendants())do
    O(B,A,w,F);
  end;
end
