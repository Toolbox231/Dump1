-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #19
-- offset 10499..11527 (1028 bytes, type=payload)

function()
  local l=Instance.new("Attachment");
  l.Parent=w;
  local T,n=math.clamp(e.Bright/100,0,1),Instance.new("ParticleEmitter");
  n.Texture=j;
  n.Color=ColorSequence.new(e.Color);
  n.LightEmission=1;
  n.LightInfluence=0;
  n.Rate=0;
  n.Lifetime=NumberRange.new(e.Life);
  n.Speed=NumberRange.new(0.01);
  n.Drag=0;
  n.Acceleration=Vector3.new(0.0,0.0,0.0);
  n.VelocityInheritance=0;
  n.EmissionDirection=Enum.NormalId.Top;
  n.Rotation=NumberRange.new(0);
  n.RotSpeed=NumberRange.new(e.Spin);
  n.ZOffset=0;
  pcall(function()
    n.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  end);
  n.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,e.Size*0.35),NumberSequenceKeypoint.new(0.4,e.Size),NumberSequenceKeypoint.new(1,e.Size*e.Grow/100)});
  n.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1-T),NumberSequenceKeypoint.new(0.6,1-T*0.55),NumberSequenceKeypoint.new(1,1)});
  if B.frames and L[B.cols] then
    pcall(function()
      n.FlipbookLayout=L[B.cols];
      n.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
    end);
  end
  n.Parent=l;
  n:Emit(1);
  s.Enabled=false;
end
