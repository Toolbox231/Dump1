-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #135
-- offset 3692926..3693187 (261 bytes, type=payload)

function()
  local T,J=-1,-1;
  while true do
    local H,d=l.Alive;
    if H then
      local Z=n;
      d=Z.ScreenGui.Parent;
    else
      d=H;
    end
    if not d then
      break;
    end
    d,H=#(l.EmoteCatalog or{}),#(l.PackCatalog or{});
    if d~=T or H~=J then
      pcall(c);
      pcall(a);
      T,J=d,H;
    else
    end
    task.wait(2);
  end;
end
