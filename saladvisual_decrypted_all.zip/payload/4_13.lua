-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #13
-- offset 3248359..3248749 (390 bytes, type=payload)

local function O(B,A,w,F)
  if B.Native and B.Native[F] then
    return;
  end
  local h,W=S(F,w);
  if not h then
    return;
  end
  B.Native=B.Native or{};
  local S={Property=h,Value=F[h]};
  B.Native[F]=S;
  S.Connection=F:GetPropertyChangedSignal(h):Connect(function()
    if not(B.NativeActive and Y.On and Y.Aura and F.Parent and F:IsDescendantOf(A)) then
      return;
    end
    if F[h]~=W then
      S.Value=F[h];
      F[h]=W;
    end
  end);
  F[h]=W;
end
