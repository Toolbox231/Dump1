-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #255
-- offset 3362760..3380911 (18151 bytes, type=payload)

local function SP(BP,wP,FP,hP,WP)
  local VP,_P=s[87](),{[l[404]]=l[1329],[l[1273]]=l[1329],[l[230]]=nil,[l[649]]=l[524],[l[1019]]=l[393],[l[559]]=l[1753],[l[434]]=l[393]};
  local XP=WP[l[1019]];
  if XP then
    _P[l[1019]]=VP[l[1382]](XP[l[950]])or XP[l[457]]or l[393];
  end
  local xP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1526]},YP);
  local kP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1282]},YP)or nil;
  local vP=kP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=VP[l[740]][l[772]](l[393],l[829]),[l[1485]]=VP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=VP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},kP)or nil;
  if kP then
    D(kP,l[930]);
  end
  local IP=a(l[1751],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[219]},YP);
  D(IP,l[930]);
  local iP,EP=l[1622],{[l[500]]=l[117]};
  EP[l[1630]]=VP[l[1262]][l[772]]({VP[l[527]][l[772]](l[393],VP[l[360]][l[772]](l[229],l[229],l[229])),VP[l[527]][l[772]](l[229],VP[l[360]][l[353]](l[291],l[291],l[920]))});
  a(iP,EP,IP);
  a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},IP);
  iP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[520]},IP);
  D(iP,l[930]);
  a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},iP);
  EP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[1596]--[[__newindex]]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},IP);
  D(EP,l[930]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[393],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},EP);
  local QP,tP,RP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1274],l[229],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[368]},EP),l[755],{[l[101]]=VP[l[128]][l[101]][l[1505]],[l[1749]]=VP[l[128]][l[1749]][l[46]],[l[1259]]=VP[l[128]][l[1259]][l[46]],[l[407]]=VP[l[128]][l[407]][l[537]]};
  RP[l[536]]=VP[l[740]][l[772]](l[393],l[1092]);
  a(tP,RP,QP);
  local gP=a;
  local uP=l[859];
  local UP={};
  UP[l[1150]]=f();
  UP[l[1639]]=VP[l[1459]][l[588]](l[750],l[750]);
  UP[l[1646]]=l[229];
  UP[l[1451]]=y[30](l[1680]);
  UP[l[936]]=R[l[98]];
  UP[l[2]]=l[841];
  UP[l[537]]=l[229];
  UP[l[1557]]=VP[l[128]][l[1557]][l[220]];
  UP[l[711]]=l[1289];
  gP(uP,UP,QP);
  a(l[1070],{[l[1150]]=f(),[l[1347]]=VP[l[128]][l[1347]][l[1437]],[l[1639]]=VP[l[1459]][l[588]](l[393],l[829]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=wP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[537]]=l[59],[l[711]]=l[1289]},QP);
  K(a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1596]--[[__newindex]]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[966]],[l[1646]]=l[986],[l[1418]]=l[393],[l[711]]=l[368]},IP),l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[820],l[263]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[70],l[263]),VP[l[677]][l[772]](l[229],l[229])});
  local gP=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1282]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=VP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[489]},IP);
  iP,EP=l[755],{[l[407]]=VP[l[128]][l[407]][l[537]]};
  EP[l[536]]=VP[l[740]][l[772]](l[393],l[786]);
  a(iP,EP,gP);
  a(l[1359],{[l[299]]=VP[l[740]][l[772]](l[393],l[1092]),[l[645]]=VP[l[740]][l[772]](l[393],l[930]),[l[1612]]=VP[l[740]][l[772]](l[393],l[1092]),[l[517]]=VP[l[740]][l[772]](l[393],l[1092])},gP);
  local uP=l[393];
  local function UP(MP)
    local sC,lC=s[87](),uP;
    uP=lC+l[229];
    local lC,LC=l[211],{[l[1150]]=f(),[l[1639]]=sC[l[1459]][l[772]](l[229],l[393],l[393],MP),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=uP,[l[711]]=l[489]};
    return a(lC,LC,gP);
  end
  local function uP(MP,sC,lC,LC)
    local yC=s[87]();
    return a(l[1070],{[l[1150]]=f(),[l[948]]=yC[l[1459]][l[588]](l[303],lC),[l[1639]]=yC[l[1459]][l[772]](LC or l[330],l[1519],l[393],l[973]),[l[1646]]=l[229],[l[437]]=yC[l[128]][l[437]][l[1381]],[l[1420]]=sC,[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[330],[l[164]]=yC[l[128]][l[164]][l[1021]],[l[1634]]=yC[l[128]][l[1634]][l[701]],[l[711]]=l[368]},MP);
  end
  EP=UP(l[1243]);
  uP(EP,l[1686],l[786]);
  local MP=a(l[1742],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=VP[l[1459]][l[588]](l[1707],l[1707]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[711]]=l[1289]},EP);
  D(MP,l[303]);
  local sC=a;
  local lC=l[859];
  local LC={};
  LC[l[1150]]=f();
  LC[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]);
  LC[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]);
  LC[l[1639]]=VP[l[1459]][l[588]](l[1307],l[1307]);
  LC[l[1646]]=l[229];
  LC[l[1451]]=y[30](l[905]);
  LC[l[936]]=R[l[1379]];
  LC[l[2]]=l[411];
  LC[l[1557]]=VP[l[128]][l[1557]][l[220]];
  LC[l[711]]=l[1365];
  local yC=sC(lC,LC,MP);
  local sC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[662],l[659],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[1419],l[221],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},EP);
  D(sC,l[1158]);
  local lC=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},sC);
  local LC=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[711]]=l[1289]},sC);
  local zC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},sC);
  K(zC,l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[229],l[229])});
  QP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},sC);
  local TC,nC,JC,HC;
  if XP then
    tP=UP(l[1282]);
    uP(tP,l[1019],l[229]);
    JC=a(l[1070],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[393]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=VP[l[1459]][l[588]](l[616],l[973]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[1634]]=VP[l[128]][l[1634]][l[877]],[l[711]]=l[368]},tP);
    TC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[303],l[209]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[368]},tP);
    iP,RP=l[1112],{};
    RP[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
    a(iP,RP,TC);
    nC=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1289]},TC);
    local fC,aC=l[1112],{};
    aC[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
    a(fC,aC,nC);
    HC=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=VP[l[1459]][l[588]](l[393],l[352]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[829]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},tP);
  else
  end
  local tP,fC={};
  if WP[l[649]] then
    RP=UP(l[1655]);
    uP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},RP);
    D(uP,l[1158]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},uP);
    fC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[393],l[59],l[393],l[59]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[1452],l[229],l[1024]),[l[1535]]=R[l[98]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[1289]},uP);
    D(fC,l[303]);
    K(fC,l[117],{VP[l[677]][l[772]](l[393],l[393]),VP[l[677]][l[772]](l[229],l[1017])});
    a(l[734],{[l[1630]]=R[l[98]],[l[747]]=l[1567]},fC);
    iP={l[524],l[259]};
    for RP,UP in y[3],iP,nil do
      EP={[l[572]]=UP,[l[892]]=l[1329],[l[590]]=RP,[l[974]]=a(l[1742],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[659]*(RP-l[229]),l[393],l[393],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[393],l[229],l[393]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},uP)};
      EP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=UP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[711]]=l[1365]},EP[l[974]]);
      tP[RP]=EP;
    end;
  else
  end
  local iP=XP and VP[l[35]][l[850]](VP[l[1382]](XP[l[109]])or l[229],l[393])or l[393];
  local EP=XP and XP[l[1647]]or l[393];
  local RP=l[1329];
  local function uP(UP)
    local aC=s[87]();
    if EP>l[393] then
      return aC[l[409]][l[846]](l[1213]..EP..l[347],UP)..(XP[l[26]]or l[1746]);
    end
    return aC[l[409]][l[846]](l[1489],aC[l[35]][l[499]](UP+l[659]))..(XP[l[26]]or l[1746]);
  end
  local function UP(aC)
    local dC=s[87]();
    aC=dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
    aC=if iP>l[393]then XP[l[457]]+dC[l[35]][l[499]]((aC-XP[l[457]])/iP+l[659])*iP else aC;
    aC=if EP>l[393]then dC[l[1382]](dC[l[409]][l[846]](l[1213]..EP..l[347],aC))or aC else aC;
    return dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
  end
  local function iP()
    local EP=s[87]();
    if not XP then
      return;
    end
    local aC=XP[l[850]]-XP[l[457]];
    local dC=aC>l[393]and(_P[l[1019]]-XP[l[457]])/aC or l[393];
    JC[l[1420]]=uP(_P[l[1019]]);
    local uP,JC=RP and J or n,{};
    JC[l[1639]]=EP[l[1459]][l[772]](dC,EP[l[35]][l[499]](l[1158]*(l[229]-dC)+l[659]),l[229],l[393]);
    P(nC,uP,JC);
  end
  local function EP()
    local uP=s[87]();
    for nC=l[229],#tP,l[229]do
      local JC=tP[nC];
      nC=_P[l[649]]==JC[l[572]];
      P(JC[l[1615]],n,{[l[916]]=nC and l[393]or(JC[l[892]]and l[874]or l[323]),[l[510]]=nC and R[l[1095]]or R[l[1379]]});
      if nC and fC then
        P(fC,H,{[l[948]]=uP[l[1459]][l[772]](l[659]*(JC[l[590]]-l[229]),l[59],l[393],l[59])});
      end
    end;
  end
  local function uP()
    LC[l[1420]]=_P[l[548]]and l[538]or z(_P[l[230]]);
    P(sC,H,{[l[1646]]=_P[l[548]]and l[393]or l[841]});
    P(lC,H,{[l[747]]=_P[l[548]]and l[120]or l[1373]});
    P(zC,H,{[l[1646]]=_P[l[548]]and l[986]or l[229]});
    local sC,lC,zC={[l[916]]=_P[l[230]]and l[1296]or l[615]},l[510],_P[l[548]]and R[l[98]]or(_P[l[230]]and R[l[1095]]or R[l[1379]]);
    sC[lC]=zC;
    P(LC,H,sC);
    P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509]});
  end
  local function sC()
    if not _P[l[230]] then
      fP(WP[l[1463]]);
      return;
    end
    NP(WP[l[1463]],{[l[572]]=wP,[l[230]]=z(_P[l[230]]),[l[103]]=WP[l[103]],[l[194]]=WP[l[194]],[l[1204]]=WP[l[1735]]and WP[l[1735]]()or nil,[l[628]]=WP[l[1386]]and WP[l[1386]]()or l[1329]});
  end
  local function fP()
    local NP=s[87]();
    return l[1282]+NP[l[35]][l[850]](NP[l[35]][l[499]](e(gP)[l[636]]+l[659]),l[1655]);
  end
  local function NP()
    local wP,lC,LC,zC,nC,JC,fC=s[87](),G(YP),e(YP),G(FP),e(FP),G(BP),e(BP);
    local aC,dC=zC[l[1437]]-lC[l[1437]]+nC[l[1437]]+l[930],zC[l[1437]]-lC[l[1437]]-_P[l[559]]-l[930];
    nC,zC=if aC+_P[l[559]]>LC[l[1437]]-l[930]then dC>=l[930]and dC or wP[l[35]][l[850]](l[930],LC[l[1437]]-l[930]-_P[l[559]])else aC,wP[l[35]][l[819]](JC[l[636]]-lC[l[636]]+fC[l[636]]*l[659]-_P[l[434]]*l[659],l[930],wP[l[35]][l[850]](l[930],LC[l[636]]-_P[l[434]]-l[930]));
    IP[l[948]]=wP[l[1459]][l[588]](wP[l[35]][l[499]](nC+l[659]),wP[l[35]][l[499]](zC+l[659]));
    if kP then
      kP[l[948]]=IP[l[948]];
    end
  end
  local function wP()
    local lC=s[87]();
    _P[l[434]]=fP();
    IP[l[1639]]=lC[l[1459]][l[588]](_P[l[559]],_P[l[434]]);
    if kP then
      kP[l[1639]]=IP[l[1639]];
    end
  end
  local function fP()
    local lC=IP[l[1569]];
    local LC=_P[l[404]]and l[393]or l[229];
    b(IP,_P[l[404]]and l[894]or l[304],_P[l[404]]and N or q,function(zC)
      local nC=lC+(LC-lC)*zC;
      IP[l[1569]]=nC;
      if kP then
        kP[l[1646]]=nC;
        vP[l[747]]=l[615]+l[411]*nC;
      end
      if zC>=l[229] then
        IP[l[1324]]=_P[l[404]];
        if kP then
          kP[l[1324]]=_P[l[404]];
        end
      end
    end);
  end
  local vP;
  local function lC()
    local LC=vP;
    if LC then
      vP:Disconnect();
      vP=nil;
    end
  end
  local function LC()
    _P:setopen(l[1329]);
  end
  local function zC()
    local nC=S;
    if nC>l[393] then
      NP();
      return;
    end
    if not LP[l[1600]]or not KP[l[1324]]or not BP[l[1324]] then
      _P:setopen(l[1329]);
      return;
    end
    local JC,fC,aC,dC,PC,ZC=FP[l[81]],FP[l[160]],hP[l[81]],hP[l[160]],BP[l[81]],BP[l[160]];
    nC=PC[l[636]]+ZC[l[636]]*l[659];
    if nC<JC[l[636]]or nC>JC[l[636]]+fC[l[636]]or nC<aC[l[636]]or nC>aC[l[636]]+dC[l[636]] then
      _P:setopen(l[1329]);
      return;
    end
    NP();
  end
  local function BP(FP,hP)
    local nC={};
    hP=hP and l[383]or l[1329];
    if _P[l[404]]==hP then
      return;
    end
    _P[l[404]]=hP;
    if hP then
      V();
      U(_P);
      wP();
      xP[l[1324]]=l[383];
      IP[l[1324]]=l[383];
      if kP then
        kP[l[1324]]=l[383];
      end
      NP();
      A,w=LC,IP;
      lC();
      nC[1]=(y[10][l[1119]]:Connect(zC));
      vP=nC[1];
    else
      lC();
      xP[l[1324]]=l[1329];
      if _P[l[548]] then
        _P[l[548]]=l[1329];
        lP(nil);
        uP();
      end
      FP=A==LC;
      if FP then
        A,w=nil,nil;
      end
    end
    fP();
  end
  _P[l[1521]--[[0]]]=BP;
  local fP=l[393];
  local function BP(FP)
    FP=s[87]();
    local hP=FP[l[655]][l[1587]]();
    FP=hP-fP;
    if FP<l[874] then
      return l[1329];
    end
    fP=hP;
    if _P[l[404]]and(W(IP,l[59])or kP and W(kP,l[59])) then
      return l[1329];
    end
    _P:setopen(not _P[l[404]]);
    return l[383];
  end
  _P[l[1352]]=BP;
  local function BP()
    local FP=s[87]();
    if F() then
      return;
    end
    fP=FP[l[655]][l[1587]]();
    _P:setopen(l[1329]);
  end
  d(xP[l[445]],BP);
  d(xP[l[861]],BP);
  local function fP(BP,BP)
    local FP,hP=s[87](),BP;
    hP=if FP[l[40]](hP)==l[409]then FP[l[199]](l[59],FP[l[1146]](function()
      local xP=s[87]();
      return xP[l[128]][l[880]--[[readu32]]][BP];
    end))else hP;
    hP=if FP[l[1703]](hP)~=l[802]or hP==FP[l[128]][l[880]--[[readu32]]][l[605]]then nil else hP;
    if _P[l[230]]==hP then
      return;
    end
    if _P[l[1273]] then
      _P[l[1273]]=l[1329];
      WP[l[1498]](l[1329]);
    end
    _P[l[230]]=hP;
    uP();
    sC();
  end
  _P[l[1046]]=fP;
  local function fP(BP,BP)
    if BP~=l[524]and BP~=l[259] then
      return;
    end
    if _P[l[649]]==BP then
      return;
    end
    if _P[l[1273]] then
      _P[l[1273]]=l[1329];
      WP[l[1498]](l[1329]);
    end
    _P[l[649]]=BP;
    EP();
  end
  _P[l[1755]]=fP;
  local function fP(BP,FP)
    BP=s[87]();
    if not XP then
      return;
    end
    FP=UP(BP[l[1382]](FP)or XP[l[457]]);
    if _P[l[1019]]==FP then
      return;
    end
    _P[l[1019]]=FP;
    iP();
    if _P[l[230]] then
      sC();
    end
  end
  _P[l[378]]=fP;
  local function fP(BP,BP)
    _P[l[1273]]=BP and l[383]or l[1329];
  end
  _P[l[488]]=fP;
  local function fP(BP,BP)
    aP(WP[l[1463]],BP);
  end
  _P[l[628]]=fP;
  _P[l[1498]]=WP[l[1498]];
  local function fP()
    _P[l[548]]=l[1329];
    uP();
  end
  d(QP[l[445]],function()
    if _P[l[548]] then
      lP(nil);
      fP();
      return;
    end
    _P[l[548]]=l[383];
    uP();
    y[18]:chime(l[1352]);
    lP(function(aP)
      fP();
      if aP then
        _P:setkey(aP);
        y[18]:chime(l[1320]);
      end
    end,fP);
  end);
  d(MP[l[445]],function()
    if _P[l[548]] then
      lP(nil);
      fP();
    end
    if not _P[l[230]] then
      return;
    end
    _P:setkey(nil);
    yC[l[936]]=R[l[98]];
    P(yC,H,{[l[936]]=R[l[1379]]});
    y[18]:chime(l[676]);
  end);
  d(MP[l[1538]],function()
    P(MP,H,{[l[1646]]=l[330]});
    P(yC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
  end);
  d(MP[l[1628]],function()
    P(MP,H,{[l[1646]]=l[229]});
    P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509],[l[936]]=R[l[1379]]});
  end);
  for fP=l[229],#tP,l[229]do
    local aP=tP[fP];
    d(aP[l[974]][l[1538]],function()
      aP[l[892]]=l[383];
      EP();
    end);
    d(aP[l[974]][l[1628]],function()
      aP[l[892]]=l[1329];
      EP();
    end);
    d(aP[l[974]][l[445]],function()
      _P:setmode(aP[l[572]]);
      y[18]:chime(l[1320]);
    end);
  end;
  EP();
  if XP then
    local fP=l[1329];
    local function aP()
      RP=l[1329];
      local BP=fP;
      if BP then
        fP=l[1329];
        O(l[715]);
      end
    end
    d(HC[l[956]],aP);
    d(HC[l[1558]],function(BP)
      local FP=s[87]();
      if BP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and BP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
        return;
      end
      local hP=RP;
      if hP then
        return;
      end
      RP=l[383];
      fP=l[383];
      O(l[229]);
      local fP,hP=FP[l[1146]](function()
        local xP=s[87]();
        y[18]:chime(l[1320]);
        while true do
          local vP=RP and y[18][l[630]];
          if not(vP and HC[l[382]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[912]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[625]]) then
            break;
          end
          local vP,EP=TC[l[81]],TC[l[160]];
          if EP[l[1437]]>l[393] then
            _P:setvalue(XP[l[457]]+(XP[l[850]]-XP[l[457]])*xP[l[35]][l[819]]((v(BP)[l[1437]]-vP[l[1437]])/EP[l[1437]],l[393],l[229]));
          end
          xP[l[1022]][l[153]]();
        end;
      end);
      aP();
      if not fP then
        FP[l[972]](l[800]..FP[l[1130]](hP));
      end
      iP();
    end);
    d(HC[l[412]],function(fP)
      local BP=s[87]();
      if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
        aP();
      end
    end);
    d(y[9][l[412]],function(fP)
      local BP=s[87]();
      if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
        aP();
      end
    end);
    _P[l[1019]]=UP(_P[l[1019]]);
    iP();
  end
  d(gP:GetPropertyChangedSignal(l[160]),function()
    if _P[l[404]] then
      wP();
      NP();
    end
  end);
  d(y[9][l[1558]],function(fP)
    local aP,NP,BP=s[87](),not _P[l[404]];
    if NP then
      BP=NP;
    else
      local NP=S;
      BP=NP>l[393];
    end
    if BP or F() then
      return;
    end
    if fP[l[1317]]~=aP[l[128]][l[1317]][l[1356]]and fP[l[1317]]~=aP[l[128]][l[1317]][l[239]] then
      return;
    end
    if W(IP,l[59])or kP and W(kP,l[59]) then
      return;
    end
    aP[l[1022]][l[1061]](function()
      if _P[l[404]] then
        _P:setopen(l[1329]);
      end
    end);
  end);
  d(y[9][l[1558]],function(F,fP)
    local aP=s[87]();
    if fP or y[18][l[1333]]or not _P[l[230]]or not y[18][l[630]] then
      return;
    end
    if F[l[1317]]~=aP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
      return;
    end
    if not WP[l[649]] then
      WP[l[1498]](l[383]);
      return;
    end
    if _P[l[649]]==l[259] then
      if _P[l[1273]] then
        return;
      end
      _P[l[1273]]=l[383];
      WP[l[1498]](l[383]);
    else
      _P[l[1273]]=not _P[l[1273]];
      WP[l[1498]](_P[l[1273]]);
    end
  end);
  d(y[9][l[412]],function(F)
    local fP=s[87]();
    if _P[l[649]]~=l[259]or not _P[l[230]]or not _P[l[1273]] then
      return;
    end
    if F[l[1317]]~=fP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
      return;
    end
    _P[l[1273]]=l[1329];
    WP[l[1498]](l[1329]);
  end);
  uP();
  VP[l[1346]][l[968]](m,_P);
  y[18]:hook(WP[l[1463]]..l[728],l[230],function()
    return _P[l[230]]and _P[l[230]][l[1150]]or nil;
  end,function(F)
    _P:setkey(F);
  end);
  if WP[l[649]] then
    y[18]:hook(WP[l[1463]]..l[1175],l[1206],function()
      return _P[l[649]];
    end,function(F)
      _P:setmode(F);
    end,{[l[284]]=function(F)
      return F==l[524]or F==l[259];
    end});
  end
  if XP then
    y[18]:hook(WP[l[1463]]..l[562],l[384],function()
      return _P[l[1019]];
    end,function(F)
      _P:setvalue(F);
    end,{[l[457]]=XP[l[457]],[l[850]]=XP[l[850]]});
  end
  return _P;
end
