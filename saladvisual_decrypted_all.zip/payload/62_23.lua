-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #23
-- offset 3231038..3231267 (229 bytes, type=payload)

function()
  local A;
  local A=z[4][z[6]]and(X or x);
  local h=not A or k;
  if h then
    return;
  end
  k=true;
  task.defer(function()
    k=false;
    local A,h=z[4][z[6]];
    if A then
      local k;
      local k=T;
      h=k.Character==B;
    else
      h=A;
    end
    if h then
      F();
    end
  end);
end
