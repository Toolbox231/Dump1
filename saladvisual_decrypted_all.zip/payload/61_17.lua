-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #17
-- offset 112328..113228 (900 bytes, type=payload)

local function Y(e)
  if d.Loaded[e] then
    return d.Loaded[e];
  end
  local j=G[e];
  if j then
    local C=os.clock()+60;
    while true do
      task.wait(0.05);
      local N;
      local N=not G[e]or not y[4][y[6]];
      if N or os.clock()>C then
        break;
      end
    end;
    return d.Loaded[e];
  end
  G[e]=true;
  local C,N=pcall(function()
    local q;
    local b="fxdata/"..e..".lua";
    if isfile and readfile then
      local D,p=pcall(isfile,b);
      if D and p then
        local D,p=pcall(readfile,b);
        q=if D then p else q;
      else
      end
    else
    end
    if q then
    else
      local D;
      b=z;
      q=b.body("fx/"..e..".bin");
    end
    if type(q)~="string"or q:sub(1,7)~="return " then
      error("fx/"..e..".bin did not arrive");
    end
    local D,p=loadstring(q,"@fx_"..e);
    if not D then
      error(p);
    end
    local q,p,r=setfenv,setmetatable,{__index=Z};
    q(D,p({},r));
    b={};
    for Z,Z in ipairs(D().items)do
      b[Z.id]=Z;
    end;
    return b;
  end);
  G[e]=nil;
  j=not C;
  if j then
    local Z;
    C=T;
    C("game fx "..e..": "..tostring(N));
    return nil;
  end
  d.Loaded[e]=N;
  return N;
end
