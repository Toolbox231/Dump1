-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #27
-- offset 3621661..3621942 (281 bytes, type=payload)

function()
  while true do
    local L;
    local L=J[4][J[6]];
    if not L then
      break;
    end
    task.wait(1);
    for z,T in pairs(o)do
      if not z.Parent then
        o[z]=nil;
      else
        L=z.Character;
        local z=L and l[L];
        if L and L:FindFirstChild("HumanoidRootPart")and not(z and z.cfg==T) then
          pcall(c,L);
        end
      end
    end;
  end;
end
