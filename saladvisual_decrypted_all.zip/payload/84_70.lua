-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #70
-- offset 3680437..3680677 (240 bytes, type=payload)

local function p(r,K)
  local o,c,m,S={},{},{r,K},0;
  for r,r in ipairs(m)do
    for K,K in ipairs(r)do
      if K and K.id and not o[K.id] then
        K.name=j(K.name or K.id);
        o[K.id]=true;
        c[#c+1]=K;
      end
      S+=1;
      if S%3000==0 then
        task.wait();
      end
    end;
  end;
  return c;
end
