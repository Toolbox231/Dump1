-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #18
-- offset 3652554..3653236 (682 bytes, type=payload)

local function k(v)
  if h[v]~=nil then
    return h[v]or nil;
  end
  local I,i=x[v];
  if I then
    local i=os.clock()+13;
    while true do
      task.wait(0.03);
      local E=not x[v]or not z[4][z[6]];
      if E or os.clock()>=i then
        break;
      end
    end;
    return h[v];
  end
  local i=e[v];
  if not i then
    return nil;
  end
  x[v]=true;
  local E;
  I=T;
  local E,Q=I.objects(function()
    local t,R=game,"rbxassetid://"..i;
    return t:GetObjects(R);
  end);
  x[v]=nil;
  I=E and type(Q)=="table"and Q[1]or nil;
  if type(Q)=="table" then
    for x=2,#Q,1 do
      pcall(function()
        Q[x]:Destroy();
      end);
    end;
  end
  E=z[4][z[6]];
  if not E then
    if I then
      I:Destroy();
    end
    return nil;
  end
  h[v]=I;
  if I then
    N.LoadErrors[v]=nil;
  else
    N.LoadErrors[v]="Asset unavailable: "..i;
  end
  return I;
end
