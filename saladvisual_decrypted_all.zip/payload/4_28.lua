-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #28
-- offset 3250476..3253523 (3047 bytes, type=payload)

local function f(a,F,h,W)
  if not Y.Aura then
    B(a);
    return;
  end
  if W==false then
    O(a);
    S(a,F,h);
    return;
  end
  local V=table.find(Y.AuraTypes,Y.AuraType)and Y.AuraType or"ForceField";
  W=a.shell or a.AuraEffect;
  local _=a.AuraType~=V or a.AuraPart~=h or not W or not W.Parent;
  if _ then
    O(a);
    local O,W=pcall(function()
      local X=C[V];
      if X then
        local x=Instance.new("Attachment");
        x:SetAttribute("VisualsGunAura",true);
        local k=Instance.new("ParticleEmitter");
        k:SetAttribute("VisualsGunAura",true);
        k.Enabled=false;
        k.LightEmission=1;
        k.LightInfluence=0;
        k.Lifetime=NumberRange.new(0.6,1.2);
        k.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.15,0.25),NumberSequenceKeypoint.new(0.7,0.4),NumberSequenceKeypoint.new(1,1)});
        k.Parent=x;
        x.Parent=h;
        task.defer(function()
          local v;
          local v=d;
          local I,I=d,v.id(d.file("particles/"..C[V]..".png"));
          local d;
          v=T[4][T[6]]and j[F]==a and a.AuraEffect==x and x.Parent and I;
          if v then
            k.Texture,k.Enabled=I,Y.On and Y.Aura;
          end
        end);
        return x;
      end
      if V=="Sparkle"or V=="Fire"or V=="Smoke" then
        X=Instance.new(V=="Sparkle"and"Sparkles"or V);
        X:SetAttribute("VisualsGunAura",true);
        if V=="Fire" then
          X.Size=1.2;
          X.Heat=0.3;
        end
        if V=="Smoke" then
          X.Size=0.75;
          X.Opacity=0.12;
          X.RiseVelocity=0.4;
        end
        X.Parent=h;
        return X;
      end
      local d=w(h);
      if d then
        d.Parent=b;
      end
      return d;
    end);
    if not O or not W then
      J(a);
      return;
    end
    if W:IsA("BasePart") then
      a.shell=W;
    else
      a.AuraEffect=W;
    end
    a.AuraType=V;
    a.AuraPart=h;
  end
  if a.shell then
    _=a.shell;
    local J,d,O=_:FindFirstChildWhichIsA("DataModelMesh"),h:FindFirstChildWhichIsA("DataModelMesh"),(1+0.08*Y.AuraSpread)*Y.AuraSize;
    if J and d then
      J.Scale=d.Scale*O;
    else
      _.Size=h.Size*O;
    end
    _.CFrame,_.Color=h.CFrame,Y.AuraColor;
    _.Material=Enum.Material[V];
    _.Reflectance=V=="Metal"and 0.3 or V=="Glass"and 0.12 or 0;
    _.Transparency=1-Y.AuraOpacity;
    _.LocalTransparencyModifier=0;
  elseif C[V] then
    local J,d,C=a.AuraEffect:FindFirstChildOfClass("ParticleEmitter"),{Y.AuraColor,Y.AuraSpread,Y.AuraSpeed,Y.AuraSize,Y.AuraRate,Y.AuraGlow,Y.AuraOpacity},not a.AuraSettings;
    for O,w in ipairs(d)do
      C=if not a.AuraSettings or w~=a.AuraSettings[O]then true else C;
    end;
    if J and C then
      a.AuraSettings=d;
      J.Color=ColorSequence.new(Y.AuraColor);
      J.Speed=NumberRange.new(0.15*Y.AuraSpread*Y.AuraSpeed,1.5*Y.AuraSpread*Y.AuraSpeed);
      J.SpreadAngle=Vector2.new(180,180);
      J.Size=NumberSequence.new(0.3*Y.AuraSize);
      J.Rate,J.Brightness=24*Y.AuraRate,Y.AuraGlow;
      J.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.15,1-Y.AuraOpacity),NumberSequenceKeypoint.new(0.7,1-Y.AuraOpacity*0.6),NumberSequenceKeypoint.new(1,1)});
    end
  elseif V=="Sparkle" then
    a.AuraEffect.SparkleColor=Y.AuraColor;
  elseif V=="Fire" then
    a.AuraEffect.Size,a.AuraEffect.Heat=1.2*Y.AuraSize*Y.AuraSpread,0.3*Y.AuraSpeed;
    a.AuraEffect.Color=Y.AuraColor;
    a.AuraEffect.SecondaryColor=Y.AuraColor:Lerp(Color3.new(1,1,1),0.35);
  else
    a.AuraEffect.Color=Y.AuraColor;
    a.AuraEffect.Size=0.75*Y.AuraSize*Y.AuraSpread;
    a.AuraEffect.Opacity,a.AuraEffect.RiseVelocity=0.2*Y.AuraOpacity,0.4*Y.AuraSpeed;
  end
  S(a,F,h);
end
