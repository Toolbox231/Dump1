-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #1
-- offset 961..17065 (16104 bytes, type=payload)

function(l,l)
  local L=l[1];
  local y=l[2];
  local z=l[3];
  local T=l[4];
  local n=l[5];
  local J=l[6];
  local H=l[7];
  local f=l[8];
  local a=l[9];
  local d=l[10];
  local P=l[11];
  local Z=l[12];
  return function()
    local l=game:GetService("Debris");
    local G,Y=game:GetService("ContentProvider"),"Soft Ring";
    local e,j,C,N={Jump=false,Land=false,Style=Y,Color=Color3.fromRGB(150,200,255),Size=4,Life=0.8,Target="Self",Bright=100,Grow=160,Spin=0},{},{};
    local N=L;
    C.file=N.file("circles/circle.png");
    j["Soft Ring"]=C;
    C,N={},L;
    C.file=N.file("circles/konchal.png");
    j.Inscription=C;
    j["Classic Ring"]={asset="rbxassetid://7185003058"};
    C,N={},L;
    C.file=N.file("circles/ripple.png");
    j["Double Ripple"]=C;
    N,C={},L;
    N.file=C.file("circles/neonring.png");
    j["Neon Ring"]=N;
    N,C={},L;
    N.file=C.file("circles/swirl.png");
    j["Triple Swirl"]=N;
    N,C={},L;
    N.file=C.file("circles/neonstar.png");
    j["Neon Star"]=N;
    C,N={},L;
    C.file=N.file("circles/haloring.png");
    j["Halo Ring"]=C;
    N,C={},L;
    N.file=C.file("circles/shatter.png");
    j["Cracked Ground"]=N;
    C,N={},L;
    C.file=N.file("circles/img.png");
    j["Rune Crown"]=C;
    C,N={},L;
    C.file=N.file("circles/pentos.png");
    j["Glyph Ring"]=C;
    N,C={},L;
    N.file=C.file("circles/imagephotoroom.png");
    j["Magic Circle"]=N;
    C,N={},L;
    C.file=N.file("circles/boom1.png");
    j["Blast Ring"]=C;
    N,C={},L;
    N.file=C.file("circles/omut3.png");
    j["Vortex Ring"]=N;
    N,C={},L;
    N.file=C.file("circles/85362844633530.png");
    j["Radial Burst"]=N;
    C,N={},L;
    C.file=N.file("circles/134160165648626.png");
    j["Mist Ring"]=C;
    N,C={},L;
    N.file=C.file("circles/17068400400.png");
    j["Star Flash"]=N;
    C,N={},L;
    C.file=N.file("circles/circle4.png");
    j["Arcane Sigil"]=C;
    local q,b,D,p,r={"Soft Ring","Inscription","Classic Ring","Double Ripple","Neon Ring","Triple Swirl","Neon Star","Halo Ring","Cracked Ground","Rune Crown","Glyph Ring","Magic Circle","Blast Ring","Vortex Ring","Radial Burst","Mist Ring","Star Flash","Arcane Sigil"},{Circle="Soft Ring",Konchal="Inscription",Ring="Classic Ring",Ripple="Double Ripple",Neon="Neon Ring",Swirl="Triple Swirl",Star="Neon Star",Halo="Halo Ring",Shatter="Cracked Ground",Img="Rune Crown",Pentos="Glyph Ring",["Image Photoroom"]="Magic Circle",["Boom 1"]="Blast Ring",["Omut 3"]="Vortex Ring",["85362844633530"]="Radial Burst",["134160165648626"]="Mist Ring",["17068400400"]="Star Flash",["Circle 4"]="Arcane Sigil",Animation1="Orbit Rings",Animation2="Firework Bloom",Puff="Smoke Bloom"},{animation1="Orbit Rings",animation2="Firework Bloom",puff="Smoke Bloom"},ipairs,L;
    C=s[70](r.under("circles/"));
    for K,o in p(s:ZT(C))do
      K=string.match(o,"([^/]+)$");
      local s,c,m,S=string.match(K or"","^(.+)_(%d+)x(%d+)_(%d+)%.png$");
      if s then
        r,N,K=D[string.lower(s)]or string.gsub(s,"^%l",string.upper),{},L;
        N.file=K.file(o);
        N.cols=tonumber(c);
        N.rows=tonumber(m);
        N.frames=tonumber(S);
        j[r]=N;
        q[#q+1]=r;
      end
    end;
    local function s(K)
      if K.asset then
        return K.asset;
      end
      if K.url~=nil then
        return K.url or nil;
      end
      local o=L;
      K.url=o.id(K.file)or false;
      return K.url or nil;
    end
    local function K(o)
      o=b[o]or o;
      return j[o]and o or Y;
    end
    local o;
    r=y;
    r.CircleStyles={Order=q,Styles=j,Aliases=b,Default=Y};
    task.spawn(function()
      local b,o,c={},ipairs;
      for c,m in o(q)do
        c=z[4][z[6]];
        if not c then
          return;
        end
        c=s(j[m]);
        if c then
          b[#b+1]=c;
        end
        task.wait();
      end;
      o=z[4][z[6]]and#b>0;
      if o then
        local o=L;
        o.invoke(function()
          G:PreloadAsync(b);
        end,8);
      end
    end);
    local L,L;
    do
      C=y;
      local L=C.GunChams;
      if L then
        local function G(b,o)
          local c=Instance.new("Part");
          c.Name="VisualsGunCircle";
          local m;
          local m,S=T;
          local S=n;
          c:SetAttribute(m,S);
          c:SetAttribute("VisualsGunAura",true);
          c.Anchored=true;
          c.CanCollide=false;
          c.CanQuery=false;
          c.CanTouch=false;
          c.CastShadow=false;
          c.Transparency=1;
          c.Parent=workspace;
          m=Instance.new("Attachment");
          m.Parent=c;
          local S=Instance.new("ParticleEmitter");
          S:SetAttribute("VisualsGunAura",true);
          S.Rate=0;
          S.TimeScale=0;
          S.Lifetime,S.Speed=NumberRange.new(20),NumberRange.new(0.01);
          S.LightEmission=1;
          S.LightInfluence=0;
          S.LockedToPart=true;
          S.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
          S.EmissionDirection=Enum.NormalId.Top;
          S.Rotation,S.RotSpeed=NumberRange.new(0),NumberRange.new(0);
          S.Parent=m;
          local m={Part=c,Emitter=S,Style=L.CircleStyle,Clock=1};
          b.Circle=m;
          task.defer(function()
            local O=s(o);
            local B;
            local B=not z[4][z[6]]or b.Circle~=m or not c.Parent or not O;
            if B then
              return;
            end
            S.Texture=O;
            O={[2]=Enum.ParticleFlipbookLayout.Grid2x2,[4]=Enum.ParticleFlipbookLayout.Grid4x4,[8]=Enum.ParticleFlipbookLayout.Grid8x8};
            if o.frames and O[o.cols] then
              S.FlipbookLayout=O[o.cols];
              S.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
              S.FlipbookStartRandom=false;
              S.FlipbookFramerate=NumberRange.new(0);
            end
            S:Emit(1);
            m.Ready=true;
          end);
          return m;
        end
        local b=y;
        b.StaticGunCircle=function(b,o,c,m)
          local S,O=j[L.CircleStyle]or j[Y],b.Circle;
          if not O or O.Style~=L.CircleStyle or not O.Part.Parent then
            if O then
              O.Part:Destroy();
            end
            O=(G(b,S));
          else
          end
          O.Clock=O.Clock+m;
          m=O.Clock>=0.1 or O.Ground~=L.CircleGround;
          if m then
            O.Clock,O.Ground=0,L.CircleGround;
            local G,B,A=c.Position-Vector3.new(0,c.Size.Y*0.5,0),Vector3.new(0.0,1.0,0.0),L.CircleGround;
            if A then
              b=RaycastParams.new();
              b.FilterType=Enum.RaycastFilterType.Exclude;
              local A,w={o,O.Part},J;
              for F,F in ipairs(w:GetPlayers())do
                if F.Character then
                  A[#A+1]=F.Character;
                end
              end;
              b.FilterDescendantsInstances=A;
              b.IgnoreWater=true;
              w=workspace:Raycast(c.Position,Vector3.new(0,-64,0),b);
              if w then
                G,B=w.Position,w.Normal;
              else
              end
            else
            end
            O.Position=G;
            O.Normal=B;
          end
          m=O.Normal or Vector3.new(0.0,1.0,0.0);
          o=math.abs(m.Y)>0.98 and Vector3.new(1.0,0.0,0.0)or Vector3.new(0.0,1.0,0.0);
          b=m:Cross(o).Unit;
          O.Part.CFrame=CFrame.fromMatrix(O.Position+m*L.CircleHeight,b,m,b:Cross(m).Unit);
          S,m,c=O.Emitter,{L.CircleColor,L.CircleSize,L.CircleOpacity,L.CircleGlow,L.CircleRotation,L.CircleThroughWalls},not O.Settings;
          for G,o in ipairs(m)do
            c=if not O.Settings or o~=O.Settings[G]then true else c;
          end;
          if c then
            O.Settings=m;
            S.Color,S.Size=ColorSequence.new(L.CircleColor),NumberSequence.new(L.CircleSize);
            S.Transparency,S.Brightness=NumberSequence.new(1-L.CircleOpacity),L.CircleGlow;
            S.Rotation=NumberRange.new(L.CircleRotation);
            local G;
            b=H;
            b.FxDepth(S,L.CircleThroughWalls);
            if O.Ready then
              S:Clear();
              S:Emit(1);
            end
          end
        end;
        N=f;
        r=N.Guns:AddLabel("Gun Circle");
        r:AddToggle({Default=false,Flag="gun_circle",Callback=function(H)
          L.Circle=H;
          L.SetTracking();
        end});
        r:AddColorPicker({Default=L.CircleColor,Flag="gun_circle_color",Callback=function(H)
          L.CircleColor=H;
        end});
        D=r:AddOption(1);
        D:AddLabel("Style"):AddDropdown({Default=Y,Values=q,Flag="gun_circle_style",Callback=function(H)
          L.CircleStyle=K(H);
        end});
        p={{"Size","CircleSize","size",5,300,40,10},{"Opacity","CircleOpacity","opacity",0,100,100,100},{"Glow","CircleGlow","glow",0,600,200,100},{"Height","CircleHeight","height",0,200,6,100},{"Rotation","CircleRotation","rotation",0,360,0,1}};
        for H,H in ipairs(p)do
          local G=H[2];
          local b=H[7];
          D:AddLabel(H[1]):AddSlider({Min=H[4],Max=H[5],Default=H[6],Rounding=0,Flag="gun_circle_"..H[3],Callback=function(H)
            L[G]=H/b;
          end});
        end;
        D:AddLabel("On Ground"):AddToggle({Default=true,Flag="gun_circle_ground",Callback=function(H)
          L.CircleGround=H;
        end});
      end
    end;
    local L={[2]=Enum.ParticleFlipbookLayout.Grid2x2,[4]=Enum.ParticleFlipbookLayout.Grid4x4,[8]=Enum.ParticleFlipbookLayout.Grid8x8};
    local function H(G,b)
      local o=RaycastParams.new();
      o.FilterType=Enum.RaycastFilterType.Exclude;
      o.FilterDescendantsInstances={G};
      o.IgnoreWater=true;
      local c,m,S,O={"LeftFoot","RightFoot","Left Leg","Right Leg"},(Vector3.new(0.0,0.0,0.0)),(Vector3.new(0.0,0.0,0.0)),0;
      for B,A in ipairs(c)do
        B=G:FindFirstChild(A);
        if B and(B:IsA("BasePart")) then
          A=workspace:Raycast(B.Position+Vector3.new(0,0.35,0),Vector3.new(0,-7,0),o);
          if A then
            m,S,O=m+A.Position,S+A.Normal,O+1;
          else
          end
        else
        end
      end;
      if O>0 then
        return m/O,S.Unit;
      end
      G=workspace:Raycast(b.Position+Vector3.new(0,1,0),Vector3.new(0,-16,0),o);
      if G then
        return G.Position,G.Normal;
      end
      return b.Position-Vector3.new(0,3,0),(Vector3.new(0.0,1.0,0.0));
    end
    local G,b={},{};
    local function o()
      local c={};
      for m in pairs(G)do
        c[#c+1]=m;
      end;
      for m,m in ipairs(c)do
        if m.Parent then
          m:Destroy();
        end
      end;
      table.clear(G);
      table.clear(b);
    end
    local function c(m,S)
      local O;
      local O=z[4][z[6]];
      if not O then
        return;
      end
      local B=j[e.Style]or j[Y];
      local j,A=s(B),0;
      local s,w=1/0;
      for F,h in pairs(b)do
        A+=1;
        if h.born<s then
          s,w=h.born,F;
        else
        end
      end;
      if A>=24 and w then
        w:Destroy();
      end
      O=S or(Vector3.new(0.0,1.0,0.0));
      S=math.abs(O.Y)>0.98 and Vector3.new(1.0,0.0,0.0)or Vector3.new(0.0,1.0,0.0);
      local s=O:Cross(S).Unit;
      local A,w=s:Cross(O).Unit,Instance.new("Part");
      w.Name="VisualsJumpCircle";
      local F;
      local F,h=T;
      S=n;
      w:SetAttribute(F,S);
      w.Anchored=true;
      w.CanCollide=false;
      w.CanQuery=false;
      w.CanTouch=false;
      w.CastShadow=false;
      w.Transparency=1;
      w.Size=Vector3.new(0.2,0.2,0.2);
      w.CFrame=CFrame.fromMatrix(m+O*0.08,s,O,A);
      G[w]=true;
      local function s()
        G[w]=nil;
        b[w]=nil;
      end
      w.Destroying:Once(s);
      w.Parent=workspace;
      local s=Instance.new("SurfaceGui");
      s.Face=Enum.NormalId.Top;
      s.Adornee=w;
      s.AlwaysOnTop=false;
      s.LightInfluence=0;
      s.CanvasSize=Vector2.new(512,512);
      s.Parent=w;
      m=Instance.new("Frame");
      m.BackgroundTransparency,m.Size=1,UDim2.fromScale(0.94,0.94);
      m.Position=UDim2.fromScale(0.03,0.03);
      m.BorderSizePixel=0;
      m.Parent=s;
      O=Instance.new("UICorner");
      O.CornerRadius=UDim.new(1,0);
      O.Parent=m;
      A=Instance.new("UIStroke");
      A.ApplyStrokeMode=Enum.ApplyStrokeMode.Border;
      A.Thickness=7;
      A.Color=e.Color;
      A.Parent=m;
      b[w]={born=os.clock(),life=e.Life,size=e.Size,grow=e.Grow/100,bright=math.clamp(e.Bright/100,0,1),stroke=A,base=w.CFrame,spin=math.rad(e.Spin)};
      w.Size=Vector3.new(e.Size*0.35,0.025,e.Size*0.35);
      l:AddItem(w,e.Life+0.4);
      if not j then
        return w;
      end
      if not pcall(function()local l=Instance.new("Attachment");l.Parent=w;local T,n=math.clamp(e.Bright/100,0,1),Instance.new("ParticleEmitter");n.Texture=j;n.Color=ColorSequence.new(e.Color);n.LightEmission=1;n.LightInfluence=0;n.Rate=0;n.Lifetime=NumberRange.new(e.Life);n.Speed=NumberRange.new(0.01);n.Drag=0;n.Acceleration=Vector3.new(0.0,0.0,0.0);n.VelocityInheritance=0;n.EmissionDirection=Enum.NormalId.Top;n.Rotation=NumberRange.new(0);n.RotSpeed=NumberRange.new(e.Spin);n.ZOffset=0;pcall(function()n.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;end);n.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,e.Size*0.35),NumberSequenceKeypoint.new(0.4,e.Size),NumberSequenceKeypoint.new(1,e.Size*e.Grow/100)});n.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1-T),NumberSequenceKeypoint.new(0.6,1-T*0.55),NumberSequenceKeypoint.new(1,1)});if B.frames and L[B.cols]then pcall(function()n.FlipbookLayout=L[B.cols];n.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;end);end;n.Parent=l;n:Emit(1);s.Enabled=false;end) then
        for s,s in ipairs(w:GetChildren())do
          if s:IsA("Attachment") then
            s:Destroy();
          end
        end;
      end
      return w;
    end
    local function s(l)
      local L;
      local L=a;
      local T=l==L;
      return e.Target=="All"or T and e.Target=="Self"or not T and e.Target=="Other";
    end
    local l={};
    local function L(T,n)
      local G=n.RootPart or T:FindFirstChild("HumanoidRootPart")or T.PrimaryPart;
      return G and G:IsA("BasePart")and G or nil;
    end
    local function T(n,G,j)
      local m=os.clock();
      if n.lastCircleAt and m-n.lastCircleAt<=0.22 and n.lastCirclePosition and(G-n.lastCirclePosition).Magnitude<=5 then
        return false;
      end
      n.lastCircleAt=m;
      n.lastCirclePosition=G;
      c(G,j);
      return true;
    end
    local function n(G)
      local j=l[G];
      if not j then
        return;
      end
      l[G]=nil;
      for G,G in ipairs(j.conns)do
        G:Disconnect();
      end;
      for G,G in ipairs(j.humanConns or{})do
        G:Disconnect();
      end;
    end
    local function G(j,m)
      local S=L(j.character,j.human);
      if not S then
        return;
      end
      if m and j.jumpDetected then
        j.air=true;
        return;
      end
      j.jumpDetected=true;
      m=os.clock();
      if e.Jump and s(j.player)and m-j.lastJump>0.18 then
        j.lastJump=m;
        local m,O=H(j.character,S);
        T(j,m,O);
      end
      j.air=true;
    end
    local function j(m)
      if m.air and e.Land and s(m.player) then
        local S=L(m.character,m.human);
        if S then
          local O,B=H(m.character,S);
          T(m,O,B);
        end
      end
      m.air=false;
      m.jumpDetected=false;
    end
    local T;
    local function T(m)
      local function S(O)
        n(m);
        local B={player=m,character=O,conns={},humanConns={},lastJump=-1/0};
        l[m]=B;
        local function A(w)
          local F;
          local F=B.human and B.human.Parent or not z[4][z[6]]or l[m]~=B or m.Character~=O;
          if F then
            return;
          end
          for F,F in ipairs(B.humanConns)do
            F:Disconnect();
          end;
          table.clear(B.humanConns);
          B.human=w;
          B.air=w.FloorMaterial==Enum.Material.Air;
          B.floorAir=B.air;
          B.humanConns[#B.humanConns+1]=w.StateChanged:Connect(function(F,h)
            F=not z[4][z[6]]or l[m]~=B;
            if F then
              return;
            end
            if h==Enum.HumanoidStateType.Jumping then
              G(B);
            elseif h==Enum.HumanoidStateType.Freefall then
              B.air=true;
            elseif h==Enum.HumanoidStateType.Landed then
              j(B);
            end
          end);
          B.humanConns[#B.humanConns+1]=w.Jumping:Connect(function(w)
            local F=z[4][z[6]]and w and l[m]==B;
            if F then
              G(B);
            end
          end);
        end
        B.conns[#B.conns+1]=O.DescendantAdded:Connect(function(w)
          if w:IsA("Humanoid") then
            A(w);
          end
        end);
        B.conns[#B.conns+1]=O.ChildRemoved:Connect(function(w)
          if w==B.human then
            for w,w in ipairs(B.humanConns)do
              w:Disconnect();
            end;
            table.clear(B.humanConns);
            B.human=nil;
            local B=O:FindFirstChildOfClass("Humanoid");
            if B then
              A(B);
            end
          end
        end);
        task.spawn(function()
          local B,w=O:FindFirstChildOfClass("Humanoid")or O:WaitForChild("Humanoid",10);
          local w=B and z[4][z[6]]and O.Parent and m.Parent and m.Character==O;
          if w then
            A(B);
          end
        end);
      end
      if m.Character then
        S(m.Character);
      end
      local O=d;
      O:AddPlayerSignal(m,m.CharacterAdded:Connect(S));
      O=d;
      local function S()
        n(m);
      end
      O:AddPlayerSignal(m,m.CharacterRemoving:Connect(S));
    end
    local m,S,O=0,d;
    r=P;
    S:AddSignal(r.RenderStepped:Connect(function(P)
      local O;
      local O=z[4][z[6]];
      if not O then
        return;
      end
      O=os.clock();
      for z,B in pairs(b)do
        local b=(O-B.born)/B.life;
        if b>=1 or not z.Parent then
          z:Destroy();
        else
          local A=B.size*(b<0.4 and 0.35+b/0.4*0.65 or 1+(B.grow-1)*(b-0.4)/0.6);
          z.Size=Vector3.new(A,0.025,A);
          z.CFrame=B.base*CFrame.Angles(0,B.spin*(O-B.born),0);
          B.stroke.Transparency=1-B.bright*(1-b)^1.4;
        end
      end;
      if not(e.Jump or e.Land) then
        return;
      end
      m+=P;
      P=m;
      if P<0.04 then
        return;
      end
      m=0;
      for z,b in pairs(l)do
        P,O=b.human,b.character;
        if P and P.Parent and O.Parent and z.Character==O and s(z) then
          local s=L(O,P);
          if s then
            local L=P.FloorMaterial==Enum.Material.Air;
            if L and not b.floorAir and s.AssemblyLinearVelocity.Y>1 then
              G(b,true);
            elseif not L and b.floorAir then
              j(b);
            end
            b.floorAir=L;
          end
        end
      end;
    end));
    r=J;
    for s,s in ipairs(r:GetPlayers())do
      T(s);
    end;
    p,r=d,J;
    p:AddSignal(r.PlayerAdded:Connect(T));
    r,S=d,J;
    r:AddSignal(S.PlayerRemoving:Connect(n));
    S=y;
    S.Circles=e;
    r=y;
    r.SpawnCircle=c;
    local s,L=y;
    r=Z;
    s.ClearCircles=r("circles",function()
      e.Jump=false;
      e.Land=false;
      o();
      for s in pairs(l)do
        n(s);
      end;
      table.clear(l);
    end);
    r=f;
    C=r.Circles:AddLabel("Jump Circle");
    C:AddToggle({Default=false,Flag="jump_circle",Callback=function(s)
      e.Jump=s;
      if not(e.Jump or e.Land) then
        o();
      end
    end});
    C:AddColorPicker({Default=e.Color,Flag="circle_color",Callback=function(s)
      e.Color=s;
    end});
    r=f;
    r.Circles:AddLabel("Land Circle"):AddToggle({Default=false,Flag="land_circle",Callback=function(s)
      e.Land=s;
      if not(e.Jump or e.Land) then
        o();
      end
    end});
    D=f;
    D.Circles:AddLabel("Style"):AddDropdown({Default=Y,Values=q,Flag="circle_style",Callback=function(s)
      local l=K(s);
      if e.Style~=l then
        o();
      end
      e.Style=l;
    end});
    C=f;
    C.Circles:AddLabel("Size"):AddSlider({Min=1,Max=30,Default=4,Rounding=1,Size=100,Flag="circle_size",Callback=function(s)
      e.Size=s;
    end});
    N=f;
    N.Circles:AddLabel("Life"):AddSlider({Min=2,Max=40,Default=8,Rounding=0,Size=100,Flag="circle_life",Callback=function(s)
      e.Life=s/10;
    end});
    r=f;
    r.Circles:AddLabel("Grow"):AddSlider({Min=100,Max=400,Default=220,Type="%",Size=100,Flag="circle_grow",Callback=function(s)
      e.Grow=s;
    end});
    N=f;
    N.Circles:AddLabel("Brightness"):AddSlider({Min=10,Max=100,Default=100,Type="%",Size=100,Flag="circle_bright",Callback=function(s)
      e.Bright=s;
    end});
    D=f;
    D.Circles:AddLabel("Spin"):AddSlider({Min=0,Max=180,Default=0,Rounding=0,Size=100,Flag="circle_spin",Callback=function(s)
      e.Spin=s;
    end});
    D=f;
    D.Circles:AddLabel("Target"):AddDropdown({Default="Self",Values={"Self","Other","All"},Flag="circle_target",Callback=function(s)
      e.Target=s;
    end});
    p=f;
    p.Circles:AddButton({Name="Test Circle",Callback=function()
      local s;
      local s=a;
      local l=s.Character;
      s=l and(l:FindFirstChild("HumanoidRootPart"));
      if s then
        c(H(l,s));
      end
    end});
  end;
end
