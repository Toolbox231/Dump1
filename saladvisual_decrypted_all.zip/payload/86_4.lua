-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #4
-- offset 3204938..3205191 (253 bytes, type=payload)

local function N(q)
  local b,D=Instance.new(Y),l;
  b.Name=D.RandomString();
  b.Enabled=false;
  for Y,D in pairs(e)do
    b[Y]=D;
  end;
  if q then
    for Y in pairs(e)do
      pcall(function()
        b[Y]=q[Y];
      end);
    end;
    pcall(function()
      b.Enabled=q.Enabled;
    end);
  end
  b.Parent=s;
  return b;
end
