-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #11
-- offset 203562..203812 (250 bytes, type=payload)

function()
  local n,e=pcall(w,T);
  local j=K;
  if T~=j then
    return;
  end
  o=false;
  if not n then
    L();
    warn("[visuals] Starfall: "..tostring(e));
    return;
  end
  j=not e or not y[4][y[6]]or not d.On;
  if j then
    return;
  end
  p=0;
  local y;
  e=J;
  D=e.RenderStepped:Connect(G);
end
