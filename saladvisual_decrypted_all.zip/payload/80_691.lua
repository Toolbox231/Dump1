-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #691
-- offset 3513802..3529903 (16101 bytes, type=payload)

local function G(Y,Y)
  local j,C=s[87](),y[18][l[131]];
  Y=X(Y,{[l[572]]=l[1116],[l[1590]]=l[300],[l[1096]]=j[l[1689]][l[772]](l[84],l[521]),[l[457]]=j[l[1689]][l[772]](l[306],l[341]),[l[24]]=l[1286],[l[1610]]=l[1249],[l[871]]=l[863],[l[1617]]=nil});
  local p,r=j[l[35]][l[850]](j[l[35]][l[499]](Y[l[1096]][l[1437]]),Y[l[457]][l[1437]]),j[l[35]][l[850]](j[l[35]][l[499]](Y[l[1096]][l[636]]),Y[l[457]][l[636]]);
  local o=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=j[l[1459]][l[772]](l[659],-j[l[35]][l[499]](p*l[659]),l[659],-j[l[35]][l[499]](r*l[659])),[l[1639]]=j[l[1459]][l[588]](p,r),[l[1535]]=C[l[641]],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1632]},x);
  Z(o);
  D(o,l[551]);
  a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1017]},o);
  if T then
    a(l[1198],{[l[1630]]=C[l[641]],[l[258]]=j[l[740]][l[772]](l[393],l[658]),[l[1485]]=j[l[1459]][l[588]](l[393],l[1158]),[l[1326]]=j[l[1459]][l[588]](l[1024],l[1024]),[l[747]]=l[330],[l[711]]=l[715]},o);
  end
  local T=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[1282]),[l[1535]]=C[l[1466]],[l[1418]]=l[393],[l[711]]=l[421]},o);
  D(T,l[551]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[229]),[l[948]]=j[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[551]),[l[1535]]=C[l[1466]],[l[1418]]=l[393],[l[711]]=l[421]},T);
  K(a(l[211],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[393],l[1282]),[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=C[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[652]},o),l[393],{j[l[677]][l[772]](l[393],l[229]),j[l[677]][l[772]](l[841],l[874]),j[l[677]][l[772]](l[659],l[393]),j[l[677]][l[772]](l[804],l[874]),j[l[677]][l[772]](l[229],l[229])});
  local function r(B,A,w)
    local F=s[87]();
    local V=a;
    local k=l[1742];
    local i={};
    i[l[1150]]=f();
    i[l[1016]]=F[l[1689]][l[772]](w and l[229]or l[393],l[659]);
    i[l[948]]=F[l[1459]][l[772]](w and l[229]or l[393],B,l[659],l[393]);
    i[l[1639]]=F[l[1459]][l[588]](l[1243],l[1243]);
    i[l[1535]]=C[l[675]];
    i[l[1646]]=l[229];
    i[l[1418]]=l[393];
    i[l[1451]]=y[30](A);
    i[l[936]]=C[l[1379]];
    i[l[2]]=l[986];
    i[l[1557]]=F[l[128]][l[1557]][l[220]];
    i[l[711]]=l[1513];
    local B=V(k,i,T);
    D(B,l[1158]);
    d(B[l[1538]],function()
      P(B,H,{[l[2]]=l[393],[l[936]]=C[l[1095]],[l[1646]]=l[615]});
    end);
    d(B[l[1628]],function()
      P(B,H,{[l[2]]=l[986],[l[936]]=C[l[1379]],[l[1646]]=l[229]});
    end);
    return B;
  end
  local B,A,w,F=r(l[930],l[515]),r(l[913],l[515]),r(l[205],l[1169]),r(l[1519],l[898],l[383]);
  B[l[500]]=l[1510];
  local V=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[659]),[l[948]]=j[l[1459]][l[772]](l[393],l[694],l[659],l[393]),[l[1639]]=j[l[1459]][l[772]](l[229],l[1171],l[393],l[1655]),[l[1535]]=C[l[641]],[l[1646]]=l[986],[l[1418]]=l[393],[l[1155]]=l[1329],[l[437]]=j[l[128]][l[437]][l[807]],[l[32]]=l[617],[l[592]]=C[l[1379]],[l[1420]]=Y[l[1590]],[l[510]]=C[l[1095]],[l[723]]=l[750],[l[164]]=j[l[128]][l[164]][l[1021]],[l[1634]]=j[l[128]][l[1634]][l[701]],[l[711]]=l[1513]},T);
  D(V,l[1158]);
  j[l[1146]](function()
    local k=s[87]();
    V[l[526]]=k[l[437]][l[772]](l[624],k[l[128]][l[1444]][l[1121]]);
  end);
  a(l[1359],{[l[1612]]=j[l[740]][l[772]](l[393],l[551]),[l[517]]=j[l[740]][l[772]](l[393],l[551])},V);
  local k=a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1419]},V);
  local i=a(l[211],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[930],l[726]),[l[1639]]=j[l[1459]][l[772]](l[229],l[286],l[229],l[1679]),[l[1535]]=C[l[641]],[l[1646]]=l[874],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[421]},o);
  D(i,l[1092]);
  a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1567]},i);
  local E=a(l[859],{[l[1150]]=f(),[l[1639]]=j[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[2]]=l[229],[l[196]]=j[l[128]][l[1727]][l[1380]],[l[1557]]=j[l[128]][l[1557]][l[208]],[l[711]]=l[652]},i);
  D(E,l[1092]);
  local Q=a(l[1070],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[659],l[659]),[l[948]]=j[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=j[l[1459]][l[772]](l[229],l[207],l[393],l[906]),[l[1646]]=l[229],[l[437]]=j[l[128]][l[437]][l[1381]],[l[1420]]=l[1164],[l[510]]=C[l[1379]],[l[723]]=l[310],[l[916]]=l[986],[l[789]]=l[383],[l[711]]=l[1513]},i);
  local t,R=a(l[1742],{[l[1150]]=f(),[l[1639]]=j[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1167]},i),a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[207],l[207]),[l[1639]]=j[l[1459]][l[588]](l[730],l[730]),[l[1646]]=l[229],[l[1155]]=l[1329],[l[1420]]=l[1746],[l[916]]=l[229],[l[711]]=l[421]},o);
  local g=a(l[1070],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[229]),[l[948]]=j[l[1459]][l[772]](l[393],l[310],l[229],l[348]),[l[1639]]=j[l[1459]][l[772]](l[229],l[1614],l[393],l[558]),[l[1646]]=l[229],[l[437]]=j[l[128]][l[437]][l[807]],[l[1420]]=l[498],[l[510]]=C[l[1379]],[l[723]]=l[1307],[l[916]]=l[1431],[l[164]]=j[l[128]][l[164]][l[1021]],[l[1634]]=j[l[128]][l[1634]][l[701]],[l[711]]=l[652]},o);
  local u=a;
  local sP=l[1742];
  local LP={};
  LP[l[1150]]=f();
  LP[l[1016]]=j[l[1689]][l[772]](l[229],l[229]);
  LP[l[948]]=j[l[1459]][l[772]](l[229],l[1024],l[229],l[1024]);
  LP[l[1639]]=j[l[1459]][l[588]](l[352],l[352]);
  LP[l[1646]]=l[229];
  LP[l[1451]]=y[30](l[908]);
  LP[l[936]]=C[l[1379]];
  LP[l[2]]=l[323];
  LP[l[500]]=l[1157];
  LP[l[1557]]=j[l[128]][l[1557]][l[220]];
  LP[l[711]]=l[1513];
  local yP=u(sP,LP,o);
  local u,sP,LP={[l[1156]]=o,[l[732]]=i,[l[1736]]=E,[l[1590]]=Y[l[1590]],[l[1600]]=l[1329],[l[1273]]=l[1329],[l[24]]=Y[l[24]]};
  local zP=j[l[1689]][l[1729]];
  local JP=l[1329];
  local HP=l[393];
  local fP=l[393];
  local aP=l[393];
  local dP=l[1329];
  local PP,ZP,GP=l[1329],{};
  local YP,eP={};
  local function jP(CP)
    local NP,qP=s[87](),CP:IsA(l[734])or CP:IsA(l[1198]);
    if qP then
      local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[747]};
      bP[l[1118]]=CP[l[747]];
      qP(YP,bP);
    else
      local qP=CP:IsA(l[1070])or CP:IsA(l[1400]--[[-1]])or CP:IsA(l[192]);
      if qP then
        local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
        bP[l[1118]]=CP[l[1646]];
        qP(YP,bP);
        bP,qP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[916]};
        qP[l[1118]]=CP[l[916]];
        bP(YP,qP);
      else
        local qP=CP:IsA(l[859])or CP:IsA(l[1742]);
        if qP then
          local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
          bP[l[1118]]=CP[l[1646]];
          qP(YP,bP);
          bP={[l[689]]=CP,[l[1540]]=l[2],[l[1118]]=CP[l[2]]};
          NP[l[1346]][l[968]](YP,bP);
          qP=CP==E;
          if qP then
            eP=bP;
          end
        else
          local qP=l[957];
          if CP:IsA(qP) then
            local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
            bP[l[1118]]=CP[l[1646]];
            qP(YP,bP);
          end
        end
      end
    end
  end
  local function CP(NP)
    for qP=l[229],#YP,l[229]do
      local bP=YP[qP];
      if bP[l[689]][l[382]] then
        bP[l[689]][bP[l[1540]]]=bP[l[1118]]+(l[229]-bP[l[1118]])*NP;
      end
    end;
  end
  j[l[1146]](function()
    local YP=s[87]();
    GP=YP[l[188]](YP[l[1458]]:GetService(l[1718]));
  end);
  local function YP(NP)
    if g[l[1420]]~=NP then
      g[l[1420]]=NP;
    end
  end
  local function g(NP)
    local qP,bP=s[87](),sP;
    if not bP then
      return l[1329];
    end
    bP=qP[l[1146]](function()
      sP:Send(NP);
    end);
    if not bP then
      u[l[1273]]=l[1329];
    end
    return bP;
  end
  local function NP(qP,bP)
    local DP=s[87]();
    local pP=dP or not u[l[1600]]or DP[l[40]](qP)~=l[384]or DP[l[40]](bP)~=l[384]or qP<l[229]or bP<l[229]or qP>l[783]or bP>l[783]or qP%l[229]~=l[393]or bP%l[229]~=l[393];
    if pP then
      return l[1329];
    end
    pP=GP;
    if not pP then
      return l[1329];
    end
    local pP,rP=DP[l[1146]](function()
      local KP,oP=s[87](),GP;
      local GP={[l[1639]]=KP[l[1689]][l[772]](qP,bP)};
      return oP:CreateEditableImage(GP);
    end);
    if not pP or not rP then
      return l[1329];
    end
    pP=DP[l[1146]](function()
      local GP=s[87]();
      E[l[610]--[[readi32]]]=GP[l[342]][l[1625]](rP);
    end);
    if not(if not pP then DP[l[1146]](function()rP[l[382]]=E;end)else pP) then
      DP[l[1146]](function()
        rP:Destroy();
      end);
      return l[1329];
    end
    pP=LP;
    if pP then
      DP[l[1146]](function()
        LP:Destroy();
      end);
    end
    LP=rP;
    zP=DP[l[1689]][l[772]](qP,bP);
    E[l[2]]=l[393];
    Q[l[1324]]=l[1329];
    return l[383];
  end
  local function GP(qP,bP,DP,pP,rP)
    local KP,oP,cP=s[87](),dP or not u[l[1600]]or not qP or not bP or not DP or not pP or qP<l[393]or bP<l[393]or DP<l[229]or pP<l[229]or qP%l[229]~=l[393]or bP%l[229]~=l[393]or DP%l[229]~=l[393]or pP%l[229]~=l[393];
    if oP then
      cP=oP;
    else
      local mP,SP=qP+DP,zP;
      cP=mP>SP[l[1437]];
    end
    oP=nil;
    if cP then
      oP=cP;
    else
      local mP,SP=bP+pP,zP;
      oP=mP>SP[l[636]];
    end
    if oP or KP[l[40]](rP)~=l[409]or#rP>l[1392] then
      return;
    end
    oP=LP;
    if not oP then
      return;
    end
    local oP=J(rP);
    cP=DP*pP*l[786];
    if not oP or#oP<cP then
      return;
    end
    if #oP>cP then
      oP=KP[l[409]][l[1724]](oP,l[229],cP);
    else
    end
    KP[l[1146]](function()
      local J,rP=s[87](),LP;
      rP:WritePixelsBuffer(J[l[1689]][l[772]](qP,bP),J[l[1689]][l[772]](DP,pP),J[l[427]][l[1077]](oP));
    end);
  end
  local function J()
    local qP,bP=s[87](),i[l[160]];
    return qP[l[35]][l[819]](qP[l[35]][l[499]](bP[l[1437]]/l[930])*l[930],l[633],l[783]),(qP[l[35]][l[819]](qP[l[35]][l[499]](bP[l[636]]/l[930])*l[930],l[633],l[783]));
  end
  local function i()
    local qP,bP=J();
    local DP=zP;
    local pP,rP=DP[l[1437]]~=qP;
    if pP then
      rP=pP;
    else
      DP=zP;
      rP=DP[l[636]]~=bP;
    end
    if rP then
      g(l[635]..qP..l[214]..bP);
    end
  end
  local function qP(bP)
    local DP=s[87]();
    local pP=dP or not y[18][l[630]]or not u[l[1600]]or DP[l[40]](bP)~=l[409]or#bP>l[1392];
    if pP then
      return;
    end
    pP=DP[l[409]][l[56]](bP,l[1542]);
    if pP==l[347] then
      local rP,KP,oP,cP,mP=DP[l[409]][l[56]](bP,l[845]);
      if mP then
        GP(DP[l[1382]](rP),DP[l[1382]](KP),DP[l[1382]](oP),DP[l[1382]](cP),mP);
      end
    elseif pP==l[900] then
      local GP,rP=DP[l[409]][l[56]](bP,l[152]);
      if GP then
        NP(DP[l[1382]](GP),DP[l[1382]](rP));
      end
    elseif pP==l[692] then
      local GP=DP[l[409]][l[1724]](bP,l[863]);
      u[l[1590]]=GP;
      if not V:IsFocused() then
        V[l[1420]]=GP;
      end
    elseif pP==l[1395] then
      YP(DP[l[409]][l[1724]](bP,l[863]));
    elseif pP==l[1253] then
      YP(DP[l[409]][l[1724]](bP,l[863]));
    end
  end
  local function GP()
    local NP,bP=s[87](),aP;
    aP=bP+l[229];
    PP=l[1329];
    for DP,DP in y[5](ZP)do
      DP:Disconnect();
    end;
    NP[l[1346]][l[267]](ZP);
    bP=sP;
    if bP then
      local DP=sP;
      sP=nil;
      NP[l[1146]](function()
        DP:Close();
      end);
    end
    u[l[1273]]=l[1329];
    zP=NP[l[1689]][l[1729]];
    bP=LP;
    if bP then
      NP[l[1146]](function()
        LP:Destroy();
      end);
      LP=nil;
    end
    E[l[2]]=l[229];
    Q[l[1324]]=l[383];
  end
  local function LP()
    local zP,NP=s[87](),sP or PP or dP or not y[18][l[630]]or not u[l[1600]];
    if NP then
      return;
    end
    Q[l[1420]]=l[288]..u[l[24]];
    Q[l[1324]]=l[383];
    NP=aP;
    PP=l[383];
    local bP=n(u[l[24]]);
    local n=NP~=aP or dP or not y[18][l[630]]or not u[l[1600]];
    if n then
      if bP then
        zP[l[1146]](function()
          bP:Close();
        end);
      end
      return;
    end
    PP=l[1329];
    if not bP then
      Q[l[1420]]=l[1497]..u[l[24]]..l[1541];
      return;
    end
    sP=bP;
    u[l[1273]]=l[383];
    zP[l[1146]](function()
      ZP[#ZP+l[229]]=bP[l[1450]]:Connect(function(PP)
        local DP=sP;
        if DP==bP then
          qP(PP);
        end
      end);
    end);
    zP[l[1146]](function()
      ZP[#ZP+l[229]]=bP[l[1140]]:Connect(function()
        local PP=sP;
        if PP==bP then
          GP();
          Q[l[1420]]=l[1523];
        end
      end);
    end);
    NP,n=J();
    g(l[573]..zP[l[35]][l[819]](zP[l[35]][l[499]](Y[l[1610]]),l[229],l[1632]));
    g(l[635]..NP..l[214]..n);
    g(l[1620]..u[l[1590]]);
    YP(l[888]);
  end
  local function n()
    local J,Q,zP,PP=s[87](),y[9]:GetMouseLocation(),E[l[81]]+h(),E[l[160]];
    if PP[l[1437]]<l[229]or PP[l[636]]<l[229] then
      return nil;
    end
    return J[l[35]][l[819]]((Q[l[1437]]-zP[l[1437]])/PP[l[1437]],l[393],l[229]),J[l[35]][l[819]]((Q[l[636]]-zP[l[636]])/PP[l[636]],l[393],l[229]);
  end
  local function J(h,Q)
    h=s[87]();
    Q=h[l[1130]](Q or l[1746]);
    if not h[l[409]][l[56]](Q,l[825]) then
      return;
    end
    Q=if not h[l[409]][l[23]](Q,l[54],l[229],l[383])then h[l[409]][l[23]](Q,l[1213])and not h[l[409]][l[23]](Q,l[1446])and l[1585]..Q or l[696]..h[l[409]][l[1710]](Q,l[631],l[1287])else Q;
    if not Q:match(l[1388])or#Q>l[329] then
      return l[1329];
    end
    u[l[1590]]=Q;
    V[l[1420]]=Q;
    YP(l[1335]);
    g(l[1620]..Q);
  end
  u[l[1280]]=J;
  local function J(h,Q)
    local zP,PP=s[87](),dP or not y[18][l[630]];
    if PP then
      return;
    end
    Q=Q and l[383]or l[1329];
    if u[l[1600]]==Q then
      return;
    end
    u[l[1600]]=Q;
    PP=aP;
    aP=PP+l[229];
    local ZP=aP;
    y[18]:chime(Q and l[1600]or l[914]);
    PP=eP;
    if PP then
      h=eP;
      h[l[1118]]=E[l[2]];
    end
    if Q then
      CP(l[229]);
      o[l[1324]]=l[383];
      zP[l[1022]][l[1061]](LP);
      b(o,l[894],N,function(h)
        CP(l[229]-h);
      end);
    else
      b(o,l[304],q,function(h)
        CP(h);
        if h>=l[229] then
          o[l[1324]]=l[1329];
          CP(l[393]);
        end
      end);
      zP[l[1022]][l[1330]](l[304],function()
        local h=ZP==aP and not u[l[1600]]and not dP;
        if h then
          GP();
        end
      end);
    end
    if Y[l[1617]] then
      I(Y[l[1617]],Q);
    end
  end
  u[l[80]]=J;
  local function J(h)
    u:render(not u[l[1600]]);
  end
  u[l[524]]=J;
  local function J(h,E)
    h=s[87]();
    u[l[24]]=h[l[1130]](E or u[l[24]]);
    if u[l[1600]] then
      GP();
      h[l[1022]][l[1061]](LP);
    end
  end
  u[l[1173]]=J;
  local function J(h)
    local h,E=s[87](),dP;
    if E then
      return;
    end
    local E,Q,zP=l[1600],l[383],l[1329];
    dP=Q;
    u[E]=zP;
    GP();
    zP=(h[l[1346]][l[23]](y[18][l[1438]],u));
    if zP then
      h[l[1346]][l[1357]](y[18][l[1438]],zP);
    end
    o:Destroy();
  end
  u[l[794]]=J;
  d(F[l[445]],function()
    u:render(l[1329]);
  end);
  d(B[l[445]],function()
    y[18]:chime(l[1352]);
    g(l[885]);
  end);
  d(A[l[445]],function()
    y[18]:chime(l[1352]);
    g(l[1599]);
  end);
  d(w[l[445]],function()
    y[18]:chime(l[1320]);
    g(l[8]);
  end);
  d(V[l[722]],function(J)
    P(k,H,{[l[747]]=l[1419]});
    if J then
      u:go(V[l[1420]]);
    end
  end);
  d(V[l[505]],function()
    P(k,H,{[l[747]]=l[1431]});
  end);
  d(t[l[445]],function()
    local J,B,A=s[87](),n();
    if B then
      y[18]:chime(l[1320]);
      g(l[124]..J[l[409]][l[846]](l[1355],B,A)..l[842]);
      J[l[1146]](function()
        R:CaptureFocus();
      end);
    end
  end);
  d(t[l[861]],function()
    local J,B,A=s[87](),n();
    if B then
      g(l[124]..J[l[409]][l[846]](l[1355],B,A)..l[201]);
    end
  end);
  d(t[l[233]],function(J)
    local B=s[87]();
    if not u[l[1273]] then
      return;
    end
    if J[l[1317]]==B[l[128]][l[1317]][l[72]] then
      local A,w=n();
      if A then
        g(l[1371]..B[l[409]][l[846]](l[1355],A,w)..l[214]..(J[l[948]][l[989]]>l[393]and l[549]or l[710]));
      end
      return;
    end
    local A=J[l[1317]]==B[l[128]][l[1317]][l[765]];
    if A then
      J=B[l[655]][l[1587]]();
      local A=J-fP;
      if A<l[629] then
        return;
      end
      fP=J;
      local J,A=n();
      if J then
        g(l[1071]..B[l[409]][l[846]](l[1355],J,A));
      end
    end
  end);
  d(t[l[1558]],function(J)
    local B=s[87]();
    if J[l[1317]]~=B[l[128]][l[1317]][l[239]]or not u[l[1273]] then
      return;
    end
    local A,w=y[9]:GetMouseLocation(),B[l[655]][l[1587]]();
    local F=l[393];
    while true do
      local h,V=J[l[1101]],B[l[128]];
      if not(h~=V[l[1101]][l[912]]) then
        break;
      end
      h=(y[9]:GetMouseLocation());
      V=h-A;
      if B[l[35]][l[1575]](V[l[636]])>=l[59] then
        local J,k=n();
        if J then
          g(l[1371]..B[l[409]][l[846]](l[1355],J,k)..l[214]..B[l[35]][l[499]](-V[l[636]]*l[863]));
        end
        A,F=h,F+B[l[35]][l[1575]](V[l[636]]);
      else
      end
      B[l[1022]][l[153]]();
    end;
    if F<l[1158]and B[l[655]][l[1587]]()-w<l[659] then
      local J,A=n();
      if J then
        g(l[124]..B[l[409]][l[846]](l[1355],J,A)..l[842]);
      end
    end
  end);
  d(R:GetPropertyChangedSignal(l[1420]),function()
    local n=R[l[1420]];
    if n==l[1746]or not u[l[1273]] then
      return;
    end
    R[l[1420]]=l[1746];
    g(l[1595]..n);
  end);
  d(y[9][l[1558]],function(n,J)
    if not u[l[1600]]or not u[l[1273]]or not R:IsFocused() then
      return;
    end
    J=z(n[l[880]--[[readu32]]]);
    if J==l[579]or J==l[944]or J==l[367]or J==l[1460]or J==l[1436]or J==l[1492]or J==l[701]or J==l[877] then
      g(l[1556]..J);
    end
  end);
  d(yP[l[1558]],function(z)
    local n=s[87]();
    if z[l[1317]]~=n[l[128]][l[1317]][l[1356]]and z[l[1317]]~=n[l[128]][l[1317]][l[239]] then
      return;
    end
    local J=JP;
    if J then
      return;
    end
    JP=l[383];
    O(l[229]);
    local B,A=y[9]:GetMouseLocation(),e(o);
    local w,F,h=A[l[1437]],A[l[636]],(n[l[964]][l[227]]and n[l[964]][l[227]][l[952]]or n[l[1689]][l[772]](l[1248],l[1704]))/y[29];
    P(yP,H,{[l[2]]=l[393],[l[936]]=C[l[1095]]});
    while true do
      J=JP and(y[9]:IsMouseButtonPressed(n[l[128]][l[1317]][l[1356]])or z[l[1101]]~=n[l[128]][l[1101]][l[912]]);
      if not J then
        break;
      end
      A=(y[9]:GetMouseLocation()-B)/y[29];
      o[l[1639]]=n[l[1459]][l[588]](n[l[35]][l[819]](w+A[l[1437]],Y[l[457]][l[1437]],n[l[35]][l[850]](Y[l[457]][l[1437]],h[l[1437]]-l[829])),n[l[35]][l[819]](F+A[l[636]],Y[l[457]][l[636]],n[l[35]][l[850]](Y[l[457]][l[636]],h[l[636]]-l[829])));
      n[l[1022]][l[153]]();
    end;
    JP=l[1329];
    O(l[715]);
    P(yP,H,{[l[2]]=l[323],[l[936]]=C[l[1379]]});
    i();
  end);
  d(yP[l[412]],function(z)
    local n=s[87]();
    local J=z[l[1317]]==n[l[128]][l[1317]][l[1356]]or z[l[1317]]==n[l[128]][l[1317]][l[239]];
    if J then
      JP=l[1329];
    end
  end);
  d(y[10][l[756]],function()
    local z=s[87]();
    if not u[l[1600]] then
      return;
    end
    local n=z[l[655]][l[1587]]();
    z=n-HP;
    if z<Y[l[871]] then
      return;
    end
    HP=n;
    n=not sP;
    if n then
      LP();
    else
      z=JP;
      if not z then
        i();
      end
    end
  end);
  jP(o);
  r,p=o:GetDescendants();
  for z,z in y[3],r,p do
    jP(z);
  end;
  CP(l[229]);
  _(T,o,l[1209]);
  j[l[1346]][l[968]](y[18][l[1438]],u);
  return u;
end
