-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #97
-- offset 3688445..3688665 (220 bytes, type=payload)

local function a()
  pcall(function()
    if not(writefile and isfolder) then
      return;
    end
    local b;
    local b,b=d,not isfolder(d);
    if b then
      local b=d;
      makefolder(b);
    end
    writefile(T,game:GetService("HttpService"):JSONEncode(H));
  end);
end
