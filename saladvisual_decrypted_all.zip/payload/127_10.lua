-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #10
-- offset 203443..203817 (374 bytes, type=payload)

local function z()
  local T;
  local T=D or o or not y[4][y[6]]or not d.On;
  if T then
    return;
  end
  o=true;
  local T=K;
  task.spawn(function()
    local n,e=pcall(w,T);
    local j=K;
    if T~=j then
      return;
    end
    o=false;
    if not n then
      L();
      warn("[visuals] Starfall: "..tostring(e));
      return;
    end
    j=not e or not y[4][y[6]]or not d.On;
    if j then
      return;
    end
    p=0;
    local y;
    e=J;
    D=e.RenderStepped:Connect(G);
  end);
end
