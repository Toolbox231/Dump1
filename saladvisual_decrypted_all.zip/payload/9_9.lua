-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #9
-- offset 3630462..3630672 (210 bytes, type=payload)

local function A()
  local W=Y;
  if W then
    return;
  end
  local W=a:GetMouse();
  local V,_=pcall(W.GetPropertyChangedSignal,W,"Icon");
  if not V then
    return;
  end
  Y=_:Connect(function()
    if W.Icon~="" then
      W.Icon="";
    end
  end);
end
