-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #39
-- offset 3672893..3674040 (1147 bytes, type=payload)

function(s)
  local r=l._resumePack;
  l._resumePack=nil;
  l._request=l._request+1;
  l.PendingEmoteId=nil;
  l.PendingPack=nil;
  l.SelectedEmoteId=nil;
  if l._emoteStopped then
    l._emoteStopped:Disconnect();
    l._emoteStopped=nil;
  end
  if l._emotePlayed then
    l._emotePlayed:Disconnect();
    l._emotePlayed=nil;
  end
  local K=l._currentEmoteTrack;
  l._currentEmoteTrack=nil;
  local o=l._currentEmoteAnim;
  l._currentEmoteAnim=nil;
  if K then
    pcall(function()
      K:Stop(0);
    end);
    task.delay(0.25,function()
      pcall(function()
        K:Destroy();
      end);
      if o then
        pcall(function()
          o:Destroy();
        end);
      end
    end);
  elseif o then
    o:Destroy();
  end
  local o=l._emoteAnimate;
  local c=l._emoteAnimateWasEnabled;
  l._emoteAnimate=nil;
  l._emoteAnimateWasEnabled=nil;
  local m;
  if o then
    local S;
    S,m=z,o.Parent==z.Character;
  else
    m=o;
  end
  if m then
    local m=o.Parent:FindFirstChildOfClass("Humanoid");
    if m then
      if c then
        pcall(function()
          o.Disabled=false;
        end);
      end
      b(m,o);
    end
  elseif K then
    local K=z;
    local o=K.Character;
    local K,c=o and(o:FindFirstChildOfClass("Humanoid")),o and(o:FindFirstChild("Animate"));
    if K and c then
      b(K,c);
    end
  end
  if l.OnStateChange then
    l.OnStateChange();
  end
  if r and not s and l.Alive then
    l.ApplyPack(r);
  end
end
