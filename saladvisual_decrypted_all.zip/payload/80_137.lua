-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #137
-- offset 3306557..3307028 (471 bytes, type=payload)

local function TP()
  local nP={};
  local HP=y[18][l[1028]][y[18][l[1043]]];
  local fP,aP=y[18][l[1429]]and(y[18][l[583]]or y[18][l[1455]])and not y[18][l[388]]and HP~=nil,m~=nil;
  if fP==aP then
    if fP then
      U(HP);
    end
    return;
  end
  if fP then
    nP[1]=y[9][l[1181]];
    lP=nP[1];
    U(HP);
    LP();
    c[l[1324]]=l[383];
    nP[2]=(y[10][l[1119]]:Connect(LP));
    m=nP[2];
    return;
  end
  m:Disconnect();
  m=nil;
  c[l[1324]]=l[1329];
  HP=lP~=nil;
  if HP then
    nP[3]=y[9];
    nP[4]=l[1181];
    nP[5]=lP;
    nP[3][nP[4]]=nP[5];
    lP=nil;
  end
end
