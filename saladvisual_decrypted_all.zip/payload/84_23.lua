-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #23
-- offset 3668107..3670541 (2434 bytes, type=payload)

function(s)
  if not l.Alive then
    return false;
  end
  D();
  l._resumePack=nil;
  l.ResetEmote(true);
  local S=l._request;
  local O,B=s or l.PackName or"Default",z;
  local s=B.Character;
  l.PackName="Default";
  l.PendingPack=O~="Default"and O or nil;
  if l.OnStateChange then
    l.OnStateChange();
  end
  local B,A,w=p(),s and(s:FindFirstChildOfClass("Humanoid")),s and(s:FindFirstChild("Animate"));
  if B and A and w then
    b(A,w);
  end
  if O=="Default" then
    l.LastError=nil;
    return true;
  end
  local w=o[O];
  if not w then
    l.PendingPack=nil;
    if l.OnStateChange then
      l.OnStateChange();
    end
    return false;
  end
  A,B=task,function()
    local F,h=pcall(m,w);
    local m,w=not l.Alive or S~=l._request;
    if m then
      w=m;
    else
      local W=z;
      w=W.Character~=s;
    end
    if w then
      return;
    end
    w=z;
    m=w.Character;
    local s,w=m and(m:FindFirstChildOfClass("Humanoid")),m and(m:FindFirstChild("Animate"));
    l.PendingPack=nil;
    if not(F and h and#h>0 and s and w) then
      l.LastError="Animation pack could not load on this character";
      if l.OnStateChange then
        l.OnStateChange();
      end
      return;
    end
    m,F=s.RigType==Enum.HumanoidRigType.R6 and"R6"or"R15",{};
    for W,W in ipairs(h)do
      if W.rig==m then
        F[#F+1]=W;
      end
    end;
    for W,W in ipairs(h)do
      if not W.rig then
        F[#F+1]=W;
      end
    end;
    h={};
    for W,W in ipairs(F)do
      m=W.category and W.category:lower();
      if m and not h[m] then
        h[m]=W.id;
      end
    end;
    local m,W,V,_=h.idle or h.walk or h.run or h.jump or h.fall or h.climb or h.swim or h.swimidle,{walk="run",run="walk",jump="fall",fall="jump",swim="swimidle",swimidle="swim"},{"idle","walk","run","jump","fall","climb","swim","swimidle"},0;
    for X,X in ipairs(V)do
      _+=c(w,X,F,h[W[X]]or m);
    end;
    if _>0 then
      l.PackName=O;
      l.LastError=nil;
      local c={};
      for m,h in ipairs(F)do
        m=N(h.id);
        if m then
          c[m]=true;
        end
      end;
      local function m(F)
        if not l.Alive or S~=l._request or l.PackName~=O then
          return;
        end
        l._packPlayed=F.AnimationPlayed:Connect(function(S)
          if l.PackName~=O then
            return;
          end
          local O,F,h=pcall(function()
            return N(S.Animation.AnimationId),S.Priority.Value;
          end);
          if O and h<=Enum.AnimationPriority.Movement.Value and not c[F] then
            pcall(function()
              S:Stop(0);
            end);
          end
        end);
      end
      W=s:FindFirstChildOfClass("Animator");
      if W then
        m(W);
      else
        l._packAnimatorAdded=s.ChildAdded:Connect(function(c)
          if not c:IsA("Animator") then
            return;
          end
          local S=l._packAnimatorAdded;
          l._packAnimatorAdded=nil;
          if S then
            S:Disconnect();
          end
          m(c);
        end);
      end
      b(s,w);
    else
      l.LastError="This pack has no matching animation slots";
    end
    if l.OnStateChange then
      l.OnStateChange();
    end
  end;
  A.spawn(B);
  return true;
end
