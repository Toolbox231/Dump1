-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #71
-- offset 3680687..3681732 (1045 bytes, type=payload)

function()
  while true do
    task.wait(0.5);
    local r,K=not l.Alive;
    if r then
      K=r;
    else
      local r;
      local r=T;
      local T=r.stage=="ready";
      if T then
        r=y;
        K=r.Status.stage~="fetching";
      else
        K=T;
      end
    end
    if K then
      break;
    end
  end;
  if not l.Alive then
    return;
  end
  local T=b();
  if T then
    l.EmoteCatalog=p(l.EmoteCatalog,T);
    l._refreshEmoteList();
    if l._buildEmoteGrid then
      pcall(l._buildEmoteGrid);
    end
    local b,p=pcall(function()
      return isfile(q)and tonumber(readfile(q));
    end);
    if b and p and os.time()-p<86400 then
      return;
    end
  end
  for b=1,5,1 do
    if not l.Alive then
      return;
    end
    T=C();
    if not l.Alive then
      return;
    end
    if #T>0 then
      local C,b={},{};
      for p,p in ipairs(l.EmoteCatalog)do
        if p and p.id and not C[p.id] then
          p.name=j(p.name or p.id);
          C[p.id]=true;
          b[#b+1]=p;
        end
      end;
      for p,p in ipairs(T)do
        if p and p.id and not C[p.id] then
          p.name=j(p.name or p.id);
          C[p.id]=true;
          b[#b+1]=p;
        end
      end;
      l.EmoteCatalog=b;
      D(l.EmoteCatalog);
      pcall(function()
        writefile(q,tostring(os.time()));
      end);
      l._refreshEmoteList();
      if l._buildEmoteGrid then
        pcall(l._buildEmoteGrid);
      end
      return;
    end
    task.wait(3);
  end;
end
