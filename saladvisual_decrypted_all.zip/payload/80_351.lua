-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #351
-- offset 3396331..3402899 (6568 bytes, type=payload)

local function NP(BP,wP)
  BP=s[87]();
  wP=X(wP,{[l[572]]=l[1223],[l[457]]=l[393],[l[850]]=l[856],[l[950]]=nil,[l[109]]=l[229],[l[26]]=l[1746],[l[1013]]=nil,[l[1617]]=nil});
  fP[l[668]]+=l[229];
  local WP,VP=aP[l[1594]--[[__index]]],aP[l[438]];
  local _P,XP=aP[l[745]],BP[l[35]][l[850]](BP[l[1382]](wP[l[109]])or l[229],l[393]);
  local xP=XP>l[393]and XP<l[229]and#(BP[l[409]][l[56]](BP[l[1130]](XP),l[361])or l[1746])or l[393];
  local kP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},WP);
  local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[229]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1057],l[393],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=wP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},kP);
  local IP=a(l[1070],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[393]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=BP[l[1459]][l[588]](l[1167],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[874],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[877]],[l[711]]=l[1158]},kP);
  local iP=a(l[211],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[1243]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},kP);
  local EP,QP=l[1112],{};
  QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
  a(EP,QP,iP);
  local tP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1092]},iP);
  EP,QP=l[1112],{};
  QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
  a(EP,QP,tP);
  local RP,gP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[393],l[973]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[114]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},kP),{[l[266]]=kP,[l[1019]]=wP[l[457]]};
  local uP=l[1329];
  local UP,MP,sC=l[1329];
  EP,QP,WP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=kP};
  WP[l[572]]=wP[l[572]];
  EP(QP,WP);
  local function lC(LC)
    local yC=s[87]();
    if xP>l[393] then
      return yC[l[409]][l[846]](l[1213]..xP..l[347],LC)..wP[l[26]];
    end
    return yC[l[409]][l[846]](l[1489],yC[l[35]][l[499]](LC+l[659]))..wP[l[26]];
  end
  local function LC(yC)
    local zC=s[87]();
    yC=zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
    yC=if XP>l[393]then wP[l[457]]+zC[l[35]][l[499]]((yC-wP[l[457]])/XP+l[659])*XP else yC;
    yC=if xP>l[393]then zC[l[1382]](zC[l[409]][l[846]](l[1213]..xP..l[347],yC))or yC else yC;
    return zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
  end
  local function yC(zC)
    local TC=s[87]();
    return TC[l[1459]][l[772]](zC,TC[l[35]][l[499]](l[1158]*(l[229]-zC)+l[659]),l[229],l[393]);
  end
  local function zC()
    local TC=wP[l[850]]-wP[l[457]];
    local nC=TC>l[393]and(gP[l[1019]]-wP[l[457]])/TC or l[393];
    IP[l[1420]]=lC(gP[l[1019]]);
    local TC,JC=UP and J or n,{};
    JC[l[1639]]=yC(nC);
    P(tP,TC,JC);
  end
  local function J()
    P(iP,H,{[l[1646]]=(UP or uP)and l[393]or l[841]});
    local yC,TC,nC={},l[1646],UP and l[393]or(uP and l[613]or l[1209]);
    yC[TC]=nC;
    P(tP,H,yC);
    P(vP,H,{[l[916]]=(UP or uP)and l[1209]or l[615]});
    P(IP,H,{[l[916]]=(UP or uP)and l[393]or l[874]});
  end
  local function vP(IP,tP,yC)
    IP=s[87]();
    tP=LC(IP[l[1382]](tP)or wP[l[457]]);
    if gP[l[1019]]==tP and not y[18][l[921]] then
      return;
    end
    gP[l[1019]]=tP;
    zC();
    if not yC and wP[l[1617]] then
      I(wP[l[1617]],tP);
    end
  end
  gP[l[1255]]=vP;
  local function vP(IP)
    return gP[l[1019]];
  end
  gP[l[506]]=vP;
  local function IP(tP)
    if tP and tP[l[948]] then
      return tP[l[948]][l[1437]];
    end
    return y[9]:GetMouseLocation()[l[1437]];
  end
  local function tP(yC)
    local TC,nC,JC=s[87](),iP[l[81]],iP[l[160]];
    if JC[l[1437]]<=l[393] then
      return gP[l[1019]];
    end
    return wP[l[457]]+(wP[l[850]]-wP[l[457]])*TC[l[35]][l[819]]((yC-nC[l[1437]])/JC[l[1437]],l[393],l[229]);
  end
  local function iP()
    local yC=sC;
    if yC then
      sC:Disconnect();
      sC=nil;
    end
    yC=UP;
    if not yC then
      return;
    end
    UP,MP=l[1329],nil;
    VP[l[1195]]=l[383];
    O(l[715]);
    zC();
    J();
  end
  d(RP[l[1558]],function(yC)
    local TC={};
    local nC=s[87]();
    if yC[l[1317]]~=nC[l[128]][l[1317]][l[1356]]and yC[l[1317]]~=nC[l[128]][l[1317]][l[239]] then
      return;
    end
    local JC=UP;
    if JC then
      return;
    end
    UP=l[383];
    MP=yC[l[1317]]==nC[l[128]][l[1317]][l[239]]and yC or nil;
    JC=sC;
    if JC then
      sC:Disconnect();
    end
    TC[1]=(y[10][l[756]]:Connect(function()
      local nC,JC,HC=s[87](),MP;
      if JC then
        local JC=MP;
        local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
        if fC then
          HC=fC;
        else
          JC=MP;
          HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
        end
      else
        HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
      end
      if not HC then
        iP();
      end
    end));
    sC=TC[1];
    O(l[229]);
    J();
    VP[l[1195]]=l[1329];
    y[18]:chime(l[1320]);
    gP:set(tP(IP(yC)));
  end);
  local function sC(yC)
    local TC,nC=s[87](),MP;
    if nC then
      local nC=MP;
      return yC==nC;
    end
    return yC[l[1317]]==TC[l[128]][l[1317]][l[1356]];
  end
  d(RP[l[412]],function(yC)
    if sC(yC) then
      iP();
    end
  end);
  d(y[9][l[233]],function(yC)
    local TC,nC=s[87](),UP;
    if not nC then
      return;
    end
    nC=MP;
    if nC then
      local UP=MP;
      if yC~=UP then
        return;
      end
    elseif yC[l[1317]]~=TC[l[128]][l[1317]][l[765]] then
      return;
    end
    gP:set(tP(IP(yC)));
  end);
  d(y[9][l[412]],function(IP)
    if sC(IP) then
      iP();
    end
  end);
  d(kP[l[1538]],function()
    uP=l[383];
    J();
  end);
  d(kP[l[1628]],function()
    uP=l[1329];
    J();
  end);
  gP[l[1019]]=LC(BP[l[1382]](wP[l[950]])or wP[l[457]]);
  zC();
  local J,IP,iP=wP[l[1013]]or hP..l[1074]..wP[l[572]];
  EP,WP,QP,vP=wP[l[572]],VP,{[l[1463]]=J,[l[103]]=l[1716],[l[649]]=l[383],[l[1019]]={[l[457]]=wP[l[457]],[l[850]]=wP[l[850]],[l[109]]=XP,[l[1647]]=xP,[l[26]]=wP[l[26]],[l[950]]=gP[l[1019]]},[l[1735]]=function()
    return lC(iP[l[1019]]);
  end},l[1498];
  local function VP(XP)
    if XP then
      local XP=IP==nil;
      if XP then
        IP=gP[l[1019]];
      end
      gP:set(iP[l[1019]]);
    else
      local XP=IP~=nil;
      if XP then
        gP:set(IP);
        IP=nil;
      end
    end
    iP:lit(IP~=nil);
  end
  QP[vP]=VP;
  QP[l[194]]=function()
    iP[l[1273]]=not iP[l[1273]];
    iP[l[1498]](iP[l[1273]]);
  end;
  QP[l[1386]]=function()
    local VP=IP;
    return VP~=nil;
  end;
  iP=SP(kP,EP,WP,_P,QP);
  gP[l[1686]]=iP;
  vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[973]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},kP);
  local function BP()
    if not iP:flip() then
      return;
    end
    y[18]:chime(l[1352]);
  end
  d(vP[l[861]],BP);
  d(RP[l[1558]],function(WP)
    local VP=s[87]();
    if WP[l[1317]]==VP[l[128]][l[1317]][l[321]--[[-1]]] then
      BP();
    end
  end);
  y[18]:hook(J,l[384],function()
    return gP[l[1019]];
  end,function(J)
    gP:set(J);
  end,{[l[457]]=wP[l[457]],[l[850]]=wP[l[850]]});
  return gP;
end
