-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[82] / function #13
-- offset 30271..30789 (518 bytes, type=payload)

local function T()
  local N=Z and Z.Parent;
  if N then
    return;
  end
  Z=Instance.new("Part");
  local p;
  local p,r=Z,n;
  p.Name=n.RandomString();
  Z.Anchored=true;
  Z.CanCollide=false;
  Z.CanQuery=false;
  Z.CanTouch=false;
  Z.CastShadow=false;
  Z.Transparency=1;
  p=Z;
  p.Size=Vector3.new(P.Distance,P.Height,P.Distance);
  N,p=L,y;
  Z:SetAttribute(N,p);
  N=Z;
  N.Parent=workspace;
  G=Instance.new("ParticleEmitter");
  pcall(function()
    local L=G;
    L.Shape=Enum.ParticleEmitterShape.Box;
    L=G;
    L.ShapeStyle=Enum.ParticleEmitterShapeStyle.Volume;
  end);
  G.Parent=Z;
  q();
end
