-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #18
-- offset 3632650..3632859 (209 bytes, type=payload)

function(n)
  task.wait(0.3);
  local c;
  local c=not z[4][z[6]]or not P or p~=w or a.Character~=n;
  if c then
    return;
  end
  T(n,"character");
  T(a:FindFirstChildOfClass("Backpack"),"backpack");
  l=m();
  y(true,l);
  Y(l and Z);
end
