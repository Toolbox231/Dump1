-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #1
-- offset 3593007..3609907 (16900 bytes, type=payload)

function(l,l,L,L)
  local L=l[1];
  local y=l[2];
  local z=l[3];
  local T=l[4];
  local n=l[5];
  local J=l[6];
  local H=l[7];
  local f=l[8];
  local a=l[9];
  local d=l[10];
  return function()
    local l=game:GetService("UserInputService");
    local P;
    local P=L;
    local Z=P.Lib;
    local G,Y=Z.theme;
    local function e()
      local j=Y and Y.Parent;
      if j then
        local C=Y;
        return C;
      end
      j=L;
      local C,N=j.WindowFrame;
      if C then
        j=L;
        N=j.WindowFrame.Parent;
      else
        N=C;
      end
      if N then
        C=L;
        Y=C.WindowFrame;
        j=Y;
        return j;
      end
      N,C=ipairs,L;
      j=s[70](C.ScreenGui:GetChildren());
      for q,b in N(s:ZT(j))do
        q=b:IsA("Frame")and b.Active and b.AnchorPoint==Vector2.new(0.5,0.5);
        if q then
          Y=b;
        end
      end;
      C=Y;
      return C;
    end
    local Y;
    P=y;
    P.WindowFrame=e;
    local function Y(j,C,N)
      local q=Instance.new(j);
      for j,b in pairs(C)do
        q[j]=b;
      end;
      q.Parent=N;
      return q;
    end
    local j,C,N=Y,{},L;
    C.Name=N.RandomString();
    C.BackgroundColor3=Color3.fromRGB(8,8,13);
    C.BackgroundTransparency=0.0255;
    C.BorderSizePixel=0;
    C.ClipsDescendants=true;
    N,P=Z.shown==true;
    if N then
      local q=L;
      P=not q.Mobile;
    else
      P=N;
    end
    C.Visible=P;
    C.ZIndex=0;
    P=L;
    local q=j("Frame",C,P.ScreenGui);
    Y("UICorner",{CornerRadius=UDim.new(0,8)},q);
    N,j,C=Y,{AnchorPoint=Vector2.new(0,0.5),BackgroundTransparency=1,Position=UDim2.new(0,12,0,20),Size=UDim2.fromOffset(16,16)},L;
    j.TextColor3=C.AccentColor;
    j.TextSize=14;
    j.ZIndex=4;
    C,P=N("TextLabel",j,q),L;
    P.ApplyIcon(C,"person");
    local b,D,p=Y,{AnchorPoint=Vector2.new(0,0.5),BackgroundTransparency=1,Position=UDim2.new(0,34,0,20),Size=UDim2.new(1,-70,0,14),Font=Enum.Font.GothamBold};
    N=z;
    D.Text=N.DisplayName;
    D.TextColor3=G.text;
    D.TextSize=12;
    D.TextTruncate=Enum.TextTruncate.AtEnd;
    D.TextXAlignment=Enum.TextXAlignment.Left;
    D.ZIndex=4;
    b("TextLabel",D,q);
    P,C,N,b=Y("ImageButton",{AnchorPoint=Vector2.new(1,0.5),Position=UDim2.new(1,-12,0,20),Size=UDim2.fromOffset(16,16),BackgroundTransparency=1,AutoButtonColor=false,ImageColor3=G.dim,ZIndex=5,Image=Z.icons["refresh-cw"]and"rbxassetid://"..Z.icons["refresh-cw"]or""},q),Y,{},L;
    N.Name=b.RandomString();
    N.AnchorPoint=Vector2.new(0,0.5);
    N.Size=UDim2.fromOffset(22,52);
    N.BackgroundColor3=Color3.fromRGB(8,8,13);
    N.BackgroundTransparency=0.0255;
    N.BorderSizePixel=0;
    N.AutoButtonColor=false;
    N.Text="";
    N.Visible=false;
    N.ZIndex=0;
    D=L;
    local p=C("TextButton",N,D.ScreenGui);
    Y("UICorner",{CornerRadius=UDim.new(0,7)},p);
    local r,K=Y("ImageLabel",{AnchorPoint=Vector2.new(0.5,0.5),Position=UDim2.new(0.5,4,0.5,0),Size=UDim2.fromOffset(12,12),BackgroundTransparency=1,ImageColor3=G.dim,ZIndex=1,Image=Z.icons["chevron-right"]and"rbxassetid://"..Z.icons["chevron-right"]or""},p),L;
    local function o()
      r.ImageColor3=G.text;
    end
    K:AddSignal(p.MouseEnter:Connect(o));
    K=L;
    local function c()
      r.ImageColor3=G.dim;
    end
    K:AddSignal(p.MouseLeave:Connect(c));
    Y("Frame",{BackgroundColor3=G.line,BackgroundTransparency=0.5,BorderSizePixel=0,Position=UDim2.new(0,12,0,40),Size=UDim2.new(1,-24,0,1),ZIndex=4},q);
    j=Y("Frame",{Position=UDim2.fromOffset(0,41),Size=UDim2.new(1,0,1,-41),BackgroundColor3=G.panel,BorderSizePixel=0,ClipsDescendants=true,Active=true,ZIndex=1},q);
    Y("UICorner",{CornerRadius=UDim.new(0,8)},j);
    Y("UIGradient",{Rotation=90,Color=ColorSequence.new(Color3.new(1,1,1),Color3.fromRGB(150,150,165))},j);
    local G=Y("ImageLabel",{AnchorPoint=Vector2.new(0.5,0.5),Position=UDim2.fromScale(0.5,0.45),Size=UDim2.fromScale(1.15,0.85),BackgroundTransparency=1,ImageTransparency=1,ScaleType=Enum.ScaleType.Fit,ZIndex=2},j);
    task.spawn(function()
      local m;
      local m=T;
      local S,S=T,m.id(T.file("particles/p_glow.png"));
      if S and G.Parent then
        G.Image=S;
      end
    end);
    K=Y("Frame",{AnchorPoint=Vector2.new(0.5,0.5),Position=UDim2.fromScale(0.5,0.9),Size=UDim2.new(0.55,0,0,10),BackgroundColor3=Color3.new(0,0,0),BackgroundTransparency=0.4,BorderSizePixel=0,ZIndex=2},j);
    Y("UICorner",{CornerRadius=UDim.new(1,0)},K);
    Y("UIGradient",{Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.5,0),NumberSequenceKeypoint.new(1,1)})},K);
    local T=Y("ViewportFrame",{Size=UDim2.fromScale(1,1),BackgroundTransparency=1,Ambient=Color3.fromRGB(200,200,208),LightColor=Color3.fromRGB(255,250,242),LightDirection=Vector3.new(-0.4,-0.9,-0.6),ZIndex=3},j);
    local m=Y("WorldModel",{},T);
    local S=Y("Camera",{FieldOfView=30},T);
    T.CurrentCamera=S;
    local O,B,A=Y("Frame",{Size=UDim2.fromScale(1,1),BackgroundTransparency=1,ZIndex=6},j),{Head=true,Torso=true,["Left Arm"]=true,["Right Arm"]=true,["Left Leg"]=true,["Right Leg"]=true,UpperTorso=true,LowerTorso=true,LeftUpperArm=true,LeftLowerArm=true,LeftHand=true,RightUpperArm=true,RightLowerArm=true,RightHand=true,LeftUpperLeg=true,LeftLowerLeg=true,LeftFoot=true,RightUpperLeg=true,RightLowerLeg=true,RightFoot=true};
    local w=Vector3.zero;
    local F,h=Vector3.new(4,5,2),{LuaSourceContainer=true,Sound=true,ForceField=true,Highlight=true,BillboardGui=true,ParticleEmitter=true,Trail=true,Beam=true,Light=true,Fire=true,Smoke=true,Sparkles=true,SelectionBox=true,BoxHandleAdornment=true};
    local function W()
      local V=A;
      if V then
        pcall(y.Restore,A);
        A:Destroy();
        A=nil;
      end
    end
    local V,_,X,X=false,0;
    X,n.Refresh=n,function()
      _+=1;
      local x=not q.Visible;
      if x then
        local k=n;
        k.NeedsRefresh=true;
        return;
      end
      x=n;
      x.NeedsRefresh=false;
      local x,k=A==nil,V;
      if k then
        return;
      end
      V=true;
      task.spawn(function()
        task.wait(x and 0.25 or 0);
        while true do
          local x;
          local x=J[4][J[6]];
          if not x then
            break;
          end
          x=not q.Visible;
          if x then
            local k=n;
            k.NeedsRefresh=true;
            break;
          end
          local k,v=_,z;
          local I=v.Character;
          if not(I and I.Parent) then
            break;
          end
          x=I.Archivable;
          I.Archivable=true;
          local i,E=pcall(function()
            return I:Clone();
          end);
          I.Archivable=x;
          v=not(i and E);
          if v then
            x=_;
            if k==x then
              break;
            end
            continue;
          end
          x,i=ipairs,s[70](E:GetDescendants());
          for Q,t in x(s:ZT(i))do
            pcall(function()
              local s=false;
              for R in pairs(h)do
                if t:IsA(R) then
                  s=true;
                  break;
                end
              end;
              if s then
                t:Destroy();
              elseif t:IsA("BasePart") then
                t.Anchored=true;
                t.CanCollide=false;
                t.CanQuery=false;
                t.CanTouch=false;
                t.LocalTransparencyModifier=0;
              end
            end);
            if Q%48==0 then
              task.wait();
            end
            v=not J[4][J[6]]or k~=_ or not q.Visible;
            if v then
              break;
            end
          end;
          i=J[4][J[6]];
          if not i then
            E:Destroy();
            break;
          end
          i=not q.Visible;
          if i then
            E:Destroy();
            x=n;
            x.NeedsRefresh=true;
            break;
          end
          x,v=k~=_;
          if x then
            v=x;
          else
            i=z;
            v=i.Character~=I;
          end
          if v then
            E:Destroy();
            continue;
          end
          local s=E:FindFirstChildOfClass("Humanoid");
          if s then
            s.DisplayDistanceType=Enum.HumanoidDisplayDistanceType.None;
            pcall(function()
              s.HealthDisplayType=Enum.HumanoidHealthDisplayType.AlwaysOff;
            end);
          end
          i=E:FindFirstChild("HumanoidRootPart")or E:FindFirstChild("UpperTorso")or E:FindFirstChild("Torso");
          x=not i;
          if x then
            E:Destroy();
            v=_;
            if k==v then
              break;
            end
            continue;
          end
          E.PrimaryPart=i;
          E:PivotTo(CFrame.Angles(0,3.141592653589793,0));
          local s,h,Q,t,R,g=1/0,1/0,1/0,-1/0,-1/0,-1/0;
          for u,U in ipairs(E:GetChildren())do
            if U:IsA("BasePart")and B[U.Name] then
              v,i=U.Size/2,{-1,1};
              for M,sP in ipairs(i)do
                u={-1,1};
                for lP,LP in ipairs(u)do
                  lP={-1,1};
                  for u,u in ipairs(lP)do
                    M=U.CFrame*Vector3.new(v.X*sP,v.Y*LP,v.Z*u);
                    s,h,Q,t,R=math.min(s,M.X),math.min(h,M.Y),math.min(Q,M.Z),math.max(t,M.X),math.max(R,M.Y);
                    g=math.max(g,M.Z);
                  end;
                end;
              end;
            else
            end
          end;
          i,x=k~=_;
          if i then
            x=i;
          else
            v=z;
            x=v.Character~=I;
          end
          if x then
            E:Destroy();
            continue;
          end
          W();
          E.Parent=m;
          A=E;
          v=t>s;
          if v then
            i,x=Vector3.new((s+t)/2,(h+R)/2,(Q+g)/2),Vector3.new(t-s,R-h,g-Q);
            w,F=i,x;
          else
            local s,m=E:GetBoundingBox();
            w,F=s.Position,m;
          end
          E=n;
          x=E.Paint;
          if x then
            pcall(n.Paint);
          end
          E=_;
          if k==E then
            break;
          end
        end;
        V=false;
      end);
    end;
    N=L;
    local function s()
      pcall(function()
        Z:chime("tap");
      end);
      local m=n;
      m.Refresh();
    end
    N:AddSignal(P.MouseButton1Click:Connect(s));
    local s,m,h,_,x=0,1,false;
    local function k()
      local v=T.AbsoluteSize;
      if v.X<2 or v.Y<2 then
        return;
      end
      local I,i=math.tan(math.rad(S.FieldOfView)/2),v.X/v.Y;
      local v,E=(math.max(F.Y/2/I,math.max(F.X,F.Z)/2/(I*i))*1.25+F.Z/2)*m,w;
      I=E+Vector3.new(0,F.Y*0.02,0);
      S.CFrame=CFrame.lookAt(I+Vector3.new(math.sin(s),0.1,math.cos(s)).Unit*v,I);
    end
    o=L;
    o:AddSignal(j.InputBegan:Connect(function(v)
      local I=v.UserInputType==Enum.UserInputType.MouseButton1 or v.UserInputType==Enum.UserInputType.Touch;
      if I then
        local I;
        I,h=v.Position.X,true;
        _=I;
        x=v.UserInputType==Enum.UserInputType.Touch and v or nil;
      end
    end));
    C=L;
    C:AddSignal(j.InputChanged:Connect(function(v)
      local I=v.UserInputType==Enum.UserInputType.MouseWheel;
      if I then
        local I,i=math.clamp,m;
        m=I(i*(v.Position.Z>0 and 0.86 or 1.16),0.45,2.5);
        k();
      end
    end));
    D=L;
    D:AddSignal(l.InputChanged:Connect(function(v)
      local I=h;
      if not I then
        return;
      end
      I=x and v==x or not x and v.UserInputType==Enum.UserInputType.MouseMovement;
      if I then
        local I=v.Position.X-(_ or v.Position.X);
        _=v.Position.X;
        local _=s;
        s=_-I*0.012;
      end
    end));
    X=L;
    X:AddSignal(l.InputEnded:Connect(function(_)
      local v=x and _==x or not x and _.UserInputType==Enum.UserInputType.MouseButton1;
      if v then
        h,x=false,nil;
      end
    end));
    local h,_=Vector2.zero,{-1,1};
    local function x(v)
      local I=S.CFrame:PointToObjectSpace(v);
      if I.Z>-0.05 then
        return nil;
      end
      v=h;
      local i=v.Y/2/math.tan(math.rad(S.FieldOfView)/2);
      return Vector2.new(v.X/2+I.X/-I.Z*i,v.Y/2-I.Y/-I.Z*i);
    end
    local v,I={},0;
    local function i()
      I+=1;
      local E=v[I];
      local Q=not E;
      if Q then
        E=Y("Frame",{AnchorPoint=Vector2.new(0.5,0.5),BorderSizePixel=0,ZIndex=7},O);
        v[I]=E;
      else
      end
      E.Visible=true;
      return E;
    end
    local function E(Q,t,R,g)
      local u,U=t-Q,i();
      U.BackgroundColor3=R;
      U.BackgroundTransparency=0;
      U.Position=UDim2.fromOffset((Q.X+t.X)/2,(Q.Y+t.Y)/2);
      U.Size=UDim2.fromOffset(u.Magnitude+g*0.5,g);
      U.Rotation=math.deg(math.atan2(u.Y,u.X));
    end
    local i=Y("Frame",{BorderSizePixel=0,Visible=false,ZIndex=6},O);
    local function Q(t)
      return Y("TextLabel",{AnchorPoint=Vector2.new(0.5,0.5),BackgroundTransparency=1,Font=Enum.Font.GothamBold,TextSize=t,TextStrokeTransparency=0.5,Size=UDim2.fromOffset(160,14),Visible=false,ZIndex=8},O);
    end
    local Y=Q(12);
    local O,t=Q(11),{{"Head","UpperTorso"},{"UpperTorso","LowerTorso"},{"UpperTorso","LeftUpperArm"},{"LeftUpperArm","LeftLowerArm"},{"LeftLowerArm","LeftHand"},{"UpperTorso","RightUpperArm"},{"RightUpperArm","RightLowerArm"},{"RightLowerArm","RightHand"},{"LowerTorso","LeftUpperLeg"},{"LeftUpperLeg","LeftLowerLeg"},{"LeftLowerLeg","LeftFoot"},{"LowerTorso","RightUpperLeg"},{"RightUpperLeg","RightLowerLeg"},{"RightLowerLeg","RightFoot"},{"Head","Torso"},{"Torso","Left Arm"},{"Torso","Right Arm"},{"Torso","Left Leg"},{"Torso","Right Leg"}};
    local function R()
      I=0;
      h=T.AbsoluteSize;
      i.Visible=false;
      Y.Visible=false;
      O.Visible=false;
      local h,g,g=A;
      if h then
        local u=H;
        g=u.Enabled;
      else
        g=h;
      end
      if g then
        local g,u,U,M,sP=1/0,1/0,-1/0,-1/0,A;
        for lP,LP in ipairs(sP:GetChildren())do
          if LP:IsA("BasePart")and B[LP.Name] then
            h=LP.Size/2;
            for B,B in ipairs(_)do
              for yP,yP in ipairs(_)do
                for zP,zP in ipairs(_)do
                  lP=x(LP.CFrame*Vector3.new(h.X*B,h.Y*yP,h.Z*zP));
                  if lP then
                    g,u,U=math.min(g,lP.X),math.min(u,lP.Y),math.max(U,lP.X);
                    M=math.max(M,lP.Y);
                  else
                  end
                end;
              end;
            end;
          else
          end
        end;
        sP=U>g;
        if sP then
          local B,_,lP,lP,LP=Vector2.new(g-3,u-3),Vector2.new(U+3,M+3),H,math.clamp(tonumber(H.BoxThickness)or 1,1,4),H;
          local g=LP.Box;
          if g then
            local u,U,M=Vector2.new(_.X,B.Y),Vector2.new(B.X,_.Y),H;
            LP=M.BoxStyle=="Corner";
            if LP then
              local yP,zP=(_.X-B.X)*0.25,(_.Y-B.Y)*0.2;
              E(B,B+Vector2.new(yP,0),H.BoxColor,lP);
              E(B,B+Vector2.new(0,zP),H.BoxColor,lP);
              E(u,u-Vector2.new(yP,0),H.BoxColor,lP);
              E(u,u+Vector2.new(0,zP),H.BoxColor,lP);
              E(U,U+Vector2.new(yP,0),H.BoxColor,lP);
              E(U,U-Vector2.new(0,zP),H.BoxColor,lP);
              E(_,_-Vector2.new(yP,0),H.BoxColor,lP);
              E(_,_-Vector2.new(0,zP),H.BoxColor,lP);
            else
              M=H;
              E(B,u,M.BoxColor,lP);
              local yP=H;
              E(U,_,yP.BoxColor,lP);
              yP=H;
              E(B,U,yP.BoxColor,lP);
              yP=H;
              E(u,_,yP.BoxColor,lP);
            end
            M=H;
            u=M.BoxFilled;
            if u then
              i.Visible=true;
              M=H;
              i.BackgroundColor3=M.BoxColor;
              i.BackgroundTransparency=0.82;
              i.Position,i.Size=UDim2.fromOffset(B.X,B.Y),UDim2.fromOffset(_.X-B.X,_.Y-B.Y);
            end
          end
          LP=H;
          g=LP.Name;
          if g then
            Y.Visible=true;
            LP,lP=z;
            lP,Y.Text,Y.TextColor3=H,LP.DisplayName,H.NameColor;
            Y.Position=UDim2.fromOffset((B.X+_.X)/2,B.Y-9);
          end
          LP=H;
          g=LP.Distance;
          if g then
            O.Visible=true;
            LP=nil;
            LP,O.Text,O.TextColor3=H,("%dm"):format(math.floor((S.CFrame.Position-w).Magnitude+0.5)),H.NameColor;
            O.Position=UDim2.fromOffset((B.X+_.X)/2,_.Y+9);
          end
        end
        sP=H;
        local Y=sP.Skeleton;
        if Y then
          sP=ipairs;
          for Y,S in sP(t)do
            Y=A;
            local O,B=Y:FindFirstChild(S[1]),A;
            Y=B:FindFirstChild(S[2]);
            B=O and Y and O:IsA("BasePart")and Y:IsA("BasePart");
            if B then
              local B,_=x(O.Position),x(Y.Position);
              S=B and _;
              if S then
                local Y=H;
                E(B,_,Y.SkeletonColor,1);
              end
            end
          end;
        end
      end
      h=I+1;
      for H=h,#v,1 do
        v[H].Visible=false;
      end;
    end
    local H=false;
    local Y,S=Color3.new(1,1,1),n;
    S.ReadAura=function()
      local S=y;
      local O=S.Aura;
      H=O and O.On and true or false;
      Y=O and O.Color or Y;
    end;
    local S,O,B=game:GetService("TweenService"),false,false;
    local function h()
      local _,x=e(),workspace.CurrentCamera;
      local v,I=x and x.ViewportSize or Vector2.new(1280,720),_ and _.AbsoluteSize or Vector2.new(640,480);
      local i,E=_ and _.AbsolutePosition or v/2-I/2,L;
      local t,g,u=E.ScreenGui.AbsolutePosition,math.floor(I.Y*0.46),16;
      _=i.X+I.X+u+g<=v.X;
      x=_ and i.X+I.X or i.X;
      return{right=_,width=g,height=I.Y,y=i.Y-t.Y,open=(_ and x+u or x-u-g)-t.X,tucked=(_ and x-g-16 or x+16)-t.X,edge=x-t.X,mid=i.Y+I.Y/2-t.Y};
    end
    local function _(x)
      local v=O;
      r.Rotation=x.right==v and 0 or 180;
      r.Position=UDim2.new(0.5,x.right and 4 or-4,0.5,0);
    end
    local function x(v)
      local I=h();
      local i=I.right and I.edge-10 or I.edge+10;
      i=if v then I.right and I.edge-22 or I.edge+22 else i;
      p.AnchorPoint=Vector2.new(I.right and 0 or 1,0.5);
      return UDim2.fromOffset(i,I.mid),I;
    end
    local function v()
      local I,i=x(false);
      p.Position=I;
      _(i);
      I=B or O;
      if I then
        return;
      end
      q.Size=UDim2.fromOffset(i.width,i.height);
      q.Position=UDim2.fromOffset(i.open,i.y);
    end
    local function _(x,I,i,E)
      local t=S:Create(x,TweenInfo.new(I,Enum.EasingStyle.Quint,E or Enum.EasingDirection.Out),i);
      t:Play();
      return t;
    end
    local function S()
      local x=h();
      B=true;
      _(r,0.25,{Rotation=x.right==O and 0 or 180});
      local r=O;
      if r then
        _(q,0.26,{Position=UDim2.fromOffset(x.tucked,x.y)},Enum.EasingDirection.In);
        task.delay(0.26,function()
          B=false;
          local r=O;
          if r then
            q.Visible=false;
          end
        end);
      else
        q.Size=UDim2.fromOffset(x.width,x.height);
        q.Position=UDim2.fromOffset(x.tucked,x.y);
        local r,h=Z.shown==true;
        if r then
          local I=L;
          h=not I.Mobile;
        else
          h=r;
        end
        q.Visible=h;
        _(q,0.3,{Position=UDim2.fromOffset(x.open,x.y)});
        task.delay(0.3,function()
          B=false;
          v();
        end);
      end
    end
    l=nil;
    l,n.SetShown=n,function(r)
      local B,h=not r,O;
      if h==B then
        return;
      end
      O=B;
      pcall(function()
        Z:chime("tap");
      end);
      S();
    end;
    local r=n;
    r.Shown=function()
      local r=O;
      return not r;
    end;
    K=L;
    K:AddSignal(p.MouseButton1Click:Connect(function()
      local r=n;
      r.SetShown(O);
    end));
    do
      local r;
      local function K()
        local S=e();
        local e=S and S~=r;
        if e then
          r=S;
          local e=L;
          e:AddSignal(S:GetPropertyChangedSignal("AbsolutePosition"):Connect(v));
          e=L;
          e:AddSignal(S:GetPropertyChangedSignal("AbsoluteSize"):Connect(v));
        end
      end
      K();
      N,D=L,L;
      Q,b=D.ScreenGui,function()
        K();
        v();
      end;
      N:AddSignal(Q.ChildAdded:Connect(b));
    end;
    local e,r=L;
    C=f;
    e:AddSignal(C.Signal:Connect(function(f)
      local e;
      if f then
        local r=L;
        e=not r.Mobile;
      else
        e=f;
      end
      q.Visible=e and not O;
      e=nil;
      if f then
        local r=L;
        e=not r.Mobile;
      else
        e=f;
      end
      p.Visible=e;
      v();
    end));
    C,N=Z.shown==true;
    if C then
      j=L;
      N=not j.Mobile;
    else
      N=C;
    end
    p.Visible=N;
    task.defer(v);
    local f,e=false,0;
    local function r()
      local K;
      K,f=os.clock(),true;
      e=K;
    end
    C,j=L,z;
    C:AddSignal(j.CharacterAdded:Connect(function()
      W();
      task.delay(1,function()
        local j;
        local j=J[4][J[6]];
        if j then
          r();
        end
      end);
    end));
    o,D=L,z;
    o:AddSignal(D.CharacterAppearanceLoaded:Connect(r));
    b,P=L,z;
    b:AddSignal(P.CharacterRemoving:Connect(W));
    C=y;
    l,c=C.GameFX;
    if l then
      b=y;
      c=b.GameFX.OnChange;
    else
      c=l;
    end
    if c then
      N=y;
      N.GameFX.OnChange(r);
    end
    local z,J={"model","korblox","headless","hairless","no_accessories","character","cosmetic","aura","china"};
    J,n.Queue=n,function(J)
      if type(J)~="string" then
        return;
      end
      for j,j in ipairs(z)do
        if string.sub(J,1,#j)==j then
          r();
          return;
        end
      end;
      J=n;
      local z=J.Paint;
      if z then
        pcall(n.Paint);
      end
    end;
    local z,J,j,C,D,r,K=0;
    local o,c,S=math.huge,L;
    N=a;
    c:AddSignal(N.RenderStepped:Connect(function(L)
      local a=not q.Visible;
      if a then
        o=1/0;
        return;
      end
      a=n;
      local N=a.NeedsRefresh and not V;
      if N then
        pcall(n.Refresh);
      end
      N=n;
      local S,O=N.PaintPending;
      if S then
        N=n;
        O=N.Paint;
      else
        O=S;
      end
      if O then
        pcall(n.Paint);
      end
      O=f and os.clock()-e>0.4 and not Z.configApplying;
      if O then
        f=false;
        pcall(n.Refresh);
      end
      o+=L;
      O=T.AbsoluteSize;
      S=o>0.3 or s~=J or m~=j or O~=C or A~=D or w~=r or F~=K;
      if S then
        J,j,C,D,r,K,o=s,m,O,A,w,F,0;
        k();
        R();
      end
      z+=L;
      a=H and 0.35+math.sin(z*2)*0.06 or 1;
      O=G.ImageTransparency+(a-G.ImageTransparency)*math.min(L*6,1);
      O=if not H and 1-O<0.001 then 1 else O;
      if G.ImageTransparency~=O then
        G.ImageTransparency=O;
      end
      S=G.ImageColor3~=Y;
      if S then
        G.ImageColor3=Y;
      end
    end));
    c=n;
    c.Panel=q;
    b=n;
    b.Viewport=T;
    local s=n;
    s.Model=function()
      local s=A;
      return s;
    end;
    X,Q=y,n;
    X.Preview=Q;
    P=n;
    P.ReadAura();
    l=n;
    l.Refresh();
    v();
    task.defer(function()
      local s=n;
      local L=s.Paint;
      if L then
        pcall(n.Paint);
      end
    end);
    local s;
    l=d;
    l("preview",function()
      W();
      pcall(function()
        q:Destroy();
      end);
      pcall(function()
        p:Destroy();
      end);
    end);
  end;
end
