-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #0
-- offset 206593..241894 (35301 bytes, type=payload)

function(s,s,s,s)
  return function(s,s)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    local f=s[9];
    local a=s[10];
    return function()
      local s,d,P,Z=1400,190,{Andromeda={stars={{"Alpheratz",0.14,29.09,2.1},{"Mirach",1.162,35.62,2.1},{"Almach",2.065,42.33,2.1},{"Delta And",0.655,30.86,3.3},{"51 And",1.632,48.63,3.6}},lines={{1,4},{4,2},{2,3},{2,5}}},Antlia={stars={{"Alpha Ant",10.452,-31.07,4.3},{"Epsilon Ant",9.487,-35.95,4.5}},lines={{2,1}}},Apus={stars={{"Alpha Aps",14.798,-79.04,3.8},{"Gamma Aps",16.558,-78.9,3.9},{"Beta Aps",16.718,-77.52,4.2}},lines={{1,2},{2,3}}},Aquarius={stars={{"Sadalsuud",21.526,-5.57,2.9},{"Sadalmelik",22.096,-0.32,2.9},{"Skat",22.911,-15.82,3.3},{"Zeta Aqr",22.481,-0.02,3.6},{"Eta Aqr",22.582,-0.12,4},{"Gamma Aqr",22.361,-1.39,3.8},{"Lambda Aqr",22.879,-7.58,3.7}},lines={{1,2},{2,6},{6,4},{4,5},{2,7},{7,3}}},Aquila={stars={{"Altair",19.846,8.87,0.8},{"Tarazed",19.771,10.61,2.7},{"Alshain",19.922,6.41,3.7},{"Deneb el Okab",19.09,13.86,3},{"Theta Aql",20.188,-0.82,3.2},{"Lambda Aql",19.104,-4.88,3.4}},lines={{2,1},{1,3},{2,4},{3,5},{5,6}}},Ara={stars={{"Beta Ara",17.422,-55.53,2.8},{"Alpha Ara",17.531,-49.88,2.8},{"Zeta Ara",16.977,-55.99,3.1},{"Gamma Ara",17.419,-56.38,3.3},{"Delta Ara",17.518,-60.68,3.6}},lines={{3,1},{1,4},{4,5},{1,2}}},Aries={stars={{"Hamal",2.119,23.46,2},{"Sheratan",1.911,20.81,2.6},{"Mesarthim",1.892,19.29,3.9},{"41 Ari",2.832,27.26,3.6}},lines={{4,1},{1,2},{2,3}}},Auriga={stars={{"Capella",5.278,45.998,0.1},{"Menkalinan",5.992,44.95,1.9},{"Mahasim",5.995,37.21,2.6},{"Hassaleh",4.95,33.17,2.7},{"Almaaz",5.033,43.82,3},{"Elnath",5.438,28.61,1.7}},lines={{1,2},{2,3},{3,6},{6,4},{4,5},{5,1}}},Bootes={stars={{"Arcturus",14.261,19.18,-0.05},{"Izar",14.75,27.07,2.4},{"Muphrid",13.911,18.4,2.7},{"Seginus",14.534,38.31,3},{"Nekkar",15.032,40.39,3.5},{"Rho Boo",14.529,30.37,3.6},{"Zeta Boo",14.685,13.73,3.8}},lines={{3,1},{1,6},{6,4},{4,5},{5,2},{2,1},{1,7}}},Caelum={stars={{"Alpha Cae",4.676,-41.86,4.4},{"Beta Cae",4.703,-37.14,5}},lines={{1,2}}},Camelopardalis={stars={{"Beta Cam",5.057,60.44,4},{"CS Cam",3.487,59.94,4.2},{"Alpha Cam",4.906,66.34,4.3},{"Gamma Cam",3.839,71.33,4.6}},lines={{2,1},{1,3},{3,4}}},Cancer={stars={{"Altarf",8.275,9.19,3.5},{"Asellus Australis",8.745,18.15,3.9},{"Asellus Borealis",8.722,21.47,4.7},{"Acubens",8.975,11.86,4.3},{"Iota Cnc",8.779,28.76,4}},lines={{1,2},{2,4},{2,3},{3,5}}},["Canes Venatici"]={stars={{"Cor Caroli",12.934,38.32,2.9},{"Chara",12.562,41.36,4.2}},lines={{1,2}}},["Canis Major"]={stars={{"Sirius",6.752,-16.72,-1.5},{"Mirzam",6.378,-17.96,2},{"Wezen",7.14,-26.39,1.8},{"Adhara",6.977,-28.97,1.5},{"Aludra",7.402,-29.3,2.4},{"Muliphein",7.063,-15.63,4.1}},lines={{2,1},{1,6},{1,3},{3,4},{3,5}}},["Canis Minor"]={stars={{"Procyon",7.655,5.22,0.4},{"Gomeisa",7.453,8.29,2.9}},lines={{1,2}}},Capricornus={stars={{"Algedi",20.3,-12.51,3.6},{"Dabih",20.351,-14.78,3.1},{"Deneb Algedi",21.784,-16.13,2.8},{"Nashira",21.668,-16.66,3.7},{"Zeta Cap",21.444,-22.41,3.7},{"Omega Cap",20.863,-26.92,4.1}},lines={{1,2},{2,6},{6,5},{5,4},{4,3},{3,1}}},Carina={stars={{"Canopus",6.399,-52.7,-0.7},{"Miaplacidus",9.22,-69.72,1.7},{"Avior",8.375,-59.51,1.9},{"Aspidiske",9.285,-59.28,2.2},{"Theta Car",10.716,-64.39,2.8},{"Upsilon Car",9.785,-65.07,3}},lines={{1,3},{3,4},{4,6},{6,2},{6,5}}},Cassiopeia={stars={{"Segin",1.907,63.67,3.4},{"Ruchbah",1.43,60.24,2.7},{"Gamma Cas",0.945,60.72,2.2},{"Schedar",0.675,56.54,2.2},{"Caph",0.153,59.15,2.3}},lines={{1,2},{2,3},{3,4},{4,5}}},Centaurus={stars={{"Rigil Kentaurus",14.66,-60.84,-0.3},{"Hadar",14.064,-60.37,0.6},{"Menkent",14.112,-36.37,2.1},{"Muhlifain",12.692,-48.96,2.2},{"Epsilon Cen",13.665,-53.47,2.3},{"Eta Cen",14.596,-42.16,2.3},{"Zeta Cen",13.926,-47.29,2.5},{"Delta Cen",12.139,-50.72,2.6},{"Iota Cen",13.343,-36.71,2.7}},lines={{1,2},{2,5},{5,7},{7,6},{6,3},{5,4},{4,8},{3,9}}},Cepheus={stars={{"Alderamin",21.31,62.59,2.4},{"Alfirk",21.478,70.56,3.2},{"Errai",23.656,77.63,3.2},{"Zeta Cep",22.181,58.2,3.4},{"Iota Cep",22.828,66.2,3.5},{"Eta Cep",20.755,61.84,3.4}},lines={{1,2},{2,3},{3,5},{5,4},{4,1},{1,6}}},Cetus={stars={{"Diphda",0.726,-17.99,2},{"Menkar",3.038,4.09,2.5},{"Mira",2.322,-2.98,3},{"Kaffaljidhma",2.722,3.24,3.5},{"Baten Kaitos",1.858,-10.34,3.5},{"Tau Cet",1.734,-15.94,3.5},{"Deneb Algenubi",1.4,-8.18,3.6}},lines={{1,6},{6,5},{5,3},{3,4},{4,2},{1,7},{7,5}}},Chamaeleon={stars={{"Alpha Cha",8.309,-76.92,4.1},{"Gamma Cha",10.591,-78.61,4.1},{"Beta Cha",12.303,-79.31,4.2}},lines={{1,2},{2,3}}},Circinus={stars={{"Alpha Cir",14.708,-64.98,3.2},{"Beta Cir",15.29,-58.8,4.1}},lines={{1,2}}},Columba={stars={{"Phact",5.661,-34.07,2.6},{"Wazn",5.849,-35.77,3.1},{"Delta Col",6.372,-33.44,3.9},{"Epsilon Col",5.522,-35.47,3.9}},lines={{4,1},{1,2},{2,3}}},["Coma Berenices"]={stars={{"Beta Com",13.198,27.88,4.3},{"Alpha Com",13.166,17.53,4.3},{"Gamma Com",12.448,28.27,4.4}},lines={{3,1},{1,2}}},["Corona Australis"]={stars={{"Alphecca Meridiana",19.158,-37.9,4.1},{"Beta CrA",19.167,-39.34,4.1},{"Gamma CrA",19.107,-37.06,4.2},{"Delta CrA",19.129,-40.5,4.6}},lines={{3,1},{1,2},{2,4}}},["Corona Borealis"]={stars={{"Alphecca",15.578,26.71,2.2},{"Nusakan",15.464,29.11,3.7},{"Gamma CrB",15.711,26.3,3.8},{"Delta CrB",15.827,26.07,4.6},{"Epsilon CrB",15.96,26.88,4.1},{"Theta CrB",15.548,31.36,4.1}},lines={{6,2},{2,1},{1,3},{3,4},{4,5}}},Corvus={stars={{"Gienah Corvi",12.263,-17.54,2.6},{"Kraz",12.573,-23.4,2.7},{"Algorab",12.498,-16.52,3},{"Minkar",12.169,-22.62,3},{"Alchiba",12.14,-24.73,4}},lines={{5,4},{4,1},{1,3},{3,2},{2,4}}},Crater={stars={{"Delta Crt",11.323,-14.78,3.6},{"Gamma Crt",11.415,-17.68,4.1},{"Alpha Crt",10.996,-18.3,4.1},{"Beta Crt",11.194,-22.83,4.5},{"Epsilon Crt",11.416,-10.86,4.8}},lines={{3,1},{1,5},{1,2},{2,4}}},Crux={stars={{"Acrux",12.443,-63.1,0.8},{"Mimosa",12.795,-59.69,1.3},{"Gacrux",12.519,-57.11,1.6},{"Imai",12.253,-58.75,2.8},{"Epsilon Cru",12.356,-60.4,3.6}},lines={{1,3},{2,4}}},Cygnus={stars={{"Deneb",20.69,45.28,1.3},{"Sadr",20.37,40.26,2.2},{"Gienah",20.77,33.97,2.5},{"Delta Cyg",19.749,45.13,2.9},{"Albireo",19.512,27.96,3.1}},lines={{1,2},{2,3},{2,4},{2,5}}},Delphinus={stars={{"Rotanev",20.626,14.6,3.6},{"Sualocin",20.661,15.91,3.8},{"Gamma Del",20.777,16.12,3.9},{"Delta Del",20.727,15.07,4.4},{"Epsilon Del",20.555,11.3,4}},lines={{2,3},{3,4},{4,1},{1,2},{1,5}}},Dorado={stars={{"Alpha Dor",4.567,-55.04,3.3},{"Beta Dor",5.56,-62.49,3.8},{"Gamma Dor",4.269,-51.49,4.2}},lines={{3,1},{1,2}}},Draco={stars={{"Thuban",14.073,64.38,3.7},{"Rastaban",17.507,52.3,2.8},{"Eltanin",17.943,51.49,2.2},{"Grumium",17.892,56.87,3.7},{"Altais",19.209,67.66,3.1},{"Aldhibah",17.146,65.71,3.2},{"Edasich",15.415,58.97,3.3},{"Giausar",11.531,69.33,3.8},{"Kappa Dra",12.558,69.79,3.9},{"Chi Dra",18.352,72.73,3.6}},lines={{2,3},{3,4},{4,6},{6,5},{5,10},{10,1},{1,7},{7,6},{1,9},{9,8}}},Equuleus={stars={{"Kitalpha",21.263,5.25,3.9},{"Delta Equ",21.245,10.01,4.5},{"Gamma Equ",21.174,10.13,4.7}},lines={{1,2},{2,3}}},Eridanus={stars={{"Achernar",1.629,-57.24,0.5},{"Cursa",5.131,-5.09,2.8},{"Zaurak",3.967,-13.51,2.9},{"Acamar",2.971,-40.3,3.2},{"Theta2 Eri",2.971,-40.3,4.4},{"Epsilon Eri",3.549,-9.46,3.7},{"Tau4 Eri",3.322,-21.76,3.7},{"Upsilon Eri",4.593,-30.56,3.8},{"Phi Eri",2.276,-51.51,3.6}},lines={{2,6},{6,3},{3,7},{7,8},{8,4},{4,9},{9,1}}},Fornax={stars={{"Dalim",3.201,-28.99,3.9},{"Beta For",2.816,-32.41,4.5}},lines={{1,2}}},Gemini={stars={{"Castor",7.577,31.89,1.6},{"Pollux",7.755,28.03,1.1},{"Mebsuta",6.732,25.13,3},{"Tejat",6.383,22.51,2.9},{"Wasat",7.335,21.98,3.5},{"Alhena",6.629,16.4,1.9}},lines={{1,2},{1,3},{3,4},{2,5},{5,6}}},Grus={stars={{"Alnair",22.137,-46.96,1.7},{"Beta Gru",22.711,-46.88,2.1},{"Gamma Gru",21.899,-37.36,3},{"Delta Gru",22.487,-43.5,4},{"Epsilon Gru",22.807,-51.32,3.5}},lines={{3,4},{4,1},{1,2},{2,5}}},Hercules={stars={{"Kornephoros",16.504,21.49,2.8},{"Zeta Her",16.688,31.6,2.8},{"Pi Her",17.251,36.81,3.2},{"Eta Her",16.715,38.92,3.5},{"Epsilon Her",17.005,30.93,3.9},{"Delta Her",17.25,24.84,3.1},{"Rasalgethi",17.244,14.39,3.1},{"Mu Her",17.774,27.72,3.4},{"Xi Her",17.965,29.25,3.7},{"Iota Her",17.655,46.01,3.8}},lines={{7,1},{1,2},{2,4},{4,3},{3,5},{5,2},{5,6},{6,8},{8,9},{3,10}}},Horologium={stars={{"Alpha Hor",4.234,-42.29,3.9},{"Beta Hor",2.985,-64.07,5}},lines={{1,2}}},Hydra={stars={{"Alphard",9.46,-8.66,2},{"Gamma Hya",13.315,-23.17,3},{"Zeta Hya",8.925,5.95,3.1},{"Nu Hya",10.828,-16.19,3.1},{"Pi Hya",14.107,-26.68,3.3},{"Epsilon Hya",8.779,6.42,3.4},{"Xi Hya",11.553,-31.86,3.5},{"Lambda Hya",10.181,-12.35,3.6},{"Delta Hya",8.629,5.7,4.1}},lines={{9,6},{6,3},{3,1},{1,8},{8,4},{4,7},{7,2},{2,5}}},Hydrus={stars={{"Beta Hyi",0.429,-77.25,2.8},{"Alpha Hyi",1.98,-61.57,2.9},{"Gamma Hyi",3.787,-74.24,3.2}},lines={{2,1},{1,3}}},Indus={stars={{"Alpha Ind",20.626,-47.29,3.1},{"Beta Ind",20.913,-58.45,3.7},{"Theta Ind",21.331,-53.45,4.4}},lines={{1,3},{3,2}}},Lacerta={stars={{"Alpha Lac",22.521,50.28,3.8},{"Beta Lac",22.394,52.23,4.4},{"5 Lac",22.499,47.71,4.4},{"1 Lac",22.264,37.75,4.1}},lines={{2,1},{1,3},{3,4}}},Leo={stars={{"Regulus",10.139,11.97,1.4},{"Algieba",10.333,19.84,2},{"Ras Elased",9.764,23.77,3},{"Zosma",11.235,20.52,2.6},{"Denebola",11.818,14.57,2.1},{"Chort",11.237,15.43,3.3}},lines={{1,2},{2,3},{2,4},{4,5},{5,6},{6,1}}},["Leo Minor"]={stars={{"46 LMi",10.886,34.22,3.8},{"Beta LMi",10.472,36.71,4.2},{"21 LMi",10.124,35.24,4.5}},lines={{1,2},{2,3}}},Lepus={stars={{"Arneb",5.545,-17.82,2.6},{"Nihal",5.471,-20.76,2.8},{"Epsilon Lep",5.093,-22.37,3.2},{"Mu Lep",5.216,-16.21,3.3},{"Zeta Lep",5.782,-14.82,3.5},{"Gamma Lep",5.744,-22.45,3.6}},lines={{4,1},{1,5},{1,2},{2,3},{2,6}}},Libra={stars={{"Zubeneschamali",15.283,-9.38,2.6},{"Zubenelgenubi",14.848,-16.04,2.7},{"Brachium",15.067,-25.28,3.3},{"Gamma Lib",15.596,-14.79,3.9}},lines={{2,1},{1,4},{4,3},{3,2}}},Lupus={stars={{"Alpha Lup",14.699,-47.39,2.3},{"Beta Lup",14.976,-43.13,2.7},{"Gamma Lup",15.585,-41.17,2.8},{"Delta Lup",15.356,-40.65,3.2},{"Epsilon Lup",15.379,-44.69,3.4},{"Zeta Lup",15.203,-52.1,3.4}},lines={{1,6},{1,2},{2,4},{4,3},{3,5},{5,1}}},Lynx={stars={{"Alpha Lyn",9.351,34.39,3.1},{"38 Lyn",9.317,36.8,3.8},{"31 Lyn",8.383,43.19,4.2},{"21 Lyn",7.444,49.21,4.6},{"15 Lyn",6.96,58.42,4.3}},lines={{1,2},{2,3},{3,4},{4,5}}},Lyra={stars={{"Vega",18.615,38.78,0},{"Zeta Lyr",18.746,37.6,4.3},{"Delta Lyr",18.908,36.9,4.2},{"Sulafat",18.982,32.69,3.2},{"Sheliak",18.834,33.36,3.5}},lines={{1,2},{2,3},{3,4},{4,5},{5,2}}},Mensa={stars={{"Alpha Men",6.171,-74.75,5.1},{"Gamma Men",5.514,-76.34,5.2}},lines={{1,2}}},Microscopium={stars={{"Gamma Mic",21.017,-32.26,4.7},{"Epsilon Mic",21.297,-32.18,4.7}},lines={{1,2}}},Monoceros={stars={{"Beta Mon",6.482,-7.03,3.7},{"Alpha Mon",7.685,-9.55,3.9},{"Gamma Mon",6.248,-6.27,4},{"Delta Mon",7.198,-0.49,4.1}},lines={{3,1},{1,2},{1,4}}},Musca={stars={{"Alpha Mus",12.62,-69.14,2.7},{"Beta Mus",12.771,-68.11,3},{"Delta Mus",13.037,-71.55,3.6},{"Gamma Mus",12.542,-72.13,3.8}},lines={{2,1},{1,4},{4,3}}},Norma={stars={{"Gamma2 Nor",16.32,-50.16,4},{"Epsilon Nor",16.457,-47.55,4.5}},lines={{1,2}}},Octans={stars={{"Nu Oct",21.691,-77.39,3.8},{"Beta Oct",22.767,-81.38,4.1},{"Delta Oct",14.454,-83.67,4.3}},lines={{1,2},{2,3}}},Ophiuchus={stars={{"Rasalhague",17.582,12.56,2.1},{"Cebalrai",17.724,4.57,2.8},{"Yed Prior",16.239,-3.69,2.7},{"Yed Posterior",16.304,-4.69,3.2},{"Zeta Oph",16.619,-10.57,2.6},{"Eta Oph",17.173,-15.72,2.4},{"Nu Oph",17.983,-9.77,3.3},{"Kappa Oph",16.961,9.38,3.2}},lines={{1,8},{8,3},{3,4},{4,5},{5,6},{6,7},{7,2},{2,1}}},Orion={stars={{"Betelgeuse",5.919,7.41,0.5},{"Bellatrix",5.418,6.35,1.6},{"Mintaka",5.533,-0.3,2.2},{"Alnilam",5.604,-1.2,1.7},{"Alnitak",5.679,-1.94,1.8},{"Saiph",5.796,-9.67,2.1},{"Rigel",5.242,-8.2,0.1},{"Meissa",5.585,9.93,3.4}},lines={{1,2},{2,3},{3,4},{4,5},{5,1},{3,7},{5,6},{7,6},{1,8},{2,8}}},Pavo={stars={{"Peacock",20.427,-56.74,1.9},{"Beta Pav",20.749,-66.2,3.4},{"Delta Pav",20.145,-66.18,3.6},{"Eta Pav",17.762,-64.72,3.6}},lines={{1,2},{2,3},{3,4}}},Pegasus={stars={{"Markab",23.079,15.21,2.5},{"Scheat",23.063,28.08,2.4},{"Algenib",0.221,15.18,2.8},{"Alpheratz",0.14,29.09,2.1},{"Enif",21.736,9.88,2.4},{"Homam",22.691,10.83,3.4},{"Matar",22.717,30.22,2.9}},lines={{1,2},{2,4},{4,3},{3,1},{1,6},{6,5},{2,7}}},Perseus={stars={{"Mirfak",3.405,49.86,1.8},{"Algol",3.136,40.96,2.1},{"Zeta Per",3.902,31.88,2.8},{"Epsilon Per",3.964,40.01,2.9},{"Gamma Per",3.08,53.51,2.9},{"Delta Per",3.715,47.79,3},{"Eta Per",2.845,55.9,3.8}},lines={{7,5},{5,1},{1,6},{6,4},{4,3},{1,2},{2,3}}},Phoenix={stars={{"Ankaa",0.438,-42.31,2.4},{"Beta Phe",1.101,-46.72,3.3},{"Gamma Phe",1.472,-43.32,3.4},{"Epsilon Phe",0.157,-45.75,3.9}},lines={{4,1},{1,2},{2,3}}},Pictor={stars={{"Alpha Pic",6.803,-61.94,3.3},{"Beta Pic",5.788,-51.07,3.9}},lines={{1,2}}},Pisces={stars={{"Alrescha",2.034,2.76,3.8},{"Eta Psc",1.525,15.35,3.6},{"Gamma Psc",23.286,3.28,3.7},{"Omega Psc",23.986,6.86,4},{"Iota Psc",23.66,5.63,4.1},{"Lambda Psc",23.7,1.78,4.5},{"Nu Psc",1.683,5.49,4.4}},lines={{1,7},{7,2},{1,6},{6,5},{5,3},{3,4},{4,6}}},["Piscis Austrinus"]={stars={{"Fomalhaut",22.961,-29.62,1.2},{"Epsilon PsA",22.679,-27.04,4.2},{"Delta PsA",22.93,-32.54,4.2},{"Beta PsA",22.526,-32.35,4.3}},lines={{1,2},{2,4},{4,3},{3,1}}},Puppis={stars={{"Naos",8.06,-40,2.2},{"Tureis",8.126,-24.3,2.8},{"Pi Pup",7.285,-37.1,2.7},{"Nu Pup",6.623,-43.2,3.2}},lines={{4,3},{3,1},{1,2}}},Pyxis={stars={{"Alpha Pyx",8.726,-33.19,3.7},{"Beta Pyx",8.673,-35.31,4},{"Gamma Pyx",8.841,-27.71,4}},lines={{2,1},{1,3}}},Reticulum={stars={{"Alpha Ret",4.24,-62.47,3.3},{"Beta Ret",3.737,-64.81,3.8},{"Epsilon Ret",4.274,-59.3,4.4},{"Gamma Ret",4.01,-62.16,4.5}},lines={{1,3},{3,4},{4,2},{2,1}}},Sagitta={stars={{"Gamma Sge",19.979,19.49,3.5},{"Delta Sge",19.789,18.53,3.8},{"Alpha Sge",19.669,18.01,4.4},{"Beta Sge",19.683,17.48,4.4}},lines={{1,2},{2,3},{2,4}}},Sagittarius={stars={{"Kaus Australis",18.403,-34.38,1.8},{"Nunki",18.921,-26.3,2.1},{"Ascella",19.044,-29.88,2.6},{"Kaus Media",18.35,-29.83,2.7},{"Kaus Borealis",18.466,-25.42,2.8},{"Alnasl",18.097,-30.42,3},{"Phi Sgr",18.762,-26.99,3.2},{"Tau Sgr",19.116,-27.67,3.3}},lines={{6,4},{4,1},{4,5},{5,7},{7,2},{2,8},{8,3},{3,7}}},Scorpius={stars={{"Antares",16.49,-26.43,1},{"Graffias",16.09,-19.81,2.6},{"Dschubba",16.005,-22.62,2.3},{"Pi Sco",15.981,-26.11,2.9},{"Sigma Sco",16.353,-25.59,2.9},{"Tau Sco",16.598,-28.22,2.8},{"Shaula",17.56,-37.1,1.6},{"Sargas",17.622,-42.99,1.9},{"Lesath",17.512,-37.3,2.7},{"Epsilon Sco",16.836,-34.29,2.3}},lines={{2,3},{3,4},{3,5},{5,1},{1,6},{6,10},{10,8},{8,9},{9,7}}},Sculptor={stars={{"Alpha Scl",0.977,-29.36,4.3},{"Beta Scl",23.548,-37.82,4.4},{"Gamma Scl",23.315,-32.53,4.4}},lines={{1,3},{3,2}}},Scutum={stars={{"Alpha Sct",18.586,-8.24,3.8},{"Beta Sct",18.786,-4.75,4.2},{"Gamma Sct",18.487,-14.57,4.7}},lines={{2,1},{1,3}}},Serpens={stars={{"Unukalhai",15.738,6.43,2.6},{"Mu Ser",15.824,-3.43,3.5},{"Beta Ser",15.77,15.42,3.7},{"Gamma Ser",15.941,15.66,3.8},{"Kappa Ser",15.811,18.14,4.1},{"Eta Ser",18.355,-2.9,3.2},{"Xi Ser",17.628,-15.4,3.5},{"Theta Ser",18.939,4.2,4}},lines={{5,3},{3,4},{3,1},{1,2},{7,6},{6,8}}},Sextans={stars={{"Alpha Sex",10.132,-0.37,4.5},{"Gamma Sex",9.879,-8.1,5.1}},lines={{1,2}}},Taurus={stars={{"Aldebaran",4.599,16.51,0.9},{"Elnath",5.438,28.61,1.7},{"Alcyone",3.791,24.11,2.9},{"Hyadum",4.33,15.63,3.7},{"Ain",4.478,19.18,3.5},{"Zeta Tau",5.627,21.14,3}},lines={{1,4},{1,5},{5,2},{1,6},{4,3}}},Telescopium={stars={{"Alpha Tel",18.45,-45.97,3.5},{"Zeta Tel",18.485,-49.07,4.1}},lines={{1,2}}},Triangulum={stars={{"Mothallah",1.885,29.58,3.4},{"Beta Tri",2.159,34.99,3},{"Gamma Tri",2.289,33.85,4}},lines={{1,2},{2,3},{3,1}}},["Triangulum Australe"]={stars={{"Atria",16.811,-69.03,1.9},{"Beta TrA",15.919,-63.43,2.8},{"Gamma TrA",15.315,-68.68,2.9}},lines={{1,2},{2,3},{3,1}}},Tucana={stars={{"Alpha Tuc",22.308,-60.26,2.9},{"Gamma Tuc",23.294,-58.24,4},{"Zeta Tuc",0.336,-64.87,4.2},{"Beta Tuc",0.525,-62.96,4.4}},lines={{1,2},{2,4},{4,3}}},["Ursa Major"]={stars={{"Dubhe",11.062,61.75,1.8},{"Merak",11.031,56.38,2.4},{"Phecda",11.897,53.69,2.4},{"Megrez",12.257,57.03,3.3},{"Alioth",12.9,55.96,1.8},{"Mizar",13.399,54.93,2.2},{"Alkaid",13.792,49.31,1.9}},lines={{1,2},{2,3},{3,4},{4,5},{5,6},{6,7},{4,1}}},["Ursa Minor"]={stars={{"Polaris",2.53,89.26,2},{"Yildun",17.537,86.59,4.4},{"Epsilon UMi",16.766,82.04,4.2},{"Zeta UMi",15.734,77.79,4.3},{"Kochab",14.845,74.16,2.1},{"Pherkad",15.345,71.83,3},{"Eta UMi",16.291,75.76,5}},lines={{1,2},{2,3},{3,4},{4,5},{5,6},{6,7},{7,4}}},Vela={stars={{"Suhail al Muhlif",8.158,-47.34,1.8},{"Markeb",9.368,-55.01,2.5},{"Suhail",9.133,-43.43,2.2},{"Delta Vel",8.745,-54.71,2},{"Mu Vel",10.777,-49.42,2.7}},lines={{1,4},{4,2},{2,3},{3,5},{3,1}}},Virgo={stars={{"Spica",13.42,-11.16,1},{"Porrima",12.694,-1.45,2.7},{"Vindemiatrix",13.036,10.96,2.8},{"Auva",12.927,3.4,3.4},{"Zavijava",11.845,1.76,3.6},{"Heze",13.578,-0.6,3.4},{"Syrma",14.269,-6,4.1},{"Zaniah",12.333,-0.67,3.9}},lines={{5,8},{8,2},{2,4},{4,3},{2,1},{1,6},{6,7}}},Volans={stars={{"Beta Vol",8.429,-66.14,3.8},{"Gamma Vol",7.145,-70.5,3.8},{"Zeta Vol",7.694,-72.61,3.9},{"Delta Vol",7.279,-67.96,4}},lines={{2,4},{4,1},{1,3}}},Vulpecula={stars={{"Anser",19.478,24.66,4.4},{"15 Vul",20.048,27.81,4.6}},lines={{1,2}}}},{"Andromeda","Antlia","Apus","Aquarius","Aquila","Ara","Aries","Auriga","Bootes","Caelum","Camelopardalis","Cancer","Canes Venatici","Canis Major","Canis Minor","Capricornus","Carina","Cassiopeia","Centaurus","Cepheus","Cetus","Chamaeleon","Circinus","Columba","Coma Berenices","Corona Australis","Corona Borealis","Corvus","Crater","Crux","Cygnus","Delphinus","Dorado","Draco","Equuleus","Eridanus","Fornax","Gemini","Grus","Hercules","Horologium","Hydra","Hydrus","Indus","Lacerta","Leo","Leo Minor","Lepus","Libra","Lupus","Lynx","Lyra","Mensa","Microscopium","Monoceros","Musca","Norma","Octans","Ophiuchus","Orion","Pavo","Pegasus","Perseus","Phoenix","Pictor","Pisces","Piscis Austrinus","Puppis","Pyxis","Reticulum","Sagitta","Sagittarius","Scorpius","Sculptor","Scutum","Serpens","Sextans","Taurus","Telescopium","Triangulum","Triangulum Australe","Tucana","Ursa Major","Ursa Minor","Vela","Virgo","Volans","Vulpecula"};
      local G={Betelgeuse=Color3.fromRGB(255,154,102),Antares=Color3.fromRGB(255,148,100),Tejat=Color3.fromRGB(255,160,112),["Delta Lyr"]=Color3.fromRGB(255,176,128),Aldebaran=Color3.fromRGB(255,184,128),Schedar=Color3.fromRGB(255,196,142),Hyadum=Color3.fromRGB(255,198,146),Ain=Color3.fromRGB(255,198,146),Gienah=Color3.fromRGB(255,196,140),Albireo=Color3.fromRGB(255,202,138),Pollux=Color3.fromRGB(255,202,152),Algieba=Color3.fromRGB(255,206,160),Dubhe=Color3.fromRGB(255,210,170),["Ras Elased"]=Color3.fromRGB(255,226,180),Mebsuta=Color3.fromRGB(255,232,190),Sadr=Color3.fromRGB(255,244,214),Wezen=Color3.fromRGB(255,246,222),Caph=Color3.fromRGB(255,246,224),Sargas=Color3.fromRGB(255,248,230),Wasat=Color3.fromRGB(246,248,255),Ruchbah=Color3.fromRGB(246,248,255),["Zeta Lyr"]=Color3.fromRGB(244,247,255),Chort=Color3.fromRGB(240,246,255),Alhena=Color3.fromRGB(240,246,255),Zosma=Color3.fromRGB(238,244,255),Megrez=Color3.fromRGB(238,244,255),Sirius=Color3.fromRGB(236,244,255),Merak=Color3.fromRGB(236,242,255),Phecda=Color3.fromRGB(236,242,255),["Delta Cyg"]=Color3.fromRGB(236,243,255),Castor=Color3.fromRGB(235,242,255),Denebola=Color3.fromRGB(235,242,255),Alioth=Color3.fromRGB(234,241,255),Mizar=Color3.fromRGB(234,241,255),Deneb=Color3.fromRGB(232,240,255),Vega=Color3.fromRGB(226,236,255),Elnath=Color3.fromRGB(208,226,255),Alkaid=Color3.fromRGB(206,224,255),Regulus=Color3.fromRGB(202,222,255),Sheliak=Color3.fromRGB(202,220,255),Sulafat=Color3.fromRGB(200,219,255),Muliphein=Color3.fromRGB(198,218,255),Segin=Color3.fromRGB(198,218,255),Rigel=Color3.fromRGB(196,216,255),["Gamma Cas"]=Color3.fromRGB(196,217,255),["Zeta Tau"]=Color3.fromRGB(194,215,255),["Sigma Sco"]=Color3.fromRGB(192,213,255),Alcyone=Color3.fromRGB(192,214,255),Bellatrix=Color3.fromRGB(190,212,255),Saiph=Color3.fromRGB(190,212,255),Meissa=Color3.fromRGB(190,212,255),Aludra=Color3.fromRGB(190,212,255),["Pi Sco"]=Color3.fromRGB(190,212,255),Mintaka=Color3.fromRGB(188,210,255),Alnitak=Color3.fromRGB(188,210,255),Graffias=Color3.fromRGB(188,210,255),["Tau Sco"]=Color3.fromRGB(188,210,255),Alnilam=Color3.fromRGB(186,209,255),Mirzam=Color3.fromRGB(186,209,255),Dschubba=Color3.fromRGB(186,209,255),Shaula=Color3.fromRGB(184,208,255),Adhara=Color3.fromRGB(182,207,255)};
      local Y=Color3.fromRGB(252,250,242);
      local e=Color3.fromRGB(255,198,150);
      local j=Color3.fromRGB(255,244,222);
      local C={On=false,Star=Color3.fromRGB(255,252,235),Line=Color3.fromRGB(120,175,255),Scale=100,Glow=100,Lines=true,Labels=false,Spin=12,Twinkle=60,Natural=true,Always=false,Names=false,Field=true,Density=220,Meteors=true,Rate=12,Picked={}};
      for N,N in ipairs(Z)do
        C.Picked[N]=true;
      end;
      local N;
      local N=l;
      N.Constellations=C;
      local function q(b,D)
        local p,r=math.rad(b*15),math.rad(D);
        b=math.cos(r);
        return Vector3.new(b*math.cos(p),math.sin(r),b*math.sin(p));
      end
      local b={};
      for D,p in pairs(P)do
        N=(Vector3.new(0.0,0.0,0.0));
        for r,r in ipairs(p.stars)do
          N+=q(r[2],r[3]);
        end;
        b[D]=N.Magnitude>0.001 and N.Unit or Vector3.new(0.0,1.0,0.0);
      end;
      local D=Instance.new("Part");
      local p;
      N=L;
      D.Name=N.RandomString();
      D.Anchored=true;
      D.CanCollide=false;
      D.CanQuery=false;
      D.CanTouch=false;
      D.Transparency=1;
      D.Size=Vector3.new(1.0,1.0,1.0);
      D.Locked=true;
      local p;
      local p,r=y;
      N=z;
      D:SetAttribute(p,N);
      D.Parent=workspace;
      local y,z=Instance.new("Folder"),L;
      y.Name=z.RandomString();
      y.Parent=D;
      local r,K;
      z=T;
      r=z.asset("particles/p_glow.png");
      local T,K,o,c,m,S={},0,0.767944870877505,0.4886921905584123,s,1;
      local O=game:GetService("Lighting");
      local function B()
        local A=O:FindFirstChildOfClass("Atmosphere");
        local O=A and A.Density or 0;
        if O<=0.01 then
          return s;
        end
        return math.floor(math.clamp(d*(1-O),24,d)/2)*2;
      end
      local function d(O)
        return math.clamp((O+0.03)/0.16,0,1);
      end
      local O=0.05235987755982989;
      local function A(w)
        local F=P[w];
        if not F then
          return nil;
        end
        local P,h,W={stars={},beams={},born=os.clock(),sway=math.random()*3.141592653589793*2},{},(Vector3.new(0.0,0.0,0.0));
        for V,_ in ipairs(F.stars)do
          local X=q(_[2],_[3]);
          h[V]=X;
          W+=X;
        end;
        local q,V=#h>0 and W.Magnitude>0.001 and W.Unit or Vector3.new(0.0,1.0,0.0),0;
        for _,_ in ipairs(h)do
          V=math.max(V,math.acos(math.clamp(q:Dot(_),-1,1)));
        end;
        local _=V>O and O/V or 1;
        local function O(V)
          if _>=0.9999 then
            return V;
          end
          local X=math.acos(math.clamp(q:Dot(V),-1,1));
          if X<1.0E-5 then
            return q;
          end
          local x=math.sin(X);
          return(q*(math.sin((1-_)*X)/x)+V*(math.sin(_*X)/x)).Unit;
        end
        W=Vector3.new(0.0,0.0,0.0);
        local q,V=ipairs,F.stars;
        for _,X in q(V)do
          local x,k,v=O(h[_]),Instance.new("Attachment"),L;
          k.Name=v.RandomString();
          k.Position=x*m;
          k.Parent=D;
          local I,i,E=math.clamp((5.2-X[4])/6.2,0.3,1),Instance.new("BillboardGui"),L;
          i.Name=E.RandomString();
          i.Adornee=k;
          i.AlwaysOnTop=false;
          i.LightInfluence=0;
          i.Size=UDim2.fromScale(1,1);
          i.Parent=y;
          v=Instance.new("ImageLabel");
          v.BackgroundTransparency=1;
          v.AnchorPoint=Vector2.new(0.5,0.5);
          v.Position=UDim2.fromScale(0.5,0.5);
          v.Size=UDim2.fromScale(2.4,2.4);
          v.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
          v.Parent=i;
          E=Instance.new("ImageLabel");
          E.BackgroundTransparency=1;
          E.AnchorPoint=Vector2.new(0.5,0.5);
          E.Position=UDim2.fromScale(0.5,0.5);
          E.Size=UDim2.fromScale(1,1);
          E.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
          E.Parent=i;
          local Q;
          if X[1] then
            Q=Instance.new("TextLabel");
            Q.AnchorPoint=Vector2.new(0.5,0);
            Q.Position=UDim2.fromScale(0.5,1);
            Q.Size=UDim2.fromScale(4,0.5);
            Q.BackgroundTransparency=1;
            Q.Font=Enum.Font.Gotham;
            Q.Text=X[1];
            Q.TextSize=11;
            Q.TextTransparency=0.35;
            Q.Visible=false;
            Q.Parent=i;
          else
          end
          W+=x;
          P.stars[_]={anchor=k,board=i,dot=E,halo=v,label=Q,weight=I,aim=x,home=x*m,tint=G[X[1]]or Y,phase=math.random()*3.141592653589793*2,rate=0.5+math.random()*1.3,delay=0.04*_,alpha=0};
        end;
        h=#F.stars>0;
        if h then
          O=W/#F.stars;
          O=O.Magnitude>0.001 and O.Unit or Vector3.new(0.0,1.0,0.0);
          q,V=Instance.new("Attachment"),L;
          q.Name=V.RandomString();
          q.Position=O*m;
          q.Parent=D;
          local G,Y=Instance.new("BillboardGui"),L;
          G.Name=Y.RandomString();
          G.Adornee=q;
          G.AlwaysOnTop=false;
          G.LightInfluence=0;
          G.Size=UDim2.fromScale(1,1);
          G.Enabled=false;
          G.Parent=y;
          Y=Instance.new("TextLabel");
          Y.BackgroundTransparency=1;
          Y.Size=UDim2.fromScale(1,1);
          Y.Font=Enum.Font.Gotham;
          Y.Text=w;
          Y.TextScaled=true;
          Y.TextTransparency=0.45;
          Y.Parent=G;
          P.title={seat=q,board=G,tag=Y,aim=O};
        end
        for G,Y in ipairs(F.lines)do
          h,V=P.stars[Y[1]],P.stars[Y[2]];
          if h and V then
            Y=Instance.new("Beam");
            Y.Attachment0=h.anchor;
            Y.Attachment1=V.anchor;
            Y.FaceCamera=true;
            Y.LightInfluence=0;
            Y.LightEmission=1;
            Y.Segments=1;
            Y.Width0=4;
            Y.Width1=4;
            Y.Parent=D;
            local q,O=P.beams,P.beams;
            local w,F=#O+1,{beam=Y,a=h,b=V};
            F.delay,F.shown,q[w]=0.45+0.05*G,-1,F;
          end
        end;
        return P;
      end
      local function P(G)
        if G.title then
          pcall(function()
            G.title.board:Destroy();
          end);
          pcall(function()
            G.title.seat:Destroy();
          end);
        end
        for Y,Y in ipairs(G.beams)do
          pcall(function()
            Y.beam:Destroy();
          end);
        end;
        for Y,Y in ipairs(G.stars)do
          pcall(function()
            Y.board:Destroy();
          end);
          pcall(function()
            Y.anchor:Destroy();
          end);
        end;
      end
      local G,Y={},0;
      local function q()
        for O,O in ipairs(G)do
          pcall(function()
            O.beam:Destroy();
          end);
          pcall(function()
            O.head:Destroy();
          end);
          pcall(function()
            O.tail:Destroy();
          end);
        end;
        table.clear(G);
      end
      local function O(w)
        local F,h=0.3+math.random()*0.55,math.random()*3.141592653589793*2;
        local W=math.sqrt(math.max(0,1-F*F));
        local V=Vector3.new(W*math.cos(h),F,W*math.sin(h))*m;
        h,W=V.Unit,Vector3.new(math.random()-0.5,-1.1,math.random()-0.5);
        F=W-h*W:Dot(h);
        F=if F.Magnitude<0.05 then h:Cross((Vector3.new(0.0,1.0,0.0)))else F;
        h,W=Instance.new("Attachment"),L;
        h.Name=W.RandomString();
        h.Parent=D;
        local _,X=Instance.new("Attachment"),L;
        _.Name=X.RandomString();
        _.Parent=D;
        W=Instance.new("Beam");
        W.Attachment0=_;
        W.Attachment1=h;
        W.FaceCamera=true;
        W.LightInfluence=0;
        W.LightEmission=1;
        W.Segments=8;
        W.Width0=0.8;
        W.Width1=11;
        W.Parent=D;
        G[#G+1]={beam=W,head=h,tail=_,from=V,dir=F.Unit,born=w,life=0.9+math.random()*0.8,span=240+math.random()*300,trail=110+math.random()*150};
      end
      local function w(F,h)
        local W=not C.Meteors;
        if W then
          if #G>0 then
            q();
          end
          Y=0;
          return;
        end
        W=Y==0;
        if W then
          Y=F+math.random()*4;
        else
          local V=F>=Y;
          if V then
            local V=60/math.max(1,C.Rate);
            Y=F+V*(0.45+math.random());
            if #G<6 then
              O(F);
            end
          end
        end
        W=#G;
        for Y=W,1,-1 do
          local O=G[Y];
          local W=(F-O.born)/O.life;
          local F=W>=1;
          if F then
            pcall(function()
              O.beam:Destroy();
            end);
            pcall(function()
              O.head:Destroy();
            end);
            pcall(function()
              O.tail:Destroy();
            end);
            table.remove(G,Y);
          else
            local G,Y=O.from+O.dir*(O.span*W),O.trail*math.min(1,W*5);
            O.head.Position=G;
            O.tail.Position=G-O.dir*Y;
            local F;
            Y=n;
            Y.FxDepth(O.beam,C.Always);
            Y=(W<0.12 and W/0.12 or(1-(W-0.12)/0.88)^1.6)*d(D.CFrame:VectorToWorldSpace(G).Unit.Y);
            O.beam.Color=ColorSequence.new(h);
            O.beam.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.35,math.clamp(1-Y*0.25,0,1)),NumberSequenceKeypoint.new(1,math.clamp(1-Y,0,1))});
          end
        end;
      end
      local G={};
      local function Y()
        local O,F=B(),m;
        if O==F then
          return;
        end
        m=O;
        S=m/s;
        for s,B in pairs(T)do
          F,O=ipairs,B.stars;
          for h,h in F(O)do
            h.home=h.aim*m;
            h.anchor.Position=h.home;
          end;
          s=B.title;
          if s then
            B.title.seat.Position=B.title.aim*m;
          end
        end;
        for s,s in ipairs(G)do
          s.seat.Position=s.aim*m;
        end;
        q();
      end
      local s,O,B=0,0,0;
      local function F()
        for h,h in ipairs(G)do
          pcall(function()
            h.board:Destroy();
          end);
          pcall(function()
            h.seat:Destroy();
          end);
        end;
        table.clear(G);
      end
      local function h()
        local W=C.Field and math.floor(C.Density)or 0;
        while#G>W do
          local V=table.remove(G);
          pcall(function()
            V.board:Destroy();
          end);
          pcall(function()
            V.seat:Destroy();
          end);
        end;
        while#G<W do
          local W,V=math.random()*2-1,math.random()*3.141592653589793*2;
          local _=math.sqrt(math.max(0,1-W*W));
          local X,x,k=Vector3.new(_*math.cos(V),W,_*math.sin(V)),Instance.new("Attachment"),L;
          x.Name=k.RandomString();
          x.Position=X*m;
          x.Parent=D;
          V,W=Instance.new("BillboardGui"),L;
          V.Name=W.RandomString();
          V.Adornee=x;
          V.LightInfluence=0;
          V.Size=UDim2.fromScale(1,1);
          V.Parent=y;
          k=Instance.new("ImageLabel");
          k.BackgroundTransparency=1;
          k.AnchorPoint=Vector2.new(0.5,0.5);
          k.Position=UDim2.fromScale(0.5,0.5);
          k.Size=UDim2.fromScale(1,1);
          k.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
          k.Parent=V;
          G[#G+1]={seat=x,board=V,dot=k,aim=X,weight=0.1+math.random()^3*0.28,phase=math.random()*3.141592653589793*2,rate=0.4+math.random()*1.4,warm=math.random()<0.3};
        end;
      end
      local y,r,m,W={},{},0,24;
      local function V()
        for _,X in pairs(T)do
          P(X);
          T[_]=nil;
        end;
        q();
        F();
        table.clear(y);
        table.clear(r);
        m=0;
      end
      local function q(_)
        local X,x=D.CFrame:VectorToObjectSpace(_.CFrame.LookVector),{};
        for k,v in ipairs(Z)do
          if C.Picked[v] then
            local I,i=#x+1,{name=v};
            i.dot,i.order,x[I]=b[v]:Dot(X),k,i;
          end
        end;
        table.sort(x,function(b,X)
          if math.abs(b.dot-X.dot)<1.0E-4 then
            return b.order<X.order;
          end
          return b.dot>X.dot;
        end);
        table.clear(y);
        for b=1,math.min(W,#x),1 do
          y[x[b].name]=true;
        end;
        for b,X in pairs(T)do
          if not y[b] then
            P(X);
            T[b]=nil;
          end
        end;
        table.clear(r);
        for b=1,math.min(W,#x),1 do
          _=x[b].name;
          if not T[_] then
            r[#r+1]=_;
          end
        end;
      end
      local function b()
        if not C.On then
          V();
          return;
        end
        for W,_ in pairs(T)do
          if not C.Picked[W] then
            P(_);
            T[W]=nil;
          end
        end;
        m=0;
      end
      local function P(W)
        return NumberSequence.new(W);
      end
      local function W(_)
        local X;
        local X=not(J[4][J[6]]and C.On);
        if X then
          B=0;
          return;
        end
        B=math.min(B+_,0.1);
        X=B;
        if X<0.03333333333333333 then
          return;
        end
        _=B;
        X=_;
        B%=0.03333333333333333;
        local J;
        local J=n;
        local B=J.camera();
        if not B then
          return;
        end
        local _,x=os.clock(),K;
        K=(x+X*(C.Spin/1000))%6.283185307179586;
        D.CFrame=CFrame.new(B.CFrame.Position)*CFrame.Angles(0,c,0)*CFrame.Angles(o,0,0)*CFrame.Angles(0,K,0);
        m-=X;
        X=m<=0;
        if X then
          m=0.25;
          q(B);
        end
        x=0;
        while x<2 and#r>0 do
          J=table.remove(r,1);
          if y[J]and C.Picked[J]and not T[J] then
            T[J]=A(J);
            x+=1;
          else
          end
        end;
        Y();
        local y,Y,q,r,K=C.Scale/100*S,C.Glow/100,C.Twinkle/100,C.Natural,D.CFrame;
        w(_,r and j or C.Star);
        h();
        X=C.Star:Lerp(e,0.5);
        s=(s+1)%3;
        B=1+s;
        for s=B,#G,3 do
          x=G[s];
          s=d(K:VectorToWorldSpace(x.aim).Y);
          if s<=0.002 then
            if x.board.Enabled then
              x.board.Enabled=false;
            end
          else
            if not x.board.Enabled then
              x.board.Enabled=true;
            end
            J=1+q*0.2*math.sin(_*x.rate+x.phase);
            local G,e=Y*s*x.weight*J,78*x.weight*y*J;
            x.board.Size=UDim2.fromScale(e,e);
            if x.board.AlwaysOnTop~=C.Always then
              x.board.AlwaysOnTop=C.Always;
            end
            e=r and x.warm and X or C.Star;
            if x.tone~=e then
              x.tone=e;
              x.dot.ImageColor3=e;
            end
            x.dot.ImageTransparency=math.clamp(1-G,0,1);
          end
        end;
        O=1-O;
        x=pairs;
        for s,G in x(T)do
          s,B=0.92+0.08*math.sin(_*0.32+G.sway),_-G.born;
          if C.Lines then
            for T,T in ipairs(G.stars)do
              T.horizon=d(K:VectorToWorldSpace(T.aim).Y);
            end;
          end
          X=1+O;
          for T=X,#G.stars,2 do
            J=G.stars[T];
            T=C.Lines and J.horizon or d(K:VectorToWorldSpace(J.aim).Y);
            if T<=0.002 then
              if J.board.Enabled then
                J.board.Enabled=false;
              end
              continue;
            end
            if not J.board.Enabled then
              J.board.Enabled=true;
            end
            J.alpha=math.clamp((B-J.delay)/0.55,0,1);
            local e=1+q*0.16*math.sin(_*J.rate+J.phase)+q*0.07*math.sin(_*J.rate*2.7+J.phase*1.7);
            local j,o,c=Y*T*J.alpha*s*(0.35+J.weight*0.65)*e,34*J.weight*y*(0.55+0.45*J.alpha)*(1+q*0.08*(e-1)*6),C.Star;
            if r then
              if J.mixedFor~=C.Star then
                J.mixedFor=C.Star;
                J.mixedTone=J.tint:Lerp(C.Star,0.35);
              end
              c=J.mixedTone;
            else
            end
            J.board.Size=UDim2.fromScale(o,o);
            if J.board.AlwaysOnTop~=C.Always then
              J.board.AlwaysOnTop=C.Always;
            end
            if J.tone~=c then
              J.tone=c;
              J.dot.ImageColor3=c;
              J.halo.ImageColor3=c;
            end
            J.dot.ImageTransparency=math.clamp(1-j,0,1);
            J.halo.ImageTransparency=math.clamp(1-j*J.weight*0.7,0,1);
            if J.label then
              j=C.Labels and T>0.25 and J.weight>0.62;
              if J.label.Visible~=j then
                J.label.Visible=j;
              end
              if j then
                if J.labelTone~=c then
                  J.labelTone=c;
                  J.label.TextColor3=c;
                end
                J.label.TextTransparency=math.clamp(0.35+(1-T)*0.65,0,1);
              end
            end
          end;
          if G.title then
            local T=G.title;
            if not C.Names then
              if T.board.Enabled then
                T.board.Enabled=false;
              end
            else
              local J=d(K:VectorToWorldSpace(T.aim).Y);
              local d=J>0.2;
              if T.board.Enabled~=d then
                T.board.Enabled=d;
              end
              if d then
                local d=26*y;
                T.board.Size=UDim2.fromScale(d*4,d);
                if T.board.AlwaysOnTop~=C.Always then
                  T.board.AlwaysOnTop=C.Always;
                end
                if T.tone~=C.Line then
                  T.tone=C.Line;
                  T.tag.TextColor3=C.Line;
                end
                T.tag.TextTransparency=math.clamp(0.5+(1-J)*0.5,0,1);
              end
            end
          end
          local T,J=ipairs,G.beams;
          for d,e in T(J)do
            d,G=e.beam,n;
            G.FxDepth(d,C.Always);
            if not C.Lines then
              d.Enabled=false;
            else
              local T,n=math.min(e.a.horizon,e.b.horizon),math.clamp((B-e.delay)/0.7,0,1);
              local J=Y*T*n*s;
              T=J>0.02;
              if d.Enabled~=T then
                d.Enabled=T;
              end
              if T then
                n=math.clamp(1-J*1.35,0.42,0.9);
                if math.abs(n-e.shown)>0.015 then
                  e.shown=n;
                  d.Transparency=P(n);
                end
                local s=4*y;
                if e.wide~=s then
                  e.wide=s;
                  d.Width0=s;
                  d.Width1=s;
                end
                if e.natural~=r or e.tone~=C.Line then
                  e.natural=r;
                  e.tone=C.Line;
                  d.Color=r and ColorSequence.new(e.a.tint:Lerp(C.Line,0.55),e.b.tint:Lerp(C.Line,0.55))or ColorSequence.new(C.Line);
                end
              end
            end
          end;
        end;
      end
      local s,y=L;
      N=H;
      s:AddSignal(N.RenderStepped:Connect(W));
      local L;
      z=f;
      p=z.Stars:AddLabel("Constellations");
      p:AddToggle({Name="Constellations",Default=false,Flag="stars",Callback=function(L)
        C.On=L;
        b();
      end});
      p:AddColorPicker({Default=C.Star,Flag="stars_color",Callback=function(L)
        C.Star=L;
      end});
      z=f;
      s=z.Stars:AddLabel("Lines");
      s:AddToggle({Name="Lines",Default=true,Flag="stars_lines",Callback=function(L)
        C.Lines=L;
      end});
      s:AddColorPicker({Default=C.Line,Flag="stars_line_color",Callback=function(L)
        C.Line=L;
      end});
      W=f;
      W.Stars:AddLabel("Constellations"):AddDropdown({Default=Z,Values=Z,Multi=true,Flag="stars_pick",Callback=function(L)
        local y={};
        if type(L)=="table" then
          for T,n in pairs(L)do
            if type(T)=="string"and n then
              y[T]=true;
            elseif type(n)=="string" then
              y[n]=true;
            end
          end;
        elseif type(L)=="string" then
          y[L]=true;
        end
        C.Picked=y;
        b();
      end});
      W=f;
      W.Stars:AddLabel("Size"):AddSlider({Min=20,Max=260,Default=100,Rounding=0,Type="%",Size=100,Flag="stars_scale",Callback=function(L)
        C.Scale=L;
      end});
      s=f;
      s.Stars:AddLabel("Glow"):AddSlider({Min=10,Max=100,Default=100,Rounding=0,Type="%",Size=100,Flag="stars_glow",Callback=function(L)
        C.Glow=L;
      end});
      N=f;
      N.Stars:AddLabel("Drift"):AddSlider({Min=0,Max=60,Default=12,Rounding=0,Size=100,Flag="stars_spin",Callback=function(L)
        C.Spin=L;
      end});
      s=f;
      s.Stars:AddLabel("Twinkle"):AddSlider({Min=0,Max=100,Default=60,Rounding=0,Type="%",Size=100,Flag="stars_twinkle",Callback=function(L)
        C.Twinkle=L;
      end});
      W=f;
      W.Stars:AddLabel("Star Colors"):AddToggle({Name="Real Star Colors",Default=true,Flag="stars_natural",Callback=function(L)
        C.Natural=L;
      end});
      z=f;
      s=z.Stars:AddLabel("Shooting Stars");
      s:AddToggle({Name="Shooting Stars",Default=true,Flag="stars_meteors",Callback=function(L)
        C.Meteors=L;
      end});
      s:AddSlider({Min=1,Max=60,Default=12,Rounding=0,Size=90,Flag="stars_meteor_rate",Callback=function(L)
        C.Rate=L;
      end});
      s=f;
      p=s.Stars:AddLabel("Background Stars");
      p:AddToggle({Name="Background Stars",Default=true,Flag="stars_field",Callback=function(s)
        C.Field=s;
        if not s then
          F();
        end
      end});
      p:AddSlider({Min=60,Max=700,Default=220,Rounding=0,Size=80,Flag="stars_density",Callback=function(s)
        C.Density=s;
      end});
      W=f;
      W.Stars:AddLabel("Names"):AddToggle({Name="Names",Default=false,Flag="stars_names",Callback=function(s)
        C.Names=s;
      end});
      N=f;
      N.Stars:AddLabel("Star Labels"):AddToggle({Name="Star Labels",Default=false,Flag="stars_labels",Callback=function(s)
        C.Labels=s;
      end});
      local s,L=l;
      p=a;
      s.ClearConstellations=p("constellations",function()
        C.On=false;
        V();
        pcall(function()
          D:Destroy();
        end);
      end);
    end;
  end;
end
