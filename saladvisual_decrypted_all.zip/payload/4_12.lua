-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #12
-- offset 3247742..3248358 (616 bytes, type=payload)

local function S(O,B)
  if O:GetAttribute("VisualsGunAura") then
    return nil;
  end
  if O:IsA("ParticleEmitter")or O:IsA("Beam")or O:IsA("Trail")or O:IsA("Sparkles")or O:IsA("Fire")or O:IsA("Smoke")or O:IsA("Light")or O:IsA("Highlight")or O:IsA("BillboardGui")or O:IsA("SurfaceGui") then
    return"Enabled",false;
  end
  if O:IsA("BasePart")and O~=B then
    local B,A=O.Color,O.Name:lower();
    if B.G>B.R*1.15 and B.G>B.B*1.15 and(A:find("aura",1,true)or A:find("glow",1,true)or A:find("ring",1,true)or A:find("effect",1,true)or O.Material==Enum.Material.Neon or O.Material==Enum.Material.ForceField) then
      return"Transparency",1;
    end
  end
end
