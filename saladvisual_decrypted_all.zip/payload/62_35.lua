-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #35
-- offset 3233081..3234202 (1121 bytes, type=payload)

local function I()
  local i=Q;
  if not i then
    return;
  end
  local E;
  i=T;
  local E=i.Character;
  if not E then
    return;
  end
  v();
  i=E:FindFirstChild("Right Leg");
  local lP=i and i:IsA("BasePart")and not E:FindFirstChild("RightUpperLeg");
  if lP then
    R[i]={Transparency=i.Transparency};
    local zP=Instance.new("Part");
    zP.Name="VisualsR6Korblox";
    local TP;
    local TP,nP=f;
    local f=a;
    zP:SetAttribute(TP,f);
    zP.Size,zP.CFrame=i.Size,i.CFrame;
    zP.Color,zP.Material=i.Color,Enum.Material.SmoothPlastic;
    zP.Transparency,zP.Reflectance=0,i.Reflectance;
    zP.CanCollide=false;
    zP.CanQuery=false;
    zP.CanTouch=false;
    zP.Massless=true;
    zP.CastShadow=false;
    f=Instance.new("SpecialMesh");
    f.MeshType=Enum.MeshType.FileMesh;
    f.MeshId="rbxassetid://902942096";
    f.TextureId="rbxassetid://902843398";
    f.Scale=Vector3.new(1.05,1,1.05);
    f.Parent=zP;
    f=Instance.new("WeldConstraint");
    f.Part0=zP;
    f.Part1=i;
    f.Parent=zP;
    zP.Parent=E;
    i.Transparency=1;
    u=zP;
    return;
  end
  for f,a in pairs(h)do
    local h=E:FindFirstChild(f);
    if h then
      i={};
      for E in pairs(a)do
        lP,f=pcall(function()
          return h[E];
        end);
        if lP then
          i[E]=f;
        end
      end;
      R[h]=i;
      for f,i in pairs(a)do
        pcall(function()
          h[f]=i;
        end);
      end;
    end
  end;
end
