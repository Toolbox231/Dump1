-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #0
-- offset 3244992..3257347 (12355 bytes, type=payload)

function(s,s,s,s)
  return function(s,s,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    local f=s[9];
    local a=s[10];
    local d=s[11];
    local P=s[12];
    local Z=s[13];
    local G=s[14];
    return function()
      local s;
      local s=l;
      if not s.Guns then
        return;
      end
      local Y,e={On=false,Outline=Color3.fromRGB(255,190,60),Fill=0.75,Aura=true,AuraType="ForceField",AuraColor=Color3.fromRGB(255,150,40),AuraSpread=1,AuraSize=1,AuraSpeed=1,AuraRate=1,AuraOpacity=0.75,AuraGlow=2,Circle=false,CircleStyle="Soft Ring",CircleColor=Color3.fromRGB(255,190,60),CircleSize=4,CircleOpacity=1,CircleGlow=2,CircleHeight=0.06,CircleRotation=0,CircleGround=true,CircleThroughWalls=false,Text=true,TextColor=Color3.fromRGB(255,220,140)};
      s=L;
      s.GunChams=Y;
      local e,j={},{};
      Y.Live=j;
      Y.AuraTypes={"ForceField","Neon","Glass","Metal","Sparkle","Fire","Smoke"};
      local C,N={Glow="p_glow",Bloom="p_bloom",Stars="p_star",Sparks="p_sparkle",Hearts="p_heart",Snow="p_snowflake",Lightning="p_lightning",Petals="p_petal1",Flowers="p_flower1",Leaves="p_leaf1",Bubbles="p_bubble",Crown="p_crown",Fireflies="p_firefly",Flames="p_flame3"},{"Glow","Bloom","Stars","Sparks","Hearts","Snow","Lightning","Petals","Flowers","Leaves","Bubbles","Crown","Fireflies","Flames"};
      for q,q in ipairs(N)do
        Y.AuraTypes[#Y.AuraTypes+1]=q;
      end;
      local q;
      N=y;
      local q=N.gui("gunchams",-6);
      local b=Instance.new("Folder");
      local D;
      N=z;
      b.Name=N.RandomString();
      b.Parent=workspace.CurrentCamera;
      s=z;
      s:AddSignal(workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
        local z;
        local z=T[4][T[6]];
        if z then
          b.Parent=workspace.CurrentCamera;
        end
      end));
      local z,D={};
      local p,r=0,0;
      local function K(o)
        if o:IsA("BasePart") then
          return o;
        end
        if o:IsA("Model") then
          return o.PrimaryPart or o:FindFirstChildWhichIsA("BasePart",true);
        end
        return o:FindFirstChild("Handle")or o:FindFirstChildWhichIsA("BasePart",true);
      end
      local function o(c)
        if c:GetAttribute("VisualsGunAura")or c:IsDescendantOf(b) then
          return true;
        end
        local m;
        local m=n;
        for n,n in ipairs(m:GetPlayers())do
          if n.Character and c:IsDescendantOf(n.Character) then
            return true;
          end
        end;
        return false;
      end
      local function n(c)
        if c.Name~="GunDrop"or o(c) then
          return;
        end
        if c:IsA("BasePart")or c:IsA("Model")or c:IsA("Tool") then
          e[c]=true;
        end
      end
      local function c(m)
        if m.Name=="GunDrop" then
          e[m]=nil;
        end
      end
      local function m(S)
        table.clear(e);
        local O;
        local O=J;
        O("gun chams scan",workspace,n,function()
          local J=S==p and(Y.On or Y.Circle);
          return J;
        end,512);
      end
      local function J(S)
        S.NativeActive=false;
        if S.NativeAdded then
          S.NativeAdded:Disconnect();
          S.NativeAdded=nil;
        end
        for O,B in pairs(S.Native or{})do
          if B.Connection then
            B.Connection:Disconnect();
          end
          if O.Parent then
            pcall(function()
              O[B.Property]=B.Value;
            end);
          end
        end;
        S.Native=nil;
      end
      local function S(O,B)
        if O:GetAttribute("VisualsGunAura") then
          return nil;
        end
        if O:IsA("ParticleEmitter")or O:IsA("Beam")or O:IsA("Trail")or O:IsA("Sparkles")or O:IsA("Fire")or O:IsA("Smoke")or O:IsA("Light")or O:IsA("Highlight")or O:IsA("BillboardGui")or O:IsA("SurfaceGui") then
          return"Enabled",false;
        end
        if O:IsA("BasePart")and O~=B then
          local B,A=O.Color,O.Name:lower();
          if B.G>B.R*1.15 and B.G>B.B*1.15 and(A:find("aura",1,true)or A:find("glow",1,true)or A:find("ring",1,true)or A:find("effect",1,true)or O.Material==Enum.Material.Neon or O.Material==Enum.Material.ForceField) then
            return"Transparency",1;
          end
        end
      end
      local function O(B,A,w,F)
        if B.Native and B.Native[F] then
          return;
        end
        local h,W=S(F,w);
        if not h then
          return;
        end
        B.Native=B.Native or{};
        local S={Property=h,Value=F[h]};
        B.Native[F]=S;
        S.Connection=F:GetPropertyChangedSignal(h):Connect(function()
          if not(B.NativeActive and Y.On and Y.Aura and F.Parent and F:IsDescendantOf(A)) then
            return;
          end
          if F[h]~=W then
            S.Value=F[h];
            F[h]=W;
          end
        end);
        F[h]=W;
      end
      local function S(B,A,w)
        B.NativeActive=true;
        if not B.NativeAdded then
          B.NativeAdded=A.DescendantAdded:Connect(function(F)
            if B.NativeActive then
              O(B,A,B.AuraPart or w,F);
            end
          end);
          B.NativeSweep=0;
        end
        local F=os.clock();
        if F<B.NativeSweep then
          return;
        end
        B.NativeSweep=F+0.25;
        for F,h in pairs(B.Native or{})do
          if not F.Parent or not F:IsDescendantOf(A) then
            h.Connection:Disconnect();
            if F.Parent then
              pcall(function()
                F[h.Property]=h.Value;
              end);
            end
            B.Native[F]=nil;
          end
        end;
        for F,F in ipairs(A:GetDescendants())do
          O(B,A,w,F);
        end;
      end
      local function O(B)
        if B.shell then
          B.shell:Destroy();
          B.shell=nil;
        end
        if B.AuraEffect then
          B.AuraEffect:Destroy();
          B.AuraEffect=nil;
        end
        B.AuraPart=nil;
        B.AuraType=nil;
        B.AuraSettings=nil;
      end
      local function B(A)
        O(A);
        J(A);
      end
      local function A(w)
        local F=j[w];
        if not F then
          return;
        end
        j[w]=nil;
        if F.glow then
          pcall(function()
            F.glow:Destroy();
          end);
        end
        B(F);
        if F.Circle then
          F.Circle.Part:Destroy();
          F.Circle=nil;
        end
        local h;
        w=H;
        w(F.label);
      end
      local function H()
        for w in pairs(j)do
          A(w);
        end;
      end
      local function w(F)
        local h=F.Archivable;
        local W=not h;
        if W and not pcall(function()F.Archivable=true;end) then
          return nil;
        end
        local V,_=pcall(F.Clone,F);
        if W then
          pcall(function()
            F.Archivable=h;
          end);
        end
        if not V or not _ then
          return nil;
        end
        for F,F in ipairs(_:GetChildren())do
          if not F:IsA("DataModelMesh") then
            F:Destroy();
          end
        end;
        local F=_:FindFirstChildWhichIsA("DataModelMesh");
        if F then
          pcall(function()
            F.TextureId="";
          end);
        end
        pcall(function()
          _.TextureID="";
        end);
        _.Name="VisualsGunAuraShell";
        local F;
        local F,h=f;
        W=a;
        _:SetAttribute(F,W);
        _.MaterialVariant="";
        _:SetAttribute("VisualsGunAura",true);
        _.Anchored=true;
        _.CanCollide=false;
        _.CanQuery=false;
        _.CanTouch=false;
        _.CastShadow=false;
        _.Massless=true;
        return _;
      end
      local function f(a,F,h,W)
        if not Y.Aura then
          B(a);
          return;
        end
        if W==false then
          O(a);
          S(a,F,h);
          return;
        end
        local V=table.find(Y.AuraTypes,Y.AuraType)and Y.AuraType or"ForceField";
        W=a.shell or a.AuraEffect;
        local _=a.AuraType~=V or a.AuraPart~=h or not W or not W.Parent;
        if _ then
          O(a);
          local O,W=pcall(function()
            local X=C[V];
            if X then
              local x=Instance.new("Attachment");
              x:SetAttribute("VisualsGunAura",true);
              local k=Instance.new("ParticleEmitter");
              k:SetAttribute("VisualsGunAura",true);
              k.Enabled=false;
              k.LightEmission=1;
              k.LightInfluence=0;
              k.Lifetime=NumberRange.new(0.6,1.2);
              k.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.15,0.25),NumberSequenceKeypoint.new(0.7,0.4),NumberSequenceKeypoint.new(1,1)});
              k.Parent=x;
              x.Parent=h;
              task.defer(function()
                local v;
                local v=d;
                local I,I=d,v.id(d.file("particles/"..C[V]..".png"));
                local d;
                v=T[4][T[6]]and j[F]==a and a.AuraEffect==x and x.Parent and I;
                if v then
                  k.Texture,k.Enabled=I,Y.On and Y.Aura;
                end
              end);
              return x;
            end
            if V=="Sparkle"or V=="Fire"or V=="Smoke" then
              X=Instance.new(V=="Sparkle"and"Sparkles"or V);
              X:SetAttribute("VisualsGunAura",true);
              if V=="Fire" then
                X.Size=1.2;
                X.Heat=0.3;
              end
              if V=="Smoke" then
                X.Size=0.75;
                X.Opacity=0.12;
                X.RiseVelocity=0.4;
              end
              X.Parent=h;
              return X;
            end
            local d=w(h);
            if d then
              d.Parent=b;
            end
            return d;
          end);
          if not O or not W then
            J(a);
            return;
          end
          if W:IsA("BasePart") then
            a.shell=W;
          else
            a.AuraEffect=W;
          end
          a.AuraType=V;
          a.AuraPart=h;
        end
        if a.shell then
          _=a.shell;
          local J,d,O=_:FindFirstChildWhichIsA("DataModelMesh"),h:FindFirstChildWhichIsA("DataModelMesh"),(1+0.08*Y.AuraSpread)*Y.AuraSize;
          if J and d then
            J.Scale=d.Scale*O;
          else
            _.Size=h.Size*O;
          end
          _.CFrame,_.Color=h.CFrame,Y.AuraColor;
          _.Material=Enum.Material[V];
          _.Reflectance=V=="Metal"and 0.3 or V=="Glass"and 0.12 or 0;
          _.Transparency=1-Y.AuraOpacity;
          _.LocalTransparencyModifier=0;
        elseif C[V] then
          local J,d,C=a.AuraEffect:FindFirstChildOfClass("ParticleEmitter"),{Y.AuraColor,Y.AuraSpread,Y.AuraSpeed,Y.AuraSize,Y.AuraRate,Y.AuraGlow,Y.AuraOpacity},not a.AuraSettings;
          for O,w in ipairs(d)do
            C=if not a.AuraSettings or w~=a.AuraSettings[O]then true else C;
          end;
          if J and C then
            a.AuraSettings=d;
            J.Color=ColorSequence.new(Y.AuraColor);
            J.Speed=NumberRange.new(0.15*Y.AuraSpread*Y.AuraSpeed,1.5*Y.AuraSpread*Y.AuraSpeed);
            J.SpreadAngle=Vector2.new(180,180);
            J.Size=NumberSequence.new(0.3*Y.AuraSize);
            J.Rate,J.Brightness=24*Y.AuraRate,Y.AuraGlow;
            J.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.15,1-Y.AuraOpacity),NumberSequenceKeypoint.new(0.7,1-Y.AuraOpacity*0.6),NumberSequenceKeypoint.new(1,1)});
          end
        elseif V=="Sparkle" then
          a.AuraEffect.SparkleColor=Y.AuraColor;
        elseif V=="Fire" then
          a.AuraEffect.Size,a.AuraEffect.Heat=1.2*Y.AuraSize*Y.AuraSpread,0.3*Y.AuraSpeed;
          a.AuraEffect.Color=Y.AuraColor;
          a.AuraEffect.SecondaryColor=Y.AuraColor:Lerp(Color3.new(1,1,1),0.35);
        else
          a.AuraEffect.Color=Y.AuraColor;
          a.AuraEffect.Size=0.75*Y.AuraSize*Y.AuraSpread;
          a.AuraEffect.Opacity,a.AuraEffect.RiseVelocity=0.2*Y.AuraOpacity,0.4*Y.AuraSpeed;
        end
        S(a,F,h);
      end
      local function J()
        local a={};
        for d in pairs(e)do
          if d.Name=="GunDrop"and d.Parent and not o(d) then
            local C=K(d);
            if C then
              local K,o=#a+1,{object=d,part=C};
              o.adorn,a[K]=(d:IsA("BasePart")or d:IsA("Model"))and d or C,o;
            end
          end
        end;
        return a;
      end
      local a={};
      local function d(C)
        local K;
        local K=T[4][T[6]]and(Y.On or Y.Circle);
        if not K then
          if next(j) then
            H();
          end
          return;
        end
        r+=C;
        K=r>=0.25;
        if K then
          r=0;
          a=J();
          local T,J={},a;
          for o,o in ipairs(J)do
            T[o.object]=true;
          end;
          for J in pairs(j)do
            if not T[J] then
              A(J);
            end
          end;
        end
        K=y;
        local y=K.camera();
        if not y then
          return;
        end
        local T,J=ipairs,a;
        for o,S in T(J)do
          o,K=S.object,S.part;
          local T=not(o.Parent and K and K.Parent);
          if T then
            A(o);
          else
            local T,J=j[o],L;
            local O=J.Visibility.Part(y,K,o);
            if not T then
              T={};
              j[o]=T;
            else
            end
            if not T.glow then
              J=Instance.new("Highlight");
              J.DepthMode=Enum.HighlightDepthMode.Occluded;
              J.Parent=q;
              T.glow=J;
            end
            T.glow.Adornee=S.adorn;
            T.glow.OutlineColor=Y.Outline;
            T.glow.OutlineTransparency=0;
            T.glow.FillColor=Y.Outline;
            T.glow.FillTransparency=math.clamp(Y.Fill,0,1);
            T.glow.Enabled=Y.On and O;
            if Y.On then
              f(T,o,K,O);
            else
              B(T);
            end
            local f,q=Y.Circle;
            if f then
              J=L;
              q=J.StaticGunCircle;
            else
              q=f;
            end
            if q then
              J=L;
              J.StaticGunCircle(T,o,K,C);
            elseif T.Circle then
              T.Circle.Part:Destroy();
              T.Circle=nil;
            end
            J=Y.On and Y.Text;
            if J then
              f=not T.label;
              if f then
                local J;
                q=P;
                local J=q("Text");
                J.Center=true;
                J.Outline=true;
                J.Size=13;
                J.Font=2;
                T.label=J;
              end
              local J,f=y:WorldToViewportPoint(K.Position);
              if O and f and J.Z>0 then
                T.label.Text="Gun";
                T.label.Color=Y.TextColor;
                T.label.Position=Vector2.new(J.X,J.Y);
                T.label.Visible=true;
              else
                T.label.Visible=false;
              end
            elseif T.label then
              T.label.Visible=false;
            end
          end
        end;
      end
      local function y()
        if z[1] then
          return;
        end
        p+=1;
        local T=p;
        r=0.25;
        z[#z+1]=workspace.DescendantAdded:Connect(n);
        z[#z+1]=workspace.DescendantRemoving:Connect(c);
        local n;
        local n=Z;
        D=n.RenderStepped:Connect(d);
        m(T);
      end
      local function T()
        p+=1;
        for n,n in ipairs(z)do
          pcall(function()
            n:Disconnect();
          end);
        end;
        local n=D;
        if n then
          pcall(function()
            D:Disconnect();
          end);
          D=nil;
        end
        table.clear(z);
        table.clear(e);
        a={};
        H();
      end
      Y.SetTracking=function()
        if Y.On or Y.Circle then
          y();
        else
          T();
        end
      end;
      s=l;
      N=s.Guns:AddLabel("Dropped Gun");
      N:AddToggle({Name="Dropped Gun",Default=false,Flag="gun_chams",Callback=function(y)
        Y.On=y;
        Y.SetTracking();
      end});
      N:AddColorPicker({Default=Y.Outline,Flag="gun_chams_color",Callback=function(y)
        Y.Outline=y;
      end});
      N=l;
      N.Guns:AddLabel("Fill"):AddSlider({Min=0,Max=100,Default=75,Rounding=0,Size=100,Type="%",Flag="gun_chams_fill",Callback=function(y)
        Y.Fill=y/100;
      end});
      N=l;
      s=N.Guns:AddLabel("Aura");
      s:AddToggle({Name="Aura",Default=true,Flag="gun_chams_aura",Callback=function(y)
        Y.Aura=y;
        if not y then
          for y,y in pairs(j)do
            B(y);
          end;
        end
      end});
      s:AddColorPicker({Default=Y.AuraColor,Flag="gun_chams_aura_color",Callback=function(y)
        Y.AuraColor=y;
      end});
      N=s:AddOption(1);
      N:AddLabel("Style"):AddDropdown({Default="ForceField",Values=Y.AuraTypes,Flag="gun_chams_aura_type",Callback=function(y)
        Y.AuraType=table.find(Y.AuraTypes,y)and y or"ForceField";
      end});
      s={{"Spread","AuraSpread","spread",0,800,100},{"Size","AuraSize","size",10,500,100},{"Speed","AuraSpeed","speed",0,500,100},{"Rate","AuraRate","rate",0,400,100},{"Opacity","AuraOpacity","opacity",0,100,75},{"Glow","AuraGlow","glow",0,600,200}};
      for y,y in ipairs(s)do
        local z=y[2];
        N:AddLabel(y[1]):AddSlider({Min=y[4],Max=y[5],Default=y[6],Rounding=0,Flag="gun_chams_aura_"..y[3],Callback=function(y)
          Y[z]=y/100;
        end});
      end;
      N=l;
      s=N.Guns:AddLabel("Label");
      s:AddToggle({Name="Label",Default=true,Flag="gun_chams_text",Callback=function(l)
        Y.Text=l;
      end});
      s:AddColorPicker({Default=Y.TextColor,Flag="gun_chams_text_color",Callback=function(l)
        Y.TextColor=l;
      end});
      local l,y=L;
      s=G;
      l.ClearGunChams=s("gunchams",function()
        Y.On=false;
        Y.Circle=false;
        T();
        pcall(function()
          b:Destroy();
        end);
      end);
    end;
  end;
end
