-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #30
-- offset 116631..117955 (1324 bytes, type=payload)

local function f(q,r)
  if q.limb then
    local K=e(r.char,q.n);
    if not K then
      return nil;
    end
    r.map[q.i]=K;
    for o,c in ipairs(q.k or{})do
      o=f(c,r);
      if o then
        r.limbKids[#r.limbKids+1]={o,K,q.cf};
      end
    end;
    return nil;
  end
  local K,o;
  if q.c=="MeshPart"and q.m and q.m~="" then
    local c;
    K,c=p(q.m);
    o=c;
  else
    local p,c=pcall(Instance.new,q.c);
    if not p then
      return nil;
    end
    K=c;
  end
  K.Name=q.n;
  r.map[q.i]=K;
  for p,c in pairs(q.p)do
    if getmetatable(c)==a then
      local a,m=r.refs,r.refs;
      local S,O=#m+1,{};
      s:MT(O,0,K,p,c[1]);
      a[S]=O;
    else
      pcall(function()
        K[p]=c;
      end);
    end
  end;
  if q.a then
    for s,a in pairs(q.a)do
      pcall(K.SetAttribute,K,s,a);
    end;
  end
  if o then
    local s=q.z;
    if typeof(s)=="Vector3"and s.X>0 and s.Y>0 and s.Z>0 then
      o.Scale=K.Size/s;
    else
      K.Transparency=1;
    end
    if type(q.p.TextureID)=="string" then
      o.TextureId=q.p.TextureID;
    end
  end
  if q.c=="Part"and K.Shape==Enum.PartType.Block and D(q) then
    K.Transparency=1;
  end
  if K:IsA("BasePart") then
    K.Anchored=false;
    K.CanCollide=false;
    K.CanTouch=false;
    K.CanQuery=false;
    K.Massless=true;
  end
  for s,a in ipairs(q.k or{})do
    if a.c=="SurfaceAppearance" then
      local q=a.p.ColorMap;
      if type(q)=="string"and q~="" then
        if o then
          if o.TextureId=="" then
            o.TextureId=q;
          end
        elseif K:IsA("MeshPart")and K.TextureID=="" then
          pcall(function()
            K.TextureID=q;
          end);
        end
      end
    else
      s=f(a,r);
      if s then
        s.Parent=K;
      end
    end
  end;
  return K;
end
