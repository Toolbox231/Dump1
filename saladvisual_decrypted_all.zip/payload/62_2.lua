-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #2
-- offset 3226076..3244583 (18507 bytes, type=payload)

function()
  local l;
  local l=L;
  local C,N=l("models.txt"),L;
  local L,q,b,D=N("model_sizes.txt"),{{Name="Tung Tung Sahur",Id="138151705692565"}},{On=false,Pick=nil,Sizes={},Rotations={}};
  l=y;
  l.Models=b;
  local N,D,p,r,K,o,c,m,S,O={},{},{},0,0,0,false;
  local B,A,w,F={},{};
  local h,W,V={};
  local _,X,x,k,v,I,i={},false,false,false,{},{},{};
  local E,Q,t,R,g,u=game:GetService("MarketplaceService"),false,false,{},{};
  local function U(M)
    if N[M.Name] then
      return;
    end
    N[M.Name]=M;
    D[#D+1]=M.Name;
  end
  local function M()
    table.clear(N);
    table.clear(D);
    for sP,sP in ipairs(q)do
      U({Name=sP.Name,Id=sP.Id,Kind="asset"});
    end;
    table.sort(D,function(q,sP)
      return string.lower(q)<string.lower(sP);
    end);
    if isfile and readfile and isfile(C) then
      local q,sP=pcall(readfile,C);
      if q and type(sP)=="string" then
        for q in string.gmatch(sP,"[^\13\10]+")do
          local sP,lP=string.match(q,"^(%d+)|(.*)$");
          if sP then
            U({Name=lP~=""and lP or"Model "..sP,Id=sP,Kind="asset",User=true});
          end
        end;
      end
    end
  end
  local function q()
    if not writefile then
      return;
    end
    local sP={};
    for lP,LP in ipairs(D)do
      lP=N[LP];
      if lP and lP.User and lP.Id then
        sP[#sP+1]=lP.Id.."|"..lP.Name;
      end
    end;
    pcall(writefile,C,table.concat(sP,"\10"));
  end
  local function C()
    local sP={};
    for lP,lP in ipairs(D)do
      local LP,yP,zP=N[lP],#sP+1,{name=lP,label=lP};
      zP.id,sP[yP]=LP and LP.Id and tonumber(LP.Id)or nil,zP;
    end;
    return sP;
  end
  local function sP()
    if not w then
      return;
    end
    local lP=C();
    if w.setdata then
      pcall(function()
        w:setdata(lP);
      end);
    elseif w.setlist then
      pcall(function()
        w:setlist(lP);
      end);
    end
  end
  local function lP()
    for LP,yP in pairs(B)do
      if LP.Parent then
        pcall(function()
          LP.LocalTransparencyModifier=yP;
        end);
      end
    end;
    for LP,yP in pairs(A)do
      if LP.Parent then
        pcall(function()
          LP.Transparency=yP;
        end);
      end
    end;
    table.clear(B);
    table.clear(A);
    if F then
      F();
    end
  end
  local function LP(yP)
    for zP,TP in ipairs(yP:GetDescendants())do
      zP=TP:FindFirstAncestorWhichIsA("Accessory");
      local yP=zP and(zP:GetAttribute("VisualsCharacterAccessory"));
      if TP:IsA("BasePart")and not yP then
        if B[TP]==nil then
          B[TP]=h[TP]or TP.LocalTransparencyModifier;
        end
        if TP.LocalTransparencyModifier<1 then
          TP.LocalTransparencyModifier=1;
        end
      elseif not yP and(TP:IsA("Decal")or TP:IsA("Texture")) then
        if A[TP]==nil then
          A[TP]=TP.Transparency;
        end
        if TP.Transparency<1 then
          TP.Transparency=1;
        end
      end
    end;
  end
  local A={"hair","bang","ponytail","pigtail","braid","dread","locks","wig","afro","mohawk","fringe","twintail","hairstyle","bobcut","hairdo"};
  local function yP(zP)
    table.clear(v);
    local TP=zP and(zP:FindFirstChildOfClass("Humanoid"));
    if not TP then
      return;
    end
    local zP,nP=pcall(TP.GetAppliedDescription,TP);
    if zP and nP then
      for zP in string.gmatch(nP.HairAccessory or"","%d+")do
        v[zP]=true;
      end;
    end
  end
  local function zP(TP)
    local nP,JP=pcall(function()
      return TP.SourceAssetId;
    end);
    return nP and tonumber(JP)or nil;
  end
  local function TP(nP,JP)
    local HP=JP and string.format("%.0f",JP)or nil;
    if not HP or JP<=0 or I[HP]~=nil or i[HP] then
      return;
    end
    i[HP]=true;
    task.spawn(function()
      local fP,aP=pcall(E.GetProductInfo,E,JP,Enum.InfoType.Asset);
      i[HP]=nil;
      I[HP]=fP and type(aP)=="table"and tonumber(aP.AssetTypeId)==Enum.AssetType.HairAccessory.Value or false;
      local i;
      fP=I[HP]and z[4][z[6]]and X and nP.Parent;
      if fP then
        F();
      end
    end);
  end
  local function i(E)
    if E:IsA("Accessory")and E.AccessoryType==Enum.AccessoryType.Hair then
      return true;
    end
    for nP,nP in ipairs(E:GetDescendants())do
      if nP:IsA("Attachment")and nP.Name=="HairAttachment" then
        return true;
      end
    end;
    local nP=zP(E);
    local zP=nP and string.format("%.0f",nP)or nil;
    if zP and(v[zP]or I[zP]==true) then
      return true;
    end
    if zP and I[zP]==nil then
      TP(E,nP);
    end
    local v,I,zP=string.lower(E.Name),pcall(E.GetTags,E);
    if I then
      for I,I in ipairs(zP)do
        v..=" "..string.lower(I);
      end;
    else
    end
    for I,I in ipairs(A)do
      if string.find(v,I,1,true) then
        return true;
      end
    end;
    return false;
  end
  F=function()
    local A;
    local A=T;
    local v,I,E=A.Character,{},{};
    A=v and(X or x);
    if A then
      local zP,TP=ipairs,s[70](v:GetChildren());
      for nP,nP in zP(s:ZT(TP))do
        local s,zP=nP:IsA("Accessory")or nP:IsA("Hat"),nP:GetAttribute("VisualsCharacterAccessory")==true;
        local TP,JP=x and s and not zP,X and s and i(nP);
        if TP or JP then
          if nP:IsA("BasePart") then
            I[nP]=true;
          end
          for s,s in ipairs(nP:GetDescendants())do
            if s:IsA("BasePart") then
              I[s]=true;
            end
          end;
          if TP then
            for s in pairs(I)do
              if s==nP or s:IsDescendantOf(nP) then
                E[s]=true;
              end
            end;
          end
        end
      end;
    end
    for s,i in pairs(_)do
      v=not E[s];
      if v then
        A=s.Parent;
        if A then
          s.Transparency=t and g[s]and 1 or i;
        end
        _[s]=nil;
      end
    end;
    for s in pairs(E)do
      if _[s]==nil then
        _[s]=g[s]and g[s].Transparency or s.Transparency;
      end
      s.Transparency=1;
    end;
    for s,A in pairs(h)do
      if not I[s] then
        if s.Parent then
          s.LocalTransparencyModifier=B[s]~=nil and 1 or A;
        end
        h[s]=nil;
      end
    end;
    for s in pairs(I)do
      if h[s]==nil then
        h[s]=B[s]or s.LocalTransparencyModifier;
      end
      s.LocalTransparencyModifier=1;
    end;
  end;
  local function s(B)
    local A=W;
    if A then
      W:Disconnect();
      W=nil;
    end
    if not B then
      return;
    end
    yP(B);
    W=B.DescendantAdded:Connect(function()
      local A;
      local A=z[4][z[6]]and(X or x);
      local h=not A or k;
      if h then
        return;
      end
      k=true;
      task.defer(function()
        k=false;
        local A,h=z[4][z[6]];
        if A then
          local k;
          local k=T;
          h=k.Character==B;
        else
          h=A;
        end
        if h then
          F();
        end
      end);
    end);
  end
  local B,A=0;
  local A,h=n;
  l=J;
  A:AddSignal(l.RenderStepped:Connect(function(h)
    local k=not(X or x);
    if k then
      B=0;
      return;
    end
    B+=h;
    h=B>=0.08;
    if h then
      B=0;
      F();
    end
  end));
  local function B(h)
    if p[h.Name] then
      return p[h.Name];
    end
    local k;
    local k=H;
    local H,v=k.objects(function()
      local I,i=game,"rbxassetid://"..tostring(h.Id);
      return I:GetObjects(i);
    end);
    if not H or type(v)~="table"or not v[1] then
      return nil;
    end
    k=v[1];
    for I=2,#v,1 do
      pcall(function()
        v[I]:Destroy();
      end);
    end;
    local v;
    H=z[4][z[6]];
    if not H then
      k:Destroy();
      return nil;
    end
    if not k:IsA("Model") then
      H=Instance.new("Model");
      k.Parent=H;
      k=H;
    else
    end
    H=k:GetDescendants();
    if #H>4096 then
      k:Destroy();
      return nil;
    end
    k.Archivable=true;
    for v,v in ipairs(H)do
      v.Archivable=true;
      if v:IsA("LuaSourceContainer")or v:IsA("Humanoid")or v:IsA("JointInstance")or v:IsA("Constraint")or v:IsA("BodyMover")or v:IsA("Sound")or v:IsA("ParticleEmitter")or v:IsA("Beam")or v:IsA("Trail")or v:IsA("Fire")or v:IsA("Smoke")or v:IsA("Sparkles") then
        pcall(function()
          v:Destroy();
        end);
      end
    end;
    for H,H in ipairs(k:GetDescendants())do
      if H:IsA("BasePart") then
        H.Anchored=true;
        H.CanCollide=false;
        H.CanQuery=false;
        H.CanTouch=false;
        H.Massless=true;
        H.CastShadow=false;
        H.Locked=true;
      end
    end;
    p[h.Name]=k;
    return k;
  end
  local function H()
    local h=S;
    if h then
      pcall(function()
        S:Disconnect();
      end);
      S=nil;
    end
    h=m;
    if h then
      pcall(function()
        m:Destroy();
      end);
      m=nil;
    end
    lP();
  end
  local h,k={RightUpperLeg={MeshId="rbxassetid://902942096",TextureID="rbxassetid://902843398"},RightLowerLeg={MeshId="rbxassetid://902942093",Transparency=1},RightFoot={MeshId="rbxassetid://902942089",Transparency=1}},"rbxassetid://6686307858";
  local function v()
    local I=u;
    if I then
      u:Destroy();
      u=nil;
    end
    for I,i in pairs(R)do
      if I.Parent then
        for E,lP in pairs(i)do
          pcall(function()
            I[E]=lP;
          end);
        end;
      end
    end;
    table.clear(R);
  end
  local function I()
    local i=Q;
    if not i then
      return;
    end
    local E;
    i=T;
    local E=i.Character;
    if not E then
      return;
    end
    v();
    i=E:FindFirstChild("Right Leg");
    local lP=i and i:IsA("BasePart")and not E:FindFirstChild("RightUpperLeg");
    if lP then
      R[i]={Transparency=i.Transparency};
      local zP=Instance.new("Part");
      zP.Name="VisualsR6Korblox";
      local TP;
      local TP,nP=f;
      local f=a;
      zP:SetAttribute(TP,f);
      zP.Size,zP.CFrame=i.Size,i.CFrame;
      zP.Color,zP.Material=i.Color,Enum.Material.SmoothPlastic;
      zP.Transparency,zP.Reflectance=0,i.Reflectance;
      zP.CanCollide=false;
      zP.CanQuery=false;
      zP.CanTouch=false;
      zP.Massless=true;
      zP.CastShadow=false;
      f=Instance.new("SpecialMesh");
      f.MeshType=Enum.MeshType.FileMesh;
      f.MeshId="rbxassetid://902942096";
      f.TextureId="rbxassetid://902843398";
      f.Scale=Vector3.new(1.05,1,1.05);
      f.Parent=zP;
      f=Instance.new("WeldConstraint");
      f.Part0=zP;
      f.Part1=i;
      f.Parent=zP;
      zP.Parent=E;
      i.Transparency=1;
      u=zP;
      return;
    end
    for f,a in pairs(h)do
      local h=E:FindFirstChild(f);
      if h then
        i={};
        for E in pairs(a)do
          lP,f=pcall(function()
            return h[E];
          end);
          if lP then
            i[E]=f;
          end
        end;
        R[h]=i;
        for f,i in pairs(a)do
          pcall(function()
            h[f]=i;
          end);
        end;
      end
    end;
  end
  local function f()
    for a,h in pairs(g)do
      if a.Parent then
        for i,E in pairs(h)do
          if i=="Transparency"and _[a]~=nil then
            E=1;
          else
          end
          pcall(function()
            a[i]=E;
          end);
        end;
      end
    end;
    table.clear(g);
  end
  local function a()
    local h=t;
    if not h then
      return;
    end
    local _;
    h=T;
    local _=h.Character;
    local i=_ and(_:FindFirstChild("Head"));
    if not i then
      return;
    end
    f();
    g[i]={MeshId=pcall(function()
      return i.MeshId;
    end)and i.MeshId or nil,TextureID=pcall(function()
      return i.TextureID;
    end)and i.TextureID or nil,Transparency=i.Transparency};
    pcall(function()
      i.MeshId=k;
    end);
    pcall(function()
      i.TextureID=k;
    end);
    pcall(function()
      i.Transparency=1;
    end);
    for k,k in ipairs(i:GetDescendants())do
      _,h=pcall(function()
        return k.Transparency;
      end);
      if _ and type(h)=="number" then
        g[k]={Transparency=h};
        pcall(function()
          k.Transparency=1;
        end);
      end
    end;
  end
  local function h(_)
    local k=b.Pick and N[b.Pick];
    if not k then
      return;
    end
    local i,E;
    local R;
    for R=1,40,1 do
      R=_~=r or not(b.On and b.Pick);
      if R then
        return;
      end
      R=T;
      i=R.Character;
      E=i and(i:FindFirstChild("HumanoidRootPart"));
      if E then
        break;
      end
      task.wait(0.25);
    end;
    if not i or not E then
      return;
    end
    local R,g=i:FindFirstChildOfClass("Humanoid"),B(k);
    local u;
    local u,lP=not z[4][z[6]]or not b.On or _~=r;
    if u then
      lP=u;
    else
      _=T;
      lP=_.Character~=i;
    end
    if lP or not i.Parent or not E.Parent then
      return;
    end
    _=not g;
    if _ then
      local zP;
      lP=d;
      local zP,TP=lP.new,{Title="Models"};
      TP.Content,TP.Duration="Could not load "..k.Name,4;
      zP(TP);
      return;
    end
    local zP=g:Clone();
    if not zP then
      return;
    end
    u=y;
    _=u.BodyExtents(i,E);
    g,lP,u=_ and _.half*2 or Vector3.new(3,5,2),zP:GetBoundingBox();
    if u.Y>0.01 then
      _=math.clamp(tonumber(b.Sizes[k.Name])or 1,0.35,1.25);
      local lP=g.Y/u.Y*_;
      if math.abs(lP-1)>0.02 then
        pcall(function()
          zP:ScaleTo(zP:GetScale()*lP);
        end);
      end
    end
    g,_=zP:GetBoundingBox();
    local u=(zP:GetPivot():Inverse()*g):Inverse();
    local g=_.Y*0.5-E.Size.Y*0.5-(R and R.HipHeight or 0);
    zP.Name="VisualsModelShell";
    local _;
    R=P;
    R.DepthTree(zP,false);
    local _={};
    for R,R in ipairs(zP:GetDescendants())do
      if R:IsA("BasePart") then
        _[#_+1]={R,R.LocalTransparencyModifier};
      end
    end;
    zP.Parent=workspace;
    m=zP;
    LP(i);
    local R,lP;
    local TP,nP=0;
    local JP,HP=i.DescendantAdded:Connect(function()
      local fP=z[4][z[6]]and b.On and m;
      if fP then
        TP=0;
      end
    end),n;
    HP:AddSignal(JP);
    local function fP()
      JP:Disconnect();
    end
    zP.Destroying:Once(fP);
    HP=J;
    S=HP.RenderStepped:Connect(function()
      local S=z[4][z[6]]and b.On and m and m.Parent;
      if not S then
        return;
      end
      if not E.Parent then
        return;
      end
      S=y;
      local zP,zP=P,S.Visibility.Character(P.camera(),i,E);
      S=nP~=zP;
      if S then
        nP=zP;
        for P,P in ipairs(_)do
          if P[1].Parent then
            P[1].LocalTransparencyModifier=zP and P[2]or 1;
          end
        end;
      end
      local P,_,nP=E.CFrame,b.Rotations[k.Name]or 0,os.clock()>=TP;
      if nP then
        TP=os.clock()+0.2;
        LP(i);
      end
      nP=R==P and lP==_;
      if nP then
        return;
      end
      R,lP=P,_;
      S,zP,nP=P.LookVector,P.Position,m;
      nP:PivotTo(CFrame.new(zP.X,zP.Y+g,zP.Z)*CFrame.fromEulerAnglesYXZ(0,math.atan2(-S.X,-S.Z)+math.rad(_),0)*u);
    end);
  end
  local function P()
    r+=1;
    H();
    if not(b.On and b.Pick) then
      return;
    end
    local m=r;
    task.spawn(function()
      local S,_=pcall(h,m);
      if not S then
        warn("[visuals] model: "..tostring(_));
      end
      S=m==r and not b.On;
      if S then
        H();
      end
    end);
  end
  local function m()
    local S=not c or not writefile;
    if S then
      return;
    end
    S={};
    for h in pairs(N)do
      if b.Sizes[h]or b.Rotations[h] then
        S[#S+1]=h.."|"..tostring(b.Sizes[h]or 1).."|"..tostring(b.Rotations[h]or 0);
      end
    end;
    table.sort(S);
    local h=pcall(writefile,L,table.concat(S,"\10"));
    if h then
      c=false;
    end
  end
  local function S()
    c=true;
    local c=writefile;
    if c then
      o+=1;
      local c=o;
      task.delay(0.35,function()
        local h;
        local h=c==o and z[4][z[6]];
        if h then
          m();
        end
      end);
    end
  end
  local function c(h,_)
    local k;
    local k=not z[4][z[6]]or not N[h];
    if k then
      return;
    end
    _=tonumber(_);
    if not _ or _~=_ or math.abs(_)==1/0 then
      return;
    end
    b.Rotations[h]=math.clamp(_,0,360);
    S();
  end
  b.SetRotation=c;
  local function h(_,k)
    local i;
    local i=not z[4][z[6]]or not N[_];
    if i then
      return;
    end
    k=tonumber(k);
    if not k or k~=k or math.abs(k)==1/0 then
      return;
    end
    b.Sizes[_]=math.clamp(k,0.35,1.25);
    S();
    i=b.Pick==_ and b.On;
    if i then
      K+=1;
      local S=K;
      task.delay(0.12,function()
        local k=S==K and z[4][z[6]]and b.On and b.Pick==_;
        if k then
          P();
        end
      end);
    end
  end
  local function K()
    if not(isfile and readfile and isfile(L)) then
      return;
    end
    local S,_=pcall(readfile,L);
    if not S or type(_)~="string" then
      return;
    end
    for L in string.gmatch(_,"[^\13\10]+")do
      local S,_,k=string.match(L,"^(.-)|([^|]+)|?(.*)$");
      _,k=tonumber(_),tonumber(k);
      if S and N[S] then
        if _ and _==_ and math.abs(_)<1/0 then
          b.Sizes[S]=math.clamp(_,0.35,1.25);
        end
        if k and k==k and math.abs(k)<1/0 then
          b.Rotations[S]=math.clamp(k,0,360);
        end
      end
    end;
  end
  local function L(S)
    local _=type(S)=="table"and S[1]or S;
    _=type(_)=="string"and N[_]and _ or nil;
    S=_~=nil;
    if b.Pick==_ and b.On==S then
      return;
    end
    b.Pick=_;
    b.On=S;
    P();
  end
  local function S(_)
    local k=string.match(tostring(_ or""),"(%d+)");
    _=not k;
    if _ then
      local _;
      local _=d;
      _.new({Title="Models",Content="Invalid ID",Duration=4});
      return;
    end
    U({Name="Model "..k,Id=k,Kind="asset",User=true});
    q();
    sP();
  end
  local function d(_)
    local k=N[_];
    if not(k and k.User) then
      return;
    end
    N[_]=nil;
    for k,i in ipairs(D)do
      if i==_ then
        table.remove(D,k);
        break;
      end
    end;
    if b.Pick==_ then
      b.Pick=nil;
      b.On=false;
      P();
      if w then
        w:set("");
      end
    end
    q();
    sP();
  end
  M();
  K();
  local function q()
    local K;
    local K=z[4][z[6]];
    if not K then
      return;
    end
    task.wait(1);
    K=z[4][z[6]];
    if not K then
      return;
    end
    pcall(I);
    pcall(a);
    pcall(F);
    if b.On then
      pcall(P);
    end
  end
  local function K()
    local _=O;
    if _ then
      return;
    end
    local k,i=n;
    _=T;
    local function i(E)
      s(E);
      task.spawn(q);
    end
    O=k:AddSignal(_.CharacterAdded:Connect(i));
    k=T;
    s(k.Character);
    k=T;
    V=k.CharacterAppearanceLoaded:Connect(function(s)
      local _;
      local _,k=z[4][z[6]];
      if _ then
        local i=T;
        k=i.Character==s;
      else
        k=_;
      end
      if k then
        task.spawn(q);
      end
    end);
  end
  K();
  local s;
  l=Z;
  local s,q=l.Character:AddLabel("Korblox Leg"),{Name="Korblox Leg",Default=false,Flag="korblox_leg"};
  q.Callback=function(_)
    Q=_;
    if _ then
      K();
      I();
    else
      v();
    end
  end;
  s:AddToggle(q);
  l=Z;
  local q,_=l.Character:AddLabel("Headless"),{Name="Headless",Default=false,Flag="headless"};
  _.Callback=function(k)
    t=k;
    if k then
      K();
      a();
    else
      f();
    end
  end;
  q:AddToggle(_);
  b.SetHairless=function(a)
    local q,K=a==true,a==true;
    X=q;
    b.Hairless=K;
    K=X;
    if K then
      local q;
      a=T;
      yP(a.Character);
    end
    F();
  end;
  b.SetNoAccessories=function(a)
    local q,K=a==true,a==true;
    x=q;
    b.NoAccessories=K;
    F();
  end;
  l=Z;
  l.Character:AddLabel("Hairless"):AddToggle({Default=false,Flag="hairless",Callback=b.SetHairless});
  local a;
  local a,q=G;
  if a then
    local a,G,q=false,{},{};
    local function K()
      local F,_={};
      local _=T;
      local T,k=_.Character,{"Knife","Gun"};
      for I,i in ipairs(k)do
        _=T and T:FindFirstChild("DisplayRef"..i);
        I=_ and _:IsA("ObjectValue")and _.Value;
        if I and(I:IsA("BasePart")) then
          F[#F+1]=I;
          for T,_ in ipairs(I.Parent and I.Parent:GetChildren()or{})do
            T=_~=I and _:FindFirstChildOfClass("WeldConstraint");
            if T and(T.Part0==I or T.Part1==I) then
              F[#F+1]=_;
            end
          end;
        end
      end;
      return F;
    end
    local function T(F)
      if F:IsA("BasePart") then
        if G[F]==nil then
          G[F]=F.LocalTransparencyModifier;
        end
        F.LocalTransparencyModifier=1;
      elseif F:IsA("ParticleEmitter")or F:IsA("Beam")or F:IsA("Trail")or F:IsA("Fire")or F:IsA("Sparkles")or F:IsA("Smoke")or F:IsA("Light") then
        if q[F]==nil then
          q[F]=F.Enabled;
        end
        F.Enabled=false;
      end
    end
    local function F()
      for _,_ in ipairs(K())do
        T(_);
        for K,K in ipairs(_:GetDescendants())do
          T(K);
        end;
      end;
    end
    local function T()
      for K,_ in pairs(G)do
        if K.Parent then
          pcall(function()
            K.LocalTransparencyModifier=_;
          end);
        end
      end;
      for K,_ in pairs(q)do
        if K.Parent then
          pcall(function()
            K.Enabled=_;
          end);
        end
      end;
      table.clear(G);
      table.clear(q);
    end
    local G,q,K=0,n,J;
    q:AddSignal(K.Heartbeat:Connect(function(J)
      local q=a;
      if not q then
        return;
      end
      G+=J;
      q=G;
      if q<0.25 then
        return;
      end
      G=0;
      pcall(F);
    end));
    l=Z;
    local J,G=l.Character:AddLabel("No Weapons"),{Default=false,Flag="no_weapons"};
    G.Callback=function(q)
      a=q==true;
      q=a;
      if q then
        pcall(F);
      else
        T();
      end
    end;
    J:AddToggle(G);
    s=Y;
    s("no weapons",function()
      a=false;
      T();
    end);
  end
  M=Z;
  M.Character:AddLabel("No Accessories"):AddToggle({Default=false,Flag="no_accessories",Callback=b.SetNoAccessories});
  A=Z;
  local s,T=A.Models,{Name="Add by ID"};
  T.Callback=function()
    local J=false;
    local function a()
      local G=n;
      G.Lib:ask({title="add model",icon="plus",hint="model id or link",accept="add",deny="cancel",callback=function(G)
        S(G);
      end});
      J=true;
    end
    pcall(a);
    a=not J;
    if a then
      S(getgenv and getgenv().VISUALS_MODEL_ID);
    end
  end;
  s:AddButton(T);
  A=Z;
  A.Models:AddButton({Name="Remove Model",Callback=function()
    b.On=false;
    b.Pick=nil;
    local s=n;
    local T=s.Lib;
    local s,J=T.quiet,T.configApplying;
    T.quiet=true;
    T.configApplying=true;
    pcall(function()
      if w then
        w:set("");
      end
    end);
    T.quiet=s;
    T.configApplying=J;
    P();
  end});
  local function s(T,J,a,P,Z)
    local G,q=N[T];
    J=not z[4][z[6]]or not G;
    if J then
      return;
    end
    if typeof(Z)=="Instance"and Z:IsA("GuiObject") then
      local q,K=Z.AbsolutePosition,Z.AbsoluteSize;
      a=q.X+K.X-8;
      P=q.Y+20;
    else
    end
    local q={};
    if G.Id then
      q[#q+1]={icon="copy",name="Copy ID",callback=function()
        pcall(setclipboard,G.Id);
      end};
    end
    if G.User then
      q[#q+1]={icon="trash-2",name="Remove",callback=function()
        d(T);
      end};
    end
    local d,G=pcall(function()
      local K=n;
      local n,S=K.Lib,{name="VisualsModelOptions",title=T,icon="shirt",x=a,y=P,follow=Z,width=194,items=q};
      S.sliders={{name="Size",min=35,max=125,value=math.floor((b.Sizes[T]or 1)*100+0.5),suffix="%",callback=function(a)
        h(T,a/100);
      end},{name="Rotate",min=0,max=360,value=b.Rotations[T]or 0,suffix="\194\176",callback=function(a)
        c(T,a);
      end}};
      n:popup(S);
    end);
    J=not d;
    if J then
      local T;
      d=e;
      d("model options: "..tostring(G));
      warn("[visuals] model options: "..tostring(G));
    end
  end
  local T;
  l=j;
  w=l.Models:AddGallery({Name="Models",Icon="shirt",Position="left",Height=320,Cell=78,Thumb="Asset",Blank="person-standing",Empty="No models yet",Values=C(),Flag="model_pick",Reset=true,Smooth=true,Callback=L,Action={Icon="ellipsis",Callback=s}});
  task.spawn(function()
    task.wait(0.2);
    local l=math.min(#D,6);
    for L=1,l,1 do
      local l;
      local l=z[4][z[6]];
      if not l then
        return;
      end
      l=N[D[L]];
      if l then
        pcall(B,l);
      end
      task.wait();
    end;
  end);
  A,s=y,Y;
  A.ClearModels=s("models",function()
    m();
    o+=1;
    b.On=false;
    Q,t,X,x=false,false,false,false;
    r+=1;
    local s=O;
    if s then
      pcall(function()
        O:Disconnect();
      end);
      O=nil;
    end
    s=W;
    if s then
      W:Disconnect();
      W=nil;
    end
    s=V;
    if s then
      V:Disconnect();
      V=nil;
    end
    v();
    f();
    H();
    for s,s in pairs(p)do
      pcall(function()
        s:Destroy();
      end);
    end;
    table.clear(p);
  end);
end
