-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #34
-- offset 3271543..3271942 (399 bytes, type=payload)

local function b(D,p,r,K,o)
  local c=C[D];
  if c then
    c:Disconnect();
    C[D]=nil;
  end
  local c,m=-(o or l[393]);
  m=(y[10][l[1119]]:Connect(function(o)
    local S=s[87]();
    if not D[l[382]] then
      m:Disconnect();
      if C[D]==m then
        C[D]=nil;
      end
      return;
    end
    c=S[l[35]][l[457]](c+o,p);
    S=c;
    if S<l[393] then
      K(l[393]);
      return;
    end
    K(r(c/p));
    o=c;
    if o>=p then
      m:Disconnect();
      if C[D]==m then
        C[D]=nil;
      end
    end
  end));
  C[D]=m;
  return m;
end
