-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #68
-- offset 128444..129438 (994 bytes, type=payload)

local function m(O,B,A,w)
  local F=O.parent;
  local h,W=F:FindFirstChildOfClass("AnimationController"),O.anims[B];
  if h and W then
    local V=h:FindFirstChildOfClass("Animator")or h;
    local h=Instance.new("Animation");
    h.AnimationId=W;
    O.undo(function()
      h:Destroy();
    end);
    local W,_=pcall(function()
      return V:LoadAnimation(h);
    end);
    if W and _ then
      if not O.alive() then
        pcall(function()
          _:Stop(0);
        end);
        return;
      end
      O.undo(function()
        pcall(function()
          _:Stop(0);
        end);
      end);
      _:Play(0);
      B=os.clock();
      repeat
        task.wait(0.1);
      until _.Length>0 or os.clock()-B>3 or not O.alive();
      if _.Length>0 then
        if w then
          _.TimePosition=Random.new(tick()):NextNumber(0,_.Length);
        end
        return;
      end
      pcall(function()
        _:Stop(0);
      end);
    end
  end
  if not A then
    return;
  end
  local B={};
  for h,h in ipairs(F:GetDescendants())do
    if h:IsA("Motor6D") then
      B[#B+1]={h,h.C0};
    end
  end;
  if #B==0 then
    return;
  end
  local F,h=w and math.random()*10 or 0;
  O.conn(J.RenderStepped:Connect(function(J)
    F+=J;
    J=CFrame.Angles(0,F*A,0);
    for O,O in ipairs(B)do
      O[1].C0=O[2]*J;
    end;
  end));
end
