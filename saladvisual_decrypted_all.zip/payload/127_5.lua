-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #5
-- offset 199542..199779 (237 bytes, type=payload)

local function h(W)
  local V=Instance.new("Beam");
  V.Attachment0=z;
  V.Attachment1=T;
  V.FaceCamera=true;
  V.LightInfluence=0;
  V.LightEmission=1;
  V.Texture=W;
  V.TextureSpeed=0;
  V.Segments=8;
  W=nil;
  W,V.Width0,V.Enabled=b,0,false;
  V.Parent=W;
  return V;
end
