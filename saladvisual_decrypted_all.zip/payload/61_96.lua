-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #96
-- offset 132035..132811 (776 bytes, type=payload)

function(W)
  if not(W:IsA("ParticleEmitter")or W:IsA("Beam")or W:IsA("Trail"))or W.Texture=="" then
    return;
  end
  local _=W.Texture;
  local X,x=pcall(p.GetAssetFetchStatus,p,_);
  if A[_]or X and(x==Enum.AssetFetchStatus.Failure or x==Enum.AssetFetchStatus.TimedOut) then
    A[_]=true;
    V(W);
  elseif X and x~=Enum.AssetFetchStatus.Success then
    local X=F[_];
    if not X then
      local x,k=setmetatable,{__mode="k"};
      X=x({},k);
      F[_]=X;
      k,x=pcall(p.GetAssetFetchStatusChangedSignal,p,_);
      if not k then
        F[_]=nil;
        return;
      end
      local p;
      p=x:Connect(function(x)
        if x==Enum.AssetFetchStatus.Success then
          p:Disconnect();
          F[_]=nil;
        elseif x==Enum.AssetFetchStatus.Failure or x==Enum.AssetFetchStatus.TimedOut then
          p:Disconnect();
          F[_]=nil;
          A[_]=true;
          for A in pairs(X)do
            V(A);
          end;
        end
      end);
      h[#h+1]=p;
    else
    end
    X[W]=true;
  end
end
