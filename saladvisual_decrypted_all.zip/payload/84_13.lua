-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #13
-- offset 3665603..3665825 (222 bytes, type=payload)

function()
  task.wait();
  if K~=l._reloadSerial then
    return;
  end
  l._reloadAnimate=nil;
  l._reloadEnabled=nil;
  if p.Parent~=D.Parent or l._emoteAnimate==p then
    return;
  end
  q(D);
  if r then
    pcall(function()
      p.Disabled=false;
    end);
  end
end
