-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #47
-- offset 3220352..3220865 (513 bytes, type=payload)

function()
  local A=J;
  local J,W=A.objects(function()
    local V,_=game,"rbxassetid://"..S;
    return V:GetObjects(_);
  end);
  if not J or type(W)~="table" then
    return;
  end
  A=nil;
  for S,S in ipairs(W)do
    if S:IsA("Sky") then
      A=S;
      break;
    end
    J=S:FindFirstChildWhichIsA("Sky",true);
    if J then
      A=J;
      break;
    end
  end;
  local S;
  J=not A or not L[4][L[6]]or G.Box~=O or m~=B;
  if J then
    for S,S in ipairs(W)do
      S:Destroy();
    end;
    return;
  end
  w();
  F();
  J=l;
  A.Name=J.RandomString();
  A.Parent=s;
  K=A;
  for J,J in ipairs(W)do
    if J~=A then
      J:Destroy();
    end
  end;
  b();
end
