-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #37
-- offset 118717..119422 (705 bytes, type=payload)

local function r(K)
  K.transforms={};
  local o,c={},{};
  for m,m in ipairs(K.worn or{})do
    o[m]=true;
    c[#c+1]=m;
    for S,S in ipairs(m:GetDescendants())do
      o[S]=true;
      c[#c+1]=S;
    end;
  end;
  for m,S in ipairs(c)do
    if S:IsA("BasePart") then
      m=S:FindFirstChildOfClass("SpecialMesh");
      local c,O;
      for B,A in ipairs(S:GetJoints())do
        if A:IsA("Weld")or A:IsA("Motor6D") then
          B=A.Part0==S and A.Part1 or A.Part0;
          if B and not o[B] then
            c,O=A,A.Part0==S;
            break;
          end
        end
      end;
      K.transforms[S]={kind="part",cframe=S.CFrame,size=S.Size,mesh=m,meshScale=m and m.Scale or nil,joint=c,first=O,c0=c and c.C0 or CFrame.new(),c1=c and c.C1 or CFrame.new()};
    elseif S:IsA("Attachment") then
      K.transforms[S]={kind="attachment",cframe=S.CFrame};
    end
  end;
end
