-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #26
-- offset 3655525..3655828 (303 bytes, type=payload)

local function Q()
  local t=O or k or os.clock()<v;
  if t then
    return;
  end
  k=true;
  task.spawn(function()
    local t,R=pcall(function()
      local g;
      local g,u=T,T;
      return g.id(u.file("particles/comet_bloom.png"));
    end);
    k=false;
    local T;
    local T=z[4][z[6]]and t;
    if T then
      O=R;
    end
    t=not O;
    if t then
      v=os.clock()+5;
    end
  end);
end
