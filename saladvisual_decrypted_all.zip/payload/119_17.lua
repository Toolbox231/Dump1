-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[119] / function #17
-- offset 3590776..3591155 (379 bytes, type=payload)

local function T()
  w();
  O();
  m();
  F();
  c=a.RenderStepped:Connect(function(a)
    local d;
    local d=not n[4][n[6]]or not P;
    if d then
      A();
      return;
    end
    local p,r=z(),b;
    b=r+(p-r)*(1-math.exp(-a*18));
    N+=a;
    r,p=os.clock(),N>=C;
    if p then
      N%=C;
      D[#D+1]={t=r,v=b};
      d=r-j;
      while#D>2 and D[2].t<d do
        table.remove(D,1);
      end;
    end
    q+=a;
    d=q>=0.016666666666666666;
    if d then
      q%=0.016666666666666666;
      W(r);
    end
  end);
end
