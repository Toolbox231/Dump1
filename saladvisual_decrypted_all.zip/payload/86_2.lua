-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #2
-- offset 3204834..3225801 (20967 bytes, type=payload)

function()
  local s=game:GetService("Lighting");
  local f,a,d,P;
  local Z,G={};
  local function G(Y,e,j)
    local C;
    local function N(q)
      local b,D=Instance.new(Y),l;
      b.Name=D.RandomString();
      b.Enabled=false;
      for Y,D in pairs(e)do
        b[Y]=D;
      end;
      if q then
        for Y in pairs(e)do
          pcall(function()
            b[Y]=q[Y];
          end);
        end;
        pcall(function()
          b.Enabled=q.Enabled;
        end);
      end
      b.Parent=s;
      return b;
    end
    C=N(nil);
    Z[#Z+1]=function()
      local Y=C.Parent~=s;
      if Y then
        C=N(C);
        j(C);
      end
    end;
    return C;
  end
  f=G("BloomEffect",{Intensity=0.6,Size=24,Threshold=0.9},function(Y)
    f=Y;
  end);
  a=G("SunRaysEffect",{Intensity=0.15,Spread=0.9},function(Y)
    a=Y;
  end);
  d=G("BlurEffect",{Size=8},function(Y)
    d=Y;
  end);
  P=G("ColorCorrectionEffect",{Brightness=0,Contrast=0.1,Saturation=0.2,TintColor=Color3.fromRGB(255,255,255)},function(Y)
    P=Y;
  end);
  task.spawn(function()
    while true do
      local Y;
      local Y=L[4][L[6]];
      if not Y then
        break;
      end
      task.wait(1);
      Y=L[4][L[6]];
      if not Y then
        break;
      end
      for Y,Y in ipairs(Z)do
        pcall(Y);
      end;
    end;
  end);
  local Z,Y,e={On=false,Density=0.3,Haze=0,Glare=0,Color=Color3.fromRGB(199,199,199),Decay=Color3.fromRGB(106,112,125)};
  local function j()
    local C=s:FindFirstChildOfClass("Atmosphere");
    local N=not C;
    if N then
      C=Instance.new("Atmosphere");
      local q=l;
      C.Name=q.RandomString();
      C.Parent=s;
      Y=C;
    else
    end
    N=not e or e.instance~=C or not C.Parent;
    if N then
      e={instance=C,Density=C.Density,Offset=C.Offset,Haze=C.Haze,Glare=C.Glare,Color=C.Color,Decay=C.Decay};
    end
    return C;
  end
  local C;
  local function C()
    local N=y;
    local q=N.Fog;
    N=q and q.On;
    local b=not(Z.On or N);
    if b then
      local D=e and e.instance and e.instance.Parent;
      if D then
        local p=e.instance;
        pcall(function()
          p.Density=e.Density;
          p.Offset=e.Offset;
          p.Haze=e.Haze;
          p.Glare=e.Glare;
          p.Color=e.Color;
          p.Decay=e.Decay;
        end);
      end
      D=Y;
      if D then
        pcall(function()
          Y:Destroy();
        end);
        Y,e=nil,nil;
      end
      return;
    end
    b=j();
    if not b then
      return;
    end
    if N then
      b.Density=math.clamp(q.Density/100,0,1);
      b.Offset=math.clamp(q.Offset or 0,-1,1);
      b.Color=q.Color;
    else
      local Y=Z.On;
      if Y then
        b.Density=math.clamp(Z.Density,0,1);
        local Y=Z.Offset or e and e.Offset;
        b.Offset=Y or 0;
        b.Color=Z.Color;
      end
    end
    q=Z.On;
    if q then
      local Y,j,q=Z.Haze,Z.Glare,y;
      local D,p=q.Sky,y;
      N,q=p.ShaderLighting and D and D.Box~="Off";
      if N then
        p=nil;
        p,q=y,D.Box~=y.PresetSky;
      else
        q=N;
      end
      if q then
        Y,j=(math.min(Y,0.35)),0;
      else
      end
      b.Haze=math.clamp(Y,0,10);
      b.Glare=math.clamp(j,0,10);
      b.Decay=Z.Decay;
    else
      local Y=e;
      if Y then
        b.Haze=e.Haze;
        b.Glare=e.Glare;
        b.Decay=e.Decay;
      end
    end
  end
  G=y;
  G.ApplyAir=C;
  G=y;
  G.Air=Z;
  local Y;
  G=z;
  G("atmosphere",function()
    Z.On=false;
    local Y=y;
    local e=Y.Fog;
    if e then
      Y=y;
      Y.Fog.On=false;
    end
    pcall(C);
  end);
  local Y,e,j=y,setmetatable,{};
  local function N(q,b)
    q=b=="bloom";
    if q then
      local q=f;
      return q;
    else
      local q=b=="rays";
      if q then
        local q=a;
        return q;
      else
        local q=b=="blur";
        if q then
          local q=d;
          return q;
        else
          local q=b=="grade";
          if q then
            local q=P;
            return q;
          end
        end
      end
    end
  end
  j.__index=N;
  Y.Shaders=e({},j);
  local q=y;
  q.ClearShaders=function()
    local q=y;
    q.ShaderLighting=nil;
    q=y;
    local b=q.RestoreFog;
    if b then
      pcall(y.RestoreFog);
    end
    b=y;
    q=b.RestoreLighting;
    if q then
      pcall(y.RestoreLighting);
    end
    b=y;
    q=b.RestoreSky;
    if q then
      pcall(y.RestoreSky);
    end
    f:Destroy();
    a:Destroy();
    d:Destroy();
    P:Destroy();
    Z.On=false;
    b=y;
    q=b.Fog;
    if q then
      b=y;
      b.Fog.On=false;
    end
    pcall(C);
  end;
  local function q(b,D,p)
    return Color3.fromRGB(b,D,p);
  end
  local b,D,p,r={Natural={bloom={on=true,intensity=0.2,size=20,threshold=1.2},rays={on=true,intensity=0.05},blur={on=false,size=0},grade={on=true,brightness=0.01,contrast=0.08,saturation=0.08,tint=q(255,253,250)},air={on=true,density=0.26,offset=0.08,haze=0.6,glare=0,color=q(198,214,232),decay=q(104,112,124)},lighting={EnvironmentDiffuseScale=1,EnvironmentSpecularScale=1,ShadowSoftness=0.2}},Competitive={bloom={on=false,intensity=0,size=18,threshold=1.3},rays={on=false,intensity=0},blur={on=false,size=0},grade={on=true,brightness=0.03,contrast=0.1,saturation=0.12,tint=q(255,255,255)},air={on=true,density=0,offset=0,haze=0,glare=0,color=q(199,199,199)},lighting={ClockTime=13,Brightness=2.2,GlobalShadows=false,ExposureCompensation=0.05,Ambient=q(135,135,138),OutdoorAmbient=q(150,150,154),FogStart=100000,FogEnd=100000}},Summer={bloom={on=true,intensity=0.3,size=22,threshold=1.15},rays={on=true,intensity=0.08},blur={on=false,size=0},grade={on=true,brightness=0.02,contrast=0.12,saturation=0.2,tint=q(255,250,240)},air={on=true,density=0.22,offset=0.1,haze=0.4,glare=0,color=q(205,222,240),decay=q(110,120,135)},lighting={ClockTime=13.5,Brightness=3,ExposureCompensation=0,GlobalShadows=true,ShadowSoftness=0.15,Ambient=q(115,112,108),OutdoorAmbient=q(140,138,132),ColorShift_Top=q(255,238,214)},sky="Sunny Sky"},["Golden Hour"]={bloom={on=true,intensity=0.5,size=26,threshold=1},rays={on=true,intensity=0.14},blur={on=false,size=0},grade={on=true,brightness=0.02,contrast=0.14,saturation=0.18,tint=q(255,230,204)},air={on=true,density=0.28,offset=0.12,haze=1.4,glare=1.2,color=q(255,202,164),decay=q(182,112,92)},lighting={ClockTime=17.6,Brightness=2.4,ExposureCompensation=0.2,GlobalShadows=true,ShadowSoftness=0.3,Ambient=q(120,100,92),OutdoorAmbient=q(150,122,108),ColorShift_Top=q(255,184,120)},sky="SettingSunSky"},["Blue Hour"]={bloom={on=true,intensity=0.45,size=26,threshold=1},rays={on=false,intensity=0},blur={on=false,size=0},grade={on=true,brightness=0.03,contrast=0.12,saturation=0.1,tint=q(232,226,255)},air={on=true,density=0.3,offset=0.1,haze=1.2,glare=0.3,color=q(150,140,192),decay=q(92,80,132)},lighting={ClockTime=18.5,Brightness=1.4,ExposureCompensation=0.35,GlobalShadows=true,Ambient=q(104,100,136),OutdoorAmbient=q(124,116,160),ColorShift_Top=q(206,158,255)},sky="sky_sunset"},Moonlight={bloom={on=true,intensity=0.45,size=24,threshold=0.95},rays={on=false,intensity=0},blur={on=false,size=0},grade={on=true,brightness=0.02,contrast=0.14,saturation=-0.1,tint=q(222,231,255)},air={on=true,density=0.2,offset=0,haze=0.3,glare=0,color=q(92,106,142),decay=q(60,70,102)},lighting={ClockTime=0,Brightness=1.2,ExposureCompensation=0.35,GlobalShadows=true,Ambient=q(84,94,122),OutdoorAmbient=q(102,114,146),ColorShift_Top=q(172,192,255)},sky="Goodnight"},Overcast={bloom={on=false,intensity=0,size=18,threshold=1.3},rays={on=false,intensity=0},blur={on=false,size=0},grade={on=true,brightness=0.01,contrast=0.05,saturation=-0.08,tint=q(242,246,255)},air={on=true,density=0.35,offset=0.05,haze=2,glare=0,color=q(196,201,209),decay=q(150,156,166)},lighting={ClockTime=12,Brightness=1.5,GlobalShadows=true,ShadowSoftness=1,Ambient=q(128,130,136),OutdoorAmbient=q(152,154,160),ColorShift_Top=q(222,226,236)},sky="Overcast"},["Misty Morning"]={bloom={on=true,intensity=0.35,size=28,threshold=1.05},rays={on=true,intensity=0.12},blur={on=false,size=0},grade={on=true,brightness=0.02,contrast=0.05,saturation=0.05,tint=q(255,244,238)},air={on=true,density=0.38,offset=0.25,haze=2.5,glare=0.5,color=q(222,214,210),decay=q(204,172,160)},lighting={ClockTime=7,Brightness=2,ExposureCompensation=0.15,GlobalShadows=true,ShadowSoftness=0.4,Ambient=q(118,112,112),OutdoorAmbient=q(146,138,138),ColorShift_Top=q(255,214,190)},sky="Pink Sunrise"},Cinematic={bloom={on=true,intensity=0.4,size=26,threshold=1},rays={on=true,intensity=0.08},blur={on=false,size=0},grade={on=true,brightness=0,contrast=0.22,saturation=0.1,tint=q(244,236,226)},air={on=true,density=0.25,offset=0.1,haze=0.8,glare=0.2,color=q(178,198,214),decay=q(112,120,134)},lighting={ExposureCompensation=0.05,Ambient=q(96,108,122),OutdoorAmbient=q(110,126,142),ColorShift_Top=q(255,226,192)}},["Neon Night"]={bloom={on=true,intensity=1,size=32,threshold=0.8},rays={on=false,intensity=0},blur={on=false,size=0},grade={on=true,brightness=0.02,contrast=0.18,saturation=0.35,tint=q(246,236,255)},air={on=true,density=0.26,offset=0.05,haze=0.6,glare=0,color=q(82,62,122),decay=q(142,62,162)},lighting={ClockTime=22,Brightness=0.8,ExposureCompensation=0.25,GlobalShadows=true,Ambient=q(68,60,98),OutdoorAmbient=q(80,68,120),ColorShift_Top=q(200,140,255)},sky="NeonSky2"}},{"Off","Natural","Competitive","Summer","Golden Hour","Blue Hour","Moonlight","Overcast","Misty Morning","Cinematic","Neon Night"},{Day="Summer",Night="Moonlight",Night2="Moonlight",Sunset="Golden Hour",Noir="Cinematic",Vibrant="Summer",Dream="Misty Morning",Horror="Overcast"},y;
  r.ShaderPresets=b;
  local function K(o)
    local c=l;
    local m=c.Lib;
    local c,S=m.quiet,m.configApplying;
    m.quiet=true;
    m.configApplying=true;
    local O,B=pcall(function()
      for A,w in pairs(o)do
        local o=m.pool[A];
        if o then
          o.set(w);
        end
      end;
    end);
    m.quiet=c;
    m.configApplying=S;
    S=not O;
    if S then
      local o;
      O=T;
      O("shader preset: "..tostring(B));
    end
  end
  local T;
  local function o(c)
    local m;
    if c then
      local S=y;
      m=S.SkyLabel;
    else
      m=c;
    end
    local S;
    if m then
      local O=y;
      S=O.SkyLabel(c);
    else
      S=m;
    end
    m=y;
    local O,B=m.Sky;
    if O then
      m=y;
      B=m.Sky.Box;
    else
      B=O;
    end
    c=B or"Off";
    m=c~="Off"and c~=T and c~=S;
    if m then
      T=nil;
      O=y;
      O.PresetSky=nil;
    elseif S then
      T=S;
      B=y;
      B.PresetSky=S;
      local m=c~=S;
      if m then
        local c=y;
        c.SetSkyBox(S);
        K({sky_box=S});
      end
    else
      local c=T;
      if c then
        T=nil;
        local T=y;
        T.PresetSky=nil;
        T=y;
        T.SetSkyBox("Off");
        K({sky_box="Off"});
      end
    end
  end
  local function T(c)
    local m=b[c];
    if not m then
      return;
    end
    c=y;
    c.ShaderLighting=m.lighting;
    c=y;
    local b=c.ApplyLighting;
    if b then
      c=y;
      c.ApplyLighting();
    end
    b=f;
    b.Enabled=m.bloom.on;
    b=f;
    b.Intensity=m.bloom.intensity;
    c=f;
    c.Size=m.bloom.size;
    b=f;
    b.Threshold=m.bloom.threshold;
    c=a;
    c.Enabled=m.rays.on;
    c=a;
    c.Intensity=m.rays.intensity;
    c=d;
    c.Enabled=m.blur.on;
    b=d;
    b.Size=m.blur.size;
    b=P;
    b.Enabled=m.grade.on;
    b=P;
    b.Brightness=m.grade.brightness;
    c=P;
    c.Contrast=m.grade.contrast;
    b=P;
    b.Saturation=m.grade.saturation;
    c=P;
    c.TintColor=m.grade.tint;
    Z.Density=m.air.density;
    Z.Haze=m.air.haze;
    Z.Color=m.air.color;
    Z.Glare=m.air.glare or 0;
    Z.Decay=m.air.decay or q(106,112,125);
    Z.Offset=m.air.offset;
    Z.On=m.air.on;
    o(m.sky);
    C();
    K({shader_bloom=m.bloom.on,shader_bloom_intensity=m.bloom.intensity*100,shader_bloom_size=m.bloom.size,shader_bloom_threshold=m.bloom.threshold*100,shader_rays=m.rays.on,shader_rays_intensity=m.rays.intensity*100,shader_blur=m.blur.on,shader_blur_size=m.blur.size,shader_grade=m.grade.on,shader_grade_brightness=m.grade.brightness*100,shader_grade_contrast=m.grade.contrast*100,shader_grade_saturation=m.grade.saturation*100,shader_grade_tint=m.grade.tint,shader_atmosphere=m.air.on,shader_atmosphere_density=m.air.density*100,shader_atmosphere_haze=m.air.haze*10,shader_atmosphere_color=m.air.color});
  end
  j=y;
  j.ApplyShaderPreset=T;
  local b;
  j=n;
  local b,c=j.Shaders:AddLabel("Preset"),{Default="Off",Values=D,Flag="shader_preset"};
  c.Callback=function(m)
    if p[m] then
      m=p[m];
      K({shader_preset=m});
    else
    end
    local p=m=="Off";
    if p then
      local p=y;
      p.ShaderLighting=nil;
      p=y;
      local S=p.ApplyLighting;
      if S then
        p=y;
        p.ApplyLighting();
      end
      K({shader_bloom=false,shader_rays=false,shader_blur=false,shader_grade=false,shader_atmosphere=false});
      f.Enabled=false;
      a.Enabled=false;
      d.Enabled=false;
      P.Enabled=false;
      Z.On=false;
      Z.Glare,Z.Decay=0,q(106,112,125);
      Z.Offset=nil;
      C();
      o(nil);
      p=y;
      S=p.ApplyGrade;
      if S then
        pcall(y.ApplyGrade);
      end
      return;
    end
    T(m);
  end;
  b:AddDropdown(c);
  local T,q,p,K={Jungle={SkyboxBk="rbxassetid://214399891",SkyboxDn="rbxassetid://214399887",SkyboxFt="rbxassetid://214399894",SkyboxLf="rbxassetid://214405668",SkyboxRt="rbxassetid://214399899",SkyboxUp="rbxassetid://214399889"},Blossom={SkyboxBk="rbxassetid://271042516",SkyboxDn="rbxassetid://271077243",SkyboxFt="rbxassetid://271042556",SkyboxLf="rbxassetid://271042310",SkyboxRt="rbxassetid://271042467",SkyboxUp="rbxassetid://271077958"},["Red Night"]={SkyboxBk="rbxassetid://401664839",SkyboxDn="rbxassetid://401664862",SkyboxFt="rbxassetid://401664960",SkyboxLf="rbxassetid://401664881",SkyboxRt="rbxassetid://401664901",SkyboxUp="rbxassetid://401664936"},Purple={SkyboxBk="rbxassetid://13694952867",SkyboxDn="rbxassetid://13694968325",SkyboxFt="rbxassetid://13694980654",SkyboxLf="rbxassetid://13694998113",SkyboxRt="rbxassetid://13695002700",SkyboxUp="rbxassetid://13695007103"}},{Galaxy=15983996673},{"Off","Jungle","Blossom","Red Night","Purple","Galaxy"},{up="SkyboxUp",dn="SkyboxDn",lf="SkyboxLf",rt="SkyboxRt",ft="SkyboxFt",bk="SkyboxBk"};
  local function o(c)
    return(tostring(c or""):gsub("[_%-]+"," "):gsub("(%l)(%u)","%1 %2"):gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$",""):gsub("(%a)([%w']*)",function(c,m)
      return c:upper()..m:lower();
    end));
  end
  local c;
  local function c(m)
    if m.__ready then
      return m.__ready;
    end
    local S,O={},pairs;
    for B,A in O(K)do
      local O=m.files[B];
      if not O then
        return nil;
      end
      B=J;
      local w=B.asset(O);
      if not w then
        return nil;
      end
      S[A]=w;
    end;
    m.__ready=S;
    return S;
  end
  b=y;
  b.ResolveSky=c;
  e=isfile and getcustomasset;
  if e then
    D,G={},J;
    for e,m in ipairs(G.under("skyboxes/"))do
      e=string.match(m,"([^/]+)$");
      b,N=string.match(e or"","^(.+)_(%a%a)%.[jp][pn]g$");
      if b and K[N] then
        D[b]=D[b]or{};
        D[b][N]=m;
      end
    end;
    r=J;
    Y,j=r.manifest;
    if Y then
      j=Y;
    else
      local G=J;
      local e=G.base~="";
      if e then
        G=J;
        j=G.load();
      else
        j=e;
      end
    end
    local G=j or nil;
    if G and type(G.skyboxes)=="table" then
      for e,b in pairs(G.skyboxes)do
        D[e]=D[e]or{};
        for m,m in ipairs(b)do
          if K[m]and not D[e][m] then
            D[e][m]="skyboxes/"..e.."_"..m..".jpg";
          end
        end;
      end;
    end
    for e in pairs(D)do
      if string.lower(e):match("cloudy")or string.lower(e):match("foggy") then
        D[e]=nil;
      end
    end;
    G={};
    for e in pairs(D)do
      G[#G+1]=e;
    end;
    table.sort(G);
    for e,b in ipairs(G)do
      e=true;
      for G in pairs(K)do
        e=if not D[b][G]then false else e;
      end;
      if e then
        local G=o(b);
        G=if T[G]or q[G]or G=="Off"then G.." (Local)"else G;
        G=if T[G]then G.." ["..b.."]"else G;
        T[G]={__sky=b,files=D[b]};
        p[#p+1]=G;
      end
    end;
  end
  table.sort(p,function(G,e)
    if G=="Off" then
      return e~="Off";
    end
    if e=="Off" then
      return false;
    end
    return G:lower()<e:lower();
  end);
  local G,e,b,K={Box="Off",Body="Default",Size=21,Stars=3000};
  local m,S,O=0,{},{"StarCount","CelestialBodiesShown","SunAngularSize","MoonAngularSize","SunTextureId","MoonTextureId"};
  local function B(A)
    if not A or S[A] then
      return;
    end
    local w={};
    for F,F in ipairs(O)do
      w[F]=A[F];
    end;
    S[A]=w;
  end
  local function O(A)
    if A and S[A] then
      for w,F in pairs(S[A])do
        pcall(function()
          A[w]=F;
        end);
      end;
    end
  end
  local function A(w)
    if w then
      S[w]=nil;
    end
  end
  local function w()
    local F=e;
    if F then
      return;
    end
    local h=s:FindFirstChildOfClass("Sky");
    F=h and h~=K;
    if F then
      local F;
      F,e=h.Parent,h;
      b=F;
      pcall(function()
        h.Parent=nil;
      end);
    end
  end
  local function F()
    local h=K;
    if h then
      A(K);
      pcall(function()
        K:Destroy();
      end);
      K=nil;
    end
  end
  local function h()
    m+=1;
    for W in pairs(S)do
      O(W);
    end;
    table.clear(S);
    F();
    local W=e;
    if W then
      pcall(function()
        e.Parent=b or s;
      end);
      e,b=nil,nil;
    end
  end
  local e;
  local function b()
    local W=K or s:FindFirstChildOfClass("Sky");
    local V=not W and G.Body~="Default";
    if V then
      W=Instance.new("Sky");
      local _=l;
      W.Name=_.RandomString();
      W.Parent=s;
      e=W;
    else
    end
    if not W then
      return;
    end
    V=e and W==e and G.Body=="Default";
    if V then
      A(e);
      pcall(function()
        e:Destroy();
      end);
      e=nil;
      return;
    end
    B(W);
    O(W);
    W.StarCount=G.Stars;
    if G.Body=="Default" then
      W.CelestialBodiesShown=true;
      return;
    end
    W.CelestialBodiesShown=G.Body~="None";
    if G.Body=="Sun" then
      W.SunAngularSize=G.Size;
      W.MoonAngularSize=0;
    elseif G.Body=="Moon" then
      W.SunAngularSize=0;
      W.MoonAngularSize=G.Size;
    elseif G.Body=="Eclipse" then
      W.SunTextureId="rbxasset://sky/moon.jpg";
      W.SunAngularSize=G.Size;
      W.MoonAngularSize=0;
    else
      W.SunAngularSize=0;
      W.MoonAngularSize=0;
    end
  end
  N=z;
  N("celestial",function()
    local z=e;
    if z then
      A(e);
      pcall(function()
        e:Destroy();
      end);
      e=nil;
    end
    for z in pairs(S)do
      O(z);
    end;
    table.clear(S);
  end);
  local function z(e)
    w();
    F();
    local S,O=Instance.new("Sky"),l;
    S.Name=O.RandomString();
    for O,B in pairs(e)do
      pcall(function()
        S[O]=B;
      end);
    end;
    S.Parent=s;
    K=S;
    b();
  end
  local function e(S)
    local O,B=G.Box,m;
    task.spawn(function()
      local A=J;
      local J,W=A.objects(function()
        local V,_=game,"rbxassetid://"..S;
        return V:GetObjects(_);
      end);
      if not J or type(W)~="table" then
        return;
      end
      A=nil;
      for S,S in ipairs(W)do
        if S:IsA("Sky") then
          A=S;
          break;
        end
        J=S:FindFirstChildWhichIsA("Sky",true);
        if J then
          A=J;
          break;
        end
      end;
      local S;
      J=not A or not L[4][L[6]]or G.Box~=O or m~=B;
      if J then
        for S,S in ipairs(W)do
          S:Destroy();
        end;
        return;
      end
      w();
      F();
      J=l;
      A.Name=J.RandomString();
      A.Parent=s;
      K=A;
      for J,J in ipairs(W)do
        if J~=A then
          J:Destroy();
        end
      end;
      b();
    end);
  end
  local function J()
    m+=1;
    pcall(C);
    local K=y;
    local S=K.ApplyLighting;
    if S then
      pcall(y.ApplyLighting);
    end
    if G.Box=="Off" then
      h();
      return;
    end
    K=T[G.Box];
    if K then
      local K=T[G.Box];
      S=K.files;
      if S then
        local S,O=G.Box,m;
        task.spawn(function()
          local B=c(K);
          local c;
          local c=B and L[4][L[6]]and O==m and G.Box==S;
          if c then
            z(B);
          end
        end);
      else
        z(K);
      end
    elseif q[G.Box] then
      e(q[G.Box]);
    end
  end
  Y=y;
  Y.Sky=G;
  j=y;
  j.RestoreSky=h;
  local z=y;
  z.SkyLabel=function(z)
    for e,q in pairs(T)do
      if type(q)=="table"and q.__sky==z then
        return e;
      end
    end;
  end;
  local z=y;
  z.SetSkyBox=function(z)
    G.Box=z;
    J();
  end;
  j=n;
  j.Shaders:AddLabel("Skybox"):AddDropdown({Default="Off",Values=p,Flag="sky_box",Callback=function(z)
    G.Box=z;
    J();
  end});
  D=n;
  o=D.Shaders:AddLabel("Sun / Moon");
  o:AddDropdown({Default="Default",Values={"Default","Sun","Moon","Eclipse","None"},Flag="sky_body",Callback=function(z)
    G.Body=z;
    b();
  end});
  D=o:AddOption(1);
  D:AddLabel("Size"):AddSlider({Min=0,Max=60,Default=21,Rounding=0,Size=90,Flag="sky_size",Callback=function(z)
    G.Size=z;
    b();
  end});
  D:AddLabel("Stars"):AddSlider({Min=0,Max=12000,Default=3000,Rounding=0,Size=90,Flag="sky_stars",Callback=function(z)
    G.Stars=z;
    b();
  end});
  local z,T={On=false,Color=Color3.fromRGB(192,192,192),Density=35,Offset=0},y;
  T.Fog=z;
  local J=y;
  J.ApplyFog=function()
    C();
  end;
  local J=y;
  J.RestoreFog=function()
    z.On=false;
    C();
  end;
  local J,G,e=0,l;
  D=H;
  G:AddSignal(D.Heartbeat:Connect(function(l)
    J+=l;
    local H;
    l=J<1 or not L[4][L[6]];
    if l then
      return;
    end
    J=0;
    if not(z.On or Z.On) then
      return;
    end
    l=s:FindFirstChildOfClass("Atmosphere");
    if not l then
      C();
      return;
    end
    local s=z.On and math.clamp(z.Density/100,0,1)or Z.Density;
    if math.abs(l.Density-s)>0.01 then
      C();
    end
  end));
  T=n;
  o=T.Shaders:AddLabel("Fog");
  o:AddToggle({Default=false,Flag="fog",Callback=function(s)
    z.On=s;
    C();
  end});
  o:AddColorPicker({Default=z.Color,Flag="fog_color",Callback=function(s)
    z.Color=s;
    C();
  end});
  G=o:AddOption(1);
  G:AddLabel("Density"):AddSlider({Min=0,Max=100,Default=35,Rounding=0,Size=90,Flag="fog_density",Callback=function(s)
    z.Density=s;
    C();
  end});
  G:AddLabel("Height"):AddSlider({Min=-100,Max=100,Default=0,Rounding=0,Size=90,Flag="fog_offset",Callback=function(s)
    z.Offset=s/100;
    C();
  end});
  j=n;
  p=j.Shaders:AddLabel("Bloom");
  p:AddToggle({Default=false,Flag="shader_bloom",Callback=function(s)
    f.Enabled=s;
  end});
  o=p:AddOption(1);
  local s,l=o:AddLabel("Intensity"),{Min=0,Max=200,Default=60,Rounding=0,Size=90,Flag="shader_bloom_intensity"};
  l.Callback=function(L)
    local z=f;
    z.Intensity=L/100;
  end;
  s:AddSlider(l);
  local l,L=o:AddLabel("Size"),{Min=1,Max=56,Default=24,Rounding=0,Size=90,Flag="shader_bloom_size"};
  L.Callback=function(z)
    f.Size=z;
  end;
  l:AddSlider(L);
  local L,z=o:AddLabel("Threshold"),{Min=0,Max=200,Default=90,Rounding=0,Size=90,Flag="shader_bloom_threshold"};
  z.Callback=function(J)
    local H=f;
    H.Threshold=J/100;
  end;
  L:AddSlider(z);
  s=n;
  p=s.Shaders:AddLabel("Sun Rays");
  p:AddToggle({Default=false,Flag="shader_rays",Callback=function(s)
    a.Enabled=s;
  end});
  local s,L=p:AddOption(1):AddLabel("Intensity"),{Min=0,Max=100,Default=15,Rounding=0,Size=90,Flag="shader_rays_intensity"};
  L.Callback=function(z)
    local J=a;
    J.Intensity=z/100;
  end;
  s:AddSlider(L);
  r=n;
  T=r.Shaders:AddLabel("Blur");
  T:AddToggle({Default=false,Flag="shader_blur",Callback=function(L)
    d.Enabled=L;
  end});
  T:AddSlider({Min=1,Max=40,Default=8,Rounding=0,Size=90,Flag="shader_blur_size",Callback=function(L)
    d.Size=L;
  end});
  local L={On=false,Tint=Color3.fromRGB(255,255,255),Saturation=0.2,Contrast=0.1,Brightness=0};
  local function z()
    local T=P;
    T.Enabled=L.On;
    T=P;
    T.TintColor=L.Tint;
    T=P;
    T.Saturation=L.Saturation;
    T=P;
    T.Contrast=L.Contrast;
    T=P;
    T.Brightness=L.Brightness;
  end
  p=y;
  p.ApplyGrade=z;
  l=n;
  s=l.Shaders:AddLabel("Color Grade");
  s:AddToggle({Default=false,Flag="shader_grade",Callback=function(l)
    L.On=l;
    z();
  end});
  s:AddColorPicker({Default=Color3.fromRGB(255,255,255),Flag="shader_grade_tint",Callback=function(l)
    L.Tint=l;
    z();
  end});
  Y=s:AddOption(1);
  Y:AddLabel("Saturation"):AddSlider({Min=-100,Max=200,Default=20,Rounding=0,Size=90,Flag="shader_grade_saturation",Callback=function(s)
    L.Saturation=s/100;
    z();
  end});
  Y:AddLabel("Contrast"):AddSlider({Min=-100,Max=200,Default=10,Rounding=0,Size=90,Flag="shader_grade_contrast",Callback=function(s)
    L.Contrast=s/100;
    z();
  end});
  Y:AddLabel("Brightness"):AddSlider({Min=-100,Max=100,Default=0,Rounding=0,Size=90,Flag="shader_grade_brightness",Callback=function(s)
    L.Brightness=s/100;
    z();
  end});
  o=n;
  j=o.Shaders:AddLabel("Atmosphere");
  j:AddToggle({Default=false,Flag="shader_atmosphere",Callback=function(s)
    Z.On=s;
    C();
  end});
  j:AddColorPicker({Default=Color3.fromRGB(199,199,199),Flag="shader_atmosphere_color",Callback=function(s)
    Z.Color=s;
    C();
  end});
  N=j:AddOption(1);
  N:AddLabel("Density"):AddSlider({Min=0,Max=100,Default=30,Rounding=0,Size=90,Flag="shader_atmosphere_density",Callback=function(s)
    Z.Density=s/100;
    C();
  end});
  N:AddLabel("Haze"):AddSlider({Min=0,Max=100,Default=0,Rounding=0,Size=90,Flag="shader_atmosphere_haze",Callback=function(s)
    Z.Haze=s/10;
    C();
  end});
end
