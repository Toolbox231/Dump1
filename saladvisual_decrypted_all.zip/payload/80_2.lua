-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #2
-- offset 3258631..3583172 (324541 bytes, type=payload)

function(...)
  local function L(...)
    local y={};
    y[33]={};
    y[34]=(s[87]());
    s:MT(y[33],0,y[34]);
    s:vT(y[33],1,s[70](...));
    y[1],y[2]=y[33][1],y[33][2];
    y[35]={};
    y[36]=l[542];
    s:MT(y[35],0,y[1][y[36]]);
    y[35].n=1;
    y[3]=y[35][1];
    y[37]={};
    y[38]=l[534];
    s:MT(y[37],0,y[1][y[38]]);
    y[37].n=1;
    y[4]=y[37][1];
    y[39]={};
    y[40]=l[1471];
    s:MT(y[39],0,y[1][y[40]]);
    y[39].n=1;
    y[5]=y[39][1];
    y[41]={};
    y[42]=l[188];
    y[43]=y[1][y[42]]or function(z)
      return z;
    end;
    s:MT(y[41],0,y[43]);
    y[41].n=1;
    y[6]=y[41][1];
    y[44]=l[188];
    y[1][y[44]]=y[6];
    y[45]=l[638];
    y[47]=y[1][y[45]];
    if not y[47] then
      y[46]=l[1536]--[[Instance]];
      y[47]=y[1][y[46]];
    end
    y[6]=y[47];
    y[48]=l[638];
    y[1][y[48]]=y[6];
    y[49]=l[553];
    y[51]=y[1][y[49]];
    if not y[51] then
      y[50]=l[1269];
      y[51]=y[1][y[50]];
    end
    y[6]=y[51];
    y[52]=l[553];
    y[1][y[52]]=y[6];
    y[53]=l[1469];
    y[55]=y[1][y[53]];
    if not y[55] then
      y[54]=l[1251];
      y[55]=y[1][y[54]];
    end
    y[6]=y[55];
    y[56]=l[1469];
    y[1][y[56]]=y[6];
    do
      y[57]=l[638];
      y[59]=y[1][y[57]];
      if not y[59] then
        y[58]=l[1536]--[[Instance]];
        y[59]=y[1][y[58]];
      end
      local z=y[59];
      local function T()
        local n=s[87]();
        if n[l[40]](z)==l[1712] then
          local J,H=n[l[1146]](z);
          if J and n[l[1703]](H)==l[1089] then
            return H;
          end
        end
      end
      y[60]=l[638];
      y[1][y[60]]=T;
      y[61]=l[1536]--[[Instance]];
      y[1][y[61]]=T;
    end;
    y[62]={};
    y[63]=l[188];
    y[65]=y[1][y[63]];
    y[64]=l[1458];
    s:vT(y[62],0,s[70](y[65](y[1][y[64]]:GetService(l[298]))));
    y[7]=y[62][1];
    y[66]={};
    y[67]=l[188];
    y[69]=y[1][y[67]];
    y[68]=l[1458];
    s:vT(y[66],0,s[70](y[69](y[1][y[68]]:GetService(l[965]))));
    y[8]=y[66][1];
    y[70]={};
    y[71]=l[188];
    y[73]=y[1][y[71]];
    y[72]=l[1458];
    s:vT(y[70],0,s[70](y[73](y[1][y[72]]:GetService(l[1]))));
    y[9]=y[70][1];
    y[74]={};
    y[75]=l[188];
    y[77]=y[1][y[75]];
    y[76]=l[1458];
    s:vT(y[74],0,s[70](y[77](y[1][y[76]]:GetService(l[1351]))));
    y[10]=y[74][1];
    y[78]={};
    y[79]=l[188];
    y[81]=y[1][y[79]];
    y[80]=l[1458];
    y[82]=(y[81](y[1][y[80]]:GetService(l[793])));
    s:MT(y[78],0,y[82]);
    y[83]=l[188];
    y[85]=y[1][y[83]];
    y[84]=l[1458];
    s:vT(y[78],1,s[70](y[85](y[1][y[84]]:GetService(l[1408]--[[nparams]]))));
    y[11],y[12]=y[78][1],y[78][2];
    y[86]={};
    y[87]=l[1232];
    s:MT(y[86],0,y[11][y[87]]);
    y[86].n=1;
    y[13]=y[86][1];
    y[13]:GetMouse();
    y[88]={};
    y[89]=l[302];
    y[91]=y[1][y[89]];
    if not y[91] then
      y[90]=l[144];
      y[91]=y[1][y[90]];
    end
    y[95]=y[91];
    if not y[95] then
      y[92]=l[784];
      y[94]=y[1][y[92]];
      if y[94] then
        y[93]=l[784];
        y[94]=y[1][y[93]][l[1255]];
      end
      y[95]=y[94];
    end
    s:MT(y[88],0,y[95]);
    y[88].n=1;
    y[14]=y[88][1];
    y[96]={};
    y[97]=l[5];
    y[99]=y[1][y[97]];
    if not y[99] then
      y[98]=l[1490];
      y[99]=y[1][y[98]];
    end
    y[103]=y[99];
    if not y[103] then
      y[100]=l[784];
      y[102]=y[1][y[100]];
      if y[102] then
        y[101]=l[784];
        y[102]=y[1][y[101]][l[506]];
      end
      y[103]=y[102];
    end
    s:MT(y[96],0,y[103]);
    y[96].n=1;
    y[15]=y[96][1];
    y[104]={};
    y[105]=l[638];
    y[107]=y[1][y[105]];
    if y[107] then
      y[106]=l[638];
      y[107]=y[1][y[106]]();
    end
    s:MT(y[104],0,y[107]);
    y[104].n=1;
    y[16]=y[104][1];
    if not y[16] then
      y[108]=l[1146];
      y[109]=s[70](y[1][y[108]](function()
        local z=s[87]();
        local T,n,J=z[l[188]],z[l[1458]],l[244];
        return T(n:GetService(J));
      end));
      y[11]=y[109][1];
      y[6]=y[109][2];
      y[16]=y[11]and y[6]or nil;
    else
    end
    y[111]=y[16];
    if not y[111] then
      y[110]=l[753];
      y[111]=y[13]:WaitForChild(y[110]);
    end
    y[16]=y[111];
    y[112]={};
    y[113]=l[1667];
    y[115]=y[1][y[113]];
    if not y[115] then
      y[114]=l[776];
      y[115]=y[1][y[114]];
    end
    y[119]=y[115];
    if not y[119] then
      y[116]=l[904];
      y[118]=y[1][y[116]];
      if y[118] then
        y[117]=l[904];
        y[118]=y[1][y[117]][l[1667]];
      end
      y[119]=y[118];
    end
    y[120]=y[119]or function(z)
      return z;
    end;
    s:MT(y[112],0,y[120]);
    y[121]={[l[1318]]=l[1714],[l[769]]={},[l[673]]={}};
    s:MT(y[112],1,y[121]);
    y[112].n=2;
    y[17],y[18]=y[112][1],y[112][2];
    y[122]={};
    y[123]=l[1469];
    s:MT(y[122],0,y[1][y[123]]()[l[1340]]);
    y[122].n=1;
    y[19]=y[122][1];
    y[124]=l[40];
    if y[1][y[124]](y[19])~=l[1346] then
      y[19]={};
      y[125]=l[1469];
      y[126]=y[1][y[125]]();
      y[127]=l[1340];
      y[126][y[127]]=y[19];
    else
    end
    y[128]=l[493];
    y[18][y[128]]=y[19];
    y[20]=function(z)
      local T=s[87]();
      for n=#y[19],l[229],l[715]do
        if y[19][n]==z then
          T[l[1346]][l[1357]](y[19],n);
        end
      end;
    end;
    y[21]=function(z)
      local T={};
      local n=s[87]();
      for J=#y[19],l[229],l[715]do
        local H=y[19][J];
        if H==z or n[l[1703]](H)~=l[1089]or not H[l[382]] then
          n[l[1346]][l[1357]](y[19],J);
        end
      end;
      T[1]=y[19];
      T[2]=#y[19]+l[229];
      T[1][T[2]]=z;
    end;
    y[129]=l[170];
    y[130]=l[265];
    y[18][y[129]]=y[130];
    y[131]={};
    y[132]=l[1214];
    s:MT(y[131],0,y[9][y[132]]);
    y[133]=l[928];
    s:MT(y[131],1,y[9][y[133]]);
    y[134]=l[1136];
    s:MT(y[131],2,y[9][y[134]]);
    y[135]=l[964];
    s:MT(y[131],3,y[1][y[135]][l[227]]);
    y[131].n=4;
    y[22],y[23],y[24],y[25]=y[131][1],y[131][2],y[131][3],y[131][4];
    y[136]={};
    y[138]=y[25];
    if y[138] then
      y[137]=l[952];
      y[138]=y[25][y[137]];
    end
    y[140]=y[138];
    if not y[140] then
      y[139]=l[1689];
      y[140]=y[1][y[139]][l[772]](l[1248],l[1704]);
    end
    s:MT(y[136],0,y[140],l[1329]);
    y[136].n=2;
    y[26],y[27]=y[136][1],y[136][2];
    y[141]=l[1146];
    y[1][y[141]](function()
      local z={};
      local T=s[87]();
      z[1]=y[9][l[58]]==T[l[128]][l[58]][l[239]];
      y[27]=z[1];
    end);
    y[142]={};
    s:MT(y[142],0,l[1329]);
    y[142].n=1;
    y[28]=y[142][1];
    y[143]=l[1146];
    y[1][y[143]](function()
      local z={};
      local T=s[87]();
      z[1]=T[l[1469]]()[l[1189]]==l[383];
      y[28]=z[1];
    end);
    y[6]=l[388];
    y[151]=y[28];
    if not y[151] then
      y[150]=y[22];
      if y[150] then
        y[149]=y[27]or not y[24];
        if not y[149] then
          y[144]=l[35];
          y[146]=y[1][y[144]][l[457]];
          y[145]=l[1437];
          y[148]=y[26][y[145]];
          y[147]=l[636];
          y[149]=y[146](y[148],y[26][y[147]])<l[843];
        end
        y[150]=y[149];
      end
      y[151]=y[150];
    end
    y[11]=y[151];
    y[18][y[6]]=y[11];
    y[152]=l[1581];
    y[153]=l[388];
    y[154]=y[18][y[153]]and l[731]or l[229];
    y[18][y[152]]=y[154];
    y[155]={};
    y[156]=l[1581];
    s:MT(y[155],0,y[18][y[156]]);
    y[155].n=1;
    y[29]=y[155][1];
    y[157]=l[131];
    y[158]={};
    y[160]=l[641];
    y[159]=l[360];
    y[158][y[160]]=y[1][y[159]][l[353]](l[1158],l[1158],l[930]);
    y[162]=l[1132];
    y[161]=l[360];
    y[158][y[162]]=y[1][y[161]][l[353]](l[310],l[310],l[973]);
    y[164]=l[675];
    y[163]=l[360];
    y[158][y[164]]=y[1][y[163]][l[353]](l[1307],l[1307],l[558]);
    y[166]=l[1466];
    y[165]=l[360];
    y[158][y[166]]=y[1][y[165]][l[353]](l[973],l[973],l[352]);
    y[168]=l[966];
    y[167]=l[360];
    y[158][y[168]]=y[1][y[167]][l[353]](l[430],l[430],l[1167]);
    y[170]=l[1529]--[[cancel]];
    y[169]=l[360];
    y[158][y[170]]=y[1][y[169]][l[353]](l[1179],l[896],l[1413]);
    y[172]=l[1095];
    y[171]=l[360];
    y[158][y[172]]=y[1][y[171]][l[353]](l[1475],l[1475],l[1486]);
    y[174]=l[1379];
    y[173]=l[360];
    y[158][y[174]]=y[1][y[173]][l[353]](l[1339],l[1339],l[544]);
    y[176]=l[98];
    y[175]=l[360];
    y[158][y[176]]=y[1][y[175]][l[353]](l[1682],l[1682],l[1682]);
    y[177]=y[158];
    y[18][y[157]]=y[177];
    y[178]=l[567]--[[info]];
    y[179]={[l[1338]]=l[389],[l[514]]=l[36],[l[1633]]=l[738],[l[1715]]=l[982],[l[1591]]=l[1314],[l[1547]]=l[1487],[l[637]]=l[476],[l[349]]=l[1563],[l[1319]]=l[1131],[l[763]]=l[1421],[l[1545]]=l[576],[l[1411]]=l[327],[l[606]--[[readu16]]]=l[1086],[l[515]]=l[359],[l[1231]]=l[653],[l[234]]=l[334],[l[967]]=l[1079],[l[1587]]=l[340],[l[565]]=l[1531]--[[defer]],[l[1549]]=l[1706],[l[1137]]=l[554],[l[180]]=l[981]--[[defer]],[l[1015]]=l[1579],[l[1643]]=l[1533]--[[wait]],[l[1153]]=l[937],[l[443]]=l[1565],[l[1004]]=l[666],[l[1159]]=l[1124],[l[1456]]=l[1068],[l[591]]=l[202],[l[975]]=l[69],[l[1177]]=l[779],[l[672]]=l[337],[l[1732]]=l[650],[l[1517]]=l[1097],[l[90]]=l[684],[l[600]]=l[1278],[l[462]]=l[1687],[l[1605]]=l[1297],[l[118]]=l[181],[l[1010]]=l[1482],[l[175]]=l[970],[l[1190]]=l[1078],[l[1736]]=l[594],[l[531]]=l[949],[l[230]]=l[282],[l[1680]]=l[1370],[l[903]]=l[76],[l[473]]=l[1618],[l[1206]]=l[1734],[l[45]]=l[42],[l[619]]=l[909],[l[1623]]=l[1539],[l[669]]=l[872],[l[1399]]=l[1465],[l[1447]]=l[507],[l[908]]=l[232],[l[503]]=l[1603],[l[1020]]=l[490],[l[478]]=l[719],[l[453]]=l[682],[l[931]]=l[1522]--[[h]],[l[607]]=l[508],[l[1268]]=l[716],[l[787]]=l[770],[l[1169]]=l[1041],[l[1165]]=l[92],[l[317]]=l[1588],[l[961]]=l[448],[l[4]]=l[853],[l[1457]]=l[840],[l[1203]]=l[312],[l[240]]=l[274],[l[1607]]=l[1511],[l[683]]=l[555],[l[1369]]=l[212],[l[976]]=l[177],[l[1276]]=l[1076],[l[1716]]=l[87],[l[1719]]=l[486],[l[1059]]=l[1163],[l[1695]]=l[585],[l[697]]=l[942],[l[746]]=l[1051],[l[257]]=l[1060],[l[915]]=l[283],[l[1499]]=l[1215],[l[905]]=l[1093],[l[703]]=l[376],[l[566]]=l[1065],[l[792]]=l[495],[l[1178]]=l[96],[l[1349]]=l[821],[l[396]]=l[1313],[l[1256]]=l[727],[l[68]]=l[609],[l[898]]=l[1512],[l[370]]=l[1083]};
    y[18][y[178]]=y[179];
    y[30]=function(z)
      local T=s[87]();
      if T[l[40]](z)==l[384] then
        return l[1440]..z;
      end
      if T[l[40]](z)~=l[409]or z==l[1746] then
        return l[1746];
      end
      if T[l[409]][l[23]](z,l[54],l[229],l[383]) then
        return z;
      end
      if T[l[409]][l[56]](z,l[1576]) then
        return l[1440]..z;
      end
      local n=y[18][l[567]--[[info]]][T[l[409]][l[345]](z)];
      return n and l[1440]..n or l[1746];
    end;
    y[180]={};
    y[181]={[l[584]]=l[744],[l[442]]=l[318]--[[C]],[l[985]]=l[1303],[l[1108]]=l[25],[l[137]]=l[1720],[l[939]]=l[1443],[l[714]]=l[276],[l[791]]=l[1566],[l[1246]]=l[1527],[l[835]]=l[760]};
    s:MT(y[180],0,y[181]);
    y[180].n=1;
    y[31]=y[180][1];
    y[182]={};
    y[183]={[l[1548]--[[2443976510]]]=l[270],[l[1306]]=l[1252],[l[1494]]=l[943],[l[1383]]=l[441],[l[1238]]=l[735],[l[782]]=l[193],[l[213]]=l[53],[l[1454]]=l[200],[l[439]]=l[459],[l[1445]]=l[71],[l[902]]=l[944],[l[33]]=l[416],[l[237]]=l[385],[l[1750]]=l[1460],[l[184]]=l[251],[l[1666]]=l[867],[l[1739]]=l[1546],[l[1183]]=l[579],[l[1550]--[[3962277859]]]=l[1500],[l[866]]=l[1310],[l[828]]=l[1723],[l[990]]=l[1343],[l[358]]=l[718],[l[325]]=l[241],[l[858]]=l[532],[l[163]]=l[365],[l[1045]]=l[1621],[l[190]]=l[1593],[l[857]]=l[20],[l[1145]]=l[1299],[l[1036]]=l[313],[l[785]]=l[471],[l[605]]=l[31]};
    s:MT(y[182],0,y[183]);
    y[182].n=1;
    y[32]=y[182][1];
    local function z(T)
      local n=s[87]();
      if n[l[1703]](T)~=l[802] then
        return l[31];
      end
      local J=T[l[1150]];
      if y[32][J] then
        return y[32][J];
      end
      T=n[l[409]][l[56]](J,l[712]);
      if T then
        return l[1745]..T;
      end
      return J;
    end
    y[184]=l[1725];
    local T=y[1][y[184]][l[772]](l[820]);
    y[185]=l[1725];
    y[187]=y[1][y[185]][l[772]];
    y[188]=l[849];
    y[186]=l[128];
    y[190]=y[1][y[186]][l[1353]][l[816]];
    y[189]=l[128];
    local n=y[187](y[188],y[190],y[1][y[189]][l[848]--[[readu8]]][l[100]]);
    y[191]=l[1725];
    y[193]=y[1][y[191]][l[772]];
    y[194]=l[263];
    y[192]=l[128];
    y[196]=y[1][y[192]][l[1353]][l[816]];
    y[195]=l[128];
    local J=y[193](y[194],y[196],y[1][y[195]][l[848]--[[readu8]]][l[100]]);
    y[197]=l[1725];
    y[199]=y[1][y[197]][l[772]];
    y[200]=l[832];
    y[198]=l[128];
    y[202]=y[1][y[198]][l[1353]][l[1502]];
    y[201]=l[128];
    local H=y[199](y[200],y[202],y[1][y[201]][l[848]--[[readu8]]][l[100]]);
    local function f()
      local a=s[87]();
      local d=a[l[1346]][l[803]](l[310]);
      for P=l[229],l[310],l[229]do
        d[P]=a[l[409]][l[189]](a[l[35]][l[1298]](l[95],l[1339]));
      end;
      return a[l[1346]][l[978]](d);
    end
    local function a(d,P,Z)
      local G=s[87]();
      local Y=G[l[1089]][l[772]](d);
      if d==l[1058] then
        Y:SetAttribute(l[1472],l[383]);
      end
      if d==l[1742]or d==l[192] then
        Y[l[1247]]=l[1329];
        Y[l[38]]=l[1329];
      end
      for d,G in y[3],P,nil do
        Y[d]=G;
      end;
      if Z then
        Y[l[382]]=Z;
      end
      return Y;
    end
    local function d(P,Z)
      local G=s[87]();
      if #y[18][l[673]]>l[633] then
        for Y=#y[18][l[673]],l[229],l[715]do
          if not y[18][l[673]][Y][l[49]] then
            G[l[1346]][l[1357]](y[18][l[673]],Y);
          end
        end;
      end
      local Y=P:Connect(Z);
      G[l[1346]][l[968]](y[18][l[673]],Y);
      return Y;
    end
    local function P(Z,G,Y)
      local e=y[7]:Create(Z,G,Y);
      e:Play();
      return e;
    end
    local function Z(G)
      if y[29]~=l[229] then
        local Y=a;
        local e=l[238];
        local j={};
        j[l[1609]]=y[29];
        Y(e,j,G);
      end
      return G;
    end
    local G={l[1016],l[948],l[1639],l[537]};
    local function Y(e)
      local j=s[87]();
      local C=j[l[1089]][l[772]](l[211]);
      C[l[1150]]=f();
      C[l[1418]]=l[393];
      C[l[656]]=e[l[656]];
      C[l[711]]=e[l[711]];
      C[l[1324]]=l[1329];
      for j,j in y[3],G,nil do
        C[j]=e[j];
      end;
      local j,N=e:GetChildren();
      for q,b in y[3],j,N do
        q=l[1112];
        if b:IsA(q) then
          b:Clone()[l[382]]=C;
        end
      end;
      C[l[382]]=e[l[382]];
      local j,N=l[1329];
      local function q(b)
        return b:IsA(l[957])and b[l[1324]];
      end
      local function b()
        local D=j or e[l[1569]]>l[984]or not e[l[382]];
        if D then
          return;
        end
        j=l[383];
        N={[l[641]]=e[l[1646]],[l[897]]=e[l[43]],[l[63]]=e[l[711]]};
        C[l[1535]]=e[l[1535]];
        local p,r=l[1646],N;
        C[p]=r[l[641]];
        p,r=l[43],N;
        C[p]=r[l[897]];
        r,p=l[711],N;
        C[r]=p[l[63]];
        p,D=e:GetChildren();
        for r,r in y[3],p,D do
          if q(r) then
            r[l[382]]=C;
          end
        end;
        e[l[1646]]=l[229];
        e[l[43]]=l[1329];
        D,p=l[711],N;
        e[D]=p[l[63]]+l[229];
        C[l[1324]]=e[l[1324]];
      end
      local function D()
        local p=j;
        if not p then
          return;
        end
        j=l[1329];
        local r,K=C:GetChildren();
        for o,o in y[3],r,K do
          if not o:IsA(l[1112]) then
            o[l[382]]=e;
          end
        end;
        p,K=l[1646],N;
        e[p]=K[l[641]];
        p,r=l[43],N;
        e[p]=r[l[897]];
        r,p=l[711],N;
        e[r]=p[l[63]];
        C[l[1324]]=l[1329];
      end
      d(e:GetPropertyChangedSignal(l[1569]),function()
        if e[l[1569]]>l[984] then
          D();
        else
          b();
        end
      end);
      d(e:GetPropertyChangedSignal(l[1324]),function()
        C[l[1324]]=j and e[l[1324]];
      end);
      for N,N in y[3],G,nil do
        d(e:GetPropertyChangedSignal(N),function()
          C[N]=e[N];
        end);
      end;
      d(e[l[74]],function(G)
        local N,D=s[87](),j;
        if D then
          N[l[1022]][l[1061]](function()
            local N=j and G[l[382]]==e and q(G);
            if N then
              G[l[382]]=C;
            end
          end);
        end
      end);
      d(e[l[956]],function()
        C:Destroy();
      end);
      b();
      return C;
    end
    local function G(e)
      return e[l[81]]/y[29];
    end
    local function e(j)
      return j[l[160]]/y[29];
    end
    local function j(C)
      return C[l[996]]/y[29];
    end
    y[203]=l[1488];
    y[11]=y[1][y[203]];
    y[25]={[l[277]]=l[1540]};
    local C=y[11]({},y[25]);
    y[204]=l[1488];
    y[24]=y[1][y[204]];
    y[26]={};
    y[205]=l[277];
    y[206]=l[1540];
    y[26][y[205]]=y[206];
    y[24]({},y[26]);
    local function N(q)
      return l[229]-(l[229]-q)^l[303];
    end
    local function q(b)
      return b*b;
    end
    local function b(D,p,r,K,o)
      local c=C[D];
      if c then
        c:Disconnect();
        C[D]=nil;
      end
      local c,m=-(o or l[393]);
      m=(y[10][l[1119]]:Connect(function(o)
        local S=s[87]();
        if not D[l[382]] then
          m:Disconnect();
          if C[D]==m then
            C[D]=nil;
          end
          return;
        end
        c=S[l[35]][l[457]](c+o,p);
        S=c;
        if S<l[393] then
          K(l[393]);
          return;
        end
        K(r(c/p));
        o=c;
        if o>=p then
          m:Disconnect();
          if C[D]==m then
            C[D]=nil;
          end
        end
      end));
      C[D]=m;
      return m;
    end
    local function D(p,r)
      local K=s[87]();
      return a(l[1112],{[l[1182]]=K[l[740]][l[772]](l[393],r)},p);
    end
    local function p(r)
      local K=s[87]();
      return K[l[409]][l[846]](l[145],K[l[35]][l[499]](r[l[126]]*l[1682]+l[659]),K[l[35]][l[499]](r[l[1192]]*l[1682]+l[659]),K[l[35]][l[499]](r[l[1378]]*l[1682]+l[659]));
    end
    local function r(K)
      local o=s[87]();
      if o[l[40]](K)~=l[409] then
        return nil;
      end
      local c=o[l[409]][l[1710]](K,l[16],l[1746]);
      c=if#c==l[863]then o[l[409]][l[1710]](c,l[564],l[236])else c;
      if #c~=l[1158] then
        return nil;
      end
      K=o[l[1382]](c,l[829]);
      if not K then
        return nil;
      end
      return o[l[360]][l[353]](o[l[35]][l[499]](K/l[546])%l[598],o[l[35]][l[499]](K/l[598])%l[598],K%l[598]);
    end
    local function K(o,c,m)
      local S=s[87]();
      return a(l[1622],{[l[500]]=c,[l[747]]=S[l[1197]][l[772]](m)},o);
    end
    y[207]={};
    y[208]=l[135];
    y[209]=(y[1][y[208]][l[772]](l[229],l[229],l[229]));
    s:MT(y[207],0,y[209]);
    y[210]=l[135];
    y[211]=(y[1][y[210]][l[772]](l[229],l[229],l[715]));
    s:MT(y[207],1,y[211]);
    y[212]=l[135];
    y[213]=(y[1][y[212]][l[772]](l[229],l[715],l[229]));
    s:MT(y[207],2,y[213]);
    y[214]=l[135];
    y[215]=(y[1][y[214]][l[772]](l[229],l[715],l[715]));
    s:MT(y[207],3,y[215]);
    y[216]=l[135];
    y[217]=(y[1][y[216]][l[772]](l[715],l[229],l[229]));
    s:MT(y[207],4,y[217]);
    y[218]=l[135];
    y[219]=(y[1][y[218]][l[772]](l[715],l[229],l[715]));
    s:MT(y[207],5,y[219]);
    y[220]=l[135];
    y[221]=(y[1][y[220]][l[772]](l[715],l[715],l[229]));
    s:MT(y[207],6,y[221]);
    y[222]=l[135];
    s:MT(y[207],7,y[1][y[222]][l[772]](l[715],l[715],l[715]));
    local o=y[207];
    local c=l[1329];
    local function m(S)
      local O={};
      local B,A=s[87](),c;
      if A then
        return nil;
      end
      local w=l[1329];
      local F,h=l[1329];
      B[l[1022]][l[281]](function()
        local W=s[87]();
        local V,_=W[l[1146]](S);
        W=not F;
        if W then
          h=V and _ or nil;
          w=l[383];
        end
      end);
      A=B[l[655]][l[1587]]()+l[1525];
      while true do
        local S=not w and y[18][l[630]]~=l[1329];
        if not(S and B[l[655]][l[1587]]()<A) then
          break;
        end
        B[l[1022]][l[153]](l[182]);
      end;
      A=not w or y[18][l[630]]==l[1329];
      if A then
        F=l[383];
        B=not w and y[18][l[630]]~=l[1329];
        if B then
          c=l[383];
          O[1]=y[18];
          O[2]=l[1032];
          O[3]=l[847];
          O[1][O[2]]=O[3];
        end
        return nil;
      end
      return h;
    end
    local function c(S)
      local O=s[87]();
      local B=O[l[40]](y[2])==l[1346]and y[2][l[584]]or O[l[1469]]()[l[482]];
      if O[l[40]](B)~=l[1712]or O[l[40]](S)~=l[409]or S==l[1746] then
        return nil;
      end
      local A=m(function()
        return B(S);
      end);
      if O[l[40]](A)==l[409]and A~=l[1746] then
        return A;
      end
    end
    local function m(S)
      local O=s[87]();
      local B=O[l[40]](y[2])==l[1346]and y[2][l[142]]or O[l[1469]]()[l[428]];
      if O[l[40]](B)~=l[1712] then
        return{};
      end
      local A,w=O[l[1146]](B,S);
      if A and O[l[40]](w)==l[1346] then
        return w;
      end
      return{};
    end
    local S=l[393];
    local function O(B)
      local A=s[87]();
      S=A[l[35]][l[850]](S+B,l[393]);
    end
    local function B(A,w)
      local F;
      local h,W=l[756],function()
        local V=s[87]();
        if not(if A and A[l[1317]]==V[l[128]][l[1317]][l[239]]then A[l[1101]]==V[l[128]][l[1101]][l[115]]or A[l[1101]]==V[l[128]][l[1101]][l[890]]else y[9]:IsMouseButtonPressed(V[l[128]][l[1317]][l[1356]])) then
          F:Disconnect();
          w();
        end
      end;
      F=(y[10][h]:Connect(W));
      return F;
    end
    do
      local A={};
      local w=l[393];
      y[224]=d;
      y[223]=l[1558];
      y[224](y[9][y[223]],function(F)
        local h=s[87]();
        if F[l[1317]]==h[l[128]][l[1317]][l[239]] then
          A[F]=l[383];
        end
      end);
      local function F()
        local h=s[87]();
        for W in y[3],A,nil do
          if W[l[1101]]==h[l[128]][l[1101]][l[115]]or W[l[1101]]==h[l[128]][l[1101]][l[890]] then
            return l[383];
          end
          A[W]=nil;
        end;
        local A=h[l[128]][l[1317]][l[1356]];
        return y[9]:IsMouseButtonPressed(A);
      end
      y[226]=d;
      y[225]=l[756];
      y[226](y[10][y[225]],function(A)
        local h=S;
        local W=h>l[393]and not F()and not y[9]:GetFocusedTextBox();
        if W then
          w+=A;
          h=w;
          local A=h>l[330];
          if A then
            S=l[393];
            w=l[393];
          end
        else
          w=l[393];
        end
      end);
    end;
    local A,w,F;
    local function h()
      local W=s[87]();
      local V,_=W[l[1146]](function()
        return y[12]:GetGuiInset();
      end);
      if V and W[l[1703]](_)==l[1689] then
        return _;
      end
      return W[l[1689]][l[1729]];
    end
    local function W(V,_)
      if not V or not V[l[382]]or not V[l[1324]] then
        return l[1329];
      end
      local X=V[l[160]];
      if X[l[1437]]<=l[393]or X[l[636]]<=l[393] then
        return l[1329];
      end
      local x=V[l[81]]+h();
      _=_ or l[393];
      V=(y[9]:GetMouseLocation());
      return V[l[1437]]>=x[l[1437]]-_ and V[l[1437]]<=x[l[1437]]+X[l[1437]]+_ and V[l[636]]>=x[l[636]]-_ and V[l[636]]<=x[l[636]]+X[l[636]]+_;
    end
    local function V()
      local _=A;
      if not _ then
        return;
      end
      A,w=nil,nil;
      _();
    end
    y[228]=d;
    y[227]=l[1558];
    y[228](y[9][y[227]],function(_,X)
      local x,k=s[87](),not A or X;
      if k then
        return;
      end
      X=S;
      if X>l[393] then
        return;
      end
      if F and F() then
        return;
      end
      k=w and W(w,l[59]);
      if k then
        return;
      end
      if _[l[1317]]==x[l[128]][l[1317]][l[1356]]or _[l[1317]]==x[l[128]][l[1317]][l[239]] then
        V();
      end
    end);
    local function _(X,x,k)
      local v=s[87]();
      local I=v[l[1725]][l[772]](k or l[243],v[l[128]][l[1353]][l[816]],v[l[128]][l[848]--[[readu8]]][l[100]]);
      local k,v,i,E=l[1329];
      d(X[l[1558]],function(X)
        local Q=s[87]();
        if X[l[1317]]~=Q[l[128]][l[1317]][l[1356]]and X[l[1317]]~=Q[l[128]][l[1317]][l[239]] then
          return;
        end
        local t,R=X[l[948]],x[l[948]];
        Q[l[1022]][l[153]]();
        local g=S;
        if g>l[393]or X[l[1101]]==Q[l[128]][l[1101]][l[912]] then
          return;
        end
        k,v,i=l[383],t,R;
        E=X[l[1317]]==Q[l[128]][l[1317]][l[239]]and X or nil;
        local Q;
        Q=X[l[1551]]:Connect(function()
          local t=s[87]();
          local R=X[l[1101]]==t[l[128]][l[1101]][l[912]];
          if R then
            k=l[1329];
            Q:Disconnect();
          end
        end);
      end);
      d(y[9][l[412]],function(X)
        local Q,t=s[87](),E;
        if t then
          local t=X==E;
          if t then
            k=l[1329];
          end
        else
          local t=X[l[1317]]==Q[l[128]][l[1317]][l[1356]];
          if t then
            k=l[1329];
          end
        end
      end);
      d(y[9][l[233]],function(X)
        local Q,t,R=s[87](),not k;
        if t then
          R=t;
        else
          local k=S;
          R=k>l[393];
        end
        if R then
          return;
        end
        t=E;
        if t then
          R=E;
          if X~=R then
            return;
          end
        elseif X[l[1317]]~=Q[l[128]][l[1317]][l[765]] then
          return;
        end
        local k,g,u=X[l[948]]-v,Q[l[1459]][l[772]],i;
        R,t,X=u[l[1437]][l[1609]],Q[l[35]][l[499]],i;
        local v,U=t(X[l[1437]][l[1485]]+k[l[1437]]),i;
        t,X,u=U[l[636]][l[1609]],Q[l[35]][l[499]],i;
        local i,Q=g(R,v,t,X(u[l[636]][l[1485]]+k[l[636]])),E;
        if Q then
          x[l[948]]=i;
        else
          P(x,I,{[l[948]]=i});
        end
      end);
    end
    local function X(x,k)
      x=x or{};
      for v,I in y[3],k,nil do
        if x[v]==nil then
          x[v]=I;
        end
      end;
      return x;
    end
    y[229]=l[560];
    y[230]=l[1746];
    y[18][y[229]]=y[230];
    do
      y[231]=l[1469];
      local x=y[1][y[231]]()[l[670]];
      y[232]=l[40];
      y[234]=y[1][y[232]](x)==l[1346]and x~=y[18];
      if y[234] then
        y[233]=l[1703];
        y[234]=y[1][y[233]](x[l[278]])==l[1089];
      end
      if y[234]and x[l[278]][l[382]] then
        y[235]=l[1146];
        y[1][y[235]](x[l[332]],x);
        y[236]=l[1146];
        y[1][y[236]](function()
          x[l[278]]:Destroy();
        end);
      end
    end;
    y[240]=a;
    y[241]=l[122];
    y[237]={};
    y[237][l[1150]]=f();
    y[237][l[1126]]=l[383];
    y[237][l[926]]=l[1329];
    y[239]=l[1448];
    y[238]=l[128];
    y[237][y[239]]=y[1][y[238]][l[1448]][l[1323]];
    y[237][l[1552]]=l[1261];
    local x=y[240](y[241],y[237]);
    y[242]=l[1146];
    y[1][y[242]](y[17],x);
    y[243]=l[1146];
    if not y[1][y[243]](function()local k={};k[1]=x;k[2]=l[382];k[3]=y[16];k[1][k[2]]=k[3];end)or not x[l[382]] then
      y[244]=l[1146];
      y[1][y[244]](function()
        local k={};
        k[1]=x;
        k[2]=l[382];
        k[3]=(y[13]:WaitForChild(l[753]));
        k[1][k[2]]=k[3];
      end);
    end
    local function k(v)
      local I=s[87]();
      local i,E=I[l[1146]](I[l[1089]][l[772]],v);
      if i then
        E:Destroy();
      end
      return i;
    end
    local function v(I)
      local i=s[87]();
      if I and I[l[1317]]==i[l[128]][l[1317]][l[239]] then
        return i[l[1689]][l[772]](I[l[948]][l[1437]],I[l[948]][l[636]]);
      end
      return y[9]:GetMouseLocation()-y[12]:GetGuiInset();
    end
    local function I(i,...)
      local E=s[87]();
      if not y[18][l[630]]or E[l[40]](i)~=l[1712] then
        return;
      end
      if y[18][l[921]] then
        return i(...);
      end
      local Q=E[l[1346]][l[235]](...);
      local t=y[18][l[1478]];
      E[l[1022]][l[281]](function()
        local E=s[87]();
        if y[18][l[630]]and t==y[18][l[1478]] then
          local t,R=E[l[1146]](i,E[l[1346]][l[1433]](Q,l[229],Q[l[668]]));
          if not t then
            E[l[972]](l[1048]..E[l[1130]](R));
          end
        end
      end);
    end
    y[245]=l[278];
    y[18][y[245]]=x;
    do
      local i,E={},{};
      local Q=l[710];
      y[17]=l[394];
      y[246]=l[394];
      y[247]=y[18][y[246]];
      y[26]=y[247];
      y[6]=nil;
      if y[26] then
        y[6]=y[26];
      else
        y[248]=l[1488];
        y[24]=y[1][y[248]];
        y[11]={[l[277]]=l[1540]};
        y[6]=(y[24]({},y[11]));
      end
      y[18][y[17]]=y[6];
      local function t(R)
        local g=s[87]();
        return g[l[35]][l[850]](R[l[1311]][l[636]]-R[l[464]][l[636]],l[393]);
      end
      local function R(g,u)
        local U,M=g[l[81]],g[l[160]];
        return u[l[1437]]>=U[l[1437]]and u[l[636]]>=U[l[636]]and u[l[1437]]<=U[l[1437]]+M[l[1437]]and u[l[636]]<=U[l[636]]+M[l[636]];
      end
      local function g(u,U)
        local M,sP,lP=u,l[393],l[393];
        while M and M~=x do
          sP=if y[18][l[394]][M]then l[1261]else sP;
          local LP=l[957];
          if M:IsA(LP) then
            if not M[l[1324]] then
              return nil;
            end
            if (M==u or M[l[656]])and not R(M,U) then
              return nil;
            end
          end
          lP+=l[229];
          M=M[l[382]];
        end;
        return M==x and lP+sP or nil;
      end
      local function u(U)
        if i[U]or y[18][l[388]]or not U[l[382]] then
          return;
        end
        local M={[l[504]]=U[l[1690]][l[636]],[l[717]]=U[l[1690]][l[636]],[l[77]]=U[l[1195]],[l[1018]]=l[393]};
        i[U]=M;
        local function sP()
          if U[l[1195]] then
            M[l[1018]]+=l[229];
            U[l[1195]]=l[1329];
          end
        end
        sP();
        local lP,LP,yP,zP=l[1271],{},l[1195],function()
          if M[l[1018]]>l[393] then
            M[l[1018]]-=l[229];
            return;
          end
          M[l[77]]=U[l[1195]];
          sP();
        end;
        s:MT(LP,0,U:GetPropertyChangedSignal(yP):Connect(zP));
        M[lP]=LP;
        M[l[1271]][l[863]]=U[l[648]]:Connect(function()
          local sP=s[87]();
          if not U:IsDescendantOf(sP[l[1458]]) then
            for sP,sP in y[3],M[l[1271]],nil do
              sP:Disconnect();
            end;
            i[U]=nil;
            E[U]=nil;
          end
        end);
      end
      y[249]=l[1678];
      y[18][y[249]]=u;
      y[251]=d;
      y[250]=l[233];
      y[251](y[9][y[250]],function(U)
        local M=s[87]();
        if U[l[1317]]~=M[l[128]][l[1317]][l[72]]or not y[18][l[583]] then
          return;
        end
        local sP,lP,LP=v(),-U[l[948]][l[989]],{};
        for yP,zP in y[3],i,nil do
          if zP[l[77]] then
            U=g(yP,sP);
            if U then
              LP[#LP+l[229]]={[l[796]]=yP,[l[335]]=U};
            end
          end
        end;
        M[l[1346]][l[933]](LP,function(g,yP)
          return g[l[335]]>yP[l[335]];
        end);
        U=l[1329];
        for g in y[3],y[18][l[394]],nil do
          if g[l[1324]]and g[l[382]]and R(g,sP) then
            U=l[383];
            break;
          end
        end;
        for R,g in y[3],LP,nil do
          if U and g[l[335]]<l[1261] then
            return;
          end
          sP=t(g[l[796]]);
          if sP>l[229] then
            R=i[g[l[796]]];
            if not R[l[261]] then
              local i=g[l[796]][l[1690]][l[636]];
              R[l[504]],R[l[717]]=i,i;
            end
            local i=M[l[35]][l[819]](R[l[717]]+lP*Q,l[393],sP);
            if i~=R[l[717]] then
              R[l[717]]=i;
              R[l[261]]=l[383];
              E[g[l[796]]]=R;
            end
            return;
          end
        end;
      end);
      y[253]=d;
      y[252]=l[1119];
      y[253](y[10][y[252]],function(i)
        local Q=s[87]();
        if not y[18][l[583]] then
          for R,g in y[3],E,nil do
            g[l[261]]=l[1329];
            E[R]=nil;
          end;
          return;
        end
        if not y[3](E) then
          return;
        end
        local R=l[229]-Q[l[35]][l[9]](-i*l[1655]);
        for g,U in y[3],E,nil do
          i=g[l[1690]][l[636]];
          if Q[l[35]][l[1575]](i-U[l[504]])>l[1525] then
            U[l[504]]=i;
          end
          U[l[717]]=Q[l[35]][l[819]](U[l[717]],l[393],t(g));
          local i=U[l[504]]+(U[l[717]]-U[l[504]])*R;
          if Q[l[35]][l[1575]](U[l[717]]-i)<l[659] then
            i=U[l[717]];
            U[l[261]]=l[1329];
            E[g]=nil;
          else
          end
          U[l[504]]=i;
          g[l[1690]]=Q[l[1689]][l[772]](g[l[1690]][l[1437]],i);
        end;
      end);
      d(x[l[328]],function(i)
        local E,Q=s[87](),l[1439];
        if i:IsA(Q) then
          E[l[1022]][l[1061]](u,i);
        end
      end);
    end;
    local i={};
    local E=l[393];
    y[254]=l[1488];
    y[11]=y[1][y[254]];
    y[25]={[l[277]]=l[1540]};
    local Q=y[11]({},y[25]);
    d(x[l[328]],function(t)
      local R,g=s[87](),(t:IsA(l[957])or t:IsA(l[734])or t:IsA(l[1198]))and not Q[t];
      if g then
        Q[t]=l[383];
        R[l[1346]][l[968]](i,t);
        R=E;
        E=R+l[229];
        R=E;
        local t=R>=l[329];
        if t then
          E=l[393];
          R=l[393];
          for E=l[229],#i,l[229]do
            local t=i[E];
            if t[l[382]] then
              R+=l[229];
              i[R]=t;
            else
              Q[t]=nil;
            end
          end;
          for E=#i,R+l[229],l[715]do
            i[E]=nil;
          end;
        end
      end
    end);
    y[255]=l[1029];
    y[256]={};
    y[18][y[255]]=y[256];
    local function E(t,R)
      local g={};
      local u,U=s[87](),{};
      t=l[1329];
      for M,sP in y[3],R,nil do
        local lP=y[18][l[131]][M];
        if u[l[1703]](sP)==l[360]and u[l[1703]](lP)==l[360]and sP:ToHex()~=lP:ToHex() then
          U[lP:ToHex()]=sP;
          t=l[383];
        else
        end
      end;
      for M,sP in y[3],R,nil do
        if u[l[1703]](sP)==l[360]and u[l[1703]](y[18][l[131]][M])==l[360] then
          g[1]=y[18][l[131]];
          g[1][M]=sP;
        end
      end;
      if not t then
        return;
      end
      local function M(sP)
        if sP:IsA(l[734])or sP:IsA(l[1198]) then
          local lP=U[sP[l[1630]]:ToHex()];
          if lP then
            sP[l[1630]]=lP;
          end
        else
          local lP=l[957];
          if sP:IsA(lP) then
            local lP=U[sP[l[1535]]:ToHex()];
            if lP then
              sP[l[1535]]=lP;
            end
            if sP:IsA(l[1070])or sP:IsA(l[192])or sP:IsA(l[1400]--[[-1]]) then
              lP=U[sP[l[510]]:ToHex()];
              if lP then
                sP[l[510]]=lP;
              end
            elseif sP:IsA(l[859])or sP:IsA(l[1742]) then
              lP=U[sP[l[936]]:ToHex()];
              if lP then
                sP[l[936]]=lP;
              end
            end
          end
        end
      end
      for U=#i,l[229],l[715]do
        R=i[U];
        if not R[l[382]] then
          u[l[1346]][l[1357]](i,U);
          Q[R]=nil;
        else
          M(R);
        end
      end;
      for i in y[3],y[18][l[1029]],nil do
        if i[l[382]] then
          t,R=i:GetDescendants();
          for Q,Q in y[3],t,R do
            M(Q);
          end;
        else
          g[2]=y[18][l[1029]];
          g[2][i]=nil;
        end
      end;
    end
    y[257]=l[1225];
    y[18][y[257]]=E;
    local function i(E,E,Q)
      y[18]:retheme({[E]=Q});
    end
    y[258]=l[1341];
    y[18][y[258]]=i;
    local i={{l[1380],nil},{l[112],l[1688]},{l[1152],l[1672]},{l[362],l[362]},{l[525],l[525]},{l[1495],l[878]},{l[154],l[862]},{l[223],l[223]},{l[1285],l[1442]},{l[496],l[496]},{l[1580],l[1580]},{l[1128],l[1128]},{l[1342],l[1342]}};
    y[259]={};
    y[260]=l[128];
    y[262]=y[1][y[260]][l[437]][l[1350]];
    y[261]=l[128];
    y[259][y[262]]=y[1][y[261]][l[1444]][l[1042]];
    y[263]=l[128];
    y[265]=y[1][y[263]][l[437]][l[1381]];
    y[264]=l[128];
    y[259][y[265]]=y[1][y[264]][l[1444]][l[1518]];
    y[266]=l[128];
    y[268]=y[1][y[266]][l[437]][l[1701]];
    y[267]=l[128];
    y[259][y[268]]=y[1][y[267]][l[1444]][l[206]];
    y[269]=l[128];
    y[271]=y[1][y[269]][l[437]][l[807]];
    y[270]=l[128];
    y[259][y[271]]=y[1][y[270]][l[1444]][l[1121]];
    y[272]=l[128];
    y[274]=y[1][y[272]][l[437]][l[1188]];
    y[273]=l[128];
    y[259][y[274]]=y[1][y[273]][l[1444]][l[809]];
    local E=y[259];
    y[275]=l[1146];
    y[1][y[275]](function()
      local Q=s[87]();
      E[Q[l[128]][l[437]][l[1111]]]=Q[l[128]][l[1444]][l[1518]];
      E[Q[l[128]][l[437]][l[169]]]=Q[l[128]][l[1444]][l[1121]];
      E[Q[l[128]][l[437]][l[1672]]]=Q[l[128]][l[1444]][l[809]];
    end);
    local Q;
    y[276]=l[1488];
    y[22]=y[1][y[276]];
    y[17]={[l[277]]=l[1540]};
    local t=y[22]({},y[17]);
    y[277]=l[1407];
    y[278]=l[1380];
    y[18][y[277]]=y[278];
    local function R(g)
      local g,u=s[87](),{};
      for U,U in y[5](i)do
        if not U[l[59]]or g[l[1146]](function()local g=s[87]();return g[l[437]][l[466]](g[l[128]][l[437]][U[l[59]]]);end) then
          u[#u+l[229]]=U[l[229]];
        end
      end;
      return u;
    end
    y[279]=l[664];
    y[18][y[279]]=R;
    local function g(u)
      local U=s[87]();
      if not(u:IsA(l[1070])or u:IsA(l[192])or u:IsA(l[1400]--[[-1]])) then
        return;
      end
      local M=t[u];
      if M==nil then
        M=u[l[437]];
        t[u]=M;
      else
      end
      local t=E[M];
      if not t then
        return;
      end
      local E=Q;
      if E then
        u[l[526]]=U[l[437]][l[772]](Q,t);
      elseif u[l[437]]~=M then
        u[l[437]]=M;
      end
    end
    y[280]=l[556];
    y[18][y[280]]=g;
    local function E(t,u)
      local U={};
      local M=s[87]();
      t=nil;
      for sP,sP in y[5](i)do
        if sP[l[229]]==u and sP[l[59]] then
          local i,lP=M[l[1146]](function()
            local LP=s[87]();
            return LP[l[437]][l[466]](LP[l[128]][l[437]][sP[l[59]]]);
          end);
          t=i and lP[l[458]]or nil;
        else
        end
      end;
      local i=Q;
      if t==i then
        return;
      end
      Q=t;
      U[1]=y[18];
      U[2]=l[1407];
      U[3]=t and u or l[1380];
      U[1][U[2]]=U[3];
      M[l[1022]][l[281]](function()
        local i,t=s[87](),{x};
        for u in y[3],y[18][l[1029]],nil do
          if u[l[382]] then
            t[#t+l[229]]=u;
          end
        end;
        local u=l[393];
        for U,U in y[5](t)do
          local t,M=U:GetDescendants();
          for U,U in y[3],t,M do
            i[l[1146]](g,U);
            u+=l[229];
            if u%l[1651]==l[393] then
              i[l[1022]][l[153]]();
            end
          end;
        end;
      end);
    end
    y[281]=l[1038];
    y[18][y[281]]=E;
    d(x[l[328]],function(i)
      local t,u=s[87](),Q and(i:IsA(l[1070])or i:IsA(l[192])or i:IsA(l[1400]--[[-1]]));
      if u then
        t[l[1022]][l[1061]](function()
          local Q=s[87]();
          Q[l[1146]](g,i);
        end);
      end
    end);
    y[282]=l[354];
    y[283]=l[1184];
    y[18][y[282]]=y[283];
    y[284]=l[1294];
    y[285]={};
    y[18][y[284]]=y[285];
    y[286]=l[752];
    y[287]={};
    y[18][y[286]]=y[287];
    y[288]=l[630];
    y[289]=l[383];
    y[18][y[288]]=y[289];
    local i,Q=l[1417],{};
    for t=l[229],l[1167],l[229]do
      y[290]=l[409];
      y[291]=y[1][y[290]][l[1724]](i,t,t);
      y[292]=t-l[229];
      Q[y[291]]=y[292];
    end;
    local t=l[1258];
    local function g(u)
      local U=s[87]();
      local M=U[l[1346]][l[803]](#u);
      for sP=l[229],#u,l[229]do
        local lP=(U[l[409]][l[377]](t,(sP-l[229])%#t+l[229])+sP*l[1596]--[[__newindex]]+l[322]--[[[C] ]])%l[598];
        M[sP]=U[l[409]][l[189]](U[l[1187]][l[623]](U[l[409]][l[377]](u,sP),lP));
      end;
      return U[l[1346]][l[978]](M);
    end
    local function t(u)
      local U,M,sP=s[87](),{},l[229];
      while sP<=#u do
        local lP,LP,yP=U[l[409]][l[377]](u,sP),U[l[409]][l[377]](u,sP+l[229]),U[l[409]][l[377]](u,sP+l[59]);
        local u=lP*l[546]+(LP or l[393])*l[598]+(yP or l[393]);
        lP={U[l[35]][l[499]](u/l[250])%l[1167],U[l[35]][l[499]](u/l[329])%l[1167],U[l[35]][l[499]](u/l[1167])%l[1167],u%l[1167]};
        M[#M+l[229]]=U[l[409]][l[1724]](i,lP[l[229]]+l[229],lP[l[229]]+l[229]);
        M[#M+l[229]]=U[l[409]][l[1724]](i,lP[l[59]]+l[229],lP[l[59]]+l[229]);
        M[#M+l[229]]=LP and U[l[409]][l[1724]](i,lP[l[863]]+l[229],lP[l[863]]+l[229])or l[313];
        M[#M+l[229]]=yP and U[l[409]][l[1724]](i,lP[l[786]]+l[229],lP[l[786]]+l[229])or l[313];
        sP+=l[863];
      end;
      return U[l[1346]][l[978]](M);
    end
    local function i(u)
      local U=s[87]();
      u=U[l[409]][l[1710]](u,l[475],l[1746]);
      local M,sP={},l[229];
      while sP<#u do
        local lP,LP=l[393],l[393];
        for yP=l[393],l[863],l[229]do
          local zP=U[l[409]][l[1724]](u,sP+yP,sP+yP);
          if zP==l[313]or zP==l[1746] then
            lP,LP=lP*l[1167],LP+l[229];
          else
            lP=lP*l[1167]+(Q[zP]or l[393]);
          end
        end;
        M[#M+l[229]]=U[l[409]][l[189]](U[l[35]][l[499]](lP/l[546])%l[598]);
        if LP<l[59] then
          M[#M+l[229]]=U[l[409]][l[189]](U[l[35]][l[499]](lP/l[598])%l[598]);
        end
        if LP<l[229] then
          M[#M+l[229]]=U[l[409]][l[189]](lP%l[598]);
        end
        sP+=l[786];
      end;
      return U[l[1346]][l[978]](M);
    end
    local function Q(u)
      local U=s[87]();
      return(U[l[409]][l[1710]](U[l[1130]](u),l[706],function(u)
        local U=s[87]();
        return U[l[409]][l[846]](l[159],U[l[409]][l[377]](u));
      end));
    end
    local function u(U)
      local M=s[87]();
      return(M[l[409]][l[1710]](U,l[1135],function(U)
        local M=s[87]();
        return M[l[409]][l[189]](M[l[1382]](U,l[829]));
      end));
    end
    local function U(M,...)
      local sP=s[87]();
      if sP[l[40]](M)~=l[1712] then
        return nil;
      end
      local lP,LP=sP[l[1146]](M,...);
      if lP then
        return LP;
      end
      if y[18][l[921]] then
        sP[l[279]](LP,l[393]);
      end
      sP[l[972]](l[1006]..sP[l[1130]](LP));
    end
    local function M()
      local sP=s[87]();
      if sP[l[40]](sP[l[215]])~=l[1712]or sP[l[40]](sP[l[1528]])~=l[1712] then
        return l[1329];
      end
      local lP=l[1746];
      for LP in sP[l[409]][l[78]](sP[l[409]][l[1710]](y[18][l[354]],l[365],l[532]),l[1360])do
        lP=lP==l[1746]and LP or lP..l[532]..LP;
        if not U(sP[l[215]],lP) then
          U(sP[l[1528]],lP);
        end
        if not U(sP[l[215]],lP) then
          return l[1329];
        end
      end;
      return lP~=l[1746];
    end
    local function sP(lP)
      local LP=s[87]();
      if LP[l[40]](lP)~=l[409] then
        return nil;
      end
      lP=LP[l[409]][l[56]](lP,l[381])or l[1746];
      lP=LP[l[409]][l[1710]](lP,l[1236],l[1746]);
      if #lP==l[393]or#lP>l[633]or lP==l[241]or lP==l[1056]or lP:find(l[129])or lP:match(l[767]) then
        return nil;
      end
      return lP;
    end
    local function lP(LP)
      return y[18][l[354]]..l[532]..LP..l[1133];
    end
    local function LP(yP,zP,TP,nP,JP,HP)
      local fP={};
      yP=s[87]();
      if yP[l[40]](zP)~=l[409]or zP==l[1746] then
        return;
      end
      if not y[18][l[1294]][zP] then
        yP[l[1346]][l[968]](y[18][l[752]],zP);
      end
      fP[1]=y[18][l[1294]];
      fP[2]={[l[415]]=TP,[l[506]]=nP,[l[1255]]=JP,[l[260]]=HP};
      fP[1][zP]=fP[2];
    end
    y[293]=l[1047];
    y[18][y[293]]=LP;
    local function LP(yP,zP)
      local TP={};
      yP=s[87]();
      if yP[l[40]](zP)~=l[409]or not y[18][l[1294]][zP] then
        return;
      end
      TP[1]=y[18][l[1294]];
      TP[1][zP]=nil;
      local TP=yP[l[1346]][l[23]](y[18][l[752]],zP);
      if TP then
        yP[l[1346]][l[1357]](y[18][l[752]],TP);
      end
    end
    y[294]=l[168];
    y[18][y[294]]=LP;
    local function yP(zP)
      local TP,nP=s[87](),{};
      for JP,HP in y[3],y[18][l[752]],nil do
        JP=y[18][l[1294]][HP];
        if JP and not(zP[l[1207]]and zP[l[1207]][HP]) then
          local zP=U(JP[l[506]]);
          local fP;
          if TP[l[1703]](zP)==l[360] then
            fP=l[1073];
            zP=(p(zP));
          else
            if TP[l[40]](zP)==l[268] then
              fP=l[1118];
              zP=zP and l[1337]or l[121];
            else
              if TP[l[40]](zP)==l[384]and zP==zP and TP[l[35]][l[1575]](zP)<l[94] then
                fP=l[668];
                zP=TP[l[1130]](zP);
              else
                if TP[l[40]](zP)==l[409] then
                  fP=l[900];
                else
                  if zP==nil and JP[l[415]]==l[230] then
                    fP=l[900];
                    zP=l[605];
                  else
                  end
                end
              end
            end
          end
          if fP then
            nP[#nP+l[229]]=l[1327]..Q(HP)..l[214]..fP..l[214]..Q(zP);
          end
        end
      end;
      for zP,JP in y[3],y[18][l[131]],nil do
        if TP[l[1703]](JP)==l[360] then
          nP[#nP+l[229]]=l[1659]..Q(zP)..l[481]..p(JP);
        end
      end;
      return l[249]..t(g(TP[l[1346]][l[978]](nP,l[222])));
    end
    y[295]=l[806];
    y[18][y[295]]=yP;
    local function Q(t,zP)
      t=s[87]();
      if t[l[40]](zP)~=l[409]or#zP>l[39] then
        return nil;
      end
      zP=t[l[409]][l[1710]](zP,l[1113],l[1746]);
      zP=t[l[409]][l[56]](zP,l[381])or l[1746];
      if t[l[409]][l[1724]](zP,l[229],l[786])~=l[249] then
        return nil;
      end
      local TP=t[l[409]][l[1710]](t[l[409]][l[1724]](zP,l[303]),l[1446],l[1746]);
      if TP:find(l[1050])or#TP%l[786]~=l[393]or not TP:match(l[1721]) then
        return nil;
      end
      local zP,nP,JP=g(i(TP)),{},{};
      for i in t[l[409]][l[78]](zP,l[639])do
        local g,zP,TP,HP=t[l[409]][l[56]](i,l[44]);
        if (g==l[347]or g==l[1395])and(TP==l[1118]or TP==l[668]or TP==l[900]or TP==l[1073]) then
          zP,HP=u(zP),u(HP);
          if TP==l[1118] then
            if HP~=l[1337]and HP~=l[121] then
              return nil;
            end
            HP=HP==l[1337];
          else
            if TP==l[668] then
              HP=t[l[1382]](HP);
              if not HP or HP~=HP or t[l[35]][l[1575]](HP)==l[94] then
                return nil;
              end
            else
              if TP==l[1073]and not r(HP) then
                return nil;
              end
            end
          end
          if HP~=nil then
            if g==l[347] then
              nP[zP]=HP;
            elseif g==l[1395] then
              JP[zP]=HP;
            end
          end
        else
          return nil;
        end
      end;
      return{[l[516]]=nP,[l[131]]=JP};
    end
    y[296]=l[324];
    y[18][y[296]]=Q;
    local function i(Q)
      local t={};
      local g=s[87]();
      if g[l[40]](y[14])~=l[1712] then
        return l[1329],l[1063];
      end
      local u,zP=g[l[1146]](Q[l[806]],Q);
      if not u or g[l[40]](zP)~=l[409]or zP==l[1746] then
        return l[1329],l[1302];
      end
      t[1]=s[70](g[l[1146]](y[14],zP));
      u=t[1][1];
      Q=t[1][2];
      if not u then
        return l[1329],g[l[1130]](Q);
      end
      return l[383],#zP;
    end
    y[297]=l[1534];
    y[18][y[297]]=i;
    local function i(Q)
      local t=s[87]();
      if t[l[40]](y[15])~=l[1712] then
        return l[1329],l[1696];
      end
      local g,u=t[l[1146]](y[15]);
      if not g or t[l[40]](u)~=l[409]or u==l[1746] then
        return l[1329],l[1030];
      end
      local g,zP=t[l[1146]](Q[l[324]],Q,u);
      if not g or t[l[40]](zP)~=l[1346] then
        return l[1329],l[446];
      end
      Q[l[1583]]=u;
      Q[l[518]]=zP;
      return l[383];
    end
    y[298]=l[1354];
    y[18][y[298]]=i;
    local function Q(t)
      local g,u=s[87](),t[l[518]];
      if g[l[40]](u)~=l[1346] then
        local zP,TP=t:clipboardImport();
        if not zP then
          return l[1329],TP;
        end
        u=t[l[518]];
      else
      end
      local zP,TP=g[l[1146]](t[l[1328]],t,u);
      t[l[1583]],t[l[518]]=nil,nil;
      if not zP then
        local u,zP=l[171],{[l[502]]=l[1329]};
        zP[l[1290]],t[u]={g[l[1130]](TP)},zP;
        return l[1329],g[l[1130]](TP);
      end
      if TP~=l[383] then
        g=t[l[171]]and t[l[171]][l[1290]];
        return l[1329],g and g[l[229]]or l[217];
      end
      return l[383];
    end
    y[299]=l[67];
    y[18][y[299]]=Q;
    local function Q(t,g)
      local u=s[87]();
      if u[l[40]](g)~=l[1346]or not t[l[630]] then
        return l[1329];
      end
      local zP,TP,nP={},{},{};
      local JP=g[l[516]]or{};
      if u[l[40]](JP)~=l[1346]or g[l[131]]~=nil and u[l[40]](g[l[131]])~=l[1346] then
        return l[1329];
      end
      for HP,fP in y[4](JP)do
        local aP=t[l[1294]][HP];
        if aP and not(t[l[1207]]and t[l[1207]][HP]) then
          local dP;
          if aP[l[415]]==l[384] then
            local PP=u[l[1382]](fP);
            dP=PP~=nil and PP==PP and u[l[35]][l[1575]](PP)<l[94];
            if dP then
              PP=if aP[l[260]]and aP[l[260]][l[457]]~=nil then u[l[35]][l[850]](PP,aP[l[260]][l[457]])else PP;
              fP=if aP[l[260]]and aP[l[260]][l[850]]~=nil then u[l[35]][l[457]](PP,aP[l[260]][l[850]])else PP;
            else
            end
          else
            dP=if aP[l[415]]==l[524]then u[l[40]](fP)==l[268]else if aP[l[415]]==l[1409]then u[l[1703]](fP)==l[360]or u[l[40]](fP)==l[409]and r(fP)~=nil else if aP[l[415]]==l[230]then u[l[40]](fP)==l[409]and u[l[1146]](function()
              local aP=s[87]();
              aP[l[817]](aP[l[128]][l[880]--[[readu32]]][fP]);
            end)else u[l[40]](fP)==l[409]and#fP<=l[546];
          end
          if not dP then
            zP[#zP+l[229]]=HP..l[621];
          end
          if dP then
            nP[HP]=fP;
          end
        else
        end
      end;
      for HP,fP in y[4](g[l[131]]or{})do
        if u[l[40]](HP)~=l[409]or u[l[40]](fP)~=l[409]or not r(fP) then
          zP[#zP+l[229]]=l[141];
        end
      end;
      if #zP>l[393] then
        t[l[171]]={[l[502]]=l[1329],[l[1290]]=zP};
        u[l[972]](l[11]..u[l[1346]][l[978]](zP,l[130]));
        return l[1329];
      end
      if u[l[40]](t[l[106]])==l[1712] then
        local HP,fP=u[l[1146]](t[l[106]],{[l[516]]=nP,[l[131]]=g[l[131]]});
        if not HP then
          local HP,aP=l[171],{[l[502]]=l[1329]};
          aP[l[1290]],t[HP]={u[l[1130]](fP)},aP;
          return l[1329];
        end
      end
      if not t[l[630]] then
        return l[1329];
      end
      for HP,fP in y[4](nP)do
        JP=t[l[1294]][HP];
        if JP[l[260]]and JP[l[260]][l[284]] then
          local aP,dP=u[l[1146]](JP[l[260]][l[284]],fP);
          if aP and dP~=l[383]and(JP[l[415]]==l[1206]or JP[l[415]]==l[409]) then
            TP[#TP+l[229]]=HP..l[6];
            nP[HP]=nil;
          elseif not aP or dP~=l[383] then
            zP[#zP+l[229]]=HP..l[621];
          end
        end
      end;
      if #zP>l[393] then
        t[l[171]]={[l[502]]=l[1329],[l[1290]]=zP};
        return l[1329];
      end
      t[l[1478]]=(t[l[1478]]or l[393])+l[229];
      local JP=t[l[1478]];
      t[l[921]]=l[383];
      t[l[1334]]=l[383];
      t[l[171]]={[l[502]]=l[1329],[l[140]]=l[383],[l[1290]]=zP,[l[1012]]=TP};
      local function HP()
        return t[l[630]]and t[l[1478]]==JP;
      end
      local fP,aP=u[l[1146]](function()
        local dP,PP=s[87](),l[393];
        if dP[l[40]](g[l[131]])==l[1346] then
          local ZP={};
          for GP,YP in y[3],g[l[131]],nil do
            local eP=r(YP);
            if eP then
              ZP[GP]=eP;
            end
          end;
          if not HP() then
            return;
          end
          t:retheme(ZP);
          dP[l[1022]][l[153]]();
        end
        if dP[l[40]](g[l[516]])==l[1346] then
          for g,g in y[3],t[l[752]],nil do
            if not HP() then
              return;
            end
            local ZP,GP=t[l[1294]][g],nP[g];
            if ZP and GP~=nil then
              if not(t[l[1207]]and t[l[1207]][g]) then
                local nP,YP=dP[l[1146]](ZP[l[1255]],GP);
                if not nP then
                  zP[#zP+l[229]]=g..l[1221]..dP[l[1130]](YP);
                end
              end
            end
            PP+=l[229];
            if PP%l[1158]==l[393] then
              dP[l[1022]][l[153]]();
            end
          end;
        end
      end);
      if t[l[1478]]==JP then
        t[l[1334]]=l[1329];
        t[l[921]]=l[1329];
        t[l[775]]=u[l[655]][l[1587]]();
        if not fP then
          zP[#zP+l[229]]=u[l[1130]](aP);
        end
        t[l[171]]={[l[502]]=fP and t[l[630]]and#zP==l[393],[l[1290]]=zP,[l[1012]]=TP};
      end
      if not fP then
        u[l[972]](l[110]..u[l[1130]](aP));
      end
      if #zP>l[393] then
        u[l[972]](l[729]..u[l[1346]][l[978]](zP,l[130]));
      end
      return fP and HP()and#zP==l[393];
    end
    y[300]=l[1328];
    y[18][y[300]]=Q;
    local function Q(t)
      local g,u=s[87](),{};
      if g[l[40]](g[l[433]])~=l[1712]or not M() then
        return u;
      end
      for zP,zP in y[3],U(g[l[433]],y[18][l[354]])or{},nil do
        t=g[l[409]][l[56]](g[l[409]][l[1710]](g[l[1130]](zP),l[365],l[532]),l[991]);
        if t then
          g[l[1346]][l[968]](u,t);
        end
      end;
      g[l[1346]][l[933]](u,function(t,g)
        local zP=s[87]();
        return zP[l[409]][l[345]](t)<zP[l[409]][l[345]](g);
      end);
      return u;
    end
    y[301]=l[640];
    y[18][y[301]]=Q;
    y[302]=l[1091];
    y[18][y[302]]=nil;
    local function t(g)
      local u,zP=s[87](),y[18][l[1091]];
      if not(zP and u[l[40]](u[l[1496]])==l[1712]and u[l[40]](u[l[1216]])==l[1712]) then
        return nil;
      end
      local TP,nP=u[l[1146]](u[l[1496]],zP);
      if not(TP and nP) then
        return nil;
      end
      g,TP=u[l[1146]](u[l[1216]],zP);
      return g and sP(u[l[1130]](TP))or nil;
    end
    y[303]=l[173];
    y[18][y[303]]=t;
    local function t(g,u)
      local zP,TP=s[87](),y[18][l[1091]];
      if not TP then
        return l[1329];
      end
      if not u then
        if zP[l[40]](zP[l[1496]])==l[1712]and zP[l[40]](zP[l[255]])==l[1712]and zP[l[199]](l[59],zP[l[1146]](zP[l[1496]],TP))==l[383] then
          zP[l[1146]](zP[l[255]],TP);
        end
        return l[383];
      end
      g=zP[l[409]][l[56]](TP,l[292]);
      if g and zP[l[40]](zP[l[215]])==l[1712]and zP[l[40]](zP[l[1528]])==l[1712]and not zP[l[199]](l[59],zP[l[1146]](zP[l[215]],g)) then
        zP[l[1146]](zP[l[1528]],g);
      end
      return zP[l[40]](zP[l[611]])==l[1712]and zP[l[1146]](zP[l[611]],TP,u)or l[1329];
    end
    y[304]=l[570];
    y[18][y[304]]=t;
    local function g(u,zP)
      local TP=s[87]();
      zP=sP(zP);
      if not zP or TP[l[40]](TP[l[611]])~=l[1712]or not M() then
        return nil;
      end
      local M,nP=TP[l[1146]](y[18][l[806]],y[18]);
      if not M or TP[l[40]](nP)~=l[409] then
        return nil;
      end
      if not TP[l[1146]](TP[l[611]],lP(zP),nP) then
        return nil;
      end
      if TP[l[40]](TP[l[1216]])==l[1712] then
        u,M=TP[l[1146]](TP[l[1216]],lP(zP));
        if not u or M~=nP then
          return nil;
        end
      end
      return zP;
    end
    y[305]=l[705];
    y[18][y[305]]=g;
    local function u(M,zP)
      local TP=s[87]();
      zP=sP(zP);
      M[l[171]]=nil;
      if not zP or TP[l[40]](TP[l[1216]])~=l[1712] then
        local nP,JP=l[171],{[l[502]]=l[1329]};
        JP[l[1290]],M[nP]={l[1673]},JP;
        return nil;
      end
      local nP,JP=TP[l[1146]](TP[l[1216]],lP(zP));
      if not nP or TP[l[40]](JP)~=l[409] then
        local HP,fP=l[171],{[l[502]]=l[1329]};
        fP[l[1290]],M[HP]={l[1524]--[[task]]},fP;
        return nil;
      end
      local HP,fP=TP[l[1146]](y[18][l[324]],y[18],JP);
      if not HP or not fP then
        JP,nP=l[171],{[l[502]]=l[1329]};
        nP[l[1290]],M[JP]={l[1066]},nP;
        return nil;
      end
      nP,HP=TP[l[1146]](M[l[1328]],M,fP);
      if not nP then
        M[l[1334]],M[l[921]]=l[1329],l[1329];
        JP,fP=l[171],{[l[502]]=l[1329]};
        fP[l[1290]],M[JP]={TP[l[1130]](HP)},fP;
      end
      return nP and HP and zP or nil;
    end
    y[306]=l[1270];
    y[18][y[306]]=u;
    local function M(zP,TP)
      zP=s[87]();
      TP=sP(TP);
      local nP=zP[l[255]]or zP[l[1217]];
      if not TP or zP[l[40]](nP)~=l[1712] then
        return nil;
      end
      if not zP[l[1146]](nP,lP(TP)) then
        return nil;
      end
      return TP;
    end
    y[307]=l[626];
    y[18][y[307]]=M;
    local function M(zP,TP,nP)
      local JP=s[87]();
      TP,nP=sP(TP),sP(nP);
      if not TP or not nP or JP[l[40]](JP[l[1216]])~=l[1712]or JP[l[40]](JP[l[611]])~=l[1712] then
        return nil;
      end
      if TP==nP then
        return nP;
      end
      if JP[l[40]](JP[l[1496]])~=l[1712]or JP[l[1496]](lP(nP)) then
        return nil;
      end
      local HP,fP=JP[l[1146]](JP[l[1216]],lP(TP));
      if not HP or JP[l[40]](fP)~=l[409] then
        return nil;
      end
      if not JP[l[1146]](JP[l[611]],lP(nP),fP) then
        return nil;
      end
      zP,HP=JP[l[1146]](JP[l[1216]],lP(nP));
      if not zP or HP~=fP or not y[18]:erase(TP) then
        return nil;
      end
      return nP;
    end
    y[308]=l[1584];
    y[18][y[308]]=M;
    local M,lP={};
    local function zP()
      local TP,nP=s[87](),y[18]:roster();
      local JP,HP=TP[l[1346]][l[978]](nP,l[214]),lP;
      if JP==HP then
        return;
      end
      lP=JP;
      for JP,JP in y[3],M,nil do
        TP[l[1022]][l[281]](JP,nP);
      end;
    end
    local function TP(nP,nP)
      local JP,HP=s[87](),y[18]:roster();
      lP=JP[l[1346]][l[978]](HP,l[214]);
      JP[l[1346]][l[968]](M,nP);
      JP[l[1022]][l[281]](nP,HP);
    end
    y[309]=l[1731];
    y[18][y[309]]=TP;
    y[310]=l[1022];
    y[1][y[310]][l[281]](function()
      local lP=s[87]();
      while y[18][l[630]]do
        lP[l[1022]][l[153]](l[599]);
        if #M>l[393] then
          zP();
        end
      end;
    end);
    y[311]=l[583];
    y[312]=l[1329];
    y[18][y[311]]=y[312];
    local lP={[l[998]]=l[210],[l[50]]=l[844],[l[93]]=l[530]};
    y[313]=l[333];
    y[314]={l[998],l[50],l[93]};
    y[18][y[313]]=y[314];
    y[315]=l[491];
    y[316]={};
    y[18][y[315]]=y[316];
    y[317]=l[73];
    y[318]=l[998];
    y[18][y[317]]=y[318];
    y[319]=l[27];
    y[320]=l[1329];
    y[18][y[319]]=y[320];
    local TP=l[762];
    local nP,JP={l[134],l[15],l[246],l[1746]},{};
    local function HP(fP)
      local aP=s[87]();
      if aP[l[40]](aP[l[1496]])==l[1712]and aP[l[40]](aP[l[553]])==l[1712] then
        for dP,PP in y[3],nP,nil do
          dP={l[1464],l[1364],l[1390]};
          for nP,ZP in y[3],dP,nil do
            nP=PP..fP..ZP;
            if U(aP[l[1496]],nP) then
              ZP=U(aP[l[553]],nP);
              if aP[l[40]](ZP)==l[409]and ZP~=l[1746] then
                return ZP;
              end
            end
          end;
        end;
      end
      local nP,dP=m(l[1746]);
      for PP,ZP in y[3],nP,dP do
        local nP,dP=aP[l[409]][l[56]](ZP,l[1608]);
        if nP==fP and(dP==l[1464]or dP==l[1364]or dP==l[1390]) then
          PP=c(ZP);
          if PP then
            return PP;
          end
        end
      end;
    end
    local function nP(fP)
      if JP[fP]~=nil then
        return JP[fP]or nil;
      end
      local aP=lP[fP];
      local dP=aP and HP(aP)or nil;
      JP[fP]=dP or l[1329];
      return dP;
    end
    local JP={};
    local HP=l[393];
    for fP=l[229],l[786],l[229]do
      JP[fP]=a(l[1058],{[l[1150]]=f(),[l[980]]=TP,[l[1110]]=l[894]},x);
    end;
    local fP={[l[404]]={l[343],l[330]},[l[676]]={l[1432],l[894]},[l[651]]={l[229],l[1491]},[l[1352]]={l[685],l[120]},[l[1600]]={l[1194],l[893]},[l[914]]={l[1023],l[1431]},[l[1320]]={l[1075],l[304]}};
    local function aP(dP,PP)
      dP=s[87]();
      if not y[18][l[27]]or y[18][l[1334]] then
        return;
      end
      local ZP,GP=fP[PP]or fP[l[1320]],HP;
      HP=GP%#JP+l[229];
      PP=JP[HP];
      PP[l[1301]]=ZP[l[229]];
      PP[l[1110]]=ZP[l[59]];
      PP[l[105]]=l[393];
      dP[l[1146]](PP[l[363]],PP);
    end
    y[321]=l[248];
    y[18][y[321]]=aP;
    local function HP(fP)
      for dP,dP in y[3],JP,nil do
        if dP[l[980]]~=fP then
          dP[l[980]]=fP;
        end
      end;
    end
    local function JP(fP,dP)
      local PP={};
      fP=s[87]();
      if not lP[dP] then
        return;
      end
      PP[1]=y[18];
      PP[2]=l[73];
      PP[1][PP[2]]=dP;
      local lP=y[18][l[491]][dP];
      if lP then
        HP(lP);
        return;
      end
      fP[l[1022]][l[281]](function()
        local lP={};
        local fP=nP(dP);
        if y[18][l[73]]~=dP then
          return;
        end
        lP[1]=y[18][l[491]];
        lP[2]=dP;
        lP[3]=fP or TP;
        lP[1][lP[2]]=lP[3];
        HP(y[18][l[491]][dP]);
      end);
    end
    y[322]=l[539];
    y[18][y[322]]=JP;
    local function lP(TP,TP)
      local nP={};
      nP[1]=y[18];
      nP[2]=l[27];
      nP[3]=TP and l[383]or l[1329];
      nP[1][nP[2]]=nP[3];
    end
    y[323]=l[308];
    y[18][y[323]]=lP;
    y[324]=l[1028];
    y[325]={};
    y[18][y[324]]=y[325];
    y[326]=l[661];
    y[327]={};
    y[18][y[326]]=y[327];
    y[328]=l[1043];
    y[18][y[328]]=nil;
    y[329]=l[1429];
    y[330]=l[1329];
    y[18][y[329]]=y[330];
    y[331]=l[1455];
    y[332]=l[1329];
    y[18][y[331]]=y[332];
    y[334]=y[3];
    y[333]=l[40];
    for TP,TP in y[334],y[1][y[333]](y[2])==l[1346]and{}or m(l[1144]),nil do
      y[335]=l[409];
      JP=(y[1][y[335]][l[56]](TP,l[1476]));
      y[337]=JP;
      if y[337] then
        y[336]=l[1028];
        y[337]=not y[18][y[336]][JP];
      end
      if y[337] then
        y[11]=(c(TP));
        if y[11] then
          y[338]=l[1028];
          y[339]=y[18][y[338]];
          y[339][JP]=y[11];
          y[340]=l[1346];
          y[342]=y[1][y[340]][l[968]];
          y[341]=l[661];
          y[342](y[18][y[341]],JP);
        end
      end
    end;
    lP={l[1430],l[1028]};
    for c,c in y[3],lP,nil do
      y[344]=U;
      y[343]=l[215];
      y[348]=y[344](y[1][y[343]],c);
      if y[348] then
        y[345]=l[40];
        y[347]=y[1][y[345]];
        y[346]=l[433];
        y[348]=y[347](y[1][y[346]])==l[1712];
      end
      y[352]=y[348];
      if y[352] then
        y[349]=l[40];
        y[351]=y[1][y[349]];
        y[350]=l[553];
        y[352]=y[351](y[1][y[350]])==l[1712];
      end
      if y[352] then
        y[355]=y[3];
        y[354]=U;
        y[353]=l[433];
        for m,m in y[355],y[354](y[1][y[353]],c)or{},nil do
          y[356]=l[409];
          y[360]=y[1][y[356]][l[56]];
          y[357]=l[409];
          y[359]=y[1][y[357]][l[1710]];
          y[358]=l[1130];
          aP=(y[360](y[359](y[1][y[358]](m),l[365],l[532]),l[1476]));
          y[362]=aP;
          if y[362] then
            y[361]=l[1028];
            y[362]=not y[18][y[361]][aP];
          end
          if y[362] then
            y[364]=U;
            y[363]=l[553];
            LP=(y[364](y[1][y[363]],c..l[532]..aP..l[111]));
            y[365]=l[40];
            if y[1][y[365]](LP)==l[409]and LP~=l[1746] then
              y[366]=l[1028];
              y[367]=y[18][y[366]];
              y[367][aP]=LP;
              y[368]=l[1346];
              y[370]=y[1][y[368]][l[968]];
              y[369]=l[661];
              y[370](y[18][y[369]],aP);
            end
          end
        end;
      end
    end;
    y[371]=l[1346];
    y[373]=y[1][y[371]][l[933]];
    y[372]=l[661];
    y[373](y[18][y[372]],function(c,m)
      local U=s[87]();
      return U[l[409]][l[345]](c)<U[l[409]][l[345]](m);
    end);
    y[374]=l[1043];
    y[375]=l[661];
    y[376]=y[18][y[375]][l[229]];
    y[18][y[374]]=y[376];
    y[384]=a;
    y[385]=l[859];
    y[377]={};
    y[377][l[1150]]=f();
    y[379]=l[1016];
    y[378]=l[1689];
    y[377][y[379]]=y[1][y[378]][l[772]](l[659],l[659]);
    y[381]=l[1639];
    y[380]=l[1459];
    y[377][y[381]]=y[1][y[380]][l[588]](l[1167],l[1167]);
    y[377][l[1646]]=l[229];
    y[377][l[1418]]=l[393];
    y[377][l[1451]]=l[1746];
    y[383]=l[1557];
    y[382]=l[128];
    y[377][y[383]]=y[1][y[382]][l[1557]][l[208]];
    y[377][l[1324]]=l[1329];
    y[377][l[711]]=l[1461];
    local c=y[384](y[385],y[377],x);
    y[386]=l[1146];
    y[1][y[386]](function()
      local m=s[87]();
      c[l[196]]=m[l[128]][l[1727]][l[1467]];
    end);
    local m={[l[314]]={l[1526],l[906]},[l[301]]={l[229],l[303]},[l[951]]={l[1307],l[1243]},[l[891]]={l[973],l[1655]},[l[1114]]={l[973],l[114]},[l[452]]={l[1158],l[1307]},[l[1288]]={l[558],l[1241]},[l[1520]]={l[750],l[352]},[l[1676]]={l[352],l[1241]},[l[91]]={l[973],l[1707]}};
    local function U(lP)
      local LP,TP=s[87](),m[y[18][l[1043]]];
      c[l[1451]]=lP;
      c[l[1016]]=TP and LP[l[1689]][l[772]](TP[l[229]]/l[1167],TP[l[59]]/l[1167])or LP[l[1689]][l[772]](l[659],l[659]);
    end
    local m,lP;
    local function LP()
      local TP={};
      local nP,HP=s[87](),y[9]:GetMouseLocation();
      c[l[948]]=nP[l[1459]][l[588]](HP[l[1437]],HP[l[636]]);
      HP=not y[18][l[583]]and y[9][l[643]]==nP[l[128]][l[643]][l[1081]];
      if c[l[1324]]==HP then
        c[l[1324]]=not HP;
      end
      if y[9][l[1181]]~=HP then
        TP[1]=y[9];
        TP[2]=l[1181];
        TP[1][TP[2]]=HP;
      end
    end
    local function TP()
      local nP={};
      local HP=y[18][l[1028]][y[18][l[1043]]];
      local fP,aP=y[18][l[1429]]and(y[18][l[583]]or y[18][l[1455]])and not y[18][l[388]]and HP~=nil,m~=nil;
      if fP==aP then
        if fP then
          U(HP);
        end
        return;
      end
      if fP then
        nP[1]=y[9][l[1181]];
        lP=nP[1];
        U(HP);
        LP();
        c[l[1324]]=l[383];
        nP[2]=(y[10][l[1119]]:Connect(LP));
        m=nP[2];
        return;
      end
      m:Disconnect();
      m=nil;
      c[l[1324]]=l[1329];
      HP=lP~=nil;
      if HP then
        nP[3]=y[9];
        nP[4]=l[1181];
        nP[5]=lP;
        nP[3][nP[4]]=nP[5];
        lP=nil;
      end
    end
    local function c(m,m)
      local U={};
      if not y[18][l[1028]][m] then
        return;
      end
      U[1]=y[18];
      U[2]=l[1043];
      U[1][U[2]]=m;
      TP();
    end
    y[387]=l[379];
    y[18][y[387]]=c;
    local function c(m,m)
      local U={};
      U[1]=y[18];
      U[2]=l[1429];
      U[3]=m and l[383]or l[1329];
      U[1][U[2]]=U[3];
      TP();
    end
    y[388]=l[960];
    y[18][y[388]]=c;
    local function c(m,m)
      local U={};
      U[1]=y[18];
      U[2]=l[1455];
      U[3]=m and l[383]or l[1329];
      U[1][U[2]]=U[3];
      TP();
    end
    y[389]=l[75];
    y[18][y[389]]=c;
    local function c(m)
      TP();
    end
    y[390]=l[987];
    y[18][y[390]]=c;
    y[391]=l[131];
    local c,m,U=y[18][y[391]];
    local function lP(LP,nP)
      local HP={};
      local fP=U;
      if fP then
        local aP=U;
        U=nil;
        aP();
      end
      fP=m;
      if fP then
        m:Disconnect();
        m=nil;
      end
      if not LP then
        HP[1]=y[18];
        HP[2]=l[1333];
        HP[3]=l[1329];
        HP[1][HP[2]]=HP[3];
        return;
      end
      U=nP;
      HP[4]=y[18];
      HP[5]=l[1333];
      HP[6]=l[383];
      HP[4][HP[5]]=HP[6];
      HP[7]=(y[9][l[1558]]:Connect(function(nP)
        local fP=s[87]();
        if nP[l[1317]]~=fP[l[128]][l[1317]][l[1441]]or nP[l[880]--[[readu32]]]==fP[l[128]][l[880]--[[readu32]]][l[605]] then
          return;
        end
        local aP=nP[l[880]--[[readu32]]];
        U=nil;
        lP(nil);
        LP(aP~=fP[l[128]][l[880]--[[readu32]]][l[1739]]and aP or nil);
      end));
      m=HP[7];
    end
    y[392]=l[1648];
    y[393]=l[383];
    y[18][y[392]]=y[393];
    local m={};
    local function U(LP)
      for nP=#m,l[229],l[715]do
        local HP=m[nP];
        if HP~=LP then
          HP:setopen(l[1329]);
        end
      end;
    end
    local function LP(nP,HP)
      local fP=s[87]();
      local aP,dP=fP[l[1146]](function()
        local PP=s[87]();
        local ZP,GP=PP[l[128]][l[437]][l[1381]],s[70](PP[l[1689]][l[772]](l[1304],l[1304]));
        return y[8]:GetTextSize(nP,HP,ZP,s:ZT(GP));
      end);
      if aP and dP then
        return fP[l[35]][l[139]](dP[l[1437]]);
      end
      return fP[l[35]][l[139]](#fP[l[1130]](nP)*HP*l[1419]);
    end
    local nP=k(l[1198]);
    y[403]=a;
    y[404]=l[1751];
    y[394]={};
    y[394][l[1150]]=f();
    y[396]=l[1016];
    y[395]=l[1689];
    y[394][y[396]]=y[1][y[395]][l[772]](l[393],l[659]);
    y[398]=l[948];
    y[397]=l[1459];
    y[394][y[398]]=y[1][y[397]][l[772]](l[393],l[930],l[659],l[393]);
    y[400]=l[1639];
    y[399]=l[1459];
    y[394][y[400]]=y[1][y[399]][l[588]](l[393],l[393]);
    y[402]=l[1347];
    y[401]=l[128];
    y[394][y[402]]=y[1][y[401]][l[1347]][l[1613]];
    y[394][l[1646]]=l[229];
    y[394][l[1418]]=l[393];
    y[394][l[711]]=l[104];
    local HP=y[403](y[404],y[394],x);
    y[22]=l[755];
    y[405]={};
    y[407]=l[101];
    y[406]=l[128];
    y[405][y[407]]=y[1][y[406]][l[101]][l[1401]];
    y[409]=l[1749];
    y[408]=l[128];
    y[405][y[409]]=y[1][y[408]][l[1749]][l[701]];
    y[411]=l[407];
    y[410]=l[128];
    y[405][y[411]]=y[1][y[410]][l[407]][l[537]];
    y[11]=y[405];
    y[412]=l[536];
    y[413]=l[740];
    y[414]=(y[1][y[413]][l[772]](l[393],l[863]));
    y[11][y[412]]=y[414];
    a(y[22],y[11],HP);
    y[424]=a;
    y[425]=l[1359];
    y[415]={};
    y[417]=l[299];
    y[416]=l[740];
    y[415][y[417]]=y[1][y[416]][l[772]](l[393],l[730]);
    y[419]=l[645];
    y[418]=l[740];
    y[415][y[419]]=y[1][y[418]][l[772]](l[393],l[730]);
    y[421]=l[1612];
    y[420]=l[740];
    y[415][y[421]]=y[1][y[420]][l[772]](l[393],l[730]);
    y[423]=l[517];
    y[422]=l[740];
    y[415][y[423]]=y[1][y[422]][l[772]](l[393],l[730]);
    y[424](y[425],y[415],HP);
    HP[l[1324]]=l[1329];
    HP[l[1569]]=l[229];
    Z(HP);
    local function fP(aP,dP,PP,ZP,GP)
      local YP=s[87]();
      local eP=a(l[211],{[l[1150]]=f(),[l[1639]]=YP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=c[l[675]],[l[1646]]=l[561],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=dP,[l[711]]=l[59]},aP);
      D(eP,l[930]);
      dP=a(l[734],{[l[1630]]=c[l[966]],[l[1544]]=l[229],[l[747]]=l[323],[l[1161]]=YP[l[128]][l[1161]][l[1741]],[l[371]]=YP[l[128]][l[371]][l[808]]},eP);
      if GP and nP then
        a(l[1198],{[l[1630]]=c[l[641]],[l[258]]=YP[l[740]][l[772]](l[393],GP),[l[1485]]=YP[l[1459]][l[588]](l[393],l[59]),[l[1326]]=YP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[1419],[l[711]]=l[715]},eP);
      end
      GP=a(l[211],{[l[1150]]=f(),[l[1639]]=YP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=c[l[1529]--[[cancel]]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[59]},eP);
      D(GP,l[930]);
      K(GP,l[117],{YP[l[677]][l[772]](l[393],l[659]),YP[l[677]][l[772]](l[1419],l[70]),YP[l[677]][l[772]](l[229],l[387])});
      K(a(l[211],{[l[1150]]=f(),[l[1016]]=YP[l[1689]][l[772]](l[659],l[393]),[l[948]]=YP[l[1459]][l[772]](l[659],l[393],l[393],l[229]),[l[1639]]=YP[l[1459]][l[772]](l[229],l[992]--[[readi8]],l[393],l[229]),[l[1535]]=c[l[1529]--[[cancel]]],[l[1646]]=l[509],[l[1418]]=l[393],[l[711]]=l[863]},eP),l[393],{YP[l[677]][l[772]](l[393],l[229]),YP[l[677]][l[772]](l[659],l[1209]),YP[l[677]][l[772]](l[229],l[229])});
      aP=a(l[211],{[l[1150]]=f(),[l[1639]]=YP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[863]},eP);
      if PP then
        a(l[1359],{[l[1612]]=YP[l[740]][l[772]](l[393],PP),[l[517]]=YP[l[740]][l[772]](l[393],PP)},aP);
      end
      if ZP then
        a(l[755],{[l[101]]=YP[l[128]][l[101]][l[1505]],[l[1749]]=YP[l[128]][l[1749]][l[46]],[l[1259]]=YP[l[128]][l[1259]][l[46]],[l[407]]=YP[l[128]][l[407]][l[537]],[l[536]]=YP[l[740]][l[772]](l[393],ZP)},aP);
      end
      return eP,dP,GP,aP;
    end
    local aP,dP,dP,dP=fP(HP,l[393],l[558],l[930],l[730]);
    aP[l[43]]=l[383];
    y[431]=a;
    y[432]=l[859];
    y[426]={};
    y[426][l[1150]]=f();
    y[428]=l[1639];
    y[427]=l[1459];
    y[426][y[428]]=y[1][y[427]][l[588]](l[114],l[114]);
    y[426][l[1646]]=l[229];
    y[426][l[1451]]=y[30](l[1680]);
    y[426][l[936]]=c[l[1379]];
    y[426][l[2]]=l[393];
    y[426][l[537]]=l[229];
    y[430]=l[1557];
    y[429]=l[128];
    y[426][y[430]]=y[1][y[429]][l[1557]][l[220]];
    y[426][l[711]]=l[786];
    y[431](y[432],y[426],dP);
    y[440]=a;
    y[441]=l[1070];
    y[433]={};
    y[433][l[1150]]=f();
    y[435]=l[1347];
    y[434]=l[128];
    y[433][y[435]]=y[1][y[434]][l[1347]][l[1437]];
    y[437]=l[1639];
    y[436]=l[1459];
    y[433][y[437]]=y[1][y[436]][l[588]](l[393],l[1707]);
    y[433][l[1646]]=l[229];
    y[439]=l[437];
    y[438]=l[128];
    y[433][y[439]]=y[1][y[438]][l[437]][l[807]];
    y[433][l[1420]]=l[1648];
    y[433][l[510]]=c[l[1095]];
    y[433][l[723]]=l[558];
    y[433][l[537]]=l[59];
    y[433][l[711]]=l[786];
    y[440](y[441],y[433],dP);
    local dP=l[1107]+LP(l[1648],l[558]);
    _(aP,HP,l[841]);
    local PP,ZP={},{};
    local GP,YP=l[1329];
    local function eP()
      local jP,CP=s[87](),dP;
      for dP=l[229],#ZP,l[229]do
        local NP=PP[ZP[dP]];
        CP=if NP and NP[l[133]]and NP[l[133]]>CP then NP[l[133]]else CP;
      end;
      local dP=YP;
      if CP==dP then
        return;
      end
      dP=YP==nil;
      if dP then
        YP=CP;
        aP[l[1639]]=jP[l[1459]][l[588]](CP,l[489]);
        return;
      end
      YP=CP;
      P(aP,H,{[l[1639]]=jP[l[1459]][l[588]](CP,l[489])});
    end
    local function aP()
      local dP=s[87]();
      dP[l[1346]][l[933]](ZP,function(YP,jP)
        local CP,NP=PP[YP],PP[jP];
        if not CP or not NP then
          return l[1329];
        end
        if CP[l[1100]]~=NP[l[1100]] then
          return CP[l[1100]]<NP[l[1100]];
        end
        return CP[l[572]]<NP[l[572]];
      end);
      for YP=l[229],#ZP,l[229]do
        dP=PP[ZP[YP]];
        if dP then
          dP[l[266]][l[537]]=YP;
        end
      end;
    end
    local function dP()
      local YP,jP=y[18][l[1648]]and#ZP>l[393],GP;
      if YP==jP then
        return;
      end
      GP=YP;
      eP();
      if YP then
        HP[l[1324]]=l[383];
      end
      local jP=HP[l[1569]];
      local CP=YP and l[393]or l[229];
      b(HP,YP and l[1431]or l[120],YP and N or q,function(YP)
        HP[l[1569]]=jP+(CP-jP)*YP;
        local jP=YP>=l[229]and not GP;
        if jP then
          HP[l[1324]]=l[1329];
        end
      end);
    end
    local function GP(YP,jP)
      local CP=s[87]();
      jP=jP and l[383]or l[1329];
      if not YP[l[1154]]or YP[l[404]]==jP then
        return;
      end
      YP[l[404]]=jP;
      local NP,qP=YP[l[1154]],{};
      qP[l[1535]]=jP and c[l[98]]or c[l[641]];
      P(NP,H,qP);
      P(YP[l[456]],H,{[l[948]]=CP[l[1459]][l[772]](jP and l[156]or l[1491],l[393],l[659],l[393]),[l[1535]]=jP and c[l[641]]or CP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=jP and l[393]or l[323]});
    end
    local function YP(jP)
      local CP,NP=s[87](),l[688]+jP[l[1100]];
      NP=if jP[l[1204]]then NP+jP[l[431]]+l[730]else NP;
      local qP=CP[l[35]][l[850]](l[1655]+jP[l[586]],l[913]);
      if NP==jP[l[1037]]and qP==jP[l[720]] then
        return;
      end
      jP[l[1037]]=NP;
      jP[l[720]]=qP;
      jP[l[133]]=NP+l[303]+qP+(jP[l[1560]]and l[368]or l[393])+l[786];
      if jP[l[663]] then
        local bP,DP=jP[l[531]],{};
        DP[l[1639]]=CP[l[1459]][l[588]](NP,l[913]);
        P(bP,H,DP);
        bP,DP=jP[l[425]],{};
        DP[l[1639]]=CP[l[1459]][l[588]](qP,l[913]);
        P(bP,H,DP);
        bP,DP=jP[l[266]],{};
        DP[l[1639]]=CP[l[1459]][l[588]](jP[l[133]],l[489]);
        P(bP,H,DP);
      else
        jP[l[531]][l[1639]]=CP[l[1459]][l[588]](NP,l[913]);
        jP[l[425]][l[1639]]=CP[l[1459]][l[588]](qP,l[913]);
        jP[l[266]][l[1639]]=CP[l[1459]][l[588]](jP[l[133]],l[489]);
      end
    end
    local function jP(CP)
      if CP[l[331]]or CP[l[1600]] then
        return;
      end
      CP[l[1600]]=l[383];
      CP[l[266]][l[1324]]=l[383];
      local NP=CP[l[266]][l[1569]];
      b(CP[l[266]],l[269],N,function(qP)
        CP[l[266]][l[1569]]=NP*(l[229]-qP);
      end);
    end
    local function CP(NP,qP)
      if NP[l[331]]or not NP[l[1600]]and not qP then
        return;
      end
      NP[l[331]]=qP and l[383]or l[1329];
      NP[l[1600]]=l[1329];
      local qP=NP[l[266]][l[1569]];
      b(NP[l[266]],l[120],q,function(bP)
        NP[l[266]][l[1569]]=qP+(l[229]-qP)*bP;
        if bP<l[229] then
          return;
        end
        if NP[l[331]] then
          if NP[l[266]]and NP[l[266]][l[382]] then
            NP[l[266]]:Destroy();
          end
          return;
        end
        NP[l[266]][l[1324]]=l[1329];
      end);
    end
    local function NP(qP,bP)
      local DP,pP=s[87](),PP[qP];
      if pP then
        pP[l[572]]=bP[l[572]];
        pP[l[1100]]=LP(bP[l[572]],l[558]);
        pP[l[586]]=LP(bP[l[230]],l[558]);
        pP[l[1685]][l[1420]]=bP[l[572]];
        pP[l[1574]][l[1420]]=bP[l[230]];
        if pP[l[1204]] then
          pP[l[1204]][l[1420]]=bP[l[1204]]or l[1746];
          pP[l[431]]=LP(pP[l[1204]][l[1420]],l[558]);
        end
        YP(pP);
        GP(pP,bP[l[628]]);
        aP();
        eP();
        jP(pP);
        return;
      end
      pP={[l[572]]=bP[l[572]],[l[1100]]=LP(bP[l[572]],l[558]),[l[586]]=LP(bP[l[230]],l[558]),[l[431]]=l[393],[l[266]]=a(l[1751],{[l[1150]]=f(),[l[1639]]=DP[l[1459]][l[588]](l[393],l[489]),[l[1646]]=l[229],[l[1418]]=l[393],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[59]},HP)};
      local rP,KP=l[755],{[l[101]]=DP[l[128]][l[101]][l[1505]],[l[1259]]=DP[l[128]][l[1259]][l[46]],[l[407]]=DP[l[128]][l[407]][l[537]]};
      KP[l[536]]=DP[l[740]][l[772]](l[393],l[303]);
      a(rP,KP,pP[l[266]]);
      a(l[1359],{[l[299]]=DP[l[740]][l[772]](l[393],l[59]),[l[645]]=DP[l[740]][l[772]](l[393],l[59]),[l[1612]]=DP[l[740]][l[772]](l[393],l[59]),[l[517]]=DP[l[740]][l[772]](l[393],l[59])},pP[l[266]]);
      if bP[l[103]] then
        pP[l[1560]],pP[l[1088]],pP[l[454]]=fP(pP[l[266]],l[229]);
        pP[l[1560]][l[1639]]=DP[l[1459]][l[588]](l[913],l[913]);
        pP[l[1154]]=a(l[211],{[l[1150]]=f(),[l[1016]]=DP[l[1689]][l[772]](l[659],l[659]),[l[948]]=DP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=DP[l[1459]][l[588]](l[1655],l[750]),[l[1535]]=c[l[641]],[l[1418]]=l[393],[l[711]]=l[786]},pP[l[1560]]);
        rP,KP=l[1112],{};
        KP[l[1182]]=DP[l[740]][l[772]](l[229],l[393]);
        a(rP,KP,pP[l[1154]]);
        pP[l[456]]=a(l[211],{[l[1150]]=f(),[l[1016]]=DP[l[1689]][l[772]](l[659],l[659]),[l[948]]=DP[l[1459]][l[772]](l[1431],l[393],l[659],l[393]),[l[1639]]=DP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=DP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[303]},pP[l[1154]]);
        local rP,oP=l[1112],{};
        oP[l[1182]]=DP[l[740]][l[772]](l[229],l[393]);
        a(rP,oP,pP[l[456]]);
        if bP[l[194]] then
          pP[l[1674]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=DP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1158]},pP[l[1560]]);
          d(pP[l[1674]][l[445]],function()
            bP[l[194]]();
          end);
        end
      end
      KP=nil;
      pP[l[531]],pP[l[1080]],pP[l[1240]],KP=fP(pP[l[266]],l[59],l[558],l[730]);
      pP[l[1685]]=a(l[1070],{[l[1150]]=f(),[l[1347]]=DP[l[128]][l[1347]][l[1437]],[l[1639]]=DP[l[1459]][l[588]](l[393],l[1707]),[l[1646]]=l[229],[l[437]]=DP[l[128]][l[437]][l[807]],[l[1420]]=bP[l[572]],[l[510]]=c[l[1095]],[l[723]]=l[558],[l[916]]=l[1296],[l[537]]=l[229],[l[711]]=l[786]},KP);
      if bP[l[1204]] then
        pP[l[1204]]=a(l[1070],{[l[1150]]=f(),[l[1347]]=DP[l[128]][l[1347]][l[1437]],[l[1639]]=DP[l[1459]][l[588]](l[393],l[1707]),[l[1646]]=l[229],[l[437]]=DP[l[128]][l[437]][l[807]],[l[1420]]=bP[l[1204]],[l[510]]=c[l[1379]],[l[723]]=l[558],[l[916]]=l[986],[l[537]]=l[59],[l[711]]=l[786]},KP);
        pP[l[431]]=LP(bP[l[1204]],l[558]);
      end
      local rP,KP,oP,cP,mP,SP,OP=l[425],l[469],l[280],fP(pP[l[266]],l[863],l[310],l[393]);
      pP[rP]=cP;
      pP[KP]=mP;
      pP[oP]=SP;
      pP[l[1574]]=a(l[1070],{[l[1150]]=f(),[l[1347]]=DP[l[128]][l[1347]][l[1437]],[l[1639]]=DP[l[1459]][l[588]](l[393],l[1707]),[l[1646]]=l[229],[l[437]]=DP[l[128]][l[437]][l[807]],[l[1420]]=bP[l[230]],[l[510]]=c[l[98]],[l[723]]=l[558],[l[916]]=l[1209],[l[537]]=l[229],[l[711]]=l[786]},OP);
      PP[qP]=pP;
      DP[l[1346]][l[968]](ZP,qP);
      YP(pP);
      GP(pP,bP[l[628]]);
      aP();
      dP();
      eP();
      pP[l[663]]=l[383];
      DP[l[1022]][l[281]](function()
        y[10][l[756]]:Wait();
        if pP[l[266]][l[382]] then
          jP(pP);
        end
      end);
    end
    local function fP(YP)
      local jP,qP=s[87](),PP[YP];
      if not qP then
        return;
      end
      PP[YP]=nil;
      local bP=jP[l[1346]][l[23]](ZP,YP);
      if bP then
        jP[l[1346]][l[1357]](ZP,bP);
      end
      aP();
      dP();
      eP();
      CP(qP,l[383]);
    end
    local function aP(ZP,YP)
      local jP=PP[ZP];
      if jP then
        GP(jP,YP);
      end
    end
    F=function()
      return W(HP,l[1158]);
    end;
    local function PP(ZP,ZP)
      local GP={};
      GP[1]=y[18];
      GP[2]=l[1648];
      GP[3]=ZP and l[383]or l[1329];
      GP[1][GP[2]]=GP[3];
      dP();
    end
    y[442]=l[1148];
    y[18][y[442]]=PP;
    local function dP(PP,ZP)
      PP=s[87]();
      if PP[l[1703]](ZP)==l[1459] then
        HP[l[948]]=ZP;
      end
    end
    y[443]=l[311];
    y[18][y[443]]=dP;
    eP();
    y[444]=l[1185];
    y[445]=l[383];
    y[18][y[444]]=y[445];
    local function dP(PP)
      local ZP=s[87]();
      return ZP[l[409]][l[846]](l[1730],PP[l[1437]][l[1609]],ZP[l[35]][l[499]](PP[l[1437]][l[1485]]+l[659]),PP[l[636]][l[1609]],ZP[l[35]][l[499]](PP[l[636]][l[1485]]+l[659]));
    end
    local function PP(ZP)
      local GP=s[87]();
      if GP[l[40]](ZP)~=l[409] then
        return nil;
      end
      local YP,eP,jP,CP=GP[l[409]][l[56]](ZP,l[1737]);
      if not YP then
        return nil;
      end
      return GP[l[1459]][l[772]](GP[l[1382]](YP),GP[l[1382]](eP),GP[l[1382]](jP),GP[l[1382]](CP));
    end
    y[455]=a;
    y[456]=l[1751];
    y[446]={};
    y[446][l[1150]]=f();
    y[448]=l[1016];
    y[447]=l[1689];
    y[446][y[448]]=y[1][y[447]][l[772]](l[229],l[393]);
    y[450]=l[948];
    y[449]=l[1459];
    y[446][y[450]]=y[1][y[449]][l[772]](l[229],l[1519],l[393],l[930]);
    y[452]=l[1639];
    y[451]=l[1459];
    y[446][y[452]]=y[1][y[451]][l[588]](l[393],l[393]);
    y[454]=l[1347];
    y[453]=l[128];
    y[446][y[454]]=y[1][y[453]][l[1347]][l[1613]];
    y[446][l[1646]]=l[229];
    y[446][l[1418]]=l[393];
    y[446][l[711]]=l[104];
    local ZP=y[455](y[456],y[446],x);
    Q=l[755];
    y[457]={};
    y[459]=l[101];
    y[458]=l[128];
    y[457][y[459]]=y[1][y[458]][l[101]][l[1505]];
    y[461]=l[1749];
    y[460]=l[128];
    y[457][y[461]]=y[1][y[460]][l[1749]][l[877]];
    y[463]=l[1259];
    y[462]=l[128];
    y[457][y[463]]=y[1][y[462]][l[1259]][l[46]];
    y[465]=l[407];
    y[464]=l[128];
    y[457][y[465]]=y[1][y[464]][l[407]][l[537]];
    g=y[457];
    y[466]=l[536];
    y[467]=l[740];
    y[468]=(y[1][y[467]][l[772]](l[393],l[930]));
    g[y[466]]=y[468];
    a(Q,g,ZP);
    y[478]=a;
    y[479]=l[1359];
    y[469]={};
    y[471]=l[299];
    y[470]=l[740];
    y[469][y[471]]=y[1][y[470]][l[772]](l[393],l[730]);
    y[473]=l[645];
    y[472]=l[740];
    y[469][y[473]]=y[1][y[472]][l[772]](l[393],l[730]);
    y[475]=l[1612];
    y[474]=l[740];
    y[469][y[475]]=y[1][y[474]][l[772]](l[393],l[730]);
    y[477]=l[517];
    y[476]=l[740];
    y[469][y[477]]=y[1][y[476]][l[772]](l[393],l[730]);
    y[478](y[479],y[469],ZP);
    ZP[l[1324]]=l[1329];
    ZP[l[1569]]=l[229];
    Z(ZP);
    local function Q(g,GP,YP)
      local eP=s[87]();
      local jP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=eP[l[1459]][l[588]](l[393],l[1249]),[l[1347]]=eP[l[128]][l[1347]][l[1437]],[l[1535]]=c[l[675]],[l[1646]]=l[561],[l[1418]]=l[393],[l[537]]=g,[l[711]]=l[59]},ZP);
      D(jP,l[930]);
      a(l[734],{[l[1630]]=c[l[966]],[l[1544]]=l[229],[l[747]]=l[323],[l[1161]]=eP[l[128]][l[1161]][l[1741]],[l[371]]=eP[l[128]][l[371]][l[808]]},jP);
      if nP then
        a(l[1198],{[l[1630]]=c[l[641]],[l[258]]=eP[l[740]][l[772]](l[393],l[730]),[l[1485]]=eP[l[1459]][l[588]](l[393],l[59]),[l[1326]]=eP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[1419],[l[711]]=l[715]},jP);
      end
      g=a(l[211],{[l[1150]]=f(),[l[1639]]=eP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=c[l[1529]--[[cancel]]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[59]},jP);
      D(g,l[930]);
      K(g,l[117],{eP[l[677]][l[772]](l[393],l[659]),eP[l[677]][l[772]](l[1419],l[70]),eP[l[677]][l[772]](l[229],l[387])});
      K(a(l[211],{[l[1150]]=f(),[l[1016]]=eP[l[1689]][l[772]](l[659],l[393]),[l[948]]=eP[l[1459]][l[772]](l[659],l[393],l[393],l[229]),[l[1639]]=eP[l[1459]][l[772]](l[229],l[992]--[[readi8]],l[393],l[229]),[l[1535]]=c[l[1529]--[[cancel]]],[l[1646]]=l[509],[l[1418]]=l[393],[l[711]]=l[863]},jP),l[393],{eP[l[677]][l[772]](l[393],l[229]),eP[l[677]][l[772]](l[659],l[1209]),eP[l[677]][l[772]](l[229],l[229])});
      g=a(l[211],{[l[1150]]=f(),[l[1639]]=eP[l[1459]][l[588]](l[393],l[1249]),[l[1347]]=eP[l[128]][l[1347]][l[1437]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[863]},jP);
      a(l[1359],{[l[1612]]=eP[l[740]][l[772]](l[393],GP),[l[517]]=eP[l[740]][l[772]](l[393],GP)},g);
      a(l[755],{[l[101]]=eP[l[128]][l[101]][l[1505]],[l[1259]]=eP[l[128]][l[1259]][l[46]],[l[407]]=eP[l[128]][l[407]][l[537]],[l[536]]=eP[l[740]][l[772]](l[393],YP)},g);
      _(jP,ZP,l[841]);
      return jP,g;
    end
    yP,R=Q(l[229],l[750],l[930]);
    y[485]=a;
    y[486]=l[859];
    y[480]={};
    y[480][l[1150]]=f();
    y[482]=l[1639];
    y[481]=l[1459];
    y[480][y[482]]=y[1][y[481]][l[588]](l[829],l[829]);
    y[480][l[1646]]=l[229];
    y[480][l[1451]]=y[30](l[565]);
    y[480][l[936]]=c[l[1379]];
    y[480][l[2]]=l[393];
    y[480][l[537]]=l[229];
    y[484]=l[1557];
    y[483]=l[128];
    y[480][y[484]]=y[1][y[483]][l[1557]][l[220]];
    y[480][l[711]]=l[786];
    y[485](y[486],y[480],R);
    y[494]=a;
    y[495]=l[1070];
    y[487]={};
    y[487][l[1150]]=f();
    y[489]=l[1347];
    y[488]=l[128];
    y[487][y[489]]=y[1][y[488]][l[1347]][l[1437]];
    y[491]=l[1639];
    y[490]=l[1459];
    y[487][y[491]]=y[1][y[490]][l[588]](l[393],l[1707]);
    y[487][l[1646]]=l[229];
    y[493]=l[437];
    y[492]=l[128];
    y[487][y[493]]=y[1][y[492]][l[437]][l[807]];
    y[487][l[1420]]=l[1397];
    y[487][l[510]]=c[l[1095]];
    y[487][l[723]]=l[558];
    y[487][l[916]]=l[1296];
    y[487][l[537]]=l[59];
    y[487][l[711]]=l[786];
    y[494](y[495],y[487],R);
    local R,R=Q(l[59],l[750],l[930]);
    y[510]=a;
    y[511]=l[859];
    y[496]={};
    y[496][l[1150]]=f();
    y[498]=l[1639];
    y[497]=l[1459];
    y[496][y[498]]=y[1][y[497]][l[588]](l[1243],l[1243]);
    y[496][l[1535]]=c[l[641]];
    y[496][l[1646]]=l[1431];
    y[496][l[1418]]=l[393];
    y[507]=l[1451];
    y[499]=l[560];
    y[501]=y[18][y[499]]~=l[1746];
    if y[501] then
      y[500]=l[560];
      y[501]=y[18][y[500]];
    end
    y[506]=y[501];
    if not y[506] then
      y[502]=l[409];
      y[504]=y[1][y[502]][l[846]];
      y[505]=l[1303];
      y[503]=l[1675];
      y[506]=y[504](y[505],y[13][y[503]]);
    end
    y[496][y[507]]=y[506];
    y[496][l[2]]=l[1422];
    y[496][l[537]]=l[730];
    y[509]=l[1557];
    y[508]=l[128];
    y[496][y[509]]=y[1][y[508]][l[1557]][l[574]];
    y[496][l[711]]=l[786];
    i=(y[510](y[511],y[496],R));
    y[22]=l[1112];
    u={};
    y[512]=l[1182];
    y[513]=l[740];
    y[514]=(y[1][y[513]][l[772]](l[229],l[393]));
    u[y[512]]=y[514];
    a(y[22],u,i);
    JP,E=l[734],{[l[1630]]=c[l[966]],[l[1544]]=l[229],[l[747]]=l[615]};
    y[515]=l[1161];
    y[516]=l[128];
    y[517]=y[1][y[516]][l[1161]][l[1741]];
    E[y[515]]=y[517];
    a(JP,E,i);
    local function i(E,Q,g,u)
      local yP=s[87]();
      if not u then
        local u=a(l[211],{[l[1150]]=f(),[l[1639]]=yP[l[1459]][l[588]](l[558],l[829]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=E,[l[711]]=l[786]},R);
        K(a(l[211],{[l[1150]]=f(),[l[1016]]=yP[l[1689]][l[772]](l[659],l[659]),[l[948]]=yP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=yP[l[1459]][l[588]](l[229],l[829]),[l[1535]]=c[l[1529]--[[cancel]]],[l[1646]]=l[1373],[l[1418]]=l[393],[l[711]]=l[786]},u),l[117],{yP[l[677]][l[772]](l[393],l[731]),yP[l[677]][l[772]](l[659],l[393]),yP[l[677]][l[772]](l[229],l[731])});
      end
      if Q then
        local u=a;
        local JP=l[859];
        local GP={};
        GP[l[1150]]=f();
        GP[l[1639]]=yP[l[1459]][l[588]](l[973],l[973]);
        GP[l[1646]]=l[229];
        GP[l[1451]]=y[30](Q);
        GP[l[936]]=c[l[1095]];
        GP[l[2]]=l[986];
        GP[l[537]]=E+l[229];
        GP[l[1557]]=yP[l[128]][l[1557]][l[220]];
        GP[l[711]]=l[786];
        u(JP,GP,R);
      end
      return a(l[1070],{[l[1150]]=f(),[l[1347]]=yP[l[128]][l[1347]][l[1437]],[l[1639]]=yP[l[1459]][l[588]](l[393],l[1707]),[l[1646]]=l[229],[l[437]]=yP[l[128]][l[437]][l[807]],[l[1420]]=g,[l[510]]=c[l[1095]],[l[723]]=l[558],[l[916]]=l[1296],[l[537]]=E+l[59],[l[711]]=l[786]},R);
    end
    y[519]=i;
    y[520]=l[1707];
    y[518]=l[1150];
    local E=y[519](y[520],nil,y[13][y[518]],l[383]);
    local Q=i(l[1249],l[903],l[121]);
    local R=i(l[906],l[1256],l[983]--[[delay]]);
    local g=i(l[1656],l[1587],l[795]);
    t={[Q]=LP(l[357],l[558]),[R]=LP(l[470],l[558]),[g]=LP(l[795],l[558])};
    for i,u in y[3],t,nil do
      y[521]=l[1347];
      y[522]=l[128];
      y[523]=y[1][y[522]][l[1347]][l[31]];
      i[y[521]]=y[523];
      y[524]=l[1639];
      y[525]=l[1459];
      y[526]=(y[1][y[525]][l[588]](u,l[1707]));
      i[y[524]]=y[526];
      y[527]=l[1634];
      y[528]=l[128];
      y[529]=y[1][y[528]][l[1634]][l[701]];
      i[y[527]]=y[529];
    end;
    local i=F;
    F=function()
      return i and i()or W(ZP,l[1158]);
    end;
    local i=l[1329];
    local function t()
      local u,yP=y[18][l[1185]]and l[383]or l[1329],i;
      if u==yP then
        return;
      end
      i=u;
      if u then
        ZP[l[1324]]=l[383];
      end
      local yP=ZP[l[1569]];
      local JP=u and l[393]or l[229];
      b(ZP,u and l[1431]or l[120],u and N or q,function(u)
        ZP[l[1569]]=yP+(JP-yP)*u;
        local yP=u>=l[229]and not i;
        if yP then
          ZP[l[1324]]=l[1329];
        end
      end);
    end
    local i;
    y[530]=l[1146];
    y[1][y[530]](function()
      local u=s[87]();
      i=u[l[188]](u[l[1458]]:GetService(l[1239]));
    end);
    local function u()
      local yP,JP=s[87](),i;
      if not JP then
        return l[393];
      end
      local JP,GP=yP[l[1146]](function()
        local YP=i;
        return YP[l[1611]][l[272]][l[497]]:GetValue();
      end);
      if not JP or yP[l[40]](GP)~=l[384] then
        return l[393];
      end
      return yP[l[35]][l[499]](GP+l[659]);
    end
    local i=l[393];
    local yP=l[393];
    y[532]=d;
    y[531]=l[1119];
    y[532](y[10][y[531]],function(JP)
      local GP={};
      local YP,eP=s[87](),i;
      i=eP+l[229];
      yP+=JP;
      JP=yP;
      if JP<l[659] then
        return;
      end
      local JP,eP,jP=YP[l[35]][l[499]](i/yP+l[659]),l[393],l[393];
      i,yP=eP,jP;
      if not ZP[l[1324]] then
        return;
      end
      if E[l[1420]]~=y[13][l[1150]] then
        GP[1]=E;
        GP[2]=l[1420];
        GP[3]=y[13][l[1150]];
        GP[1][GP[2]]=GP[3];
      end
      Q[l[1420]]=YP[l[1130]](JP);
      R[l[1420]]=YP[l[1130]](u())..l[403];
      g[l[1420]]=YP[l[655]][l[10]](l[962]);
    end);
    y[533]=l[187];
    y[534]=l[409];
    y[535]=function()
      return dP(HP[l[948]]);
    end;
    y[536]=function(i)
      local E=PP(i);
      if E then
        HP[l[948]]=E;
      end
    end;
    y[18]:hook(y[533],y[534],y[535],y[536]);
    y[537]=l[224];
    y[538]=l[409];
    y[539]=function()
      return dP(ZP[l[948]]);
    end;
    y[540]=function(i)
      local E=PP(i);
      if E then
        ZP[l[948]]=E;
      end
    end;
    y[18]:hook(y[537],y[538],y[539],y[540]);
    local function i(E,E)
      local Q={};
      Q[1]=y[18];
      Q[2]=l[1185];
      Q[3]=E and l[383]or l[1329];
      Q[1][Q[2]]=Q[3];
      t();
    end
    y[541]=l[679];
    y[18][y[541]]=i;
    local function i(E,Q)
      E=s[87]();
      if E[l[1703]](Q)==l[1459] then
        ZP[l[948]]=Q;
      end
    end
    y[542]=l[1362];
    y[18][y[542]]=i;
    y[543]=l[1420];
    y[544]=l[655];
    y[545]=(y[1][y[544]][l[10]](l[962]));
    g[y[543]]=y[545];
    t();
    y[546]=l[319];
    y[547]=l[388];
    y[548]=y[18][y[547]];
    y[18][y[546]]=y[548];
    y[567]=a;
    y[568]=l[1742];
    y[549]={};
    y[549][l[1150]]=f();
    y[551]=l[1016];
    y[550]=l[1689];
    y[549][y[551]]=y[1][y[550]][l[772]](l[229],l[659]);
    y[553]=l[948];
    y[552]=l[1459];
    y[549][y[553]]=y[1][y[552]][l[772]](l[229],l[1026],l[659],l[393]);
    y[555]=l[1639];
    y[554]=l[1459];
    y[549][y[555]]=y[1][y[554]][l[588]](l[161],l[161]);
    y[549][l[1646]]=l[229];
    y[549][l[1418]]=l[393];
    y[560]=l[1451];
    y[556]=l[409];
    y[558]=y[1][y[556]][l[846]];
    y[559]=l[1303];
    y[557]=l[1675];
    y[549][y[560]]=y[558](y[559],y[13][y[557]]);
    y[562]=l[936];
    y[561]=l[360];
    y[549][y[562]]=y[1][y[561]][l[772]](l[229],l[229],l[229]);
    y[564]=l[1557];
    y[563]=l[128];
    y[549][y[564]]=y[1][y[563]][l[1557]][l[220]];
    y[566]=l[1324];
    y[565]=l[319];
    y[549][y[566]]=y[18][y[565]];
    y[549][l[43]]=l[383];
    y[549][l[711]]=l[1640];
    local i=y[567](y[568],y[549],x);
    _(i,i,l[1209]);
    local E;
    local Q=l[393];
    d(i[l[1558]],function(t)
      local R=s[87]();
      local g=t[l[1317]]==R[l[128]][l[1317]][l[1356]]or t[l[1317]]==R[l[128]][l[1317]][l[239]];
      if g then
        local g,u=t[l[948]],R[l[655]][l[1587]]();
        E,Q=g,u;
      end
    end);
    d(i[l[412]],function(t)
      local R=s[87]();
      if t[l[1317]]~=R[l[128]][l[1317]][l[1356]]and t[l[1317]]~=R[l[128]][l[1317]][l[239]] then
        return;
      end
      local g=E;
      local u=g;
      E=nil;
      local E,yP=not u;
      if E then
        yP=E;
      else
        g=S;
        yP=g>l[393];
      end
      if yP then
        return;
      end
      yP=(t[l[948]]-u)[l[945]]>l[930]or R[l[655]][l[1587]]()-Q>l[509];
      if yP then
        return;
      end
      for E,E in y[3],y[18][l[769]],nil do
        R[l[1146]](function()
          E:toggle();
        end);
      end;
    end);
    y[569]=l[797];
    y[570]=l[409];
    y[571]=function()
      return dP(i[l[948]]);
    end;
    y[572]=function(E)
      local Q=PP(E);
      if Q then
        i[l[948]]=Q;
      end
    end;
    y[18]:hook(y[569],y[570],y[571],y[572]);
    local function E(Q,Q)
      local t={};
      t[1]=y[18];
      t[2]=l[319];
      t[3]=Q and l[383]or l[1329];
      t[1][t[2]]=t[3];
      t[4]=i;
      t[5]=l[1324];
      t[6]=y[18][l[319]];
      t[4][t[5]]=t[6];
    end
    y[573]=l[1202];
    y[18][y[573]]=E;
    local function E(Q,t)
      Q=s[87]();
      if Q[l[1703]](t)==l[1459] then
        i[l[948]]=t;
      end
    end
    y[574]=l[1393];
    y[18][y[574]]=E;
    local function E(Q,t)
      Q=s[87]();
      i[l[1451]]=Q[l[1130]](t);
    end
    y[575]=l[97];
    y[18][y[575]]=E;
    y[585]=a;
    y[586]=l[211];
    y[576]={};
    y[576][l[1150]]=f();
    y[578]=l[1016];
    y[577]=l[1689];
    y[576][y[578]]=y[1][y[577]][l[772]](l[393],l[393]);
    y[580]=l[948];
    y[579]=l[1459];
    y[576][y[580]]=y[1][y[579]][l[772]](l[393],l[352],l[393],l[352]);
    y[582]=l[1639];
    y[581]=l[1459];
    y[576][y[582]]=y[1][y[581]][l[588]](l[737],l[393]);
    y[584]=l[1347];
    y[583]=l[128];
    y[576][y[584]]=y[1][y[583]][l[1347]][l[636]];
    y[576][l[1646]]=l[229];
    y[576][l[711]]=l[1651];
    local i=y[585](y[586],y[576],x);
    Z(i);
    local E={};
    local Q=l[393];
    local function t(R)
      local g,u=s[87](),l[393];
      for yP=l[229],#E,l[229]do
        local JP=E[yP];
        yP=JP[l[351]];
        if yP and yP[l[382]] then
          local HP=g[l[1459]][l[588]](l[393],u);
          if JP==R or JP[l[1662]]==nil then
            yP[l[948]]=HP;
          elseif JP[l[1662]]~=u then
            P(yP,H,{[l[948]]=HP});
          end
          JP[l[1662]]=u;
          u+=(JP[l[1754]]or yP[l[1639]][l[636]][l[1485]])+l[930];
        else
        end
      end;
    end
    y[587]=l[801];
    y[588]=l[383];
    y[18][y[587]]=y[588];
    y[589]=l[547];
    y[590]=l[303];
    y[18][y[589]]=y[590];
    local function R(g,g)
      local u={};
      u[1]=y[18];
      u[2]=l[801];
      u[3]=g and l[383]or l[1329];
      u[1][u[2]]=u[3];
    end
    y[591]=l[1212];
    y[18][y[591]]=R;
    local function R(g,u)
      g=s[87]();
      if not y[18][l[630]]or not y[18][l[801]] then
        return;
      end
      u=X(u,{[l[1434]]=l[1645],[l[1095]]=l[1746],[l[13]]=l[531],[l[440]]=l[303],[l[73]]=nil});
      local yP,JP,HP,dP=y[18][l[131]],l[737],g[l[1130]](u[l[1434]]or l[1746]),g[l[1130]](u[l[1095]]or l[1746]);
      local PP,ZP=g[l[1703]](u[l[73]])==l[360]and u[l[73]]or yP[l[98]],l[393];
      ZP=if dP~=l[1746]then g[l[35]][l[819]](g[l[35]][l[139]](LP(dP,l[1307])/l[1224]),l[229],l[786])else ZP;
      local LP,GP=l[941]+(ZP>l[393]and ZP*l[310]+l[863]or l[393]),Q;
      Q=GP+l[229];
      local YP=a(l[1751],{[l[1150]]=f(),[l[1639]]=g[l[1459]][l[588]](JP,LP),[l[1535]]=yP[l[675]],[l[1646]]=l[393],[l[1418]]=l[393],[l[1569]]=l[229],[l[537]]=Q,[l[711]]=l[1651]},i);
      D(YP,l[1092]);
      a(l[734],{[l[1630]]=yP[l[966]],[l[1544]]=l[229],[l[747]]=l[323],[l[1161]]=g[l[128]][l[1161]][l[1741]],[l[371]]=g[l[128]][l[371]][l[808]]},YP);
      if nP then
        a(l[1198],{[l[1630]]=yP[l[641]],[l[258]]=g[l[740]][l[772]](l[393],l[558]),[l[1485]]=g[l[1459]][l[588]](l[393],l[863]),[l[1326]]=g[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[1431],[l[711]]=l[715]},YP);
      end
      local i=a(l[211],{[l[1150]]=f(),[l[1639]]=g[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=yP[l[1529]--[[cancel]]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[1651]},YP);
      D(i,l[1092]);
      K(i,l[117],{g[l[677]][l[772]](l[393],l[659]),g[l[677]][l[772]](l[1419],l[70]),g[l[677]][l[772]](l[229],l[387])});
      K(a(l[211],{[l[1150]]=f(),[l[1016]]=g[l[1689]][l[772]](l[659],l[393]),[l[948]]=g[l[1459]][l[772]](l[659],l[393],l[393],l[229]),[l[1639]]=g[l[1459]][l[772]](l[229],l[992]--[[readi8]],l[393],l[229]),[l[1535]]=yP[l[1529]--[[cancel]]],[l[1646]]=l[509],[l[1418]]=l[393],[l[711]]=l[1237]},YP),l[393],{g[l[677]][l[772]](l[393],l[229]),g[l[677]][l[772]](l[659],l[1209]),g[l[677]][l[772]](l[229],l[229])});
      K(a(l[211],{[l[1150]]=f(),[l[1639]]=g[l[1459]][l[772]](l[393],l[59],l[229],l[393]),[l[1535]]=PP,[l[1646]]=l[263],[l[1418]]=l[393],[l[711]]=l[1237]},YP),l[117],{g[l[677]][l[772]](l[393],l[229]),g[l[677]][l[772]](l[841],l[874]),g[l[677]][l[772]](l[659],l[393]),g[l[677]][l[772]](l[804],l[874]),g[l[677]][l[772]](l[229],l[229])});
      local Q=a;
      local eP=l[859];
      local jP={};
      jP[l[1150]]=f();
      jP[l[948]]=g[l[1459]][l[588]](l[1307],l[1092]);
      jP[l[1639]]=g[l[1459]][l[588]](l[750],l[750]);
      jP[l[1646]]=l[229];
      jP[l[1451]]=y[30](u[l[13]]);
      jP[l[936]]=PP;
      jP[l[2]]=l[1296];
      jP[l[1557]]=g[l[128]][l[1557]][l[220]];
      jP[l[711]]=l[1237];
      Q(eP,jP,YP);
      a(l[1070],{[l[1150]]=f(),[l[948]]=g[l[1459]][l[588]](l[1596]--[[__newindex]],l[303]),[l[1639]]=g[l[1459]][l[772]](l[229],l[1614],l[393],l[114]),[l[1646]]=l[229],[l[437]]=g[l[128]][l[437]][l[807]],[l[1420]]=HP,[l[510]]=yP[l[1095]],[l[723]]=l[750],[l[916]]=l[1296],[l[164]]=g[l[128]][l[164]][l[1021]],[l[1634]]=g[l[128]][l[1634]][l[701]],[l[711]]=l[1237]},YP);
      if ZP>l[393] then
        a(l[1070],{[l[1150]]=f(),[l[948]]=g[l[1459]][l[588]](l[1596]--[[__newindex]],l[884]),[l[1639]]=g[l[1459]][l[772]](l[229],l[1099],l[393],ZP*l[310]),[l[1646]]=l[229],[l[437]]=g[l[128]][l[437]][l[807]],[l[1420]]=dP,[l[510]]=yP[l[1379]],[l[723]]=l[1307],[l[916]]=l[263],[l[789]]=l[383],[l[1634]]=g[l[128]][l[1634]][l[701]],[l[65]]=g[l[128]][l[65]][l[1728]],[l[711]]=l[1237]},YP);
      end
      dP=a(l[211],{[l[1150]]=f(),[l[1016]]=g[l[1689]][l[772]](l[393],l[229]),[l[948]]=g[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=g[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=PP,[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1001]},YP);
      K(dP,l[393],{g[l[677]][l[772]](l[393],l[229]),g[l[677]][l[772]](l[841],l[874]),g[l[677]][l[772]](l[659],l[393]),g[l[677]][l[772]](l[804],l[874]),g[l[677]][l[772]](l[229],l[229])});
      HP=a(l[1742],{[l[1150]]=f(),[l[1639]]=g[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1376]},YP);
      local function Q(ZP,eP)
        local jP=YP[l[1569]];
        local CP=ZP and l[393]or l[229];
        b(YP,ZP and l[1431]or l[120],ZP and N or q,function(ZP)
          YP[l[1569]]=jP+(CP-jP)*ZP;
          if ZP>=l[229]and eP then
            eP();
          end
        end);
      end
      local ZP={[l[351]]=YP,[l[1754]]=LP,[l[436]]=l[1329]};
      local function eP(jP)
        if ZP[l[436]] then
          return;
        end
        ZP[l[436]]=l[383];
        Q(l[1329],function()
          local jP=s[87]();
          local CP=jP[l[1346]][l[23]](E,ZP);
          if CP then
            jP[l[1346]][l[1357]](E,CP);
          end
          YP:Destroy();
          t();
        end);
      end
      ZP[l[914]]=eP;
      g[l[1346]][l[968]](E,ZP);
      t(ZP);
      eP=l[393];
      LP=(g[l[35]][l[850]](y[18][l[547]],l[229]));
      for t=#E,l[229],l[715]do
        JP=E[t];
        if not JP[l[436]] then
          eP+=l[229];
          if eP>LP then
            JP:close();
          end
        else
        end
      end;
      d(HP[l[445]],function()
        y[18]:chime(l[1320]);
        ZP:close();
      end);
      d(HP[l[1538]],function()
        P(i,H,{[l[1646]]=l[411]});
      end);
      d(HP[l[1628]],function()
        P(i,H,{[l[1646]]=l[70]});
      end);
      Q(l[383]);
      LP,yP,HP=g[l[35]][l[850]](g[l[1382]](u[l[440]])or l[303],l[330]),g[l[1725]][l[772]],g[l[128]];
      PP,GP=HP[l[1353]],l[1748];
      HP,eP=yP(LP,PP[GP]),{};
      eP[l[1639]]=g[l[1459]][l[772]](l[393],l[393],l[393],l[59]);
      P(dP,HP,eP);
      g[l[1022]][l[1330]](LP,function()
        ZP:close();
      end);
      return ZP;
    end
    y[592]=l[578];
    y[18][y[592]]=R;
    y[593]=l[30];
    y[594]={};
    y[18][y[593]]=y[594];
    local function i(E)
      local Q=s[87]();
      for t,t in y[3],E[l[1271]],nil do
        t:Destroy();
      end;
      Q[l[1346]][l[267]](E[l[1271]]);
      local t=y[18][l[131]];
      for R,g in y[3],y[18][l[30]],nil do
        local u=a(l[1742],{[l[1150]]=f(),[l[1016]]=Q[l[1689]][l[772]](l[393],l[659]),[l[948]]=Q[l[1459]][l[772]](l[393],l[829]+(R-l[229])*l[688],l[659],l[59]),[l[1639]]=Q[l[1459]][l[588]](l[1243],l[1243]),[l[1535]]=t[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=g[l[1736]]or l[1746],[l[936]]=t[l[1379]],[l[2]]=l[263],[l[1557]]=Q[l[128]][l[1557]][l[220]],[l[711]]=l[930]},E[l[836]]);
        D(u,l[1158]);
        d(u[l[1538]],function()
          P(u,H,{[l[2]]=l[393],[l[936]]=t[l[1095]],[l[1646]]=l[323]});
        end);
        d(u[l[1628]],function()
          P(u,H,{[l[2]]=l[263],[l[936]]=t[l[1379]],[l[1646]]=l[229]});
        end);
        d(u[l[445]],function()
          local Q=s[87]();
          y[18]:chime(l[1320]);
          if Q[l[40]](g[l[1617]])==l[1712] then
            Q[l[1022]][l[281]](g[l[1617]]);
          end
        end);
        E[l[1271]][R]=u;
      end;
    end
    y[595]=l[1277];
    y[18][y[595]]=i;
    local function i(E,Q)
      local t={};
      E=s[87]();
      t[1]=y[18];
      t[2]=l[30];
      t[3]=E[l[40]](Q)==l[1346]and Q or{};
      t[1][t[2]]=t[3];
      for E,E in y[3],y[18][l[602]]or{},nil do
        y[18][l[1277]](E);
      end;
    end
    y[596]=l[513];
    y[18][y[596]]=i;
    local function i(E,Q)
      local t={};
      E=s[87]();
      t[2]=X;
      t[3]=Q;
      t[1]={};
      t[1][l[560]]=y[18][l[560]];
      t[1][l[1096]]=E[l[1459]][l[588]](l[1007],l[1709]);
      t[1][l[1132]]=l[601];
      t[1][l[646]]=l[551];
      t[1][l[1686]]=l[1383];
      Q=(t[2](t[3],t[1]));
      local R=y[18][l[131]];
      local g,u=Q[l[646]],Q[l[1132]];
      local LP={[l[1096]]=Q[l[1096]],[l[1600]]=l[383],[l[1206]]={},[l[1686]]=E[l[1703]](Q[l[1686]])==l[802]and Q[l[1686]]or E[l[128]][l[880]--[[readu32]]][Q[l[1686]]]};
      local yP=E[l[1458]]:GetService(l[1597]);
      local JP=l[398];
      local function HP()
        local dP=s[87]();
        dP[l[1146]](function()
          yP:UnbindAction(JP);
        end);
        if not LP[l[1686]] then
          return;
        end
        dP[l[1146]](function()
          local dP=s[87]();
          yP:BindActionAtPriority(JP,function(PP,ZP)
            PP=s[87]();
            if ZP==PP[l[128]][l[1101]][l[115]] then
              LP:toggle();
            end
            return PP[l[128]][l[1235]][l[1267]];
          end,l[1329],dP[l[128]][l[1345]][l[1170]][l[216]],LP[l[1686]]);
        end);
      end
      local dP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[1016]]=E[l[1689]][l[772]](l[659],l[659]),[l[948]]=E[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=Q[l[1096]],[l[1646]]=l[229],[l[1418]]=l[393]},x);
      Z(dP);
      local PP,ZP={},{};
      local GP=k(l[1198]);
      if GP then
        local YP=a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[229]},dP);
        D(YP,g);
        local eP={{E[l[740]][l[772]](l[393],l[829]),E[l[1459]][l[588]](l[59],l[59]),l[874]},{E[l[740]][l[772]](l[393],l[1289]),E[l[1459]][l[588]](l[310],l[310]),l[323]}};
        for jP,CP in y[3],eP,nil do
          PP[jP]=a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=CP[l[229]],[l[1326]]=CP[l[59]],[l[1485]]=E[l[1459]][l[772]](),[l[747]]=l[229],[l[711]]=-jP},YP);
          ZP[jP]=CP[l[863]];
        end;
      else
        local YP={l[615],l[1017],l[1567]};
        for eP,jP in y[3],YP,nil do
          local YP=a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[659]),[l[948]]=E[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=E[l[1459]][l[772]](l[229],eP*l[303],l[229],eP*l[303]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[229]},dP);
          D(YP,g+eP*l[863]);
          PP[eP]=a(l[734],{[l[1630]]=R[l[641]],[l[1544]]=l[863],[l[747]]=l[229]},YP);
          ZP[eP]=jP;
        end;
      end
      local YP=a(l[1751],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=E[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[641]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[711]]=l[59]},dP);
      D(YP,g);
      LP[l[1740]]=Y(YP);
      local Y=a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1707]},YP);
      D(Y,g);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},Y);
      LP[l[191]]=function(eP)
      end;
      local eP,jP=a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[711]]=l[393],[l[43]]=l[383]},YP),a(l[211],{[l[1150]]=f(),[l[948]]=E[l[1459]][l[588]](u,l[393]),[l[1639]]=E[l[1459]][l[772]](l[229],-u,l[229],l[393]),[l[1535]]=R[l[641]],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[229]},YP);
      D(jP,g);
      a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[772]](l[393],g,l[229],l[393]),[l[1535]]=R[l[641]],[l[1418]]=l[393],[l[711]]=l[229]},jP);
      local CP={[l[404]]=l[1329],[l[1040]]=function()
      end};
      local qP=a(l[211],{[l[1150]]=f(),[l[948]]=E[l[1459]][l[588]](l[829],l[829]),[l[1639]]=E[l[1459]][l[772]](l[229],l[1263],l[229],l[1263]),[l[1646]]=l[229],[l[711]]=l[786]},jP);
      local bP=a(l[211],{[l[1150]]=f(),[l[1646]]=l[229],[l[1324]]=l[1329]},x);
      Z(bP);
      local function DP()
        local pP={};
        local rP,KP=s[87](),qP[l[160]];
        if KP[l[1437]]>l[229]and KP[l[636]]>l[229] then
          pP[1]=bP;
          pP[2]=l[1639];
          pP[3]=(rP[l[1459]][l[588]](rP[l[35]][l[499]](KP[l[1437]]/y[29]+l[659]),rP[l[35]][l[499]](KP[l[636]]/y[29]+l[659])));
          pP[1][pP[2]]=pP[3];
        else
          local pP=dP[l[1639]];
          bP[l[1639]]=rP[l[1459]][l[588]](rP[l[35]][l[850]](pP[l[1437]][l[1485]]-u-l[913],l[229]),rP[l[35]][l[850]](pP[l[636]][l[1485]]-l[913],l[229]));
        end
      end
      DP();
      d(qP:GetPropertyChangedSignal(l[160]),DP);
      d(dP:GetPropertyChangedSignal(l[1639]),DP);
      DP,Y=E[l[1488]],{[l[277]]=l[1540]};
      local pP=DP({},Y);
      local function rP(KP)
        local oP={};
        local cP=s[87]();
        if pP[KP]or not KP:IsA(l[957]) then
          return;
        end
        pP[KP]=l[383];
        if not KP[l[1324]] then
          oP[1]=y[18][l[394]];
          oP[2]=l[383];
          oP[1][KP]=oP[2];
        end
        local function pP()
          if KP[l[1324]] then
            if KP[l[382]]==bP then
              KP[l[382]]=YP;
            end
          elseif KP[l[382]]==YP or KP[l[382]]==LP[l[1740]] then
            KP[l[382]]=bP;
          end
        end
        d(KP:GetPropertyChangedSignal(l[1324]),pP);
        cP[l[1022]][l[1061]](pP);
      end
      d(YP[l[74]],rP);
      rP=a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[772]](l[393],u,l[229],l[393]),[l[1535]]=R[l[1132]],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[303]},YP);
      D(rP,g);
      a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[229],l[393]),[l[948]]=E[l[1459]][l[1368]](l[229],l[393]),[l[1639]]=E[l[1459]][l[772]](l[393],g,l[229],l[393]),[l[1535]]=R[l[1132]],[l[1418]]=l[393],[l[711]]=l[303]},rP);
      Y=a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[659]),[l[948]]=E[l[1459]][l[772]](l[393],u,l[659],l[393]),[l[1639]]=E[l[1459]][l[772]](l[393],l[829],l[229],l[393]),[l[1646]]=l[229],[l[711]]=l[930]},YP);
      K(a(l[211],{[l[1150]]=f(),[l[1639]]=E[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[1529]--[[cancel]]],[l[1646]]=l[387],[l[1418]]=l[393],[l[711]]=l[930]},Y),l[393],{E[l[677]][l[772]](l[393],l[229]),E[l[677]][l[772]](l[659],l[615]),E[l[677]][l[772]](l[229],l[229])});
      K(a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[659]),[l[948]]=E[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=E[l[1459]][l[772]](l[393],l[229],l[229],l[393]),[l[1535]]=R[l[966]],[l[1418]]=l[393],[l[711]]=l[551]},Y),l[117],{E[l[677]][l[772]](l[393],l[229]),E[l[677]][l[772]](l[841],l[986]),E[l[677]][l[772]](l[804],l[986]),E[l[677]][l[772]](l[229],l[229])});
      local u=a(l[859],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[393]),[l[948]]=E[l[1459]][l[772]](l[659],l[393],l[393],l[558]),[l[1639]]=E[l[1459]][l[588]](l[813],l[813]),[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=Q[l[560]],[l[936]]=R[l[98]],[l[1557]]=E[l[128]][l[1557]][l[220]],[l[711]]=l[1092]},rP);
      LP[l[773]]=u;
      g=a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[393]),[l[948]]=E[l[1459]][l[772]](l[659],l[393],l[393],l[827]),[l[1639]]=E[l[1459]][l[772]](l[229],l[662],l[393],l[229]),[l[1535]]=R[l[966]],[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1092]},rP);
      K(g,l[393],{E[l[677]][l[772]](l[393],l[229]),E[l[677]][l[772]](l[659],l[874]),E[l[677]][l[772]](l[229],l[229])});
      local Q=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=E[l[1459]][l[588]](l[1158],l[535]),[l[1639]]=E[l[1459]][l[772]](l[229],l[1504],l[229],l[419]),[l[1646]]=l[229],[l[1418]]=l[393],[l[969]]=l[393],[l[392]]=E[l[1459]][l[772]](),[l[711]]=l[1092]},rP);
      local pP=a(l[755],{[l[407]]=E[l[128]][l[407]][l[537]],[l[536]]=E[l[740]][l[772]](l[393],l[863])},Q);
      d(pP:GetPropertyChangedSignal(l[996]),function()
        local KP=s[87]();
        Q[l[392]]=KP[l[1459]][l[588]](l[393],j(pP)[l[636]]+l[59]);
      end);
      y[18][l[1678]](Q);
      K(a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[229]),[l[948]]=E[l[1459]][l[772]](l[659],l[393],l[229],l[132]),[l[1639]]=E[l[1459]][l[772]](l[229],l[662],l[393],l[229]),[l[1535]]=R[l[966]],[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1092]},rP),l[393],{E[l[677]][l[772]](l[393],l[229]),E[l[677]][l[772]](l[659],l[874]),E[l[677]][l[772]](l[229],l[229])});
      DP=a(l[211],{[l[1150]]=f(),[l[1016]]=E[l[1689]][l[772]](l[659],l[229]),[l[948]]=E[l[1459]][l[772]](l[659],l[393],l[229],l[1519]),[l[1639]]=E[l[1459]][l[772]](l[229],l[1504],l[393],l[520]),[l[1535]]=R[l[1466]],[l[1646]]=l[986],[l[1418]]=l[393],[l[711]]=l[1092]},rP);
      D(DP,l[930]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1567]},DP);
      t[5]=a;
      t[6]=l[859];
      t[4]={};
      t[4][l[1150]]=f();
      t[4][l[1016]]=E[l[1689]][l[772]](l[393],l[659]);
      t[4][l[948]]=E[l[1459]][l[772]](l[393],l[1158],l[659],l[393]);
      t[4][l[1639]]=E[l[1459]][l[588]](l[913],l[913]);
      t[4][l[1535]]=R[l[675]];
      t[4][l[1418]]=l[393];
      t[4][l[1451]]=E[l[409]][l[846]](l[1303],y[13][l[1675]]);
      t[4][l[1557]]=E[l[128]][l[1557]][l[574]];
      t[4][l[711]]=l[930];
      local pP,KP,oP=t[5](t[6],t[4],DP),l[1112],{};
      oP[l[1182]]=E[l[740]][l[772]](l[229],l[393]);
      a(KP,oP,pP);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[323]},pP);
      t[8]=a;
      t[9]=l[1070];
      t[7]={};
      t[7][l[1150]]=f();
      t[7][l[948]]=E[l[1459]][l[588]](l[1157],l[1158]);
      t[7][l[1639]]=E[l[1459]][l[772]](l[229],l[1601],l[393],l[973]);
      t[7][l[1646]]=l[229];
      t[7][l[437]]=E[l[128]][l[437]][l[1381]];
      t[7][l[1420]]=y[13][l[195]];
      t[7][l[510]]=R[l[1095]];
      t[7][l[723]]=l[750];
      t[7][l[164]]=E[l[128]][l[164]][l[1021]];
      t[7][l[1634]]=E[l[128]][l[1634]][l[701]];
      t[7][l[711]]=l[930];
      local pP=t[8](t[9],t[7],DP);
      t[11]=a;
      t[12]=l[1070];
      t[10]={};
      t[10][l[1150]]=f();
      t[10][l[948]]=E[l[1459]][l[588]](l[1157],l[1243]);
      t[10][l[1639]]=E[l[1459]][l[772]](l[229],l[1601],l[393],l[750]);
      t[10][l[1646]]=l[229];
      t[10][l[437]]=E[l[128]][l[437]][l[1381]];
      t[10][l[1420]]=l[413]..y[13][l[1150]];
      t[10][l[510]]=R[l[1379]];
      t[10][l[723]]=l[1307];
      t[10][l[916]]=l[1431];
      t[10][l[164]]=E[l[128]][l[164]][l[1021]];
      t[10][l[1634]]=E[l[128]][l[1634]][l[701]];
      t[10][l[711]]=l[930];
      t[11](t[12],t[10],DP);
      d(y[13]:GetPropertyChangedSignal(l[195]),function()
        local t={};
        t[1]=pP;
        t[2]=l[1420];
        t[3]=y[13][l[195]];
        t[1][t[2]]=t[3];
      end);
      if y[18][l[388]] then
        u[l[1324]]=l[1329];
        g[l[1324]]=l[1329];
        LP[l[1717]]=a(l[211],{[l[1150]]=f(),[l[948]]=E[l[1459]][l[588]](l[1158],l[1158]),[l[1639]]=E[l[1459]][l[772]](l[229],l[1504],l[304],l[348]),[l[1646]]=l[229],[l[711]]=l[1092]},rP);
        Q[l[948]]=E[l[1459]][l[772]](l[393],l[1158],l[304],l[786]);
        Q[l[1639]]=E[l[1459]][l[772]](l[229],l[1504],l[52],l[1106]);
      end
      local t,g=l[393];
      local function DP(pP,KP,oP)
        local cP=s[87]();
        local mP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=cP[l[1459]][l[588]](l[730],l[906]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[1274],l[393],l[919]),[l[1535]]=cP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1158]},pP);
        D(mP,l[1158]);
        local SP=a(l[211],{[l[1150]]=f(),[l[1639]]=cP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=cP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1249]},mP);
        D(SP,l[1158]);
        local OP,BP=l[1622],{[l[1630]]=cP[l[1262]][l[772]](cP[l[360]][l[772]](l[229],l[229],l[229]))};
        BP[l[747]]=cP[l[1197]][l[772]]({cP[l[677]][l[772]](l[393],l[393]),cP[l[677]][l[772]](l[229],l[229])});
        a(OP,BP,SP);
        SP=a(l[211],{[l[1150]]=f(),[l[1639]]=cP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=cP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1249]},mP);
        D(SP,l[1158]);
        OP,BP=l[1622],{[l[1630]]=cP[l[1262]][l[772]](cP[l[360]][l[772]]()),[l[500]]=l[117]};
        BP[l[747]]=cP[l[1197]][l[772]]({cP[l[677]][l[772]](l[393],l[229]),cP[l[677]][l[772]](l[229],l[393])});
        a(OP,BP,SP);
        a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},mP);
        local AP=a(l[211],{[l[1150]]=f(),[l[1016]]=cP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=cP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1596]--[[__newindex]]},mP);
        SP,OP=l[1112],{};
        OP[l[1182]]=cP[l[740]][l[772]](l[229],l[393]);
        a(SP,OP,AP);
        a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},AP);
        local wP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=cP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=cP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1158]},pP);
        D(wP,l[303]);
        a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},wP);
        OP={};
        for FP=l[393],l[1158],l[229]do
          cP[l[1346]][l[968]](OP,cP[l[527]][l[772]](FP/l[1158],cP[l[360]][l[149]](FP/l[1158],l[229],l[229])));
        end;
        SP,BP=l[1622],{};
        BP[l[1630]]=cP[l[1262]][l[772]](OP);
        a(SP,BP,wP);
        local BP=a(l[211],{[l[1150]]=f(),[l[1016]]=cP[l[1689]][l[772]](l[659],l[659]),[l[948]]=cP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=cP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1596]--[[__newindex]]},wP);
        OP,SP=l[1112],{};
        SP[l[1182]]=cP[l[740]][l[772]](l[229],l[393]);
        a(OP,SP,BP);
        a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},BP);
        local SP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=cP[l[1459]][l[588]](l[730],l[1201]),[l[1639]]=cP[l[1459]][l[772]](l[229],l[865],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[437]]=cP[l[128]][l[437]][l[1381]],[l[1420]]=p(KP[l[1409]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[1158]},pP);
        D(SP,l[303]);
        local OP={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
        OP[l[434]],OP[l[900]],OP[l[999]]=cP[l[360]][l[1412]](KP[l[1409]]);
        local function cP(FP,hP)
          local WP=s[87]();
          local VP,_P,XP=WP[l[360]][l[149]](OP[l[434]],OP[l[900]],OP[l[999]]),WP[l[1459]][l[1368]](OP[l[900]],l[229]-OP[l[999]]),WP[l[1459]][l[772]](OP[l[434]],l[393],l[659],l[393]);
          if hP then
            AP[l[948]]=_P;
            BP[l[948]]=XP;
            AP[l[1535]]=VP;
            mP[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229]);
            if KP[l[275]] then
              KP[l[275]][l[1535]]=VP;
            end
          else
            P(AP,n,{[l[948]]=_P,[l[1535]]=VP});
            P(BP,n,{[l[948]]=XP});
            P(mP,n,{[l[1535]]=WP[l[360]][l[149]](OP[l[434]],l[229],l[229])});
            if KP[l[275]] then
              P(KP[l[275]],n,{[l[1535]]=VP});
            end
          end
          if not SP:IsFocused() then
            SP[l[1420]]=p(VP);
          end
          KP[l[1328]](VP,FP);
        end
        local KP=(function()
          local BP=pP[l[382]];
          while BP and BP~=x do
            local pP=l[1439];
            if BP:IsA(pP) then
              return BP;
            end
            BP=BP[l[382]];
          end;
        end)();
        local function pP()
          if not OP[l[259]] then
            return;
          end
          OP[l[259]]=l[1329];
          OP[l[700]]=nil;
          if OP[l[1731]] then
            OP[l[1731]]:Disconnect();
            OP[l[1731]]=nil;
          end
          if KP then
            KP[l[1195]]=l[383];
          end
          O(l[715]);
        end
        local function BP()
          local AP=s[87]();
          if OP[l[259]]and OP[l[700]] then
            local FP,hP=AP[l[1146]](function()
              OP[l[700]]();
              cP(l[383],l[383]);
            end);
            if not FP then
              pP();
              AP[l[972]](l[1752]..AP[l[1130]](hP));
            end
          end
        end
        local function AP(FP,hP)
          d(FP[l[956]],pP);
          d(FP[l[1558]],function(WP)
            local VP=s[87]();
            if WP[l[1317]]~=VP[l[128]][l[1317]][l[1356]]and WP[l[1317]]~=VP[l[128]][l[1317]][l[239]] then
              return;
            end
            if OP[l[259]] then
              return;
            end
            OP[l[259]]=l[383];
            OP[l[700]]=hP;
            OP[l[225]]=WP;
            O(l[229]);
            OP[l[1731]]=B(WP,pP);
            if KP then
              KP[l[1195]]=l[1329];
            end
            BP();
          end);
          d(FP[l[412]],function(KP)
            local FP=s[87]();
            if KP[l[1317]]==FP[l[128]][l[1317]][l[1356]]or KP[l[1317]]==FP[l[128]][l[1317]][l[239]]and KP==OP[l[225]] then
              pP();
            end
          end);
        end
        AP(mP,function()
          local KP,FP,hP,WP=s[87](),mP[l[81]],mP[l[160]],v(OP[l[225]]);
          OP[l[900]]=KP[l[35]][l[819]]((WP[l[1437]]-FP[l[1437]])/KP[l[35]][l[850]](hP[l[1437]],l[229]),l[393],l[229]);
          OP[l[999]]=l[229]-KP[l[35]][l[819]]((WP[l[636]]-FP[l[636]])/KP[l[35]][l[850]](hP[l[636]],l[229]),l[393],l[229]);
        end);
        AP(wP,function()
          local KP,mP,AP=s[87](),wP[l[81]],wP[l[160]];
          OP[l[434]]=KP[l[35]][l[819]]((v(OP[l[225]])[l[1437]]-mP[l[1437]])/KP[l[35]][l[850]](AP[l[1437]],l[229]),l[393],l[229]);
        end);
        d(y[9][l[412]],function(KP)
          local mP=s[87]();
          if KP[l[1317]]==mP[l[128]][l[1317]][l[1356]]or KP[l[1317]]==mP[l[128]][l[1317]][l[239]]and KP==OP[l[225]] then
            pP();
          end
        end);
        d(y[9][l[233]],function(pP)
          local KP=s[87]();
          if not OP[l[259]] then
            return;
          end
          if pP[l[1317]]==KP[l[128]][l[1317]][l[765]]or pP[l[1317]]==KP[l[128]][l[1317]][l[239]] then
            if pP[l[1317]]==KP[l[128]][l[1317]][l[239]]and pP~=OP[l[225]] then
              return;
            end
            BP();
          end
        end);
        d(SP[l[722]],function()
          local pP,KP=s[87](),r(SP[l[1420]]);
          if KP then
            OP[l[434]],OP[l[900]],OP[l[999]]=pP[l[360]][l[1412]](KP);
          end
          cP(l[383]);
        end);
        local function pP(KP)
          local mP=s[87]();
          OP[l[434]],OP[l[900]],OP[l[999]]=mP[l[360]][l[1412]](KP);
          cP(l[383]);
        end
        oP[l[391]]=pP;
        cP(l[1329],l[383]);
      end
      local function pP(KP,oP)
        local cP={};
        local mP=s[87]();
        if not y[18][l[602]] then
          cP[1]=y[18];
          cP[2]=l[602];
          cP[3]={};
          cP[1][cP[2]]=cP[3];
        end
        local SP,OP={},{};
        local BP=l[1282];
        oP=oP or l[593];
        for AP=l[229],l[59],l[229]do
          local wP=a(l[1439],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[772]](l[659]*(AP-l[229]),AP==l[229]and l[393]or l[786],l[393],BP),[l[1639]]=mP[l[1459]][l[772]](l[659],l[1024],l[229],-BP),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=mP[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[303]},KP);
          local FP=a(l[755],{[l[407]]=mP[l[128]][l[407]][l[537]],[l[536]]=mP[l[740]][l[772]](l[393],l[551])},wP);
          d(FP:GetPropertyChangedSignal(l[996]),function()
            local hP=s[87]();
            wP[l[392]]=hP[l[1459]][l[588]](l[393],j(FP)[l[636]]+l[786]);
          end);
          SP[AP]={[l[1594]--[[__index]]]=wP,[l[305]]={},[l[668]]=l[393]};
        end;
        local function AP(wP)
          local FP=s[87]();
          if wP==l[1747]or wP==l[863] then
            if not SP[l[863]] then
              local hP=a(l[1439],{[l[1150]]=f(),[l[948]]=FP[l[1459]][l[588]](l[393],BP),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[229],-BP),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=FP[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[303]},KP);
              local BP=a(l[755],{[l[407]]=FP[l[128]][l[407]][l[537]],[l[536]]=FP[l[740]][l[772]](l[393],l[551])},hP);
              d(BP:GetPropertyChangedSignal(l[996]),function()
                local FP=s[87]();
                hP[l[392]]=FP[l[1459]][l[588]](l[393],j(BP)[l[636]]+l[786]);
              end);
              local BP,FP=l[863],{[l[1594]--[[__index]]]=hP,[l[305]]={}};
              FP[l[668]],SP[BP]=l[393],FP;
              SP[l[229]][l[1594]--[[__index]]][l[1324]]=l[1329];
              SP[l[59]][l[1594]--[[__index]]][l[1324]]=l[1329];
            end
            return SP[l[863]];
          end
          return SP[(wP==l[1316]or wP==l[59])and l[59]or l[229]];
        end
        local BP=a(l[211],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[588]](l[286],l[286]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[913],l[393],l[726]),[l[1535]]=R[l[641]],[l[1418]]=l[393],[l[711]]=l[1158]},KP);
        local wP=a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[393],l[659]),[l[948]]=mP[l[1459]][l[772]](l[393],l[393],l[229],l[393]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[393],l[393],l[829]),[l[1646]]=l[229],[l[711]]=l[1158]},BP);
        K(a(l[211],{[l[1150]]=f(),[l[1639]]=mP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[1529]--[[cancel]]],[l[1646]]=l[387],[l[1418]]=l[393],[l[711]]=l[1158]},wP),l[117],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[659],l[615]),mP[l[677]][l[772]](l[229],l[229])});
        K(a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[659],l[659]),[l[948]]=mP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[966]],[l[1418]]=l[393],[l[711]]=l[1092]},wP),l[393],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[841],l[986]),mP[l[677]][l[772]](l[804],l[986]),mP[l[677]][l[772]](l[229],l[229])});
        local FP=a(l[1070],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[588]](l[114],l[863]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[889],l[229],l[1519]),[l[1646]]=l[229],[l[437]]=mP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[558],[l[916]]=l[229],[l[164]]=mP[l[128]][l[164]][l[1021]],[l[1634]]=mP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},BP);
        local hP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[229],l[659]),[l[948]]=mP[l[1459]][l[772]](l[229],l[1435],l[659],l[715]),[l[1639]]=mP[l[1459]][l[772]](l[393],l[393],l[393],l[941]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=mP[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[4],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[558],[l[916]]=l[229],[l[1634]]=mP[l[128]][l[1634]][l[701]],[l[1324]]=l[1329],[l[711]]=l[1092]},BP);
        D(hP,l[930]);
        a(l[1359],{[l[1612]]=mP[l[740]][l[772]](l[393],l[310]),[l[517]]=mP[l[740]][l[772]](l[393],l[310])},hP);
        local WP=a(l[734],{[l[1161]]=mP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1017]},hP);
        local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[659],l[229]),[l[948]]=mP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[1158],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},hP);
        K(VP,l[393],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[659],l[393]),mP[l[677]][l[772]](l[229],l[229])});
        cP[5]=a;
        cP[6]=l[1742];
        cP[4]={};
        cP[4][l[1150]]=f();
        cP[4][l[1016]]=mP[l[1689]][l[772]](l[229],l[659]);
        cP[4][l[948]]=mP[l[1459]][l[772]](l[229],l[774],l[659],l[59]);
        cP[4][l[1639]]=mP[l[1459]][l[588]](l[1243],l[1243]);
        cP[4][l[1535]]=R[l[1466]];
        cP[4][l[1646]]=l[229];
        cP[4][l[1418]]=l[393];
        cP[4][l[1451]]=y[30](l[4]);
        cP[4][l[936]]=R[l[1379]];
        cP[4][l[2]]=l[874];
        cP[4][l[1557]]=mP[l[128]][l[1557]][l[220]];
        cP[4][l[711]]=l[930];
        local _P=cP[5](cP[6],cP[4],BP);
        D(_P,l[1158]);
        if y[18][l[388]] then
          cP[8]=a;
          cP[9]=l[1742];
          cP[7]={};
          cP[7][l[1150]]=f();
          cP[7][l[1016]]=mP[l[1689]][l[772]](l[229],l[659]);
          cP[7][l[948]]=mP[l[1459]][l[772]](l[229],l[992]--[[readi8]],l[659],l[59]);
          cP[7][l[1639]]=mP[l[1459]][l[588]](l[1655],l[1655]);
          cP[7][l[1646]]=l[229];
          cP[7][l[1418]]=l[393];
          cP[7][l[1451]]=y[30](l[898]);
          cP[7][l[936]]=R[l[1379]];
          cP[7][l[2]]=l[1209];
          cP[7][l[1557]]=mP[l[128]][l[1557]][l[220]];
          cP[7][l[711]]=l[930];
          wP=(cP[8](cP[9],cP[7],BP));
          _P[l[948]]=mP[l[1459]][l[772]](l[229],l[1509],l[659],l[59]);
          hP[l[948]]=mP[l[1459]][l[772]](l[229],l[1650],l[659],l[715]);
          d(wP[l[445]],function()
            LP:toggle();
          end);
        end
        local cP={[l[836]]=BP,[l[1271]]={}};
        mP[l[1346]][l[968]](y[18][l[602]],cP);
        y[18][l[1277]](cP);
        local function mP(BP)
          local wP=s[87]();
          local XP,xP=wP[l[409]][l[56]](wP[l[409]][l[345]](BP or l[1746]),l[381])or l[1746],l[393];
          for kP,kP in y[3],OP,nil do
            local vP,IP,iP=XP==l[1746]or wP[l[409]][l[23]](wP[l[409]][l[345]](kP[l[572]]),XP,l[229],l[383])~=nil,l[1329],l[1329];
            for EP,QP in y[3],kP[l[12]],nil do
              EP=XP~=l[1746]and wP[l[409]][l[23]](wP[l[409]][l[345]](QP[l[572]]),XP,l[229],l[383])~=nil;
              BP=vP or EP;
              if QP[l[266]][l[1324]]~=BP then
                QP[l[266]][l[1324]]=BP;
                IP=l[383];
              else
              end
              iP,xP=iP or BP,if EP then xP+l[229]else xP;
            end;
            if kP[l[1637]] then
              kP[l[1637]](XP~=l[1746]and iP or nil);
            end
            if IP and kP[l[1654]] then
              kP[l[1654]]();
            end
            xP=if vP and XP~=l[1746]then xP+l[229]else xP;
            kP[l[590]][l[1735]](vP or iP);
          end;
          return xP;
        end
        local BP=l[1329];
        local wP=l[393];
        local function XP(xP)
          local kP={};
          local vP,IP=s[87](),BP;
          if IP==xP then
            return;
          end
          BP=xP;
          for IP,IP in y[3],cP[l[1271]],nil do
            IP[l[1324]]=not xP;
          end;
          if xP then
            hP[l[1324]]=l[383];
            kP[1]=_P;
            kP[2]=l[1451];
            kP[3]=(y[30](l[898]));
            kP[1][kP[2]]=kP[3];
            P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[959],l[1435],l[393],l[941]),[l[916]]=l[393]});
            P(WP,H,{[l[747]]=l[615]});
            P(VP,H,{[l[1646]]=l[615]});
            P(_P,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
            vP[l[1022]][l[1330]](l[841],function()
              local cP=BP;
              if cP then
                hP:CaptureFocus();
              end
            end);
          else
            wP=vP[l[655]][l[1587]]();
            kP[4]=_P;
            kP[5]=l[1451];
            kP[6]=(y[30](l[4]));
            kP[4][kP[5]]=kP[6];
            hP:ReleaseFocus();
            if hP[l[1420]]~=l[1746] then
              hP[l[1420]]=l[1746];
            end
            P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[393],l[393],l[393],l[941]),[l[916]]=l[229]});
            P(WP,H,{[l[747]]=l[1017]});
            P(VP,H,{[l[1646]]=l[229]});
            P(_P,H,{[l[2]]=l[874],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
            vP[l[1022]][l[1330]](l[269],function()
              local cP=BP;
              if not cP then
                hP[l[1324]]=l[1329];
              end
            end);
          end
        end
        d(_P[l[445]],function()
          local cP=s[87]();
          local WP=not BP and cP[l[655]][l[1587]]()-wP<l[986];
          if WP then
            return;
          end
          XP(not BP);
        end);
        d(_P[l[1538]],function()
          P(_P,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
        end);
        d(_P[l[1628]],function()
          local cP=BP;
          if not cP then
            P(_P,H,{[l[2]]=l[874],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
          end
        end);
        d(hP:GetPropertyChangedSignal(l[1420]),function()
          local cP,BP=s[87](),mP(hP[l[1420]]);
          local mP=cP[l[409]][l[56]](hP[l[1420]],l[825])~=nil;
          FP[l[1420]]=mP and BP..(BP==l[229]and l[1090]or l[818])or l[1746];
          P(FP,H,{[l[916]]=mP and l[874]or l[229]});
        end);
        d(hP[l[722]],function()
          local cP=s[87]();
          if not cP[l[409]][l[56]](hP[l[1420]],l[825]) then
            XP(l[1329]);
          end
        end);
        local cP={};
        local function mP(BP,wP)
          local FP,hP=s[87](),l[668];
          BP[hP]=BP[hP]+l[229];
          local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[393],wP or l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=BP[l[668]],[l[711]]=l[303]},BP[l[1594]--[[__index]]]);
          local VP=a(l[211],{[l[1150]]=f(),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[393],wP or l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[303]},WP);
          VP:SetAttribute(l[226],l[383]);
          local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=wP and FP[l[1459]][l[772]](l[229],l[393],l[393],wP)or FP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=not wP and FP[l[128]][l[1347]][l[636]]or FP[l[128]][l[1347]][l[31]],[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[711]]=l[303]},VP);
          D(_P,l[1092]);
          hP,wP=l[1622],{[l[500]]=l[117]};
          wP[l[1630]]=FP[l[1262]][l[772]]({FP[l[527]][l[772]](l[393],FP[l[360]][l[772]](l[229],l[229],l[229])),FP[l[527]][l[772]](l[229],FP[l[360]][l[353]](l[291],l[291],l[920]))});
          a(hP,wP,_P);
          if GP then
            a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=FP[l[740]][l[772]](l[393],l[310]),[l[1485]]=FP[l[1459]][l[588]](l[393],l[863]),[l[1326]]=FP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[323],[l[711]]=l[715]},_P);
          end
          local wP={[l[1594]--[[__index]]]=WP,[l[1501]]=VP,[l[675]]=_P,[l[1273]]=l[383]};
          local function hP(XP)
            XP=XP and l[383]or l[1329];
            if wP[l[1273]]==XP then
              return;
            end
            wP[l[1273]]=XP;
            if XP then
              WP[l[1324]]=l[383];
            end
            b(VP,l[304],XP and N or q,function(xP)
              local kP,vP,IP=s[87](),e(_P)[l[636]],XP and xP or l[229]-xP;
              local iP=kP[l[35]][l[499]](vP*IP+l[659]);
              WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
              VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
              _P[l[948]]=kP[l[1459]][l[588]](l[393],-kP[l[35]][l[499]](kP[l[35]][l[457]](l[352],vP)*(l[229]-IP)+l[659]));
              if xP>=l[229] then
                _P[l[948]]=kP[l[1459]][l[772]]();
                WP[l[1324]]=XP;
                if XP then
                  WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
                  VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
                end
              end
            end);
          end
          wP[l[1735]]=hP;
          FP[l[1346]][l[968]](BP[l[305]],wP);
          d(_P:GetPropertyChangedSignal(l[160]),function()
            local BP,FP=s[87](),e(_P)[l[636]];
            if not wP[l[1273]] then
              return;
            end
            WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
            if not C[VP] then
              VP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
            end
          end);
          return _P,wP;
        end
        local function BP()
          cP[l[86]]();
        end
        cP[l[811]]=BP;
        local function BP()
          local wP=s[87]();
          for FP,hP in y[3],SP,nil do
            for SP,SP in y[3],hP[l[305]],nil do
              if SP[l[1273]] then
                FP=C[SP[l[1501]]];
                if FP then
                  FP:Disconnect();
                  C[SP[l[1501]]]=nil;
                end
                SP[l[675]][l[948]]=wP[l[1459]][l[772]]();
                SP[l[1501]][l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],e(SP[l[675]])[l[636]]);
              end
            end;
          end;
        end
        cP[l[86]]=BP;
        local function SP(BP,wP,FP,hP,WP)
          local VP,_P=s[87](),{[l[404]]=l[1329],[l[1273]]=l[1329],[l[230]]=nil,[l[649]]=l[524],[l[1019]]=l[393],[l[559]]=l[1753],[l[434]]=l[393]};
          local XP=WP[l[1019]];
          if XP then
            _P[l[1019]]=VP[l[1382]](XP[l[950]])or XP[l[457]]or l[393];
          end
          local xP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1526]},YP);
          local kP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1282]},YP)or nil;
          local vP=kP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=VP[l[740]][l[772]](l[393],l[829]),[l[1485]]=VP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=VP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},kP)or nil;
          if kP then
            D(kP,l[930]);
          end
          local IP=a(l[1751],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[219]},YP);
          D(IP,l[930]);
          local iP,EP=l[1622],{[l[500]]=l[117]};
          EP[l[1630]]=VP[l[1262]][l[772]]({VP[l[527]][l[772]](l[393],VP[l[360]][l[772]](l[229],l[229],l[229])),VP[l[527]][l[772]](l[229],VP[l[360]][l[353]](l[291],l[291],l[920]))});
          a(iP,EP,IP);
          a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},IP);
          iP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[520]},IP);
          D(iP,l[930]);
          a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},iP);
          EP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[1596]--[[__newindex]]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},IP);
          D(EP,l[930]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[393],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},EP);
          local QP,tP,RP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1274],l[229],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[368]},EP),l[755],{[l[101]]=VP[l[128]][l[101]][l[1505]],[l[1749]]=VP[l[128]][l[1749]][l[46]],[l[1259]]=VP[l[128]][l[1259]][l[46]],[l[407]]=VP[l[128]][l[407]][l[537]]};
          RP[l[536]]=VP[l[740]][l[772]](l[393],l[1092]);
          a(tP,RP,QP);
          local gP=a;
          local uP=l[859];
          local UP={};
          UP[l[1150]]=f();
          UP[l[1639]]=VP[l[1459]][l[588]](l[750],l[750]);
          UP[l[1646]]=l[229];
          UP[l[1451]]=y[30](l[1680]);
          UP[l[936]]=R[l[98]];
          UP[l[2]]=l[841];
          UP[l[537]]=l[229];
          UP[l[1557]]=VP[l[128]][l[1557]][l[220]];
          UP[l[711]]=l[1289];
          gP(uP,UP,QP);
          a(l[1070],{[l[1150]]=f(),[l[1347]]=VP[l[128]][l[1347]][l[1437]],[l[1639]]=VP[l[1459]][l[588]](l[393],l[829]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=wP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[537]]=l[59],[l[711]]=l[1289]},QP);
          K(a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1596]--[[__newindex]]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[966]],[l[1646]]=l[986],[l[1418]]=l[393],[l[711]]=l[368]},IP),l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[820],l[263]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[70],l[263]),VP[l[677]][l[772]](l[229],l[229])});
          local gP=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1282]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=VP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[489]},IP);
          iP,EP=l[755],{[l[407]]=VP[l[128]][l[407]][l[537]]};
          EP[l[536]]=VP[l[740]][l[772]](l[393],l[786]);
          a(iP,EP,gP);
          a(l[1359],{[l[299]]=VP[l[740]][l[772]](l[393],l[1092]),[l[645]]=VP[l[740]][l[772]](l[393],l[930]),[l[1612]]=VP[l[740]][l[772]](l[393],l[1092]),[l[517]]=VP[l[740]][l[772]](l[393],l[1092])},gP);
          local uP=l[393];
          local function UP(MP)
            local sC,lC=s[87](),uP;
            uP=lC+l[229];
            local lC,LC=l[211],{[l[1150]]=f(),[l[1639]]=sC[l[1459]][l[772]](l[229],l[393],l[393],MP),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=uP,[l[711]]=l[489]};
            return a(lC,LC,gP);
          end
          local function uP(MP,sC,lC,LC)
            local yC=s[87]();
            return a(l[1070],{[l[1150]]=f(),[l[948]]=yC[l[1459]][l[588]](l[303],lC),[l[1639]]=yC[l[1459]][l[772]](LC or l[330],l[1519],l[393],l[973]),[l[1646]]=l[229],[l[437]]=yC[l[128]][l[437]][l[1381]],[l[1420]]=sC,[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[330],[l[164]]=yC[l[128]][l[164]][l[1021]],[l[1634]]=yC[l[128]][l[1634]][l[701]],[l[711]]=l[368]},MP);
          end
          EP=UP(l[1243]);
          uP(EP,l[1686],l[786]);
          local MP=a(l[1742],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=VP[l[1459]][l[588]](l[1707],l[1707]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[711]]=l[1289]},EP);
          D(MP,l[303]);
          local sC=a;
          local lC=l[859];
          local LC={};
          LC[l[1150]]=f();
          LC[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]);
          LC[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]);
          LC[l[1639]]=VP[l[1459]][l[588]](l[1307],l[1307]);
          LC[l[1646]]=l[229];
          LC[l[1451]]=y[30](l[905]);
          LC[l[936]]=R[l[1379]];
          LC[l[2]]=l[411];
          LC[l[1557]]=VP[l[128]][l[1557]][l[220]];
          LC[l[711]]=l[1365];
          local yC=sC(lC,LC,MP);
          local sC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[662],l[659],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[1419],l[221],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},EP);
          D(sC,l[1158]);
          local lC=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},sC);
          local LC=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[711]]=l[1289]},sC);
          local zC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},sC);
          K(zC,l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[229],l[229])});
          QP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},sC);
          local TC,nC,JC,HC;
          if XP then
            tP=UP(l[1282]);
            uP(tP,l[1019],l[229]);
            JC=a(l[1070],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[393]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=VP[l[1459]][l[588]](l[616],l[973]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[1634]]=VP[l[128]][l[1634]][l[877]],[l[711]]=l[368]},tP);
            TC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[303],l[209]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[368]},tP);
            iP,RP=l[1112],{};
            RP[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
            a(iP,RP,TC);
            nC=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1289]},TC);
            local fC,aC=l[1112],{};
            aC[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
            a(fC,aC,nC);
            HC=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=VP[l[1459]][l[588]](l[393],l[352]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[829]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},tP);
          else
          end
          local tP,fC={};
          if WP[l[649]] then
            RP=UP(l[1655]);
            uP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},RP);
            D(uP,l[1158]);
            a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},uP);
            fC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[393],l[59],l[393],l[59]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[1452],l[229],l[1024]),[l[1535]]=R[l[98]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[1289]},uP);
            D(fC,l[303]);
            K(fC,l[117],{VP[l[677]][l[772]](l[393],l[393]),VP[l[677]][l[772]](l[229],l[1017])});
            a(l[734],{[l[1630]]=R[l[98]],[l[747]]=l[1567]},fC);
            iP={l[524],l[259]};
            for RP,UP in y[3],iP,nil do
              EP={[l[572]]=UP,[l[892]]=l[1329],[l[590]]=RP,[l[974]]=a(l[1742],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[659]*(RP-l[229]),l[393],l[393],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[393],l[229],l[393]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},uP)};
              EP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=UP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[711]]=l[1365]},EP[l[974]]);
              tP[RP]=EP;
            end;
          else
          end
          local iP=XP and VP[l[35]][l[850]](VP[l[1382]](XP[l[109]])or l[229],l[393])or l[393];
          local EP=XP and XP[l[1647]]or l[393];
          local RP=l[1329];
          local function uP(UP)
            local aC=s[87]();
            if EP>l[393] then
              return aC[l[409]][l[846]](l[1213]..EP..l[347],UP)..(XP[l[26]]or l[1746]);
            end
            return aC[l[409]][l[846]](l[1489],aC[l[35]][l[499]](UP+l[659]))..(XP[l[26]]or l[1746]);
          end
          local function UP(aC)
            local dC=s[87]();
            aC=dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
            aC=if iP>l[393]then XP[l[457]]+dC[l[35]][l[499]]((aC-XP[l[457]])/iP+l[659])*iP else aC;
            aC=if EP>l[393]then dC[l[1382]](dC[l[409]][l[846]](l[1213]..EP..l[347],aC))or aC else aC;
            return dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
          end
          local function iP()
            local EP=s[87]();
            if not XP then
              return;
            end
            local aC=XP[l[850]]-XP[l[457]];
            local dC=aC>l[393]and(_P[l[1019]]-XP[l[457]])/aC or l[393];
            JC[l[1420]]=uP(_P[l[1019]]);
            local uP,JC=RP and J or n,{};
            JC[l[1639]]=EP[l[1459]][l[772]](dC,EP[l[35]][l[499]](l[1158]*(l[229]-dC)+l[659]),l[229],l[393]);
            P(nC,uP,JC);
          end
          local function EP()
            local uP=s[87]();
            for nC=l[229],#tP,l[229]do
              local JC=tP[nC];
              nC=_P[l[649]]==JC[l[572]];
              P(JC[l[1615]],n,{[l[916]]=nC and l[393]or(JC[l[892]]and l[874]or l[323]),[l[510]]=nC and R[l[1095]]or R[l[1379]]});
              if nC and fC then
                P(fC,H,{[l[948]]=uP[l[1459]][l[772]](l[659]*(JC[l[590]]-l[229]),l[59],l[393],l[59])});
              end
            end;
          end
          local function uP()
            LC[l[1420]]=_P[l[548]]and l[538]or z(_P[l[230]]);
            P(sC,H,{[l[1646]]=_P[l[548]]and l[393]or l[841]});
            P(lC,H,{[l[747]]=_P[l[548]]and l[120]or l[1373]});
            P(zC,H,{[l[1646]]=_P[l[548]]and l[986]or l[229]});
            local sC,lC,zC={[l[916]]=_P[l[230]]and l[1296]or l[615]},l[510],_P[l[548]]and R[l[98]]or(_P[l[230]]and R[l[1095]]or R[l[1379]]);
            sC[lC]=zC;
            P(LC,H,sC);
            P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509]});
          end
          local function sC()
            if not _P[l[230]] then
              fP(WP[l[1463]]);
              return;
            end
            NP(WP[l[1463]],{[l[572]]=wP,[l[230]]=z(_P[l[230]]),[l[103]]=WP[l[103]],[l[194]]=WP[l[194]],[l[1204]]=WP[l[1735]]and WP[l[1735]]()or nil,[l[628]]=WP[l[1386]]and WP[l[1386]]()or l[1329]});
          end
          local function fP()
            local NP=s[87]();
            return l[1282]+NP[l[35]][l[850]](NP[l[35]][l[499]](e(gP)[l[636]]+l[659]),l[1655]);
          end
          local function NP()
            local wP,lC,LC,zC,nC,JC,fC=s[87](),G(YP),e(YP),G(FP),e(FP),G(BP),e(BP);
            local aC,dC=zC[l[1437]]-lC[l[1437]]+nC[l[1437]]+l[930],zC[l[1437]]-lC[l[1437]]-_P[l[559]]-l[930];
            nC,zC=if aC+_P[l[559]]>LC[l[1437]]-l[930]then dC>=l[930]and dC or wP[l[35]][l[850]](l[930],LC[l[1437]]-l[930]-_P[l[559]])else aC,wP[l[35]][l[819]](JC[l[636]]-lC[l[636]]+fC[l[636]]*l[659]-_P[l[434]]*l[659],l[930],wP[l[35]][l[850]](l[930],LC[l[636]]-_P[l[434]]-l[930]));
            IP[l[948]]=wP[l[1459]][l[588]](wP[l[35]][l[499]](nC+l[659]),wP[l[35]][l[499]](zC+l[659]));
            if kP then
              kP[l[948]]=IP[l[948]];
            end
          end
          local function wP()
            local lC=s[87]();
            _P[l[434]]=fP();
            IP[l[1639]]=lC[l[1459]][l[588]](_P[l[559]],_P[l[434]]);
            if kP then
              kP[l[1639]]=IP[l[1639]];
            end
          end
          local function fP()
            local lC=IP[l[1569]];
            local LC=_P[l[404]]and l[393]or l[229];
            b(IP,_P[l[404]]and l[894]or l[304],_P[l[404]]and N or q,function(zC)
              local nC=lC+(LC-lC)*zC;
              IP[l[1569]]=nC;
              if kP then
                kP[l[1646]]=nC;
                vP[l[747]]=l[615]+l[411]*nC;
              end
              if zC>=l[229] then
                IP[l[1324]]=_P[l[404]];
                if kP then
                  kP[l[1324]]=_P[l[404]];
                end
              end
            end);
          end
          local vP;
          local function lC()
            local LC=vP;
            if LC then
              vP:Disconnect();
              vP=nil;
            end
          end
          local function LC()
            _P:setopen(l[1329]);
          end
          local function zC()
            local nC=S;
            if nC>l[393] then
              NP();
              return;
            end
            if not LP[l[1600]]or not KP[l[1324]]or not BP[l[1324]] then
              _P:setopen(l[1329]);
              return;
            end
            local JC,fC,aC,dC,PC,ZC=FP[l[81]],FP[l[160]],hP[l[81]],hP[l[160]],BP[l[81]],BP[l[160]];
            nC=PC[l[636]]+ZC[l[636]]*l[659];
            if nC<JC[l[636]]or nC>JC[l[636]]+fC[l[636]]or nC<aC[l[636]]or nC>aC[l[636]]+dC[l[636]] then
              _P:setopen(l[1329]);
              return;
            end
            NP();
          end
          local function BP(FP,hP)
            local nC={};
            hP=hP and l[383]or l[1329];
            if _P[l[404]]==hP then
              return;
            end
            _P[l[404]]=hP;
            if hP then
              V();
              U(_P);
              wP();
              xP[l[1324]]=l[383];
              IP[l[1324]]=l[383];
              if kP then
                kP[l[1324]]=l[383];
              end
              NP();
              A,w=LC,IP;
              lC();
              nC[1]=(y[10][l[1119]]:Connect(zC));
              vP=nC[1];
            else
              lC();
              xP[l[1324]]=l[1329];
              if _P[l[548]] then
                _P[l[548]]=l[1329];
                lP(nil);
                uP();
              end
              FP=A==LC;
              if FP then
                A,w=nil,nil;
              end
            end
            fP();
          end
          _P[l[1521]--[[0]]]=BP;
          local fP=l[393];
          local function BP(FP)
            FP=s[87]();
            local hP=FP[l[655]][l[1587]]();
            FP=hP-fP;
            if FP<l[874] then
              return l[1329];
            end
            fP=hP;
            if _P[l[404]]and(W(IP,l[59])or kP and W(kP,l[59])) then
              return l[1329];
            end
            _P:setopen(not _P[l[404]]);
            return l[383];
          end
          _P[l[1352]]=BP;
          local function BP()
            local FP=s[87]();
            if F() then
              return;
            end
            fP=FP[l[655]][l[1587]]();
            _P:setopen(l[1329]);
          end
          d(xP[l[445]],BP);
          d(xP[l[861]],BP);
          local function fP(BP,BP)
            local FP,hP=s[87](),BP;
            hP=if FP[l[40]](hP)==l[409]then FP[l[199]](l[59],FP[l[1146]](function()
              local xP=s[87]();
              return xP[l[128]][l[880]--[[readu32]]][BP];
            end))else hP;
            hP=if FP[l[1703]](hP)~=l[802]or hP==FP[l[128]][l[880]--[[readu32]]][l[605]]then nil else hP;
            if _P[l[230]]==hP then
              return;
            end
            if _P[l[1273]] then
              _P[l[1273]]=l[1329];
              WP[l[1498]](l[1329]);
            end
            _P[l[230]]=hP;
            uP();
            sC();
          end
          _P[l[1046]]=fP;
          local function fP(BP,BP)
            if BP~=l[524]and BP~=l[259] then
              return;
            end
            if _P[l[649]]==BP then
              return;
            end
            if _P[l[1273]] then
              _P[l[1273]]=l[1329];
              WP[l[1498]](l[1329]);
            end
            _P[l[649]]=BP;
            EP();
          end
          _P[l[1755]]=fP;
          local function fP(BP,FP)
            BP=s[87]();
            if not XP then
              return;
            end
            FP=UP(BP[l[1382]](FP)or XP[l[457]]);
            if _P[l[1019]]==FP then
              return;
            end
            _P[l[1019]]=FP;
            iP();
            if _P[l[230]] then
              sC();
            end
          end
          _P[l[378]]=fP;
          local function fP(BP,BP)
            _P[l[1273]]=BP and l[383]or l[1329];
          end
          _P[l[488]]=fP;
          local function fP(BP,BP)
            aP(WP[l[1463]],BP);
          end
          _P[l[628]]=fP;
          _P[l[1498]]=WP[l[1498]];
          local function fP()
            _P[l[548]]=l[1329];
            uP();
          end
          d(QP[l[445]],function()
            if _P[l[548]] then
              lP(nil);
              fP();
              return;
            end
            _P[l[548]]=l[383];
            uP();
            y[18]:chime(l[1352]);
            lP(function(aP)
              fP();
              if aP then
                _P:setkey(aP);
                y[18]:chime(l[1320]);
              end
            end,fP);
          end);
          d(MP[l[445]],function()
            if _P[l[548]] then
              lP(nil);
              fP();
            end
            if not _P[l[230]] then
              return;
            end
            _P:setkey(nil);
            yC[l[936]]=R[l[98]];
            P(yC,H,{[l[936]]=R[l[1379]]});
            y[18]:chime(l[676]);
          end);
          d(MP[l[1538]],function()
            P(MP,H,{[l[1646]]=l[330]});
            P(yC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
          end);
          d(MP[l[1628]],function()
            P(MP,H,{[l[1646]]=l[229]});
            P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509],[l[936]]=R[l[1379]]});
          end);
          for fP=l[229],#tP,l[229]do
            local aP=tP[fP];
            d(aP[l[974]][l[1538]],function()
              aP[l[892]]=l[383];
              EP();
            end);
            d(aP[l[974]][l[1628]],function()
              aP[l[892]]=l[1329];
              EP();
            end);
            d(aP[l[974]][l[445]],function()
              _P:setmode(aP[l[572]]);
              y[18]:chime(l[1320]);
            end);
          end;
          EP();
          if XP then
            local fP=l[1329];
            local function aP()
              RP=l[1329];
              local BP=fP;
              if BP then
                fP=l[1329];
                O(l[715]);
              end
            end
            d(HC[l[956]],aP);
            d(HC[l[1558]],function(BP)
              local FP=s[87]();
              if BP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and BP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
                return;
              end
              local hP=RP;
              if hP then
                return;
              end
              RP=l[383];
              fP=l[383];
              O(l[229]);
              local fP,hP=FP[l[1146]](function()
                local xP=s[87]();
                y[18]:chime(l[1320]);
                while true do
                  local vP=RP and y[18][l[630]];
                  if not(vP and HC[l[382]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[912]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[625]]) then
                    break;
                  end
                  local vP,EP=TC[l[81]],TC[l[160]];
                  if EP[l[1437]]>l[393] then
                    _P:setvalue(XP[l[457]]+(XP[l[850]]-XP[l[457]])*xP[l[35]][l[819]]((v(BP)[l[1437]]-vP[l[1437]])/EP[l[1437]],l[393],l[229]));
                  end
                  xP[l[1022]][l[153]]();
                end;
              end);
              aP();
              if not fP then
                FP[l[972]](l[800]..FP[l[1130]](hP));
              end
              iP();
            end);
            d(HC[l[412]],function(fP)
              local BP=s[87]();
              if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
                aP();
              end
            end);
            d(y[9][l[412]],function(fP)
              local BP=s[87]();
              if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
                aP();
              end
            end);
            _P[l[1019]]=UP(_P[l[1019]]);
            iP();
          end
          d(gP:GetPropertyChangedSignal(l[160]),function()
            if _P[l[404]] then
              wP();
              NP();
            end
          end);
          d(y[9][l[1558]],function(fP)
            local aP,NP,BP=s[87](),not _P[l[404]];
            if NP then
              BP=NP;
            else
              local NP=S;
              BP=NP>l[393];
            end
            if BP or F() then
              return;
            end
            if fP[l[1317]]~=aP[l[128]][l[1317]][l[1356]]and fP[l[1317]]~=aP[l[128]][l[1317]][l[239]] then
              return;
            end
            if W(IP,l[59])or kP and W(kP,l[59]) then
              return;
            end
            aP[l[1022]][l[1061]](function()
              if _P[l[404]] then
                _P:setopen(l[1329]);
              end
            end);
          end);
          d(y[9][l[1558]],function(F,fP)
            local aP=s[87]();
            if fP or y[18][l[1333]]or not _P[l[230]]or not y[18][l[630]] then
              return;
            end
            if F[l[1317]]~=aP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
              return;
            end
            if not WP[l[649]] then
              WP[l[1498]](l[383]);
              return;
            end
            if _P[l[649]]==l[259] then
              if _P[l[1273]] then
                return;
              end
              _P[l[1273]]=l[383];
              WP[l[1498]](l[383]);
            else
              _P[l[1273]]=not _P[l[1273]];
              WP[l[1498]](_P[l[1273]]);
            end
          end);
          d(y[9][l[412]],function(F)
            local fP=s[87]();
            if _P[l[649]]~=l[259]or not _P[l[230]]or not _P[l[1273]] then
              return;
            end
            if F[l[1317]]~=fP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
              return;
            end
            _P[l[1273]]=l[1329];
            WP[l[1498]](l[1329]);
          end);
          uP();
          VP[l[1346]][l[968]](m,_P);
          y[18]:hook(WP[l[1463]]..l[728],l[230],function()
            return _P[l[230]]and _P[l[230]][l[1150]]or nil;
          end,function(F)
            _P:setkey(F);
          end);
          if WP[l[649]] then
            y[18]:hook(WP[l[1463]]..l[1175],l[1206],function()
              return _P[l[649]];
            end,function(F)
              _P:setmode(F);
            end,{[l[284]]=function(F)
              return F==l[524]or F==l[259];
            end});
          end
          if XP then
            y[18]:hook(WP[l[1463]]..l[562],l[384],function()
              return _P[l[1019]];
            end,function(F)
              _P:setvalue(F);
            end,{[l[457]]=XP[l[457]],[l[850]]=XP[l[850]]});
          end
          return _P;
        end
        local function F(fP,aP)
          fP=s[87]();
          aP=X(aP,{[l[572]]=l[146],[l[1132]]=l[356]});
          local NP=AP(aP[l[1132]]);
          local BP,wP=mP(NP);
          local FP={[l[590]]=wP,[l[572]]=aP[l[572]],[l[12]]={}};
          local hP=oP..l[1074]..aP[l[572]];
          fP[l[1346]][l[968]](OP,FP);
          local WP,VP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
          VP[l[536]]=fP[l[740]][l[772]](l[393],l[393]);
          a(WP,VP,BP);
          WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[537]]=l[229],[l[711]]=l[303]},BP);
          D(WP,l[1092]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=fP[l[1689]][l[772]](l[393],l[229]),[l[948]]=fP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[711]]=l[303]},WP);
          a(l[1070],{[l[1150]]=f(),[l[948]]=fP[l[1459]][l[588]](l[730],l[393]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[644],l[229],l[393]),[l[1646]]=l[229],[l[437]]=fP[l[128]][l[437]][l[1381]],[l[1420]]=aP[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=fP[l[128]][l[164]][l[1021]],[l[1634]]=fP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
          local _P=a;
          local XP=l[859];
          local xP={};
          xP[l[1150]]=f();
          xP[l[1016]]=fP[l[1689]][l[772]](l[229],l[659]);
          xP[l[948]]=fP[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
          xP[l[1639]]=fP[l[1459]][l[588]](l[750],l[750]);
          xP[l[1646]]=l[229];
          xP[l[1451]]=y[30](l[606]--[[readu16]]);
          xP[l[936]]=R[l[1379]];
          xP[l[2]]=l[615];
          xP[l[500]]=l[1510];
          xP[l[711]]=l[1158];
          local kP=_P(XP,xP,WP);
          aP=a(l[1742],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},WP);
          K(a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[537]]=l[59],[l[711]]=l[1158]},BP),l[393],{fP[l[677]][l[772]](l[393],l[229]),fP[l[677]][l[772]](l[841],l[874]),fP[l[677]][l[772]](l[659],l[393]),fP[l[677]][l[772]](l[804],l[874]),fP[l[677]][l[772]](l[229],l[229])});
          local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=l[863],[l[711]]=l[303]},BP);
          local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=fP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[711]]=l[303]},WP);
          VP,wP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
          wP[l[536]]=fP[l[740]][l[772]](l[393],l[229]);
          a(VP,wP,_P);
          a(l[1359],{[l[299]]=fP[l[740]][l[772]](l[393],l[1158]),[l[645]]=fP[l[740]][l[772]](l[393],l[930]),[l[1612]]=fP[l[740]][l[772]](l[393],l[303]),[l[517]]=fP[l[740]][l[772]](l[393],l[303])},_P);
          local fP={[l[675]]=BP,[l[1577]]=_P,[l[668]]=l[393],[l[1600]]=l[383]};
          d(_P:GetPropertyChangedSignal(l[160]),function()
            local BP=s[87]();
            if fP[l[1600]]and not fP[l[1678]] then
              WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],e(_P)[l[636]]);
            end
          end);
          local function BP()
            local wP,VP=s[87](),WP[l[1639]][l[636]][l[1485]];
            fP[l[1678]]=l[383];
            wP[l[1022]][l[1061]](function()
              local wP=fP[l[1600]]and e(_P)[l[636]]or l[393];
              b(WP,l[1491],wP>=VP and N or q,function(XP)
                local xP=s[87]();
                WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],xP[l[35]][l[499]](VP+(wP-VP)*XP+l[659]));
                if XP>=l[229] then
                  fP[l[1678]]=l[1329];
                  WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],fP[l[1600]]and e(_P)[l[636]]or l[393]);
                end
              end);
            end);
          end
          fP[l[721]]=BP;
          local function BP(wP,wP)
            fP[l[1600]]=wP and l[383]or l[1329];
            local wP=kP[l[500]];
            local VP=fP[l[1600]]and l[1510]or l[393];
            b(kP,l[894],N,function(XP)
              kP[l[500]]=wP+(VP-wP)*XP;
            end);
            fP[l[721]]();
          end
          fP[l[1521]--[[0]]]=BP;
          FP[l[1654]]=fP[l[721]];
          FP[l[1637]]=function(BP)
            if BP==nil then
              if FP[l[1626]]~=nil then
                local wP=FP[l[1626]];
                FP[l[1626]]=nil;
                if fP[l[1600]]~=wP then
                  fP:setopen(wP);
                end
              end
              return;
            end
            if BP and not fP[l[1600]] then
              if FP[l[1626]]==nil then
                FP[l[1626]]=l[1329];
              end
              fP:setopen(l[383]);
            end
          end;
          d(aP[l[445]],function()
            fP:setopen(not fP[l[1600]]);
            y[18]:chime(l[1352]);
          end);
          d(aP[l[1538]],function()
            P(kP,H,{[l[2]]=l[1209]});
          end);
          d(aP[l[1628]],function()
            P(kP,H,{[l[2]]=l[615]});
          end);
          local aP={[l[1594]--[[__index]]]=_P,[l[438]]=NP[l[1594]--[[__index]]],[l[745]]=WP};
          local NP={l[524],l[1223],l[166],l[654],l[1336],l[1409],l[138],l[1094]};
          local function BP(wP,WP,VP)
            local _P={};
            for XP,XP in y[3],NP,nil do
              _P[XP]=function(NP,NP)
                local xP,kP,vP,IP=s[87](),aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
                aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=wP,WP,VP;
                local wP,WP=xP[l[1146]](fP[XP],fP,NP);
                aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=kP,vP,IP;
                if not wP then
                  xP[l[279]](WP,l[59]);
                end
                xP[l[1346]][l[1357]](FP[l[12]]);
                return WP;
              end;
            end;
            return _P;
          end
          local function NP(wP,WP,VP,_P)
            local XP,xP=s[87](),{[l[404]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
            local kP=a(l[1742],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1243]},YP);
            local vP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[209]},YP)or nil;
            local IP=vP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=XP[l[740]][l[772]](l[393],l[558]),[l[1485]]=XP[l[1459]][l[588]](l[393],l[786]),[l[1326]]=XP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},vP)or nil;
            if vP then
              D(vP,l[1092]);
            end
            local iP=a(l[1751],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1655]},YP);
            D(iP,l[1092]);
            local EP,QP=l[1622],{[l[500]]=l[117]};
            QP[l[1630]]=XP[l[1262]][l[772]]({XP[l[527]][l[772]](l[393],XP[l[360]][l[772]](l[229],l[229],l[229])),XP[l[527]][l[772]](l[229],XP[l[360]][l[353]](l[291],l[291],l[920]))});
            a(EP,QP,iP);
            EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[658]},iP);
            D(EP,l[1092]);
            a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},EP);
            QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},iP);
            EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},QP);
            D(EP,l[1092]);
            a(l[211],{[l[1150]]=f(),[l[1016]]=XP[l[1689]][l[772]](l[393],l[229]),[l[948]]=XP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},EP);
            local tP=a;
            local RP=l[859];
            local gP={};
            gP[l[1150]]=f();
            gP[l[1016]]=XP[l[1689]][l[772]](l[393],l[659]);
            gP[l[948]]=XP[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
            gP[l[1639]]=XP[l[1459]][l[588]](l[310],l[310]);
            gP[l[1646]]=l[229];
            gP[l[1451]]=y[30](l[1716]);
            gP[l[936]]=R[l[1379]];
            gP[l[2]]=l[1431];
            gP[l[1557]]=XP[l[128]][l[1557]][l[220]];
            gP[l[711]]=l[1660];
            tP(RP,gP,EP);
            a(l[1070],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=XP[l[128]][l[437]][l[1381]],[l[1420]]=WP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=XP[l[128]][l[164]][l[1021]],[l[1634]]=XP[l[128]][l[1634]][l[701]],[l[711]]=l[1660]},EP);
            K(a(l[211],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1660]},QP),l[393],{XP[l[677]][l[772]](l[393],l[229]),XP[l[677]][l[772]](l[841],l[874]),XP[l[677]][l[772]](l[659],l[393]),XP[l[677]][l[772]](l[804],l[874]),XP[l[677]][l[772]](l[229],l[229])});
            local tP=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=XP[l[1459]][l[588]](l[393],l[913]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=XP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=XP[l[128]][l[62]][l[636]],[l[711]]=l[1655]},QP);
            local QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=XP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},tP);
            EP,WP=l[755],{[l[407]]=XP[l[128]][l[407]][l[537]]};
            WP[l[536]]=XP[l[740]][l[772]](l[393],l[229]);
            a(EP,WP,QP);
            a(l[1359],{[l[299]]=XP[l[740]][l[772]](l[393],l[1158]),[l[645]]=XP[l[740]][l[772]](l[393],l[930]),[l[1612]]=XP[l[740]][l[772]](l[393],l[303]),[l[517]]=XP[l[740]][l[772]](l[393],l[303])},QP);
            local function WP()
              local XP,EP=s[87](),e(YP);
              local RP=XP[l[35]][l[499]](e(VP)[l[1437]]+l[659]);
              return XP[l[35]][l[819]](RP,l[1592],XP[l[35]][l[850]](XP[l[35]][l[499]](EP[l[1437]])-l[1655],l[1592]));
            end
            local function XP()
              local EP,RP=s[87](),e(YP);
              local gP=EP[l[35]][l[850]](EP[l[35]][l[499]](e(QP)[l[636]]+l[659]),l[658]);
              return EP[l[35]][l[819]](l[913]+gP,l[1167],EP[l[35]][l[850]](EP[l[35]][l[499]](RP[l[636]])-l[1655],l[1167]));
            end
            local function EP()
              local RP,gP,uP,UP,MP,sC,lC=s[87](),G(YP),e(YP),G(VP),e(VP),G(wP),e(wP);
              local LC,yC=UP[l[1437]]-gP[l[1437]]+MP[l[1437]]+l[930],UP[l[1437]]-gP[l[1437]]-xP[l[559]]-l[930];
              UP,MP=if LC+xP[l[559]]>uP[l[1437]]-l[930]then yC>=l[930]and yC or RP[l[35]][l[850]](l[930],uP[l[1437]]-l[930]-xP[l[559]])else LC,RP[l[35]][l[819]](sC[l[636]]-gP[l[636]]+lC[l[636]]*l[659]-xP[l[434]]*l[659],l[930],RP[l[35]][l[850]](l[930],uP[l[636]]-xP[l[434]]-l[930]));
              iP[l[948]]=RP[l[1459]][l[588]](RP[l[35]][l[499]](UP+l[659]),RP[l[35]][l[499]](MP+l[659]));
              if vP then
                vP[l[948]]=iP[l[948]];
              end
            end
            local function RP()
              local gP=iP[l[1569]];
              local uP=xP[l[404]]and l[393]or l[229];
              b(iP,xP[l[404]]and l[894]or l[304],xP[l[404]]and N or q,function(UP)
                local MP=gP+(uP-gP)*UP;
                iP[l[1569]]=MP;
                if vP then
                  vP[l[1646]]=MP;
                  IP[l[747]]=l[330]+l[1419]*MP;
                end
                if UP>=l[229] then
                  iP[l[1324]]=xP[l[404]];
                  if vP then
                    vP[l[1324]]=xP[l[404]];
                  end
                end
              end);
            end
            local function IP()
              local gP=s[87]();
              xP[l[559]]=WP();
              xP[l[434]]=XP();
              iP[l[1639]]=gP[l[1459]][l[588]](xP[l[559]],xP[l[434]]);
              if vP then
                vP[l[1639]]=iP[l[1639]];
              end
            end
            local WP;
            local function XP()
              local gP=WP;
              if gP then
                WP:Disconnect();
                WP=nil;
              end
            end
            local function gP()
              local uP=S;
              if uP>l[393] then
                EP();
                return;
              end
              if not LP[l[1600]]or not KP[l[1324]]or not wP[l[1324]] then
                xP:setopen(l[1329]);
                return;
              end
              local UP,MP,sC,lC,LC,yC=VP[l[81]],VP[l[160]],_P[l[81]],_P[l[160]],wP[l[81]],wP[l[160]];
              uP=LC[l[636]]+yC[l[636]]*l[659];
              if uP<UP[l[636]]or uP>UP[l[636]]+MP[l[636]]or uP<sC[l[636]]or uP>sC[l[636]]+lC[l[636]] then
                xP:setopen(l[1329]);
                return;
              end
              EP();
            end
            local function wP(VP,_P)
              local uP={};
              VP=s[87]();
              _P=_P and l[383]or l[1329];
              if xP[l[404]]==_P then
                return;
              end
              xP[l[404]]=_P;
              if _P then
                IP();
                iP[l[1324]]=l[383];
                kP[l[1324]]=l[383];
                tP[l[1690]]=VP[l[1689]][l[772]]();
                if vP then
                  vP[l[1324]]=l[383];
                end
                EP();
                XP();
                y[21](iP);
                uP[1]=(y[10][l[1119]]:Connect(gP));
                WP=uP[1];
              else
                XP();
                V();
                y[20](iP);
                kP[l[1324]]=l[1329];
              end
              RP();
            end
            xP[l[1521]--[[0]]]=wP;
            d(QP:GetPropertyChangedSignal(l[160]),function()
              local wP=s[87]();
              tP[l[392]]=wP[l[1459]][l[588]](l[393],wP[l[35]][l[499]](e(QP)[l[636]]+l[659]));
              if xP[l[404]] then
                IP();
                EP();
              end
            end);
            d(kP[l[445]],function()
              local wP=S;
              if wP>l[393] then
                return;
              end
              xP:setopen(l[1329]);
            end);
            xP[l[1594]--[[__index]]]=iP;
            xP[l[642]]=QP;
            xP[l[429]]=BP(QP,tP,tP);
            return xP;
          end
          local function BP(wP,WP)
            wP=s[87]();
            WP=X(WP,{[l[572]]=l[524],[l[950]]=l[1329],[l[925]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local VP,_P,XP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
            local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},VP);
            local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[829],l[829]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},xP);
            D(VP,l[786]);
            local kP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[874]},VP);
            local vP=a;
            local IP=l[859];
            local iP={};
            iP[l[1150]]=f();
            iP[l[1016]]=wP[l[1689]][l[772]](l[659],l[659]);
            iP[l[948]]=wP[l[1459]][l[1368]](l[659],l[659]);
            iP[l[1639]]=wP[l[1459]][l[588]](l[1158],l[1158]);
            iP[l[1646]]=l[229];
            iP[l[1451]]=y[30](l[1411]);
            iP[l[936]]=R[l[641]];
            iP[l[2]]=l[229];
            iP[l[1557]]=wP[l[128]][l[1557]][l[220]];
            iP[l[711]]=l[1092];
            local EP=vP(IP,iP,VP);
            local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=wP[l[1459]][l[588]](l[910],l[393]),[l[1639]]=wP[l[1459]][l[772]](l[229],WP[l[925]]and l[132]or l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=wP[l[128]][l[437]][l[1381]],[l[1420]]=WP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=wP[l[128]][l[164]][l[1021]],[l[1634]]=wP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
            local IP=a(l[1742],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},xP);
            local iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[59],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[1243],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},xP);
            local QP=WP[l[925]];
            if QP then
              local tP=a;
              local RP=l[1742];
              local gP={};
              gP[l[1150]]=f();
              gP[l[1016]]=wP[l[1689]][l[772]](l[229],l[659]);
              gP[l[948]]=wP[l[1459]][l[772]](l[229],l[66],l[659],l[393]);
              gP[l[1639]]=wP[l[1459]][l[588]](l[884],l[884]);
              gP[l[1535]]=R[l[1466]];
              gP[l[1646]]=l[229];
              gP[l[1418]]=l[393];
              gP[l[1451]]=y[30](l[1456]);
              gP[l[936]]=R[l[1379]];
              gP[l[2]]=l[615];
              gP[l[1557]]=wP[l[128]][l[1557]][l[220]];
              gP[l[711]]=l[730];
              QP=tP(RP,gP,xP);
            end
            local tP,RP,gP=IP,iP,QP or nil;
            if gP then
              D(gP,l[1158]);
            end
            local IP,iP,QP=wP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
            QP[l[572]]=WP[l[572]];
            IP(iP,QP);
            local wP={[l[266]]=xP,[l[404]]=l[1329]};
            local IP=l[1329];
            if gP then
              local QP=NP(xP,WP[l[572]],_P,XP);
              wP[l[1085]]=QP;
              wP[l[925]]=QP[l[429]];
              local function NP(uP,uP)
                QP:setopen(uP);
              end
              wP[l[691]]=NP;
              d(gP[l[445]],function()
                QP:setopen(not QP[l[404]]);
                y[18]:chime(l[1352]);
              end);
              d(gP[l[1538]],function()
                P(gP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
              end);
              d(gP[l[1628]],function()
                P(gP,H,{[l[2]]=l[615],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
              end);
            end
            local function NP()
              local QP,gP,uP,UP=s[87](),{},l[1646],wP[l[404]]and l[1296]or(IP and l[804]or l[229]);
              gP[uP]=UP;
              P(VP,H,gP);
              UP,gP,uP={},l[747],wP[l[404]]and l[229]or(IP and l[1296]or l[874]);
              UP[gP]=uP;
              P(kP,H,UP);
              P(EP,H,{[l[2]]=wP[l[404]]and l[393]or l[229],[l[1639]]=QP[l[1459]][l[588]](wP[l[404]]and l[310]or l[1158],wP[l[404]]and l[310]or l[1158])});
              P(vP,H,{[l[916]]=wP[l[404]]and l[393]or l[615],[l[510]]=wP[l[404]]and R[l[1095]]or R[l[1379]]});
            end
            local function VP(kP,kP,vP)
              kP=kP and l[383]or l[1329];
              if wP[l[404]]==kP and not y[18][l[921]] then
                return;
              end
              wP[l[404]]=kP;
              NP();
              if wP[l[1686]] then
                wP[l[1686]]:sync(kP);
                wP[l[1686]]:lit(kP);
              end
              if not vP then
                y[18]:chime(kP and l[404]or l[676]);
                if WP[l[1617]] then
                  I(WP[l[1617]],kP);
                end
              end
            end
            wP[l[1255]]=VP;
            local function VP(kP)
              return wP[l[404]];
            end
            wP[l[506]]=VP;
            d(tP[l[445]],function()
              wP:set(not wP[l[404]]);
            end);
            d(RP[l[445]],function()
              wP:set(not wP[l[404]]);
            end);
            d(RP[l[1538]],function()
              IP=l[383];
              NP();
            end);
            d(RP[l[1628]],function()
              IP=l[1329];
              NP();
            end);
            if WP[l[950]] then
              wP[l[404]]=l[383];
              NP();
            end
            iP=WP[l[1013]]or hP..l[1074]..WP[l[572]];
            local NP=SP(xP,WP[l[572]],_P,XP,{[l[1463]]=iP,[l[103]]=l[1499],[l[649]]=l[383],[l[1498]]=function(WP)
              wP:set(WP);
            end,[l[194]]=function()
              wP:set(not wP[l[404]]);
            end,[l[1386]]=function()
              return wP[l[404]];
            end});
            wP[l[1686]]=NP;
            NP:lit(wP[l[404]]);
            d(tP[l[861]],function()
              if not NP:flip() then
                return;
              end
              y[18]:chime(l[1352]);
            end);
            d(RP[l[861]],function()
              if not NP:flip() then
                return;
              end
              y[18]:chime(l[1352]);
            end);
            y[18]:hook(iP,l[524],function()
              return wP[l[404]];
            end,function(NP)
              wP:set(NP==l[383]or NP==l[1102]or NP==l[229]);
            end);
            return wP;
          end
          fP[l[524]]=BP;
          local function NP(BP,wP)
            BP=s[87]();
            wP=X(wP,{[l[572]]=l[1223],[l[457]]=l[393],[l[850]]=l[856],[l[950]]=nil,[l[109]]=l[229],[l[26]]=l[1746],[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local WP,VP=aP[l[1594]--[[__index]]],aP[l[438]];
            local _P,XP=aP[l[745]],BP[l[35]][l[850]](BP[l[1382]](wP[l[109]])or l[229],l[393]);
            local xP=XP>l[393]and XP<l[229]and#(BP[l[409]][l[56]](BP[l[1130]](XP),l[361])or l[1746])or l[393];
            local kP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},WP);
            local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[229]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1057],l[393],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=wP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},kP);
            local IP=a(l[1070],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[393]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=BP[l[1459]][l[588]](l[1167],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[874],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[877]],[l[711]]=l[1158]},kP);
            local iP=a(l[211],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[1243]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},kP);
            local EP,QP=l[1112],{};
            QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
            a(EP,QP,iP);
            local tP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1092]},iP);
            EP,QP=l[1112],{};
            QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
            a(EP,QP,tP);
            local RP,gP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[393],l[973]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[114]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},kP),{[l[266]]=kP,[l[1019]]=wP[l[457]]};
            local uP=l[1329];
            local UP,MP,sC=l[1329];
            EP,QP,WP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=kP};
            WP[l[572]]=wP[l[572]];
            EP(QP,WP);
            local function lC(LC)
              local yC=s[87]();
              if xP>l[393] then
                return yC[l[409]][l[846]](l[1213]..xP..l[347],LC)..wP[l[26]];
              end
              return yC[l[409]][l[846]](l[1489],yC[l[35]][l[499]](LC+l[659]))..wP[l[26]];
            end
            local function LC(yC)
              local zC=s[87]();
              yC=zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
              yC=if XP>l[393]then wP[l[457]]+zC[l[35]][l[499]]((yC-wP[l[457]])/XP+l[659])*XP else yC;
              yC=if xP>l[393]then zC[l[1382]](zC[l[409]][l[846]](l[1213]..xP..l[347],yC))or yC else yC;
              return zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
            end
            local function yC(zC)
              local TC=s[87]();
              return TC[l[1459]][l[772]](zC,TC[l[35]][l[499]](l[1158]*(l[229]-zC)+l[659]),l[229],l[393]);
            end
            local function zC()
              local TC=wP[l[850]]-wP[l[457]];
              local nC=TC>l[393]and(gP[l[1019]]-wP[l[457]])/TC or l[393];
              IP[l[1420]]=lC(gP[l[1019]]);
              local TC,JC=UP and J or n,{};
              JC[l[1639]]=yC(nC);
              P(tP,TC,JC);
            end
            local function J()
              P(iP,H,{[l[1646]]=(UP or uP)and l[393]or l[841]});
              local yC,TC,nC={},l[1646],UP and l[393]or(uP and l[613]or l[1209]);
              yC[TC]=nC;
              P(tP,H,yC);
              P(vP,H,{[l[916]]=(UP or uP)and l[1209]or l[615]});
              P(IP,H,{[l[916]]=(UP or uP)and l[393]or l[874]});
            end
            local function vP(IP,tP,yC)
              IP=s[87]();
              tP=LC(IP[l[1382]](tP)or wP[l[457]]);
              if gP[l[1019]]==tP and not y[18][l[921]] then
                return;
              end
              gP[l[1019]]=tP;
              zC();
              if not yC and wP[l[1617]] then
                I(wP[l[1617]],tP);
              end
            end
            gP[l[1255]]=vP;
            local function vP(IP)
              return gP[l[1019]];
            end
            gP[l[506]]=vP;
            local function IP(tP)
              if tP and tP[l[948]] then
                return tP[l[948]][l[1437]];
              end
              return y[9]:GetMouseLocation()[l[1437]];
            end
            local function tP(yC)
              local TC,nC,JC=s[87](),iP[l[81]],iP[l[160]];
              if JC[l[1437]]<=l[393] then
                return gP[l[1019]];
              end
              return wP[l[457]]+(wP[l[850]]-wP[l[457]])*TC[l[35]][l[819]]((yC-nC[l[1437]])/JC[l[1437]],l[393],l[229]);
            end
            local function iP()
              local yC=sC;
              if yC then
                sC:Disconnect();
                sC=nil;
              end
              yC=UP;
              if not yC then
                return;
              end
              UP,MP=l[1329],nil;
              VP[l[1195]]=l[383];
              O(l[715]);
              zC();
              J();
            end
            d(RP[l[1558]],function(yC)
              local TC={};
              local nC=s[87]();
              if yC[l[1317]]~=nC[l[128]][l[1317]][l[1356]]and yC[l[1317]]~=nC[l[128]][l[1317]][l[239]] then
                return;
              end
              local JC=UP;
              if JC then
                return;
              end
              UP=l[383];
              MP=yC[l[1317]]==nC[l[128]][l[1317]][l[239]]and yC or nil;
              JC=sC;
              if JC then
                sC:Disconnect();
              end
              TC[1]=(y[10][l[756]]:Connect(function()
                local nC,JC,HC=s[87](),MP;
                if JC then
                  local JC=MP;
                  local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
                  if fC then
                    HC=fC;
                  else
                    JC=MP;
                    HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
                  end
                else
                  HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
                end
                if not HC then
                  iP();
                end
              end));
              sC=TC[1];
              O(l[229]);
              J();
              VP[l[1195]]=l[1329];
              y[18]:chime(l[1320]);
              gP:set(tP(IP(yC)));
            end);
            local function sC(yC)
              local TC,nC=s[87](),MP;
              if nC then
                local nC=MP;
                return yC==nC;
              end
              return yC[l[1317]]==TC[l[128]][l[1317]][l[1356]];
            end
            d(RP[l[412]],function(yC)
              if sC(yC) then
                iP();
              end
            end);
            d(y[9][l[233]],function(yC)
              local TC,nC=s[87](),UP;
              if not nC then
                return;
              end
              nC=MP;
              if nC then
                local UP=MP;
                if yC~=UP then
                  return;
                end
              elseif yC[l[1317]]~=TC[l[128]][l[1317]][l[765]] then
                return;
              end
              gP:set(tP(IP(yC)));
            end);
            d(y[9][l[412]],function(IP)
              if sC(IP) then
                iP();
              end
            end);
            d(kP[l[1538]],function()
              uP=l[383];
              J();
            end);
            d(kP[l[1628]],function()
              uP=l[1329];
              J();
            end);
            gP[l[1019]]=LC(BP[l[1382]](wP[l[950]])or wP[l[457]]);
            zC();
            local J,IP,iP=wP[l[1013]]or hP..l[1074]..wP[l[572]];
            EP,WP,QP,vP=wP[l[572]],VP,{[l[1463]]=J,[l[103]]=l[1716],[l[649]]=l[383],[l[1019]]={[l[457]]=wP[l[457]],[l[850]]=wP[l[850]],[l[109]]=XP,[l[1647]]=xP,[l[26]]=wP[l[26]],[l[950]]=gP[l[1019]]},[l[1735]]=function()
              return lC(iP[l[1019]]);
            end},l[1498];
            local function VP(XP)
              if XP then
                local XP=IP==nil;
                if XP then
                  IP=gP[l[1019]];
                end
                gP:set(iP[l[1019]]);
              else
                local XP=IP~=nil;
                if XP then
                  gP:set(IP);
                  IP=nil;
                end
              end
              iP:lit(IP~=nil);
            end
            QP[vP]=VP;
            QP[l[194]]=function()
              iP[l[1273]]=not iP[l[1273]];
              iP[l[1498]](iP[l[1273]]);
            end;
            QP[l[1386]]=function()
              local VP=IP;
              return VP~=nil;
            end;
            iP=SP(kP,EP,WP,_P,QP);
            gP[l[1686]]=iP;
            vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[973]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},kP);
            local function BP()
              if not iP:flip() then
                return;
              end
              y[18]:chime(l[1352]);
            end
            d(vP[l[861]],BP);
            d(RP[l[1558]],function(WP)
              local VP=s[87]();
              if WP[l[1317]]==VP[l[128]][l[1317]][l[321]--[[-1]]] then
                BP();
              end
            end);
            y[18]:hook(J,l[384],function()
              return gP[l[1019]];
            end,function(J)
              gP:set(J);
            end,{[l[457]]=wP[l[457]],[l[850]]=wP[l[850]]});
            return gP;
          end
          fP[l[1223]]=NP;
          local function J(NP,BP)
            NP=s[87]();
            BP=X(BP,{[l[572]]=l[166],[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local wP=aP[l[1594]--[[__index]]];
            local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
            local wP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
            local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
            D(VP,l[1158]);
            local _P=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},VP);
            local XP=a;
            local xP=l[859];
            local kP={};
            kP[l[1150]]=f();
            kP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
            kP[l[948]]=NP[l[1459]][l[772]](l[393],l[303],l[659],l[393]);
            kP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
            kP[l[1646]]=l[229];
            kP[l[1451]]=y[30](l[1680]);
            kP[l[936]]=R[l[1379]];
            kP[l[2]]=l[1431];
            kP[l[1557]]=NP[l[128]][l[1557]][l[220]];
            kP[l[711]]=l[1092];
            local vP=XP(xP,kP,VP);
            local XP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[1243],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[393],l[229],l[393],l[750]),[l[1535]]=R[l[966]],[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1092]},VP);
            K(XP,l[117],{NP[l[677]][l[772]](l[393],l[731]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[731])});
            local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[221],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},VP);
            local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},VP);
            K(kP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
            local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},WP),{[l[266]]=WP,[l[230]]=nil,[l[1273]]=l[1329]};
            local EP=l[1329];
            local QP,tP,RP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
            RP[l[572]]=BP[l[572]];
            QP(tP,RP);
            local function NP()
              xP[l[1420]]=iP[l[1273]]and l[538]or z(iP[l[230]]);
            end
            local function WP()
              local QP,tP,RP={},l[1646],iP[l[1273]]and l[393]or(EP and l[613]or l[841]);
              QP[tP]=RP;
              P(VP,H,QP);
              tP,QP,RP={},l[747],iP[l[1273]]and l[120]or(EP and l[323]or l[1373]);
              tP[QP]=RP;
              P(_P,H,tP);
              P(kP,H,{[l[1646]]=iP[l[1273]]and l[986]or l[229]});
              P(XP,H,{[l[1646]]=iP[l[1273]]and l[1209]or l[615]});
              P(xP,H,{[l[916]]=iP[l[1273]]and l[393]or l[1209],[l[510]]=iP[l[1273]]and R[l[98]]or R[l[1095]]});
              tP,QP,RP={},l[2],iP[l[1273]]and l[393]or(EP and l[1209]or l[1431]);
              tP[QP]=RP;
              tP[l[936]]=iP[l[1273]]and R[l[98]]or R[l[1379]];
              P(vP,H,tP);
              P(wP,H,{[l[916]]=(iP[l[1273]]or EP)and l[1209]or l[615]});
            end
            local function wP(VP,VP,_P)
              local XP,xP=s[87](),VP;
              xP=if XP[l[40]](xP)==l[409]then XP[l[199]](l[59],XP[l[1146]](function()
                local kP=s[87]();
                return kP[l[128]][l[880]--[[readu32]]][VP];
              end))else xP;
              if XP[l[1703]](xP)~=l[802]or xP==iP[l[230]] then
                return;
              end
              iP[l[230]]=xP;
              NP();
              if not _P and BP[l[1617]] then
                I(BP[l[1617]],xP[l[1150]]);
              end
            end
            iP[l[1255]]=wP;
            local function wP(VP)
              return iP[l[230]]and iP[l[230]][l[1150]]or nil;
            end
            iP[l[506]]=wP;
            local function wP()
              iP[l[1273]]=l[1329];
              NP();
              WP();
            end
            d(IP[l[445]],function()
              if iP[l[1273]] then
                lP(nil);
                wP();
                return;
              end
              iP[l[1273]]=l[383];
              NP();
              WP();
              y[18]:chime(l[1352]);
              lP(function(VP)
                wP();
                if VP then
                  iP:set(VP);
                  y[18]:chime(l[1320]);
                end
              end,wP);
            end);
            d(IP[l[1538]],function()
              EP=l[383];
              WP();
            end);
            d(IP[l[1628]],function()
              EP=l[1329];
              WP();
            end);
            iP:set(BP[l[950]]);
            NP();
            WP();
            y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[230],function()
              return iP:get();
            end,function(NP)
              iP:set(NP);
            end);
            return iP;
          end
          fP[l[166]]=J;
          local function J(NP,BP)
            NP=s[87]();
            BP=X(BP,{[l[572]]=l[654],[l[1206]]={},[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local wP=aP[l[1594]--[[__index]]];
            local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
            wP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[303]},WP);
            local VP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1218],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},wP);
            local _P=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
            D(_P,l[1158]);
            local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},_P);
            local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[289],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},_P);
            local kP=a;
            local vP=l[859];
            local IP={};
            IP[l[1150]]=f();
            IP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
            IP[l[948]]=NP[l[1459]][l[772]](l[229],l[348],l[659],l[393]);
            IP[l[1639]]=NP[l[1459]][l[588]](l[1307],l[1307]);
            IP[l[1646]]=l[229];
            IP[l[1451]]=y[30](l[606]--[[readu16]]);
            IP[l[936]]=R[l[1379]];
            IP[l[2]]=l[1431];
            IP[l[1557]]=NP[l[128]][l[1557]][l[220]];
            IP[l[711]]=l[1092];
            local iP=kP(vP,IP,_P);
            local kP,vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),a(l[211],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[688]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[393]),[l[1535]]=R[l[641]],[l[1646]]=l[269],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
            D(vP,l[1158]);
            a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},vP);
            local IP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=NP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP);
            local EP,QP=l[755],{[l[407]]=NP[l[128]][l[407]][l[537]]};
            QP[l[536]]=NP[l[740]][l[772]](l[393],l[229]);
            a(EP,QP,IP);
            a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786]),[l[1612]]=NP[l[740]][l[772]](l[393],l[786]),[l[517]]=NP[l[740]][l[772]](l[393],l[786])},IP);
            local tP={[l[266]]=WP,[l[404]]=l[1329],[l[955]]=nil,[l[1072]]={}};
            wP,EP,QP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
            QP[l[572]]=BP[l[572]];
            wP(EP,QP);
            local function wP(QP)
              local RP,gP=s[87](),tP[l[955]]==QP[l[572]];
              local uP,UP,MP,sC=QP[l[1642]],{},l[1646],gP and l[841]or(QP[l[892]]and l[659]or l[229]);
              UP[MP]=sC;
              P(uP,n,UP);
              MP,sC=QP[l[1377]],{[l[1646]]=gP and l[1296]or l[229]};
              sC[l[1639]]=RP[l[1459]][l[588]](gP and l[1092]or l[786],gP and l[1092]or l[786]);
              P(MP,n,sC);
              P(QP[l[1615]],n,{[l[916]]=gP and l[393]or(QP[l[892]]and l[820]or l[323]),[l[510]]=gP and R[l[1095]]or R[l[1379]]});
            end
            local function QP()
              local RP=vP[l[1639]][l[636]][l[1485]];
              local gP=tP[l[404]]and e(IP)[l[636]]or l[393];
              local uP=WP[l[1639]][l[636]][l[1485]];
              local UP=l[658]+(tP[l[404]]and gP+l[1158]or l[393]);
              local MP=iP[l[500]];
              local sC=tP[l[404]]and l[1510]or l[393];
              b(vP,l[1431],tP[l[404]]and N or q,function(lC)
                local LC=s[87]();
                vP[l[1639]]=LC[l[1459]][l[772]](l[229],l[1026],l[393],LC[l[35]][l[499]](RP+(gP-RP)*lC+l[659]));
                WP[l[1639]]=LC[l[1459]][l[772]](l[229],l[393],l[393],LC[l[35]][l[499]](uP+(UP-uP)*lC+l[659]));
              end);
              b(iP,l[1431],N,function(WP)
                iP[l[500]]=MP+(sC-MP)*WP;
              end);
              P(XP,H,{[l[747]]=tP[l[404]]and l[739]or l[1373]});
            end
            local function WP(XP,XP)
              tP[l[404]]=XP and l[383]or l[1329];
              QP();
            end
            tP[l[1521]--[[0]]]=WP;
            local function WP(XP,vP,QP)
              XP=s[87]();
              if XP[l[40]](vP)~=l[409]or vP==tP[l[955]]and not y[18][l[921]] then
                return;
              end
              if not XP[l[1346]][l[23]](BP[l[1206]],vP) then
                return;
              end
              tP[l[955]]=vP;
              xP[l[1420]]=vP;
              for XP,XP in y[3],tP[l[1072]],nil do
                wP(XP);
              end;
              if not QP and BP[l[1617]] then
                I(BP[l[1617]],vP);
              end
            end
            tP[l[1255]]=WP;
            local function XP(xP)
              return tP[l[955]];
            end
            tP[l[506]]=XP;
            for XP,xP in y[3],BP[l[1206]],nil do
              local vP={[l[572]]=xP,[l[892]]=l[1329],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[884]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=XP,[l[711]]=l[1158]},IP)};
              vP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP[l[1466]]);
              D(vP[l[1642]],l[303]);
              K(vP[l[1642]],l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[509],l[986]),NP[l[677]][l[772]](l[229],l[1017])});
              vP[l[1377]]=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[930],l[659],l[393]),[l[1639]]=NP[l[1459]][l[588]](l[786],l[786]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},vP[l[1466]]);
              WP,EP=l[1112],{};
              EP[l[1182]]=NP[l[740]][l[772]](l[229],l[393]);
              a(WP,EP,vP[l[1377]]);
              vP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[1243],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[14],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=xP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP[l[1466]]);
              vP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},vP[l[1466]]);
              d(vP[l[974]][l[1538]],function()
                vP[l[892]]=l[383];
                wP(vP);
              end);
              d(vP[l[974]][l[1628]],function()
                vP[l[892]]=l[1329];
                wP(vP);
              end);
              d(vP[l[974]][l[445]],function()
                tP:set(vP[l[572]]);
                tP:setopen(l[1329]);
                y[18]:chime(l[1320]);
              end);
              tP[l[1072]][XP]=vP;
            end;
            d(kP[l[445]],function()
              tP:setopen(not tP[l[404]]);
              y[18]:chime(l[1352]);
            end);
            d(kP[l[1538]],function()
              P(VP,H,{[l[916]]=l[1209]});
              P(iP,H,{[l[2]]=l[1296]});
              P(_P,H,{[l[1646]]=l[393]});
            end);
            d(kP[l[1628]],function()
              P(VP,H,{[l[916]]=l[615]});
              P(iP,H,{[l[2]]=l[1431]});
              P(_P,H,{[l[1646]]=l[841]});
            end);
            tP:set(BP[l[950]]or BP[l[1206]][l[229]]);
            y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
              return tP[l[955]];
            end,function(NP)
              tP:set(NP);
            end,{[l[284]]=function(NP)
              local wP=s[87]();
              return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
            end});
            return tP;
          end
          fP[l[654]]=J;
          local function J(NP,BP)
            NP=s[87]();
            BP=X(BP,{[l[572]]=l[1336],[l[1206]]={},[l[950]]=nil,[l[850]]=l[930],[l[1693]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
            local VP=aP[l[745]];
            local _P=l[941];
            local XP=NP[l[35]][l[850]](NP[l[35]][l[499]](NP[l[1382]](BP[l[850]])or l[930]),l[229]);
            local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
            local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
            local vP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},xP);
            D(vP,l[1158]);
            local IP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},vP);
            local iP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[662],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP);
            local EP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[551]},vP);
            K(EP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
            local QP=a;
            local tP=l[859];
            local RP={};
            RP[l[1150]]=f();
            RP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
            RP[l[948]]=NP[l[1459]][l[772]](l[229],l[708],l[659],l[393]);
            RP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
            RP[l[1646]]=l[229];
            RP[l[1451]]=y[30](l[606]--[[readu16]]);
            RP[l[936]]=R[l[1379]];
            RP[l[2]]=l[1431];
            RP[l[1557]]=NP[l[128]][l[1557]][l[220]];
            RP[l[711]]=l[1092];
            local gP=QP(tP,RP,vP);
            local QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[730]},vP),a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
            local RP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
            local uP=RP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=NP[l[740]][l[772]](l[393],l[829]),[l[1485]]=NP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=NP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},RP)or nil;
            if RP then
              D(RP,l[930]);
            end
            local UP=a(l[1751],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
            D(UP,l[930]);
            local MP,sC=l[1622],{[l[500]]=l[117]};
            sC[l[1630]]=NP[l[1262]][l[772]]({NP[l[527]][l[772]](l[393],NP[l[360]][l[772]](l[229],l[229],l[229])),NP[l[527]][l[772]](l[229],NP[l[360]][l[353]](l[291],l[291],l[920]))});
            a(MP,sC,UP);
            a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},UP);
            MP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},UP);
            D(MP,l[930]);
            a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},MP);
            local lC=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=NP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=NP[l[128]][l[62]][l[636]],[l[711]]=l[913]},UP);
            local LC=a(l[755],{[l[407]]=NP[l[128]][l[407]][l[537]],[l[536]]=NP[l[740]][l[772]](l[393],l[59])},lC);
            a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[1158]),[l[645]]=NP[l[740]][l[772]](l[393],l[1158]),[l[1612]]=NP[l[740]][l[772]](l[393],l[1158]),[l[517]]=NP[l[740]][l[772]](l[393],l[1158])},lC);
            local yC={[l[266]]=xP,[l[404]]=l[1329],[l[955]]=nil,[l[1406]--[[]]]={},[l[1072]]={},[l[771]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
            local zC=l[1329];
            local TC=l[393];
            MP,sC,wP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
            wP[l[572]]=BP[l[572]];
            MP(sC,wP);
            local function NP(wP)
              if BP[l[1693]] then
                return yC[l[1406]--[[]]][wP]==l[383];
              end
              return yC[l[955]]==wP;
            end
            local function wP()
              local MP,sC=s[87](),{};
              for nC=l[229],#BP[l[1206]],l[229]do
                if yC[l[1406]--[[]]][BP[l[1206]][nC]] then
                  MP[l[1346]][l[968]](sC,BP[l[1206]][nC]);
                end
              end;
              return sC;
            end
            local function MP(sC,nC)
              local JC,HC,fC,aC=s[87](),NP(sC[l[572]]),sC[l[892]]or yC[l[1072]][TC]==sC,nC and n or H;
              local NP,dC,PC,ZC=sC[l[1466]],{},l[1646],HC and l[922]or(fC and l[330]or l[229]);
              dC[PC]=ZC;
              P(NP,aC,dC);
              ZC,nC=sC[l[1473]],{};
              nC[l[747]]=HC and l[509]or l[229];
              P(ZC,aC,nC);
              nC,PC=sC[l[1642]],{};
              PC[l[1646]]=HC and l[1432]or l[229];
              P(nC,aC,PC);
              P(sC[l[451]],aC,{[l[1639]]=JC[l[1459]][l[772]](l[393],l[863],l[393],HC and l[750]or l[393]),[l[1646]]=HC and l[1296]or l[229]});
              P(sC[l[1615]],aC,{[l[916]]=HC and l[393]or(fC and l[263]or l[323]),[l[510]]=HC and R[l[1095]]or R[l[1379]]});
              if BP[l[1693]] then
                nC,NP=sC[l[595]],{};
                NP[l[1646]]=HC and l[1296]or l[229];
                P(nC,aC,NP);
                local NP,nC,GC,YC=sC[l[741]],{},l[747],HC and l[229]or(fC and l[1296]or l[1431]);
                nC[GC]=YC;
                P(NP,aC,nC);
                PC,nC=sC[l[1572]],{[l[2]]=HC and l[393]or l[229]};
                nC[l[1639]]=JC[l[1459]][l[588]](HC and l[730]or l[786],HC and l[730]or l[786]);
                P(PC,aC,nC);
              else
                dC,ZC=sC[l[1040]],{[l[2]]=HC and l[393]or l[229]};
                ZC[l[1639]]=JC[l[1459]][l[588]](HC and l[310]or l[1092],HC and l[310]or l[1092]);
                P(dC,aC,ZC);
              end
            end
            local function NP()
              local sC=s[87]();
              if not BP[l[1693]] then
                iP[l[1420]]=yC[l[955]]or l[31];
                return;
              end
              local nC=wP();
              iP[l[1420]]=#nC>l[393]and sC[l[1346]][l[978]](nC,l[1200])or l[31];
            end
            local function iP()
              P(vP,H,{[l[1646]]=(yC[l[404]]or zC)and l[393]or l[841]});
              local sC,nC,JC={},l[747],yC[l[404]]and l[1431]or(zC and l[323]or l[1373]);
              sC[nC]=JC;
              P(IP,H,sC);
              P(EP,H,{[l[1646]]=yC[l[404]]and l[874]or l[229]});
              P(kP,H,{[l[916]]=(yC[l[404]]or zC)and l[1209]or l[615]});
              P(gP,H,{[l[2]]=(yC[l[404]]or zC)and l[1296]or l[1431],[l[936]]=yC[l[404]]and R[l[1095]]or R[l[1379]]});
            end
            local function kP()
              NP();
              for IP=l[229],#yC[l[1072]],l[229]do
                MP(yC[l[1072]][IP],l[383]);
              end;
            end
            local function IP()
              local EP=s[87]();
              return EP[l[35]][l[819]](#yC[l[1072]],l[229],XP)*_P+l[730];
            end
            local function XP()
              local EP,sC=s[87](),l[393];
              for nC=l[229],#BP[l[1206]],l[229]do
                local JC,HC=EP[l[1146]](function()
                  local fC,aC,dC=s[87](),BP[l[1206]][nC],l[310];
                  local nC,PC=fC[l[128]][l[437]][l[1381]],s[70](fC[l[1689]][l[772]](l[329],l[1655]));
                  return y[8]:GetTextSize(aC,dC,nC,s:ZT(PC));
                end);
                sC=if JC and HC then EP[l[35]][l[850]](sC,HC[l[1437]])else sC;
              end;
              return EP[l[35]][l[139]](sC)+(BP[l[1693]]and l[205]or l[430]);
            end
            local function EP()
              local sC,nC,JC,HC,fC=s[87](),G(YP),e(YP),G(vP),e(vP);
              local aC,dC=HC[l[1437]]-nC[l[1437]],yC[l[771]]and HC[l[636]]-nC[l[636]]-l[1158]or HC[l[636]]-nC[l[636]]+fC[l[636]]+l[1158];
              aC=if aC+yC[l[559]]>JC[l[1437]]-l[930]then sC[l[35]][l[850]](l[930],HC[l[1437]]-nC[l[1437]]+fC[l[1437]]-yC[l[559]])else aC;
              UP[l[948]]=sC[l[1459]][l[588]](sC[l[35]][l[499]](aC+l[659]),sC[l[35]][l[499]](dC+l[659]));
              if RP then
                RP[l[948]]=UP[l[948]];
              end
            end
            local function sC()
              local nC=s[87]();
              yC[l[434]]=IP();
              UP[l[1639]]=nC[l[1459]][l[588]](yC[l[559]],yC[l[434]]);
              if RP then
                RP[l[1639]]=UP[l[1639]];
              end
              EP();
            end
            local function nC()
              local JC=UP[l[1569]];
              local HC=yC[l[404]]and l[393]or l[229];
              local fC=gP[l[500]];
              local aC=yC[l[404]]and l[1510]or l[393];
              b(UP,yC[l[404]]and l[894]or l[304],yC[l[404]]and N or q,function(dC)
                local PC=JC+(HC-JC)*dC;
                UP[l[1569]]=PC;
                if RP then
                  RP[l[1646]]=PC;
                  uP[l[747]]=l[615]+l[411]*PC;
                end
                if dC>=l[229] then
                  UP[l[1324]]=yC[l[404]];
                  if RP then
                    RP[l[1324]]=yC[l[404]];
                  end
                end
              end);
              b(gP,l[1431],N,function(uP)
                gP[l[500]]=fC+(aC-fC)*uP;
              end);
            end
            local function gP(uP)
              local JC,HC,fC=s[87](),lC[l[464]][l[636]]/y[29],j(LC)[l[636]]+l[310];
              local aC=JC[l[1346]][l[23]](yC[l[1072]],uP);
              if not aC or HC<=l[393]or fC<=HC then
                return;
              end
              uP,fC=l[1158]+(aC-l[229])*_P,lC[l[1690]][l[636]];
              if uP<fC then
                lC[l[1690]]=JC[l[1689]][l[772]](l[393],JC[l[35]][l[850]](uP-l[1158],l[393]));
              elseif uP+l[1660]>fC+HC then
                lC[l[1690]]=JC[l[1689]][l[772]](l[393],uP+l[1596]--[[__newindex]]-HC);
              end
            end
            local function _P(uP)
              local JC=yC[l[1072]][TC];
              TC=uP;
              if JC then
                MP(JC,l[383]);
              end
              uP=yC[l[1072]][TC];
              if uP then
                MP(uP,l[383]);
                gP(uP);
              end
            end
            local function uP(JC)
              if #yC[l[1072]]==l[393] then
                return;
              end
              local HC=TC+JC;
              _P(if HC<l[229]then#yC[l[1072]]else if HC>#yC[l[1072]]then l[229]else HC);
              y[18]:chime(l[1320]);
            end
            local function _P(JC)
              if not JC then
                return;
              end
              if BP[l[1693]] then
                yC[l[1406]--[[]]][JC[l[572]]]=not yC[l[1406]--[[]]][JC[l[572]]]or nil;
                kP();
                y[18]:chime(yC[l[1406]--[[]]][JC[l[572]]]and l[404]or l[676]);
                if BP[l[1617]] then
                  I(BP[l[1617]],yC:get());
                end
                return;
              end
              yC:set(JC[l[572]]);
              yC:setopen(l[1329]);
              y[18]:chime(l[1320]);
            end
            local function JC()
              local HC={};
              local fC=s[87]();
              for aC=l[229],#yC[l[1072]],l[229]do
                local dC=yC[l[1072]][aC];
                for aC,aC in y[3],dC[l[608]],nil do
                  aC:Disconnect();
                end;
                dC[l[1466]]:Destroy();
              end;
              fC[l[1346]][l[267]](yC[l[1072]]);
              local aC,dC,PC,ZC,GC=BP[l[1693]]and l[1249]or l[1307],BP[l[1693]]and l[730]or l[688],l[229],#BP[l[1206]],l[229];
              for YC=PC,ZC,GC do
                local PC=BP[l[1206]][YC];
                local ZC={[l[572]]=PC,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=YC,[l[711]]=l[913]},lC)};
                D(ZC[l[1466]],l[1158]);
                ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
                ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[913]},ZC[l[1466]]);
                D(ZC[l[1642]],l[1158]);
                K(ZC[l[1642]],l[393],{fC[l[677]][l[772]](l[393],l[393]),fC[l[677]][l[772]](l[1017],l[1373]),fC[l[677]][l[772]](l[229],l[229])});
                ZC[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=fC[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
                local GC,eC=l[1112],{};
                eC[l[1182]]=fC[l[740]][l[772]](l[229],l[393]);
                a(GC,eC,ZC[l[451]]);
                if BP[l[1693]] then
                  ZC[l[595]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[551],l[659],l[393]),[l[1639]]=fC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
                  D(ZC[l[595]],l[786]);
                  ZC[l[741]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1431]},ZC[l[595]]);
                  HC[1]=l[1572];
                  HC[3]=a;
                  HC[4]=l[859];
                  HC[2]={};
                  HC[2][l[1150]]=f();
                  HC[2][l[1016]]=fC[l[1689]][l[772]](l[659],l[659]);
                  HC[2][l[948]]=fC[l[1459]][l[1368]](l[659],l[659]);
                  HC[2][l[1639]]=fC[l[1459]][l[588]](l[786],l[786]);
                  HC[2][l[1646]]=l[229];
                  HC[2][l[1451]]=y[30](l[1411]);
                  HC[2][l[936]]=R[l[641]];
                  HC[2][l[2]]=l[229];
                  HC[2][l[1557]]=fC[l[128]][l[1557]][l[220]];
                  HC[2][l[711]]=l[1282];
                  HC[5]=(HC[3](HC[4],HC[2],ZC[l[595]]));
                  ZC[HC[1]]=HC[5];
                else
                  HC[6]=l[1040];
                  HC[8]=a;
                  HC[9]=l[859];
                  HC[7]={};
                  HC[7][l[1150]]=f();
                  HC[7][l[1016]]=fC[l[1689]][l[772]](l[229],l[659]);
                  HC[7][l[948]]=fC[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
                  HC[7][l[1639]]=fC[l[1459]][l[588]](l[1092],l[1092]);
                  HC[7][l[1646]]=l[229];
                  HC[7][l[1451]]=y[30](l[1411]);
                  HC[7][l[936]]=R[l[98]];
                  HC[7][l[2]]=l[229];
                  HC[7][l[1557]]=fC[l[128]][l[1557]][l[220]];
                  HC[7][l[711]]=l[1526];
                  HC[10]=(HC[8](HC[9],HC[7],ZC[l[1466]]));
                  ZC[HC[6]]=HC[10];
                end
                ZC[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=fC[l[1459]][l[588]](aC,l[393]),[l[1639]]=fC[l[1459]][l[772]](l[229],-aC-dC,l[229],l[393]),[l[1646]]=l[229],[l[437]]=fC[l[128]][l[437]][l[1381]],[l[1420]]=PC,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=fC[l[128]][l[164]][l[1021]],[l[1634]]=fC[l[128]][l[1634]][l[701]],[l[711]]=l[1526]},ZC[l[1466]]);
                ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1282]},ZC[l[1466]]);
                fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1538]]:Connect(function()
                  local HC=yC[l[1072]][TC];
                  ZC[l[892]]=l[383];
                  TC=l[393];
                  if HC and HC~=ZC then
                    MP(HC,l[383]);
                  end
                  MP(ZC,l[383]);
                end));
                fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1628]]:Connect(function()
                  ZC[l[892]]=l[1329];
                  MP(ZC,l[383]);
                end));
                fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[445]]:Connect(function()
                  _P(ZC);
                end));
                yC[l[1072]][YC]=ZC;
                MP(ZC,l[383]);
              end;
            end
            local HC,fC;
            local function aC()
              local dC=HC;
              if dC then
                HC:Disconnect();
                HC=nil;
              end
            end
            local function dC()
              local PC=fC;
              if PC then
                fC:Disconnect();
                fC=nil;
              end
            end
            local function PC()
              yC:setopen(l[1329]);
            end
            local function ZC()
              local GC=S;
              if GC>l[393] then
                EP();
                return;
              end
              if not LP[l[1600]]or not KP[l[1324]]or not xP[l[1324]] then
                PC();
                return;
              end
              local xP,YC,eC,jC,CC,NC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],vP[l[81]],vP[l[160]];
              GC=CC[l[636]]+NC[l[636]]*l[659];
              if GC<xP[l[636]]or GC>xP[l[636]]+YC[l[636]]or GC<eC[l[636]]or GC>eC[l[636]]+jC[l[636]] then
                PC();
                return;
              end
              EP();
            end
            local function WP(VP)
              local xP=s[87]();
              if y[18][l[1333]]or VP[l[1317]]~=xP[l[128]][l[1317]][l[1441]] then
                return;
              end
              local EP=VP[l[880]--[[readu32]]];
              VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1492]];
              if VP then
                uP(l[229]);
              else
                local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1436]];
                if VP then
                  uP(l[715]);
                else
                  local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1183]]or EP==xP[l[128]][l[880]--[[readu32]]][l[839]];
                  if VP then
                    _P(yC[l[1072]][TC]);
                  elseif EP==xP[l[128]][l[880]--[[readu32]]][l[1739]] then
                    PC();
                  end
                end
              end
            end
            local function VP(_P,xP)
              local EP={};
              _P=s[87]();
              xP=xP and l[383]or l[1329];
              if yC[l[404]]==xP then
                return;
              end
              yC[l[404]]=xP;
              if xP then
                V();
                local xP,uP,GC,YC=G(YP),e(YP),G(vP),e(vP);
                yC[l[559]]=_P[l[35]][l[819]](_P[l[35]][l[850]](XP(),_P[l[35]][l[499]](YC[l[1437]]+l[659])),l[492],_P[l[35]][l[850]](_P[l[35]][l[499]](uP[l[1437]])-l[829],l[492]));
                yC[l[434]]=IP();
                local XP,vP=uP[l[636]]-(GC[l[636]]-xP[l[636]]+YC[l[636]]+l[1158])-l[1158],GC[l[636]]-xP[l[636]]-l[310];
                yC[l[771]]=XP<yC[l[434]]and vP>XP;
                UP[l[1016]]=_P[l[1689]][l[772]](l[393],yC[l[771]]and l[229]or l[393]);
                UP[l[1324]]=l[383];
                tP[l[1324]]=l[383];
                lC[l[1690]]=_P[l[1689]][l[772]]();
                if RP then
                  RP[l[1016]]=UP[l[1016]];
                  RP[l[1324]]=l[383];
                end
                sC();
                kP();
                vP=not BP[l[1693]];
                if vP then
                  uP,XP,GC=l[229],#yC[l[1072]],l[229];
                  for _P=uP,XP,GC do
                    xP=yC[l[1072]][_P][l[572]]==yC[l[955]];
                    if xP then
                      TC=_P;
                      MP(yC[l[1072]][_P],l[383]);
                      gP(yC[l[1072]][_P]);
                      break;
                    end
                  end;
                end
                A,w=PC,UP;
                aC();
                dC();
                EP[1]=(y[10][l[1119]]:Connect(ZC));
                HC=EP[1];
                EP[2]=(y[9][l[1558]]:Connect(WP));
                fC=EP[2];
              else
                aC();
                dC();
                tP[l[1324]]=l[1329];
                TC=l[393];
                local WP=A==PC;
                if WP then
                  A,w=nil,nil;
                end
                for WP=l[229],#yC[l[1072]],l[229]do
                  yC[l[1072]][WP][l[892]]=l[1329];
                  MP(yC[l[1072]][WP],l[383]);
                end;
              end
              iP();
              nC();
            end
            yC[l[1521]--[[0]]]=VP;
            local function WP(VP)
              if not BP[l[1693]] then
                return yC[l[955]];
              end
              return wP();
            end
            yC[l[506]]=WP;
            local function wP(WP,VP,_P)
              local XP=s[87]();
              if BP[l[1693]] then
                WP={};
                if XP[l[40]](VP)==l[1346] then
                  for xP,xP in y[3],VP,nil do
                    WP[xP]=l[383];
                  end;
                elseif XP[l[40]](VP)==l[409] then
                  for xP in XP[l[409]][l[78]](VP,l[397])do
                    WP[XP[l[409]][l[56]](xP,l[381])]=l[383];
                  end;
                else
                  return;
                end
                XP[l[1346]][l[267]](yC[l[1406]--[[]]]);
                for xP=l[229],#BP[l[1206]],l[229]do
                  if WP[BP[l[1206]][xP]] then
                    yC[l[1406]--[[]]][BP[l[1206]][xP]]=l[383];
                  end
                end;
                kP();
                if not _P and BP[l[1617]] then
                  I(BP[l[1617]],yC:get());
                end
                return;
              end
              if XP[l[40]](VP)~=l[409]or VP==yC[l[955]]and not y[18][l[921]]or not XP[l[1346]][l[23]](BP[l[1206]],VP) then
                return;
              end
              yC[l[955]]=VP;
              kP();
              if not _P and BP[l[1617]] then
                I(BP[l[1617]],VP);
              end
            end
            yC[l[1255]]=wP;
            local function wP(WP,VP)
              WP=s[87]();
              if WP[l[40]](VP)~=l[1346] then
                return;
              end
              local _P=BP[l[1693]]and yC:get()or yC[l[955]];
              BP[l[1206]]=VP;
              yC[l[955]]=nil;
              WP[l[1346]][l[267]](yC[l[1406]--[[]]]);
              JC();
              if BP[l[1693]] then
                yC:set(_P,l[383]);
              elseif _P and WP[l[1346]][l[23]](VP,_P) then
                yC:set(_P,l[383]);
              else
                yC:set(VP[l[229]],l[383]);
              end
              NP();
              if not yC[l[404]] then
                return;
              end
              if #VP==l[393] then
                PC();
                return;
              end
              sC();
            end
            yC[l[1087]]=wP;
            d(LC:GetPropertyChangedSignal(l[996]),function()
              local wP=s[87]();
              lC[l[392]]=wP[l[1459]][l[588]](l[393],j(LC)[l[636]]+l[310]);
            end);
            d(tP[l[445]],PC);
            d(QP[l[445]],function()
              if #BP[l[1206]]==l[393] then
                return;
              end
              yC:setopen(not yC[l[404]]);
              y[18]:chime(l[1352]);
            end);
            d(QP[l[1538]],function()
              zC=l[383];
              iP();
            end);
            d(QP[l[1628]],function()
              zC=l[1329];
              iP();
            end);
            JC();
            if BP[l[1693]] then
              if BP[l[950]]~=nil then
                yC:set(BP[l[950]]);
              end
            else
              yC:set(BP[l[950]]or BP[l[1206]][l[229]]);
            end
            NP();
            iP();
            y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
              local NP=s[87]();
              if BP[l[1693]] then
                return NP[l[1346]][l[978]](yC:get(),l[1200]);
              end
              return yC[l[955]];
            end,function(NP)
              yC:set(NP);
            end,{[l[284]]=function(NP)
              local wP=s[87]();
              if not BP[l[1693]] then
                return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
              end
              for WP in wP[l[409]][l[78]](NP,l[397])do
                if not wP[l[1346]][l[23]](BP[l[1206]],wP[l[409]][l[56]](WP,l[381])) then
                  return l[1329];
                end
              end;
              return l[383];
            end});
            return yC;
          end
          fP[l[1336]]=J;
          local function J(NP,BP)
            NP=s[87]();
            BP=X(BP,{[l[572]]=l[138],[l[13]]=nil,[l[1013]]=nil,[l[1617]]=nil});
            fP[l[668]]+=l[229];
            local wP,WP,VP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
            local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
            local wP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[1655]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},_P);
            D(wP,l[1158]);
            local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},wP);
            local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
            D(xP,l[1158]);
            K(xP,l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[1017],l[1373]),NP[l[677]][l[772]](l[229],l[229])});
            local kP=BP[l[13]];
            if kP then
              local vP=a;
              local IP=l[859];
              local iP={};
              iP[l[1150]]=f();
              iP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
              iP[l[948]]=NP[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
              iP[l[1639]]=NP[l[1459]][l[588]](l[750],l[750]);
              iP[l[1646]]=l[229];
              iP[l[1451]]=y[30](BP[l[13]]);
              iP[l[936]]=R[l[1379]];
              iP[l[2]]=l[986];
              iP[l[1557]]=NP[l[128]][l[1557]][l[220]];
              iP[l[711]]=l[1092];
              kP=vP(IP,iP,wP);
            end
            local vP=kP or nil;
            local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP[l[13]]and l[941]or l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],BP[l[13]]and l[860]or l[1069],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[986],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[13]]and NP[l[128]][l[1634]][l[701]]or NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},wP);
            local IP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},wP);
            K(IP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
            local iP,EP,QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=_P};
            tP[l[572]]=BP[l[572]];
            EP(QP,tP);
            local NP={[l[266]]=_P};
            local EP=l[1329];
            local function QP()
              P(wP,H,{[l[1646]]=EP and l[393]or l[841]});
              P(XP,H,{[l[747]]=EP and l[330]or l[1373]});
              P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
              P(kP,H,{[l[916]]=EP and l[393]or l[986],[l[510]]=EP and R[l[1095]]or R[l[1379]]});
              if vP then
                P(vP,H,{[l[2]]=EP and l[393]or l[986],[l[936]]=EP and R[l[1095]]or R[l[1379]]});
              end
            end
            local function wP(XP)
              xP[l[1646]]=l[1567];
              IP[l[1646]]=l[263];
              P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
              P(IP,H,{[l[1646]]=l[229]});
              y[18]:chime(l[1320]);
              if BP[l[1617]] then
                I(BP[l[1617]]);
              end
            end
            NP[l[1498]]=wP;
            d(iP[l[445]],function()
              NP:fire();
            end);
            d(iP[l[1538]],function()
              EP=l[383];
              QP();
            end);
            d(iP[l[1628]],function()
              EP=l[1329];
              QP();
            end);
            local wP=SP(_P,BP[l[572]],WP,VP,{[l[1463]]=BP[l[1013]]or hP..l[1074]..BP[l[572]],[l[103]]=nil,[l[649]]=l[1329],[l[1498]]=function(SP)
              if SP then
                NP:fire();
              end
            end});
            NP[l[1686]]=wP;
            d(iP[l[861]],function()
              if not wP:flip() then
                return;
              end
              y[18]:chime(l[1352]);
            end);
            QP();
            return NP;
          end
          fP[l[138]]=J;
          local function J(NP,SP)
            NP=s[87]();
            SP=X(if NP[l[40]](SP)==l[409]then{[l[572]]=SP}else SP,{[l[572]]=l[1094],[l[13]]=nil,[l[1141]]=l[1329],[l[73]]=nil});
            fP[l[668]]+=l[229];
            local BP=aP[l[1594]--[[__index]]];
            local wP=a(l[211],{[l[1150]]=f(),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],l[393],l[393],l[393])or NP[l[1459]][l[772]](l[229],l[393],l[393],l[1243]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},BP);
            local WP,VP,_P=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=wP};
            _P[l[572]]=SP[l[572]];
            WP(VP,_P);
            BP=l[303];
            if SP[l[13]] then
              BP=l[1655];
              local WP=a;
              local VP=l[859];
              local _P={};
              _P[l[1150]]=f();
              _P[l[1016]]=NP[l[1689]][l[772]](l[393],l[393]);
              _P[l[948]]=NP[l[1459]][l[588]](l[303],l[303]);
              _P[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
              _P[l[1646]]=l[229];
              _P[l[1451]]=y[30](SP[l[13]]);
              _P[l[936]]=R[l[1379]];
              _P[l[2]]=l[1431];
              _P[l[1557]]=NP[l[128]][l[1557]][l[220]];
              _P[l[711]]=l[1158];
              WP(VP,_P,wP);
            else
            end
            local WP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP,l[393]),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[393],l[393])or NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[229],l[393]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=NP[l[1130]](SP[l[572]]),[l[510]]=SP[l[73]]or R[l[1379]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=not SP[l[1141]]and NP[l[128]][l[164]][l[1021]]or NP[l[128]][l[164]][l[31]],[l[789]]=SP[l[1141]]and l[383]or l[1329],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[65]]=SP[l[1141]]and NP[l[128]][l[65]][l[1728]]or NP[l[128]][l[65]][l[46]],[l[711]]=l[1158]},wP);
            if SP[l[1141]] then
              a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786])},wP);
            end
            BP={[l[266]]=wP,[l[1095]]=WP};
            local function NP(SP,wP)
              SP=s[87]();
              WP[l[1420]]=SP[l[1130]](wP);
            end
            BP[l[1255]]=NP;
            local function NP(SP)
              return WP[l[1420]];
            end
            BP[l[506]]=NP;
            local function NP(SP,wP)
              SP=s[87]();
              if SP[l[1703]](wP)==l[360] then
                WP[l[510]]=wP;
              end
            end
            BP[l[539]]=NP;
            return BP;
          end
          fP[l[1094]]=J;
          local function J(NP,SP)
            local BP=s[87]();
            SP=X(SP,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1013]]=nil,[l[1617]]=nil});
            if SP[l[230]]and BP[l[1703]](R[SP[l[230]]])==l[360] then
              local wP=SP[l[1617]];
              SP[l[950]]=R[SP[l[230]]];
              SP[l[1617]]=function(WP)
                y[18]:recolor(SP[l[230]],WP);
                if wP then
                  wP(WP);
                end
              end;
            end
            fP[l[668]]+=l[229];
            local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
            local VP=aP[l[745]];
            local aP=l[291];
            local _P=l[291];
            local XP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
            local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1099],l[229],l[393]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=SP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},XP);
            local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[658],l[829]),[l[1535]]=SP[l[950]],[l[1418]]=l[393],[l[711]]=l[1158]},XP);
            D(kP,l[786]);
            local vP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[986]},kP);
            wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},kP);
            D(wP,l[786]);
            K(wP,l[117],{BP[l[677]][l[772]](l[393],l[1567]),BP[l[677]][l[772]](l[229],l[229])});
            local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[1452],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[913],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},XP),a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
            local EP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
            local GP=EP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=BP[l[740]][l[772]](l[393],l[829]),[l[1485]]=BP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=BP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},EP)or nil;
            if EP then
              D(EP,l[930]);
            end
            local QP=a(l[1751],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
            D(QP,l[930]);
            wP,NP=l[1622],{[l[500]]=l[117]};
            NP[l[1630]]=BP[l[1262]][l[772]]({BP[l[527]][l[772]](l[393],BP[l[360]][l[772]](l[229],l[229],l[229])),BP[l[527]][l[772]](l[229],BP[l[360]][l[353]](l[291],l[291],l[920]))});
            a(wP,NP,QP);
            a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},QP);
            NP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},QP);
            D(NP,l[930]);
            a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},NP);
            local tP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[730]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[422]),[l[1535]]=BP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
            D(tP,l[1158]);
            wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
            D(wP,l[1158]);
            local RP,gP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]](l[229],l[229],l[229]))};
            gP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[393]),BP[l[677]][l[772]](l[229],l[229])});
            a(RP,gP,wP);
            gP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
            D(gP,l[1158]);
            wP,NP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]]()),[l[500]]=l[117]};
            NP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[229]),BP[l[677]][l[772]](l[229],l[393])});
            a(wP,NP,gP);
            a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},tP);
            local uP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},tP);
            RP,NP=l[1112],{};
            NP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
            a(RP,NP,uP);
            a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},uP);
            local NP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[633]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
            D(NP,l[303]);
            a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},NP);
            wP={};
            for UP=l[393],l[1158],l[229]do
              BP[l[1346]][l[968]](wP,BP[l[527]][l[772]](UP/l[1158],BP[l[360]][l[149]](UP/l[1158],l[229],l[229])));
            end;
            gP,RP=l[1622],{};
            RP[l[1630]]=BP[l[1262]][l[772]](wP);
            a(gP,RP,NP);
            local UP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[948]]=BP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},NP);
            gP,wP=l[1112],{};
            wP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
            a(gP,wP,UP);
            a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},UP);
            local MP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1743],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=p(SP[l[950]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[913]},QP);
            D(MP,l[303]);
            local sC=a(l[734],{[l[1161]]=BP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[411]},MP);
            local function lC(LC,yC)
              local zC=s[87]();
              local TC=a;
              local nC=l[1742];
              local JC={};
              JC[l[1150]]=f();
              JC[l[1016]]=zC[l[1689]][l[772]](l[229],l[393]);
              JC[l[948]]=zC[l[1459]][l[772]](l[229],LC,l[393],l[1394]);
              JC[l[1639]]=zC[l[1459]][l[588]](l[1707],l[1707]);
              JC[l[1535]]=R[l[1466]];
              JC[l[1646]]=l[229];
              JC[l[1418]]=l[393];
              JC[l[1451]]=y[30](yC);
              JC[l[936]]=R[l[1379]];
              JC[l[2]]=l[986];
              JC[l[1557]]=zC[l[128]][l[1557]][l[220]];
              JC[l[711]]=l[913];
              local LC=TC(nC,JC,QP);
              D(LC,l[303]);
              d(LC[l[1538]],function()
                P(LC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
              end);
              d(LC[l[1628]],function()
                P(LC,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
              end);
              return LC;
            end
            local LC=lC(l[1726],l[1549]);
            local yC=lC(l[1026],l[967]);
            local lC={[l[266]]=XP,[l[404]]=l[1329],[l[1409]]=SP[l[950]],[l[771]]=l[1329]};
            local zC={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
            local TC,nC=l[1329];
            local JC=l[1329];
            local HC=l[393];
            local function fC(aC)
              local dC=s[87]();
              if not SP[l[1617]] then
                return;
              end
              local PC=y[18][l[921]];
              if PC then
                local ZC=HC;
                HC=ZC+l[229];
                ZC=nil;
                ZC,nC=l[1329],nil;
                JC=ZC;
                I(SP[l[1617]],aC);
                return;
              end
              nC=aC;
              PC=JC;
              if PC then
                return;
              end
              JC=l[383];
              aC=HC;
              HC=aC+l[229];
              local aC=HC;
              local PC=y[18][l[1478]];
              dC[l[1022]][l[1330]](l[1296],function()
                local dC=HC;
                if aC~=dC then
                  return;
                end
                dC=nC;
                local HC=dC;
                nC=nil;
                JC=l[1329];
                if HC and y[18][l[630]]and PC==y[18][l[1478]] then
                  I(SP[l[1617]],HC);
                end
              end);
            end
            gP,RP,wP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=XP};
            wP[l[572]]=SP[l[572]];
            gP(RP,wP);
            zC[l[434]],zC[l[900]],zC[l[999]]=BP[l[360]][l[1412]](SP[l[950]]);
            local function BP()
              local wP=s[87]();
              P(vP,H,{[l[747]]=(lC[l[404]]or TC)and l[393]or l[986]});
              P(xP,H,{[l[916]]=(lC[l[404]]or TC)and l[1209]or l[615]});
              P(kP,H,{[l[1639]]=wP[l[1459]][l[588]]((lC[l[404]]or TC)and l[688]or l[658],(lC[l[404]]or TC)and l[114]or l[829])});
            end
            local function wP(FP,xP)
              local vP=s[87]();
              local RP,gP,nC=vP[l[360]][l[149]](zC[l[434]],zC[l[900]],zC[l[999]]),vP[l[1459]][l[1368]](zC[l[900]],l[229]-zC[l[999]]),vP[l[1459]][l[772]](zC[l[434]],l[393],l[659],l[393]);
              if xP then
                uP[l[948]]=gP;
                UP[l[948]]=nC;
                uP[l[1535]]=RP;
                tP[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229]);
                kP[l[1535]]=RP;
              else
                P(uP,n,{[l[948]]=gP,[l[1535]]=RP});
                P(UP,n,{[l[948]]=nC});
                P(tP,n,{[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229])});
                P(kP,n,{[l[1535]]=RP});
              end
              if not MP:IsFocused() then
                MP[l[1420]]=p(RP);
              end
              lC[l[1409]]=RP;
              if FP then
                fC(RP);
              end
            end
            local function FP()
              local xP,vP,RP,gP,uP=s[87](),G(YP),e(YP),G(kP),e(kP);
              local UP,nC=gP[l[1437]]-vP[l[1437]]+uP[l[1437]]-aP,lC[l[771]]and gP[l[636]]-vP[l[636]]-l[1158]or gP[l[636]]-vP[l[636]]+uP[l[636]]+l[1158];
              UP=if UP+aP>RP[l[1437]]-l[930]then RP[l[1437]]-l[930]-aP else UP;
              QP[l[948]]=xP[l[1459]][l[588]](xP[l[35]][l[499]](xP[l[35]][l[850]](UP,l[930])+l[659]),xP[l[35]][l[499]](nC+l[659]));
              if EP then
                EP[l[948]]=QP[l[948]];
              end
            end
            local function xP()
              local vP=QP[l[1569]];
              local RP=lC[l[404]]and l[393]or l[229];
              b(QP,lC[l[404]]and l[894]or l[304],lC[l[404]]and N or q,function(gP)
                local uP=vP+(RP-vP)*gP;
                QP[l[1569]]=uP;
                if EP then
                  EP[l[1646]]=uP;
                  GP[l[747]]=l[615]+l[411]*uP;
                end
                if gP>=l[229] then
                  QP[l[1324]]=lC[l[404]];
                  if EP then
                    EP[l[1324]]=lC[l[404]];
                  end
                end
              end);
            end
            local GP;
            local function vP()
              local RP=GP;
              if RP then
                GP:Disconnect();
                GP=nil;
              end
            end
            local function RP()
              local gP=S;
              if gP>l[393] then
                return;
              end
              lC:setopen(l[1329]);
            end
            local function gP()
              local uP=S;
              if uP>l[393] then
                FP();
                return;
              end
              if not LP[l[1600]]or not KP[l[1324]]or not XP[l[1324]] then
                lC:setopen(l[1329]);
                return;
              end
              local XP,UP,nC,JC,HC,fC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],kP[l[81]],kP[l[160]];
              uP=HC[l[636]]+fC[l[636]]*l[659];
              if uP<XP[l[636]]or uP>XP[l[636]]+UP[l[636]]or uP<nC[l[636]]or uP>nC[l[636]]+JC[l[636]] then
                lC:setopen(l[1329]);
                return;
              end
              FP();
            end
            local function VP(XP,uP)
              local UP={};
              XP=s[87]();
              uP=uP and l[383]or l[1329];
              if lC[l[404]]==uP then
                return;
              end
              lC[l[404]]=uP;
              if uP then
                V();
                local V,uP,nC,JC=G(YP),e(YP),G(kP),e(kP);
                local G,kP=uP[l[636]]-(nC[l[636]]-V[l[636]]+JC[l[636]]+l[1158])-l[1158],nC[l[636]]-V[l[636]]-l[310];
                lC[l[771]]=G<_P and kP>G;
                QP[l[1016]]=XP[l[1689]][l[772]](l[393],lC[l[771]]and l[229]or l[393]);
                QP[l[1639]]=XP[l[1459]][l[588]](aP,_P);
                QP[l[1324]]=l[383];
                iP[l[1324]]=l[383];
                if EP then
                  EP[l[1016]]=QP[l[1016]];
                  EP[l[1639]]=QP[l[1639]];
                  EP[l[1324]]=l[383];
                end
                FP();
                A,w=RP,QP;
                vP();
                UP[1]=(y[10][l[1119]]:Connect(gP));
                GP=UP[1];
              else
                vP();
                iP[l[1324]]=l[1329];
                local G=A==RP;
                if G then
                  A,w=nil,nil;
                end
                if MP:IsFocused() then
                  MP:ReleaseFocus();
                end
              end
              BP();
              xP();
            end
            lC[l[1521]--[[0]]]=VP;
            local function G(A,w)
              A=s[87]();
              w=if A[l[1703]](w)==l[409]then r(w)else w;
              if A[l[1703]](w)~=l[360] then
                return;
              end
              zC[l[434]],zC[l[900]],zC[l[999]]=A[l[360]][l[1412]](w);
              wP(l[383]);
            end
            lC[l[1255]]=G;
            local function G(A)
              return lC[l[1409]];
            end
            lC[l[506]]=G;
            local function G()
              if not zC[l[259]] then
                return;
              end
              zC[l[259]]=l[1329];
              zC[l[700]]=nil;
              if zC[l[1731]] then
                zC[l[1731]]:Disconnect();
                zC[l[1731]]=nil;
              end
              WP[l[1195]]=l[383];
              O(l[715]);
            end
            local function A()
              local w=s[87]();
              if zC[l[259]]and zC[l[700]] then
                local V,aP=w[l[1146]](function()
                  zC[l[700]]();
                  wP(l[383],l[383]);
                end);
                if not V then
                  G();
                  w[l[972]](l[1752]..w[l[1130]](aP));
                end
              end
            end
            local function w(V,aP)
              d(V[l[956]],G);
              d(V[l[1558]],function(GP)
                local FP=s[87]();
                if GP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and GP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
                  return;
                end
                if zC[l[259]] then
                  return;
                end
                zC[l[259]]=l[383];
                zC[l[700]]=aP;
                zC[l[225]]=GP;
                O(l[229]);
                zC[l[1731]]=B(GP,G);
                WP[l[1195]]=l[1329];
                A();
              end);
              d(V[l[412]],function(B)
                local V=s[87]();
                if B[l[1317]]==V[l[128]][l[1317]][l[1356]]or B[l[1317]]==V[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
                  G();
                end
              end);
            end
            w(tP,function()
              local B,V,aP,GP=s[87](),tP[l[81]],tP[l[160]],v(zC[l[225]]);
              zC[l[900]]=B[l[35]][l[819]]((GP[l[1437]]-V[l[1437]])/B[l[35]][l[850]](aP[l[1437]],l[229]),l[393],l[229]);
              zC[l[999]]=l[229]-B[l[35]][l[819]]((GP[l[636]]-V[l[636]])/B[l[35]][l[850]](aP[l[636]],l[229]),l[393],l[229]);
            end);
            w(NP,function()
              local B,w,V=s[87](),NP[l[81]],NP[l[160]];
              zC[l[434]]=B[l[35]][l[819]]((v(zC[l[225]])[l[1437]]-w[l[1437]])/B[l[35]][l[850]](V[l[1437]],l[229]),l[393],l[229]);
            end);
            d(y[9][l[412]],function(B)
              local w=s[87]();
              if B[l[1317]]==w[l[128]][l[1317]][l[1356]]or B[l[1317]]==w[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
                G();
              end
            end);
            d(y[9][l[233]],function(G)
              local B=s[87]();
              if not zC[l[259]] then
                return;
              end
              if G[l[1317]]==B[l[128]][l[1317]][l[765]]or G[l[1317]]==B[l[128]][l[1317]][l[239]] then
                if G[l[1317]]==B[l[128]][l[1317]][l[239]]and G~=zC[l[225]] then
                  return;
                end
                A();
              end
            end);
            d(MP[l[505]],function()
              O(l[229]);
              P(sC,H,{[l[747]]=l[615]});
            end);
            d(MP[l[722]],function()
              local G=s[87]();
              O(l[715]);
              P(sC,H,{[l[747]]=l[411]});
              local B=r(MP[l[1420]]);
              if B then
                zC[l[434]],zC[l[900]],zC[l[999]]=G[l[360]][l[1412]](B);
              end
              wP(l[383]);
            end);
            local function G(B)
              B[l[936]]=R[l[98]];
              B[l[2]]=l[393];
              P(B,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
            end
            d(LC[l[445]],function()
              local B=s[87]();
              if y[14] then
                B[l[1146]](y[14],p(lC[l[1409]]));
              end
              G(LC);
              y[18]:chime(l[1320]);
            end);
            d(yC[l[445]],function()
              local B=s[87]();
              local A=r(y[15]and B[l[199]](l[59],B[l[1146]](y[15])));
              if A then
                zC[l[434]],zC[l[900]],zC[l[999]]=B[l[360]][l[1412]](A);
                wP(l[383]);
                G(yC);
                y[18]:chime(l[1320]);
              end
            end);
            d(iP[l[445]],RP);
            d(IP[l[445]],function()
              lC:setopen(not lC[l[404]]);
              y[18]:chime(l[1352]);
            end);
            d(IP[l[1538]],function()
              TC=l[383];
              BP();
            end);
            d(IP[l[1628]],function()
              TC=l[1329];
              BP();
            end);
            wP(l[1329],l[383]);
            BP();
            VP=SP[l[1013]]or SP[l[230]]and l[1321]..SP[l[230]];
            y[18]:hook(VP or hP..l[1074]..SP[l[572]],l[1409],function()
              return lC[l[1409]];
            end,function(G)
              lC:set(G);
            end);
            return lC;
          end
          fP[l[1409]]=J;
          return fP;
        end
        cP[l[146]]=F;
        local function J(G,B)
          local A=s[87]();
          B=X(B,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1132]]=l[356],[l[1013]]=nil,[l[1617]]=nil});
          if B[l[230]]and A[l[1703]](R[B[l[230]]])==l[360] then
            local w=B[l[1617]];
            B[l[950]]=R[B[l[230]]];
            B[l[1617]]=function(F)
              y[18]:recolor(B[l[230]],F);
              if w then
                w(F);
              end
            end;
          end
          G=AP(B[l[1132]]);
          local w,F=mP(G,l[1295]);
          A[l[1346]][l[968]](OP,{[l[590]]=F,[l[572]]=B[l[572]],[l[12]]={}});
          F=a(l[211],{[l[1150]]=f(),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},w);
          D(F,l[1092]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=A[l[1689]][l[772]](l[393],l[229]),[l[948]]=A[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},F);
          K(a(l[211],{[l[1150]]=f(),[l[948]]=A[l[1459]][l[588]](l[393],l[688]),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},w),l[393],{A[l[677]][l[772]](l[393],l[229]),A[l[677]][l[772]](l[841],l[874]),A[l[677]][l[772]](l[659],l[393]),A[l[677]][l[772]](l[804],l[874]),A[l[677]][l[772]](l[229],l[229])});
          a(l[1070],{[l[1150]]=f(),[l[948]]=A[l[1459]][l[588]](l[688],l[393]),[l[1639]]=A[l[1459]][l[772]](l[229],l[644],l[229],l[393]),[l[1646]]=l[229],[l[437]]=A[l[128]][l[437]][l[1381]],[l[1420]]=B[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=A[l[128]][l[164]][l[1021]],[l[711]]=l[1092]},F);
          local G,V,fP=a(l[211],{[l[1150]]=f(),[l[1016]]=A[l[1689]][l[772]](l[393],l[659]),[l[948]]=A[l[1459]][l[772]](l[393],l[730],l[659],l[393]),[l[1639]]=A[l[1459]][l[588]](l[310],l[310]),[l[1535]]=B[l[950]],[l[1418]]=l[393],[l[711]]=l[1092]},F),l[1112],{};
          fP[l[1182]]=A[l[740]][l[772]](l[229],l[393]);
          a(V,fP,G);
          a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[615]},G);
          local A,F,V={[l[852]--[[readi16]]]=w,[l[1409]]=B[l[950]],[l[275]]=G},{};
          local G=l[1329];
          local fP=l[393];
          local function aP(GP)
            local NP=s[87]();
            if not B[l[1617]] then
              return;
            end
            local SP=y[18][l[921]];
            if SP then
              local BP=fP;
              fP=BP+l[229];
              BP=nil;
              BP,V=l[1329],nil;
              G=BP;
              I(B[l[1617]],GP);
              return;
            end
            V=GP;
            SP=G;
            if SP then
              return;
            end
            G=l[383];
            GP=fP;
            fP=GP+l[229];
            local GP=fP;
            local SP=y[18][l[1478]];
            NP[l[1022]][l[1330]](l[1296],function()
              local NP=fP;
              if GP~=NP then
                return;
              end
              NP=V;
              local fP=NP;
              V=nil;
              G=l[1329];
              if fP and y[18][l[630]]and SP==y[18][l[1478]] then
                I(B[l[1617]],fP);
              end
            end);
          end
          local function G(V,fP)
            A[l[1409]]=V;
            if fP then
              aP(V);
            end
          end
          A[l[1328]]=G;
          local function V(fP,aP)
            fP=s[87]();
            aP=if fP[l[1703]](aP)==l[409]then r(aP)else aP;
            if fP[l[1703]](aP)==l[360] then
              F[l[391]](aP);
            end
          end
          A[l[1255]]=V;
          local function V(fP)
            return A[l[1409]];
          end
          A[l[506]]=V;
          local function V(fP,aP)
            local GP=s[87]();
            local NP=a;
            local SP=l[1742];
            local BP={};
            BP[l[1150]]=f();
            BP[l[1016]]=GP[l[1689]][l[772]](l[229],l[659]);
            BP[l[948]]=GP[l[1459]][l[772]](l[229],fP,l[393],l[1413]);
            BP[l[1639]]=GP[l[1459]][l[588]](l[1707],l[1707]);
            BP[l[1535]]=R[l[1466]];
            BP[l[1646]]=l[229];
            BP[l[1418]]=l[393];
            BP[l[1451]]=y[30](aP);
            BP[l[936]]=R[l[1379]];
            BP[l[2]]=l[986];
            BP[l[1557]]=GP[l[128]][l[1557]][l[220]];
            BP[l[711]]=l[1092];
            local fP=NP(SP,BP,w);
            D(fP,l[303]);
            d(fP[l[1538]],function()
              P(fP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
            end);
            d(fP[l[1628]],function()
              P(fP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
            end);
            return fP;
          end
          local fP=V(l[1263],l[1549]);
          local aP=V(l[1026],l[967]);
          local function V(GP)
            GP[l[936]]=R[l[98]];
            GP[l[2]]=l[393];
            P(GP,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
          end
          d(fP[l[445]],function()
            local GP=s[87]();
            if y[14] then
              GP[l[1146]](y[14],p(A[l[1409]]));
            end
            V(fP);
          end);
          d(aP[l[445]],function()
            local p=s[87]();
            local fP=r(y[15]and p[l[199]](l[59],p[l[1146]](y[15])));
            if fP then
              F[l[391]](fP);
              V(aP);
            end
          end);
          DP(w,A,F);
          G=B[l[1013]]or B[l[230]]and l[1321]..B[l[230]];
          y[18]:hook(G or oP..l[1074]..B[l[572]],l[1409],function()
            return A[l[1409]];
          end,function(G)
            A:set(G);
          end);
          return A;
        end
        cP[l[1409]]=J;
        local function J(G,p)
          G=s[87]();
          p=X(p,{[l[572]]=l[1104],[l[1132]]=l[356]});
          local r=AP(p[l[1132]]);
          local B,A=mP(r,l[994]);
          G[l[1346]][l[968]](OP,{[l[590]]=A,[l[572]]=p[l[572]],[l[12]]={}});
          r=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},B);
          D(r,l[1092]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[393],l[229]),[l[948]]=G[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},r);
          local A=a;
          local w=l[859];
          local F={};
          F[l[1150]]=f();
          F[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
          F[l[948]]=G[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
          F[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
          F[l[1646]]=l[229];
          F[l[1451]]=y[30](l[317]);
          F[l[936]]=R[l[1379]];
          F[l[2]]=l[986];
          F[l[1557]]=G[l[128]][l[1557]][l[220]];
          F[l[711]]=l[1092];
          A(w,F,r);
          a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=G[l[1459]][l[772]](l[229],l[207],l[229],l[393]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},r);
          K(a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[393],l[688]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},B),l[393],{G[l[677]][l[772]](l[393],l[229]),G[l[677]][l[772]](l[841],l[874]),G[l[677]][l[772]](l[659],l[393]),G[l[677]][l[772]](l[804],l[874]),G[l[677]][l[772]](l[229],l[229])});
          local A=a(l[1439],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[392]]=G[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[1158]},B);
          D(A,l[1158]);
          a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},A);
          local w=a(l[755],{[l[407]]=G[l[128]][l[407]][l[537]],[l[536]]=G[l[740]][l[772]](l[393],l[59])},A);
          a(l[1359],{[l[299]]=G[l[740]][l[772]](l[393],l[786]),[l[645]]=G[l[740]][l[772]](l[393],l[786]),[l[1612]]=G[l[740]][l[772]](l[393],l[786]),[l[517]]=G[l[740]][l[772]](l[393],l[786])},A);
          d(w:GetPropertyChangedSignal(l[996]),function()
            local F=s[87]();
            A[l[392]]=F[l[1459]][l[588]](l[393],j(w)[l[636]]+l[930]);
          end);
          local w=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1604],[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[659],[l[1324]]=l[1329],[l[711]]=l[1092]},B);
          local F=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1571]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[658]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=G[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[759],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},B);
          D(F,l[1158]);
          a(l[1359],{[l[1612]]=G[l[740]][l[772]](l[393],l[730]),[l[517]]=G[l[740]][l[772]](l[393],l[730])},F);
          local V=a(l[734],{[l[1161]]=G[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1419]},F);
          local fP=a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1331]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},B);
          p,r=l[755],{[l[101]]=G[l[128]][l[101]][l[1505]],[l[407]]=G[l[128]][l[407]][l[537]]};
          r[l[536]]=G[l[740]][l[772]](l[393],l[1158]);
          a(p,r,fP);
          local p=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1307],l[1322]),[l[1639]]=G[l[1459]][l[772]](l[229],l[749],l[393],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[229],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},B);
          local G=l[393];
          local r=l[1329];
          local function aP(GP,NP,DP)
            local SP,BP=s[87](),G;
            G=BP+l[229];
            r=DP and l[383]or l[1329];
            local BP=G;
            p[l[1420]]=GP;
            p[l[510]]=NP or R[l[1379]];
            P(p,n,{[l[916]]=l[874]});
            if DP then
              return;
            end
            SP[l[1022]][l[1330]](l[1586],function()
              local GP=G;
              if GP==BP then
                P(p,H,{[l[916]]=l[229]});
              end
            end);
          end
          local function GP()
            local NP=r;
            if not NP then
              return;
            end
            NP=G;
            G=NP+l[229];
            r=l[1329];
            P(p,H,{[l[916]]=l[229]});
          end
          local G,p,r={};
          local function NP(DP)
            local SP,BP=s[87](),p;
            local wP,FP,hP=BP==DP[l[572]],DP[l[1466]],{};
            hP[l[1646]]=wP and l[1422]or l[629];
            P(FP,H,hP);
            local BP,FP,hP,WP=DP[l[1642]],{},l[1646],wP and l[841]or(DP[l[892]]and l[659]or l[229]);
            FP[hP]=WP;
            P(BP,H,FP);
            WP,BP=DP[l[1473]],{};
            BP[l[747]]=wP and l[1567]or l[229];
            P(WP,H,BP);
            P(DP[l[451]],H,{[l[1639]]=SP[l[1459]][l[772]](l[393],l[863],l[393],wP and l[750]or l[393]),[l[1646]]=wP and l[1296]or l[229]});
            P(DP[l[647]],H,{[l[2]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[936]]=wP and R[l[1095]]or R[l[1379]]});
            P(DP[l[1615]],H,{[l[916]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[510]]=wP and R[l[1095]]or R[l[1379]]});
          end
          local function DP()
            for SP,SP in y[3],G,nil do
              NP(SP);
            end;
          end
          local function SP(BP)
            p=BP;
            F[l[1420]]=BP or l[1746];
            DP();
          end
          local function DP()
            local BP=sP(F[l[1420]])or p;
            if not BP then
              aP(l[455]);
              return;
            end
            local wP=y[18]:store(BP);
            if wP then
              p=BP;
              aP(l[1426]..BP,R[l[1095]]);
              zP();
            else
              aP(l[1702]);
            end
          end
          local function BP()
            local wP=p;
            if not wP then
              aP(l[1138]);
              return;
            end
            wP=(y[18]:store(p));
            if wP then
              F[l[1420]]=p;
              aP(l[479]..p,R[l[1095]]);
              zP();
            else
              aP(l[262]);
            end
          end
          local function wP(FP)
            local hP=sP(FP)or p;
            if not hP then
              aP(l[1138]);
              return;
            end
            if y[18]:fetch(hP) then
              SP(hP);
              aP(l[264]..hP,R[l[1095]]);
            else
              FP=y[18][l[171]];
              aP(FP and FP[l[1290]]and FP[l[1290]][l[229]]or l[418]);
            end
          end
          local function FP()
            local hP=p or sP(F[l[1420]]);
            if not hP then
              aP(l[1138]);
              return;
            end
            local WP=y[18]:erase(hP);
            if WP then
              if y[18]:autoload()==hP then
                y[18]:setautoload(nil);
              end
              p=nil;
              F[l[1420]]=l[1746];
              aP(l[285]..hP,R[l[1095]]);
              zP();
            else
              aP(l[1292]);
            end
          end
          local function hP()
            local WP,VP=sP(F[l[1420]]),p;
            if not VP then
              aP(l[1138]);
              return;
            end
            if not WP then
              aP(l[155]);
              return;
            end
            local VP,_P=p,y[18]:retitle(p,WP);
            if _P and y[18]:autoload()==VP then
              y[18]:setautoload(_P);
            end
            if _P then
              SP(_P);
              aP(l[355].._P,R[l[1095]]);
              zP();
            else
              aP(l[119]);
            end
          end
          local function zP(WP)
            local VP={};
            local _P=s[87]();
            for XP,XP in y[3],G,nil do
              for xP,xP in y[3],XP[l[608]],nil do
                xP:Disconnect();
              end;
              XP[l[1466]]:Destroy();
            end;
            _P[l[1346]][l[267]](G);
            local XP=p and not _P[l[1346]][l[23]](WP,p);
            if XP then
              p=nil;
            end
            w[l[1324]]=#WP==l[393];
            for w,XP in y[3],WP,nil do
              local WP={[l[572]]=XP,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1132]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=w,[l[711]]=l[1158]},A)};
              D(WP[l[1466]],l[1158]);
              WP[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},WP[l[1466]]);
              WP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},WP[l[1466]]);
              D(WP[l[1642]],l[1158]);
              K(WP[l[1642]],l[393],{_P[l[677]][l[772]](l[393],l[393]),_P[l[677]][l[772]](l[509],l[986]),_P[l[677]][l[772]](l[229],l[1017])});
              WP[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=_P[l[1689]][l[772]](l[393],l[659]),[l[948]]=_P[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},WP[l[1466]]);
              local xP,kP=l[1112],{};
              kP[l[1182]]=_P[l[740]][l[772]](l[229],l[393]);
              a(xP,kP,WP[l[451]]);
              VP[1]=l[647];
              VP[3]=a;
              VP[4]=l[859];
              VP[2]={};
              VP[2][l[1150]]=f();
              VP[2][l[1016]]=_P[l[1689]][l[772]](l[393],l[659]);
              VP[2][l[948]]=_P[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
              VP[2][l[1639]]=_P[l[1459]][l[588]](l[310],l[310]);
              VP[2][l[1646]]=l[229];
              VP[2][l[1451]]=y[30](XP==y[18]:autoload()and l[1059]or l[1177]);
              VP[2][l[936]]=R[l[1379]];
              VP[2][l[2]]=l[229];
              VP[2][l[1557]]=_P[l[128]][l[1557]][l[220]];
              VP[2][l[711]]=l[1092];
              VP[5]=(VP[3](VP[4],VP[2],WP[l[1466]]));
              WP[VP[1]]=VP[5];
              WP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=_P[l[1459]][l[588]](l[688],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=_P[l[128]][l[437]][l[1381]],[l[1420]]=XP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[229],[l[164]]=_P[l[128]][l[164]][l[1021]],[l[1634]]=_P[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},WP[l[1466]]);
              WP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},WP[l[1466]]);
              _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1538]]:Connect(function()
                WP[l[892]]=l[383];
                NP(WP);
              end));
              _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1628]]:Connect(function()
                WP[l[892]]=l[1329];
                NP(WP);
              end));
              _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[445]]:Connect(function()
                local VP=s[87]();
                local XP,xP=VP[l[655]][l[1587]](),p;
                VP=xP==WP[l[572]]and XP-(r or l[393])<l[330];
                if VP then
                  r=nil;
                  wP(WP[l[572]]);
                  return;
                end
                r=XP;
                SP(WP[l[572]]);
              end));
              G[w]=WP;
              _P[l[1022]][l[1330]]((w-l[229])*l[182],function()
                if WP[l[1466]][l[382]] then
                  NP(WP);
                end
              end);
            end;
          end
          local function G()
            local r=p;
            if not r then
              aP(l[1138]);
              return;
            end
            r=y[18]:autoload()==p;
            if r then
              y[18]:setautoload(nil);
              aP(l[851],R[l[1095]]);
            else
              local r=y[18]:setautoload(p);
              if r then
                aP(l[830]..p,R[l[1095]]);
              else
                aP(l[1702]);
              end
            end
            zP(y[18]:roster());
          end
          local r=l[393];
          local function w(NP,WP,VP)
            local _P,XP=s[87](),r;
            r=XP+l[229];
            local XP=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[528],l[66],l[229],l[393]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1451]]=l[1746],[l[537]]=r,[l[711]]=l[1158]},fP);
            D(XP,l[1158]);
            local r=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[923]},XP);
            local fP=a;
            local xP=l[859];
            local kP={};
            kP[l[1150]]=f();
            kP[l[1016]]=_P[l[1689]][l[772]](l[659],l[659]);
            kP[l[948]]=_P[l[1459]][l[1368]](l[659],l[659]);
            kP[l[1639]]=_P[l[1459]][l[588]](l[973],l[973]);
            kP[l[1646]]=l[229];
            kP[l[1451]]=y[30](NP);
            kP[l[936]]=R[l[1379]];
            kP[l[2]]=l[986];
            kP[l[1557]]=_P[l[128]][l[1557]][l[220]];
            kP[l[711]]=l[1092];
            local NP=fP(xP,kP,XP);
            d(XP[l[1538]],function()
              P(XP,H,{[l[1646]]=l[393]});
              P(r,H,{[l[747]]=l[323]});
              P(NP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
              aP(WP,R[l[1379]],l[383]);
            end);
            d(XP[l[1628]],function()
              P(XP,H,{[l[1646]]=l[841]});
              P(r,H,{[l[747]]=l[923]});
              P(NP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]]});
              GP();
            end);
            d(XP[l[445]],function()
              NP[l[936]]=R[l[98]];
              P(NP,H,{[l[936]]=R[l[1095]]});
              y[18]:chime(l[1320]);
              VP();
            end);
            return XP;
          end
          w(l[317],l[512],DP);
          w(l[1517],l[680],wP);
          w(l[1169],l[172],BP);
          w(l[1177],l[1222],hP);
          w(l[905],l[704],FP);
          w(l[1059],l[1125],G);
          d(F[l[505]],function()
            P(V,H,{[l[747]]=l[615]});
          end);
          d(F[l[722]],function(G)
            P(V,H,{[l[747]]=l[1419]});
            if G then
              DP();
            end
          end);
          y[18]:watch(zP);
          w={[l[852]--[[readi16]]]=B,[l[1206]]=A,[l[1002]]=function()
            zP(y[18]:roster());
          end};
          local function G(r)
            r=p;
            return r;
          end
          w[l[506]]=G;
          local function G(p,p)
            SP(sP(p));
          end
          w[l[199]]=G;
          return w;
        end
        cP[l[963]]=J;
        local function J(G,p)
          local r={};
          G=s[87]();
          p=X(p,{[l[572]]=l[1503],[l[13]]=l[1736],[l[1132]]=l[356],[l[1477]]=l[1363],[l[1206]]={},[l[950]]=nil,[l[1693]]=l[1329],[l[798]]=l[1191],[l[1410]]=l[1736],[l[294]]=l[151],[l[136]]=l[1158],[l[1141]]=l[1329],[l[634]]=l[1329],[l[4]]=l[383],[l[1105]]=l[383],[l[1009]]=l[1329],[l[424]]=nil,[l[603]]=nil,[l[1669]]=nil,[l[472]]=l[686],[l[1013]]=nil,[l[1617]]=nil});
          local B,A,w=G[l[35]][l[819]](G[l[35]][l[499]](G[l[1382]](p[l[1477]])or l[1363]),l[422],l[218]),p[l[4]]and l[383]or l[1329],G[l[40]](p[l[424]])==l[1346]and p[l[424]]or{};
          local F,V=p[l[1105]]and l[383]or l[1329]or#w>l[393],y[31][G[l[409]][l[345]](G[l[1130]](p[l[798]]))];
          local sP=l[1289]+(A and l[913]or l[393]);
          local zP=sP+B+l[930];
          local fP,aP=zP+(F and l[1282]or l[393]),AP(p[l[1132]]);
          local GP,NP=mP(aP,fP+l[1707]);
          G[l[1346]][l[968]](OP,{[l[590]]=NP,[l[572]]=p[l[572]],[l[12]]={}});
          aP=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},GP);
          D(aP,l[1092]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[393],l[229]),[l[948]]=G[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},aP);
          local DP=a;
          local SP=l[859];
          local BP={};
          BP[l[1150]]=f();
          BP[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
          BP[l[948]]=G[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
          BP[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
          BP[l[1646]]=l[229];
          BP[l[1451]]=y[30](p[l[13]]);
          BP[l[936]]=R[l[1379]];
          BP[l[2]]=l[986];
          BP[l[1557]]=G[l[128]][l[1557]][l[220]];
          BP[l[711]]=l[1092];
          DP(SP,BP,aP);
          a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=G[l[1459]][l[772]](l[229],l[571],l[229],l[393]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},aP);
          local DP=a(l[1070],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[229],l[659]),[l[948]]=G[l[1459]][l[772]](l[229],l[1026],l[659],l[393]),[l[1639]]=G[l[1459]][l[588]](l[1632],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[121],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[1431],[l[1634]]=G[l[128]][l[1634]][l[877]],[l[711]]=l[1092]},aP);
          K(a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[393],l[688]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},GP),l[393],{G[l[677]][l[772]](l[393],l[229]),G[l[677]][l[772]](l[841],l[874]),G[l[677]][l[772]](l[659],l[393]),G[l[677]][l[772]](l[804],l[874]),G[l[677]][l[772]](l[229],l[229])});
          local aP,SP;
          if A then
            aP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[658]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=G[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[4],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},GP);
            D(aP,l[1158]);
            a(l[1359],{[l[1612]]=G[l[740]][l[772]](l[393],l[1249]),[l[517]]=G[l[740]][l[772]](l[393],l[730])},aP);
            SP=a(l[734],{[l[1161]]=G[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1419]},aP);
            local A=a;
            local BP=l[859];
            local wP={};
            wP[l[1150]]=f();
            wP[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
            wP[l[948]]=G[l[1459]][l[772]](l[393],l[1707],l[393],l[29]);
            wP[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
            wP[l[1646]]=l[229];
            wP[l[1451]]=y[30](l[4]);
            wP[l[936]]=R[l[1379]];
            wP[l[2]]=l[1431];
            wP[l[1557]]=G[l[128]][l[1557]][l[220]];
            wP[l[711]]=l[930];
            A(BP,wP,GP);
          else
          end
          local A=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=G[l[1459]][l[588]](l[730],sP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],B),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[392]]=G[l[1459]][l[772]](),[l[656]]=l[383],[l[1226]]=G[l[128]][l[1226]][l[364]],[l[1195]]=l[383],[l[231]]=R[l[98]],[l[761]]=p[l[634]]and l[1431]or l[229],[l[969]]=p[l[634]]and l[863]or l[393],[l[62]]=G[l[128]][l[62]][l[636]],[l[711]]=l[1158]},GP);
          D(A,l[1158]);
          local BP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},A);
          local wP=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],sP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],B),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[472]],[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[659],[l[1324]]=l[1329],[l[711]]=l[1092]},GP);
          local FP,hP;
          if F then
            FP=a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],zP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},GP);
            sP,B=l[755],{[l[101]]=G[l[128]][l[101]][l[1505]],[l[407]]=G[l[128]][l[407]][l[537]]};
            B[l[536]]=G[l[740]][l[772]](l[393],l[1158]);
            a(sP,B,FP);
          else
          end
          hP=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1307],fP),[l[1639]]=G[l[1459]][l[772]](l[229],l[749],l[393],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[229],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},GP);
          local B=l[393];
          local F=l[1329];
          local function sP(zP,fP,WP)
            local VP,_P=s[87](),B;
            B=_P+l[229];
            F=WP and l[383]or l[1329];
            local _P=B;
            hP[l[1420]]=zP;
            hP[l[510]]=fP or R[l[1379]];
            P(hP,n,{[l[916]]=l[874]});
            if WP then
              return;
            end
            VP[l[1022]][l[1330]](l[1586],function()
              local n=B;
              if n==_P then
                P(hP,H,{[l[916]]=l[229]});
              end
            end);
          end
          local function n()
            local zP=F;
            if not zP then
              return;
            end
            zP=B;
            B=zP+l[229];
            F=l[1329];
            P(hP,H,{[l[916]]=l[229]});
          end
          local B;
          local F,zP,fP={},{};
          local hP,WP={},{};
          local VP=l[393];
          local _P,XP=l[393],{};
          local xP=G[l[35]][l[819]](G[l[35]][l[499]](G[l[1382]](p[l[294]])or l[151]),l[520],l[667]);
          local kP=G[l[35]][l[850]](G[l[35]][l[499]](G[l[1382]](p[l[136]])or l[1158]),l[59]);
          local vP=l[303];
          local IP=p[l[1141]]and l[688]or l[558];
          local iP,EP=l[229],xP;
          local QP=xP+IP;
          local tP=xP+IP+l[1158];
          local RP=l[1746];
          local gP=l[383];
          local uP=l[1329];
          local UP,MP,sC,lC,LC,yC,zC=l[393];
          local function TC(nC)
            local JC=s[87]();
            if JC[l[40]](nC)==l[409] then
              if nC==l[1746] then
                return nil;
              end
              return{[l[572]]=nC,[l[1094]]=nC};
            end
            if JC[l[40]](nC)~=l[1346] then
              return nil;
            end
            local HC=nC[l[572]]or nC[l[1150]]or nC[l[1094]]or nC[l[1053]]or nC[l[1463]]or nC[l[1554]];
            if HC==nil then
              return nil;
            end
            HC=JC[l[1130]](HC);
            local fC,aC=JC[l[1382]](nC[l[1463]]or nC[l[1554]]or nC[l[568]]or nC[l[584]]or nC[l[1191]]or nC[l[1199]]or nC[l[1428]]or nC[l[707]]or nC[l[1675]]),nC[l[1736]]or nC[l[1451]]or nC[l[13]]or nC[l[79]]or nC[l[103]]or nC[l[798]]or nC[l[1035]];
            return{[l[572]]=HC,[l[1094]]=JC[l[1130]](nC[l[1062]]or nC[l[1389]]or nC[l[1094]]or nC[l[1053]]or HC),[l[1463]]=fC,[l[103]]=(JC[l[40]](aC)==l[409]or JC[l[40]](aC)==l[384])and aC or nil,[l[83]]=JC[l[1703]](nC[l[83]])==l[1689]and nC[l[83]]or nil,[l[297]]=JC[l[1703]](nC[l[297]])==l[1689]and nC[l[297]]or nil};
          end
          local function nC(JC)
            local HC=s[87]();
            if JC[l[103]] then
              return y[30](JC[l[103]]);
            end
            if V and JC[l[1463]]and JC[l[1463]]>l[393] then
              return HC[l[409]][l[846]](V,JC[l[1463]]);
            end
            return l[1746];
          end
          r[1]=y[18];
          r[2]=l[372];
          r[3]=y[18][l[372]]or{[l[805]]={},[l[1335]]={}};
          r[1][r[2]]=r[3];
          local V,JC=y[18][l[372]],{};
          local HC=l[1329];
          local function fC(aC)
            local dC,PC=s[87](),aC and nC(aC)or l[1746];
            if PC==l[1746]or V[l[805]][PC]or V[l[1335]][PC] then
              return;
            end
            V[l[1335]][PC]=l[383];
            JC[#JC+l[229]]=PC;
            PC=HC;
            if PC then
              return;
            end
            HC=l[383];
            dC[l[1022]][l[281]](function()
              local aC=s[87]();
              local dC=aC[l[1458]]:GetService(l[1358]);
              while y[18][l[630]]and#JC>l[393]do
                local PC={};
                for ZC=l[229],aC[l[35]][l[457]](l[310],#JC),l[229]do
                  PC[#PC+l[229]]=aC[l[1346]][l[1357]](JC,l[229]);
                end;
                local ZC=aC[l[1146]](dC[l[1424]],dC,PC);
                for dC,dC in y[5](PC)do
                  V[l[1335]][dC]=nil;
                  if ZC then
                    V[l[805]][dC]=l[383];
                  end
                end;
                aC[l[1022]][l[153]]();
              end;
              for dC,dC in y[5](JC)do
                V[l[1335]][dC]=nil;
              end;
              aC[l[1346]][l[267]](JC);
              HC=l[1329];
            end);
          end
          local function V(JC)
            if p[l[1693]] then
              return hP[JC]==l[383];
            end
            local HC=fP;
            return HC==JC;
          end
          local function JC()
            local HC=not p[l[1693]];
            if HC then
              local aC=fP and l[229]or l[393];
              return aC;
            end
            HC=l[393];
            for aC in y[3],hP,nil do
              HC+=l[229];
            end;
            return HC;
          end
          local function HC()
            local aC,dC,PC=s[87](),#zP,#F;
            if dC==PC then
              DP[l[1420]]=p[l[1693]]and JC()..l[532]..PC or aC[l[1130]](PC);
            else
              DP[l[1420]]=dC..l[532]..PC;
            end
          end
          local function DP()
            local JC=not p[l[1693]];
            if JC then
              local aC=fP;
              return aC;
            end
            JC={};
            for aC=l[229],#F,l[229]do
              local dC=F[aC][l[572]];
              if hP[dC] then
                JC[#JC+l[229]]=dC;
              end
            end;
            return JC;
          end
          local function JC()
            if p[l[1617]]and not y[18][l[1334]] then
              I(p[l[1617]],DP());
            end
          end
          local function aC(dC,PC)
            if not dC[l[1466]][l[1324]]and not PC then
              return;
            end
            local ZC=dC[l[572]]~=nil and V(dC[l[572]]);
            local V,GC=dC[l[892]]and not ZC,ZC and l[1422]or l[1250];
            local YC,eC,jC,CC,NC,qC=ZC and l[1209]or(V and l[323]or l[229]),ZC and l[615]or(V and l[1419]or l[229]),ZC and R[l[98]]or R[l[966]],ZC and l[393]or(V and l[841]or l[330]),ZC and R[l[1095]]or R[l[1379]],ZC and l[393]or(V and l[629]or l[120]);
            dC[l[1040]][l[1324]]=ZC;
            if PC then
              dC[l[1466]][l[1646]]=GC;
              dC[l[1642]][l[1646]]=YC;
              dC[l[1473]][l[747]]=eC;
              dC[l[1473]][l[1630]]=jC;
              dC[l[1615]][l[916]]=CC;
              dC[l[1615]][l[510]]=NC;
              dC[l[748]][l[2]]=qC;
              return;
            end
            P(dC[l[1466]],H,{[l[1646]]=GC});
            P(dC[l[1642]],H,{[l[1646]]=YC});
            P(dC[l[1473]],H,{[l[747]]=eC,[l[1630]]=jC});
            P(dC[l[1615]],H,{[l[916]]=CC,[l[510]]=NC});
            P(dC[l[748]],H,{[l[2]]=qC});
          end
          local function V(dC)
            if not dC[l[572]] then
              return;
            end
            y[18]:chime(l[1320]);
            local PC=p[l[1693]];
            if PC then
              if hP[dC[l[572]]] then
                hP[dC[l[572]]]=nil;
              else
                hP[dC[l[572]]]=l[383];
              end
            else
              local ZC=fP;
              fP=if ZC==dC[l[572]]then nil else dC[l[572]];
            end
            PC,dC=l[229],VP;
            for ZC=PC,dC,l[229]do
              aC(WP[ZC]);
            end;
            HC();
            JC();
          end
          local function dC()
            local PC=s[87]();
            local ZC={[l[892]]=l[1329],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[588]](EP,QP),[l[1535]]=R[l[1132]],[l[1646]]=l[1250],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1158]},A)};
            D(ZC[l[1466]],l[1158]);
            ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
            ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},ZC[l[1466]]);
            D(ZC[l[1642]],l[1158]);
            K(ZC[l[1642]],l[117],{PC[l[677]][l[772]](l[393],l[1209]),PC[l[677]][l[772]](l[509],l[1431]),PC[l[677]][l[772]](l[229],l[1419])});
            local GC,YC,eC,jC,CC,NC=l[748],l[859],{[l[1150]]=f(),[l[948]]=PC[l[1459]][l[588]](l[786],l[786])},l[1639],PC[l[1459]][l[588]],EP;
            local qC,bC=NC-l[930],EP;
            eC[jC]=CC(qC,bC-l[930]);
            eC[l[1535]]=R[l[641]];
            eC[l[1646]]=l[323];
            eC[l[1418]]=l[393];
            eC[l[1451]]=l[1746];
            eC[l[936]]=PC[l[360]][l[772]](l[229],l[229],l[229]);
            eC[l[2]]=l[120];
            eC[l[1557]]=PC[l[128]][l[1557]][l[220]];
            eC[l[711]]=l[1092];
            ZC[GC]=a(YC,eC,ZC[l[1466]]);
            D(ZC[l[748]],l[303]);
            ZC[l[1040]]=a(l[211],{[l[1150]]=f(),[l[1016]]=PC[l[1689]][l[772]](l[229],l[393]),[l[948]]=PC[l[1459]][l[772]](l[229],l[348],l[393],l[1158]),[l[1639]]=PC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[930]},ZC[l[1466]]);
            YC,CC=l[1112],{};
            CC[l[1182]]=PC[l[740]][l[772]](l[229],l[393]);
            a(YC,CC,ZC[l[1040]]);
            local bC=a;
            local DC=l[859];
            local pC={};
            pC[l[1150]]=f();
            pC[l[1016]]=PC[l[1689]][l[772]](l[659],l[659]);
            pC[l[948]]=PC[l[1459]][l[1368]](l[659],l[659]);
            pC[l[1639]]=PC[l[1459]][l[588]](l[551],l[551]);
            pC[l[1646]]=l[229];
            pC[l[1451]]=y[30](l[1411]);
            pC[l[936]]=R[l[641]];
            pC[l[1557]]=PC[l[128]][l[1557]][l[220]];
            pC[l[711]]=l[551];
            bC(DC,pC,ZC[l[1040]]);
            GC,qC,CC,jC,eC,NC,YC=l[1615],l[1070],{[l[1150]]=f()},l[948],PC[l[1459]][l[588]],l[786],EP;
            CC[jC]=eC(NC,YC-l[863]);
            CC[l[1639]]=PC[l[1459]][l[772]](l[229],l[1519],l[393],IP);
            CC[l[1646]]=l[229];
            CC[l[437]]=PC[l[128]][l[437]][l[1381]];
            CC[l[1420]]=l[1746];
            CC[l[510]]=R[l[1379]];
            CC[l[723]]=l[1307];
            CC[l[916]]=l[330];
            CC[l[164]]=p[l[1141]]and PC[l[128]][l[164]][l[31]]or PC[l[128]][l[164]][l[1021]];
            CC[l[789]]=p[l[1141]];
            CC[l[65]]=p[l[1141]]and PC[l[128]][l[65]][l[1728]]or PC[l[128]][l[65]][l[46]];
            CC[l[711]]=l[1092];
            ZC[GC]=a(qC,CC,ZC[l[1466]]);
            ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},ZC[l[1466]]);
            d(ZC[l[974]][l[1538]],function()
              ZC[l[892]]=l[383];
              aC(ZC);
              if ZC[l[572]] then
                sP(ZC[l[1094]]or ZC[l[572]],R[l[1379]],l[383]);
              end
            end);
            d(ZC[l[974]][l[1628]],function()
              ZC[l[892]]=l[1329];
              aC(ZC);
              n();
            end);
            d(ZC[l[974]][l[445]],function()
              if ZC[l[1142]] then
                ZC[l[1142]]=nil;
                return;
              end
              V(ZC);
            end);
            if PC[l[40]](p[l[1669]])==l[1712] then
              local function V()
                local IP=s[87]();
                if not ZC[l[572]] then
                  return;
                end
                y[18]:chime(l[1320]);
                local GC=ZC[l[1466]][l[81]];
                IP[l[1022]][l[281]](p[l[1669]],ZC[l[572]],B,GC[l[1437]]+ZC[l[1466]][l[160]][l[1437]]*l[659],GC[l[636]]+l[310],ZC[l[1466]]);
              end
              d(ZC[l[974]][l[861]],V);
              d(ZC[l[974]][l[1558]],function(IP)
                local GC=s[87]();
                if IP[l[1317]]~=GC[l[128]][l[1317]][l[239]] then
                  return;
                end
                local IP=GC[l[655]][l[1587]]();
                ZC[l[259]]=IP;
                GC[l[1022]][l[1330]](l[615],function()
                  if ZC[l[259]]==IP then
                    ZC[l[259]]=nil;
                    ZC[l[1142]]=l[383];
                    V();
                  end
                end);
              end);
              d(ZC[l[974]][l[233]],function(V)
                local IP=s[87]();
                if V[l[1317]]==IP[l[128]][l[1317]][l[239]] then
                  ZC[l[259]]=nil;
                end
              end);
              d(ZC[l[974]][l[412]],function(V)
                local IP=s[87]();
                if V[l[1317]]==IP[l[128]][l[1317]][l[239]] then
                  ZC[l[259]]=nil;
                end
              end);
            end
            if PC[l[40]](p[l[603]])==l[1346] then
              ZC[l[247]]=a(l[1742],{[l[1150]]=f(),[l[1016]]=PC[l[1689]][l[772]](l[229],l[393]),[l[948]]=PC[l[1459]][l[772]](l[229],l[66],l[393],l[303]),[l[1639]]=PC[l[1459]][l[588]](l[1241],l[1241]),[l[1535]]=R[l[641]],[l[1646]]=l[874],[l[1418]]=l[393],[l[43]]=l[383],[l[1451]]=l[1746],[l[711]]=l[730]},ZC[l[1466]]);
              D(ZC[l[247]],l[303]);
              a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},ZC[l[247]]);
              local V=a;
              local IP=l[859];
              local GC={};
              GC[l[1150]]=f();
              GC[l[1016]]=PC[l[1689]][l[772]](l[659],l[659]);
              GC[l[948]]=PC[l[1459]][l[1368]](l[659],l[659]);
              GC[l[1639]]=PC[l[1459]][l[588]](l[310],l[310]);
              GC[l[1646]]=l[229];
              GC[l[1451]]=y[30](p[l[603]][l[13]]or l[1716]);
              GC[l[936]]=R[l[1095]];
              GC[l[2]]=l[263];
              GC[l[1557]]=PC[l[128]][l[1557]][l[220]];
              GC[l[711]]=l[1307];
              local PC=V(IP,GC,ZC[l[247]]);
              d(ZC[l[247]][l[1538]],function()
                local V,IP=ZC[l[247]],{};
                IP[l[1646]]=l[393];
                P(V,H,IP);
                P(PC,H,{[l[2]]=l[393],[l[936]]=R[l[98]]});
              end);
              d(ZC[l[247]][l[1628]],function()
                local V,IP=ZC[l[247]],{};
                IP[l[1646]]=l[874];
                P(V,H,IP);
                P(PC,H,{[l[2]]=l[263],[l[936]]=R[l[1095]]});
              end);
              d(ZC[l[247]][l[445]],function()
                local V=s[87]();
                if not ZC[l[572]] then
                  return;
                end
                y[18]:chime(l[1320]);
                local IP=p[l[603]][l[1617]];
                if V[l[40]](IP)==l[1712] then
                  local PC=ZC[l[1466]][l[81]];
                  V[l[1022]][l[281]](IP,ZC[l[572]],B,PC[l[1437]]+l[1243],PC[l[636]]+l[1707],ZC[l[1466]]);
                end
              end);
            end
            return ZC;
          end
          local function V(IP)
            local PC=s[87]();
            IP[l[1466]][l[1639]]=PC[l[1459]][l[588]](EP,QP);
            local ZC,GC,YC,eC=IP[l[748]],l[1639],PC[l[1459]][l[588]],EP;
            local jC,CC=eC-l[930],EP;
            ZC[GC]=YC(jC,CC-l[930]);
            GC,eC,ZC,YC,jC=IP[l[1615]],l[948],PC[l[1459]][l[588]],l[786],EP;
            GC[eC]=ZC(YC,jC-l[863]);
          end
          local function IP()
            local PC,ZC=s[87](),e(A)[l[1437]]-vP*l[59];
            if ZC<l[1707] then
              return l[1329];
            end
            local GC=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC+kP)/(xP+kP)),l[229]);
            local xP=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC-kP*(GC-l[229]))/GC),l[1249]);
            ZC=GC==iP and xP==EP;
            if ZC then
              return l[1329];
            end
            iP,EP=GC,xP;
            xP=EP;
            QP=xP+l[558];
            tP=QP+kP;
            for xP=l[229],#WP,l[229]do
              V(WP[xP]);
            end;
            return l[383];
          end
          local function V()
            local xP={};
            local QP,PC=s[87](),#zP;
            local ZC=QP[l[1459]][l[588]](l[393],QP[l[35]][l[850]](QP[l[35]][l[139]](PC/iP)*tP-kP+vP*l[59],l[393]));
            if A[l[392]]~=ZC then
              A[l[392]]=ZC;
            end
            local GC,YC,eC=A[l[1690]][l[636]],e(A)[l[636]],y[18][l[388]]and l[863]or l[59];
            ZC=QP[l[35]][l[850]](QP[l[35]][l[499]]((GC-vP)/tP)-eC,l[393]);
            local jC,CC=QP[l[35]][l[850]](QP[l[35]][l[139]]((GC+YC-vP)/tP)+eC,ZC+l[229]),ZC*iP+l[229];
            GC,ZC=QP[l[35]][l[457]](jC*iP,PC),iP;
            jC=ZC*(QP[l[35]][l[139]](YC/tP)+l[59]+eC*l[59]+l[229]);
            eC=MP==CC and sC==GC and lC==jC and LC==EP and yC==iP and zC==UP;
            if eC then
              return;
            end
            MP,sC,lC,LC,yC,zC=CC,GC,jC,EP,iP,UP;
            YC=jC~=_P;
            if YC then
              _P=jC;
              for _P=l[229],#WP,l[229]do
                WP[_P][l[572]]=nil;
                WP[_P][l[1466]][l[1324]]=l[1329];
              end;
            end
            QP[l[1346]][l[267]](XP);
            ZC=l[229];
            for _P=CC,GC,ZC do
              eC=zP[_P];
              if eC then
                fC(eC);
                YC=(_P-l[229])%jC+l[229];
                local MP=WP[YC];
                if not MP then
                  MP=dC();
                  WP[YC]=MP;
                else
                end
                XP[YC]=l[383];
                local sC,lC,LC=MP[l[572]]~=eC[l[572]]or MP[l[463]]~=eC,QP[l[35]][l[499]]((_P-l[229])/iP),(_P-l[229])%iP;
                MP[l[572]]=eC[l[572]];
                MP[l[463]]=eC;
                MP[l[1094]]=eC[l[1094]];
                MP[l[1466]][l[948]]=QP[l[1459]][l[588]](vP+LC*(EP+kP),vP+lC*tP);
                if sC then
                  MP[l[1615]][l[1420]]=eC[l[1094]];
                  MP[l[748]][l[1451]]=nC(eC);
                  MP[l[748]][l[589]]=eC[l[83]]or QP[l[1689]][l[1729]];
                  MP[l[748]][l[315]]=eC[l[297]]or QP[l[1689]][l[1729]];
                  if MP[l[748]][l[1451]]==l[1746] then
                    xP[1]=MP[l[748]];
                    xP[2]=l[1451];
                    xP[3]=(y[30](p[l[1410]]));
                    xP[1][xP[2]]=xP[3];
                    MP[l[748]][l[936]]=R[l[1379]];
                  else
                    MP[l[748]][l[936]]=QP[l[360]][l[772]](l[229],l[229],l[229]);
                  end
                end
                if not MP[l[1466]][l[1324]] then
                  MP[l[1466]][l[1324]]=l[383];
                end
                aC(MP,l[383]);
              end
            end;
            for _P=GC+l[229],QP[l[35]][l[457]](GC+jC,PC),l[229]do
              fC(zP[_P]);
            end;
            for _P=l[229],#WP,l[229]do
              if not XP[_P] then
                CC=WP[_P];
                CC[l[572]]=nil;
                CC[l[1466]][l[1324]]=l[1329];
              end
            end;
            VP=#WP;
          end
          local function _P()
            local XP,xP=s[87](),uP;
            if xP then
              return;
            end
            uP=l[383];
            XP[l[1022]][l[1061]](function()
              uP=l[1329];
              local XP=not LP[l[1600]]or not KP[l[1324]]or not NP[l[1273]];
              if XP then
                gP=l[383];
                return;
              end
              gP=l[1329];
              IP();
              V();
            end);
          end
          local function V()
            local XP,xP=s[87](),UP;
            UP=xP+l[229];
            XP[l[1346]][l[267]](zP);
            xP=RP;
            local vP=xP==l[1746];
            if vP then
              for vP=l[229],#F,l[229]do
                zP[vP]=F[vP];
              end;
            else
              local vP,IP,EP=l[229],#F,l[229];
              for QP=vP,IP,EP do
                xP=F[QP];
                QP=XP[l[409]][l[23]](XP[l[409]][l[345]](xP[l[1094]]),RP,l[229],l[383])or XP[l[409]][l[23]](XP[l[409]][l[345]](xP[l[572]]),RP,l[229],l[383]);
                if QP then
                  zP[#zP+l[229]]=xP;
                end
              end;
            end
            wP[l[1324]]=#zP==l[393];
            A[l[1690]]=XP[l[1689]][l[772]](l[393],XP[l[35]][l[457]](A[l[1690]][l[636]],XP[l[35]][l[850]](XP[l[35]][l[139]](#zP/XP[l[35]][l[850]](iP,l[229]))*tP-e(A)[l[636]],l[393])));
            HC();
            _P();
          end
          local function wP(XP)
            local xP=s[87]();
            xP[l[1346]][l[267]](F);
            local vP={};
            if xP[l[40]](XP)==l[1346] then
              for IP,iP in y[3],XP,nil do
                IP=TC(iP);
                if IP and not vP[IP[l[572]]] then
                  vP[IP[l[572]]]=l[383];
                  F[#F+l[229]]=IP;
                end
              end;
            end
            XP=p[l[1693]];
            if XP then
              for XP in y[3],hP,nil do
                if not vP[XP] then
                  hP[XP]=nil;
                end
              end;
            else
              xP=fP and not vP[fP];
              if xP then
                fP=nil;
              end
            end
            V();
          end
          d(A:GetPropertyChangedSignal(l[1690]),_P);
          d(A:GetPropertyChangedSignal(l[160]),_P);
          d(A[l[1538]],function()
            P(BP,H,{[l[747]]=l[659]});
          end);
          d(A[l[1628]],function()
            P(BP,H,{[l[747]]=l[52]});
          end);
          if aP then
            d(aP[l[505]],function()
              P(SP,H,{[l[747]]=l[615]});
            end);
            d(aP[l[722]],function()
              P(SP,H,{[l[747]]=l[1419]});
            end);
            d(aP:GetPropertyChangedSignal(l[1420]),function()
              local SP=s[87]();
              local BP,XP=SP[l[409]][l[345]](SP[l[409]][l[56]](aP[l[1420]],l[381])or l[1746]),RP;
              if BP==XP then
                return;
              end
              RP=BP;
              V();
            end);
          end
          B={[l[852]--[[readi16]]]=GP,[l[1206]]=A,[l[1722]]=F};
          local function A(GP)
            return DP();
          end
          B[l[506]]=A;
          local function A(GP,SP,BP)
            local XP,xP=s[87](),p[l[1693]];
            if xP then
              XP[l[1346]][l[267]](hP);
              if XP[l[40]](SP)==l[1346] then
                for vP,IP in y[3],SP,nil do
                  if IP==l[383]and XP[l[40]](vP)==l[409] then
                    hP[vP]=l[383];
                  elseif XP[l[40]](IP)==l[409]and IP~=l[1746] then
                    hP[IP]=l[383];
                  end
                end;
              elseif XP[l[40]](SP)==l[409]and SP~=l[1746] then
                for vP in XP[l[409]][l[78]](SP,l[397])do
                  GP=XP[l[409]][l[56]](vP,l[381]);
                  if GP~=l[1746] then
                    hP[GP]=l[383];
                  end
                end;
              end
            else
              SP=if XP[l[40]](SP)==l[1346]then SP[l[572]]or SP[l[1150]]else SP;
              fP=XP[l[40]](SP)==l[409]and SP~=l[1746]and SP or nil;
            end
            xP,SP=l[229],VP;
            for GP=xP,SP,l[229]do
              aC(WP[GP]);
            end;
            HC();
            if not BP then
              JC();
            end
          end
          B[l[1255]]=A;
          local function A(GP,GP)
            wP(GP);
          end
          B[l[699]]=A;
          local function A(GP,GP)
            B:set(GP,l[383]);
          end
          B[l[529]]=A;
          local function GP(SP)
            SP=s[87]();
            SP[l[1346]][l[267]](hP);
            fP=nil;
            local SP,BP=l[229],VP;
            for XP=SP,BP,l[229]do
              aC(WP[XP]);
            end;
            HC();
            JC();
          end
          B[l[267]]=GP;
          local function GP(SP)
            if not p[l[1693]] then
              return;
            end
            for SP=l[229],#zP,l[229]do
              hP[zP[SP][l[572]]]=l[383];
            end;
            local zP,SP=l[229],VP;
            for BP=zP,SP,l[229]do
              aC(WP[BP]);
            end;
            HC();
            JC();
          end
          B[l[868]]=GP;
          local function zP(SP)
            V();
          end
          B[l[1002]]=zP;
          local function SP(BP)
            BP={};
            for hP=l[229],#F,l[229]do
              BP[hP]=F[hP][l[572]];
            end;
            return BP;
          end
          B[l[690]]=SP;
          local function SP(BP,hP)
            BP=s[87]();
            if aP then
              aP[l[1420]]=BP[l[1130]](hP or l[1746]);
            end
          end
          B[l[4]]=SP;
          if FP then
            GP,A=l[393],{};
            if p[l[1693]] then
              A[#A+l[229]]={[l[13]]=l[1411],[l[1658]]=l[1514],[l[1617]]=function()
                B:all();
              end};
              A[#A+l[229]]={[l[13]]=l[898],[l[1658]]=l[1664],[l[1617]]=function()
                B:clear();
              end};
            elseif p[l[1105]] then
              A[#A+l[229]]={[l[13]]=l[898],[l[1658]]=l[1664],[l[1617]]=function()
                B:clear();
              end};
            end
            if p[l[1105]] then
              A[#A+l[229]]={[l[13]]=l[1169],[l[1658]]=l[1117],[l[1617]]=function()
                V();
              end};
            end
            for V,V in y[3],w,nil do
              if G[l[40]](V)==l[1346] then
                A[#A+l[229]]=V;
              end
            end;
            zP=G[l[35]][l[850]](#A,l[229]);
            for w,w in y[3],A,nil do
              GP+=l[229];
              local A=a(l[1742],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229]/zP,-(kP*(zP-l[229]))/zP,l[229],l[393]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1451]]=l[1746],[l[537]]=GP,[l[711]]=l[1158]},FP);
              D(A,l[1158]);
              local V=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[923]},A);
              r[5]=a;
              r[6]=l[859];
              r[4]={};
              r[4][l[1150]]=f();
              r[4][l[1016]]=G[l[1689]][l[772]](l[659],l[659]);
              r[4][l[948]]=G[l[1459]][l[1368]](l[659],l[659]);
              r[4][l[1639]]=G[l[1459]][l[588]](l[973],l[973]);
              r[4][l[1646]]=l[229];
              r[4][l[1451]]=y[30](w[l[13]]or w[l[79]]or l[234]);
              r[4][l[936]]=R[l[1379]];
              r[4][l[2]]=l[986];
              r[4][l[1557]]=G[l[128]][l[1557]][l[220]];
              r[4][l[711]]=l[1092];
              local zP=r[5](r[6],r[4],A);
              local r=w[l[1658]]or w[l[1033]]or w[l[572]]or w[l[1150]];
              d(A[l[1538]],function()
                P(A,H,{[l[1646]]=l[393]});
                P(V,H,{[l[747]]=l[323]});
                P(zP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
                if r then
                  sP(r,R[l[1379]],l[383]);
                end
              end);
              d(A[l[1628]],function()
                P(A,H,{[l[1646]]=l[841]});
                P(V,H,{[l[747]]=l[923]});
                P(zP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]]});
                n();
              end);
              d(A[l[445]],function()
                local n=s[87]();
                zP[l[936]]=R[l[98]];
                P(zP,H,{[l[936]]=R[l[1095]]});
                y[18]:chime(l[1320]);
                local r=w[l[1617]]or w[l[1683]];
                if n[l[40]](r)==l[1712] then
                  n[l[1022]][l[281]](r,B);
                end
              end);
            end;
          end
          local function n()
            local r=LP[l[1600]]and KP[l[1324]]and NP[l[1273]]and gP;
            if r then
              _P();
            end
          end
          d(NP[l[1594]--[[__index]]]:GetPropertyChangedSignal(l[1324]),n);
          d(KP:GetPropertyChangedSignal(l[1324]),n);
          d(dP:GetPropertyChangedSignal(l[1324]),n);
          wP(p[l[1206]]);
          if p[l[950]]~=nil then
            B:set(p[l[950]],l[383]);
          end
          y[18]:hook(p[l[1013]]or oP..l[1074]..p[l[572]],p[l[1693]]and l[1206]or l[409],function()
            local n=s[87]();
            if p[l[1693]] then
              return n[l[1346]][l[978]](DP(),l[1200]);
            end
            local n=fP or l[1746];
            return n;
          end,function(n)
            B:set(n,l[383]);
            if p[l[1617]] then
              I(p[l[1617]],DP());
            end
          end,{[l[284]]=function(n)
            local r=s[87]();
            local function A(w)
              for V,V in y[5](F)do
                if V[l[572]]==w then
                  return l[383];
                end
              end;
              return l[1329];
            end
            if not p[l[1693]] then
              return n==l[1746]or A(n);
            end
            for p in r[l[409]][l[78]](n,l[397])do
              if not A(r[l[409]][l[56]](p,l[381])) then
                return l[1329];
              end
            end;
            return l[383];
          end});
          G[l[1022]][l[1061]](_P);
          return B;
        end
        cP[l[484]]=J;
        local function n(J,G)
          J=s[87]();
          G=X(G,{[l[572]]=l[1403],[l[13]]=l[453],[l[1132]]=l[356],[l[1477]]=l[1331],[l[273]]=l[1157],[l[1230]]=l[229],[l[1025]]=l[352],[l[687]]=l[348],[l[932]]=l[1655],[l[1330]]=l[323],[l[892]]=l[876],[l[150]]=l[659],[l[147]]=l[383],[l[1009]]=l[383],[l[1617]]=nil});
          local p,r=J[l[35]][l[819]](J[l[35]][l[499]](J[l[1382]](G[l[1477]])or l[1331]),l[117],l[218]),AP(G[l[1132]]);
          local B,A=mP(r,p+l[1506]);
          J[l[1346]][l[968]](OP,{[l[590]]=A,[l[572]]=G[l[572]],[l[12]]={}});
          local w=a(l[211],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},B);
          D(w,l[1092]);
          a(l[211],{[l[1150]]=f(),[l[1016]]=J[l[1689]][l[772]](l[393],l[229]),[l[948]]=J[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},w);
          local F=a;
          local V=l[859];
          local sP={};
          sP[l[1150]]=f();
          sP[l[1016]]=J[l[1689]][l[772]](l[393],l[659]);
          sP[l[948]]=J[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
          sP[l[1639]]=J[l[1459]][l[588]](l[750],l[750]);
          sP[l[1646]]=l[229];
          sP[l[1451]]=y[30](G[l[13]]);
          sP[l[936]]=R[l[1379]];
          sP[l[2]]=l[986];
          sP[l[1557]]=J[l[128]][l[1557]][l[220]];
          sP[l[711]]=l[1092];
          F(V,sP,w);
          a(l[1070],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=J[l[1459]][l[772]](l[229],l[865],l[229],l[393]),[l[1646]]=l[229],[l[437]]=J[l[128]][l[437]][l[1381]],[l[1420]]=G[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=J[l[128]][l[164]][l[1021]],[l[1634]]=J[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},w);
          K(a(l[211],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[393],l[688]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},B),l[393],{J[l[677]][l[772]](l[393],l[229]),J[l[677]][l[772]](l[841],l[874]),J[l[677]][l[772]](l[659],l[393]),J[l[677]][l[772]](l[804],l[874]),J[l[677]][l[772]](l[229],l[229])});
          local F=a(l[211],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=J[l[1459]][l[772]](l[229],l[1274],l[393],p),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},B);
          D(F,l[1158]);
          local V=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},F);
          p=a(l[211],{[l[1150]]=f(),[l[1016]]=J[l[1689]][l[772]](l[393],l[229]),[l[948]]=J[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[1419],l[393]),[l[1535]]=R[l[1529]--[[cancel]]],[l[1646]]=l[804],[l[1418]]=l[393],[l[711]]=l[1158]},F);
          D(p,l[1158]);
          K(p,l[117],{J[l[677]][l[772]](l[393],l[229]),J[l[677]][l[772]](l[229],l[1431])});
          local p=a(l[757],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[854]]=J[l[360]][l[353]](l[1564],l[1564],l[1592]),[l[400]]=J[l[360]][l[353]](l[1682],l[1682],l[1682]),[l[879]]=J[l[135]][l[772]](l[1537]--[[Vector3]],l[715],l[758]),[l[711]]=l[1092]},F);
          D(p,l[1158]);
          local sP=p;
          if k(l[751]) then
            sP=a(l[751],{[l[1150]]=f()},p);
          else
          end
          local zP=a(l[1245],{[l[1150]]=f(),[l[1309]]=J[l[35]][l[819]](J[l[1382]](G[l[273]])or l[1157],l[730],l[856])},p);
          p[l[227]]=zP;
          local fP,aP=a(l[211],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[656]]=l[383],[l[711]]=l[930]},F),a(l[1742],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},F);
          local GP,NP={[l[852]--[[readi16]]]=B,[l[732]]=F,[l[1616]]=p,[l[541]]=sP,[l[179]]=zP,[l[410]]=fP,[l[1160]]=nil,[l[593]]=nil,[l[934]]={},[l[897]]=l[1329],[l[1025]]=J[l[1382]](G[l[1025]])or l[393],[l[687]]=J[l[35]][l[819]](J[l[1382]](G[l[687]])or l[393],l[1606],l[1367]),[l[1230]]=J[l[35]][l[819]](J[l[1382]](G[l[1230]])or l[229],l[615],l[786])},{};
          local B=J[l[135]][l[772]](l[786],l[1653],l[786]);
          local F=J[l[135]][l[772]](l[393],l[799],l[393]);
          local fP=J[l[135]][l[772]](l[393],l[799],l[393]);
          local DP=l[310];
          local oP=l[1329];
          local mP=l[1329];
          local SP,OP=l[393];
          local BP=l[393];
          local AP=l[393];
          local wP=l[1329];
          local FP=l[393];
          local function hP()
            local WP=s[87]();
            local VP,_P=WP[l[35]][l[899]](WP[l[35]][l[924]](zP[l[1309]]*l[659])),p[l[160]];
            local XP,xP,kP=_P[l[636]]>l[229]and _P[l[1437]]/_P[l[636]]or l[229],WP[l[35]][l[1575]],F;
            local vP,IP=kP[l[636]],fP;
            _P,kP=xP(vP-IP[l[636]]),B;
            vP,IP,xP=kP[l[636]]*l[659]+_P,WP[l[35]][l[18]],B;
            _P,kP=xP[l[1437]],B;
            local iP,EP=_P*kP[l[1437]],B;
            kP,_P=EP[l[989]],B;
            xP=IP(iP+kP*_P[l[989]])*l[659];
            DP=WP[l[35]][l[850]](vP/VP,xP/(VP*WP[l[35]][l[850]](XP,l[1296])))*l[618];
          end
          local function WP()
            local VP,_P=s[87](),l[1480];
            local XP,xP,kP,vP,IP=VP[l[1480]][l[772]](fP)*VP[l[1480]][l[369]](VP[l[35]][l[924]](GP[l[687]]),VP[l[35]][l[924]](GP[l[1025]]),l[393]),VP[l[1480]][l[772]],l[393],l[393],DP;
            zP[_P]=XP*xP(kP,vP,IP*GP[l[1230]]);
          end
          local function DP()
            local VP=p[l[382]];
            if not VP then
              return;
            end
            p[l[382]]=nil;
            p[l[382]]=VP;
          end
          local function VP()
            return p[l[81]]+h(),p[l[160]];
          end
          local function _P(XP)
            local xP,kP,vP=s[87](),VP();
            if vP[l[1437]]<l[229]or vP[l[636]]<l[229] then
              return l[393],l[393],l[1329];
            end
            local IP=zP[l[1480]]:PointToObjectSpace(XP);
            if IP[l[989]]>l[886]--[[readf32]] then
              return l[393],l[393],l[1329];
            end
            local iP,EP=xP[l[35]][l[899]](xP[l[35]][l[924]](zP[l[1309]]*l[659])),-IP[l[989]];
            XP,xP=IP[l[1437]]/(EP*iP*(vP[l[1437]]/vP[l[636]])),IP[l[636]]/(EP*iP);
            return kP[l[1437]]+vP[l[1437]]*(l[659]+XP*l[659]),kP[l[636]]+vP[l[636]]*(l[659]-xP*l[659]),l[383];
          end
          local function XP(xP)
            local kP=s[87]();
            for vP=#NP,l[229],l[715]do
              local IP=NP[vP];
              if kP[l[40]](IP)~=l[1712] then
                kP[l[1346]][l[1357]](NP,vP);
              elseif not kP[l[1146]](IP,GP,xP) then
                kP[l[1346]][l[1357]](NP,vP);
              end
            end;
          end
          local function xP()
            local kP,vP=s[87](),OP;
            if vP then
              OP:Disconnect();
              OP=nil;
            end
            if GP[l[1160]] then
              GP[l[1160]]:Destroy();
              GP[l[1160]]=nil;
            end
            kP[l[1346]][l[267]](GP[l[934]]);
            GP[l[593]]=nil;
            oP=l[1329];
          end
          local function kP(vP,IP,iP)
            local EP,QP=vP:GetChildren(),IP:GetChildren();
            for vP=l[229],#EP,l[229]do
              local tP,RP=EP[vP],QP[vP];
              RP=if not RP or RP[l[1150]]~=tP[l[1150]]or RP[l[657]]~=tP[l[657]]then IP:FindFirstChild(tP[l[1150]])else RP;
              if RP then
                if tP:IsA(l[1635])and RP:IsA(l[1635]) then
                  iP[#iP+l[229]]={tP,RP};
                end
                kP(tP,RP,iP);
              end
            end;
          end
          local function vP(IP)
            local iP,EP,QP=s[87](),IP:GetDescendants();
            for tP,RP in y[3],EP,QP do
              tP=l[1635];
              if RP:IsA(tP) then
                RP[l[82]]=l[383];
                RP[l[1127]]=l[1329];
                RP[l[1219]]=l[383];
                RP[l[1312]]=l[1329];
                RP[l[1391]]=l[393];
              else
                IP=l[1266];
                if RP:IsA(IP) then
                  local IP=RP:FindFirstChildOfClass(l[401]);
                  if IP then
                    IP:Destroy();
                  end
                  iP[l[1146]](function()
                    local IP=s[87]();
                    RP[l[702]]=IP[l[128]][l[1034]][l[31]];
                    RP[l[873]]=IP[l[128]][l[1227]][l[1005]];
                    RP[l[287]]=l[393];
                    RP[l[736]]=l[393];
                    RP[l[1233]]=l[1329];
                    RP[l[47]]=l[1329];
                    RP[l[1008]]=l[1329];
                    RP[l[1374]]=l[1329];
                    RP[l[540]]=RP[l[1698]];
                  end);
                elseif RP:IsA(l[778])or RP:IsA(l[1058])or RP:IsA(l[1260])or RP:IsA(l[1245])or RP:IsA(l[1661])or RP:IsA(l[1000]) then
                  RP:Destroy();
                end
              end
            end;
          end
          local function IP()
            local iP,EP=s[87](),not wP;
            if EP then
              wP=l[383];
              FP=iP[l[655]][l[1587]]();
            end
            SP=iP[l[655]][l[1587]]()+l[615];
          end
          local function iP()
            local EP,QP=s[87](),y[13][l[569]--[[traceback]]];
            if not QP or not QP[l[382]] then
              return;
            end
            local tP=QP[l[1281]]or QP:FindFirstChild(l[1405])or QP:FindFirstChild(l[780])or QP:FindFirstChild(l[1553])or QP:FindFirstChildWhichIsA(l[1635]);
            if not tP then
              return;
            end
            local RP,gP={},QP[l[1031]];
            local uP,UP=QP:GetDescendants();
            for MP,MP in y[3],uP,UP do
              if not MP[l[1031]] then
                RP[#RP+l[229]]=MP;
                EP[l[1146]](function()
                  MP[l[1031]]=l[383];
                end);
              end
            end;
            EP[l[1146]](function()
              QP[l[1031]]=l[383];
            end);
            UP,uP=EP[l[1146]](function()
              return QP:Clone();
            end);
            EP[l[1146]](function()
              QP[l[1031]]=gP;
            end);
            for gP,gP in y[3],RP,nil do
              EP[l[1146]](function()
                gP[l[1031]]=l[1329];
              end);
            end;
            if not UP or not uP then
              return;
            end
            UP={};
            kP(QP,uP,UP);
            vP(uP);
            if #UP==l[393] then
              uP:Destroy();
              return;
            end
            uP[l[1150]]=f();
            xP();
            uP[l[382]]=sP;
            GP[l[1160]]=uP;
            GP[l[934]]=UP;
            GP[l[593]]=tP;
            RP=tP[l[1480]]:Inverse();
            for sP=l[229],#UP,l[229]do
              tP=UP[sP];
              if tP[l[229]][l[382]]and tP[l[59]][l[382]] then
                tP[l[59]][l[1480]]=RP*tP[l[229]][l[1480]];
              end
            end;
            UP,tP,RP=EP[l[1146]](uP[l[338]],uP);
            local sP=UP and EP[l[1703]](RP)==l[135]and RP[l[636]]>l[393];
            if sP then
              B=RP;
            end
            sP=UP and EP[l[1703]](tP)==l[1480];
            if sP then
              F=EP[l[135]][l[772]](l[393],tP[l[948]][l[636]],l[393]);
              local sP,kP,vP=EP[l[135]][l[772]],l[393],F;
              UP,RP=vP[l[636]],B;
              fP=sP(kP,UP-RP[l[636]]*l[922],l[393]);
            end
            oP=l[383];
            wP=l[1329];
            hP();
            WP();
            EP[l[1022]][l[1061]](DP);
            OP=d(QP[l[328]],function(B)
              if B:IsA(l[1635])or B:IsA(l[375])or B:IsA(l[674])or B:IsA(l[468])or B:IsA(l[1619]) then
                IP();
              end
            end);
            if G[l[1617]] then
              I(G[l[1617]],uP,GP);
            end
          end
          local function B()
            local F=GP[l[593]];
            if not F or not F[l[382]] then
              IP();
              return;
            end
            local sP,fP=F[l[1480]]:Inverse(),GP[l[934]];
            for OP=l[229],#fP,l[229]do
              F=fP[OP];
              local fP,OP=F[l[229]],F[l[59]];
              if fP[l[382]]and OP[l[382]] then
                OP[l[1480]]=sP*fP[l[1480]];
              end
            end;
          end
          d(p:GetPropertyChangedSignal(l[160]),function()
            hP();
            local p=oP;
            if p then
              WP();
            end
          end);
          d(y[10][l[1119]],function(p)
            local F,sP=s[87](),y[18][l[630]]and LP[l[1600]]and KP[l[1324]]and A[l[1273]]and l[383]or l[1329];
            if sP~=GP[l[897]] then
              GP[l[897]]=sP;
              if sP then
                F[l[1022]][l[1061]](DP);
              else
                XP(l[393]);
              end
            end
            if not sP then
              return;
            end
            sP=not oP or not GP[l[1160]]or not GP[l[1160]][l[382]];
            if sP then
              local A=F[l[655]][l[1587]]()>=SP;
              if A then
                SP=F[l[655]][l[1587]]()+l[330];
                iP();
              end
              return;
            end
            sP=wP and(F[l[655]][l[1587]]()>=SP or F[l[655]][l[1587]]()-FP>=l[59]);
            if sP then
              SP=F[l[655]][l[1587]]()+l[330];
              iP();
            end
            B();
            sP=mP;
            if sP then
              AP=l[393];
              local B,A=F[l[35]][l[850]],BP;
              BP=B(A-p*l[1092],l[393]);
            else
              AP+=p;
              local B=AP;
              local A=B>G[l[1330]];
              if A then
                local B,A=F[l[35]][l[457]],BP;
                BP=B(A+p/F[l[35]][l[850]](G[l[892]],l[1296]),l[229]);
              end
            end
            local B,A=G[l[932]]~=l[393];
            if B then
              sP=BP;
              A=sP>l[393];
            else
              A=B;
            end
            if A then
              B=BP*BP*(l[863]-l[59]*BP);
              GP[l[1025]]=(GP[l[1025]]+G[l[932]]*B*p)%l[1372];
            end
            WP();
            XP(p);
          end);
          d(aP[l[1558]],function(p)
            local B,A=s[87](),not G[l[147]]or mP;
            if A then
              return;
            end
            if p[l[1317]]~=B[l[128]][l[1317]][l[1356]]and p[l[1317]]~=B[l[128]][l[1317]][l[239]] then
              return;
            end
            mP=l[383];
            O(l[229]);
            r[l[1594]--[[__index]]][l[1195]]=l[1329];
            y[18]:chime(l[1320]);
            P(V,H,{[l[747]]=l[330]});
            A=(y[9]:GetMouseLocation());
            while true do
              local F=mP and(y[9]:IsMouseButtonPressed(B[l[128]][l[1317]][l[1356]])or p[l[1101]]~=B[l[128]][l[1101]][l[912]]);
              if not F then
                break;
              end
              F=(y[9]:GetMouseLocation());
              local p=F-A;
              local sP=p[l[1437]]~=l[393]or p[l[636]]~=l[393];
              if sP then
                GP[l[1025]]=(GP[l[1025]]-p[l[1437]]*G[l[150]])%l[1372];
                GP[l[687]]=B[l[35]][l[819]](GP[l[687]]-p[l[636]]*G[l[150]],l[1606],l[1367]);
                local p=oP;
                if p then
                  WP();
                end
              end
              B[l[1022]][l[153]]();
              A=F;
            end;
            mP=l[1329];
            r[l[1594]--[[__index]]][l[1195]]=l[383];
            O(l[715]);
            P(V,H,{[l[747]]=l[52]});
          end);
          d(aP[l[412]],function(p)
            local r=s[87]();
            local B=p[l[1317]]==r[l[128]][l[1317]][l[1356]]or p[l[1317]]==r[l[128]][l[1317]][l[239]];
            if B then
              mP=l[1329];
            end
          end);
          d(y[9][l[412]],function(p)
            local r=s[87]();
            local B=p[l[1317]]==r[l[128]][l[1317]][l[1356]]or p[l[1317]]==r[l[128]][l[1317]][l[239]];
            if B then
              mP=l[1329];
            end
          end);
          d(aP[l[1538]],function()
            P(V,H,{[l[747]]=l[1017]});
          end);
          d(aP[l[1628]],function()
            local p=mP;
            if not p then
              P(V,H,{[l[747]]=l[52]});
            end
          end);
          local function p(r,B,A)
            r=s[87]();
            if r[l[1382]](B) then
              GP[l[1025]]=r[l[1382]](B)%l[1372];
            end
            if r[l[1382]](A) then
              GP[l[687]]=r[l[35]][l[819]](r[l[1382]](A),l[1606],l[1367]);
            end
            B=oP;
            if B then
              WP();
            end
          end
          GP[l[1255]]=p;
          local function p(r)
            return GP[l[1025]],GP[l[687]],GP[l[1230]];
          end
          GP[l[506]]=p;
          local function p(r,B)
            r=s[87]();
            GP[l[1230]]=r[l[35]][l[819]](r[l[1382]](B)or l[229],l[615],l[786]);
            r=oP;
            if r then
              WP();
            end
          end
          GP[l[55]]=p;
          local function p(r,B)
            r=s[87]();
            G[l[932]]=r[l[1382]](B)or l[393];
          end
          GP[l[1049]]=p;
          local function p(r,B)
            r=s[87]();
            zP[l[1309]]=r[l[35]][l[819]](r[l[1382]](B)or l[1157],l[730],l[856]);
            hP();
            r=oP;
            if r then
              WP();
            end
          end
          GP[l[1384]]=p;
          local function p(r)
            r=s[87]();
            GP[l[1025]]=r[l[1382]](G[l[1025]])or l[393];
            GP[l[687]]=r[l[35]][l[819]](r[l[1382]](G[l[687]])or l[393],l[1606],l[1367]);
            GP[l[1230]]=r[l[35]][l[819]](r[l[1382]](G[l[1230]])or l[229],l[615],l[786]);
            hP();
            r=oP;
            if r then
              WP();
            end
          end
          GP[l[1009]]=p;
          local function p(r)
            SP=l[393];
            xP();
          end
          GP[l[1002]]=p;
          local function p(r)
            DP();
          end
          GP[l[1555]]=p;
          local function p(r,B)
            r=s[87]();
            if r[l[40]](B)~=l[1712] then
              return function()
              end;
            end
            r[l[1346]][l[968]](NP,B);
            return function()
              local r=s[87]();
              local A=r[l[1346]][l[23]](NP,B);
              if A then
                r[l[1346]][l[1357]](NP,A);
              end
            end;
          end
          GP[l[64]]=p;
          local function p(r,B)
            r=s[87]();
            if r[l[1703]](B)~=l[135] then
              return r[l[1689]][l[772]](),l[1329];
            end
            local A,F,V=_P(B);
            if not V then
              return r[l[1689]][l[772]](),l[1329];
            end
            B,V=VP();
            return r[l[1689]][l[772]](A,F),A>=B[l[1437]]and F>=B[l[636]]and A<=B[l[1437]]+V[l[1437]]and F<=B[l[636]]+V[l[636]];
          end
          GP[l[467]]=p;
          local function p(r,B,A)
            local F,V=s[87](),B or GP[l[1160]];
            if not GP[l[897]]or not V or not V[l[382]] then
              return nil;
            end
            local sP=F[l[35]][l[1670]];
            local zP=F[l[35]][l[1670]];
            local fP=-l[94];
            local aP=-l[94];
            local NP=l[1329];
            local function DP(KP)
              local oP=s[87]();
              if KP[l[747]]>=l[229]or KP[l[1639]][l[945]]<=l[393] then
                return l[383];
              end
              local mP,SP,OP,BP=KP[l[1639]]*l[659],l[229],l[930],l[229];
              for AP=SP,OP,BP do
                local SP,OP,BP=_P(KP[l[1480]]*(o[AP]*mP));
                if not BP then
                  return l[1329];
                end
                BP,AP=oP[l[35]][l[457]](sP,SP),oP[l[35]][l[457]](zP,OP);
                sP,zP=BP,AP;
                AP,BP=oP[l[35]][l[850]](fP,SP),oP[l[35]][l[850]](aP,OP);
                fP,aP=AP,BP;
              end;
              NP=l[383];
              return l[383];
            end
            B=l[1635];
            if V:IsA(B) then
              if not DP(V) then
                return nil;
              end
            elseif V==GP[l[1160]] then
              r=GP[l[934]];
              for o=l[229],#r,l[229]do
                local KP=r[o][l[59]];
                if KP[l[382]]and not DP(KP) then
                  return nil;
                end
              end;
            else
              local o,KP=V:GetDescendants();
              for oP,oP in y[3],o,KP do
                if oP:IsA(l[1635])and not DP(oP) then
                  return nil;
                end
              end;
            end
            B=not NP;
            if B then
              return nil;
            end
            V=not A;
            if V then
              r,B=VP();
              sP=F[l[35]][l[850]](sP,r[l[1437]]);
              zP=F[l[35]][l[850]](zP,r[l[636]]);
              fP=F[l[35]][l[457]](fP,r[l[1437]]+B[l[1437]]);
              aP=F[l[35]][l[457]](aP,r[l[636]]+B[l[636]]);
              A=fP-sP<l[229]or aP-zP<l[229];
              if A then
                return nil;
              end
            else
            end
            r,V,DP,F=sP,zP,fP-sP,aP-zP;
            return r,V,DP,F;
          end
          GP[l[83]]=p;
          local function p(r)
            local r,o=VP();
            return r,o,GP[l[897]];
          end
          GP[l[1470]]=p;
          if G[l[1009]] then
            local G=a;
            local p=l[1742];
            local r={};
            r[l[1150]]=f();
            r[l[1016]]=J[l[1689]][l[772]](l[229],l[659]);
            r[l[948]]=J[l[1459]][l[772]](l[229],l[1519],l[659],l[393]);
            r[l[1639]]=J[l[1459]][l[588]](l[1707],l[1707]);
            r[l[1535]]=R[l[1466]];
            r[l[1646]]=l[229];
            r[l[1418]]=l[393];
            r[l[1451]]=y[30](l[1169]);
            r[l[936]]=R[l[1379]];
            r[l[2]]=l[986];
            r[l[1557]]=J[l[128]][l[1557]][l[220]];
            r[l[711]]=l[930];
            local J=G(p,r,w);
            D(J,l[303]);
            d(J[l[1538]],function()
              P(J,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
            end);
            d(J[l[1628]],function()
              P(J,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
            end);
            d(J[l[445]],function()
              J[l[936]]=R[l[98]];
              P(J,H,{[l[936]]=R[l[1379]]});
              y[18]:chime(l[1320]);
              GP:reset();
              GP:refresh();
            end);
          end
          d(y[13][l[426]],IP);
          d(y[13][l[1385]],IP);
          return GP;
        end
        cP[l[822]]=n;
        return cP;
      end
      local function n(J)
        local G=s[87]();
        local p=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1324]]=l[1329],[l[711]]=l[786]},bP);
        return p,pP(p,J);
      end
      local function J(G)
        local p=g;
        if p==G then
          return;
        end
        p=g;
        if p then
          local p=g;
          p[l[1674]](l[1329]);
          y[18]:chime(l[651]);
        end
        g=G;
        LP[l[897]]=G;
        G[l[1674]](l[383]);
      end
      local function G(p,r,o,B)
        local A={};
        local w,F=s[87](),o>l[393];
        local V=r[l[1658]]~=l[1746]and(F and l[913]or l[906])or(F and l[1655]or l[1249]);
        local sP,zP=l[930]+o*l[551],F and l[750]or l[829];
        local fP=sP+zP+l[1092];
        local aP={[l[127]]=l[930],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=w[l[1459]][l[772]](l[229],l[393],l[393],V),[l[1535]]=R[l[1132]],[l[1646]]=l[629],[l[1418]]=l[393],[l[537]]=B,[l[711]]=l[1092]},p)};
        D(aP[l[1466]],l[1158]);
        aP[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},aP[l[1466]]);
        aP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=w[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},aP[l[1466]]);
        D(aP[l[1642]],l[1158]);
        K(aP[l[1642]],l[393],{w[l[677]][l[772]](l[393],l[393]),w[l[677]][l[772]](l[509],l[986]),w[l[677]][l[772]](l[229],l[1017])});
        aP[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=w[l[1689]][l[772]](l[393],l[659]),[l[948]]=w[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=w[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},aP[l[1466]]);
        o,B=l[1112],{};
        B[l[1182]]=w[l[740]][l[772]](l[229],l[393]);
        a(o,B,aP[l[451]]);
        A[1]=l[647];
        A[3]=a;
        A[4]=l[859];
        A[2]={};
        A[2][l[1150]]=f();
        A[2][l[1016]]=w[l[1689]][l[772]](l[393],l[659]);
        A[2][l[948]]=w[l[1459]][l[772]](l[393],sP,l[659],l[393]);
        A[2][l[1639]]=w[l[1459]][l[588]](zP,zP);
        A[2][l[1646]]=l[229];
        A[2][l[1451]]=y[30](r[l[13]]);
        A[2][l[936]]=R[l[1379]];
        A[2][l[2]]=l[615];
        A[2][l[711]]=l[930];
        A[5]=(A[3](A[4],A[2],aP[l[1466]]));
        aP[A[1]]=A[5];
        if r[l[1658]]~=l[1746] then
          aP[l[1129]]=a(l[1070],{[l[1150]]=f(),[l[948]]=w[l[1459]][l[772]](l[393],fP,l[393],F and l[863]or l[303]),[l[1639]]=w[l[1459]][l[772]](l[229],-fP-aP[l[127]],l[393],F and l[558]or l[829]),[l[1646]]=l[229],[l[437]]=w[l[128]][l[437]][l[1381]],[l[1420]]=r[l[572]],[l[510]]=R[l[1379]],[l[723]]=F and l[310]or l[750],[l[916]]=l[330],[l[164]]=w[l[128]][l[164]][l[1021]],[l[1634]]=w[l[128]][l[1634]][l[701]],[l[711]]=l[930]},aP[l[1466]]);
          aP[l[1568]]=a(l[1070],{[l[1150]]=f(),[l[948]]=w[l[1459]][l[772]](l[393],fP,l[393],F and l[829]or l[884]),[l[1639]]=w[l[1459]][l[772]](l[229],-fP-aP[l[127]],l[393],l[1307]),[l[1646]]=l[229],[l[437]]=w[l[128]][l[437]][l[1381]],[l[1420]]=r[l[1658]],[l[510]]=R[l[1379]],[l[723]]=l[551],[l[916]]=l[509],[l[164]]=w[l[128]][l[164]][l[1021]],[l[1634]]=w[l[128]][l[1634]][l[701]],[l[711]]=l[930]},aP[l[1466]]);
        else
          aP[l[1129]]=a(l[1070],{[l[1150]]=f(),[l[948]]=w[l[1459]][l[772]](l[393],fP,l[393],l[393]),[l[1639]]=w[l[1459]][l[772]](l[229],-fP-aP[l[127]],l[229],l[393]),[l[1646]]=l[229],[l[437]]=w[l[128]][l[437]][l[1381]],[l[1420]]=r[l[572]],[l[510]]=R[l[1379]],[l[723]]=F and l[310]or l[750],[l[916]]=l[330],[l[164]]=w[l[128]][l[164]][l[1021]],[l[1634]]=w[l[128]][l[1634]][l[701]],[l[711]]=l[930]},aP[l[1466]]);
        end
        aP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=w[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},aP[l[1466]]);
        local function p(r)
          local o=s[87]();
          aP[l[127]]=r;
          aP[l[1129]][l[1639]]=o[l[1459]][l[772]](l[229],-fP-r,aP[l[1129]][l[1639]][l[636]][l[1609]],aP[l[1129]][l[1639]][l[636]][l[1485]]);
          if aP[l[1568]] then
            aP[l[1568]][l[1639]]=o[l[1459]][l[772]](l[229],-fP-r,l[393],l[1307]);
          end
        end
        aP[l[183]]=p;
        local function p(r)
          local o=s[87]();
          aP[l[1543]]=r;
          local B,A=aP[l[1642]],{};
          A[l[1646]]=r and l[841]or l[229];
          P(B,H,A);
          B,A=aP[l[1473]],{};
          A[l[747]]=r and l[1567]or l[229];
          P(B,H,A);
          P(aP[l[451]],H,{[l[1639]]=o[l[1459]][l[772]](l[393],l[863],l[393],r and o[l[35]][l[499]](V*l[1017])or l[393]),[l[1646]]=r and l[1296]or l[229]});
          P(aP[l[647]],H,{[l[2]]=r and l[393]or l[615],[l[936]]=r and R[l[1095]]or R[l[1379]]});
          P(aP[l[1129]],H,{[l[916]]=r and l[393]or l[330],[l[510]]=r and R[l[1095]]or R[l[1379]]});
          if aP[l[1568]] then
            A,B=aP[l[1568]],{};
            B[l[916]]=r and l[330]or l[509];
            P(A,H,B);
          end
        end
        aP[l[406]]=p;
        d(aP[l[1466]][l[1538]],function()
          if not aP[l[1543]] then
            local p,r=aP[l[1642]],{};
            r[l[1646]]=l[1017];
            P(p,H,r);
            r,p=aP[l[1129]],{};
            p[l[916]]=l[263];
            P(r,H,p);
            r,p=aP[l[647]],{};
            p[l[2]]=l[263];
            P(r,H,p);
          end
        end);
        d(aP[l[1466]][l[1628]],function()
          if not aP[l[1543]] then
            local p,r=aP[l[1642]],{};
            r[l[1646]]=l[229];
            P(p,H,r);
            r,p=aP[l[1129]],{};
            p[l[916]]=l[330];
            P(r,H,p);
            r,p=aP[l[647]],{};
            p[l[2]]=l[615];
            P(r,H,p);
          end
        end);
        return aP;
      end
      local function p(r,o)
        r=s[87]();
        o=X(o,{[l[572]]=l[651],[l[13]]=l[1746],[l[1658]]=l[1746],[l[1600]]=l[1329]});
        local B=t;
        t=B+l[229];
        local A,w,F=a(l[211],{[l[1150]]=f(),[l[1639]]=r[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=r[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[537]]=t,[l[711]]=l[1092]},Q),l[755],{[l[407]]=r[l[128]][l[407]][l[537]]};
        F[l[536]]=r[l[740]][l[772]](l[393],l[59]);
        a(w,F,A);
        local w=G(A,o,l[393],l[229]);
        local F=a;
        local V=l[859];
        local t={};
        t[l[1150]]=f();
        t[l[1016]]=r[l[1689]][l[772]](l[229],l[659]);
        t[l[948]]=r[l[1459]][l[772]](l[229],l[708],l[659],l[393]);
        t[l[1639]]=r[l[1459]][l[588]](l[750],l[750]);
        t[l[1646]]=l[229];
        t[l[1451]]=y[30](l[606]--[[readu16]]);
        t[l[936]]=R[l[1379]];
        t[l[2]]=l[229];
        t[l[500]]=l[393];
        t[l[1324]]=l[1329];
        t[l[711]]=l[930];
        local R=F(V,t,w[l[1466]]);
        local F=a(l[211],{[l[1150]]=f(),[l[1639]]=r[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=l[59],[l[711]]=l[1092]},A);
        local A=a(l[755],{[l[407]]=r[l[128]][l[407]][l[537]],[l[536]]=r[l[740]][l[772]](l[393],l[59])},F);
        local V,t=n(o[l[572]]);
        local sP={[l[572]]=o[l[572]],[l[178]]=V,[l[245]]={},[l[1600]]=l[1329],[l[1466]]=w[l[1466]]};
        local function zP(fP,fP)
          return t:section(fP);
        end
        sP[l[146]]=zP;
        local function zP(fP,fP)
          return t:color(fP);
        end
        sP[l[1409]]=zP;
        local function zP(fP,fP)
          return t:configs(fP);
        end
        sP[l[963]]=zP;
        local function zP(fP,fP)
          return t:clone(fP);
        end
        sP[l[822]]=zP;
        local function zP(fP,fP)
          return t:gallery(fP);
        end
        sP[l[484]]=zP;
        sP[l[1674]]=function(zP)
          w[l[406]](zP);
          if zP then
            V[l[382]]=qP;
            V[l[1324]]=l[383];
            t[l[811]]();
          else
            V[l[1324]]=l[1329];
            V[l[382]]=bP;
            t[l[86]]();
          end
        end;
        local function V(t)
          local zP,fP=s[87](),sP[l[1600]]and j(A)[l[636]]or l[393];
          if t then
            F[l[1639]]=zP[l[1459]][l[772]](l[229],l[393],l[393],fP);
            return;
          end
          local j=F[l[1639]][l[636]][l[1485]];
          b(F,l[894],sP[l[1600]]and N or q,function(t)
            local zP=s[87]();
            F[l[1639]]=zP[l[1459]][l[772]](l[229],l[393],l[393],j+(fP-j)*t);
          end);
        end
        d(A:GetPropertyChangedSignal(l[996]),function()
          if sP[l[1600]] then
            V(l[383]);
          end
        end);
        local function j(A,A)
          sP[l[1600]]=A and l[383]or l[1329];
          V(l[1329]);
          local A=R[l[500]];
          local V=sP[l[1600]]and l[1510]or l[393];
          b(R,l[1283],N,function(t)
            R[l[500]]=A+(V-A)*t;
          end);
        end
        sP[l[1521]--[[0]]]=j;
        local function j(A)
          J(sP);
        end
        sP[l[199]]=j;
        local function j(A,V)
          A=s[87]();
          V=X(V,{[l[572]]=l[1724],[l[13]]=l[1746],[l[1658]]=l[1746]});
          local t=G(F,V,l[229],#sP[l[245]]+l[229]);
          local G,F=n(o[l[572]]..l[1074]..V[l[572]]);
          local n={[l[572]]=V[l[572]],[l[178]]=G,[l[1466]]=t[l[1466]]};
          local function V(zP,zP)
            return F:section(zP);
          end
          n[l[146]]=V;
          local function V(zP,zP)
            return F:color(zP);
          end
          n[l[1409]]=V;
          local function V(zP,zP)
            return F:configs(zP);
          end
          n[l[963]]=V;
          local function V(zP,zP)
            return F:clone(zP);
          end
          n[l[822]]=V;
          local function V(zP,zP)
            return F:gallery(zP);
          end
          n[l[484]]=V;
          n[l[1674]]=function(V)
            t[l[406]](V);
            if V then
              G[l[382]]=qP;
              G[l[1324]]=l[383];
              F[l[811]]();
            else
              G[l[1324]]=l[1329];
              G[l[382]]=bP;
              F[l[86]]();
            end
          end;
          local function G(F)
            J(n);
          end
          n[l[199]]=G;
          d(t[l[974]][l[445]],function()
            J(n);
          end);
          A[l[1346]][l[968]](sP[l[245]],n);
          if not R[l[1324]] then
            R[l[1324]]=l[383];
            w[l[183]](l[658]);
            P(R,H,{[l[2]]=l[615]});
          end
          if o[l[1600]]and not sP[l[1600]] then
            sP:setopen(l[383]);
          end
          return n;
        end
        sP[l[1724]]=j;
        d(w[l[974]][l[445]],function()
          if #sP[l[245]]>l[393] then
            local n=sP[l[1600]];
            sP:setopen(not n);
            if n then
              return;
            end
          end
          J(sP);
        end);
        B=g;
        if not B then
          J(sP);
        end
        r[l[1346]][l[968]](LP[l[1206]],sP);
        return sP;
      end
      LP[l[651]]=p;
      CP:mark(Y);
      _(eP,dP,l[1694]);
      LP[l[1156]]=dP;
      LP[l[593]]=YP;
      LP[l[1132]]=rP;
      LP[l[642]]=jP;
      LP[l[781]]=qP;
      LP[l[895]]=Q;
      LP[l[875]]=CP;
      local function n(J,J)
        CP:mark(J);
      end
      LP[l[1040]]=n;
      local function n(J,J)
        local G={};
        local Y=s[87]();
        LP[l[1600]]=J and l[383]or l[1329];
        local j=YP[l[1569]];
        local p=LP[l[1600]]and l[393]or l[229];
        G[1]=y[18];
        G[2]=l[583];
        G[3]=LP[l[1600]];
        G[1][G[2]]=G[3];
        if not LP[l[1600]] then
          J=C[YP];
          if J then
            J:Disconnect();
            C[YP]=nil;
          end
          dP[l[1324]]=l[1329];
          for J=l[229],#PP,l[229]do
            PP[J][l[747]]=l[229];
          end;
          YP[l[1569]]=l[229];
          CP[l[404]]=l[1329];
          Y[l[1146]](y[18][l[248]],y[18],l[914]);
          Y[l[1146]](y[18][l[987]],y[18]);
          return;
        end
        Y[l[1146]](y[18][l[248]],y[18],l[1600]);
        Y[l[1146]](y[18][l[987]],y[18]);
        dP[l[1324]]=l[383];
        CP[l[404]]=l[383];
        b(YP,l[894],N,function(J)
          local G=j+(p-j)*J;
          YP[l[1569]]=G;
          for J=l[229],#PP,l[229]do
            PP[J][l[747]]=ZP[J]+(l[229]-ZP[J])*G;
          end;
        end);
      end
      LP[l[80]]=n;
      local function n(J)
        LP:render(not LP[l[1600]]);
      end
      LP[l[524]]=n;
      d(dP:GetPropertyChangedSignal(l[1324]),function()
        if dP[l[1324]]and not LP[l[1600]] then
          dP[l[1324]]=l[1329];
        end
      end);
      local function n(J,G)
        J=s[87]();
        u[l[1451]]=J[l[1130]](G);
      end
      LP[l[162]]=n;
      local function n(J,J)
        LP[l[1096]]=J;
        if LP[l[1600]] then
          P(dP,T,{[l[1639]]=J});
        else
          dP[l[1639]]=J;
        end
      end
      LP[l[1532]--[[delay]]]=n;
      local function T(n,J)
        n=s[87]();
        if n[l[1703]](J)==l[802] then
          LP[l[1686]]=J;
          HP();
          return;
        end
        if n[l[40]](J)==l[409] then
          local G,Y=n[l[1146]](function()
            local j=s[87]();
            return j[l[128]][l[880]--[[readu32]]][J];
          end);
          if G and n[l[1703]](Y)==l[802] then
            LP[l[1686]]=Y;
            HP();
          end
        end
      end
      LP[l[116]]=T;
      HP();
      d(dP[l[956]],function()
        local T=s[87]();
        T[l[1146]](function()
          yP:UnbindAction(JP);
        end);
      end);
      d(jP[l[1538]],function()
        local T={};
        T[1]=y[18];
        T[2]=l[1582];
        T[3]=l[383];
        T[1][T[2]]=T[3];
      end);
      d(jP[l[1628]],function()
        local T={};
        T[1]=y[18];
        T[2]=l[1582];
        T[3]=l[1329];
        T[1][T[2]]=T[3];
      end);
      E[l[1346]][l[968]](y[18][l[769]],LP);
      E[l[1022]][l[1061]](function()
        LP:render(l[383]);
      end);
      return LP;
    end
    y[597]=l[1423];
    y[18][y[597]]=i;
    y[598]=l[1438];
    y[599]={};
    y[18][y[598]]=y[599];
    local T=k(l[1198]);
    local n;
    local function J(G)
      local Y,j=s[87](),n;
      if j then
        local C,p=Y[l[1146]](n,G);
        return C and Y[l[40]](p)==l[409]and p or nil;
      end
      j=Y[l[1469]]();
      local C={Y[l[366]]and Y[l[366]][l[1398]--[[Path2DControlPoint]]],Y[l[366]]and Y[l[366]][l[907]]and Y[l[366]][l[907]][l[824]],Y[l[366]]and Y[l[366]][l[887]],j[l[907]]and j[l[907]][l[824]],j[l[887]],j[l[1398]--[[Path2DControlPoint]]]};
      for p,r in y[3],C,nil do
        j=Y[l[40]](r)==l[1712];
        if j then
          local j,C=Y[l[1146]](r,G);
          p=j and Y[l[40]](C)==l[409];
          if p then
            n=r;
            return C;
          end
        end
      end;
      return nil;
    end
    local function n(G)
      local Y=s[87]();
      local j=Y[l[1469]]();
      local C={j[l[1507]]and j[l[1507]][l[1055]],j[l[904]]and j[l[904]][l[1744]]and j[l[904]][l[1744]][l[1055]],j[l[1744]]and j[l[1744]][l[1055]]};
      for p,r in y[3],C,nil do
        if Y[l[40]](r)==l[1712] then
          p,j=Y[l[1146]](r,G);
          if p and j then
            return j;
          end
        end
      end;
      return nil;
    end
    local function G(Y,Y)
      local j,C=s[87](),y[18][l[131]];
      Y=X(Y,{[l[572]]=l[1116],[l[1590]]=l[300],[l[1096]]=j[l[1689]][l[772]](l[84],l[521]),[l[457]]=j[l[1689]][l[772]](l[306],l[341]),[l[24]]=l[1286],[l[1610]]=l[1249],[l[871]]=l[863],[l[1617]]=nil});
      local p,r=j[l[35]][l[850]](j[l[35]][l[499]](Y[l[1096]][l[1437]]),Y[l[457]][l[1437]]),j[l[35]][l[850]](j[l[35]][l[499]](Y[l[1096]][l[636]]),Y[l[457]][l[636]]);
      local o=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=j[l[1459]][l[772]](l[659],-j[l[35]][l[499]](p*l[659]),l[659],-j[l[35]][l[499]](r*l[659])),[l[1639]]=j[l[1459]][l[588]](p,r),[l[1535]]=C[l[641]],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1632]},x);
      Z(o);
      D(o,l[551]);
      a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1017]},o);
      if T then
        a(l[1198],{[l[1630]]=C[l[641]],[l[258]]=j[l[740]][l[772]](l[393],l[658]),[l[1485]]=j[l[1459]][l[588]](l[393],l[1158]),[l[1326]]=j[l[1459]][l[588]](l[1024],l[1024]),[l[747]]=l[330],[l[711]]=l[715]},o);
      end
      local T=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[1282]),[l[1535]]=C[l[1466]],[l[1418]]=l[393],[l[711]]=l[421]},o);
      D(T,l[551]);
      a(l[211],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[229]),[l[948]]=j[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[551]),[l[1535]]=C[l[1466]],[l[1418]]=l[393],[l[711]]=l[421]},T);
      K(a(l[211],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[393],l[1282]),[l[1639]]=j[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=C[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[652]},o),l[393],{j[l[677]][l[772]](l[393],l[229]),j[l[677]][l[772]](l[841],l[874]),j[l[677]][l[772]](l[659],l[393]),j[l[677]][l[772]](l[804],l[874]),j[l[677]][l[772]](l[229],l[229])});
      local function r(B,A,w)
        local F=s[87]();
        local V=a;
        local k=l[1742];
        local i={};
        i[l[1150]]=f();
        i[l[1016]]=F[l[1689]][l[772]](w and l[229]or l[393],l[659]);
        i[l[948]]=F[l[1459]][l[772]](w and l[229]or l[393],B,l[659],l[393]);
        i[l[1639]]=F[l[1459]][l[588]](l[1243],l[1243]);
        i[l[1535]]=C[l[675]];
        i[l[1646]]=l[229];
        i[l[1418]]=l[393];
        i[l[1451]]=y[30](A);
        i[l[936]]=C[l[1379]];
        i[l[2]]=l[986];
        i[l[1557]]=F[l[128]][l[1557]][l[220]];
        i[l[711]]=l[1513];
        local B=V(k,i,T);
        D(B,l[1158]);
        d(B[l[1538]],function()
          P(B,H,{[l[2]]=l[393],[l[936]]=C[l[1095]],[l[1646]]=l[615]});
        end);
        d(B[l[1628]],function()
          P(B,H,{[l[2]]=l[986],[l[936]]=C[l[1379]],[l[1646]]=l[229]});
        end);
        return B;
      end
      local B,A,w,F=r(l[930],l[515]),r(l[913],l[515]),r(l[205],l[1169]),r(l[1519],l[898],l[383]);
      B[l[500]]=l[1510];
      local V=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[659]),[l[948]]=j[l[1459]][l[772]](l[393],l[694],l[659],l[393]),[l[1639]]=j[l[1459]][l[772]](l[229],l[1171],l[393],l[1655]),[l[1535]]=C[l[641]],[l[1646]]=l[986],[l[1418]]=l[393],[l[1155]]=l[1329],[l[437]]=j[l[128]][l[437]][l[807]],[l[32]]=l[617],[l[592]]=C[l[1379]],[l[1420]]=Y[l[1590]],[l[510]]=C[l[1095]],[l[723]]=l[750],[l[164]]=j[l[128]][l[164]][l[1021]],[l[1634]]=j[l[128]][l[1634]][l[701]],[l[711]]=l[1513]},T);
      D(V,l[1158]);
      j[l[1146]](function()
        local k=s[87]();
        V[l[526]]=k[l[437]][l[772]](l[624],k[l[128]][l[1444]][l[1121]]);
      end);
      a(l[1359],{[l[1612]]=j[l[740]][l[772]](l[393],l[551]),[l[517]]=j[l[740]][l[772]](l[393],l[551])},V);
      local k=a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1419]},V);
      local i=a(l[211],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[930],l[726]),[l[1639]]=j[l[1459]][l[772]](l[229],l[286],l[229],l[1679]),[l[1535]]=C[l[641]],[l[1646]]=l[874],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[421]},o);
      D(i,l[1092]);
      a(l[734],{[l[1630]]=C[l[966]],[l[747]]=l[1567]},i);
      local E=a(l[859],{[l[1150]]=f(),[l[1639]]=j[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[2]]=l[229],[l[196]]=j[l[128]][l[1727]][l[1380]],[l[1557]]=j[l[128]][l[1557]][l[208]],[l[711]]=l[652]},i);
      D(E,l[1092]);
      local Q=a(l[1070],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[659],l[659]),[l[948]]=j[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=j[l[1459]][l[772]](l[229],l[207],l[393],l[906]),[l[1646]]=l[229],[l[437]]=j[l[128]][l[437]][l[1381]],[l[1420]]=l[1164],[l[510]]=C[l[1379]],[l[723]]=l[310],[l[916]]=l[986],[l[789]]=l[383],[l[711]]=l[1513]},i);
      local t,R=a(l[1742],{[l[1150]]=f(),[l[1639]]=j[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1167]},i),a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=j[l[1459]][l[588]](l[207],l[207]),[l[1639]]=j[l[1459]][l[588]](l[730],l[730]),[l[1646]]=l[229],[l[1155]]=l[1329],[l[1420]]=l[1746],[l[916]]=l[229],[l[711]]=l[421]},o);
      local g=a(l[1070],{[l[1150]]=f(),[l[1016]]=j[l[1689]][l[772]](l[393],l[229]),[l[948]]=j[l[1459]][l[772]](l[393],l[310],l[229],l[348]),[l[1639]]=j[l[1459]][l[772]](l[229],l[1614],l[393],l[558]),[l[1646]]=l[229],[l[437]]=j[l[128]][l[437]][l[807]],[l[1420]]=l[498],[l[510]]=C[l[1379]],[l[723]]=l[1307],[l[916]]=l[1431],[l[164]]=j[l[128]][l[164]][l[1021]],[l[1634]]=j[l[128]][l[1634]][l[701]],[l[711]]=l[652]},o);
      local u=a;
      local sP=l[1742];
      local LP={};
      LP[l[1150]]=f();
      LP[l[1016]]=j[l[1689]][l[772]](l[229],l[229]);
      LP[l[948]]=j[l[1459]][l[772]](l[229],l[1024],l[229],l[1024]);
      LP[l[1639]]=j[l[1459]][l[588]](l[352],l[352]);
      LP[l[1646]]=l[229];
      LP[l[1451]]=y[30](l[908]);
      LP[l[936]]=C[l[1379]];
      LP[l[2]]=l[323];
      LP[l[500]]=l[1157];
      LP[l[1557]]=j[l[128]][l[1557]][l[220]];
      LP[l[711]]=l[1513];
      local yP=u(sP,LP,o);
      local u,sP,LP={[l[1156]]=o,[l[732]]=i,[l[1736]]=E,[l[1590]]=Y[l[1590]],[l[1600]]=l[1329],[l[1273]]=l[1329],[l[24]]=Y[l[24]]};
      local zP=j[l[1689]][l[1729]];
      local JP=l[1329];
      local HP=l[393];
      local fP=l[393];
      local aP=l[393];
      local dP=l[1329];
      local PP,ZP,GP=l[1329],{};
      local YP,eP={};
      local function jP(CP)
        local NP,qP=s[87](),CP:IsA(l[734])or CP:IsA(l[1198]);
        if qP then
          local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[747]};
          bP[l[1118]]=CP[l[747]];
          qP(YP,bP);
        else
          local qP=CP:IsA(l[1070])or CP:IsA(l[1400]--[[-1]])or CP:IsA(l[192]);
          if qP then
            local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
            bP[l[1118]]=CP[l[1646]];
            qP(YP,bP);
            bP,qP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[916]};
            qP[l[1118]]=CP[l[916]];
            bP(YP,qP);
          else
            local qP=CP:IsA(l[859])or CP:IsA(l[1742]);
            if qP then
              local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
              bP[l[1118]]=CP[l[1646]];
              qP(YP,bP);
              bP={[l[689]]=CP,[l[1540]]=l[2],[l[1118]]=CP[l[2]]};
              NP[l[1346]][l[968]](YP,bP);
              qP=CP==E;
              if qP then
                eP=bP;
              end
            else
              local qP=l[957];
              if CP:IsA(qP) then
                local qP,bP=NP[l[1346]][l[968]],{[l[689]]=CP,[l[1540]]=l[1646]};
                bP[l[1118]]=CP[l[1646]];
                qP(YP,bP);
              end
            end
          end
        end
      end
      local function CP(NP)
        for qP=l[229],#YP,l[229]do
          local bP=YP[qP];
          if bP[l[689]][l[382]] then
            bP[l[689]][bP[l[1540]]]=bP[l[1118]]+(l[229]-bP[l[1118]])*NP;
          end
        end;
      end
      j[l[1146]](function()
        local YP=s[87]();
        GP=YP[l[188]](YP[l[1458]]:GetService(l[1718]));
      end);
      local function YP(NP)
        if g[l[1420]]~=NP then
          g[l[1420]]=NP;
        end
      end
      local function g(NP)
        local qP,bP=s[87](),sP;
        if not bP then
          return l[1329];
        end
        bP=qP[l[1146]](function()
          sP:Send(NP);
        end);
        if not bP then
          u[l[1273]]=l[1329];
        end
        return bP;
      end
      local function NP(qP,bP)
        local DP=s[87]();
        local pP=dP or not u[l[1600]]or DP[l[40]](qP)~=l[384]or DP[l[40]](bP)~=l[384]or qP<l[229]or bP<l[229]or qP>l[783]or bP>l[783]or qP%l[229]~=l[393]or bP%l[229]~=l[393];
        if pP then
          return l[1329];
        end
        pP=GP;
        if not pP then
          return l[1329];
        end
        local pP,rP=DP[l[1146]](function()
          local KP,oP=s[87](),GP;
          local GP={[l[1639]]=KP[l[1689]][l[772]](qP,bP)};
          return oP:CreateEditableImage(GP);
        end);
        if not pP or not rP then
          return l[1329];
        end
        pP=DP[l[1146]](function()
          local GP=s[87]();
          E[l[610]--[[readi32]]]=GP[l[342]][l[1625]](rP);
        end);
        if not(if not pP then DP[l[1146]](function()rP[l[382]]=E;end)else pP) then
          DP[l[1146]](function()
            rP:Destroy();
          end);
          return l[1329];
        end
        pP=LP;
        if pP then
          DP[l[1146]](function()
            LP:Destroy();
          end);
        end
        LP=rP;
        zP=DP[l[1689]][l[772]](qP,bP);
        E[l[2]]=l[393];
        Q[l[1324]]=l[1329];
        return l[383];
      end
      local function GP(qP,bP,DP,pP,rP)
        local KP,oP,cP=s[87](),dP or not u[l[1600]]or not qP or not bP or not DP or not pP or qP<l[393]or bP<l[393]or DP<l[229]or pP<l[229]or qP%l[229]~=l[393]or bP%l[229]~=l[393]or DP%l[229]~=l[393]or pP%l[229]~=l[393];
        if oP then
          cP=oP;
        else
          local mP,SP=qP+DP,zP;
          cP=mP>SP[l[1437]];
        end
        oP=nil;
        if cP then
          oP=cP;
        else
          local mP,SP=bP+pP,zP;
          oP=mP>SP[l[636]];
        end
        if oP or KP[l[40]](rP)~=l[409]or#rP>l[1392] then
          return;
        end
        oP=LP;
        if not oP then
          return;
        end
        local oP=J(rP);
        cP=DP*pP*l[786];
        if not oP or#oP<cP then
          return;
        end
        if #oP>cP then
          oP=KP[l[409]][l[1724]](oP,l[229],cP);
        else
        end
        KP[l[1146]](function()
          local J,rP=s[87](),LP;
          rP:WritePixelsBuffer(J[l[1689]][l[772]](qP,bP),J[l[1689]][l[772]](DP,pP),J[l[427]][l[1077]](oP));
        end);
      end
      local function J()
        local qP,bP=s[87](),i[l[160]];
        return qP[l[35]][l[819]](qP[l[35]][l[499]](bP[l[1437]]/l[930])*l[930],l[633],l[783]),(qP[l[35]][l[819]](qP[l[35]][l[499]](bP[l[636]]/l[930])*l[930],l[633],l[783]));
      end
      local function i()
        local qP,bP=J();
        local DP=zP;
        local pP,rP=DP[l[1437]]~=qP;
        if pP then
          rP=pP;
        else
          DP=zP;
          rP=DP[l[636]]~=bP;
        end
        if rP then
          g(l[635]..qP..l[214]..bP);
        end
      end
      local function qP(bP)
        local DP=s[87]();
        local pP=dP or not y[18][l[630]]or not u[l[1600]]or DP[l[40]](bP)~=l[409]or#bP>l[1392];
        if pP then
          return;
        end
        pP=DP[l[409]][l[56]](bP,l[1542]);
        if pP==l[347] then
          local rP,KP,oP,cP,mP=DP[l[409]][l[56]](bP,l[845]);
          if mP then
            GP(DP[l[1382]](rP),DP[l[1382]](KP),DP[l[1382]](oP),DP[l[1382]](cP),mP);
          end
        elseif pP==l[900] then
          local GP,rP=DP[l[409]][l[56]](bP,l[152]);
          if GP then
            NP(DP[l[1382]](GP),DP[l[1382]](rP));
          end
        elseif pP==l[692] then
          local GP=DP[l[409]][l[1724]](bP,l[863]);
          u[l[1590]]=GP;
          if not V:IsFocused() then
            V[l[1420]]=GP;
          end
        elseif pP==l[1395] then
          YP(DP[l[409]][l[1724]](bP,l[863]));
        elseif pP==l[1253] then
          YP(DP[l[409]][l[1724]](bP,l[863]));
        end
      end
      local function GP()
        local NP,bP=s[87](),aP;
        aP=bP+l[229];
        PP=l[1329];
        for DP,DP in y[5](ZP)do
          DP:Disconnect();
        end;
        NP[l[1346]][l[267]](ZP);
        bP=sP;
        if bP then
          local DP=sP;
          sP=nil;
          NP[l[1146]](function()
            DP:Close();
          end);
        end
        u[l[1273]]=l[1329];
        zP=NP[l[1689]][l[1729]];
        bP=LP;
        if bP then
          NP[l[1146]](function()
            LP:Destroy();
          end);
          LP=nil;
        end
        E[l[2]]=l[229];
        Q[l[1324]]=l[383];
      end
      local function LP()
        local zP,NP=s[87](),sP or PP or dP or not y[18][l[630]]or not u[l[1600]];
        if NP then
          return;
        end
        Q[l[1420]]=l[288]..u[l[24]];
        Q[l[1324]]=l[383];
        NP=aP;
        PP=l[383];
        local bP=n(u[l[24]]);
        local n=NP~=aP or dP or not y[18][l[630]]or not u[l[1600]];
        if n then
          if bP then
            zP[l[1146]](function()
              bP:Close();
            end);
          end
          return;
        end
        PP=l[1329];
        if not bP then
          Q[l[1420]]=l[1497]..u[l[24]]..l[1541];
          return;
        end
        sP=bP;
        u[l[1273]]=l[383];
        zP[l[1146]](function()
          ZP[#ZP+l[229]]=bP[l[1450]]:Connect(function(PP)
            local DP=sP;
            if DP==bP then
              qP(PP);
            end
          end);
        end);
        zP[l[1146]](function()
          ZP[#ZP+l[229]]=bP[l[1140]]:Connect(function()
            local PP=sP;
            if PP==bP then
              GP();
              Q[l[1420]]=l[1523];
            end
          end);
        end);
        NP,n=J();
        g(l[573]..zP[l[35]][l[819]](zP[l[35]][l[499]](Y[l[1610]]),l[229],l[1632]));
        g(l[635]..NP..l[214]..n);
        g(l[1620]..u[l[1590]]);
        YP(l[888]);
      end
      local function n()
        local J,Q,zP,PP=s[87](),y[9]:GetMouseLocation(),E[l[81]]+h(),E[l[160]];
        if PP[l[1437]]<l[229]or PP[l[636]]<l[229] then
          return nil;
        end
        return J[l[35]][l[819]]((Q[l[1437]]-zP[l[1437]])/PP[l[1437]],l[393],l[229]),J[l[35]][l[819]]((Q[l[636]]-zP[l[636]])/PP[l[636]],l[393],l[229]);
      end
      local function J(h,Q)
        h=s[87]();
        Q=h[l[1130]](Q or l[1746]);
        if not h[l[409]][l[56]](Q,l[825]) then
          return;
        end
        Q=if not h[l[409]][l[23]](Q,l[54],l[229],l[383])then h[l[409]][l[23]](Q,l[1213])and not h[l[409]][l[23]](Q,l[1446])and l[1585]..Q or l[696]..h[l[409]][l[1710]](Q,l[631],l[1287])else Q;
        if not Q:match(l[1388])or#Q>l[329] then
          return l[1329];
        end
        u[l[1590]]=Q;
        V[l[1420]]=Q;
        YP(l[1335]);
        g(l[1620]..Q);
      end
      u[l[1280]]=J;
      local function J(h,Q)
        local zP,PP=s[87](),dP or not y[18][l[630]];
        if PP then
          return;
        end
        Q=Q and l[383]or l[1329];
        if u[l[1600]]==Q then
          return;
        end
        u[l[1600]]=Q;
        PP=aP;
        aP=PP+l[229];
        local ZP=aP;
        y[18]:chime(Q and l[1600]or l[914]);
        PP=eP;
        if PP then
          h=eP;
          h[l[1118]]=E[l[2]];
        end
        if Q then
          CP(l[229]);
          o[l[1324]]=l[383];
          zP[l[1022]][l[1061]](LP);
          b(o,l[894],N,function(h)
            CP(l[229]-h);
          end);
        else
          b(o,l[304],q,function(h)
            CP(h);
            if h>=l[229] then
              o[l[1324]]=l[1329];
              CP(l[393]);
            end
          end);
          zP[l[1022]][l[1330]](l[304],function()
            local h=ZP==aP and not u[l[1600]]and not dP;
            if h then
              GP();
            end
          end);
        end
        if Y[l[1617]] then
          I(Y[l[1617]],Q);
        end
      end
      u[l[80]]=J;
      local function J(h)
        u:render(not u[l[1600]]);
      end
      u[l[524]]=J;
      local function J(h,E)
        h=s[87]();
        u[l[24]]=h[l[1130]](E or u[l[24]]);
        if u[l[1600]] then
          GP();
          h[l[1022]][l[1061]](LP);
        end
      end
      u[l[1173]]=J;
      local function J(h)
        local h,E=s[87](),dP;
        if E then
          return;
        end
        local E,Q,zP=l[1600],l[383],l[1329];
        dP=Q;
        u[E]=zP;
        GP();
        zP=(h[l[1346]][l[23]](y[18][l[1438]],u));
        if zP then
          h[l[1346]][l[1357]](y[18][l[1438]],zP);
        end
        o:Destroy();
      end
      u[l[794]]=J;
      d(F[l[445]],function()
        u:render(l[1329]);
      end);
      d(B[l[445]],function()
        y[18]:chime(l[1352]);
        g(l[885]);
      end);
      d(A[l[445]],function()
        y[18]:chime(l[1352]);
        g(l[1599]);
      end);
      d(w[l[445]],function()
        y[18]:chime(l[1320]);
        g(l[8]);
      end);
      d(V[l[722]],function(J)
        P(k,H,{[l[747]]=l[1419]});
        if J then
          u:go(V[l[1420]]);
        end
      end);
      d(V[l[505]],function()
        P(k,H,{[l[747]]=l[1431]});
      end);
      d(t[l[445]],function()
        local J,B,A=s[87](),n();
        if B then
          y[18]:chime(l[1320]);
          g(l[124]..J[l[409]][l[846]](l[1355],B,A)..l[842]);
          J[l[1146]](function()
            R:CaptureFocus();
          end);
        end
      end);
      d(t[l[861]],function()
        local J,B,A=s[87](),n();
        if B then
          g(l[124]..J[l[409]][l[846]](l[1355],B,A)..l[201]);
        end
      end);
      d(t[l[233]],function(J)
        local B=s[87]();
        if not u[l[1273]] then
          return;
        end
        if J[l[1317]]==B[l[128]][l[1317]][l[72]] then
          local A,w=n();
          if A then
            g(l[1371]..B[l[409]][l[846]](l[1355],A,w)..l[214]..(J[l[948]][l[989]]>l[393]and l[549]or l[710]));
          end
          return;
        end
        local A=J[l[1317]]==B[l[128]][l[1317]][l[765]];
        if A then
          J=B[l[655]][l[1587]]();
          local A=J-fP;
          if A<l[629] then
            return;
          end
          fP=J;
          local J,A=n();
          if J then
            g(l[1071]..B[l[409]][l[846]](l[1355],J,A));
          end
        end
      end);
      d(t[l[1558]],function(J)
        local B=s[87]();
        if J[l[1317]]~=B[l[128]][l[1317]][l[239]]or not u[l[1273]] then
          return;
        end
        local A,w=y[9]:GetMouseLocation(),B[l[655]][l[1587]]();
        local F=l[393];
        while true do
          local h,V=J[l[1101]],B[l[128]];
          if not(h~=V[l[1101]][l[912]]) then
            break;
          end
          h=(y[9]:GetMouseLocation());
          V=h-A;
          if B[l[35]][l[1575]](V[l[636]])>=l[59] then
            local J,k=n();
            if J then
              g(l[1371]..B[l[409]][l[846]](l[1355],J,k)..l[214]..B[l[35]][l[499]](-V[l[636]]*l[863]));
            end
            A,F=h,F+B[l[35]][l[1575]](V[l[636]]);
          else
          end
          B[l[1022]][l[153]]();
        end;
        if F<l[1158]and B[l[655]][l[1587]]()-w<l[659] then
          local J,A=n();
          if J then
            g(l[124]..B[l[409]][l[846]](l[1355],J,A)..l[842]);
          end
        end
      end);
      d(R:GetPropertyChangedSignal(l[1420]),function()
        local n=R[l[1420]];
        if n==l[1746]or not u[l[1273]] then
          return;
        end
        R[l[1420]]=l[1746];
        g(l[1595]..n);
      end);
      d(y[9][l[1558]],function(n,J)
        if not u[l[1600]]or not u[l[1273]]or not R:IsFocused() then
          return;
        end
        J=z(n[l[880]--[[readu32]]]);
        if J==l[579]or J==l[944]or J==l[367]or J==l[1460]or J==l[1436]or J==l[1492]or J==l[701]or J==l[877] then
          g(l[1556]..J);
        end
      end);
      d(yP[l[1558]],function(z)
        local n=s[87]();
        if z[l[1317]]~=n[l[128]][l[1317]][l[1356]]and z[l[1317]]~=n[l[128]][l[1317]][l[239]] then
          return;
        end
        local J=JP;
        if J then
          return;
        end
        JP=l[383];
        O(l[229]);
        local B,A=y[9]:GetMouseLocation(),e(o);
        local w,F,h=A[l[1437]],A[l[636]],(n[l[964]][l[227]]and n[l[964]][l[227]][l[952]]or n[l[1689]][l[772]](l[1248],l[1704]))/y[29];
        P(yP,H,{[l[2]]=l[393],[l[936]]=C[l[1095]]});
        while true do
          J=JP and(y[9]:IsMouseButtonPressed(n[l[128]][l[1317]][l[1356]])or z[l[1101]]~=n[l[128]][l[1101]][l[912]]);
          if not J then
            break;
          end
          A=(y[9]:GetMouseLocation()-B)/y[29];
          o[l[1639]]=n[l[1459]][l[588]](n[l[35]][l[819]](w+A[l[1437]],Y[l[457]][l[1437]],n[l[35]][l[850]](Y[l[457]][l[1437]],h[l[1437]]-l[829])),n[l[35]][l[819]](F+A[l[636]],Y[l[457]][l[636]],n[l[35]][l[850]](Y[l[457]][l[636]],h[l[636]]-l[829])));
          n[l[1022]][l[153]]();
        end;
        JP=l[1329];
        O(l[715]);
        P(yP,H,{[l[2]]=l[323],[l[936]]=C[l[1379]]});
        i();
      end);
      d(yP[l[412]],function(z)
        local n=s[87]();
        local J=z[l[1317]]==n[l[128]][l[1317]][l[1356]]or z[l[1317]]==n[l[128]][l[1317]][l[239]];
        if J then
          JP=l[1329];
        end
      end);
      d(y[10][l[756]],function()
        local z=s[87]();
        if not u[l[1600]] then
          return;
        end
        local n=z[l[655]][l[1587]]();
        z=n-HP;
        if z<Y[l[871]] then
          return;
        end
        HP=n;
        n=not sP;
        if n then
          LP();
        else
          z=JP;
          if not z then
            i();
          end
        end
      end);
      jP(o);
      r,p=o:GetDescendants();
      for z,z in y[3],r,p do
        jP(z);
      end;
      CP(l[229]);
      _(T,o,l[1209]);
      j[l[1346]][l[968]](y[18][l[1438]],u);
      return u;
    end
    y[600]=l[1116];
    y[18][y[600]]=G;
    local z;
    local function T(n)
      n=z;
      if n then
        local n=z;
        n[l[794]]();
        z=nil;
      end
    end
    y[601]=l[742];
    y[18][y[601]]=T;
    local function T(n,J)
      local G={};
      n=s[87]();
      J=n[l[40]](J)==l[1346]and J or{};
      local Y,j=n[l[40]](J[l[1577]])==l[1346]and J[l[1577]]or{},{};
      for C,C in y[5](n[l[40]](J[l[61]])==l[1346]and J[l[61]]or{})do
        if n[l[40]](C)==l[1346]and#j<l[930] then
          j[#j+l[229]]=C;
        end
      end;
      if #j==l[393]and n[l[40]](J[l[1223]])==l[1346] then
        j[l[229]]=J[l[1223]];
      end
      local C={};
      local function p(r,o)
        local B=r:Connect(o);
        C[#C+l[229]]=B;
        return B;
      end
      y[18]:closepopup();
      if #Y==l[393]and#j==l[393]or not y[18][l[630]] then
        return;
      end
      local r=x[l[160]];
      local o=r/y[29];
      local B,A,w=n[l[35]][l[819]](n[l[35]][l[499]](n[l[1382]](J[l[597]])or l[450]),l[827],n[l[35]][l[850]](n[l[35]][l[499]](o[l[1437]])-l[1655],l[827])),l[913],#Y*l[941]+l[558]+#j*l[1506];
      local F,h=n[l[35]][l[819]](A+w,l[1167],n[l[35]][l[850]](n[l[35]][l[499]](o[l[636]])-l[1655],l[1167])),y[9]:GetMouseLocation();
      o,A=n[l[35]][l[499]](n[l[1382]](J[l[898]])or h[l[1437]]),n[l[35]][l[499]](n[l[1382]](J[l[504]])or h[l[636]]);
      local V=n[l[35]][l[819]](o,l[930],n[l[35]][l[850]](r[l[1437]]-B*y[29]-l[930],l[930]));
      local _=n[l[35]][l[819]](A,l[930],n[l[35]][l[850]](r[l[636]]-F*y[29]-l[930],l[930]));
      local r=nP and a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](V,_),[l[1639]]=n[l[1459]][l[588]](B,F),[l[1535]]=c[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1649]},x)or nil;
      local k=r and a(l[1198],{[l[1630]]=c[l[641]],[l[258]]=n[l[740]][l[772]](l[393],l[558]),[l[1485]]=n[l[1459]][l[588]](l[393],l[786]),[l[1326]]=n[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},r)or nil;
      if r then
        D(r,l[1092]);
        Z(r);
      end
      local i=a(l[1751],{[l[1150]]=J[l[572]]or f(),[l[948]]=n[l[1459]][l[588]](V,_),[l[1639]]=n[l[1459]][l[588]](B,F),[l[1535]]=c[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[711]]=l[1651]},x);
      D(i,l[1092]);
      Z(i);
      F,B=l[1622],{[l[500]]=l[117]};
      B[l[1630]]=n[l[1262]][l[772]]({n[l[527]][l[772]](l[393],n[l[360]][l[772]](l[229],l[229],l[229])),n[l[527]][l[772]](l[229],n[l[360]][l[353]](l[291],l[291],l[920]))});
      a(F,B,i);
      o=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[487]},i);
      D(o,l[1092]);
      a(l[734],{[l[1630]]=c[l[966]],[l[747]]=l[1419]},o);
      h=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[917]},i);
      A=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[917]},h);
      D(A,l[1092]);
      a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[393],l[229]),[l[948]]=n[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[917]},A);
      local Z=a;
      local E=l[859];
      local Q={};
      Q[l[1150]]=f();
      Q[l[1016]]=n[l[1689]][l[772]](l[393],l[659]);
      Q[l[948]]=n[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
      Q[l[1639]]=n[l[1459]][l[588]](l[310],l[310]);
      Q[l[1646]]=l[229];
      Q[l[1451]]=y[30](J[l[13]]or l[1456]);
      Q[l[936]]=c[l[1379]];
      Q[l[2]]=l[1431];
      Q[l[1557]]=n[l[128]][l[1557]][l[220]];
      Q[l[711]]=l[1237];
      Z(E,Q,A);
      a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[688],l[393]),[l[1639]]=n[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](J[l[1434]]or l[1746]),[l[510]]=c[l[1095]],[l[723]]=l[750],[l[164]]=n[l[128]][l[164]][l[1021]],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1237]},A);
      K(a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=c[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1237]},h),l[393],{n[l[677]][l[772]](l[393],l[229]),n[l[677]][l[772]](l[841],l[874]),n[l[677]][l[772]](l[659],l[393]),n[l[677]][l[772]](l[804],l[874]),n[l[677]][l[772]](l[229],l[229])});
      local Z=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=n[l[1459]][l[588]](l[393],l[913]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=n[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=n[l[128]][l[62]][l[636]],[l[711]]=l[917]},h);
      local E=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=n[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[917]},Z);
      A,o=l[755],{[l[407]]=n[l[128]][l[407]][l[537]]};
      o[l[536]]=n[l[740]][l[772]](l[393],l[229]);
      a(A,o,E);
      a(l[1359],{[l[299]]=n[l[740]][l[772]](l[393],l[303]),[l[645]]=n[l[740]][l[772]](l[393],l[930]),[l[1612]]=n[l[740]][l[772]](l[393],l[303]),[l[517]]=n[l[740]][l[772]](l[393],l[303])},E);
      local A={[l[630]]=l[383],[l[1594]--[[__index]]]=i,[l[89]]={},[l[61]]={}};
      local function Q(t)
        local R=i[l[1569]];
        b(i,l[304],q,function(g)
          local u,sP=s[87](),R+(l[229]-R)*g;
          i[l[1569]]=sP;
          i[l[948]]=u[l[1459]][l[588]](V,_+u[l[35]][l[499]](l[1092]*g+l[659]));
          if r then
            r[l[1646]]=sP;
            r[l[948]]=i[l[948]];
            k[l[747]]=l[330]+l[1419]*sP;
          end
          if g>=l[229] then
            i[l[1324]]=l[1329];
            if r then
              r[l[1324]]=l[1329];
            end
            if t then
              t();
            end
          end
        end);
      end
      local function t()
        local R=s[87]();
        if not A[l[630]] then
          return;
        end
        A[l[630]]=l[1329];
        for g,g in y[5](A[l[89]])do
          g();
        end;
        for g,g in y[5](C)do
          g:Disconnect();
        end;
        R[l[1346]][l[267]](C);
        if A[l[1731]] then
          R[l[1146]](function()
            A[l[1731]]:Disconnect();
          end);
          A[l[1731]]=nil;
        end
        if A[l[932]] then
          R[l[1146]](function()
            A[l[932]]:Disconnect();
          end);
          A[l[932]]=nil;
        end
        if A[l[1052]] then
          R[l[1146]](function()
            A[l[1052]]:Disconnect();
          end);
          A[l[1052]]=nil;
        end
        if not y[18][l[630]]or not i[l[382]] then
          i:Destroy();
          if r then
            r:Destroy();
          end
          return;
        end
        Q(function()
          local C=s[87]();
          C[l[1146]](function()
            i:Destroy();
          end);
          if r then
            C[l[1146]](function()
              r:Destroy();
            end);
          end
        end);
      end
      A[l[794]]=t;
      p(i[l[956]],A[l[794]]);
      o,t,h=l[229],#Y,l[229];
      for C=o,t,h do
        local h=Y[C];
        local Q=h[l[404]]~=nil;
        local t=h[l[404]]==l[383];
        B=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=C,[l[711]]=l[1237]},E);
        local C,R,g=Q and a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[393],l[659]),[l[948]]=n[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=n[l[1459]][l[588]](l[829],l[829]),[l[1535]]=c[l[98]],[l[1646]]=t and l[1296]or l[229],[l[1418]]=l[393],[l[711]]=l[1001]},B)or nil;
        if C then
          D(C,l[786]);
          R=a(l[734],{[l[1630]]=c[l[966]],[l[747]]=t and l[229]or l[874]},C);
          G[2]=a;
          G[3]=l[859];
          G[1]={};
          G[1][l[1150]]=f();
          G[1][l[1016]]=n[l[1689]][l[772]](l[659],l[659]);
          G[1][l[948]]=n[l[1459]][l[1368]](l[659],l[659]);
          G[1][l[1639]]=n[l[1459]][l[588]](t and l[310]or l[1158],t and l[310]or l[1158]);
          G[1][l[1646]]=l[229];
          G[1][l[1451]]=y[30](l[1411]);
          G[1][l[936]]=c[l[641]];
          G[1][l[2]]=t and l[393]or l[229];
          G[1][l[1557]]=n[l[128]][l[1557]][l[220]];
          G[1][l[711]]=l[1376];
          g=(G[2](G[3],G[1],C));
        else
        end
        G[7]=not Q;
        if G[7] then
          G[5]=a;
          G[6]=l[859];
          G[4]={};
          G[4][l[1150]]=f();
          G[4][l[1016]]=n[l[1689]][l[772]](l[393],l[659]);
          G[4][l[948]]=n[l[1459]][l[772]](l[393],l[1092],l[659],l[393]);
          G[4][l[1639]]=n[l[1459]][l[588]](l[750],l[750]);
          G[4][l[1646]]=l[229];
          G[4][l[1451]]=y[30](h[l[13]]or l[234]);
          G[4][l[936]]=c[l[1379]];
          G[4][l[2]]=l[1431];
          G[4][l[1557]]=n[l[128]][l[1557]][l[220]];
          G[4][l[711]]=l[1001];
          G[7]=G[5](G[6],G[4],B);
        end
        local u=G[7]or nil;
        local sP=a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[910],l[393]),[l[1639]]=n[l[1459]][l[772]](l[229],l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](h[l[572]]or l[1746]),[l[510]]=t and c[l[1095]]or c[l[1379]],[l[723]]=l[750],[l[916]]=t and l[393]or l[615],[l[164]]=n[l[128]][l[164]][l[1021]],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1001]},B);
        local LP,yP=a(l[1742],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[838]},B),l[1329];
        local function B()
          local zP=s[87]();
          if C then
            local JP,HP,fP={},l[1646],t and l[1296]or(yP and l[804]or l[229]);
            JP[HP]=fP;
            P(C,H,JP);
            HP,fP,JP={},l[747],t and l[229]or(yP and l[1296]or l[874]);
            HP[fP]=JP;
            P(R,H,HP);
            P(g,H,{[l[2]]=t and l[393]or l[229],[l[1639]]=zP[l[1459]][l[588]](t and l[310]or l[1158],t and l[310]or l[1158])});
          end
          if u then
            P(u,H,{[l[2]]=yP and l[393]or l[1431],[l[936]]=yP and c[l[1095]]or c[l[1379]]});
          end
          P(sP,H,{[l[916]]=(t or yP)and l[393]or l[615],[l[510]]=(t or yP)and c[l[1095]]or c[l[1379]]});
        end
        p(LP[l[1538]],function()
          yP=l[383];
          B();
        end);
        p(LP[l[1628]],function()
          yP=l[1329];
          B();
        end);
        p(LP[l[445]],function()
          local C,R,g=s[87](),h[l[1617]],not Q;
          if g then
            y[18]:chime(l[1320]);
            local Q=z==A;
            if Q then
              z=nil;
            end
            A[l[794]]();
            if C[l[40]](R)==l[1712] then
              C[l[1022]][l[281]](R,h);
            end
            return;
          end
          y[18]:chime(t and l[676]or l[404]);
          g=nil;
          if C[l[40]](R)==l[1712] then
            local Q,u=C[l[1146]](R,h);
            g=if Q then u else g;
          else
          end
          t=if C[l[40]](g)==l[268]then g else not t;
          h[l[404]]=t;
          if not A[l[630]] then
            return;
          end
          B();
        end);
      end;
      p(E:GetPropertyChangedSignal(l[160]),function()
        local C=s[87]();
        Z[l[392]]=C[l[1459]][l[588]](l[393],C[l[35]][l[499]](e(E)[l[636]]+l[659]));
      end);
      for e,C in y[5](j)do
        local j=n[l[1382]](C[l[457]])or l[393];
        local B=n[l[1382]](C[l[850]])or l[856];
        local h=n[l[1382]](C[l[109]])or l[229];
        if h~=h or h<=l[393]or h==l[94] then
          h=l[229];
        else
        end
        local Q=n[l[35]][l[819]](n[l[35]][l[499]](n[l[1382]](C[l[435]])or l[393]),l[393],l[786]);
        local t=n[l[35]][l[819]](n[l[1382]](C[l[1019]])or j,j,B);
        F=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[520]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=#Y+e,[l[711]]=l[1237]},E);
        a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[303],l[229]),[l[1639]]=n[l[1459]][l[772]](l[229],l[108],l[393],l[829]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](C[l[572]]or l[1096]),[l[510]]=c[l[1379]],[l[723]]=l[310],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1001]},F);
        local Y=a(l[1070],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[229],l[393]),[l[948]]=n[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=n[l[1459]][l[588]](l[205],l[829]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[510]]=c[l[1095]],[l[723]]=l[310],[l[1634]]=n[l[128]][l[1634]][l[877]],[l[711]]=l[1001]},F);
        local E=a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[303],l[1660]),[l[1639]]=n[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[1001]},F);
        D(E,l[786]);
        local R=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=c[l[98]],[l[1418]]=l[393],[l[711]]=l[1376]},E);
        D(R,l[786]);
        local g,u,sP=a(l[1742],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[393],l[352]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[1707]),[l[1646]]=l[229],[l[2]]=l[229],[l[43]]=l[383],[l[711]]=l[838]},F),l[1329];
        local function LP()
          local yP=u;
          if yP then
            u=l[1329];
            O(l[715]);
          end
          sP=nil;
        end
        A[l[89]][#A[l[89]]+l[229]]=LP;
        local function yP()
          local zP,JP=s[87](),B-j;
          local HP,fP,aP,dP=JP>l[393]and(t-j)/JP or l[393],l[1420],Q>l[393]and zP[l[409]][l[846]](l[1213]..Q..l[347],t);
          if aP then
            dP=aP;
          else
            local JP,aP,PP=zP[l[1130]],zP[l[35]][l[499]],t;
            dP=(JP(aP(PP+l[659])));
          end
          Y[fP]=dP..zP[l[1130]](C[l[26]]or l[1387]);
          R[l[1639]]=zP[l[1459]][l[772]](HP,zP[l[35]][l[499]](l[1158]*(l[229]-HP)+l[659]),l[229],l[393]);
        end
        local function Y(R)
          local zP=s[87]();
          if not A[l[630]] then
            return;
          end
          local JP,HP=E[l[81]],E[l[160]];
          if HP[l[1437]]<=l[393] then
            return;
          end
          local fP=j+(B-j)*zP[l[35]][l[819]]((R-JP[l[1437]])/HP[l[1437]],l[393],l[229]);
          R=zP[l[35]][l[819]](j+zP[l[35]][l[499]]((fP-j)/h+l[659])*h,j,B);
          if Q>l[393] then
            fP=l[730]^Q;
            R=zP[l[35]][l[499]](R*fP+l[659])/fP;
          else
          end
          JP=t;
          if R==JP then
            return;
          end
          t=R;
          yP();
          HP=zP[l[40]](C[l[1617]])==l[1712];
          if HP then
            I(function(j)
              if A[l[630]] then
                C[l[1617]](j);
              end
            end,t);
          end
        end
        local function j(B)
          return v(B)[l[1437]];
        end
        p(g[l[1558]],function(B)
          local h,I=s[87](),not A[l[630]]or u;
          if I then
            return;
          end
          if B[l[1317]]~=h[l[128]][l[1317]][l[1356]]and B[l[1317]]~=h[l[128]][l[1317]][l[239]] then
            return;
          end
          u,sP=l[383],B;
          O(l[229]);
          local I,Q=h[l[1146]](Y,j(B));
          if not I then
            LP();
            h[l[972]](l[125]..h[l[1130]](Q));
          end
        end);
        p(y[9][l[233]],function(B)
          local h,I=s[87](),not A[l[630]]or not u;
          if I then
            return;
          end
          if B[l[1317]]~=h[l[128]][l[1317]][l[765]]and B[l[1317]]~=h[l[128]][l[1317]][l[239]] then
            return;
          end
          I=B[l[1317]]==h[l[128]][l[1317]][l[239]]and B~=sP;
          if I then
            return;
          end
          I,B=h[l[1146]](Y,j(sP));
          if not I then
            LP();
            h[l[972]](l[125]..h[l[1130]](B));
          end
        end);
        p(y[9][l[412]],function(Y)
          local j=s[87]();
          local B=Y[l[1317]]==j[l[128]][l[1317]][l[1356]]or Y[l[1317]]==j[l[128]][l[1317]][l[239]]and Y==sP;
          if B then
            LP();
          end
        end);
        p(g[l[956]],LP);
        A[l[61]][e]={[l[572]]=C[l[572]],[l[1681]]=g,[l[695]]=E,[l[266]]=F};
        yP();
      end;
      Z[l[392]]=n[l[1459]][l[588]](l[393],w);
      local function Z()
        i[l[1324]]=l[383];
        if r then
          r[l[1324]]=l[383];
        end
        b(i,l[894],N,function(Y)
          local e,j=s[87](),l[229]-Y;
          i[l[1569]]=j;
          i[l[948]]=e[l[1459]][l[588]](V,_+e[l[35]][l[499]](l[1092]*(l[229]-Y)+l[659]));
          if r then
            r[l[1646]]=j;
            r[l[948]]=i[l[948]];
            k[l[747]]=l[330]+l[1419]*j;
          end
        end);
      end
      local Y=n[l[655]][l[1587]]();
      local function e(j)
        local C,r=s[87](),j[l[1317]];
        if not A[l[630]]or C[l[655]][l[1587]]()-Y<l[874] then
          return l[1329];
        end
        if r~=C[l[128]][l[1317]][l[1356]]and r~=C[l[128]][l[1317]][l[321]--[[-1]]]and r~=C[l[128]][l[1317]][l[239]]and r~=C[l[128]][l[1317]][l[72]] then
          return l[1329];
        end
        if r==C[l[128]][l[1317]][l[239]] then
          local Y,C,r=v(j),i[l[81]],i[l[160]];
          return Y[l[1437]]<C[l[1437]]-l[786]or Y[l[636]]<C[l[636]]-l[786]or Y[l[1437]]>C[l[1437]]+r[l[1437]]+l[786]or Y[l[636]]>C[l[636]]+r[l[636]]+l[786];
        end
        return not W(i,l[786]);
      end
      G[8]=l[1731];
      G[9]=(p(y[9][l[1558]],function(Y)
        if not e(Y) then
          return;
        end
        Y=z==A;
        if Y then
          z=nil;
        end
        A[l[794]]();
      end));
      A[G[8]]=G[9];
      G[10]=l[932];
      G[11]=(p(y[9][l[233]],function(Y)
        local j=s[87]();
        if Y[l[1317]]~=j[l[128]][l[1317]][l[72]] then
          return;
        end
        if not e(Y) then
          return;
        end
        Y=z==A;
        if Y then
          z=nil;
        end
        A[l[794]]();
      end));
      A[G[10]]=G[11];
      o=n[l[1703]](J[l[1699]])==l[1089]and J[l[1699]]:IsA(l[957]);
      if o then
        local Y=J[l[1699]];
        local J=Y[l[81]];
        G[12]=l[1052];
        G[13]=(p(y[10][l[1119]],function()
          if not A[l[630]] then
            return;
          end
          local e=not Y[l[382]]or not Y[l[1324]]or(Y[l[81]]-J)[l[945]]>l[786];
          if e then
            local J=z==A;
            if J then
              z=nil;
            end
            A[l[794]]();
          end
        end));
        A[G[12]]=G[13];
      end
      n[l[1022]][l[281]](function()
        local n=s[87]();
        while A[l[630]]do
          local J=not y[18][l[630]]or not y[18][l[583]];
          if J then
            local J=z==A;
            if J then
              z=nil;
            end
            A[l[794]]();
            break;
          end
          n[l[1022]][l[153]](l[841]);
        end;
      end);
      z=A;
      Z();
      return A;
    end
    y[602]=l[444];
    y[18][y[602]]=T;
    local z;
    local function T(n)
      n=z;
      if n then
        local n=z;
        n[l[794]]();
        z=nil;
      end
    end
    y[603]=l[3];
    y[18][y[603]]=T;
    local function T(n,J)
      local Z={};
      n=s[87]();
      J=X(J,{[l[1434]]=l[225],[l[13]]=l[1680],[l[374]]=l[1746],[l[1095]]=l[1746],[l[1705]]=l[502],[l[596]]=l[320]--[[True]],[l[597]]=l[737],[l[1617]]=nil});
      y[18]:closeask();
      y[18]:closepopup();
      if not y[18][l[630]] then
        return nil;
      end
      local G;
      local Y=y[18][l[769]];
      for e,e in y[3],Y,nil do
        if e[l[593]]and e[l[593]][l[382]]and e[l[1600]] then
          G=e;
        else
        end
      end;
      if not G then
        return nil;
      end
      local e,j,C=n[l[35]][l[819]](n[l[35]][l[499]](n[l[1382]](J[l[597]])or l[737]),l[768],l[1166]),l[1339],a(l[1742],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[2]]=l[229],[l[711]]=l[906]},G[l[1156]]or G[l[593]]);
      local p=nP and a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[659],l[659]),[l[948]]=n[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=n[l[1459]][l[588]](e,j),[l[1535]]=c[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[726]},C)or nil;
      local r=p and a(l[1198],{[l[1630]]=c[l[641]],[l[258]]=n[l[740]][l[772]](l[393],l[1243]),[l[1485]]=n[l[1459]][l[588]](l[393],l[1158]),[l[1326]]=n[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},p)or nil;
      if p then
        D(p,l[930]);
      end
      local o=a(l[1751],{[l[1150]]=f(),[l[43]]=l[383],[l[1016]]=n[l[1689]][l[772]](l[659],l[659]),[l[948]]=n[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=n[l[1459]][l[588]](e,j),[l[1535]]=c[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[711]]=l[870]},C);
      D(o,l[930]);
      Y=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1570]},o);
      D(Y,l[930]);
      a(l[734],{[l[1630]]=c[l[966]],[l[747]]=l[1017]},Y);
      j=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[1598]},o);
      D(j,l[930]);
      a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[393],l[229]),[l[948]]=n[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[1598]},j);
      local B=a;
      local A=l[859];
      local w={};
      w[l[1150]]=f();
      w[l[1016]]=n[l[1689]][l[772]](l[393],l[659]);
      w[l[948]]=n[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
      w[l[1639]]=n[l[1459]][l[588]](l[750],l[750]);
      w[l[1646]]=l[229];
      w[l[1451]]=y[30](J[l[13]]);
      w[l[936]]=c[l[1379]];
      w[l[2]]=l[986];
      w[l[1557]]=n[l[128]][l[1557]][l[220]];
      w[l[711]]=l[1375];
      B(A,w,j);
      a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=n[l[1459]][l[772]](l[229],l[207],l[229],l[393]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](J[l[1434]]),[l[510]]=c[l[1095]],[l[723]]=l[750],[l[164]]=n[l[128]][l[164]][l[1021]],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1375]},j);
      K(a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=c[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1375]},o),l[393],{n[l[677]][l[772]](l[393],l[229]),n[l[677]][l[772]](l[841],l[874]),n[l[677]][l[772]](l[659],l[393]),n[l[677]][l[772]](l[804],l[874]),n[l[677]][l[772]](l[229],l[229])});
      local B=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[730],l[726]),[l[1639]]=n[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1535]]=c[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=n[l[128]][l[437]][l[1381]],[l[592]]=c[l[1379]],[l[32]]=n[l[1130]](J[l[374]]),[l[1420]]=n[l[1130]](J[l[1095]]),[l[510]]=c[l[1095]],[l[723]]=l[750],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1598]},o);
      D(B,l[1158]);
      a(l[1359],{[l[1612]]=n[l[740]][l[772]](l[393],l[730]),[l[517]]=n[l[740]][l[772]](l[393],l[730])},B);
      local A=a(l[734],{[l[1161]]=n[l[128]][l[1161]][l[1741]],[l[1630]]=c[l[966]],[l[747]]=l[1419]},B);
      local w={[l[630]]=l[383],[l[1594]--[[__index]]]=o,[l[743]]=B};
      local function F(h,V,_,X)
        local k=s[87]();
        local v=a(l[211],{[l[1150]]=f(),[l[948]]=k[l[1459]][l[588]](h,l[694]),[l[1639]]=k[l[1459]][l[588]](V,l[688]),[l[1535]]=c[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1598]},o);
        D(v,l[1158]);
        local h=a(l[734],{[l[1630]]=c[l[966]],[l[747]]=l[1373]},v);
        local V=a(l[211],{[l[1150]]=f(),[l[1639]]=k[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=c[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1375]},v);
        D(V,l[1158]);
        K(V,l[393],{k[l[677]][l[772]](l[393],l[393]),k[l[677]][l[772]](l[1017],l[1373]),k[l[677]][l[772]](l[229],l[229])});
        local D=a(l[1070],{[l[1150]]=f(),[l[1639]]=k[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=k[l[128]][l[437]][l[1381]],[l[1420]]=k[l[1130]](_),[l[510]]=X and c[l[1095]]or c[l[1379]],[l[723]]=l[750],[l[916]]=X and l[1296]or l[986],[l[711]]=l[1697]},v);
        local K,_=a(l[1742],{[l[1150]]=f(),[l[1639]]=k[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[837]},v),l[1329];
        local function f()
          P(v,H,{[l[1646]]=_ and l[393]or l[841]});
          P(h,H,{[l[747]]=_ and l[330]or l[1373]});
          P(V,H,{[l[1646]]=_ and l[804]or l[229]});
          local a,h,k={},l[916],_ and l[393]or(X and l[1296]or l[986]);
          a[h]=k;
          a[l[510]]=(_ or X)and c[l[1095]]or c[l[1379]];
          P(D,H,a);
        end
        d(K[l[1538]],function()
          _=l[383];
          f();
        end);
        d(K[l[1628]],function()
          _=l[1329];
          f();
        end);
        return K,V;
      end
      Y=l[1158];
      j=n[l[35]][l[499]]((e-l[1707]-Y)/l[59]);
      local f,a=F(l[730],j,J[l[596]],l[1329]);
      local D,K=F(l[730]+j+Y,e-l[1707]-j-Y,J[l[1705]],l[383]);
      local function Y(e)
        o[l[1569]]=e;
        if p then
          p[l[1646]]=e;
          r[l[747]]=l[615]+l[411]*e;
        end
      end
      local function e(j)
        local p=o[l[1569]];
        b(o,l[304],q,function(q)
          Y(p+(l[229]-p)*q);
          if q>=l[229]and j then
            j();
          end
        end);
      end
      local function j()
        local q=s[87]();
        if not w[l[630]] then
          return;
        end
        w[l[630]]=l[1329];
        O(l[715]);
        if w[l[1731]] then
          q[l[1146]](function()
            w[l[1731]]:Disconnect();
          end);
          w[l[1731]]=nil;
        end
        if w[l[344]] then
          q[l[1146]](function()
            w[l[344]]:Disconnect();
          end);
          w[l[344]]=nil;
        end
        q[l[1146]](function()
          B:ReleaseFocus(l[1329]);
        end);
        local q=z==w;
        if q then
          z=nil;
        end
        e(function()
          local e=s[87]();
          e[l[1146]](function()
            C:Destroy();
          end);
        end);
      end
      w[l[794]]=j;
      local function e()
        local j=s[87]();
        A[l[1630]]=c[l[98]];
        A[l[747]]=l[1209];
        P(A,H,{[l[1630]]=c[l[966]],[l[747]]=l[1419]});
        b(B,l[304],N,function(q)
          local p=s[87]();
          B[l[948]]=p[l[1459]][l[588]](l[730]+p[l[35]][l[499]](p[l[35]][l[1631]](q*l[1205]*l[863])*l[786]*(l[229]-q)+l[659]),l[726]);
        end);
        j[l[1022]][l[1061]](function()
          if w[l[630]] then
            B:CaptureFocus();
          end
        end);
      end
      local function j()
        local q=s[87]();
        if not w[l[630]] then
          return;
        end
        K[l[1646]]=l[1567];
        P(K,H,{[l[1646]]=l[229]});
        y[18]:chime(l[1320]);
        local p=q[l[409]][l[56]](B[l[1420]],l[381])or l[1746];
        if p==l[1746] then
          e();
          return;
        end
        if q[l[40]](J[l[1617]])==l[1712] then
          local r,K=q[l[1146]](J[l[1617]],p);
          if r and K==l[1329] then
            e();
            return;
          end
        end
        w[l[794]]();
      end
      local function J()
        if not w[l[630]] then
          return;
        end
        a[l[1646]]=l[1567];
        P(a,H,{[l[1646]]=l[229]});
        y[18]:chime(l[1320]);
        w[l[794]]();
      end
      d(D[l[445]],j);
      d(f[l[445]],J);
      d(C[l[445]],function()
        if W(o,l[59]) then
          return;
        end
        J();
      end);
      d(B[l[505]],function()
        P(A,H,{[l[747]]=l[1431]});
      end);
      d(B[l[722]],function(f)
        P(A,H,{[l[747]]=l[1419]});
        if f then
          j();
        end
      end);
      Z[1]=l[1731];
      Z[2]=(d(y[9][l[1558]],function(H)
        local f=s[87]();
        if not w[l[630]]or H[l[880]--[[readu32]]]~=f[l[128]][l[880]--[[readu32]]][l[1739]] then
          return;
        end
        J();
      end));
      w[Z[1]]=Z[2];
      w[l[344]]=G[l[1156]]and d(G[l[1156]]:GetPropertyChangedSignal(l[1324]),function()
        if not G[l[1156]][l[1324]] then
          w[l[794]]();
        end
      end)or nil;
      O(l[229]);
      Y(l[229]);
      b(o,l[894],N,function(J)
        Y(l[229]-J);
      end);
      n[l[1022]][l[1061]](function()
        if w[l[630]] then
          B:CaptureFocus();
        end
      end);
      z=w;
      return w;
    end
    y[604]=l[1644];
    y[18][y[604]]=T;
    local function z(T)
      local T={};
      local n=s[87]();
      if x then
        n[l[1146]](function()
          x[l[405]]=l[1329];
        end);
      end
      n[l[1146]](y[18][l[3]],y[18]);
      n[l[1146]](y[18][l[742]],y[18]);
      local J,H=n[l[1346]][l[822]](y[18][l[1438]]);
      for f,f in y[3],J,H do
        n[l[1146]](function()
          f:kill();
        end);
      end;
      n[l[1346]][l[267]](y[18][l[1438]]);
      T[1]=y[18];
      T[2]=l[630];
      T[3]=l[1329];
      T[1][T[2]]=T[3];
      T[4]=y[18];
      T[5]=l[1478];
      T[6]=(y[18][l[1478]]or l[393])+l[229];
      T[4][T[5]]=T[6];
      T[7]=y[18];
      T[8]=l[1334];
      T[9]=l[1329];
      T[7][T[8]]=T[9];
      T[10]=y[18];
      T[11]=l[921];
      T[12]=l[1329];
      T[10][T[11]]=T[12];
      S=l[393];
      T[13]=y[18];
      T[14]=l[1429];
      T[15]=l[1329];
      T[13][T[14]]=T[15];
      T[16]=y[18];
      T[17]=l[583];
      T[18]=l[1329];
      T[16][T[17]]=T[18];
      n[l[1146]](TP);
      n[l[1146]](lP,nil);
      n[l[1146]](U);
      n[l[1346]][l[267]](M);
      n[l[1346]][l[267]](m);
      n[l[1346]][l[267]](y[18][l[1294]]);
      n[l[1346]][l[267]](y[18][l[752]]);
      for T,T in y[3],y[18][l[673]],nil do
        n[l[1146]](function()
          T:Disconnect();
        end);
      end;
      n[l[1346]][l[267]](y[18][l[673]]);
      n[l[1346]][l[267]](y[18][l[769]]);
      if x then
        n[l[1146]](function()
          x:Destroy();
        end);
      end
    end
    y[605]=l[332];
    y[18][y[605]]=z;
    y[606]=l[1469];
    y[607]=y[1][y[606]]();
    y[608]=l[670];
    y[607][y[608]]=y[18];
    return y[18];
  end
  local function y(...)
    local z,T,n=s[87](),...;
    T=if z[l[40]](T)~=l[409]and z[l[40]](T)~=l[1712]and z[l[1216]]and z[l[1496]]and z[l[1496]](l[575]--[[unpack]])then z[l[1216]](l[575]--[[unpack]])else T;
    local J;
    if z[l[40]](T)==l[1712] then
      J=T(n);
    else
      z[l[817]](z[l[40]](T)==l[409]and T~=l[1746],l[1589]);
      J=z[l[817]](z[l[671]](T,l[402]))(n);
    end
    z[l[817]](z[l[40]](J)==l[1346]and z[l[40]](J[l[1423]])==l[1712],l[1562]);
    local T={[l[831]]=J,[l[122]]=J[l[278]],[l[326]]=J[l[131]][l[98]],[l[350]]=J[l[131]][l[641]]};
    local n=z[l[1346]][l[822]](J[l[131]]);
    local H=J[l[1225]];
    local function f(a,d)
      H(a,d);
      T[l[326]]=a[l[131]][l[98]];
      T[l[350]]=a[l[131]][l[641]];
    end
    J[l[1225]]=f;
    local H=J[l[1328]];
    local function a(d,P)
      local Z=s[87]();
      if Z[l[40]](P)==l[1346]and Z[l[40]](P[l[516]])==l[1346]and P[l[516]][l[185]]==l[833]--[[wait]] then
        P=Z[l[1346]][l[822]](P);
        P[l[516]]=Z[l[1346]][l[822]](P[l[516]]);
        P[l[516]][l[185]]=l[954];
      else
      end
      if Z[l[40]](P)~=l[1346]or Z[l[40]](P[l[516]])~=l[1346]or Z[l[40]](P[l[131]])~=l[1346] then
        return H(d,P);
      end
      local G;
      for Y,e in Z[l[534]](P[l[131]])do
        local j=l[1321]..Y;
        if d[l[1294]][j]and P[l[516]][j]==nil then
          if not G then
            G=Z[l[1346]][l[822]](P);
            G[l[516]]=Z[l[1346]][l[822]](P[l[516]]);
          else
          end
          G[l[516]][j]=e;
        else
        end
      end;
      return H(d,G or P);
    end
    J[l[1328]]=a;
    T[l[460]]=J[l[560]];
    T[l[1573]]=l[1329];
    T[l[724]]=l[1329];
    T[l[107]]={};
    T[l[1149]]={};
    T[l[414]]=function()
    end;
    T[l[501]]=z[l[437]][l[466]](z[l[128]][l[437]][l[807]]);
    T[l[316]]=z[l[437]][l[466]](z[l[128]][l[437]][l[1381]]);
    T[l[826]]=J[l[388]]and l[383]or l[1329];
    T[l[1147]]=T[l[826]];
    local function H(d)
      if d==l[1747] then
        return l[1747];
      end
      return d==l[1316]and l[1316]or l[356];
    end
    local function d()
      local P,Z=s[87](),{};
      for G=l[229],l[310],l[229]do
        Z[#Z+l[229]]=P[l[409]][l[189]](P[l[35]][l[1298]](l[229],l[1092]));
      end;
      return P[l[1346]][l[978]](Z);
    end
    T[l[1416]]=d;
    local function P(Z,Z)
      local G=s[87]();
      if not J[l[630]] then
        Z:Disconnect();
        return Z;
      end
      if #T[l[107]]>l[633] then
        for Y=#T[l[107]],l[229],l[715]do
          if not T[l[107]][Y][l[49]] then
            G[l[1346]][l[1357]](T[l[107]],Y);
          end
        end;
      end
      G[l[1346]][l[968]](T[l[107]],Z);
      return Z;
    end
    T[l[1657]]=P;
    local Z={};
    local function G(Y,e,j)
      local C=s[87]();
      Z[e]=Z[e]or{};
      C[l[1346]][l[968]](Z[e],j);
      return Y:AddSignal(j);
    end
    T[l[1484]]=G;
    d,f=z[l[1458]],l[793];
    z,a,P=d:GetService(f),l[1684],function(f)
      local d=s[87]();
      for G,G in d[l[1471]](Z[f]or{})do
        G:Disconnect();
      end;
      Z[f]=nil;
    end;
    T:AddSignal(z[a]:Connect(P));
    T[l[1700]]=l[1348];
    local function z(f)
      return{[l[772]]=function(f)
        f=f or{};
        local a,d=J,{[l[1434]]=f[l[1449]]or T[l[1700]],[l[1095]]=f[l[342]]or l[1746],[l[13]]=T[l[810]](f[l[79]]or l[531]),[l[440]]=f[l[1415]]or l[303]};
        return a:notify(d);
      end};
    end
    T[l[88]]=z;
    local function z(f)
      return{[l[772]]=function(f,a,d,P)
        local G=s[87]();
        J:notify({[l[1434]]=G[l[1130]](a or l[1746]),[l[13]]=T[l[810]](f or l[1177]),[l[440]]=d or l[786],[l[73]]=G[l[1703]](P)==l[360]and P or nil});
      end};
    end
    T[l[1668]]=z;
    local z={[l[309]]=l[606]--[[readu16]],[l[1275]]=l[515],[l[1120]]=l[515],[l[228]]=l[619],[l[812]]=l[1169],[l[1638]]=l[1169],[l[102]]=l[1231],[l[1220]]=l[1715],[l[855]]=l[1338],[l[1162]]=l[1338],[l[1483]]=l[515],[l[474]]=l[515],[l[519]]=l[606]--[[readu16]],[l[449]]=l[515],[l[1039]]=l[515],[l[1559]]=l[1231],[l[1196]]=l[234],[l[971]]=l[1411],[l[254]]=l[234],[l[1176]]=l[898],[l[143]]=l[1153],[l[1208]]=l[1547],[l[346]]=l[975],[l[1180]]=l[1177],[l[1013]]=l[669],[l[203]]=l[317],[l[1578]]=l[1447],[l[522]]=l[1203],[l[1210]]=l[118],[l[1733]]=l[118],[l[587]]=l[68],[l[1139]]=l[1206],[l[1134]]=l[4],[l[1186]]=l[1349],[l[622]]=l[1349],[l[977]]=l[478],[l[1713]]=l[898],[l[1414]]=l[898],[l[290]]=l[703],[l[1064]]=l[1010],[l[550]]=l[453],[l[709]]=l[370],[l[1291]]=l[370],[l[22]]=l[607],[l[678]]=l[1256],[l[577]]=l[898],[l[48]]=l[1411],[l[997]]=l[898],[l[1624]]=l[898],[l[1636]]=l[1456],[l[935]]=l[1716],[l[7]]=l[905]};
    local function f(a)
      local d=s[87]();
      local P=d[l[409]][l[345]](d[l[1130]](a or l[1746])):gsub(l[1027],l[1746]);
      if J[l[567]--[[info]]][P] then
        return P;
      end
      a=z[P];
      if a and J[l[567]--[[info]]][a] then
        return a;
      end
      return P;
    end
    T[l[810]]=f;
    local function z(f,a)
      local d=s[87]();
      if d[l[1703]](f)~=l[1089] then
        return;
      end
      local P=J[l[567]--[[info]]][T[l[810]](a)];
      if not P then
        f[l[1420]]=l[1746];
        return;
      end
      f[l[1420]]=l[1746];
      a=f:FindFirstChild(l[79]);
      if not a then
        a=d[l[1089]][l[772]](l[859]);
        a[l[1150]]=l[79];
        a[l[1646]]=l[229];
        a[l[1016]]=d[l[1689]][l[772]](l[659],l[659]);
        a[l[948]]=d[l[1459]][l[1368]](l[659],l[659]);
        a[l[1639]]=d[l[1459]][l[1368]](l[731],l[731]);
        a[l[1557]]=d[l[128]][l[1557]][l[220]];
        a[l[382]]=f;
      else
      end
      a[l[1451]]=l[1440]..P;
      a[l[936]]=f[l[510]];
      a[l[711]]=f[l[711]];
    end
    T[l[764]]=z;
    local function z(f)
      local a=s[87]();
      a[l[1146]](function()
        J:setwatermark(f and l[383]or l[1329]);
      end);
    end
    T[l[1665]]=z;
    local function z(f)
      local a=s[87]();
      for d,d in a[l[1471]](J[l[278]]:GetDescendants())do
        if d:IsA(l[1070])and d[l[1420]]==l[1397] then
          d[l[1420]]=a[l[1130]](f or l[1746]);
          return l[383];
        end
      end;
      return l[1329];
    end
    T[l[1272]]=z;
    local function z(f)
      local a=s[87]();
      a[l[1146]](function()
        J:sethotkeys(f and l[383]or l[1329]);
      end);
    end
    T[l[864]]=z;
    local function z(f)
      local a=s[87]();
      for d,d in a[l[1471]](J[l[278]]:GetChildren())do
        if d:IsA(l[1751])and d[l[711]]==l[104]and d[l[1347]]==a[l[128]][l[1347]][l[1613]] then
          if d[l[1016]][l[1437]]>l[659]==f then
            return d;
          end
        end
      end;
      return nil;
    end
    local function f(a)
      a=s[87]();
      for d,d in a[l[534]](Z)do
        for P,P in a[l[1471]](d)do
          P:Disconnect();
        end;
      end;
      a[l[1346]][l[267]](Z);
      for d,d in a[l[1471]](T[l[107]])do
        a[l[1146]](function()
          d:Disconnect();
        end);
      end;
      a[l[1346]][l[267]](T[l[107]]);
      a[l[1146]](function()
        J:unload();
      end);
    end
    T[l[790]]=f;
    T[l[790]]=T[l[790]];
    local function f(a)
      local d=s[87]();
      return d[l[1488]](a,{[l[533]]=function(a,d)
        a=s[87]();
        if a[l[40]](d)~=l[409] then
          return nil;
        end
        return function()
        end;
      end});
    end
    local function a(d,P)
      local Z=s[87]();
      if Z[l[40]](d)~=l[409]or d==l[1746] then
        return P;
      end
      T[l[1149]][d]=P;
      return P;
    end
    local d=J[l[567]--[[info]]][l[1456]]and l[1440]..J[l[567]--[[info]]][l[1456]]or nil;
    local function P(Z)
      local G,Y=s[87](),Z and Z[l[266]];
      if not d or G[l[1703]](Y)~=l[1089] then
        return nil;
      end
      for Z,Z in G[l[1471]](Y:GetChildren())do
        if (Z:IsA(l[1742])or Z:IsA(l[859]))and Z[l[1451]]==d then
          return Z;
        end
      end;
      return nil;
    end
    local function d(Z,G)
      local Y,e=s[87](),Z and Z[l[266]];
      if Y[l[1703]](e)~=l[1089] then
        return Z;
      end
      local j,C;
      for N,N in Y[l[1471]](e:GetChildren())do
        if N:IsA(l[1070])and not j then
          j=N;
        else
          C=if N:IsA(l[211])and N[l[656]]then N else C;
        end
      end;
      if G then
        if j then
          j[l[1324]]=l[1329];
        end
        if C then
          C[l[1639]]=Y[l[1459]][l[772]](l[229],l[1026],l[393],l[1243]);
        end
        return Z;
      end
      if j then
        j[l[510]]=J[l[131]][l[1095]];
        j[l[916]]=l[841];
        G=j[l[993]][l[1437]];
        G=if G<=l[393]then#j[l[1420]]*l[1092]else G;
        local N=Y[l[35]][l[819]]((G+l[558])/Y[l[35]][l[850]](l[229],e[l[160]][l[1437]]),l[1431],l[1419]);
        j[l[1639]]=Y[l[1459]][l[772]](N,l[1519],l[229],l[393]);
        if C then
          C[l[1639]]=Y[l[1459]][l[772]](l[229]-N,l[66],l[393],l[1243]);
        end
      elseif C then
        C[l[1639]]=Y[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]);
      end
      return Z;
    end
    local function Z(G,Y,e)
      local j,C=s[87](),G and G[l[266]];
      if j[l[1703]](C)~=l[1089]or j[l[40]](G[l[1255]])~=l[1712] then
        return G;
      end
      local N;
      for q,q in j[l[1471]](C:GetChildren())do
        N=if q:IsA(l[1070])and q[l[1634]]==j[l[128]][l[1634]][l[877]]then q else N;
      end;
      if not N then
        return G;
      end
      local q=j[l[1089]][l[772]](l[1400]--[[-1]]);
      q[l[1150]]=l[373];
      q[l[1535]]=J[l[131]][l[1466]];
      q[l[1646]]=l[1209];
      q[l[1418]]=l[393];
      q[l[1016]]=N[l[1016]];
      q[l[948]]=N[l[948]];
      q[l[1639]]=j[l[1459]][l[588]](j[l[35]][l[850]](l[520],N[l[160]][l[1437]]+l[558]),l[829]);
      q[l[437]]=j[l[128]][l[437]][l[1381]];
      q[l[723]]=l[310];
      q[l[510]]=J[l[131]][l[1095]];
      q[l[1155]]=l[383];
      q[l[1324]]=l[1329];
      q[l[711]]=N[l[711]]+l[59];
      q[l[382]]=C;
      j[l[1089]][l[772]](l[1112],q)[l[1182]]=j[l[740]][l[772]](l[393],l[786]);
      local b=j[l[1089]][l[772]](l[192]);
      b[l[1150]]=l[1427];
      b[l[1646]]=l[229];
      b[l[1420]]=l[1746];
      b[l[1016]]=N[l[1016]];
      b[l[948]]=N[l[948]];
      b[l[1639]]=j[l[1459]][l[588]](j[l[35]][l[850]](l[520],N[l[160]][l[1437]]+l[558]),l[352]);
      b[l[711]]=N[l[711]]+l[229];
      b[l[382]]=C;
      j,C=l[445],function()
        local N=s[87]();
        q[l[1420]]=N[l[1130]](G:get());
        q[l[1324]]=l[383];
        q:CaptureFocus();
      end;
      b[j]:Connect(C);
      j,C=l[722],function()
        local N=s[87]();
        q[l[1324]]=l[1329];
        local b=N[l[1382]]((q[l[1420]]or l[1746]):match(l[198]));
        if not b then
          return;
        end
        b=if Y then N[l[35]][l[850]](Y,b)else b;
        b=if e then N[l[35]][l[457]](e,b)else b;
        G:set(b);
      end;
      q[j]:Connect(C);
      return G;
    end
    local function G(Y)
      local e=s[87]();
      local j=e[l[1382]](Y[l[485]]or Y[l[808]])or l[393];
      return j>l[393]and l[229]/l[730]^j or l[229];
    end
    local Y=l[1329];
    local function e(j,C)
      local function N(q,...)
        local b=s[87]();
        if C then
          C(q,...);
        end
        local C=T[l[414]];
        if C then
          local D=T[l[831]]and T[l[831]][l[1334]];
          b[l[1146]](C,q,j,not Y and not D);
        end
      end
      return N;
    end
    local function j(C,...)
      local N,q,b,D=s[87](),Y;
      Y,b,D=l[383],N[l[1146]](C,...);
      Y=q;
      if not b then
        N[l[279]](D,l[863]);
      end
    end
    local function Y(C,N,q)
      local b={[l[953]]=C};
      local function D(p)
        return C:get();
      end
      b[l[582]]=D;
      local function D(p,p)
        j(C[l[1255]],C,p);
      end
      b[l[1629]]=D;
      local function D(p,p)
        j(C[l[1255]],C,p);
      end
      b[l[21]]=D;
      local function j(D,p)
        D=s[87]();
        local r=D[l[40]](C)==l[1346]and D[l[713]](C,l[266]);
        if D[l[1703]](r)==l[1089] then
          r[l[1324]]=p and l[383]or l[1329];
        end
      end
      b[l[99]]=j;
      if q then
        q(b,C);
      end
      return a(N,f(b));
    end
    local function j(C,N)
      if T[l[1652]] then
        T[l[1652]]();
      end
      local q={[l[1150]]=N,[l[380]]=C};
      local b,D=l[383];
      local function p()
        local r,K=D;
        if r then
          local o=D;
          K=o[l[382]];
        else
          K=r;
        end
        if K then
          r=D;
          r[l[1324]]=l[383];
        end
      end
      q[l[1462]]=p;
      local function r(K)
        local o,c=s[87](),b;
        if c then
          b=l[1329];
          return C[l[557]],N;
        end
        c=o[l[713]](q,l[947]);
        o=c and c[l[925]];
        if o then
          p();
          return o,K;
        end
        return C[l[557]],N;
      end
      local function b(K,o)
        o=o or{};
        local c,m=r(l[405]);
        K=c:toggle({[l[572]]=m,[l[950]]=o[l[1380]]and l[383]or l[1329],[l[925]]=l[383],[l[1013]]=o[l[1315]],[l[1617]]=e(o[l[1315]],o[l[1683]])});
        q[l[947]]=K;
        D=P(K);
        c=D;
        if c then
          m=D;
          m[l[1324]]=l[1329];
        end
        return Y(K,o[l[1315]]);
      end
      q[l[733]]=b;
      local function P(b,D)
        b=s[87]();
        D=D or{};
        local K,o=r(l[1122]);
        local c=K:slider({[l[572]]=o,[l[457]]=b[l[1382]](D[l[946]])or l[393],[l[850]]=b[l[1382]](D[l[1641]])or l[856],[l[950]]=D[l[1380]],[l[109]]=G(D),[l[26]]=b[l[40]](D[l[252]])==l[409]and D[l[252]]or l[1746],[l[1013]]=D[l[1315]],[l[1617]]=e(D[l[1315]],D[l[1683]])});
        Z(c,b[l[1382]](D[l[946]])or l[393],b[l[1382]](D[l[1641]])or l[856]);
        return Y(c,D[l[1315]]);
      end
      q[l[197]]=P;
      local function P(Z,Z)
        Z=Z or{};
        local G,b=r(l[480]);
        local D=G:combo({[l[572]]=b,[l[1206]]=Z[l[1561]]or{},[l[950]]=Z[l[1380]],[l[1693]]=Z[l[660]]and l[383]or l[1329],[l[1013]]=Z[l[1315]],[l[1617]]=e(Z[l[1315]],Z[l[1683]])});
        d(D,Z[l[295]]);
        return Y(D,Z[l[1315]],function(d)
          local function Z(G,G)
            if D[l[1087]] then
              D:setlist(G);
            end
          end
          d[l[158]]=Z;
          d[l[523]]=function(d)
          end;
        end);
      end
      q[l[1481]]=P;
      local function d(P,P)
        P=P or{};
        local Z=P[l[1683]];
        local G,b=r(l[1630]);
        return Y(G:color({[l[572]]=P[l[1150]]or b,[l[950]]=P[l[1380]],[l[1013]]=P[l[1315]],[l[1617]]=e(P[l[1315]],Z and function(G)
          Z(G,P[l[747]]);
        end or nil)}),P[l[1315]]);
      end
      q[l[545]]=d;
      local function d(P,P)
        P=P or{};
        local Z,G=r(l[41]);
        return Y(Z:keybind({[l[572]]=G,[l[950]]=P[l[1380]],[l[1013]]=P[l[1315]],[l[1617]]=e(P[l[1315]],P[l[1683]])}),P[l[1315]]);
      end
      q[l[988]]=d;
      local function d(P,Z)
        P=s[87]();
        Z=Z or{};
        local G,Y=C[l[557]][l[1577]],P[l[1089]][l[772]](l[211]);
        Y[l[1150]]=T[l[1416]]();
        Y[l[1646]]=l[229];
        Y[l[1639]]=P[l[1459]][l[772]](l[229],l[393],l[393],l[658]);
        Y[l[382]]=G;
        local G=P[l[1089]][l[772]](l[1400]--[[-1]]);
        G[l[1150]]=l[766];
        G[l[1535]]=J[l[131]][l[1466]];
        G[l[1418]]=l[393];
        G[l[948]]=P[l[1459]][l[772]](l[393],l[786],l[393],l[863]);
        G[l[1639]]=P[l[1459]][l[772]](l[229],l[1519],l[393],l[1707]);
        G[l[437]]=P[l[128]][l[437]][l[807]];
        G[l[723]]=l[310];
        G[l[510]]=J[l[131]][l[1095]];
        G[l[32]]=Z[l[940]]or N;
        G[l[592]]=J[l[131]][l[1379]];
        G[l[1420]]=Z[l[1380]]or l[1746];
        G[l[1155]]=l[1329];
        G[l[382]]=Y;
        P[l[1089]][l[772]](l[1112],G)[l[1182]]=P[l[740]][l[772]](l[393],l[303]);
        local Y={[l[477]]=G};
        local N=l[1329];
        local function b(D)
          return G[l[1420]];
        end
        Y[l[582]]=b;
        local function b(D,r)
          D=s[87]();
          N=l[383];
          G[l[1420]]=D[l[1130]](r or l[1746]);
          N=l[1329];
          if Z[l[1683]]and not(J[l[1207]]and J[l[1207]][Z[l[1315]]]) then
            Z[l[1683]](G[l[1420]]);
          end
        end
        Y[l[1629]]=b;
        T:AddSignal(G:GetPropertyChangedSignal(l[1420]):Connect(function()
          local b=N or not Z[l[1683]];
          if b then
            return;
          end
          Z[l[1683]](G[l[1420]]);
        end));
        if P[l[40]](Z[l[1315]])==l[409]and Z[l[1315]]~=l[1746] then
          P[l[1146]](function()
            J:hook(Z[l[1315]],l[409],function()
              return G[l[1420]];
            end,function(P)
              Y:SetValue(P);
            end);
          end);
        end
        return a(Z[l[1315]],Y);
      end
      q[l[604]]=d;
      local function a(d)
        d=s[87]();
        local P=d[l[713]](q,l[947]);
        local Z=P and P[l[925]];
        if not Z then
          return C;
        end
        p();
        local P={[l[557]]=d[l[1488]]({[l[1577]]=C[l[557]][l[1577]]},{[l[533]]=Z}),[l[1691]]=C};
        local function d(G,G)
          return j(P,G);
        end
        P[l[1254]]=d;
        local function d(G,G)
          G=G or{};
          Z:button({[l[572]]=G[l[1150]]or l[1453],[l[13]]=G[l[79]]and T[l[810]](G[l[79]])or nil,[l[1617]]=G[l[1683]]});
          return{};
        end
        P[l[1003]]=d;
        P[l[557]]=Z;
        P[l[557]][l[1577]]=C[l[557]][l[1577]];
        return P;
      end
      q[l[1143]]=a;
      local function a(d,d)
        if q[l[1228]]and q[l[1228]][l[1255]] then
          q[l[1228]]:set(d);
        end
      end
      q[l[1014]]=a;
      return f(q);
    end
    local function a(d)
      local P={[l[557]]=d,[l[204]]=d[l[1577]],[l[1508]]=d[l[1577]]};
      local function Z(G,Y)
        local C,N=s[87](),d[l[675]];
        G=C[l[1703]](N)==l[1089]and N[l[382]]or nil;
        local q=C[l[1703]](G)==l[1089]and G[l[382]]or nil;
        if C[l[1703]](q)~=l[1089] then
          return;
        end
        q[l[1324]]=Y and l[383]or l[1329];
        if Y then
          local Y=N[l[160]][l[636]];
          if Y>l[59] then
            G[l[1639]]=C[l[1459]][l[772]](l[229],l[393],l[393],Y);
            q[l[1639]]=C[l[1459]][l[772]](l[229],l[393],l[393],Y);
          end
        end
      end
      P[l[99]]=Z;
      local function Z(G,Y,C)
        G=s[87]();
        local N=G[l[1130]](Y or l[1746]);
        if C then
          local Y=d:label({[l[572]]=N,[l[1141]]=l[383]});
          G=j(P,N);
          G[l[1228]]=Y;
          local function C(q,q)
            if Y[l[1255]] then
              Y:set(q);
            end
          end
          G[l[1014]]=C;
          return G;
        end
        return j(P,N);
      end
      P[l[1254]]=Z;
      local function Z(G,Y)
        Y=Y or{};
        G=d:button({[l[572]]=Y[l[1150]]or l[1453],[l[13]]=Y[l[79]]and T[l[810]](Y[l[79]])or nil,[l[1617]]=Y[l[1683]]});
        return f({[l[953]]=G});
      end
      P[l[1003]]=Z;
      return f(P);
    end
    local function d(P)
      local Z=s[87]();
      local G=Z[l[1089]][l[772]](l[37]);
      G[l[382]]=T[l[122]];
      local Y=l[1329];
      local j=P[l[1674]];
      P[l[1674]]=function(P)
        Y=P and l[383]or l[1329];
        if j then
          j(P);
        end
        G:Fire(Y);
      end;
      Z={[l[582]]=function()
        local P=Y;
        return P;
      end,[l[1629]]=function(P,P)
        Y=P;
        G:Fire(P);
      end,[l[34]]=function(P,Y)
        P=s[70](G[l[511]]:Connect(Y));
        return T:AddSignal(s:ZT(P));
      end};
      return Z;
    end
    local function P(Z)
      local G=s[87]();
      if not T[l[826]] then
        return Z;
      end
      Z=G[l[964]][l[227]];
      local Y=Z and Z[l[952]]or G[l[1689]][l[772]](l[1493],l[958]);
      G[l[1146]](function()
        local j=s[87]();
        local C=j[l[1469]]()[l[1265]];
        local N=j[l[1703]](C)==l[1689];
        if N then
          Y=C;
        end
      end);
      Z=J[l[1581]];
      Z=if G[l[40]](Z)~=l[384]or Z<=l[393]then l[229]else Z;
      local j,C=G[l[1458]]:GetService(l[1408]--[[nparams]]):GetGuiInset()[l[636]],G[l[35]][l[850]](Y[l[1437]]-l[829],l[1592]);
      local N,q=G[l[35]][l[850]](Y[l[636]]-j-l[1249],l[710]),G[l[35]][l[819]](G[l[35]][l[499]](Y[l[1437]]*l[156]),G[l[35]][l[457]](l[253],C),G[l[35]][l[457]](l[1709],C));
      C=G[l[35]][l[819]](N,G[l[35]][l[457]](l[667],N),l[218]);
      return G[l[1459]][l[588]](G[l[35]][l[499]](q/Z),G[l[35]][l[499]](C/Z));
    end
    local function Z(G,Y)
      local j=s[87]();
      Y=Y or{};
      local C=J:window({[l[1096]]=P(Y[l[1639]]or j[l[1459]][l[588]](l[1493],l[563])),[l[1132]]=T[l[826]]and l[827]or nil,[l[1686]]=Y[l[483]]or l[1383]});
      T[l[1067]]=C[l[1156]];
      if T[l[826]] then
        local N=j[l[1458]]:GetService(l[1408]--[[nparams]]);
        local function q()
          local b,D=s[87](),N:GetGuiInset()[l[636]];
          b[l[1146]](function()
            local N=s[87]();
            C:setsize(P(C[l[1096]]or N[l[1459]][l[588]](l[1493],l[563])));
            C[l[1156]][l[948]]=N[l[1459]][l[772]](l[659],l[393],l[659],N[l[35]][l[499]](D/l[59]));
          end);
        end
        q();
        G=j[l[964]][l[227]];
        if G then
          T:AddSignal(G:GetPropertyChangedSignal(l[952]):Connect(q));
        end
      end
      T[l[938]]=C[l[593]];
      local P={[l[336]]=C,[l[211]]=C[l[1156]],[l[256]]={},[l[552]]=l[229],[l[483]]=Y[l[483]]or l[1383]};
      local function Y(N)
        local q=s[87]();
        if q[l[1703]](N)~=l[1089] then
          return l[393];
        end
        local b=l[393];
        for D,p in q[l[1471]](N:GetDescendants())do
          if p:IsA(l[211])and p:GetAttribute(l[226]) then
            D=p:FindFirstChildWhichIsA(l[211]);
            if D and D[l[1347]]==q[l[128]][l[1347]][l[636]] then
              local N=D[l[160]][l[636]];
              if N>l[59]and p[l[160]][l[636]]<N-l[59] then
                p[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
                local D=p[l[382]];
                if D and D:IsA(l[211])and D[l[160]][l[636]]<N-l[59] then
                  D[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
                end
                b+=l[229];
              else
              end
            else
            end
          else
          end
        end;
        return b;
      end
      local function N(q)
        local b=s[87]();
        b[l[1022]][l[1061]](function()
          Y(q);
        end);
        b[l[1022]][l[1330]](l[659],function()
          Y(q);
        end);
      end
      local Y=l[383];
      local q=j[l[1089]][l[772]](l[37]);
      q[l[382]]=T[l[122]];
      local b,D,p=l[901],{[l[582]]=function()
        local r=Y;
        return r;
      end},l[1629];
      local function r(K,K)
        Y=K;
        q:Fire(K);
      end
      D[p]=r;
      D[l[34]]=function(p,r)
        p=s[70](q[l[511]]:Connect(r));
        return T:AddSignal(s:ZT(p));
      end;
      P[b]=D;
      local function b(D)
        C:render(not C[l[1600]]);
      end
      P[l[293]]=b;
      local b=C[l[80]];
      local function D(p,r)
        b(p,r);
        r=p[l[1600]]and l[383]or l[1329];
        local b=r~=Y;
        if b then
          Y=r;
          q:Fire(r);
          if r and p[l[897]] then
            N(p[l[897]][l[178]]);
          end
        end
      end
      C[l[80]]=D;
      local Y={};
      local q=l[1329];
      local function b(p)
        local r=s[87]();
        local K=r[l[1471]];
        for o,c in K(Y)do
          local K=c==p;
          o=K and q;
          if o then
            continue;
          end
          if c[l[1600]]~=K and c[l[1521]--[[0]]] then
            r[l[1146]](function()
              c:setopen(K);
            end);
          end
        end;
      end
      local function p(r)
        local r,K=s[87](),C[l[897]];
        if r[l[40]](K)~=l[1346] then
          return nil;
        end
        for o,o in r[l[1471]](C[l[1206]])do
          if o==K then
            return r[l[1130]](o[l[572]]);
          end
          for c,c in r[l[1471]](o[l[245]]or{})do
            if c==K then
              return r[l[1130]](o[l[572]])..l[532]..r[l[1130]](c[l[572]]);
            end
          end;
        end;
        return nil;
      end
      P[l[423]]=p;
      local function r(K,o)
        K=s[87]();
        if K[l[40]](o)~=l[409]or o==l[1746] then
          return l[1329];
        end
        local c,m=K[l[409]][l[56]](o,l[85]);
        c=c or o;
        for o,o in K[l[1471]](C[l[1206]])do
          if K[l[1130]](o[l[572]])==c then
            if m then
              for c,c in K[l[1471]](o[l[245]]or{})do
                if K[l[1130]](c[l[572]])==m then
                  K[l[1146]](function()
                    c[l[199]]();
                  end);
                  b(o);
                  return l[383];
                end
              end;
            end
            K[l[1146]](function()
              o[l[199]]();
            end);
            return l[383];
          end
        end;
        return l[1329];
      end
      P[l[176]]=r;
      local function r(K,o)
        K=s[87]();
        if K[l[1703]](o)~=l[1459]or T[l[826]] then
          return;
        end
        K[l[1146]](function()
          C:setsize(o);
        end);
      end
      P[l[1193]]=r;
      local function r(K,o)
        K=s[87]();
        if o==nil then
          return;
        end
        P[l[483]]=o;
        K[l[1146]](function()
          C:setbind(o);
        end);
      end
      P[l[612]]=r;
      local r,K;
      local o,c={};
      local function m()
        local S=not K;
        if S then
          K=C:tab({[l[572]]=l[28],[l[13]]=l[240]});
          local O=K;
          local B,A=O[l[1674]],K;
          A[l[1674]]=function(O)
            local A=s[87]();
            if B then
              B(O);
            end
            if not O then
              return;
            end
            A[l[1022]][l[1061]](function()
              local O,B=s[87](),c or o[l[788]];
              q=l[383];
              if B then
                O[l[1146]](function()
                  B:select();
                end);
              end
              q=l[1329];
            end);
          end;
        end
        S=K;
        return S;
      end
      local function K(S,O)
        local B,A=s[87](),not o[S];
        if A then
          local A=m();
          local m=A:sub({[l[572]]=S,[l[13]]=O});
          local O=m[l[1674]];
          if not B[l[1346]][l[23]](Y,A) then
            B[l[1346]][l[968]](Y,A);
          end
          m[l[1674]]=function(B)
            if O then
              O(B);
            end
            if B then
              c=m;
              b(A);
            end
          end;
          o[S]=m;
        end
        return o[S];
      end
      local function o(c,m,S)
        local O=s[87]();
        return O[l[360]][l[353]](c,m,S);
      end
      local function c(m,S,O,B,A,w,F,h,W)
        return{[l[641]]=m,[l[1132]]=S,[l[675]]=O,[l[1466]]=B,[l[966]]=A,[l[1529]--[[cancel]]]=w,[l[1095]]=F,[l[1379]]=h,[l[98]]=W};
      end
      local m={[l[1380]]=n,[l[614]]=c(o(l[1158],l[930],l[558]),o(l[1307],l[558],l[209]),o(l[730],l[750],l[884]),o(l[973],l[1241],l[1249]),o(l[520],l[161],l[694]),o(l[492],l[1592],l[929]),o(l[725],l[1305],l[1682]),o(l[1308],l[494],l[777]),o(l[1627],l[777],l[1682])),[l[815]]=c(o(l[786],l[551],l[310]),o(l[930],l[829],l[884]),o(l[1092],l[558],l[1241]),o(l[1307],l[884],l[941]),o(l[489],l[1708],l[694]),o(l[710],l[1115],l[1475]),o(l[725],l[1293],l[1682]),o(l[1396],l[632],l[1179]),o(l[205],l[768],l[1475])),[l[417]]=c(o(l[303],l[730],l[551]),o(l[730],l[114],l[829]),o(l[551],l[973],l[558]),o(l[750],l[1243],l[1707]),o(l[726],l[616],l[1167]),o(l[827],l[929],l[768]),o(l[307],l[1054],l[465]),o(l[627],l[123],l[544]),o(l[754],l[307],l[1671])),[l[1257]]=c(o(l[1158],l[551],l[303]),o(l[1307],l[829],l[730]),o(l[730],l[558],l[551]),o(l[973],l[884],l[750]),o(l[1656],l[616],l[520]),o(l[450],l[929],l[827]),o(l[1322],l[1054],l[1425]),o(l[1339],l[123],l[1308]),o(l[1179],l[929],l[117])),[l[390]]=c(o(l[930],l[1092],l[303]),o(l[973],l[750],l[551]),o(l[750],l[1307],l[930]),o(l[1707],l[114],l[310]),o(l[616],l[652],l[520]),o(l[929],l[1115],l[1179]),o(l[1682],l[1363],l[1305]),o(l[1242],l[544],l[1308]),o(l[725],l[1295],l[1627])),[l[167]]=c(o(l[730],l[930],l[303]),o(l[352],l[558],l[551]),o(l[829],l[310],l[930]),o(l[209],l[352],l[1307]),o(l[1098],l[652],l[906]),o(l[1475],l[920],l[710]),o(l[1682],l[1284],l[725]),o(l[1179],l[1479],l[627]),o(l[1682],l[1300],l[1167])),[l[1244]]=c(o(l[551],l[303],l[303]),o(l[829],l[551],l[551]),o(l[558],l[930],l[930]),o(l[884],l[310],l[310]),o(l[1168],l[906],l[906]),o(l[1475],l[492],l[492]),o(l[1682],l[1305],l[1305]),o(l[1179],l[422],l[422]),o(l[1475],l[652],l[1366])),[l[1103]]=c(o(l[730],l[1158],l[551]),o(l[114],l[1307],l[973]),o(l[973],l[730],l[558]),o(l[1243],l[558],l[1241]),o(l[1168],l[834],l[652]),o(l[929],l[1179],l[920]),o(l[1682],l[1425],l[580]),o(l[1179],l[1308],l[492]),o(l[1682],l[710],l[450])),[l[927]]=c(o(l[310],l[551],l[1307]),o(l[1707],l[973],l[352]),o(l[352],l[750],l[829]),o(l[658],l[1241],l[209]),o(l[339],l[652],l[1168]),o(l[1682],l[1295],l[667]),o(l[1682],l[1322],l[465]),o(l[1201],l[1479],l[1109]),o(l[1682],l[1300],l[681])),[l[1692]]=c(o(l[930],l[1158],l[750]),o(l[973],l[1307],l[1243]),o(l[750],l[730],l[1707]),o(l[1707],l[973],l[910]),o(l[652],l[1506],l[995]),o(l[920],l[1592],l[1682]),o(l[580],l[1305],l[1682]),o(l[1479],l[581],l[1592]),o(l[60],l[494],l[1682]))};
      local n,o={l[1380],l[614],l[815],l[417],l[1257],l[390],l[167],l[1244],l[1103],l[927],l[1692]};
      local function c(S,O)
        local B,A=s[87](),m[O];
        if not A then
          return;
        end
        J:retheme(A);
        O=J[l[1334]];
        J[l[1334]]=l[383];
        for m,w in B[l[534]](A)do
          S=J[l[1294]][l[1321]..m];
          if S and S[l[1255]] then
            B[l[1146]](S[l[1255]],w);
          end
        end;
        J[l[1334]]=O;
      end
      P[l[186]]=c;
      local function m(S)
        P:ApplyMenuTheme(l[1380]);
      end
      P[l[447]]=m;
      local function S(O)
        local B,A=s[87](),o;
        if A then
          O=o;
          return O;
        end
        o=K(l[1468],l[478]);
        A=o;
        O=a(A:section({[l[572]]=l[271],[l[1132]]=H(l[356])}));
        O:AddLabel(l[165]):AddDropdown({[l[1380]]=l[1380],[l[1561]]=n,[l[1315]]=l[1361],[l[1683]]=function(n)
          P:ApplyMenuTheme(n);
        end});
        O:AddLabel(l[437]):AddDropdown({[l[1380]]=l[1380],[l[1561]]=J:fontnames(),[l[1315]]=l[1344],[l[1683]]=function(n)
          J:setfont(n);
        end});
        A,O=B[l[1471]],{{l[1602],l[98],l[356]},{l[1420],l[1095],l[1316]},{l[1325],l[675],l[356]},{l[1082],l[1466],l[1316]},{l[296],l[1132],l[356]},{l[620],l[966],l[1316]},{l[979],l[1379],l[356]},{l[918],l[1529]--[[cancel]],l[1316]},{l[1515],l[641],l[356]}};
        for n,n in A(O)do
          B=o;
          B:color({[l[572]]=n[l[229]],[l[230]]=n[l[59]],[l[1132]]=H(n[l[863]])});
        end;
        O,A=o,{[l[572]]=l[1380]};
        A[l[1132]]=H(l[1316]);
        O:section(A):button({[l[572]]=l[1677],[l[1617]]=function()
          P:ResetMenuColors();
        end});
        O=o;
        return O;
      end
      P[l[1663]]=S;
      local n;
      local function o(S)
        S=n;
        if S then
          local O=n;
          return O;
        end
        S=K(l[1104],l[1517]);
        S:configs({[l[572]]=l[1104],[l[1132]]=H(l[356])});
        local O=S:section({[l[572]]=l[399],[l[1132]]=H(l[1316])});
        local function S(B,A)
          J:notify({[l[1434]]=B,[l[13]]=A and l[898]or l[1411],[l[440]]=l[863]});
        end
        local B;
        O:button({[l[572]]=l[1011],[l[1617]]=function()
          local A=s[87]();
          if A[l[40]](T[l[1332]])~=l[1712] then
            S(l[461],l[383]);
            return;
          end
          local w,F=T[l[1332]]();
          if not w then
            S(A[l[1130]](F),l[383]);
            return;
          end
          w=A[l[40]](A[l[302]])==l[1712]and A[l[1146]](A[l[302]],F);
          if B then
            B:SetValue(F);
          end
          S(w and l[881]or F);
        end});
        O:button({[l[572]]=l[17],[l[1617]]=function()
          local A,w,F=s[87](),J:clipboardExport();
          S(w and l[1234]or A[l[1130]](F),not w);
        end});
        B=a(O):AddLabel(l[386]):AddTextInput({[l[940]]=l[1123]});
        O:button({[l[572]]=l[1172],[l[1617]]=function()
          local A=s[87]();
          local w=A[l[409]][l[56]](B:GetValue()or l[1746],l[381])or l[1746];
          if A[l[409]][l[56]](w,l[698]) then
            if A[l[40]](T[l[148]])~=l[1712] then
              S(l[461],l[383]);
              return;
            end
            local F,h=T[l[148]](w);
            if F then
              B:SetValue(l[1746]);
              S(l[432]);
            else
              S(A[l[1130]](h),l[383]);
            end
            return;
          end
          local F,h;
          if w~=l[1746] then
            local W=J:thaw(w);
            if W then
              F,h=J:apply(W)==l[383],J[l[171]]and J[l[171]][l[1290]]and J[l[171]][l[1290]][l[229]];
            else
              F,h=l[1329],l[1279];
            end
            if F then
              B:SetValue(l[1746]);
            end
          else
            F,h=J:clipboardLoad();
          end
          S(F and l[432]or A[l[1130]](h or l[51]),not F);
        end});
        n={[l[1002]]=function()
        end};
        O=n;
        return O;
      end
      P[l[1211]]=o;
      local function n(o,o,S)
        local O,B=K(l[788],l[1716]),{[l[572]]=o or l[146],[l[1132]]=H(S)};
        return a(O:section(B));
      end
      P[l[395]]=n;
      m,p,c,D=l[693],j[l[1488]],{},l[533];
      local function n(o,S)
        local O,B=s[87](),not r;
        if B then
          o=K(l[788],l[1716]);
          r=a(o:section({[l[572]]=l[788],[l[1132]]=l[356]}));
        end
        local K=r[S];
        if O[l[40]](K)~=l[1712] then
          return K;
        end
        local function o(S,...)
          S=r;
          return K(S,...);
        end
        return o;
      end
      c[D]=n;
      P[m]=p({},c);
      do
        m=z(l[1329]);
        if m then
          m[l[1016]]=j[l[1689]][l[772]](l[393],l[229]);
          m[l[948]]=j[l[1459]][l[772]](l[393],l[730],l[229],l[1026]);
        end
        local n=z(l[383]);
        if n then
          (n:FindFirstChildOfClass(l[238])or j[l[1089]][l[772]](l[238],n))[l[1609]]=T[l[826]]and l[731]or l[229];
        end
        G=n and T[l[826]];
        if G then
          n[l[43]]=l[383];
          local z=l[393];
          local function G()
            local D=s[87]();
            local r=D[l[655]][l[1587]]();
            local K=r-z;
            if K<l[820] then
              return;
            end
            z=r;
            D[l[1146]](function()
              C:toggle();
            end);
          end
          local z=j[l[1458]]:GetService(l[1]);
          local D=j[l[1458]]:GetService(l[1408]--[[nparams]]);
          local r,K,o;
          local function c(m)
            local S=s[87]();
            if m[l[1317]]==S[l[128]][l[1317]][l[239]] then
              return S[l[1689]][l[772]](m[l[948]][l[1437]],m[l[948]][l[636]]);
            end
            return z:GetMouseLocation()-D:GetGuiInset();
          end
          local function D(m)
            local S,O=n[l[81]],n[l[160]];
            return m[l[1437]]>=S[l[1437]]and m[l[1437]]<=S[l[1437]]+O[l[1437]]and m[l[636]]>=S[l[636]]and m[l[636]]<=S[l[636]]+O[l[636]];
          end
          local function m(S)
            local O=s[87]();
            return S[l[1317]]==O[l[128]][l[1317]][l[1356]]or S[l[1317]]==O[l[128]][l[1317]][l[239]];
          end
          T:AddSignal(z[l[1558]]:Connect(function(S)
            local O=s[87]();
            if not m(S) then
              return;
            end
            if not(n[l[382]]and n[l[1324]]and J[l[1185]]) then
              return;
            end
            local B=c(S);
            local A,w=D(B)and B or nil,O[l[655]][l[1587]]();
            r,K=A,w;
            o=r and S or nil;
          end));
          T:AddSignal(z[l[412]]:Connect(function(z)
            local D=s[87]();
            if not m(z) then
              return;
            end
            local m=o;
            if z~=m then
              return;
            end
            m=r;
            local S=m;
            r,o=nil,nil;
            if not S then
              return;
            end
            if (c(z)-S)[l[945]]>l[930] then
              return;
            end
            S=D[l[655]][l[1587]]()-K;
            if S>l[509] then
              return;
            end
            G();
          end));
          for z,z in j[l[1471]](n:GetChildren())do
            p=l[957];
            if z:IsA(p) then
              z[l[43]]=l[383];
            end
          end;
        end
        j[l[1146]](function()
          J:setopener(l[1329]);
        end);
        local z=l[383];
        local function n(G)
          local j=s[87]();
          z=G and l[383]or l[1329];
          j[l[1146]](function()
            J:setwatermark(z);
          end);
          j[l[1146]](function()
            J:setopener(T[l[826]]and not z);
          end);
        end
        T[l[1665]]=n;
      end;
      local function z(n,J)
        n=s[87]();
        J=J or{};
        local G=C:tab({[l[572]]=J[l[1150]]or l[367],[l[13]]=T[l[810]](J[l[79]])});
        if J[l[911]]and G[l[1466]]and G[l[1466]][l[382]] then
          G[l[1466]][l[382]][l[537]]=l[823];
        end
        local j=G[l[1674]];
        G[l[1674]]=function(D)
          if j then
            j(D);
          end
          if D then
            b(G);
          end
        end;
        local j={[l[113]]=G,[l[1150]]=J[l[1150]],[l[901]]=d(G)};
        local function J(D,p)
          p=p or{};
          D={[l[572]]=p[l[1150]]or l[146],[l[1132]]=H(p[l[948]])};
          return a(G:section(D));
        end
        j[l[157]]=J;
        local function J(D)
          if D and G[l[199]] then
            G:select();
          end
        end
        j[l[1629]]=J;
        n[l[1346]][l[968]](P[l[256]],j);
        return f(j);
      end
      P[l[1530]--[[spawn]]]=z;
      local function z(n,J,G,j)
        local D,p=s[87](),C:tab({[l[572]]=J,[l[13]]=T[l[810]](G)});
        n={[l[113]]=p};
        for r,r in D[l[1471]](j or{})do
          local K=p:sub({[l[572]]=r[l[1150]],[l[13]]=T[l[810]](r[l[79]])});
          J={[l[1711]]=K,[l[1150]]=r[l[1150]],[l[901]]=d(K)};
          local function d(o,c)
            c=c or{};
            o={[l[572]]=c[l[1150]]or l[146],[l[1132]]=H(c[l[948]])};
            return a(K:section(o));
          end
          J[l[157]]=d;
          local function a(d)
            if d and K[l[199]] then
              K:select();
            end
          end
          J[l[1629]]=a;
          local function a(d,o)
            local c=s[87]();
            o=o or{};
            local m,S=l[919]+((o[l[543]]==l[383]or c[l[40]](o[l[869]])==l[1346])and l[1282]or l[393])-(o[l[665]]==l[1329]and l[913]or l[393]),c[l[1703]](C[l[1096]])==l[1459]and C[l[1096]][l[636]][l[1485]]or l[1709];
            d=c[l[35]][l[850]](l[422],c[l[35]][l[457]](o[l[1044]]or l[341],S-l[913]-l[1282]-m-l[1158]));
            S={[l[572]]=o[l[1150]]or l[484],[l[13]]=o[l[79]]and T[l[810]](o[l[79]])or l[1736],[l[1132]]=H(o[l[948]]),[l[1477]]=d,[l[1206]]=o[l[1561]]or{},[l[950]]=o[l[1380]],[l[1693]]=o[l[660]]and l[383]or l[1329],[l[1009]]=o[l[242]]==l[383],[l[798]]=o[l[1035]]or l[1191],[l[1410]]=o[l[19]]and T[l[810]](o[l[19]])or l[1736],[l[294]]=o[l[1264]]or l[151],[l[1141]]=o[l[1738]]==l[383],[l[634]]=o[l[883]]==l[383],[l[4]]=o[l[665]]~=l[1329],[l[1105]]=o[l[543]]==l[383],[l[424]]=o[l[869]],[l[603]]=c[l[40]](o[l[1516]])==l[1346]and{[l[13]]=T[l[810]](o[l[1516]][l[79]]or o[l[1516]][l[13]]or l[1716]),[l[1617]]=o[l[1516]][l[1683]]or o[l[1516]][l[1617]]}or nil,[l[1669]]=o[l[882]],[l[472]]=o[l[814]]or l[686],[l[1013]]=o[l[1315]],[l[1617]]=e(o[l[1315]],o[l[1683]])};
            return K:gallery(S);
          end
          J[l[420]]=a;
          n[r[l[1150]]]=f(J);
          D[l[1346]][l[968]](P[l[256]],n[r[l[1150]]]);
        end;
        local J=p[l[245]]and p[l[245]][l[229]]or nil;
        local H=l[1329];
        D[l[1346]][l[968]](Y,p);
        j,G=D[l[1471]],p[l[245]]or{};
        for a,a in j(G)do
          local d=a[l[1674]];
          a[l[1674]]=function(G)
            if G then
              J=a;
            end
            if d then
              d(G);
            end
            if G then
              N(a[l[178]]);
              b(p);
            end
          end;
        end;
        local a=p[l[1674]];
        p[l[1674]]=function(d)
          local G=s[87]();
          if a then
            a(d);
          end
          if d then
            N(p[l[178]]);
          end
          local a=d and J and not H;
          if not a then
            return;
          end
          H=l[383];
          G[l[1022]][l[1061]](function()
            local a=s[87]();
            H=l[1329];
            q=l[383];
            a[l[1146]](function()
              J:select();
            end);
            q=l[1329];
          end);
        end;
        local function H()
          local a,d=s[87](),J;
          if d then
            a[l[1146]](function()
              J:select();
            end);
          end
        end
        n[l[174]]=H;
        j=J and C[l[897]]==p;
        if j then
          D[l[1022]][l[1061]](function()
            local H=s[87]();
            H[l[1146]](function()
              J:select();
            end);
          end);
        end
        local function s()
          if p[l[1521]--[[0]]] then
            p:setopen(not p[l[1600]]);
          end
          return p[l[1600]];
        end
        n[l[1229]]=s;
        local function s()
          return p[l[1600]];
        end
        n[l[408]]=s;
        return n;
      end
      P[l[1084]]=z;
      return f(P);
    end
    T[l[1174]]=Z;
    return T;
  end
  return(y(L,...));
end
