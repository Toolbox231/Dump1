-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #35
-- offset 3658788..3659167 (379 bytes, type=payload)

local function f(j)
  r+=1;
  N.On=j and true or false;
  s();
  j=N.On;
  if j then
    local s,j=not p;
    if s then
      local j;
      local j,O=J,n;
      p=j:AddSignal(O.CharacterAdded:Connect(H));
    end
    s=n;
    local J=s.Character;
    if J then
      task.spawn(function()
        task.wait(0.2);
        local s;
        local s=z[4][z[6]]and N.On;
        if s then
          T();
        end
      end);
    end
  else
    local s=p;
    if s then
      pcall(function()
        p:Disconnect();
      end);
      p=nil;
    end
    S();
  end
end
