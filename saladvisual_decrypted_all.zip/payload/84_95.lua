-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #95
-- offset 3688037..3688443 (406 bytes, type=payload)

function()
  if isfile and isfile(T) then
    local a=game:GetService("HttpService"):JSONDecode(readfile(T));
    if type(a)=="table" then
      H.emotes=type(a.emotes)=="table"and a.emotes or{};
      H.packs=type(a.packs)=="table"and a.packs or{};
      local function a(b)
        local D={};
        if type(b)~="table" then
          return D;
        end
        for p,r in pairs(b)do
          if r then
            D[j(p)]=true;
          end
        end;
        return D;
      end
      H.emotes=a(H.emotes);
      H.packs=a(H.packs);
    end
  end
end
