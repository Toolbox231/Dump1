-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #26
-- offset 3231436..3232505 (1069 bytes, type=payload)

local function B(h)
  if p[h.Name] then
    return p[h.Name];
  end
  local k;
  local k=H;
  local H,v=k.objects(function()
    local I,i=game,"rbxassetid://"..tostring(h.Id);
    return I:GetObjects(i);
  end);
  if not H or type(v)~="table"or not v[1] then
    return nil;
  end
  k=v[1];
  for I=2,#v,1 do
    pcall(function()
      v[I]:Destroy();
    end);
  end;
  local v;
  H=z[4][z[6]];
  if not H then
    k:Destroy();
    return nil;
  end
  if not k:IsA("Model") then
    H=Instance.new("Model");
    k.Parent=H;
    k=H;
  else
  end
  H=k:GetDescendants();
  if #H>4096 then
    k:Destroy();
    return nil;
  end
  k.Archivable=true;
  for v,v in ipairs(H)do
    v.Archivable=true;
    if v:IsA("LuaSourceContainer")or v:IsA("Humanoid")or v:IsA("JointInstance")or v:IsA("Constraint")or v:IsA("BodyMover")or v:IsA("Sound")or v:IsA("ParticleEmitter")or v:IsA("Beam")or v:IsA("Trail")or v:IsA("Fire")or v:IsA("Smoke")or v:IsA("Sparkles") then
      pcall(function()
        v:Destroy();
      end);
    end
  end;
  for H,H in ipairs(k:GetDescendants())do
    if H:IsA("BasePart") then
      H.Anchored=true;
      H.CanCollide=false;
      H.CanQuery=false;
      H.CanTouch=false;
      H.Massless=true;
      H.CastShadow=false;
      H.Locked=true;
    end
  end;
  p[h.Name]=k;
  return k;
end
