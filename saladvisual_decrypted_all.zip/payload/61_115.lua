-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #115
-- offset 137533..138443 (910 bytes, type=payload)

local function n(j,o)
  local c=r(j);
  if not c then
    if o.char or next(o.worn)or next(o.busy) then
      Z(o);
    end
    o.char=nil;
    return;
  end
  if o.char~=c then
    Z(o);
    o.char=c;
  end
  for Z,r in pairs(o.worn)do
    if o.want[Z]~=r.group then
      B(Z,o.worn);
    else
      local Z=o.tint and o.tint[r.group]or nil;
      if not q(r.tint,Z) then
        r.tint=Z;
        D(r);
      end
    end
  end;
  local Z,r=pairs,o.want;
  for S,A in Z(r)do
    local Z=not o.worn[S]and not o.busy[S];
    if Z then
      local Z={};
      o.busy[S]=Z;
      task.spawn(function()
        local r,w=pcall(function()
          local F=d.ById[S];
          local h=F and Y(F.g);
          local Y,F=h and h[S];
          h=Y and y[4][y[6]]and o.busy[S]==Z and o.want[S]==A and o.char==c and c.Parent;
          if h then
            p(S,Y,c,A,o.worn,j,function()
              return f[j]==o and o.busy[S]==Z and not o.worn[S]and o.want[S]==A and o.char==c and c.Parent~=nil;
            end);
          end
        end);
        local Y=not r;
        if Y then
          local Y;
          r=T;
          r("share "..tostring(S)..": "..tostring(w));
        end
        if o.busy[S]==Z then
          o.busy[S]=nil;
        end
      end);
    end
  end;
end
