-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #51
-- offset 124358..125481 (1123 bytes, type=payload)

function(c)
  local m,O=c.limb("Torso"),c.live.roots.Torso;
  local B=O and(O:WaitForChild("EchoBubbleMesh",5));
  if not(m and B) then
    return;
  end
  O=workspace:FindFirstChild(c.player.Name.."_distortion")or Instance.new("Folder");
  O.Name=c.player.Name.."_distortion";
  O.Parent=workspace;
  c.made(O);
  local A;
  local A=J;
  A.RenderStepped:Wait();
  while c.alive()and m.Parent do
    local c=B:Clone();
    c.CFrame=m.CFrame;
    c.Anchored=false;
    c.CanCollide=false;
    c.CanTouch=false;
    c.CanQuery=false;
    A=c:FindFirstChild("Weld");
    if A then
      A.Part0=m;
      A.Part1=c;
    end
    c.Massless=true;
    c.Parent=O;
    c.Material=Enum.Material.Glass;
    c.Size=Vector3.new(6,6,6);
    c.Transparency=1;
    local m=Instance.new("Highlight");
    m.Enabled=false;
    m.Parent=c;
    game:GetService("Debris"):AddItem(c,11);
    local O,B=TweenInfo.new,Enum;
    local A,w=B.EasingStyle.Sine,Enum.EasingDirection;
    B,m=O(3,A,w.In),{Transparency=6};
    m.Size=Vector3.new(7,7,7);
    l:Create(c,B,m):Play();
    task.delay(2,function()
      if c.Parent then
        local m,O=TweenInfo.new,Enum;
        local B,A=O.EasingStyle.Sine,Enum.EasingDirection;
        local O,w=m(8,B,A.Out),{Transparency=1};
        w.Size=Vector3.new(8,8,8);
        l:Create(c,O,w):Play();
      end
    end);
    task.wait(4);
  end;
end
