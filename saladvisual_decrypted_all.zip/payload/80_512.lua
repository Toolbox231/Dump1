-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #512
-- offset 3454025..3464950 (10925 bytes, type=payload)

local function J(G,p)
  G=s[87]();
  p=X(p,{[l[572]]=l[1104],[l[1132]]=l[356]});
  local r=AP(p[l[1132]]);
  local B,A=mP(r,l[994]);
  G[l[1346]][l[968]](OP,{[l[590]]=A,[l[572]]=p[l[572]],[l[12]]={}});
  r=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},B);
  D(r,l[1092]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[393],l[229]),[l[948]]=G[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},r);
  local A=a;
  local w=l[859];
  local F={};
  F[l[1150]]=f();
  F[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
  F[l[948]]=G[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
  F[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
  F[l[1646]]=l[229];
  F[l[1451]]=y[30](l[317]);
  F[l[936]]=R[l[1379]];
  F[l[2]]=l[986];
  F[l[1557]]=G[l[128]][l[1557]][l[220]];
  F[l[711]]=l[1092];
  A(w,F,r);
  a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=G[l[1459]][l[772]](l[229],l[207],l[229],l[393]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},r);
  K(a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[393],l[688]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},B),l[393],{G[l[677]][l[772]](l[393],l[229]),G[l[677]][l[772]](l[841],l[874]),G[l[677]][l[772]](l[659],l[393]),G[l[677]][l[772]](l[804],l[874]),G[l[677]][l[772]](l[229],l[229])});
  local A=a(l[1439],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[392]]=G[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[1158]},B);
  D(A,l[1158]);
  a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},A);
  local w=a(l[755],{[l[407]]=G[l[128]][l[407]][l[537]],[l[536]]=G[l[740]][l[772]](l[393],l[59])},A);
  a(l[1359],{[l[299]]=G[l[740]][l[772]](l[393],l[786]),[l[645]]=G[l[740]][l[772]](l[393],l[786]),[l[1612]]=G[l[740]][l[772]](l[393],l[786]),[l[517]]=G[l[740]][l[772]](l[393],l[786])},A);
  d(w:GetPropertyChangedSignal(l[996]),function()
    local F=s[87]();
    A[l[392]]=F[l[1459]][l[588]](l[393],j(w)[l[636]]+l[930]);
  end);
  local w=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1604],[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[659],[l[1324]]=l[1329],[l[711]]=l[1092]},B);
  local F=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1571]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[658]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=G[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[759],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},B);
  D(F,l[1158]);
  a(l[1359],{[l[1612]]=G[l[740]][l[772]](l[393],l[730]),[l[517]]=G[l[740]][l[772]](l[393],l[730])},F);
  local V=a(l[734],{[l[1161]]=G[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1419]},F);
  local fP=a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1331]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},B);
  p,r=l[755],{[l[101]]=G[l[128]][l[101]][l[1505]],[l[407]]=G[l[128]][l[407]][l[537]]};
  r[l[536]]=G[l[740]][l[772]](l[393],l[1158]);
  a(p,r,fP);
  local p=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1307],l[1322]),[l[1639]]=G[l[1459]][l[772]](l[229],l[749],l[393],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[229],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},B);
  local G=l[393];
  local r=l[1329];
  local function aP(GP,NP,DP)
    local SP,BP=s[87](),G;
    G=BP+l[229];
    r=DP and l[383]or l[1329];
    local BP=G;
    p[l[1420]]=GP;
    p[l[510]]=NP or R[l[1379]];
    P(p,n,{[l[916]]=l[874]});
    if DP then
      return;
    end
    SP[l[1022]][l[1330]](l[1586],function()
      local GP=G;
      if GP==BP then
        P(p,H,{[l[916]]=l[229]});
      end
    end);
  end
  local function GP()
    local NP=r;
    if not NP then
      return;
    end
    NP=G;
    G=NP+l[229];
    r=l[1329];
    P(p,H,{[l[916]]=l[229]});
  end
  local G,p,r={};
  local function NP(DP)
    local SP,BP=s[87](),p;
    local wP,FP,hP=BP==DP[l[572]],DP[l[1466]],{};
    hP[l[1646]]=wP and l[1422]or l[629];
    P(FP,H,hP);
    local BP,FP,hP,WP=DP[l[1642]],{},l[1646],wP and l[841]or(DP[l[892]]and l[659]or l[229]);
    FP[hP]=WP;
    P(BP,H,FP);
    WP,BP=DP[l[1473]],{};
    BP[l[747]]=wP and l[1567]or l[229];
    P(WP,H,BP);
    P(DP[l[451]],H,{[l[1639]]=SP[l[1459]][l[772]](l[393],l[863],l[393],wP and l[750]or l[393]),[l[1646]]=wP and l[1296]or l[229]});
    P(DP[l[647]],H,{[l[2]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[936]]=wP and R[l[1095]]or R[l[1379]]});
    P(DP[l[1615]],H,{[l[916]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[510]]=wP and R[l[1095]]or R[l[1379]]});
  end
  local function DP()
    for SP,SP in y[3],G,nil do
      NP(SP);
    end;
  end
  local function SP(BP)
    p=BP;
    F[l[1420]]=BP or l[1746];
    DP();
  end
  local function DP()
    local BP=sP(F[l[1420]])or p;
    if not BP then
      aP(l[455]);
      return;
    end
    local wP=y[18]:store(BP);
    if wP then
      p=BP;
      aP(l[1426]..BP,R[l[1095]]);
      zP();
    else
      aP(l[1702]);
    end
  end
  local function BP()
    local wP=p;
    if not wP then
      aP(l[1138]);
      return;
    end
    wP=(y[18]:store(p));
    if wP then
      F[l[1420]]=p;
      aP(l[479]..p,R[l[1095]]);
      zP();
    else
      aP(l[262]);
    end
  end
  local function wP(FP)
    local hP=sP(FP)or p;
    if not hP then
      aP(l[1138]);
      return;
    end
    if y[18]:fetch(hP) then
      SP(hP);
      aP(l[264]..hP,R[l[1095]]);
    else
      FP=y[18][l[171]];
      aP(FP and FP[l[1290]]and FP[l[1290]][l[229]]or l[418]);
    end
  end
  local function FP()
    local hP=p or sP(F[l[1420]]);
    if not hP then
      aP(l[1138]);
      return;
    end
    local WP=y[18]:erase(hP);
    if WP then
      if y[18]:autoload()==hP then
        y[18]:setautoload(nil);
      end
      p=nil;
      F[l[1420]]=l[1746];
      aP(l[285]..hP,R[l[1095]]);
      zP();
    else
      aP(l[1292]);
    end
  end
  local function hP()
    local WP,VP=sP(F[l[1420]]),p;
    if not VP then
      aP(l[1138]);
      return;
    end
    if not WP then
      aP(l[155]);
      return;
    end
    local VP,_P=p,y[18]:retitle(p,WP);
    if _P and y[18]:autoload()==VP then
      y[18]:setautoload(_P);
    end
    if _P then
      SP(_P);
      aP(l[355].._P,R[l[1095]]);
      zP();
    else
      aP(l[119]);
    end
  end
  local function zP(WP)
    local VP={};
    local _P=s[87]();
    for XP,XP in y[3],G,nil do
      for xP,xP in y[3],XP[l[608]],nil do
        xP:Disconnect();
      end;
      XP[l[1466]]:Destroy();
    end;
    _P[l[1346]][l[267]](G);
    local XP=p and not _P[l[1346]][l[23]](WP,p);
    if XP then
      p=nil;
    end
    w[l[1324]]=#WP==l[393];
    for w,XP in y[3],WP,nil do
      local WP={[l[572]]=XP,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1132]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=w,[l[711]]=l[1158]},A)};
      D(WP[l[1466]],l[1158]);
      WP[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},WP[l[1466]]);
      WP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},WP[l[1466]]);
      D(WP[l[1642]],l[1158]);
      K(WP[l[1642]],l[393],{_P[l[677]][l[772]](l[393],l[393]),_P[l[677]][l[772]](l[509],l[986]),_P[l[677]][l[772]](l[229],l[1017])});
      WP[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=_P[l[1689]][l[772]](l[393],l[659]),[l[948]]=_P[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},WP[l[1466]]);
      local xP,kP=l[1112],{};
      kP[l[1182]]=_P[l[740]][l[772]](l[229],l[393]);
      a(xP,kP,WP[l[451]]);
      VP[1]=l[647];
      VP[3]=a;
      VP[4]=l[859];
      VP[2]={};
      VP[2][l[1150]]=f();
      VP[2][l[1016]]=_P[l[1689]][l[772]](l[393],l[659]);
      VP[2][l[948]]=_P[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
      VP[2][l[1639]]=_P[l[1459]][l[588]](l[310],l[310]);
      VP[2][l[1646]]=l[229];
      VP[2][l[1451]]=y[30](XP==y[18]:autoload()and l[1059]or l[1177]);
      VP[2][l[936]]=R[l[1379]];
      VP[2][l[2]]=l[229];
      VP[2][l[1557]]=_P[l[128]][l[1557]][l[220]];
      VP[2][l[711]]=l[1092];
      VP[5]=(VP[3](VP[4],VP[2],WP[l[1466]]));
      WP[VP[1]]=VP[5];
      WP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=_P[l[1459]][l[588]](l[688],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=_P[l[128]][l[437]][l[1381]],[l[1420]]=XP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[229],[l[164]]=_P[l[128]][l[164]][l[1021]],[l[1634]]=_P[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},WP[l[1466]]);
      WP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},WP[l[1466]]);
      _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1538]]:Connect(function()
        WP[l[892]]=l[383];
        NP(WP);
      end));
      _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1628]]:Connect(function()
        WP[l[892]]=l[1329];
        NP(WP);
      end));
      _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[445]]:Connect(function()
        local VP=s[87]();
        local XP,xP=VP[l[655]][l[1587]](),p;
        VP=xP==WP[l[572]]and XP-(r or l[393])<l[330];
        if VP then
          r=nil;
          wP(WP[l[572]]);
          return;
        end
        r=XP;
        SP(WP[l[572]]);
      end));
      G[w]=WP;
      _P[l[1022]][l[1330]]((w-l[229])*l[182],function()
        if WP[l[1466]][l[382]] then
          NP(WP);
        end
      end);
    end;
  end
  local function G()
    local r=p;
    if not r then
      aP(l[1138]);
      return;
    end
    r=y[18]:autoload()==p;
    if r then
      y[18]:setautoload(nil);
      aP(l[851],R[l[1095]]);
    else
      local r=y[18]:setautoload(p);
      if r then
        aP(l[830]..p,R[l[1095]]);
      else
        aP(l[1702]);
      end
    end
    zP(y[18]:roster());
  end
  local r=l[393];
  local function w(NP,WP,VP)
    local _P,XP=s[87](),r;
    r=XP+l[229];
    local XP=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[528],l[66],l[229],l[393]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1451]]=l[1746],[l[537]]=r,[l[711]]=l[1158]},fP);
    D(XP,l[1158]);
    local r=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[923]},XP);
    local fP=a;
    local xP=l[859];
    local kP={};
    kP[l[1150]]=f();
    kP[l[1016]]=_P[l[1689]][l[772]](l[659],l[659]);
    kP[l[948]]=_P[l[1459]][l[1368]](l[659],l[659]);
    kP[l[1639]]=_P[l[1459]][l[588]](l[973],l[973]);
    kP[l[1646]]=l[229];
    kP[l[1451]]=y[30](NP);
    kP[l[936]]=R[l[1379]];
    kP[l[2]]=l[986];
    kP[l[1557]]=_P[l[128]][l[1557]][l[220]];
    kP[l[711]]=l[1092];
    local NP=fP(xP,kP,XP);
    d(XP[l[1538]],function()
      P(XP,H,{[l[1646]]=l[393]});
      P(r,H,{[l[747]]=l[323]});
      P(NP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
      aP(WP,R[l[1379]],l[383]);
    end);
    d(XP[l[1628]],function()
      P(XP,H,{[l[1646]]=l[841]});
      P(r,H,{[l[747]]=l[923]});
      P(NP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]]});
      GP();
    end);
    d(XP[l[445]],function()
      NP[l[936]]=R[l[98]];
      P(NP,H,{[l[936]]=R[l[1095]]});
      y[18]:chime(l[1320]);
      VP();
    end);
    return XP;
  end
  w(l[317],l[512],DP);
  w(l[1517],l[680],wP);
  w(l[1169],l[172],BP);
  w(l[1177],l[1222],hP);
  w(l[905],l[704],FP);
  w(l[1059],l[1125],G);
  d(F[l[505]],function()
    P(V,H,{[l[747]]=l[615]});
  end);
  d(F[l[722]],function(G)
    P(V,H,{[l[747]]=l[1419]});
    if G then
      DP();
    end
  end);
  y[18]:watch(zP);
  w={[l[852]--[[readi16]]]=B,[l[1206]]=A,[l[1002]]=function()
    zP(y[18]:roster());
  end};
  local function G(r)
    r=p;
    return r;
  end
  w[l[506]]=G;
  local function G(p,p)
    SP(sP(p));
  end
  w[l[199]]=G;
  return w;
end
