-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #272
-- offset 3375383..3375788 (405 bytes, type=payload)

local function BP(FP,hP)
  local nC={};
  hP=hP and l[383]or l[1329];
  if _P[l[404]]==hP then
    return;
  end
  _P[l[404]]=hP;
  if hP then
    V();
    U(_P);
    wP();
    xP[l[1324]]=l[383];
    IP[l[1324]]=l[383];
    if kP then
      kP[l[1324]]=l[383];
    end
    NP();
    A,w=LC,IP;
    lC();
    nC[1]=(y[10][l[1119]]:Connect(zC));
    vP=nC[1];
  else
    lC();
    xP[l[1324]]=l[1329];
    if _P[l[548]] then
      _P[l[548]]=l[1329];
      lP(nil);
      uP();
    end
    FP=A==LC;
    if FP then
      A,w=nil,nil;
    end
  end
  fP();
end
