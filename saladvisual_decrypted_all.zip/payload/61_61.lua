-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #61
-- offset 126931..127286 (355 bytes, type=payload)

function(G)
  local c=G.parent;
  local m=c:FindFirstChild("1")and c["1"]:FindFirstChild("1Number");
  local O=c:FindFirstChild("2")and c["2"]:FindFirstChild("2Number");
  if not(m and O) then
    return;
  end
  local c,B=0;
  G.conn(J.RenderStepped:Connect(function(G)
    local B=c;
    c=B+3.141592653589793*G;
    G=CFrame.Angles(c/4,c/2,0);
    m.CFrame=m.CFrame*G;
    O.CFrame=O.CFrame*G;
  end));
end
