-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #841
-- offset 3560008..3561420 (1412 bytes, type=payload)

local function Z(G,Y,e)
  local j,C=s[87](),G and G[l[266]];
  if j[l[1703]](C)~=l[1089]or j[l[40]](G[l[1255]])~=l[1712] then
    return G;
  end
  local N;
  for q,q in j[l[1471]](C:GetChildren())do
    N=if q:IsA(l[1070])and q[l[1634]]==j[l[128]][l[1634]][l[877]]then q else N;
  end;
  if not N then
    return G;
  end
  local q=j[l[1089]][l[772]](l[1400]--[[-1]]);
  q[l[1150]]=l[373];
  q[l[1535]]=J[l[131]][l[1466]];
  q[l[1646]]=l[1209];
  q[l[1418]]=l[393];
  q[l[1016]]=N[l[1016]];
  q[l[948]]=N[l[948]];
  q[l[1639]]=j[l[1459]][l[588]](j[l[35]][l[850]](l[520],N[l[160]][l[1437]]+l[558]),l[829]);
  q[l[437]]=j[l[128]][l[437]][l[1381]];
  q[l[723]]=l[310];
  q[l[510]]=J[l[131]][l[1095]];
  q[l[1155]]=l[383];
  q[l[1324]]=l[1329];
  q[l[711]]=N[l[711]]+l[59];
  q[l[382]]=C;
  j[l[1089]][l[772]](l[1112],q)[l[1182]]=j[l[740]][l[772]](l[393],l[786]);
  local b=j[l[1089]][l[772]](l[192]);
  b[l[1150]]=l[1427];
  b[l[1646]]=l[229];
  b[l[1420]]=l[1746];
  b[l[1016]]=N[l[1016]];
  b[l[948]]=N[l[948]];
  b[l[1639]]=j[l[1459]][l[588]](j[l[35]][l[850]](l[520],N[l[160]][l[1437]]+l[558]),l[352]);
  b[l[711]]=N[l[711]]+l[229];
  b[l[382]]=C;
  j,C=l[445],function()
    local N=s[87]();
    q[l[1420]]=N[l[1130]](G:get());
    q[l[1324]]=l[383];
    q:CaptureFocus();
  end;
  b[j]:Connect(C);
  j,C=l[722],function()
    local N=s[87]();
    q[l[1324]]=l[1329];
    local b=N[l[1382]]((q[l[1420]]or l[1746]):match(l[198]));
    if not b then
      return;
    end
    b=if Y then N[l[35]][l[850]](Y,b)else b;
    b=if e then N[l[35]][l[457]](e,b)else b;
    G:set(b);
  end;
  q[j]:Connect(C);
  return G;
end
