-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #459
-- offset 3436819..3450093 (13274 bytes, type=payload)

local function J(NP,SP)
  local BP=s[87]();
  SP=X(SP,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1013]]=nil,[l[1617]]=nil});
  if SP[l[230]]and BP[l[1703]](R[SP[l[230]]])==l[360] then
    local wP=SP[l[1617]];
    SP[l[950]]=R[SP[l[230]]];
    SP[l[1617]]=function(WP)
      y[18]:recolor(SP[l[230]],WP);
      if wP then
        wP(WP);
      end
    end;
  end
  fP[l[668]]+=l[229];
  local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
  local VP=aP[l[745]];
  local aP=l[291];
  local _P=l[291];
  local XP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
  local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1099],l[229],l[393]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=SP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},XP);
  local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[658],l[829]),[l[1535]]=SP[l[950]],[l[1418]]=l[393],[l[711]]=l[1158]},XP);
  D(kP,l[786]);
  local vP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[986]},kP);
  wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},kP);
  D(wP,l[786]);
  K(wP,l[117],{BP[l[677]][l[772]](l[393],l[1567]),BP[l[677]][l[772]](l[229],l[229])});
  local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[1452],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[913],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},XP),a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
  local EP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
  local GP=EP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=BP[l[740]][l[772]](l[393],l[829]),[l[1485]]=BP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=BP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},EP)or nil;
  if EP then
    D(EP,l[930]);
  end
  local QP=a(l[1751],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
  D(QP,l[930]);
  wP,NP=l[1622],{[l[500]]=l[117]};
  NP[l[1630]]=BP[l[1262]][l[772]]({BP[l[527]][l[772]](l[393],BP[l[360]][l[772]](l[229],l[229],l[229])),BP[l[527]][l[772]](l[229],BP[l[360]][l[353]](l[291],l[291],l[920]))});
  a(wP,NP,QP);
  a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},QP);
  NP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},QP);
  D(NP,l[930]);
  a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},NP);
  local tP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[730]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[422]),[l[1535]]=BP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
  D(tP,l[1158]);
  wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
  D(wP,l[1158]);
  local RP,gP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]](l[229],l[229],l[229]))};
  gP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[393]),BP[l[677]][l[772]](l[229],l[229])});
  a(RP,gP,wP);
  gP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
  D(gP,l[1158]);
  wP,NP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]]()),[l[500]]=l[117]};
  NP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[229]),BP[l[677]][l[772]](l[229],l[393])});
  a(wP,NP,gP);
  a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},tP);
  local uP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},tP);
  RP,NP=l[1112],{};
  NP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
  a(RP,NP,uP);
  a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},uP);
  local NP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[633]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
  D(NP,l[303]);
  a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},NP);
  wP={};
  for UP=l[393],l[1158],l[229]do
    BP[l[1346]][l[968]](wP,BP[l[527]][l[772]](UP/l[1158],BP[l[360]][l[149]](UP/l[1158],l[229],l[229])));
  end;
  gP,RP=l[1622],{};
  RP[l[1630]]=BP[l[1262]][l[772]](wP);
  a(gP,RP,NP);
  local UP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[948]]=BP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},NP);
  gP,wP=l[1112],{};
  wP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
  a(gP,wP,UP);
  a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},UP);
  local MP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1743],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=p(SP[l[950]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[913]},QP);
  D(MP,l[303]);
  local sC=a(l[734],{[l[1161]]=BP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[411]},MP);
  local function lC(LC,yC)
    local zC=s[87]();
    local TC=a;
    local nC=l[1742];
    local JC={};
    JC[l[1150]]=f();
    JC[l[1016]]=zC[l[1689]][l[772]](l[229],l[393]);
    JC[l[948]]=zC[l[1459]][l[772]](l[229],LC,l[393],l[1394]);
    JC[l[1639]]=zC[l[1459]][l[588]](l[1707],l[1707]);
    JC[l[1535]]=R[l[1466]];
    JC[l[1646]]=l[229];
    JC[l[1418]]=l[393];
    JC[l[1451]]=y[30](yC);
    JC[l[936]]=R[l[1379]];
    JC[l[2]]=l[986];
    JC[l[1557]]=zC[l[128]][l[1557]][l[220]];
    JC[l[711]]=l[913];
    local LC=TC(nC,JC,QP);
    D(LC,l[303]);
    d(LC[l[1538]],function()
      P(LC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
    end);
    d(LC[l[1628]],function()
      P(LC,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
    end);
    return LC;
  end
  local LC=lC(l[1726],l[1549]);
  local yC=lC(l[1026],l[967]);
  local lC={[l[266]]=XP,[l[404]]=l[1329],[l[1409]]=SP[l[950]],[l[771]]=l[1329]};
  local zC={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
  local TC,nC=l[1329];
  local JC=l[1329];
  local HC=l[393];
  local function fC(aC)
    local dC=s[87]();
    if not SP[l[1617]] then
      return;
    end
    local PC=y[18][l[921]];
    if PC then
      local ZC=HC;
      HC=ZC+l[229];
      ZC=nil;
      ZC,nC=l[1329],nil;
      JC=ZC;
      I(SP[l[1617]],aC);
      return;
    end
    nC=aC;
    PC=JC;
    if PC then
      return;
    end
    JC=l[383];
    aC=HC;
    HC=aC+l[229];
    local aC=HC;
    local PC=y[18][l[1478]];
    dC[l[1022]][l[1330]](l[1296],function()
      local dC=HC;
      if aC~=dC then
        return;
      end
      dC=nC;
      local HC=dC;
      nC=nil;
      JC=l[1329];
      if HC and y[18][l[630]]and PC==y[18][l[1478]] then
        I(SP[l[1617]],HC);
      end
    end);
  end
  gP,RP,wP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=XP};
  wP[l[572]]=SP[l[572]];
  gP(RP,wP);
  zC[l[434]],zC[l[900]],zC[l[999]]=BP[l[360]][l[1412]](SP[l[950]]);
  local function BP()
    local wP=s[87]();
    P(vP,H,{[l[747]]=(lC[l[404]]or TC)and l[393]or l[986]});
    P(xP,H,{[l[916]]=(lC[l[404]]or TC)and l[1209]or l[615]});
    P(kP,H,{[l[1639]]=wP[l[1459]][l[588]]((lC[l[404]]or TC)and l[688]or l[658],(lC[l[404]]or TC)and l[114]or l[829])});
  end
  local function wP(FP,xP)
    local vP=s[87]();
    local RP,gP,nC=vP[l[360]][l[149]](zC[l[434]],zC[l[900]],zC[l[999]]),vP[l[1459]][l[1368]](zC[l[900]],l[229]-zC[l[999]]),vP[l[1459]][l[772]](zC[l[434]],l[393],l[659],l[393]);
    if xP then
      uP[l[948]]=gP;
      UP[l[948]]=nC;
      uP[l[1535]]=RP;
      tP[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229]);
      kP[l[1535]]=RP;
    else
      P(uP,n,{[l[948]]=gP,[l[1535]]=RP});
      P(UP,n,{[l[948]]=nC});
      P(tP,n,{[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229])});
      P(kP,n,{[l[1535]]=RP});
    end
    if not MP:IsFocused() then
      MP[l[1420]]=p(RP);
    end
    lC[l[1409]]=RP;
    if FP then
      fC(RP);
    end
  end
  local function FP()
    local xP,vP,RP,gP,uP=s[87](),G(YP),e(YP),G(kP),e(kP);
    local UP,nC=gP[l[1437]]-vP[l[1437]]+uP[l[1437]]-aP,lC[l[771]]and gP[l[636]]-vP[l[636]]-l[1158]or gP[l[636]]-vP[l[636]]+uP[l[636]]+l[1158];
    UP=if UP+aP>RP[l[1437]]-l[930]then RP[l[1437]]-l[930]-aP else UP;
    QP[l[948]]=xP[l[1459]][l[588]](xP[l[35]][l[499]](xP[l[35]][l[850]](UP,l[930])+l[659]),xP[l[35]][l[499]](nC+l[659]));
    if EP then
      EP[l[948]]=QP[l[948]];
    end
  end
  local function xP()
    local vP=QP[l[1569]];
    local RP=lC[l[404]]and l[393]or l[229];
    b(QP,lC[l[404]]and l[894]or l[304],lC[l[404]]and N or q,function(gP)
      local uP=vP+(RP-vP)*gP;
      QP[l[1569]]=uP;
      if EP then
        EP[l[1646]]=uP;
        GP[l[747]]=l[615]+l[411]*uP;
      end
      if gP>=l[229] then
        QP[l[1324]]=lC[l[404]];
        if EP then
          EP[l[1324]]=lC[l[404]];
        end
      end
    end);
  end
  local GP;
  local function vP()
    local RP=GP;
    if RP then
      GP:Disconnect();
      GP=nil;
    end
  end
  local function RP()
    local gP=S;
    if gP>l[393] then
      return;
    end
    lC:setopen(l[1329]);
  end
  local function gP()
    local uP=S;
    if uP>l[393] then
      FP();
      return;
    end
    if not LP[l[1600]]or not KP[l[1324]]or not XP[l[1324]] then
      lC:setopen(l[1329]);
      return;
    end
    local XP,UP,nC,JC,HC,fC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],kP[l[81]],kP[l[160]];
    uP=HC[l[636]]+fC[l[636]]*l[659];
    if uP<XP[l[636]]or uP>XP[l[636]]+UP[l[636]]or uP<nC[l[636]]or uP>nC[l[636]]+JC[l[636]] then
      lC:setopen(l[1329]);
      return;
    end
    FP();
  end
  local function VP(XP,uP)
    local UP={};
    XP=s[87]();
    uP=uP and l[383]or l[1329];
    if lC[l[404]]==uP then
      return;
    end
    lC[l[404]]=uP;
    if uP then
      V();
      local V,uP,nC,JC=G(YP),e(YP),G(kP),e(kP);
      local G,kP=uP[l[636]]-(nC[l[636]]-V[l[636]]+JC[l[636]]+l[1158])-l[1158],nC[l[636]]-V[l[636]]-l[310];
      lC[l[771]]=G<_P and kP>G;
      QP[l[1016]]=XP[l[1689]][l[772]](l[393],lC[l[771]]and l[229]or l[393]);
      QP[l[1639]]=XP[l[1459]][l[588]](aP,_P);
      QP[l[1324]]=l[383];
      iP[l[1324]]=l[383];
      if EP then
        EP[l[1016]]=QP[l[1016]];
        EP[l[1639]]=QP[l[1639]];
        EP[l[1324]]=l[383];
      end
      FP();
      A,w=RP,QP;
      vP();
      UP[1]=(y[10][l[1119]]:Connect(gP));
      GP=UP[1];
    else
      vP();
      iP[l[1324]]=l[1329];
      local G=A==RP;
      if G then
        A,w=nil,nil;
      end
      if MP:IsFocused() then
        MP:ReleaseFocus();
      end
    end
    BP();
    xP();
  end
  lC[l[1521]--[[0]]]=VP;
  local function G(A,w)
    A=s[87]();
    w=if A[l[1703]](w)==l[409]then r(w)else w;
    if A[l[1703]](w)~=l[360] then
      return;
    end
    zC[l[434]],zC[l[900]],zC[l[999]]=A[l[360]][l[1412]](w);
    wP(l[383]);
  end
  lC[l[1255]]=G;
  local function G(A)
    return lC[l[1409]];
  end
  lC[l[506]]=G;
  local function G()
    if not zC[l[259]] then
      return;
    end
    zC[l[259]]=l[1329];
    zC[l[700]]=nil;
    if zC[l[1731]] then
      zC[l[1731]]:Disconnect();
      zC[l[1731]]=nil;
    end
    WP[l[1195]]=l[383];
    O(l[715]);
  end
  local function A()
    local w=s[87]();
    if zC[l[259]]and zC[l[700]] then
      local V,aP=w[l[1146]](function()
        zC[l[700]]();
        wP(l[383],l[383]);
      end);
      if not V then
        G();
        w[l[972]](l[1752]..w[l[1130]](aP));
      end
    end
  end
  local function w(V,aP)
    d(V[l[956]],G);
    d(V[l[1558]],function(GP)
      local FP=s[87]();
      if GP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and GP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
        return;
      end
      if zC[l[259]] then
        return;
      end
      zC[l[259]]=l[383];
      zC[l[700]]=aP;
      zC[l[225]]=GP;
      O(l[229]);
      zC[l[1731]]=B(GP,G);
      WP[l[1195]]=l[1329];
      A();
    end);
    d(V[l[412]],function(B)
      local V=s[87]();
      if B[l[1317]]==V[l[128]][l[1317]][l[1356]]or B[l[1317]]==V[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
        G();
      end
    end);
  end
  w(tP,function()
    local B,V,aP,GP=s[87](),tP[l[81]],tP[l[160]],v(zC[l[225]]);
    zC[l[900]]=B[l[35]][l[819]]((GP[l[1437]]-V[l[1437]])/B[l[35]][l[850]](aP[l[1437]],l[229]),l[393],l[229]);
    zC[l[999]]=l[229]-B[l[35]][l[819]]((GP[l[636]]-V[l[636]])/B[l[35]][l[850]](aP[l[636]],l[229]),l[393],l[229]);
  end);
  w(NP,function()
    local B,w,V=s[87](),NP[l[81]],NP[l[160]];
    zC[l[434]]=B[l[35]][l[819]]((v(zC[l[225]])[l[1437]]-w[l[1437]])/B[l[35]][l[850]](V[l[1437]],l[229]),l[393],l[229]);
  end);
  d(y[9][l[412]],function(B)
    local w=s[87]();
    if B[l[1317]]==w[l[128]][l[1317]][l[1356]]or B[l[1317]]==w[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
      G();
    end
  end);
  d(y[9][l[233]],function(G)
    local B=s[87]();
    if not zC[l[259]] then
      return;
    end
    if G[l[1317]]==B[l[128]][l[1317]][l[765]]or G[l[1317]]==B[l[128]][l[1317]][l[239]] then
      if G[l[1317]]==B[l[128]][l[1317]][l[239]]and G~=zC[l[225]] then
        return;
      end
      A();
    end
  end);
  d(MP[l[505]],function()
    O(l[229]);
    P(sC,H,{[l[747]]=l[615]});
  end);
  d(MP[l[722]],function()
    local G=s[87]();
    O(l[715]);
    P(sC,H,{[l[747]]=l[411]});
    local B=r(MP[l[1420]]);
    if B then
      zC[l[434]],zC[l[900]],zC[l[999]]=G[l[360]][l[1412]](B);
    end
    wP(l[383]);
  end);
  local function G(B)
    B[l[936]]=R[l[98]];
    B[l[2]]=l[393];
    P(B,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
  end
  d(LC[l[445]],function()
    local B=s[87]();
    if y[14] then
      B[l[1146]](y[14],p(lC[l[1409]]));
    end
    G(LC);
    y[18]:chime(l[1320]);
  end);
  d(yC[l[445]],function()
    local B=s[87]();
    local A=r(y[15]and B[l[199]](l[59],B[l[1146]](y[15])));
    if A then
      zC[l[434]],zC[l[900]],zC[l[999]]=B[l[360]][l[1412]](A);
      wP(l[383]);
      G(yC);
      y[18]:chime(l[1320]);
    end
  end);
  d(iP[l[445]],RP);
  d(IP[l[445]],function()
    lC:setopen(not lC[l[404]]);
    y[18]:chime(l[1352]);
  end);
  d(IP[l[1538]],function()
    TC=l[383];
    BP();
  end);
  d(IP[l[1628]],function()
    TC=l[1329];
    BP();
  end);
  wP(l[1329],l[383]);
  BP();
  VP=SP[l[1013]]or SP[l[230]]and l[1321]..SP[l[230]];
  y[18]:hook(VP or hP..l[1074]..SP[l[572]],l[1409],function()
    return lC[l[1409]];
  end,function(G)
    lC:set(G);
  end);
  return lC;
end
