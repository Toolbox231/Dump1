-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #13
-- offset 3205900..3206245 (345 bytes, type=payload)

local function j()
  local C=s:FindFirstChildOfClass("Atmosphere");
  local N=not C;
  if N then
    C=Instance.new("Atmosphere");
    local q=l;
    C.Name=q.RandomString();
    C.Parent=s;
    Y=C;
  else
  end
  N=not e or e.instance~=C or not C.Parent;
  if N then
    e={instance=C,Density=C.Density,Offset=C.Offset,Haze=C.Haze,Glare=C.Glare,Color=C.Color,Decay=C.Decay};
  end
  return C;
end
