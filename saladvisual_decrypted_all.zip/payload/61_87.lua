-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #87
-- offset 130843..131867 (1024 bytes, type=payload)

local function w(F,h,W)
  local V,_=ipairs,h.scripts or{};
  for X,x in V(_)do
    X=x.at:match("([^%.]+)$")or"";
    local V=p[F.key.."/"..x.n]or p[X.."/"..x.n];
    X=A(h,x.at);
    local p=V and X;
    if p then
      local p,A={char=h.char};
      if W then
        A=W;
      else
        local W;
        local W=n;
        A=W;
      end
      p.player=A;
      p.parent=X;
      p.live=h;
      p.anims=x.anims or{};
      p.limb=function(A)
        return(e(h.char,A));
      end;
      local A;
      p.conn=function(A)
        local W=h.alive and y[4][y[6]];
        if W then
          h.conns[#h.conns+1]=A;
        else
          A:Disconnect();
        end
        return A;
      end;
      p.undo=function(A)
        local W=h.alive and y[4][y[6]];
        if W then
          h.undo[#h.undo+1]=A;
        else
          pcall(A);
        end
      end;
      p.alive=function()
        local A=h.alive and y[4][y[6]];
        return A;
      end;
      p.made=function(A)
        local W=h.alive and y[4][y[6]];
        if W then
          h.made[#h.made+1]=A;
          if h.watch then
            h.watch(A);
          end
        else
          A:Destroy();
        end
        return A;
      end;
      local A,W=task.spawn(function()
        local _,X=pcall(V,p);
        local p=not _;
        if p then
          local p;
          _=T;
          _("game fx "..F.key.."/"..x.n..": "..tostring(X));
        end
      end),h.alive and y[4][y[6]];
      if W then
        h.tasks[#h.tasks+1]=A;
      else
        pcall(task.cancel,A);
      end
    end
  end;
end
