-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #14
-- offset 21338..21650 (312 bytes, type=payload)

local function P(G,Y,e)
  if s.Mode=="Rainbow" then
    return Color3.fromHSV((e*0.11+G.phase)%1,0.85,1);
  end
  if s.Mode=="Single" then
    return s.Color;
  end
  e=z;
  local C=e.AccentColor or s.Color;
  local e,N,q=C:ToHSV();
  C=math.sin(Y*0.5+G.phase*6.283)*0.09;
  return Color3.fromHSV((e+C)%1,math.clamp(N,0.35,1),math.max(q,0.65));
end
