-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #53
-- offset 3676505..3676739 (234 bytes, type=payload)

function()
  if l._currentEmoteTrack~=w then
    return;
  end
  task.defer(function()
    if l._currentEmoteTrack~=w or w.IsPlaying then
      return;
    end
    if l.EmoteLoop then
      pcall(function()
        w:Play(0,1,l.EmoteSpeed/100);
      end);
    else
      l.ResetEmote();
    end
  end);
end
