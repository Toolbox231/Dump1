-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #9
-- offset 5582..7066 (1484 bytes, type=payload)

function(b,o,c,m)
  local S,O=j[L.CircleStyle]or j[Y],b.Circle;
  if not O or O.Style~=L.CircleStyle or not O.Part.Parent then
    if O then
      O.Part:Destroy();
    end
    O=(G(b,S));
  else
  end
  O.Clock=O.Clock+m;
  m=O.Clock>=0.1 or O.Ground~=L.CircleGround;
  if m then
    O.Clock,O.Ground=0,L.CircleGround;
    local G,B,A=c.Position-Vector3.new(0,c.Size.Y*0.5,0),Vector3.new(0.0,1.0,0.0),L.CircleGround;
    if A then
      b=RaycastParams.new();
      b.FilterType=Enum.RaycastFilterType.Exclude;
      local A,w={o,O.Part},J;
      for F,F in ipairs(w:GetPlayers())do
        if F.Character then
          A[#A+1]=F.Character;
        end
      end;
      b.FilterDescendantsInstances=A;
      b.IgnoreWater=true;
      w=workspace:Raycast(c.Position,Vector3.new(0,-64,0),b);
      if w then
        G,B=w.Position,w.Normal;
      else
      end
    else
    end
    O.Position=G;
    O.Normal=B;
  end
  m=O.Normal or Vector3.new(0.0,1.0,0.0);
  o=math.abs(m.Y)>0.98 and Vector3.new(1.0,0.0,0.0)or Vector3.new(0.0,1.0,0.0);
  b=m:Cross(o).Unit;
  O.Part.CFrame=CFrame.fromMatrix(O.Position+m*L.CircleHeight,b,m,b:Cross(m).Unit);
  S,m,c=O.Emitter,{L.CircleColor,L.CircleSize,L.CircleOpacity,L.CircleGlow,L.CircleRotation,L.CircleThroughWalls},not O.Settings;
  for G,o in ipairs(m)do
    c=if not O.Settings or o~=O.Settings[G]then true else c;
  end;
  if c then
    O.Settings=m;
    S.Color,S.Size=ColorSequence.new(L.CircleColor),NumberSequence.new(L.CircleSize);
    S.Transparency,S.Brightness=NumberSequence.new(1-L.CircleOpacity),L.CircleGlow;
    S.Rotation=NumberRange.new(L.CircleRotation);
    local G;
    b=H;
    b.FxDepth(S,L.CircleThroughWalls);
    if O.Ready then
      S:Clear();
      S:Emit(1);
    end
  end
end
