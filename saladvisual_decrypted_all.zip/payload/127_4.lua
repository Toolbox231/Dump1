-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #4
-- offset 199428..200330 (902 bytes, type=payload)

local function L()
  local z=Instance.new("Attachment");
  local T,F=Instance.new("Attachment"),b;
  z.Parent,T.Parent=F,F;
  local function h(W)
    local V=Instance.new("Beam");
    V.Attachment0=z;
    V.Attachment1=T;
    V.FaceCamera=true;
    V.LightInfluence=0;
    V.LightEmission=1;
    V.Texture=W;
    V.TextureSpeed=0;
    V.Segments=8;
    W=nil;
    W,V.Width0,V.Enabled=b,0,false;
    V.Parent=W;
    return V;
  end
  F=Instance.new("BillboardGui");
  F.Adornee,F.AlwaysOnTop=T,d.ThroughWalls;
  F.LightInfluence=0;
  local W,V=UDim2.fromScale(1,1),b;
  F.Size=W;
  F.Enabled=false;
  F.Parent=V;
  V=Instance.new("ImageLabel");
  V.BackgroundTransparency,V.Size=1,UDim2.fromScale(1,1);
  V.Image=B;
  V.Parent=F;
  W=Instance.new("ImageLabel");
  W.BackgroundTransparency,W.Size=1,UDim2.fromScale(0.85,0.85);
  W.AnchorPoint,W.Position=Vector2.new(0.5,0.5),UDim2.fromScale(0.5,0.5);
  W.Image=A;
  W.Rotation=15;
  W.Parent=F;
  local B={tail=z,nose=T,line=h(""),haze=h(O),card=F,blob=V,star=W,busy=false};
  return B;
end
