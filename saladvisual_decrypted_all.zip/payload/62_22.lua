-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #22
-- offset 3230915..3231272 (357 bytes, type=payload)

local function s(B)
  local A=W;
  if A then
    W:Disconnect();
    W=nil;
  end
  if not B then
    return;
  end
  yP(B);
  W=B.DescendantAdded:Connect(function()
    local A;
    local A=z[4][z[6]]and(X or x);
    local h=not A or k;
    if h then
      return;
    end
    k=true;
    task.defer(function()
      k=false;
      local A,h=z[4][z[6]];
      if A then
        local k;
        local k=T;
        h=k.Character==B;
      else
        h=A;
      end
      if h then
        F();
      end
    end);
  end);
end
