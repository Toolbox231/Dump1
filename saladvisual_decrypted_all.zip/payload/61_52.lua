-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #52
-- offset 125257..125459 (202 bytes, type=payload)

function()
  if c.Parent then
    local m,O=TweenInfo.new,Enum;
    local B,A=O.EasingStyle.Sine,Enum.EasingDirection;
    local O,w=m(8,B,A.Out),{Transparency=1};
    w.Size=Vector3.new(8,8,8);
    l:Create(c,O,w):Play();
  end
end
