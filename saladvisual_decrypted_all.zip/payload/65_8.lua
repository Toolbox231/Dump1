-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #8
-- offset 5086..5539 (453 bytes, type=payload)

function()
  local O=s(o);
  local B;
  local B=not z[4][z[6]]or b.Circle~=m or not c.Parent or not O;
  if B then
    return;
  end
  S.Texture=O;
  O={[2]=Enum.ParticleFlipbookLayout.Grid2x2,[4]=Enum.ParticleFlipbookLayout.Grid4x4,[8]=Enum.ParticleFlipbookLayout.Grid8x8};
  if o.frames and O[o.cols] then
    S.FlipbookLayout=O[o.cols];
    S.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
    S.FlipbookStartRandom=false;
    S.FlipbookFramerate=NumberRange.new(0);
  end
  S:Emit(1);
  m.Ready=true;
end
