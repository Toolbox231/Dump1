-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #30
-- offset 12922..13598 (676 bytes, type=payload)

local function A(w)
  local F;
  local F=B.human and B.human.Parent or not z[4][z[6]]or l[m]~=B or m.Character~=O;
  if F then
    return;
  end
  for F,F in ipairs(B.humanConns)do
    F:Disconnect();
  end;
  table.clear(B.humanConns);
  B.human=w;
  B.air=w.FloorMaterial==Enum.Material.Air;
  B.floorAir=B.air;
  B.humanConns[#B.humanConns+1]=w.StateChanged:Connect(function(F,h)
    F=not z[4][z[6]]or l[m]~=B;
    if F then
      return;
    end
    if h==Enum.HumanoidStateType.Jumping then
      G(B);
    elseif h==Enum.HumanoidStateType.Freefall then
      B.air=true;
    elseif h==Enum.HumanoidStateType.Landed then
      j(B);
    end
  end);
  B.humanConns[#B.humanConns+1]=w.Jumping:Connect(function(w)
    local F=z[4][z[6]]and w and l[m]==B;
    if F then
      G(B);
    end
  end);
end
