-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #47
-- offset 123743..124323 (580 bytes, type=payload)

local function S(O,B)
  local A,w,F={},setmetatable,{__mode="k"};
  local h,W,V=w({},F),setmetatable,{__mode="k"};
  local w=W({},V);
  O.tune=A;
  local function F(W)
    if h[W] then
      return nil;
    end
    local V=p(W);
    if V then
      h[W]=true;
      A[#A+1]=V;
    end
    if o then
      o(W);
    end
    return V;
  end
  O.watch=function(p)
    if not O.alive or w[p] then
      return;
    end
    w[p]=true;
    F(p);
    for A,A in ipairs(p:GetDescendants())do
      F(A);
    end;
    O.conns[#O.conns+1]=p.DescendantAdded:Connect(function(p)
      if not O.alive then
        return;
      end
      local A=F(p);
      if A and O.alive then
        local p,w=c(O);
        m(A,p,w);
      end
    end);
  end;
  for p,p in ipairs(B)do
    O.watch(p);
  end;
end
