-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #12
-- offset 3614669..3615553 (884 bytes, type=payload)

local function r(K,o,c,m)
  m=m or s;
  local S,O=Instance.new("Attachment"),L;
  S.Name=O.RandomString();
  S.Position=Vector3.new(0,-0.9,0);
  S.Parent=o;
  local O,B=Instance.new("ParticleEmitter"),L;
  O.Name=B.RandomString();
  O.Texture=C(c);
  O.LightEmission=c.light;
  O.LightInfluence=0;
  O.Enabled=false;
  O.Rate=c.rate*(m.Rate/100)*(m.Amount/100);
  O.Lifetime=NumberRange.new(m.Life*0.65,m.Life);
  O.Speed=NumberRange.new(c.speed[1],c.speed[2]);
  O.SpreadAngle=Vector2.new(c.spread,c.spread)*(m.Spread/100);
  O.Acceleration=Vector3.new(0,c.rise*(m.Gravity/100),0);
  O.Drag=c.drag;
  O.VelocityInheritance=0.3;
  O.EmissionDirection=Enum.NormalId.Back;
  O.Rotation=NumberRange.new(0,360);
  O.RotSpeed=NumberRange.new(-c.spin,c.spin);
  O.Color=b(c,m);
  O.Size=D(c,m);
  O.Transparency=p(m);
  O.Parent=S;
  l[K]={emitter=O,a=S,root=o,style=c,swap=0,size=m.Size,rate=m.Rate,amount=m.Amount,bright=m.Bright,enabled=false,life=m.Life,cfg=m};
end
