-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #408
-- offset 3414063..3431242 (17179 bytes, type=payload)

local function J(NP,BP)
  NP=s[87]();
  BP=X(BP,{[l[572]]=l[1336],[l[1206]]={},[l[950]]=nil,[l[850]]=l[930],[l[1693]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
  fP[l[668]]+=l[229];
  local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
  local VP=aP[l[745]];
  local _P=l[941];
  local XP=NP[l[35]][l[850]](NP[l[35]][l[499]](NP[l[1382]](BP[l[850]])or l[930]),l[229]);
  local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
  local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
  local vP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},xP);
  D(vP,l[1158]);
  local IP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},vP);
  local iP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[662],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP);
  local EP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[551]},vP);
  K(EP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
  local QP=a;
  local tP=l[859];
  local RP={};
  RP[l[1150]]=f();
  RP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
  RP[l[948]]=NP[l[1459]][l[772]](l[229],l[708],l[659],l[393]);
  RP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
  RP[l[1646]]=l[229];
  RP[l[1451]]=y[30](l[606]--[[readu16]]);
  RP[l[936]]=R[l[1379]];
  RP[l[2]]=l[1431];
  RP[l[1557]]=NP[l[128]][l[1557]][l[220]];
  RP[l[711]]=l[1092];
  local gP=QP(tP,RP,vP);
  local QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[730]},vP),a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
  local RP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
  local uP=RP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=NP[l[740]][l[772]](l[393],l[829]),[l[1485]]=NP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=NP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},RP)or nil;
  if RP then
    D(RP,l[930]);
  end
  local UP=a(l[1751],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
  D(UP,l[930]);
  local MP,sC=l[1622],{[l[500]]=l[117]};
  sC[l[1630]]=NP[l[1262]][l[772]]({NP[l[527]][l[772]](l[393],NP[l[360]][l[772]](l[229],l[229],l[229])),NP[l[527]][l[772]](l[229],NP[l[360]][l[353]](l[291],l[291],l[920]))});
  a(MP,sC,UP);
  a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},UP);
  MP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},UP);
  D(MP,l[930]);
  a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},MP);
  local lC=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=NP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=NP[l[128]][l[62]][l[636]],[l[711]]=l[913]},UP);
  local LC=a(l[755],{[l[407]]=NP[l[128]][l[407]][l[537]],[l[536]]=NP[l[740]][l[772]](l[393],l[59])},lC);
  a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[1158]),[l[645]]=NP[l[740]][l[772]](l[393],l[1158]),[l[1612]]=NP[l[740]][l[772]](l[393],l[1158]),[l[517]]=NP[l[740]][l[772]](l[393],l[1158])},lC);
  local yC={[l[266]]=xP,[l[404]]=l[1329],[l[955]]=nil,[l[1406]--[[]]]={},[l[1072]]={},[l[771]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
  local zC=l[1329];
  local TC=l[393];
  MP,sC,wP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
  wP[l[572]]=BP[l[572]];
  MP(sC,wP);
  local function NP(wP)
    if BP[l[1693]] then
      return yC[l[1406]--[[]]][wP]==l[383];
    end
    return yC[l[955]]==wP;
  end
  local function wP()
    local MP,sC=s[87](),{};
    for nC=l[229],#BP[l[1206]],l[229]do
      if yC[l[1406]--[[]]][BP[l[1206]][nC]] then
        MP[l[1346]][l[968]](sC,BP[l[1206]][nC]);
      end
    end;
    return sC;
  end
  local function MP(sC,nC)
    local JC,HC,fC,aC=s[87](),NP(sC[l[572]]),sC[l[892]]or yC[l[1072]][TC]==sC,nC and n or H;
    local NP,dC,PC,ZC=sC[l[1466]],{},l[1646],HC and l[922]or(fC and l[330]or l[229]);
    dC[PC]=ZC;
    P(NP,aC,dC);
    ZC,nC=sC[l[1473]],{};
    nC[l[747]]=HC and l[509]or l[229];
    P(ZC,aC,nC);
    nC,PC=sC[l[1642]],{};
    PC[l[1646]]=HC and l[1432]or l[229];
    P(nC,aC,PC);
    P(sC[l[451]],aC,{[l[1639]]=JC[l[1459]][l[772]](l[393],l[863],l[393],HC and l[750]or l[393]),[l[1646]]=HC and l[1296]or l[229]});
    P(sC[l[1615]],aC,{[l[916]]=HC and l[393]or(fC and l[263]or l[323]),[l[510]]=HC and R[l[1095]]or R[l[1379]]});
    if BP[l[1693]] then
      nC,NP=sC[l[595]],{};
      NP[l[1646]]=HC and l[1296]or l[229];
      P(nC,aC,NP);
      local NP,nC,GC,YC=sC[l[741]],{},l[747],HC and l[229]or(fC and l[1296]or l[1431]);
      nC[GC]=YC;
      P(NP,aC,nC);
      PC,nC=sC[l[1572]],{[l[2]]=HC and l[393]or l[229]};
      nC[l[1639]]=JC[l[1459]][l[588]](HC and l[730]or l[786],HC and l[730]or l[786]);
      P(PC,aC,nC);
    else
      dC,ZC=sC[l[1040]],{[l[2]]=HC and l[393]or l[229]};
      ZC[l[1639]]=JC[l[1459]][l[588]](HC and l[310]or l[1092],HC and l[310]or l[1092]);
      P(dC,aC,ZC);
    end
  end
  local function NP()
    local sC=s[87]();
    if not BP[l[1693]] then
      iP[l[1420]]=yC[l[955]]or l[31];
      return;
    end
    local nC=wP();
    iP[l[1420]]=#nC>l[393]and sC[l[1346]][l[978]](nC,l[1200])or l[31];
  end
  local function iP()
    P(vP,H,{[l[1646]]=(yC[l[404]]or zC)and l[393]or l[841]});
    local sC,nC,JC={},l[747],yC[l[404]]and l[1431]or(zC and l[323]or l[1373]);
    sC[nC]=JC;
    P(IP,H,sC);
    P(EP,H,{[l[1646]]=yC[l[404]]and l[874]or l[229]});
    P(kP,H,{[l[916]]=(yC[l[404]]or zC)and l[1209]or l[615]});
    P(gP,H,{[l[2]]=(yC[l[404]]or zC)and l[1296]or l[1431],[l[936]]=yC[l[404]]and R[l[1095]]or R[l[1379]]});
  end
  local function kP()
    NP();
    for IP=l[229],#yC[l[1072]],l[229]do
      MP(yC[l[1072]][IP],l[383]);
    end;
  end
  local function IP()
    local EP=s[87]();
    return EP[l[35]][l[819]](#yC[l[1072]],l[229],XP)*_P+l[730];
  end
  local function XP()
    local EP,sC=s[87](),l[393];
    for nC=l[229],#BP[l[1206]],l[229]do
      local JC,HC=EP[l[1146]](function()
        local fC,aC,dC=s[87](),BP[l[1206]][nC],l[310];
        local nC,PC=fC[l[128]][l[437]][l[1381]],s[70](fC[l[1689]][l[772]](l[329],l[1655]));
        return y[8]:GetTextSize(aC,dC,nC,s:ZT(PC));
      end);
      sC=if JC and HC then EP[l[35]][l[850]](sC,HC[l[1437]])else sC;
    end;
    return EP[l[35]][l[139]](sC)+(BP[l[1693]]and l[205]or l[430]);
  end
  local function EP()
    local sC,nC,JC,HC,fC=s[87](),G(YP),e(YP),G(vP),e(vP);
    local aC,dC=HC[l[1437]]-nC[l[1437]],yC[l[771]]and HC[l[636]]-nC[l[636]]-l[1158]or HC[l[636]]-nC[l[636]]+fC[l[636]]+l[1158];
    aC=if aC+yC[l[559]]>JC[l[1437]]-l[930]then sC[l[35]][l[850]](l[930],HC[l[1437]]-nC[l[1437]]+fC[l[1437]]-yC[l[559]])else aC;
    UP[l[948]]=sC[l[1459]][l[588]](sC[l[35]][l[499]](aC+l[659]),sC[l[35]][l[499]](dC+l[659]));
    if RP then
      RP[l[948]]=UP[l[948]];
    end
  end
  local function sC()
    local nC=s[87]();
    yC[l[434]]=IP();
    UP[l[1639]]=nC[l[1459]][l[588]](yC[l[559]],yC[l[434]]);
    if RP then
      RP[l[1639]]=UP[l[1639]];
    end
    EP();
  end
  local function nC()
    local JC=UP[l[1569]];
    local HC=yC[l[404]]and l[393]or l[229];
    local fC=gP[l[500]];
    local aC=yC[l[404]]and l[1510]or l[393];
    b(UP,yC[l[404]]and l[894]or l[304],yC[l[404]]and N or q,function(dC)
      local PC=JC+(HC-JC)*dC;
      UP[l[1569]]=PC;
      if RP then
        RP[l[1646]]=PC;
        uP[l[747]]=l[615]+l[411]*PC;
      end
      if dC>=l[229] then
        UP[l[1324]]=yC[l[404]];
        if RP then
          RP[l[1324]]=yC[l[404]];
        end
      end
    end);
    b(gP,l[1431],N,function(uP)
      gP[l[500]]=fC+(aC-fC)*uP;
    end);
  end
  local function gP(uP)
    local JC,HC,fC=s[87](),lC[l[464]][l[636]]/y[29],j(LC)[l[636]]+l[310];
    local aC=JC[l[1346]][l[23]](yC[l[1072]],uP);
    if not aC or HC<=l[393]or fC<=HC then
      return;
    end
    uP,fC=l[1158]+(aC-l[229])*_P,lC[l[1690]][l[636]];
    if uP<fC then
      lC[l[1690]]=JC[l[1689]][l[772]](l[393],JC[l[35]][l[850]](uP-l[1158],l[393]));
    elseif uP+l[1660]>fC+HC then
      lC[l[1690]]=JC[l[1689]][l[772]](l[393],uP+l[1596]--[[__newindex]]-HC);
    end
  end
  local function _P(uP)
    local JC=yC[l[1072]][TC];
    TC=uP;
    if JC then
      MP(JC,l[383]);
    end
    uP=yC[l[1072]][TC];
    if uP then
      MP(uP,l[383]);
      gP(uP);
    end
  end
  local function uP(JC)
    if #yC[l[1072]]==l[393] then
      return;
    end
    local HC=TC+JC;
    _P(if HC<l[229]then#yC[l[1072]]else if HC>#yC[l[1072]]then l[229]else HC);
    y[18]:chime(l[1320]);
  end
  local function _P(JC)
    if not JC then
      return;
    end
    if BP[l[1693]] then
      yC[l[1406]--[[]]][JC[l[572]]]=not yC[l[1406]--[[]]][JC[l[572]]]or nil;
      kP();
      y[18]:chime(yC[l[1406]--[[]]][JC[l[572]]]and l[404]or l[676]);
      if BP[l[1617]] then
        I(BP[l[1617]],yC:get());
      end
      return;
    end
    yC:set(JC[l[572]]);
    yC:setopen(l[1329]);
    y[18]:chime(l[1320]);
  end
  local function JC()
    local HC={};
    local fC=s[87]();
    for aC=l[229],#yC[l[1072]],l[229]do
      local dC=yC[l[1072]][aC];
      for aC,aC in y[3],dC[l[608]],nil do
        aC:Disconnect();
      end;
      dC[l[1466]]:Destroy();
    end;
    fC[l[1346]][l[267]](yC[l[1072]]);
    local aC,dC,PC,ZC,GC=BP[l[1693]]and l[1249]or l[1307],BP[l[1693]]and l[730]or l[688],l[229],#BP[l[1206]],l[229];
    for YC=PC,ZC,GC do
      local PC=BP[l[1206]][YC];
      local ZC={[l[572]]=PC,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=YC,[l[711]]=l[913]},lC)};
      D(ZC[l[1466]],l[1158]);
      ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
      ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[913]},ZC[l[1466]]);
      D(ZC[l[1642]],l[1158]);
      K(ZC[l[1642]],l[393],{fC[l[677]][l[772]](l[393],l[393]),fC[l[677]][l[772]](l[1017],l[1373]),fC[l[677]][l[772]](l[229],l[229])});
      ZC[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=fC[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
      local GC,eC=l[1112],{};
      eC[l[1182]]=fC[l[740]][l[772]](l[229],l[393]);
      a(GC,eC,ZC[l[451]]);
      if BP[l[1693]] then
        ZC[l[595]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[551],l[659],l[393]),[l[1639]]=fC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
        D(ZC[l[595]],l[786]);
        ZC[l[741]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1431]},ZC[l[595]]);
        HC[1]=l[1572];
        HC[3]=a;
        HC[4]=l[859];
        HC[2]={};
        HC[2][l[1150]]=f();
        HC[2][l[1016]]=fC[l[1689]][l[772]](l[659],l[659]);
        HC[2][l[948]]=fC[l[1459]][l[1368]](l[659],l[659]);
        HC[2][l[1639]]=fC[l[1459]][l[588]](l[786],l[786]);
        HC[2][l[1646]]=l[229];
        HC[2][l[1451]]=y[30](l[1411]);
        HC[2][l[936]]=R[l[641]];
        HC[2][l[2]]=l[229];
        HC[2][l[1557]]=fC[l[128]][l[1557]][l[220]];
        HC[2][l[711]]=l[1282];
        HC[5]=(HC[3](HC[4],HC[2],ZC[l[595]]));
        ZC[HC[1]]=HC[5];
      else
        HC[6]=l[1040];
        HC[8]=a;
        HC[9]=l[859];
        HC[7]={};
        HC[7][l[1150]]=f();
        HC[7][l[1016]]=fC[l[1689]][l[772]](l[229],l[659]);
        HC[7][l[948]]=fC[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
        HC[7][l[1639]]=fC[l[1459]][l[588]](l[1092],l[1092]);
        HC[7][l[1646]]=l[229];
        HC[7][l[1451]]=y[30](l[1411]);
        HC[7][l[936]]=R[l[98]];
        HC[7][l[2]]=l[229];
        HC[7][l[1557]]=fC[l[128]][l[1557]][l[220]];
        HC[7][l[711]]=l[1526];
        HC[10]=(HC[8](HC[9],HC[7],ZC[l[1466]]));
        ZC[HC[6]]=HC[10];
      end
      ZC[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=fC[l[1459]][l[588]](aC,l[393]),[l[1639]]=fC[l[1459]][l[772]](l[229],-aC-dC,l[229],l[393]),[l[1646]]=l[229],[l[437]]=fC[l[128]][l[437]][l[1381]],[l[1420]]=PC,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=fC[l[128]][l[164]][l[1021]],[l[1634]]=fC[l[128]][l[1634]][l[701]],[l[711]]=l[1526]},ZC[l[1466]]);
      ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1282]},ZC[l[1466]]);
      fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1538]]:Connect(function()
        local HC=yC[l[1072]][TC];
        ZC[l[892]]=l[383];
        TC=l[393];
        if HC and HC~=ZC then
          MP(HC,l[383]);
        end
        MP(ZC,l[383]);
      end));
      fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1628]]:Connect(function()
        ZC[l[892]]=l[1329];
        MP(ZC,l[383]);
      end));
      fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[445]]:Connect(function()
        _P(ZC);
      end));
      yC[l[1072]][YC]=ZC;
      MP(ZC,l[383]);
    end;
  end
  local HC,fC;
  local function aC()
    local dC=HC;
    if dC then
      HC:Disconnect();
      HC=nil;
    end
  end
  local function dC()
    local PC=fC;
    if PC then
      fC:Disconnect();
      fC=nil;
    end
  end
  local function PC()
    yC:setopen(l[1329]);
  end
  local function ZC()
    local GC=S;
    if GC>l[393] then
      EP();
      return;
    end
    if not LP[l[1600]]or not KP[l[1324]]or not xP[l[1324]] then
      PC();
      return;
    end
    local xP,YC,eC,jC,CC,NC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],vP[l[81]],vP[l[160]];
    GC=CC[l[636]]+NC[l[636]]*l[659];
    if GC<xP[l[636]]or GC>xP[l[636]]+YC[l[636]]or GC<eC[l[636]]or GC>eC[l[636]]+jC[l[636]] then
      PC();
      return;
    end
    EP();
  end
  local function WP(VP)
    local xP=s[87]();
    if y[18][l[1333]]or VP[l[1317]]~=xP[l[128]][l[1317]][l[1441]] then
      return;
    end
    local EP=VP[l[880]--[[readu32]]];
    VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1492]];
    if VP then
      uP(l[229]);
    else
      local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1436]];
      if VP then
        uP(l[715]);
      else
        local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1183]]or EP==xP[l[128]][l[880]--[[readu32]]][l[839]];
        if VP then
          _P(yC[l[1072]][TC]);
        elseif EP==xP[l[128]][l[880]--[[readu32]]][l[1739]] then
          PC();
        end
      end
    end
  end
  local function VP(_P,xP)
    local EP={};
    _P=s[87]();
    xP=xP and l[383]or l[1329];
    if yC[l[404]]==xP then
      return;
    end
    yC[l[404]]=xP;
    if xP then
      V();
      local xP,uP,GC,YC=G(YP),e(YP),G(vP),e(vP);
      yC[l[559]]=_P[l[35]][l[819]](_P[l[35]][l[850]](XP(),_P[l[35]][l[499]](YC[l[1437]]+l[659])),l[492],_P[l[35]][l[850]](_P[l[35]][l[499]](uP[l[1437]])-l[829],l[492]));
      yC[l[434]]=IP();
      local XP,vP=uP[l[636]]-(GC[l[636]]-xP[l[636]]+YC[l[636]]+l[1158])-l[1158],GC[l[636]]-xP[l[636]]-l[310];
      yC[l[771]]=XP<yC[l[434]]and vP>XP;
      UP[l[1016]]=_P[l[1689]][l[772]](l[393],yC[l[771]]and l[229]or l[393]);
      UP[l[1324]]=l[383];
      tP[l[1324]]=l[383];
      lC[l[1690]]=_P[l[1689]][l[772]]();
      if RP then
        RP[l[1016]]=UP[l[1016]];
        RP[l[1324]]=l[383];
      end
      sC();
      kP();
      vP=not BP[l[1693]];
      if vP then
        uP,XP,GC=l[229],#yC[l[1072]],l[229];
        for _P=uP,XP,GC do
          xP=yC[l[1072]][_P][l[572]]==yC[l[955]];
          if xP then
            TC=_P;
            MP(yC[l[1072]][_P],l[383]);
            gP(yC[l[1072]][_P]);
            break;
          end
        end;
      end
      A,w=PC,UP;
      aC();
      dC();
      EP[1]=(y[10][l[1119]]:Connect(ZC));
      HC=EP[1];
      EP[2]=(y[9][l[1558]]:Connect(WP));
      fC=EP[2];
    else
      aC();
      dC();
      tP[l[1324]]=l[1329];
      TC=l[393];
      local WP=A==PC;
      if WP then
        A,w=nil,nil;
      end
      for WP=l[229],#yC[l[1072]],l[229]do
        yC[l[1072]][WP][l[892]]=l[1329];
        MP(yC[l[1072]][WP],l[383]);
      end;
    end
    iP();
    nC();
  end
  yC[l[1521]--[[0]]]=VP;
  local function WP(VP)
    if not BP[l[1693]] then
      return yC[l[955]];
    end
    return wP();
  end
  yC[l[506]]=WP;
  local function wP(WP,VP,_P)
    local XP=s[87]();
    if BP[l[1693]] then
      WP={};
      if XP[l[40]](VP)==l[1346] then
        for xP,xP in y[3],VP,nil do
          WP[xP]=l[383];
        end;
      elseif XP[l[40]](VP)==l[409] then
        for xP in XP[l[409]][l[78]](VP,l[397])do
          WP[XP[l[409]][l[56]](xP,l[381])]=l[383];
        end;
      else
        return;
      end
      XP[l[1346]][l[267]](yC[l[1406]--[[]]]);
      for xP=l[229],#BP[l[1206]],l[229]do
        if WP[BP[l[1206]][xP]] then
          yC[l[1406]--[[]]][BP[l[1206]][xP]]=l[383];
        end
      end;
      kP();
      if not _P and BP[l[1617]] then
        I(BP[l[1617]],yC:get());
      end
      return;
    end
    if XP[l[40]](VP)~=l[409]or VP==yC[l[955]]and not y[18][l[921]]or not XP[l[1346]][l[23]](BP[l[1206]],VP) then
      return;
    end
    yC[l[955]]=VP;
    kP();
    if not _P and BP[l[1617]] then
      I(BP[l[1617]],VP);
    end
  end
  yC[l[1255]]=wP;
  local function wP(WP,VP)
    WP=s[87]();
    if WP[l[40]](VP)~=l[1346] then
      return;
    end
    local _P=BP[l[1693]]and yC:get()or yC[l[955]];
    BP[l[1206]]=VP;
    yC[l[955]]=nil;
    WP[l[1346]][l[267]](yC[l[1406]--[[]]]);
    JC();
    if BP[l[1693]] then
      yC:set(_P,l[383]);
    elseif _P and WP[l[1346]][l[23]](VP,_P) then
      yC:set(_P,l[383]);
    else
      yC:set(VP[l[229]],l[383]);
    end
    NP();
    if not yC[l[404]] then
      return;
    end
    if #VP==l[393] then
      PC();
      return;
    end
    sC();
  end
  yC[l[1087]]=wP;
  d(LC:GetPropertyChangedSignal(l[996]),function()
    local wP=s[87]();
    lC[l[392]]=wP[l[1459]][l[588]](l[393],j(LC)[l[636]]+l[310]);
  end);
  d(tP[l[445]],PC);
  d(QP[l[445]],function()
    if #BP[l[1206]]==l[393] then
      return;
    end
    yC:setopen(not yC[l[404]]);
    y[18]:chime(l[1352]);
  end);
  d(QP[l[1538]],function()
    zC=l[383];
    iP();
  end);
  d(QP[l[1628]],function()
    zC=l[1329];
    iP();
  end);
  JC();
  if BP[l[1693]] then
    if BP[l[950]]~=nil then
      yC:set(BP[l[950]]);
    end
  else
    yC:set(BP[l[950]]or BP[l[1206]][l[229]]);
  end
  NP();
  iP();
  y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
    local NP=s[87]();
    if BP[l[1693]] then
      return NP[l[1346]][l[978]](yC:get(),l[1200]);
    end
    return yC[l[955]];
  end,function(NP)
    yC:set(NP);
  end,{[l[284]]=function(NP)
    local wP=s[87]();
    if not BP[l[1693]] then
      return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
    end
    for WP in wP[l[409]][l[78]](NP,l[397])do
      if not wP[l[1346]][l[23]](BP[l[1206]],wP[l[409]][l[56]](WP,l[381])) then
        return l[1329];
      end
    end;
    return l[383];
  end});
  return yC;
end
