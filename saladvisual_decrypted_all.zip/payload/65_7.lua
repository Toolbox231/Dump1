-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #7
-- offset 4292..5553 (1261 bytes, type=payload)

local function G(b,o)
  local c=Instance.new("Part");
  c.Name="VisualsGunCircle";
  local m;
  local m,S=T;
  local S=n;
  c:SetAttribute(m,S);
  c:SetAttribute("VisualsGunAura",true);
  c.Anchored=true;
  c.CanCollide=false;
  c.CanQuery=false;
  c.CanTouch=false;
  c.CastShadow=false;
  c.Transparency=1;
  c.Parent=workspace;
  m=Instance.new("Attachment");
  m.Parent=c;
  local S=Instance.new("ParticleEmitter");
  S:SetAttribute("VisualsGunAura",true);
  S.Rate=0;
  S.TimeScale=0;
  S.Lifetime,S.Speed=NumberRange.new(20),NumberRange.new(0.01);
  S.LightEmission=1;
  S.LightInfluence=0;
  S.LockedToPart=true;
  S.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  S.EmissionDirection=Enum.NormalId.Top;
  S.Rotation,S.RotSpeed=NumberRange.new(0),NumberRange.new(0);
  S.Parent=m;
  local m={Part=c,Emitter=S,Style=L.CircleStyle,Clock=1};
  b.Circle=m;
  task.defer(function()
    local O=s(o);
    local B;
    local B=not z[4][z[6]]or b.Circle~=m or not c.Parent or not O;
    if B then
      return;
    end
    S.Texture=O;
    O={[2]=Enum.ParticleFlipbookLayout.Grid2x2,[4]=Enum.ParticleFlipbookLayout.Grid4x4,[8]=Enum.ParticleFlipbookLayout.Grid8x8};
    if o.frames and O[o.cols] then
      S.FlipbookLayout=O[o.cols];
      S.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
      S.FlipbookStartRandom=false;
      S.FlipbookFramerate=NumberRange.new(0);
    end
    S:Emit(1);
    m.Ready=true;
  end);
  return m;
end
