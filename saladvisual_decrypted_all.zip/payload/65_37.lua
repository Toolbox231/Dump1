-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #37
-- offset 14368..15141 (773 bytes, type=payload)

function(P)
  local O;
  local O=z[4][z[6]];
  if not O then
    return;
  end
  O=os.clock();
  for z,B in pairs(b)do
    local b=(O-B.born)/B.life;
    if b>=1 or not z.Parent then
      z:Destroy();
    else
      local A=B.size*(b<0.4 and 0.35+b/0.4*0.65 or 1+(B.grow-1)*(b-0.4)/0.6);
      z.Size=Vector3.new(A,0.025,A);
      z.CFrame=B.base*CFrame.Angles(0,B.spin*(O-B.born),0);
      B.stroke.Transparency=1-B.bright*(1-b)^1.4;
    end
  end;
  if not(e.Jump or e.Land) then
    return;
  end
  m+=P;
  P=m;
  if P<0.04 then
    return;
  end
  m=0;
  for z,b in pairs(l)do
    P,O=b.human,b.character;
    if P and P.Parent and O.Parent and z.Character==O and s(z) then
      local s=L(O,P);
      if s then
        local L=P.FloorMaterial==Enum.Material.Air;
        if L and not b.floorAir and s.AssemblyLinearVelocity.Y>1 then
          G(b,true);
        elseif not L and b.floorAir then
          j(b);
        end
        b.floorAir=L;
      end
    end
  end;
end
