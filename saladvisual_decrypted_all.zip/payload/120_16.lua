-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #16
-- offset 3651261..3652083 (822 bytes, type=payload)

local function _(X)
  local x=F(X,"Head");
  if not x then
    return;
  end
  X=h(x,CFrame.new(-0.25,0.933,0.259,0.469,-0.25,-0.847,-0.117,0.933,-0.34,0.875,0.259,0.408));
  for k=1,2,1 do
    x=Instance.new("ParticleEmitter");
    x.Lifetime=NumberRange.new(1,1);
    x.SpreadAngle=Vector2.new(5,5);
    x.LockedToPart=true;
    x.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.2,0),NumberSequenceKeypoint.new(0.8,0),NumberSequenceKeypoint.new(1,1)});
    x.LightEmission=1;
    x.Color=ColorSequence.new(N.Color);
    x.Speed=NumberRange.new(0.001,0.001);
    x.Brightness=2;
    x.Size=k==1 and NumberSequence.new(2.5,3)or NumberSequence.new(2,3);
    x.RotSpeed=NumberRange.new(-400,400);
    x.Rate=7;
    x.Texture="rbxassetid://8819682608";
    x.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
    x.Rotation=NumberRange.new(0,360);
    O(x,X);
  end;
end
