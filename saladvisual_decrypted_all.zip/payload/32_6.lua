-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #6
-- offset 228501..231344 (2843 bytes, type=payload)

local function A(w)
  local F=P[w];
  if not F then
    return nil;
  end
  local P,h,W={stars={},beams={},born=os.clock(),sway=math.random()*3.141592653589793*2},{},(Vector3.new(0.0,0.0,0.0));
  for V,_ in ipairs(F.stars)do
    local X=q(_[2],_[3]);
    h[V]=X;
    W+=X;
  end;
  local q,V=#h>0 and W.Magnitude>0.001 and W.Unit or Vector3.new(0.0,1.0,0.0),0;
  for _,_ in ipairs(h)do
    V=math.max(V,math.acos(math.clamp(q:Dot(_),-1,1)));
  end;
  local _=V>O and O/V or 1;
  local function O(V)
    if _>=0.9999 then
      return V;
    end
    local X=math.acos(math.clamp(q:Dot(V),-1,1));
    if X<1.0E-5 then
      return q;
    end
    local x=math.sin(X);
    return(q*(math.sin((1-_)*X)/x)+V*(math.sin(_*X)/x)).Unit;
  end
  W=Vector3.new(0.0,0.0,0.0);
  local q,V=ipairs,F.stars;
  for _,X in q(V)do
    local x,k,v=O(h[_]),Instance.new("Attachment"),L;
    k.Name=v.RandomString();
    k.Position=x*m;
    k.Parent=D;
    local I,i,E=math.clamp((5.2-X[4])/6.2,0.3,1),Instance.new("BillboardGui"),L;
    i.Name=E.RandomString();
    i.Adornee=k;
    i.AlwaysOnTop=false;
    i.LightInfluence=0;
    i.Size=UDim2.fromScale(1,1);
    i.Parent=y;
    v=Instance.new("ImageLabel");
    v.BackgroundTransparency=1;
    v.AnchorPoint=Vector2.new(0.5,0.5);
    v.Position=UDim2.fromScale(0.5,0.5);
    v.Size=UDim2.fromScale(2.4,2.4);
    v.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
    v.Parent=i;
    E=Instance.new("ImageLabel");
    E.BackgroundTransparency=1;
    E.AnchorPoint=Vector2.new(0.5,0.5);
    E.Position=UDim2.fromScale(0.5,0.5);
    E.Size=UDim2.fromScale(1,1);
    E.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
    E.Parent=i;
    local Q;
    if X[1] then
      Q=Instance.new("TextLabel");
      Q.AnchorPoint=Vector2.new(0.5,0);
      Q.Position=UDim2.fromScale(0.5,1);
      Q.Size=UDim2.fromScale(4,0.5);
      Q.BackgroundTransparency=1;
      Q.Font=Enum.Font.Gotham;
      Q.Text=X[1];
      Q.TextSize=11;
      Q.TextTransparency=0.35;
      Q.Visible=false;
      Q.Parent=i;
    else
    end
    W+=x;
    P.stars[_]={anchor=k,board=i,dot=E,halo=v,label=Q,weight=I,aim=x,home=x*m,tint=G[X[1]]or Y,phase=math.random()*3.141592653589793*2,rate=0.5+math.random()*1.3,delay=0.04*_,alpha=0};
  end;
  h=#F.stars>0;
  if h then
    O=W/#F.stars;
    O=O.Magnitude>0.001 and O.Unit or Vector3.new(0.0,1.0,0.0);
    q,V=Instance.new("Attachment"),L;
    q.Name=V.RandomString();
    q.Position=O*m;
    q.Parent=D;
    local G,Y=Instance.new("BillboardGui"),L;
    G.Name=Y.RandomString();
    G.Adornee=q;
    G.AlwaysOnTop=false;
    G.LightInfluence=0;
    G.Size=UDim2.fromScale(1,1);
    G.Enabled=false;
    G.Parent=y;
    Y=Instance.new("TextLabel");
    Y.BackgroundTransparency=1;
    Y.Size=UDim2.fromScale(1,1);
    Y.Font=Enum.Font.Gotham;
    Y.Text=w;
    Y.TextScaled=true;
    Y.TextTransparency=0.45;
    Y.Parent=G;
    P.title={seat=q,board=G,tag=Y,aim=O};
  end
  for G,Y in ipairs(F.lines)do
    h,V=P.stars[Y[1]],P.stars[Y[2]];
    if h and V then
      Y=Instance.new("Beam");
      Y.Attachment0=h.anchor;
      Y.Attachment1=V.anchor;
      Y.FaceCamera=true;
      Y.LightInfluence=0;
      Y.LightEmission=1;
      Y.Segments=1;
      Y.Width0=4;
      Y.Width1=4;
      Y.Parent=D;
      local q,O=P.beams,P.beams;
      local w,F=#O+1,{beam=Y,a=h,b=V};
      F.delay,F.shown,q[w]=0.45+0.05*G,-1,F;
    end
  end;
  return P;
end
