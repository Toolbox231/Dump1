-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #142
-- offset 3307552..3308084 (532 bytes, type=payload)

local function lP(LP,nP)
  local HP={};
  local fP=U;
  if fP then
    local aP=U;
    U=nil;
    aP();
  end
  fP=m;
  if fP then
    m:Disconnect();
    m=nil;
  end
  if not LP then
    HP[1]=y[18];
    HP[2]=l[1333];
    HP[3]=l[1329];
    HP[1][HP[2]]=HP[3];
    return;
  end
  U=nP;
  HP[4]=y[18];
  HP[5]=l[1333];
  HP[6]=l[383];
  HP[4][HP[5]]=HP[6];
  HP[7]=(y[9][l[1558]]:Connect(function(nP)
    local fP=s[87]();
    if nP[l[1317]]~=fP[l[128]][l[1317]][l[1441]]or nP[l[880]--[[readu32]]]==fP[l[128]][l[880]--[[readu32]]][l[605]] then
      return;
    end
    local aP=nP[l[880]--[[readu32]]];
    U=nil;
    lP(nil);
    LP(aP~=fP[l[128]][l[880]--[[readu32]]][l[1739]]and aP or nil);
  end));
  m=HP[7];
end
