-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[82] / function #16
-- offset 30898..31444 (546 bytes, type=payload)

local function y()
  T();
  local T=Y;
  if T then
    return;
  end
  e,j=nil,nil;
  local N;
  local N,p=n;
  T=J;
  Y=N:AddSignal(T.RenderStepped:Connect(function()
    local T=Z and Z.Parent;
    if not T then
      return;
    end
    D();
    T=workspace.CurrentCamera;
    if not T then
      return;
    end
    local n=T.CFrame;
    local J,Y=n.Position,n.LookVector;
    n=Vector3.new(Y.X,0,Y.Z);
    n=if n.Magnitude<0.05 then Vector3.new(0,0,-1)else n.Unit;
    T=e and j and(J-e).Magnitude<10 and n:Dot(j)>0.95;
    if T then
      return;
    end
    e,j=J,n;
    Y=Z;
    Y.CFrame=CFrame.new(J+n*(P.Distance*0.22)+Vector3.new(0,P.Height*0.5-26,0));
  end));
  L();
end
