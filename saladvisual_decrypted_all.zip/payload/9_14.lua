-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #14
-- offset 3631706..3633007 (1301 bytes, type=payload)

local function s()
  local G=r;
  if G then
    return;
  end
  w+=1;
  local p=w;
  if #d==0 then
    S();
  end
  local c;
  G=n;
  r=G.RenderStepped:Connect(T);
  local function T(n,c)
    local S;
    local S=not z[4][z[6]]or not P or p~=w or not n;
    if S then
      return;
    end
    S=o[c];
    if S and S.container==n then
      return;
    end
    if S then
      S.add:Disconnect();
      S.remove:Disconnect();
    end
    local function S(A)
      local V=A.Name~="Gun"or not z[4][z[6]]or p~=w;
      if V then
        return;
      end
      A=m();
      y(true,A);
      Y(A);
    end
    o[c]={container=n,add=n.ChildAdded:Connect(S),remove=n.ChildRemoved:Connect(S)};
  end
  G=not e;
  if G then
    local n=a:FindFirstChild("PlayerGui");
    if n then
      e=n.DescendantAdded:Connect(function(n)
        local c=n.Name=="Crosshair"and n.Parent and n.Parent.Name=="GameTopbar";
        if c then
          local c;
          local c=z[4][z[6]]and P and Z and n:IsA("GuiObject");
          if c then
            F();
          end
        end
      end);
    end
  end
  G=a.Character;
  if G then
    T(G,"character");
  end
  G=a:FindFirstChildOfClass("Backpack");
  if G then
    T(G,"backpack");
  end
  G=a.CharacterAdded:Connect(function(n)
    task.wait(0.3);
    local c;
    local c=not z[4][z[6]]or not P or p~=w or a.Character~=n;
    if c then
      return;
    end
    T(n,"character");
    T(a:FindFirstChildOfClass("Backpack"),"backpack");
    l=m();
    y(true,l);
    Y(l and Z);
  end);
  table.insert(K,G);
  table.insert(K,a.ChildAdded:Connect(function(z)
    if z:IsA("Backpack") then
      T(z,"backpack");
    end
  end));
  l=m();
  y(true,l);
  Y(l and Z);
end
