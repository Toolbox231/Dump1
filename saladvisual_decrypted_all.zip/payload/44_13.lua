-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #13
-- offset 3615554..3616530 (976 bytes, type=payload)

local function b(K,o,c,m)
  m=m or s;
  local S,O=Instance.new("Attachment"),L;
  S.Name=O.RandomString();
  S.Position=Vector3.new(0,m.Size*0.09,0);
  S.Parent=o;
  local B,A=Instance.new("Attachment"),L;
  B.Name=A.RandomString();
  B.Position=Vector3.new(0,-m.Size*0.09,0);
  B.Parent=o;
  A,O=q(m);
  local w,F=Instance.new("Trail"),L;
  w.Name=F.RandomString();
  w.Attachment0=S;
  w.Attachment1=B;
  w.Lifetime=m.Life;
  w.MinLength=0.08;
  w.FaceCamera=true;
  w.LightEmission=c.light;
  w.LightInfluence=0;
  w.Texture=C(c);
  w.TextureMode=Enum.TextureMode.Static;
  w.TextureLength=4;
  w.Color=ColorSequence.new(A,O);
  w.WidthScale=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.5,0.62),NumberSequenceKeypoint.new(1,0)});
  F=1-math.clamp(m.Bright/100,0.05,1);
  w.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,F),NumberSequenceKeypoint.new(0.7,F+(1-F)*0.5),NumberSequenceKeypoint.new(1,1)});
  w.Parent=o;
  l[K]={trail=w,a=S,b=B,root=o,style=c,size=m.Size,life=m.Life,first=A,second=O,cfg=m};
end
