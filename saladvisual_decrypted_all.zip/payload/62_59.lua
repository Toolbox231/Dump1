-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #59
-- offset 3238040..3238382 (342 bytes, type=payload)

local function h(_,k)
  local i;
  local i=not z[4][z[6]]or not N[_];
  if i then
    return;
  end
  k=tonumber(k);
  if not k or k~=k or math.abs(k)==1/0 then
    return;
  end
  b.Sizes[_]=math.clamp(k,0.35,1.25);
  S();
  i=b.Pick==_ and b.On;
  if i then
    K+=1;
    local S=K;
    task.delay(0.12,function()
      local k=S==K and z[4][z[6]]and b.On and b.Pick==_;
      if k then
        P();
      end
    end);
  end
end
