-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #1
-- offset 3643510..3663270 (19760 bytes, type=payload)

function(l,l,L,L)
  local L=l[1];
  local y=l[2];
  local z=l[3];
  local T=l[4];
  local n=l[5];
  local J=l[6];
  local H=l[7];
  local f=l[8];
  local a=l[9];
  local d=l[10];
  local P=l[11];
  local Z=l[12];
  local G=l[13];
  local Y=l[14];
  return function()
    local l,e,j,C={"Angelic","Ambient","Nimb","Tornado","Comet","Angel","Starlight","Heavenly","Ribbon","Sakura","Wind","Flow","Star"},{Angel="97658130917593",Starlight="134645216613107",Heavenly="139300897520961",Ribbon="132069507632161",Sakura="81755778619404",Wind="80694081850877",Flow="119913533725648",Star="73754563740680"},{{"Head"},{"Torso","UpperTorso","LowerTorso","HumanoidRootPart"},{"Left Arm","LeftUpperArm","LeftLowerArm","LeftHand"},{"Right Arm","RightUpperArm","RightLowerArm","RightHand"},{"Left Leg","LeftUpperLeg","LeftLowerLeg","LeftFoot"},{"Right Leg","RightUpperLeg","RightLowerLeg","RightFoot"}},{};
    for N,N in ipairs(j)do
      for q,q in ipairs(N)do
        C[q]=N;
      end;
    end;
    local N,q={On=false,Color=Color3.fromRGB(133,220,255),Types={},Type="Angelic",Target="Self",Glow=2,Rate=1,Size=1,Tint=true,Speed=1,Radius=0.55,TrailLength=100,TrailStep=1.5,BloomSize=150,LoadErrors={},ReadyTypes={}};
    j=L;
    j.Aura=N;
    local function q(b)
      return{attachments={},borrowed={},particles={},accents={},color=b or N.Color};
    end
    local b=q();
    local D,p=b;
    local r,K=0,L;
    local o,c=K.GameFX;
    if o then
      j=L;
      c=j.GameFX.ProtectTexture;
    else
      c=o;
    end
    local function m(S)
      S.generation=(S.generation or 0)+1;
      for O=1,#S.attachments,1 do
        if S.attachments[O]and S.attachments[O].Parent then
          S.attachments[O]:Destroy();
        end
      end;
      for O=1,#S.borrowed,1 do
        if S.borrowed[O]and S.borrowed[O].Parent then
          pcall(function()
            S.borrowed[O]:Destroy();
          end);
        end
      end;
      S.attachments={};
      S.borrowed={};
      S.particles={};
      S.accents={};
    end
    local function S()
      m(b);
      table.clear(N.ReadyTypes);
    end
    local O;
    local function O(B,A)
      B.Parent=A;
      A=y;
      A.FxDepth(B,false);
      if c then
        c(B);
      end
      D.particles[#D.particles+1]={emitter=B,rate=B.Rate,bright=B.Brightness,size=B.Size,color=B.Color,speed=B.Speed,rotation=B.RotSpeed,life=B.Lifetime,emission=B.LightEmission};
      return B;
    end
    local function B(A,w)
      if w==1 then
        return A;
      end
      local F={};
      for h,W in ipairs(A.Keypoints)do
        F[h]=NumberSequenceKeypoint.new(W.Time,W.Value*w,W.Envelope*w);
      end;
      return NumberSequence.new(F);
    end
    local A={};
    local function w(F,h,W)
      local V=F.color;
      local _,X=h or 1,#F.particles;
      for x=_,X,1 do
        h=F.particles[x];
        x=h.emitter;
        local k=x.Parent;
        if k then
          local k=y;
          k.FxDepth(x,false);
          x.Color=N.Tint and ColorSequence.new(V)or h.color;
          x.Rate=h.rate*N.Rate;
          x.Brightness=h.bright*N.Glow*0.5;
          x.Size=B(h.size,N.Size);
          k=math.clamp(N.Speed,0.05,5);
          x.Speed=NumberRange.new(h.speed.Min*k,h.speed.Max*k);
          x.RotSpeed=NumberRange.new(h.rotation.Min*k,h.rotation.Max*k);
          x.Lifetime=NumberRange.new(math.max(0.05,h.life.Min/k),math.max(0.06,h.life.Max/k));
          x.LightEmission=math.clamp(h.emission+(N.Glow*0.5-1)*0.5,0,1);
        end
      end;
      _,X=W or 1,#F.accents;
      for B=_,X,1 do
        local _=F.accents[B];
        local B=_.item;
        h=B.Parent;
        if h then
          W=y;
          W.FxDepth(B,false);
          pcall(function()
            local F=N.Tint and V or nil;
            if B:IsA("PointLight")or B:IsA("SpotLight")or B:IsA("SurfaceLight") then
              B.Color=F or _.color;
              B.Brightness=_.brightness*N.Glow*0.5;
            elseif B:IsA("Beam")or B:IsA("Trail") then
              B.Color=F and ColorSequence.new(F)or _.color;
            elseif B:IsA("Fire") then
              B.Color,B.SecondaryColor=F or _.color,F or _.color2;
            elseif B:IsA("Smoke") then
              B.Color=F or _.color;
            elseif B:IsA("Sparkles") then
              B.SparkleColor=F or _.color;
            elseif B:IsA("Highlight") then
              B.FillColor,B.OutlineColor=F or _.color,F or _.color2;
            elseif B:IsA("Decal") then
              B.Color3=F or _.color;
            elseif B:IsA("BasePart") then
              B.Color=F or _.color;
              if _.texture then
                B.TextureID=F and""or _.texture;
              end
            end
          end);
        end
      end;
    end
    local function B()
      b.color=N.Color;
      w(b);
      for F,F in pairs(A)do
        w(F);
      end;
      local F=L;
      local h=F.GameFX;
      if h then
        F=L;
        local h,W=F.GameFX.Tune,{glow=N.Glow*0.5,rate=N.Rate,size=N.Size,speed=N.Speed};
        W.color=N.Tint and ColorSequence.new(N.Color)or nil;
        h("aura",W);
      end
    end
    local function F(h,...)
      local W={...};
      for V,_ in ipairs(W)do
        V=h:FindFirstChild(_);
        if V then
          return V;
        end
      end;
      return nil;
    end
    local function h(W,V)
      local _=Instance.new("Attachment");
      _.CFrame=V;
      _.Parent=W;
      D.attachments[#D.attachments+1]=_;
      return _;
    end
    local function W(V)
      local _=F(V,"Torso","UpperTorso");
      if not _ then
        return;
      end
      local X,x=h(_,CFrame.new(-1.012,0.5,0.852,0.966,0,0.259,0,1,0,-0.259,0,0.966)),Instance.new("ParticleEmitter");
      x.Lifetime=NumberRange.new(1,1);
      x.LockedToPart=true;
      x.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,0.944),NumberSequenceKeypoint.new(0.2,0),NumberSequenceKeypoint.new(0.8,0),NumberSequenceKeypoint.new(1,1)});
      x.LightEmission=1;
      x.Color=ColorSequence.new(N.Color);
      x.Speed=NumberRange.new(0.05,0.05);
      x.Size=NumberSequence.new(2.75,3.5);
      x.Rate=4;
      x.Texture="rbxassetid://13267054240";
      x.EmissionDirection=Enum.NormalId.Back;
      x.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
      x.Rotation=NumberRange.new(-15,-15);
      O(x,X);
      X,V=h(_,CFrame.new(1.167,0.5,0.852,0.966,0,-0.259,0,1,0,0.259,0,0.966)),x:Clone();
      V.EmissionDirection=Enum.NormalId.Front;
      O(V,X);
      V,X=h(_,CFrame.new(0,0.3,0)),Instance.new("ParticleEmitter");
      X.Lifetime=NumberRange.new(2,2);
      X.FlipbookLayout=Enum.ParticleFlipbookLayout.Grid4x4;
      X.SpreadAngle=Vector2.new(180,180);
      X.LockedToPart=true;
      X.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.5,0.3),NumberSequenceKeypoint.new(1,1)});
      X.LightEmission=1;
      X.Color=ColorSequence.new(N.Color);
      X.Speed=NumberRange.new(0.5,0.5);
      X.Brightness=2;
      X.Size=NumberSequence.new(3,4);
      X.Rate=5;
      X.Texture="rbxassetid://11402221943";
      X.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
      X.Rotation=NumberRange.new(0,360);
      O(X,V);
    end
    local function V(_)
      local X=F(_,"HumanoidRootPart");
      if not X then
        return;
      end
      local x,k,v=h(X,CFrame.new(0,-2.75,0)),NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.3,1),NumberSequenceKeypoint.new(0.6,2.5),NumberSequenceKeypoint.new(0.8,4),NumberSequenceKeypoint.new(1,6)}),Instance.new("ParticleEmitter");
      v.Lifetime=NumberRange.new(2,2);
      v.SpreadAngle=Vector2.new(0.001,0.001);
      v.LockedToPart=true;
      v.Transparency=NumberSequence.new(0,1);
      v.LightEmission=1;
      v.Color=ColorSequence.new(N.Color);
      v.Squash=NumberSequence.new(0);
      v.Speed=NumberRange.new(0.001,0.001);
      v.Brightness=2;
      v.Size=k;
      v.RotSpeed=NumberRange.new(-600,600);
      v.Texture="rbxassetid://12713358087";
      v.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
      v.Rotation=NumberRange.new(0,360);
      O(v,x);
      _=Instance.new("ParticleEmitter");
      _.Lifetime=NumberRange.new(2,2);
      _.SpreadAngle=Vector2.new(0.001,0.001);
      _.LockedToPart=true;
      _.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.6,0.2),NumberSequenceKeypoint.new(1,1)});
      _.LightEmission=1;
      _.Color=ColorSequence.new(N.Color);
      _.Squash=NumberSequence.new(0,2);
      _.Speed=NumberRange.new(0.001,0.001);
      _.Brightness=2;
      _.Size=k;
      _.RotSpeed=NumberRange.new(-30,30);
      _.Texture="rbxassetid://7216849325";
      _.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
      _.Rotation=NumberRange.new(0,360);
      O(_,x);
      X=Instance.new("ParticleEmitter");
      X.Lifetime=NumberRange.new(2,2);
      X.SpreadAngle=Vector2.new(0.001,0.001);
      X.LockedToPart=true;
      X.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.2,0.3),NumberSequenceKeypoint.new(1,1)});
      X.LightEmission=1;
      X.Color=ColorSequence.new(N.Color);
      X.Squash=NumberSequence.new(0);
      X.Speed=NumberRange.new(0.001,0.001);
      X.Brightness=2;
      X.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.3,2),NumberSequenceKeypoint.new(0.6,5),NumberSequenceKeypoint.new(0.8,8),NumberSequenceKeypoint.new(1,12)});
      X.RotSpeed=NumberRange.new(-40,40);
      X.Texture="rbxassetid://7216855136";
      X.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
      X.Rotation=NumberRange.new(0,360);
      O(X,x);
    end
    local function _(X)
      local x=F(X,"Head");
      if not x then
        return;
      end
      X=h(x,CFrame.new(-0.25,0.933,0.259,0.469,-0.25,-0.847,-0.117,0.933,-0.34,0.875,0.259,0.408));
      for k=1,2,1 do
        x=Instance.new("ParticleEmitter");
        x.Lifetime=NumberRange.new(1,1);
        x.SpreadAngle=Vector2.new(5,5);
        x.LockedToPart=true;
        x.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.2,0),NumberSequenceKeypoint.new(0.8,0),NumberSequenceKeypoint.new(1,1)});
        x.LightEmission=1;
        x.Color=ColorSequence.new(N.Color);
        x.Speed=NumberRange.new(0.001,0.001);
        x.Brightness=2;
        x.Size=k==1 and NumberSequence.new(2.5,3)or NumberSequence.new(2,3);
        x.RotSpeed=NumberRange.new(-400,400);
        x.Rate=7;
        x.Texture="rbxassetid://8819682608";
        x.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
        x.Rotation=NumberRange.new(0,360);
        O(x,X);
      end;
    end
    local function X(x)
      local k=F(x,"HumanoidRootPart");
      if not k then
        return;
      end
      local x,v=h(k,CFrame.new(0,-3,0)),Instance.new("ParticleEmitter");
      v.LightInfluence=1;
      v.LockedToPart=true;
      v.LightEmission=1;
      v.Color=ColorSequence.new(N.Color);
      v.Speed=NumberRange.new(0.01,0.01);
      v.Size=NumberSequence.new(6,10);
      v.RotSpeed=NumberRange.new(360,360);
      v.Rate=1;
      v.Texture="rbxassetid://8553497052";
      v.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
      O(v,x);
    end
    local h,x={},{};
    local function k(v)
      if h[v]~=nil then
        return h[v]or nil;
      end
      local I,i=x[v];
      if I then
        local i=os.clock()+13;
        while true do
          task.wait(0.03);
          local E=not x[v]or not z[4][z[6]];
          if E or os.clock()>=i then
            break;
          end
        end;
        return h[v];
      end
      local i=e[v];
      if not i then
        return nil;
      end
      x[v]=true;
      local E;
      I=T;
      local E,Q=I.objects(function()
        local t,R=game,"rbxassetid://"..i;
        return t:GetObjects(R);
      end);
      x[v]=nil;
      I=E and type(Q)=="table"and Q[1]or nil;
      if type(Q)=="table" then
        for x=2,#Q,1 do
          pcall(function()
            Q[x]:Destroy();
          end);
        end;
      end
      E=z[4][z[6]];
      if not E then
        if I then
          I:Destroy();
        end
        return nil;
      end
      h[v]=I;
      if I then
        N.LoadErrors[v]=nil;
      else
        N.LoadErrors[v]="Asset unavailable: "..i;
      end
      return I;
    end
    local function x(v,I)
      local i=v:FindFirstChild(I,true);
      if i and(i:IsA("BasePart")) then
        return i;
      end
      for i,E in ipairs(C[I]or{})do
        i=v:FindFirstChild(E,true);
        if i and(i:IsA("BasePart")) then
          return i;
        end
      end;
      return nil;
    end
    local function C(v)
      local function I(i,E,Q)
        Q,D=Q or D,b;
        local t,R,g=k(v),Q==b;
        local k=not t or not z[4][z[6]]or not i.Parent;
        if k then
          return;
        end
        k=nil;
        if R then
          local v=not N.On or E~=r;
          if v then
            k=v;
          else
            local v;
            local v=n;
            k=v.Character~=i;
          end
        else
          k=R;
        end
        if k then
          return;
        end
        if not R and(Q.char~=i or Q.generation~=E) then
          return;
        end
        R=D;
        k=R;
        D=Q;
        R=t:Clone();
        for v,v in ipairs(R:GetDescendants())do
          if v:IsA("LuaSourceContainer") then
            v:Destroy();
          end
        end;
        t,E=ipairs,s[70](R:GetChildren());
        for v,Q in t(s:ZT(E))do
          v=x(i,Q.Name)or F(i,"UpperTorso","Torso","HumanoidRootPart");
          if v then
            local F,x=ipairs,s[70](Q:GetChildren());
            for i,E in F(s:ZT(x))do
              E.Parent=v;
              D.borrowed[#D.borrowed+1]=E;
              i=E:GetDescendants();
              i[#i+1]=E;
              for s,F in ipairs(i)do
                E=F:IsA("ParticleEmitter");
                if E then
                  O(F,F.Parent);
                else
                  s=F:IsA("Light")or F:IsA("Beam")or F:IsA("Trail");
                  if s then
                    if c and(F:IsA("Beam")or F:IsA("Trail")) then
                      c(F);
                    end
                    local s,c=D.accents,D.accents;
                    local O,x=#c+1,{item=F,color=F.Color};
                    x.brightness,s[O]=F:IsA("Light")and F.Brightness or 1,x;
                  else
                    local s=F:IsA("Fire");
                    if s then
                      D.accents[#D.accents+1]={item=F,color=F.Color,color2=F.SecondaryColor};
                    else
                      local s=F:IsA("Smoke");
                      if s then
                        D.accents[#D.accents+1]={item=F,color=F.Color};
                      else
                        local s=F:IsA("Sparkles");
                        if s then
                          D.accents[#D.accents+1]={item=F,color=F.SparkleColor};
                        else
                          local s=F:IsA("Highlight");
                          if s then
                            D.accents[#D.accents+1]={item=F,color=F.FillColor,color2=F.OutlineColor};
                          else
                            local s=F:IsA("Decal")and F.Transparency<1;
                            if s then
                              D.accents[#D.accents+1]={item=F,color=F.Color3};
                            else
                              local s=F:IsA("BasePart")and F.Transparency<1;
                              if s then
                                local s,c=D.accents,D.accents;
                                local O,x=#c+1,{item=F,color=F.Color};
                                x.texture,s[O]=F:IsA("MeshPart")and F.TextureID or nil,x;
                              end
                            end
                          end
                        end
                      end
                    end
                  end
                end
              end;
            end;
          end
        end;
        R:Destroy();
        D=k;
      end
      return I;
    end
    j=y;
    local s,c,O=j.gui("comet aura",-7),{};
    local j,F,x=0,0;
    local k,v,I=false,0;
    N.CometSprites=c;
    local function i()
      for E,E in ipairs(c)do
        if E.Visible then
          E.Visible=false;
        end
      end;
    end
    local function E()
      local Q=x;
      if Q then
        x:Disconnect();
        x=nil;
      end
      j=0;
      i();
    end
    local function Q()
      local t=O or k or os.clock()<v;
      if t then
        return;
      end
      k=true;
      task.spawn(function()
        local t,R=pcall(function()
          local g;
          local g,u=T,T;
          return g.id(u.file("particles/comet_bloom.png"));
        end);
        k=false;
        local T;
        local T=z[4][z[6]]and t;
        if T then
          O=R;
        end
        t=not O;
        if t then
          v=os.clock()+5;
        end
      end);
    end
    local function T(k)
      local v;
      local v=z[4][z[6]];
      if not v then
        return;
      end
      v=not(N.On and N.Types.Comet)and F<=0;
      if v then
        E();
        return;
      end
      local t;
      v=n;
      local t=v.Character;
      local R,g=t and(t:FindFirstChild("UpperTorso")or t:FindFirstChild("Torso")or t:FindFirstChild("HumanoidRootPart")),y;
      v=g.camera();
      local y,u,U=N.On and N.Types.Comet and R and R:IsA("BasePart")and v,math.clamp,F;
      F=u(U+(y and k or-k)/0.35,0,1);
      u=not R or not v or F<=0;
      if u then
        g=F<=0 and not(N.On and N.Types.Comet);
        if g then
          E();
        else
          i();
        end
        return;
      end
      j+=k;
      g=j;
      if g<0.03333333333333333 then
        return;
      end
      j%=0.03333333333333333;
      g=L;
      if not g.Visibility.Part(v,R,t) then
        i();
        return;
      end
      g=O;
      if not g then
        Q();
        i();
        return;
      end
      g,k,y=math.clamp(math.floor(N.TrailLength),20,300),math.max(1.5,(v.CFrame.Position-R.Position).Magnitude),DateTime.now().UnixTimestampMillis;
      u,t=math.clamp(N.BloomSize*N.Size*v.ViewportSize.Y/720/k,1,160),I;
      U=t~=N.Color;
      I=N.Color;
      k,t=g-1,0;
      for j=0,k,1 do
        local k=0.1*(y-j*1.5*300/g*N.TrailStep)/(30/N.Speed);
        local I,i,M=math.sin(k)*N.Radius,math.cos(k)*N.Radius,j/g;
        local g,sP,lP=math.max(1,u*(1-M)^1.1),math.clamp,F;
        k=sP(lP*(1-M*M)*0.4*N.Glow*0.5,0,0.95);
        for u=1,3,1 do
          sP=u==1 and Vector3.new(I,i,-i)or u==2 and Vector3.new(-I,I,-i)or Vector3.new(-I,-I,i);
          t+=1;
          lP=c[t];
          u=not lP;
          if u then
            lP=Instance.new("ImageLabel");
            lP.Name="VisualsCometBloom";
            lP.BackgroundTransparency=1;
            lP.BorderSizePixel=0;
            local I,i=Vector2.new(0.5,0.5),O;
            lP.AnchorPoint=I;
            lP.Image=i;
            lP.ImageColor3=N.Color;
            lP.Parent=s;
            c[t]=lP;
          else
          end
          if U then
            lP.ImageColor3=N.Color;
          end
          M,u=v:WorldToViewportPoint(R.Position+sP);
          lP.Visible=u and M.Z>0 and k>0.005;
          if lP.Visible then
            lP.Position,lP.Size=UDim2.fromOffset(M.X,M.Y),UDim2.fromOffset(g,g);
            lP.ImageTransparency=1-k;
            lP.Rotation=(y/5+j*5)%180;
          end
        end;
      end;
      for s=#c,t+1,-1 do
        c[s]:Destroy();
        c[s]=nil;
      end;
    end
    local function s()
      local y=N.On and N.Types.Comet;
      if y then
        Q();
        local y=not x;
        if y then
          local y;
          local y,j=J;
          local j=H;
          x=y:AddSignal(j.RenderStepped:Connect(T));
        end
      else
        local y=F;
        if y<=0 then
          E();
        end
      end
    end
    local y={Angelic=W,Ambient=V,Nimb=_,Tornado=X,Comet=function()
    end};
    for T in pairs(e)do
      y[T]=C(T);
    end;
    local function T()
      r+=1;
      local H=r;
      S();
      s();
      local j;
      local j=z[4][z[6]]and N.On;
      if not j then
        return;
      end
      local O;
      j=n;
      local O=j.Character;
      if not O then
        return;
      end
      task.defer(function()
        local j=ipairs;
        for F,V in j(l)do
          F=N.Types[V];
          if F then
            local F,x,k=y[V],H~=r or not z[4][z[6]]or not N.On;
            if x then
              k=x;
            else
              local v=n;
              k=v.Character~=O;
            end
            if k then
              return;
            end
            if F then
              local v,I,i,Q=#b.particles+1,#b.accents+1,pcall(F,O,H);
              k=not i and H==r;
              if k then
                N.LoadErrors[V]=tostring(Q);
                local O;
                x=f;
                x("aura "..V..": "..tostring(Q));
              end
              Q=i and H==r;
              if Q then
                N.ReadyTypes[V]=true;
                w(b,v,I);
              end
            end
          end
        end;
        local f;
        local f,O=a;
        if f then
          j=a;
          O=j.ReadAura;
        else
          O=f;
        end
        f=O and z[4][z[6]]and H==r;
        if f then
          pcall(a.ReadAura);
        end
      end);
    end
    local function H()
      if not N.On then
        return;
      end
      task.wait(0.5);
      local f;
      local f=z[4][z[6]]and N.On;
      if f then
        T();
      end
    end
    local function f(j)
      r+=1;
      N.On=j and true or false;
      s();
      j=N.On;
      if j then
        local s,j=not p;
        if s then
          local j;
          local j,O=J,n;
          p=j:AddSignal(O.CharacterAdded:Connect(H));
        end
        s=n;
        local J=s.Character;
        if J then
          task.spawn(function()
            task.wait(0.2);
            local s;
            local s=z[4][z[6]]and N.On;
            if s then
              T();
            end
          end);
        end
      else
        local s=p;
        if s then
          pcall(function()
            p:Disconnect();
          end);
          p=nil;
        end
        S();
      end
    end
    N.Dress=function(s,J,H)
      local j,O=not s;
      if j then
        O=j;
      else
        local F;
        local F=n;
        O=s==F;
      end
      if O then
        return;
      end
      O=A[s];
      if not O then
        O=q(H);
        A[s]=O;
      else
      end
      j=H or O.color;
      s=O.color~=j;
      O.color=j;
      j=table.concat(J or{},",");
      if O.wantKey~=j then
        O.generation=(O.generation or 0)+1;
        O.key=nil;
      elseif s then
        w(O);
      end
      O.want=J or{};
      O.wantKey=j;
    end;
    N.Undress=function(s)
      local J=A[s];
      if not J then
        return;
      end
      m(J);
      A[s]=nil;
    end;
    N.Guests=function()
      return A;
    end;
    local function s(J,H)
      local j=J.Character;
      if not j or not j.Parent then
        if H.char then
          m(H);
          H.char=nil;
        end
        return;
      end
      local q=H.wantKey;
      if H.char==j and H.key==q then
        return;
      end
      m(H);
      H.char=j;
      H.key=q;
      local m,O,F,V=H.generation,ipairs,H.want;
      for V,x in O(F)do
        V=not z[4][z[6]]or A[J]~=H or H.generation~=m or J.Character~=j;
        if V then
          return;
        end
        V=y[x];
        q=V and x~="Comet";
        if q then
          D=H;
          pcall(V,j,m,H);
          D=b;
        end
      end;
      O=z[4][z[6]]and A[J]==H and H.generation==m and J.Character==j;
      if O then
        w(H);
      end
    end
    task.spawn(function()
      while true do
        local J;
        local J=z[4][z[6]];
        if not J then
          break;
        end
        task.wait(0.5);
        for z,J in pairs(A)do
          if not z.Parent then
            N.Undress(z);
          else
            pcall(s,z,J);
          end
        end;
      end;
    end);
    local s;
    K=d;
    K("aura guests",function()
      for s in pairs(A)do
        pcall(N.Undress,s);
      end;
    end);
    local s=L;
    s.AuraSource=function()
      local s;
      local s=n;
      return s.Character;
    end;
    local function s()
      local z;
      local z,n=a;
      if z then
        local J=a;
        n=J.ReadAura;
      else
        n=z;
      end
      if n then
        pcall(a.ReadAura);
      end
    end
    local z;
    X=P;
    W=X.Aura:AddLabel("Aura");
    W:AddToggle({Name="Aura",Default=false,Flag="aura",Callback=function(z)
      f(z);
      if N.WearGame then
        N.WearGame();
      end
      s();
    end});
    W:AddColorPicker({Default=N.Color,Flag="aura_color",Callback=function(z)
      N.Color=z;
      local n,J=not N.Tint;
      if n then
        local H;
        z=Z;
        J=(z());
      else
        J=n;
      end
      if J then
        local z;
        n=G;
        n("aura_tint",true);
      end
      B();
      s();
    end});
    C=L;
    local z,n,J=C.GameFX,{},{Angelic="rbxassetid://13267054240",Ambient="rbxassetid://12713358087",Nimb="rbxassetid://8819682608",Tornado="rbxassetid://8553497052",Comet="rbxassetid://11402221943"};
    local function H()
      local f={};
      for a,a in ipairs(l)do
        local Z,G,j=J[a];
        if z then
          Z,G,j=z.Art("builtin/aura/"..a,J[a]);
        else
        end
        local J,q=#f+1,{name=a,label=a,image=Z,rect=G,rectsize=j};
        q.id,f[J]=not G and tonumber(e[a])or nil,q;
      end;
      for J,J in ipairs(z and z.Catalog or{})do
        if J.kind~="Trail"and J.kind~="Cosmetic" then
          f[#f+1]=z.Row(J);
        end
      end;
      return f;
    end
    N.WearGame=function()
      if z then
        z.SetGroup("aura",N.On and n or{});
      end
    end;
    local J;
    C=Y;
    _,K=C.Auras,{Name="Auras",Icon="sparkles",Position="left",Height=440,Cell=74,Reset=true,Smooth=true,Thumb="Asset",Blank="sparkles",Empty="No auras",Values=H(),Default={"Angelic"},Multi=true,Flag="aura_types"};
    local function J(f)
      local a,Z={},{};
      if type(f)=="table" then
        for G,e in pairs(f)do
          local j=type(G)=="string"and e and G or e;
          if type(j)=="string" then
            if y[j] then
              a[j]=true;
            elseif z and z.ById[j] then
              Z[#Z+1]=j;
            end
          end
        end;
      elseif type(f)=="string" then
        a[f]=true;
      end
      n=Z;
      N.WearGame();
      N.Types=a;
      N.Type=nil;
      for y,y in ipairs(l)do
        if a[y] then
          N.Type=y;
          break;
        end
      end;
      if not N.Type and next(a) then
        N.Type="Angelic";
      end
      T();
      s();
    end
    K.Callback=J;
    local l,y=_:AddGallery(K),P;
    y.Aura:AddButton({Name="Unequip All",Callback=function()
      pcall(function()
        l:set({});
      end);
    end});
    if z then
      z.OnThumbs(function()
        l:setdata(H());
      end);
      _=Y;
      o,W=_.Auras,function(l)
        if l then
          z.LoadThumbs();
        end
      end;
      o.Signal:Connect(W);
    end
    C=P;
    C.Aura:AddLabel("Custom Colors"):AddToggle({Default=true,Flag="aura_tint",Callback=function(l)
      N.Tint=l;
      B();
      s();
    end});
    B();
    y,J=ipairs,{{"Glow","Glow","aura_glow",0,600,200,100},{"Rate","Rate","aura_rate",10,400,100,100},{"Size","Size","aura_size",25,300,100,100},{"Speed","Speed","aura_speed",5,500,100,100}};
    for l,l in y(J)do
      local y=l[2];
      local T,n=l[7],P;
      n.Aura:AddLabel(l[1]):AddSlider({Min=l[4],Max=l[5],Default=l[6],Rounding=0,Size=90,Flag=l[3],Callback=function(l)
        N[y]=l/T;
        B();
        s();
      end});
    end;
    _,C=L,d;
    _.ClearAura=C("aura",function()
      N.On=false;
      if z then
        pcall(z.SetGroup,"aura",{});
      end
      r+=1;
      local s=p;
      if s then
        pcall(function()
          p:Disconnect();
        end);
        p=nil;
      end
      S();
      E();
      table.clear(c);
      for s,s in pairs(h)do
        if s then
          pcall(function()
            s:Destroy();
          end);
        end
      end;
      table.clear(h);
    end);
  end;
end
