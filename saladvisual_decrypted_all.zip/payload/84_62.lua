-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #62
-- offset 3678679..3679175 (496 bytes, type=payload)

local function C()
  local q,b=pcall(function()
    local D=y;
    local p=D.download("https://raw.githubusercontent.com/7yd7/sniper-Emote/refs/heads/test/EmoteSniper.json");
    if p and p~="" then
      return game:GetService("HttpService"):JSONDecode(p).data or{};
    end
  end);
  if q and type(b)=="table" then
    local q={};
    for D,p in pairs(b)do
      D=type(p)=="table"and tonumber(p.id);
      if D and D>0 and D<9007199254740992 and D%1==0 then
        local b,r=#q+1,{id=D};
        r.name,q[b]=j(p.name or"Emote_"..D),r;
      end
    end;
    return q;
  end
  return{};
end
