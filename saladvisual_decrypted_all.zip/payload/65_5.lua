-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #5
-- offset 4015..4244 (229 bytes, type=payload)

function()
  local b,o,c={},ipairs;
  for c,m in o(q)do
    c=z[4][z[6]];
    if not c then
      return;
    end
    c=s(j[m]);
    if c then
      b[#b+1]=c;
    end
    task.wait();
  end;
  o=z[4][z[6]]and#b>0;
  if o then
    local o=L;
    o.invoke(function()
      G:PreloadAsync(b);
    end,8);
  end
end
