-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #18
-- offset 3666570..3667579 (1009 bytes, type=payload)

local function m(S)
  local O=tostring(S.id);
  if c[O] then
    return c[O];
  end
  local B=S.bundledItems;
  if type(B)~="table" then
    return nil;
  end
  local A={};
  local w,F=os.clock()+30,pairs;
  for h,W in F(B)do
    h=type(W)=="table";
    if h then
      S=pairs;
      for B,F in S(W)do
        local S,h=not l.Alive;
        if S then
          h=S;
        else
          B=y;
          h=not B.current();
        end
        if h or os.clock()>=w then
          return nil;
        end
        h=y;
        B,S=h.objects(function()
          local w,h=game,"rbxassetid://"..tostring(F);
          return w:GetObjects(h);
        end);
        if B and S then
          local function B(w,F)
            for h,W in ipairs(w:GetChildren())do
              if W:IsA("Animation") then
                h=N(W.AnimationId);
                if h then
                  local w=(F.."."..W.Name):split(".");
                  local V;
                  for _ in(F.."."..W.Name):gmatch("[^.]+")do
                    local X=_:lower();
                    V=if X:find("r15",1,true)then"R15"else if X:find("r6",1,true)then"R6"else V;
                  end;
                  A[#A+1]={category=w[#w-1],name=w[#w],id=h,rig=V};
                end
              elseif #W:GetChildren()>0 then
                B(W,F.."."..W.Name);
              end
            end;
          end
          for w,w in ipairs(S)do
            B(w,w.Name);
            pcall(function()
              w:Destroy();
            end);
          end;
        end
      end;
    end
  end;
  c[O]=next(A)and A or nil;
  return A;
end
