-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #32
-- offset 3253777..3255202 (1425 bytes, type=payload)

local function d(C)
  local K;
  local K=T[4][T[6]]and(Y.On or Y.Circle);
  if not K then
    if next(j) then
      H();
    end
    return;
  end
  r+=C;
  K=r>=0.25;
  if K then
    r=0;
    a=J();
    local T,J={},a;
    for o,o in ipairs(J)do
      T[o.object]=true;
    end;
    for J in pairs(j)do
      if not T[J] then
        A(J);
      end
    end;
  end
  K=y;
  local y=K.camera();
  if not y then
    return;
  end
  local T,J=ipairs,a;
  for o,S in T(J)do
    o,K=S.object,S.part;
    local T=not(o.Parent and K and K.Parent);
    if T then
      A(o);
    else
      local T,J=j[o],L;
      local O=J.Visibility.Part(y,K,o);
      if not T then
        T={};
        j[o]=T;
      else
      end
      if not T.glow then
        J=Instance.new("Highlight");
        J.DepthMode=Enum.HighlightDepthMode.Occluded;
        J.Parent=q;
        T.glow=J;
      end
      T.glow.Adornee=S.adorn;
      T.glow.OutlineColor=Y.Outline;
      T.glow.OutlineTransparency=0;
      T.glow.FillColor=Y.Outline;
      T.glow.FillTransparency=math.clamp(Y.Fill,0,1);
      T.glow.Enabled=Y.On and O;
      if Y.On then
        f(T,o,K,O);
      else
        B(T);
      end
      local f,q=Y.Circle;
      if f then
        J=L;
        q=J.StaticGunCircle;
      else
        q=f;
      end
      if q then
        J=L;
        J.StaticGunCircle(T,o,K,C);
      elseif T.Circle then
        T.Circle.Part:Destroy();
        T.Circle=nil;
      end
      J=Y.On and Y.Text;
      if J then
        f=not T.label;
        if f then
          local J;
          q=P;
          local J=q("Text");
          J.Center=true;
          J.Outline=true;
          J.Size=13;
          J.Font=2;
          T.label=J;
        end
        local J,f=y:WorldToViewportPoint(K.Position);
        if O and f and J.Z>0 then
          T.label.Text="Gun";
          T.label.Color=Y.TextColor;
          T.label.Position=Vector2.new(J.X,J.Y);
          T.label.Visible=true;
        else
          T.label.Visible=false;
        end
      elseif T.label then
        T.label.Visible=false;
      end
    end
  end;
end
