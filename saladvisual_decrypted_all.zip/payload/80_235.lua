-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #235
-- offset 3352383..3502899 (150516 bytes, type=payload)

local function pP(KP,oP)
  local cP={};
  local mP=s[87]();
  if not y[18][l[602]] then
    cP[1]=y[18];
    cP[2]=l[602];
    cP[3]={};
    cP[1][cP[2]]=cP[3];
  end
  local SP,OP={},{};
  local BP=l[1282];
  oP=oP or l[593];
  for AP=l[229],l[59],l[229]do
    local wP=a(l[1439],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[772]](l[659]*(AP-l[229]),AP==l[229]and l[393]or l[786],l[393],BP),[l[1639]]=mP[l[1459]][l[772]](l[659],l[1024],l[229],-BP),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=mP[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[303]},KP);
    local FP=a(l[755],{[l[407]]=mP[l[128]][l[407]][l[537]],[l[536]]=mP[l[740]][l[772]](l[393],l[551])},wP);
    d(FP:GetPropertyChangedSignal(l[996]),function()
      local hP=s[87]();
      wP[l[392]]=hP[l[1459]][l[588]](l[393],j(FP)[l[636]]+l[786]);
    end);
    SP[AP]={[l[1594]--[[__index]]]=wP,[l[305]]={},[l[668]]=l[393]};
  end;
  local function AP(wP)
    local FP=s[87]();
    if wP==l[1747]or wP==l[863] then
      if not SP[l[863]] then
        local hP=a(l[1439],{[l[1150]]=f(),[l[948]]=FP[l[1459]][l[588]](l[393],BP),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[229],-BP),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=FP[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[303]},KP);
        local BP=a(l[755],{[l[407]]=FP[l[128]][l[407]][l[537]],[l[536]]=FP[l[740]][l[772]](l[393],l[551])},hP);
        d(BP:GetPropertyChangedSignal(l[996]),function()
          local FP=s[87]();
          hP[l[392]]=FP[l[1459]][l[588]](l[393],j(BP)[l[636]]+l[786]);
        end);
        local BP,FP=l[863],{[l[1594]--[[__index]]]=hP,[l[305]]={}};
        FP[l[668]],SP[BP]=l[393],FP;
        SP[l[229]][l[1594]--[[__index]]][l[1324]]=l[1329];
        SP[l[59]][l[1594]--[[__index]]][l[1324]]=l[1329];
      end
      return SP[l[863]];
    end
    return SP[(wP==l[1316]or wP==l[59])and l[59]or l[229]];
  end
  local BP=a(l[211],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[588]](l[286],l[286]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[913],l[393],l[726]),[l[1535]]=R[l[641]],[l[1418]]=l[393],[l[711]]=l[1158]},KP);
  local wP=a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[393],l[659]),[l[948]]=mP[l[1459]][l[772]](l[393],l[393],l[229],l[393]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[393],l[393],l[829]),[l[1646]]=l[229],[l[711]]=l[1158]},BP);
  K(a(l[211],{[l[1150]]=f(),[l[1639]]=mP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[1529]--[[cancel]]],[l[1646]]=l[387],[l[1418]]=l[393],[l[711]]=l[1158]},wP),l[117],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[659],l[615]),mP[l[677]][l[772]](l[229],l[229])});
  K(a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[659],l[659]),[l[948]]=mP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[966]],[l[1418]]=l[393],[l[711]]=l[1092]},wP),l[393],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[841],l[986]),mP[l[677]][l[772]](l[804],l[986]),mP[l[677]][l[772]](l[229],l[229])});
  local FP=a(l[1070],{[l[1150]]=f(),[l[948]]=mP[l[1459]][l[588]](l[114],l[863]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[889],l[229],l[1519]),[l[1646]]=l[229],[l[437]]=mP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[558],[l[916]]=l[229],[l[164]]=mP[l[128]][l[164]][l[1021]],[l[1634]]=mP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},BP);
  local hP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[229],l[659]),[l[948]]=mP[l[1459]][l[772]](l[229],l[1435],l[659],l[715]),[l[1639]]=mP[l[1459]][l[772]](l[393],l[393],l[393],l[941]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=mP[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[4],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[558],[l[916]]=l[229],[l[1634]]=mP[l[128]][l[1634]][l[701]],[l[1324]]=l[1329],[l[711]]=l[1092]},BP);
  D(hP,l[930]);
  a(l[1359],{[l[1612]]=mP[l[740]][l[772]](l[393],l[310]),[l[517]]=mP[l[740]][l[772]](l[393],l[310])},hP);
  local WP=a(l[734],{[l[1161]]=mP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1017]},hP);
  local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=mP[l[1689]][l[772]](l[659],l[229]),[l[948]]=mP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=mP[l[1459]][l[772]](l[229],l[1158],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},hP);
  K(VP,l[393],{mP[l[677]][l[772]](l[393],l[229]),mP[l[677]][l[772]](l[659],l[393]),mP[l[677]][l[772]](l[229],l[229])});
  cP[5]=a;
  cP[6]=l[1742];
  cP[4]={};
  cP[4][l[1150]]=f();
  cP[4][l[1016]]=mP[l[1689]][l[772]](l[229],l[659]);
  cP[4][l[948]]=mP[l[1459]][l[772]](l[229],l[774],l[659],l[59]);
  cP[4][l[1639]]=mP[l[1459]][l[588]](l[1243],l[1243]);
  cP[4][l[1535]]=R[l[1466]];
  cP[4][l[1646]]=l[229];
  cP[4][l[1418]]=l[393];
  cP[4][l[1451]]=y[30](l[4]);
  cP[4][l[936]]=R[l[1379]];
  cP[4][l[2]]=l[874];
  cP[4][l[1557]]=mP[l[128]][l[1557]][l[220]];
  cP[4][l[711]]=l[930];
  local _P=cP[5](cP[6],cP[4],BP);
  D(_P,l[1158]);
  if y[18][l[388]] then
    cP[8]=a;
    cP[9]=l[1742];
    cP[7]={};
    cP[7][l[1150]]=f();
    cP[7][l[1016]]=mP[l[1689]][l[772]](l[229],l[659]);
    cP[7][l[948]]=mP[l[1459]][l[772]](l[229],l[992]--[[readi8]],l[659],l[59]);
    cP[7][l[1639]]=mP[l[1459]][l[588]](l[1655],l[1655]);
    cP[7][l[1646]]=l[229];
    cP[7][l[1418]]=l[393];
    cP[7][l[1451]]=y[30](l[898]);
    cP[7][l[936]]=R[l[1379]];
    cP[7][l[2]]=l[1209];
    cP[7][l[1557]]=mP[l[128]][l[1557]][l[220]];
    cP[7][l[711]]=l[930];
    wP=(cP[8](cP[9],cP[7],BP));
    _P[l[948]]=mP[l[1459]][l[772]](l[229],l[1509],l[659],l[59]);
    hP[l[948]]=mP[l[1459]][l[772]](l[229],l[1650],l[659],l[715]);
    d(wP[l[445]],function()
      LP:toggle();
    end);
  end
  local cP={[l[836]]=BP,[l[1271]]={}};
  mP[l[1346]][l[968]](y[18][l[602]],cP);
  y[18][l[1277]](cP);
  local function mP(BP)
    local wP=s[87]();
    local XP,xP=wP[l[409]][l[56]](wP[l[409]][l[345]](BP or l[1746]),l[381])or l[1746],l[393];
    for kP,kP in y[3],OP,nil do
      local vP,IP,iP=XP==l[1746]or wP[l[409]][l[23]](wP[l[409]][l[345]](kP[l[572]]),XP,l[229],l[383])~=nil,l[1329],l[1329];
      for EP,QP in y[3],kP[l[12]],nil do
        EP=XP~=l[1746]and wP[l[409]][l[23]](wP[l[409]][l[345]](QP[l[572]]),XP,l[229],l[383])~=nil;
        BP=vP or EP;
        if QP[l[266]][l[1324]]~=BP then
          QP[l[266]][l[1324]]=BP;
          IP=l[383];
        else
        end
        iP,xP=iP or BP,if EP then xP+l[229]else xP;
      end;
      if kP[l[1637]] then
        kP[l[1637]](XP~=l[1746]and iP or nil);
      end
      if IP and kP[l[1654]] then
        kP[l[1654]]();
      end
      xP=if vP and XP~=l[1746]then xP+l[229]else xP;
      kP[l[590]][l[1735]](vP or iP);
    end;
    return xP;
  end
  local BP=l[1329];
  local wP=l[393];
  local function XP(xP)
    local kP={};
    local vP,IP=s[87](),BP;
    if IP==xP then
      return;
    end
    BP=xP;
    for IP,IP in y[3],cP[l[1271]],nil do
      IP[l[1324]]=not xP;
    end;
    if xP then
      hP[l[1324]]=l[383];
      kP[1]=_P;
      kP[2]=l[1451];
      kP[3]=(y[30](l[898]));
      kP[1][kP[2]]=kP[3];
      P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[959],l[1435],l[393],l[941]),[l[916]]=l[393]});
      P(WP,H,{[l[747]]=l[615]});
      P(VP,H,{[l[1646]]=l[615]});
      P(_P,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
      vP[l[1022]][l[1330]](l[841],function()
        local cP=BP;
        if cP then
          hP:CaptureFocus();
        end
      end);
    else
      wP=vP[l[655]][l[1587]]();
      kP[4]=_P;
      kP[5]=l[1451];
      kP[6]=(y[30](l[4]));
      kP[4][kP[5]]=kP[6];
      hP:ReleaseFocus();
      if hP[l[1420]]~=l[1746] then
        hP[l[1420]]=l[1746];
      end
      P(hP,H,{[l[1639]]=vP[l[1459]][l[772]](l[393],l[393],l[393],l[941]),[l[916]]=l[229]});
      P(WP,H,{[l[747]]=l[1017]});
      P(VP,H,{[l[1646]]=l[229]});
      P(_P,H,{[l[2]]=l[874],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
      vP[l[1022]][l[1330]](l[269],function()
        local cP=BP;
        if not cP then
          hP[l[1324]]=l[1329];
        end
      end);
    end
  end
  d(_P[l[445]],function()
    local cP=s[87]();
    local WP=not BP and cP[l[655]][l[1587]]()-wP<l[986];
    if WP then
      return;
    end
    XP(not BP);
  end);
  d(_P[l[1538]],function()
    P(_P,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
  end);
  d(_P[l[1628]],function()
    local cP=BP;
    if not cP then
      P(_P,H,{[l[2]]=l[874],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
    end
  end);
  d(hP:GetPropertyChangedSignal(l[1420]),function()
    local cP,BP=s[87](),mP(hP[l[1420]]);
    local mP=cP[l[409]][l[56]](hP[l[1420]],l[825])~=nil;
    FP[l[1420]]=mP and BP..(BP==l[229]and l[1090]or l[818])or l[1746];
    P(FP,H,{[l[916]]=mP and l[874]or l[229]});
  end);
  d(hP[l[722]],function()
    local cP=s[87]();
    if not cP[l[409]][l[56]](hP[l[1420]],l[825]) then
      XP(l[1329]);
    end
  end);
  local cP={};
  local function mP(BP,wP)
    local FP,hP=s[87](),l[668];
    BP[hP]=BP[hP]+l[229];
    local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[393],wP or l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=BP[l[668]],[l[711]]=l[303]},BP[l[1594]--[[__index]]]);
    local VP=a(l[211],{[l[1150]]=f(),[l[1639]]=FP[l[1459]][l[772]](l[229],l[393],l[393],wP or l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[303]},WP);
    VP:SetAttribute(l[226],l[383]);
    local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=wP and FP[l[1459]][l[772]](l[229],l[393],l[393],wP)or FP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=not wP and FP[l[128]][l[1347]][l[636]]or FP[l[128]][l[1347]][l[31]],[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[711]]=l[303]},VP);
    D(_P,l[1092]);
    hP,wP=l[1622],{[l[500]]=l[117]};
    wP[l[1630]]=FP[l[1262]][l[772]]({FP[l[527]][l[772]](l[393],FP[l[360]][l[772]](l[229],l[229],l[229])),FP[l[527]][l[772]](l[229],FP[l[360]][l[353]](l[291],l[291],l[920]))});
    a(hP,wP,_P);
    if GP then
      a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=FP[l[740]][l[772]](l[393],l[310]),[l[1485]]=FP[l[1459]][l[588]](l[393],l[863]),[l[1326]]=FP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[323],[l[711]]=l[715]},_P);
    end
    local wP={[l[1594]--[[__index]]]=WP,[l[1501]]=VP,[l[675]]=_P,[l[1273]]=l[383]};
    local function hP(XP)
      XP=XP and l[383]or l[1329];
      if wP[l[1273]]==XP then
        return;
      end
      wP[l[1273]]=XP;
      if XP then
        WP[l[1324]]=l[383];
      end
      b(VP,l[304],XP and N or q,function(xP)
        local kP,vP,IP=s[87](),e(_P)[l[636]],XP and xP or l[229]-xP;
        local iP=kP[l[35]][l[499]](vP*IP+l[659]);
        WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
        VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],iP);
        _P[l[948]]=kP[l[1459]][l[588]](l[393],-kP[l[35]][l[499]](kP[l[35]][l[457]](l[352],vP)*(l[229]-IP)+l[659]));
        if xP>=l[229] then
          _P[l[948]]=kP[l[1459]][l[772]]();
          WP[l[1324]]=XP;
          if XP then
            WP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
            VP[l[1639]]=kP[l[1459]][l[772]](l[229],l[393],l[393],vP);
          end
        end
      end);
    end
    wP[l[1735]]=hP;
    FP[l[1346]][l[968]](BP[l[305]],wP);
    d(_P:GetPropertyChangedSignal(l[160]),function()
      local BP,FP=s[87](),e(_P)[l[636]];
      if not wP[l[1273]] then
        return;
      end
      WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
      if not C[VP] then
        VP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],FP);
      end
    end);
    return _P,wP;
  end
  local function BP()
    cP[l[86]]();
  end
  cP[l[811]]=BP;
  local function BP()
    local wP=s[87]();
    for FP,hP in y[3],SP,nil do
      for SP,SP in y[3],hP[l[305]],nil do
        if SP[l[1273]] then
          FP=C[SP[l[1501]]];
          if FP then
            FP:Disconnect();
            C[SP[l[1501]]]=nil;
          end
          SP[l[675]][l[948]]=wP[l[1459]][l[772]]();
          SP[l[1501]][l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],e(SP[l[675]])[l[636]]);
        end
      end;
    end;
  end
  cP[l[86]]=BP;
  local function SP(BP,wP,FP,hP,WP)
    local VP,_P=s[87](),{[l[404]]=l[1329],[l[1273]]=l[1329],[l[230]]=nil,[l[649]]=l[524],[l[1019]]=l[393],[l[559]]=l[1753],[l[434]]=l[393]};
    local XP=WP[l[1019]];
    if XP then
      _P[l[1019]]=VP[l[1382]](XP[l[950]])or XP[l[457]]or l[393];
    end
    local xP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1526]},YP);
    local kP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1282]},YP)or nil;
    local vP=kP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=VP[l[740]][l[772]](l[393],l[829]),[l[1485]]=VP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=VP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},kP)or nil;
    if kP then
      D(kP,l[930]);
    end
    local IP=a(l[1751],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[219]},YP);
    D(IP,l[930]);
    local iP,EP=l[1622],{[l[500]]=l[117]};
    EP[l[1630]]=VP[l[1262]][l[772]]({VP[l[527]][l[772]](l[393],VP[l[360]][l[772]](l[229],l[229],l[229])),VP[l[527]][l[772]](l[229],VP[l[360]][l[353]](l[291],l[291],l[920]))});
    a(iP,EP,IP);
    a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},IP);
    iP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[520]},IP);
    D(iP,l[930]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},iP);
    EP=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[1596]--[[__newindex]]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},IP);
    D(EP,l[930]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[393],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[489]},EP);
    local QP,tP,RP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1274],l[229],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[368]},EP),l[755],{[l[101]]=VP[l[128]][l[101]][l[1505]],[l[1749]]=VP[l[128]][l[1749]][l[46]],[l[1259]]=VP[l[128]][l[1259]][l[46]],[l[407]]=VP[l[128]][l[407]][l[537]]};
    RP[l[536]]=VP[l[740]][l[772]](l[393],l[1092]);
    a(tP,RP,QP);
    local gP=a;
    local uP=l[859];
    local UP={};
    UP[l[1150]]=f();
    UP[l[1639]]=VP[l[1459]][l[588]](l[750],l[750]);
    UP[l[1646]]=l[229];
    UP[l[1451]]=y[30](l[1680]);
    UP[l[936]]=R[l[98]];
    UP[l[2]]=l[841];
    UP[l[537]]=l[229];
    UP[l[1557]]=VP[l[128]][l[1557]][l[220]];
    UP[l[711]]=l[1289];
    gP(uP,UP,QP);
    a(l[1070],{[l[1150]]=f(),[l[1347]]=VP[l[128]][l[1347]][l[1437]],[l[1639]]=VP[l[1459]][l[588]](l[393],l[829]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=wP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[537]]=l[59],[l[711]]=l[1289]},QP);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1596]--[[__newindex]]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[966]],[l[1646]]=l[986],[l[1418]]=l[393],[l[711]]=l[368]},IP),l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[820],l[263]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[70],l[263]),VP[l[677]][l[772]](l[229],l[229])});
    local gP=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[393],l[1282]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=VP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[489]},IP);
    iP,EP=l[755],{[l[407]]=VP[l[128]][l[407]][l[537]]};
    EP[l[536]]=VP[l[740]][l[772]](l[393],l[786]);
    a(iP,EP,gP);
    a(l[1359],{[l[299]]=VP[l[740]][l[772]](l[393],l[1092]),[l[645]]=VP[l[740]][l[772]](l[393],l[930]),[l[1612]]=VP[l[740]][l[772]](l[393],l[1092]),[l[517]]=VP[l[740]][l[772]](l[393],l[1092])},gP);
    local uP=l[393];
    local function UP(MP)
      local sC,lC=s[87](),uP;
      uP=lC+l[229];
      local lC,LC=l[211],{[l[1150]]=f(),[l[1639]]=sC[l[1459]][l[772]](l[229],l[393],l[393],MP),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=uP,[l[711]]=l[489]};
      return a(lC,LC,gP);
    end
    local function uP(MP,sC,lC,LC)
      local yC=s[87]();
      return a(l[1070],{[l[1150]]=f(),[l[948]]=yC[l[1459]][l[588]](l[303],lC),[l[1639]]=yC[l[1459]][l[772]](LC or l[330],l[1519],l[393],l[973]),[l[1646]]=l[229],[l[437]]=yC[l[128]][l[437]][l[1381]],[l[1420]]=sC,[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[330],[l[164]]=yC[l[128]][l[164]][l[1021]],[l[1634]]=yC[l[128]][l[1634]][l[701]],[l[711]]=l[368]},MP);
    end
    EP=UP(l[1243]);
    uP(EP,l[1686],l[786]);
    local MP=a(l[1742],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=VP[l[1459]][l[588]](l[1707],l[1707]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1451]]=l[1746],[l[711]]=l[1289]},EP);
    D(MP,l[303]);
    local sC=a;
    local lC=l[859];
    local LC={};
    LC[l[1150]]=f();
    LC[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]);
    LC[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]);
    LC[l[1639]]=VP[l[1459]][l[588]](l[1307],l[1307]);
    LC[l[1646]]=l[229];
    LC[l[1451]]=y[30](l[905]);
    LC[l[936]]=R[l[1379]];
    LC[l[2]]=l[411];
    LC[l[1557]]=VP[l[128]][l[1557]][l[220]];
    LC[l[711]]=l[1365];
    local yC=sC(lC,LC,MP);
    local sC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[659]),[l[948]]=VP[l[1459]][l[772]](l[229],l[662],l[659],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[1419],l[221],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},EP);
    D(sC,l[1158]);
    local lC=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},sC);
    local LC=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[711]]=l[1289]},sC);
    local zC=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[229]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},sC);
    K(zC,l[393],{VP[l[677]][l[772]](l[393],l[229]),VP[l[677]][l[772]](l[659],l[393]),VP[l[677]][l[772]](l[229],l[229])});
    QP=a(l[1742],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},sC);
    local TC,nC,JC,HC;
    if XP then
      tP=UP(l[1282]);
      uP(tP,l[1019],l[229]);
      JC=a(l[1070],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[229],l[393]),[l[948]]=VP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=VP[l[1459]][l[588]](l[616],l[973]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=VP[l[128]][l[164]][l[1021]],[l[1634]]=VP[l[128]][l[1634]][l[877]],[l[711]]=l[368]},tP);
      TC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[588]](l[303],l[209]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[368]},tP);
      iP,RP=l[1112],{};
      RP[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
      a(iP,RP,TC);
      nC=a(l[211],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1289]},TC);
      local fC,aC=l[1112],{};
      aC[l[1182]]=VP[l[740]][l[772]](l[229],l[393]);
      a(fC,aC,nC);
      HC=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=VP[l[1459]][l[588]](l[393],l[352]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[393],l[393],l[829]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1365]},tP);
    else
    end
    local tP,fC={};
    if WP[l[649]] then
      RP=UP(l[1655]);
      uP=a(l[211],{[l[1150]]=f(),[l[1016]]=VP[l[1689]][l[772]](l[659],l[659]),[l[948]]=VP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=VP[l[1459]][l[772]](l[229],l[1026],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[368]},RP);
      D(uP,l[1158]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},uP);
      fC=a(l[211],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[393],l[59],l[393],l[59]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[1452],l[229],l[1024]),[l[1535]]=R[l[98]],[l[1646]]=l[70],[l[1418]]=l[393],[l[711]]=l[1289]},uP);
      D(fC,l[303]);
      K(fC,l[117],{VP[l[677]][l[772]](l[393],l[393]),VP[l[677]][l[772]](l[229],l[1017])});
      a(l[734],{[l[1630]]=R[l[98]],[l[747]]=l[1567]},fC);
      iP={l[524],l[259]};
      for RP,UP in y[3],iP,nil do
        EP={[l[572]]=UP,[l[892]]=l[1329],[l[590]]=RP,[l[974]]=a(l[1742],{[l[1150]]=f(),[l[948]]=VP[l[1459]][l[772]](l[659]*(RP-l[229]),l[393],l[393],l[393]),[l[1639]]=VP[l[1459]][l[772]](l[659],l[393],l[229],l[393]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[906]},uP)};
        EP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[1639]]=VP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[437]]=VP[l[128]][l[437]][l[1381]],[l[1420]]=UP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[711]]=l[1365]},EP[l[974]]);
        tP[RP]=EP;
      end;
    else
    end
    local iP=XP and VP[l[35]][l[850]](VP[l[1382]](XP[l[109]])or l[229],l[393])or l[393];
    local EP=XP and XP[l[1647]]or l[393];
    local RP=l[1329];
    local function uP(UP)
      local aC=s[87]();
      if EP>l[393] then
        return aC[l[409]][l[846]](l[1213]..EP..l[347],UP)..(XP[l[26]]or l[1746]);
      end
      return aC[l[409]][l[846]](l[1489],aC[l[35]][l[499]](UP+l[659]))..(XP[l[26]]or l[1746]);
    end
    local function UP(aC)
      local dC=s[87]();
      aC=dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
      aC=if iP>l[393]then XP[l[457]]+dC[l[35]][l[499]]((aC-XP[l[457]])/iP+l[659])*iP else aC;
      aC=if EP>l[393]then dC[l[1382]](dC[l[409]][l[846]](l[1213]..EP..l[347],aC))or aC else aC;
      return dC[l[35]][l[819]](aC,XP[l[457]],XP[l[850]]);
    end
    local function iP()
      local EP=s[87]();
      if not XP then
        return;
      end
      local aC=XP[l[850]]-XP[l[457]];
      local dC=aC>l[393]and(_P[l[1019]]-XP[l[457]])/aC or l[393];
      JC[l[1420]]=uP(_P[l[1019]]);
      local uP,JC=RP and J or n,{};
      JC[l[1639]]=EP[l[1459]][l[772]](dC,EP[l[35]][l[499]](l[1158]*(l[229]-dC)+l[659]),l[229],l[393]);
      P(nC,uP,JC);
    end
    local function EP()
      local uP=s[87]();
      for nC=l[229],#tP,l[229]do
        local JC=tP[nC];
        nC=_P[l[649]]==JC[l[572]];
        P(JC[l[1615]],n,{[l[916]]=nC and l[393]or(JC[l[892]]and l[874]or l[323]),[l[510]]=nC and R[l[1095]]or R[l[1379]]});
        if nC and fC then
          P(fC,H,{[l[948]]=uP[l[1459]][l[772]](l[659]*(JC[l[590]]-l[229]),l[59],l[393],l[59])});
        end
      end;
    end
    local function uP()
      LC[l[1420]]=_P[l[548]]and l[538]or z(_P[l[230]]);
      P(sC,H,{[l[1646]]=_P[l[548]]and l[393]or l[841]});
      P(lC,H,{[l[747]]=_P[l[548]]and l[120]or l[1373]});
      P(zC,H,{[l[1646]]=_P[l[548]]and l[986]or l[229]});
      local sC,lC,zC={[l[916]]=_P[l[230]]and l[1296]or l[615]},l[510],_P[l[548]]and R[l[98]]or(_P[l[230]]and R[l[1095]]or R[l[1379]]);
      sC[lC]=zC;
      P(LC,H,sC);
      P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509]});
    end
    local function sC()
      if not _P[l[230]] then
        fP(WP[l[1463]]);
        return;
      end
      NP(WP[l[1463]],{[l[572]]=wP,[l[230]]=z(_P[l[230]]),[l[103]]=WP[l[103]],[l[194]]=WP[l[194]],[l[1204]]=WP[l[1735]]and WP[l[1735]]()or nil,[l[628]]=WP[l[1386]]and WP[l[1386]]()or l[1329]});
    end
    local function fP()
      local NP=s[87]();
      return l[1282]+NP[l[35]][l[850]](NP[l[35]][l[499]](e(gP)[l[636]]+l[659]),l[1655]);
    end
    local function NP()
      local wP,lC,LC,zC,nC,JC,fC=s[87](),G(YP),e(YP),G(FP),e(FP),G(BP),e(BP);
      local aC,dC=zC[l[1437]]-lC[l[1437]]+nC[l[1437]]+l[930],zC[l[1437]]-lC[l[1437]]-_P[l[559]]-l[930];
      nC,zC=if aC+_P[l[559]]>LC[l[1437]]-l[930]then dC>=l[930]and dC or wP[l[35]][l[850]](l[930],LC[l[1437]]-l[930]-_P[l[559]])else aC,wP[l[35]][l[819]](JC[l[636]]-lC[l[636]]+fC[l[636]]*l[659]-_P[l[434]]*l[659],l[930],wP[l[35]][l[850]](l[930],LC[l[636]]-_P[l[434]]-l[930]));
      IP[l[948]]=wP[l[1459]][l[588]](wP[l[35]][l[499]](nC+l[659]),wP[l[35]][l[499]](zC+l[659]));
      if kP then
        kP[l[948]]=IP[l[948]];
      end
    end
    local function wP()
      local lC=s[87]();
      _P[l[434]]=fP();
      IP[l[1639]]=lC[l[1459]][l[588]](_P[l[559]],_P[l[434]]);
      if kP then
        kP[l[1639]]=IP[l[1639]];
      end
    end
    local function fP()
      local lC=IP[l[1569]];
      local LC=_P[l[404]]and l[393]or l[229];
      b(IP,_P[l[404]]and l[894]or l[304],_P[l[404]]and N or q,function(zC)
        local nC=lC+(LC-lC)*zC;
        IP[l[1569]]=nC;
        if kP then
          kP[l[1646]]=nC;
          vP[l[747]]=l[615]+l[411]*nC;
        end
        if zC>=l[229] then
          IP[l[1324]]=_P[l[404]];
          if kP then
            kP[l[1324]]=_P[l[404]];
          end
        end
      end);
    end
    local vP;
    local function lC()
      local LC=vP;
      if LC then
        vP:Disconnect();
        vP=nil;
      end
    end
    local function LC()
      _P:setopen(l[1329]);
    end
    local function zC()
      local nC=S;
      if nC>l[393] then
        NP();
        return;
      end
      if not LP[l[1600]]or not KP[l[1324]]or not BP[l[1324]] then
        _P:setopen(l[1329]);
        return;
      end
      local JC,fC,aC,dC,PC,ZC=FP[l[81]],FP[l[160]],hP[l[81]],hP[l[160]],BP[l[81]],BP[l[160]];
      nC=PC[l[636]]+ZC[l[636]]*l[659];
      if nC<JC[l[636]]or nC>JC[l[636]]+fC[l[636]]or nC<aC[l[636]]or nC>aC[l[636]]+dC[l[636]] then
        _P:setopen(l[1329]);
        return;
      end
      NP();
    end
    local function BP(FP,hP)
      local nC={};
      hP=hP and l[383]or l[1329];
      if _P[l[404]]==hP then
        return;
      end
      _P[l[404]]=hP;
      if hP then
        V();
        U(_P);
        wP();
        xP[l[1324]]=l[383];
        IP[l[1324]]=l[383];
        if kP then
          kP[l[1324]]=l[383];
        end
        NP();
        A,w=LC,IP;
        lC();
        nC[1]=(y[10][l[1119]]:Connect(zC));
        vP=nC[1];
      else
        lC();
        xP[l[1324]]=l[1329];
        if _P[l[548]] then
          _P[l[548]]=l[1329];
          lP(nil);
          uP();
        end
        FP=A==LC;
        if FP then
          A,w=nil,nil;
        end
      end
      fP();
    end
    _P[l[1521]--[[0]]]=BP;
    local fP=l[393];
    local function BP(FP)
      FP=s[87]();
      local hP=FP[l[655]][l[1587]]();
      FP=hP-fP;
      if FP<l[874] then
        return l[1329];
      end
      fP=hP;
      if _P[l[404]]and(W(IP,l[59])or kP and W(kP,l[59])) then
        return l[1329];
      end
      _P:setopen(not _P[l[404]]);
      return l[383];
    end
    _P[l[1352]]=BP;
    local function BP()
      local FP=s[87]();
      if F() then
        return;
      end
      fP=FP[l[655]][l[1587]]();
      _P:setopen(l[1329]);
    end
    d(xP[l[445]],BP);
    d(xP[l[861]],BP);
    local function fP(BP,BP)
      local FP,hP=s[87](),BP;
      hP=if FP[l[40]](hP)==l[409]then FP[l[199]](l[59],FP[l[1146]](function()
        local xP=s[87]();
        return xP[l[128]][l[880]--[[readu32]]][BP];
      end))else hP;
      hP=if FP[l[1703]](hP)~=l[802]or hP==FP[l[128]][l[880]--[[readu32]]][l[605]]then nil else hP;
      if _P[l[230]]==hP then
        return;
      end
      if _P[l[1273]] then
        _P[l[1273]]=l[1329];
        WP[l[1498]](l[1329]);
      end
      _P[l[230]]=hP;
      uP();
      sC();
    end
    _P[l[1046]]=fP;
    local function fP(BP,BP)
      if BP~=l[524]and BP~=l[259] then
        return;
      end
      if _P[l[649]]==BP then
        return;
      end
      if _P[l[1273]] then
        _P[l[1273]]=l[1329];
        WP[l[1498]](l[1329]);
      end
      _P[l[649]]=BP;
      EP();
    end
    _P[l[1755]]=fP;
    local function fP(BP,FP)
      BP=s[87]();
      if not XP then
        return;
      end
      FP=UP(BP[l[1382]](FP)or XP[l[457]]);
      if _P[l[1019]]==FP then
        return;
      end
      _P[l[1019]]=FP;
      iP();
      if _P[l[230]] then
        sC();
      end
    end
    _P[l[378]]=fP;
    local function fP(BP,BP)
      _P[l[1273]]=BP and l[383]or l[1329];
    end
    _P[l[488]]=fP;
    local function fP(BP,BP)
      aP(WP[l[1463]],BP);
    end
    _P[l[628]]=fP;
    _P[l[1498]]=WP[l[1498]];
    local function fP()
      _P[l[548]]=l[1329];
      uP();
    end
    d(QP[l[445]],function()
      if _P[l[548]] then
        lP(nil);
        fP();
        return;
      end
      _P[l[548]]=l[383];
      uP();
      y[18]:chime(l[1352]);
      lP(function(aP)
        fP();
        if aP then
          _P:setkey(aP);
          y[18]:chime(l[1320]);
        end
      end,fP);
    end);
    d(MP[l[445]],function()
      if _P[l[548]] then
        lP(nil);
        fP();
      end
      if not _P[l[230]] then
        return;
      end
      _P:setkey(nil);
      yC[l[936]]=R[l[98]];
      P(yC,H,{[l[936]]=R[l[1379]]});
      y[18]:chime(l[676]);
    end);
    d(MP[l[1538]],function()
      P(MP,H,{[l[1646]]=l[330]});
      P(yC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
    end);
    d(MP[l[1628]],function()
      P(MP,H,{[l[1646]]=l[229]});
      P(yC,H,{[l[2]]=_P[l[230]]and l[986]or l[509],[l[936]]=R[l[1379]]});
    end);
    for fP=l[229],#tP,l[229]do
      local aP=tP[fP];
      d(aP[l[974]][l[1538]],function()
        aP[l[892]]=l[383];
        EP();
      end);
      d(aP[l[974]][l[1628]],function()
        aP[l[892]]=l[1329];
        EP();
      end);
      d(aP[l[974]][l[445]],function()
        _P:setmode(aP[l[572]]);
        y[18]:chime(l[1320]);
      end);
    end;
    EP();
    if XP then
      local fP=l[1329];
      local function aP()
        RP=l[1329];
        local BP=fP;
        if BP then
          fP=l[1329];
          O(l[715]);
        end
      end
      d(HC[l[956]],aP);
      d(HC[l[1558]],function(BP)
        local FP=s[87]();
        if BP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and BP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
          return;
        end
        local hP=RP;
        if hP then
          return;
        end
        RP=l[383];
        fP=l[383];
        O(l[229]);
        local fP,hP=FP[l[1146]](function()
          local xP=s[87]();
          y[18]:chime(l[1320]);
          while true do
            local vP=RP and y[18][l[630]];
            if not(vP and HC[l[382]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[912]]and BP[l[1101]]~=xP[l[128]][l[1101]][l[625]]) then
              break;
            end
            local vP,EP=TC[l[81]],TC[l[160]];
            if EP[l[1437]]>l[393] then
              _P:setvalue(XP[l[457]]+(XP[l[850]]-XP[l[457]])*xP[l[35]][l[819]]((v(BP)[l[1437]]-vP[l[1437]])/EP[l[1437]],l[393],l[229]));
            end
            xP[l[1022]][l[153]]();
          end;
        end);
        aP();
        if not fP then
          FP[l[972]](l[800]..FP[l[1130]](hP));
        end
        iP();
      end);
      d(HC[l[412]],function(fP)
        local BP=s[87]();
        if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
          aP();
        end
      end);
      d(y[9][l[412]],function(fP)
        local BP=s[87]();
        if fP[l[1317]]==BP[l[128]][l[1317]][l[1356]]or fP[l[1317]]==BP[l[128]][l[1317]][l[239]] then
          aP();
        end
      end);
      _P[l[1019]]=UP(_P[l[1019]]);
      iP();
    end
    d(gP:GetPropertyChangedSignal(l[160]),function()
      if _P[l[404]] then
        wP();
        NP();
      end
    end);
    d(y[9][l[1558]],function(fP)
      local aP,NP,BP=s[87](),not _P[l[404]];
      if NP then
        BP=NP;
      else
        local NP=S;
        BP=NP>l[393];
      end
      if BP or F() then
        return;
      end
      if fP[l[1317]]~=aP[l[128]][l[1317]][l[1356]]and fP[l[1317]]~=aP[l[128]][l[1317]][l[239]] then
        return;
      end
      if W(IP,l[59])or kP and W(kP,l[59]) then
        return;
      end
      aP[l[1022]][l[1061]](function()
        if _P[l[404]] then
          _P:setopen(l[1329]);
        end
      end);
    end);
    d(y[9][l[1558]],function(F,fP)
      local aP=s[87]();
      if fP or y[18][l[1333]]or not _P[l[230]]or not y[18][l[630]] then
        return;
      end
      if F[l[1317]]~=aP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
        return;
      end
      if not WP[l[649]] then
        WP[l[1498]](l[383]);
        return;
      end
      if _P[l[649]]==l[259] then
        if _P[l[1273]] then
          return;
        end
        _P[l[1273]]=l[383];
        WP[l[1498]](l[383]);
      else
        _P[l[1273]]=not _P[l[1273]];
        WP[l[1498]](_P[l[1273]]);
      end
    end);
    d(y[9][l[412]],function(F)
      local fP=s[87]();
      if _P[l[649]]~=l[259]or not _P[l[230]]or not _P[l[1273]] then
        return;
      end
      if F[l[1317]]~=fP[l[128]][l[1317]][l[1441]]or F[l[880]--[[readu32]]]~=_P[l[230]] then
        return;
      end
      _P[l[1273]]=l[1329];
      WP[l[1498]](l[1329]);
    end);
    uP();
    VP[l[1346]][l[968]](m,_P);
    y[18]:hook(WP[l[1463]]..l[728],l[230],function()
      return _P[l[230]]and _P[l[230]][l[1150]]or nil;
    end,function(F)
      _P:setkey(F);
    end);
    if WP[l[649]] then
      y[18]:hook(WP[l[1463]]..l[1175],l[1206],function()
        return _P[l[649]];
      end,function(F)
        _P:setmode(F);
      end,{[l[284]]=function(F)
        return F==l[524]or F==l[259];
      end});
    end
    if XP then
      y[18]:hook(WP[l[1463]]..l[562],l[384],function()
        return _P[l[1019]];
      end,function(F)
        _P:setvalue(F);
      end,{[l[457]]=XP[l[457]],[l[850]]=XP[l[850]]});
    end
    return _P;
  end
  local function F(fP,aP)
    fP=s[87]();
    aP=X(aP,{[l[572]]=l[146],[l[1132]]=l[356]});
    local NP=AP(aP[l[1132]]);
    local BP,wP=mP(NP);
    local FP={[l[590]]=wP,[l[572]]=aP[l[572]],[l[12]]={}};
    local hP=oP..l[1074]..aP[l[572]];
    fP[l[1346]][l[968]](OP,FP);
    local WP,VP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
    VP[l[536]]=fP[l[740]][l[772]](l[393],l[393]);
    a(WP,VP,BP);
    WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[537]]=l[229],[l[711]]=l[303]},BP);
    D(WP,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=fP[l[1689]][l[772]](l[393],l[229]),[l[948]]=fP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[711]]=l[303]},WP);
    a(l[1070],{[l[1150]]=f(),[l[948]]=fP[l[1459]][l[588]](l[730],l[393]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[644],l[229],l[393]),[l[1646]]=l[229],[l[437]]=fP[l[128]][l[437]][l[1381]],[l[1420]]=aP[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=fP[l[128]][l[164]][l[1021]],[l[1634]]=fP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
    local _P=a;
    local XP=l[859];
    local xP={};
    xP[l[1150]]=f();
    xP[l[1016]]=fP[l[1689]][l[772]](l[229],l[659]);
    xP[l[948]]=fP[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
    xP[l[1639]]=fP[l[1459]][l[588]](l[750],l[750]);
    xP[l[1646]]=l[229];
    xP[l[1451]]=y[30](l[606]--[[readu16]]);
    xP[l[936]]=R[l[1379]];
    xP[l[2]]=l[615];
    xP[l[500]]=l[1510];
    xP[l[711]]=l[1158];
    local kP=_P(XP,xP,WP);
    aP=a(l[1742],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},WP);
    K(a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[537]]=l[59],[l[711]]=l[1158]},BP),l[393],{fP[l[677]][l[772]](l[393],l[229]),fP[l[677]][l[772]](l[841],l[874]),fP[l[677]][l[772]](l[659],l[393]),fP[l[677]][l[772]](l[804],l[874]),fP[l[677]][l[772]](l[229],l[229])});
    local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=l[863],[l[711]]=l[303]},BP);
    local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=fP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[711]]=l[303]},WP);
    VP,wP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
    wP[l[536]]=fP[l[740]][l[772]](l[393],l[229]);
    a(VP,wP,_P);
    a(l[1359],{[l[299]]=fP[l[740]][l[772]](l[393],l[1158]),[l[645]]=fP[l[740]][l[772]](l[393],l[930]),[l[1612]]=fP[l[740]][l[772]](l[393],l[303]),[l[517]]=fP[l[740]][l[772]](l[393],l[303])},_P);
    local fP={[l[675]]=BP,[l[1577]]=_P,[l[668]]=l[393],[l[1600]]=l[383]};
    d(_P:GetPropertyChangedSignal(l[160]),function()
      local BP=s[87]();
      if fP[l[1600]]and not fP[l[1678]] then
        WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],e(_P)[l[636]]);
      end
    end);
    local function BP()
      local wP,VP=s[87](),WP[l[1639]][l[636]][l[1485]];
      fP[l[1678]]=l[383];
      wP[l[1022]][l[1061]](function()
        local wP=fP[l[1600]]and e(_P)[l[636]]or l[393];
        b(WP,l[1491],wP>=VP and N or q,function(XP)
          local xP=s[87]();
          WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],xP[l[35]][l[499]](VP+(wP-VP)*XP+l[659]));
          if XP>=l[229] then
            fP[l[1678]]=l[1329];
            WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],fP[l[1600]]and e(_P)[l[636]]or l[393]);
          end
        end);
      end);
    end
    fP[l[721]]=BP;
    local function BP(wP,wP)
      fP[l[1600]]=wP and l[383]or l[1329];
      local wP=kP[l[500]];
      local VP=fP[l[1600]]and l[1510]or l[393];
      b(kP,l[894],N,function(XP)
        kP[l[500]]=wP+(VP-wP)*XP;
      end);
      fP[l[721]]();
    end
    fP[l[1521]--[[0]]]=BP;
    FP[l[1654]]=fP[l[721]];
    FP[l[1637]]=function(BP)
      if BP==nil then
        if FP[l[1626]]~=nil then
          local wP=FP[l[1626]];
          FP[l[1626]]=nil;
          if fP[l[1600]]~=wP then
            fP:setopen(wP);
          end
        end
        return;
      end
      if BP and not fP[l[1600]] then
        if FP[l[1626]]==nil then
          FP[l[1626]]=l[1329];
        end
        fP:setopen(l[383]);
      end
    end;
    d(aP[l[445]],function()
      fP:setopen(not fP[l[1600]]);
      y[18]:chime(l[1352]);
    end);
    d(aP[l[1538]],function()
      P(kP,H,{[l[2]]=l[1209]});
    end);
    d(aP[l[1628]],function()
      P(kP,H,{[l[2]]=l[615]});
    end);
    local aP={[l[1594]--[[__index]]]=_P,[l[438]]=NP[l[1594]--[[__index]]],[l[745]]=WP};
    local NP={l[524],l[1223],l[166],l[654],l[1336],l[1409],l[138],l[1094]};
    local function BP(wP,WP,VP)
      local _P={};
      for XP,XP in y[3],NP,nil do
        _P[XP]=function(NP,NP)
          local xP,kP,vP,IP=s[87](),aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
          aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=wP,WP,VP;
          local wP,WP=xP[l[1146]](fP[XP],fP,NP);
          aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=kP,vP,IP;
          if not wP then
            xP[l[279]](WP,l[59]);
          end
          xP[l[1346]][l[1357]](FP[l[12]]);
          return WP;
        end;
      end;
      return _P;
    end
    local function NP(wP,WP,VP,_P)
      local XP,xP=s[87](),{[l[404]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
      local kP=a(l[1742],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1243]},YP);
      local vP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[209]},YP)or nil;
      local IP=vP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=XP[l[740]][l[772]](l[393],l[558]),[l[1485]]=XP[l[1459]][l[588]](l[393],l[786]),[l[1326]]=XP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},vP)or nil;
      if vP then
        D(vP,l[1092]);
      end
      local iP=a(l[1751],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1655]},YP);
      D(iP,l[1092]);
      local EP,QP=l[1622],{[l[500]]=l[117]};
      QP[l[1630]]=XP[l[1262]][l[772]]({XP[l[527]][l[772]](l[393],XP[l[360]][l[772]](l[229],l[229],l[229])),XP[l[527]][l[772]](l[229],XP[l[360]][l[353]](l[291],l[291],l[920]))});
      a(EP,QP,iP);
      EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[658]},iP);
      D(EP,l[1092]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},EP);
      QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},iP);
      EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},QP);
      D(EP,l[1092]);
      a(l[211],{[l[1150]]=f(),[l[1016]]=XP[l[1689]][l[772]](l[393],l[229]),[l[948]]=XP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},EP);
      local tP=a;
      local RP=l[859];
      local gP={};
      gP[l[1150]]=f();
      gP[l[1016]]=XP[l[1689]][l[772]](l[393],l[659]);
      gP[l[948]]=XP[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
      gP[l[1639]]=XP[l[1459]][l[588]](l[310],l[310]);
      gP[l[1646]]=l[229];
      gP[l[1451]]=y[30](l[1716]);
      gP[l[936]]=R[l[1379]];
      gP[l[2]]=l[1431];
      gP[l[1557]]=XP[l[128]][l[1557]][l[220]];
      gP[l[711]]=l[1660];
      tP(RP,gP,EP);
      a(l[1070],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=XP[l[128]][l[437]][l[1381]],[l[1420]]=WP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=XP[l[128]][l[164]][l[1021]],[l[1634]]=XP[l[128]][l[1634]][l[701]],[l[711]]=l[1660]},EP);
      K(a(l[211],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1660]},QP),l[393],{XP[l[677]][l[772]](l[393],l[229]),XP[l[677]][l[772]](l[841],l[874]),XP[l[677]][l[772]](l[659],l[393]),XP[l[677]][l[772]](l[804],l[874]),XP[l[677]][l[772]](l[229],l[229])});
      local tP=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=XP[l[1459]][l[588]](l[393],l[913]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=XP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=XP[l[128]][l[62]][l[636]],[l[711]]=l[1655]},QP);
      local QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=XP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},tP);
      EP,WP=l[755],{[l[407]]=XP[l[128]][l[407]][l[537]]};
      WP[l[536]]=XP[l[740]][l[772]](l[393],l[229]);
      a(EP,WP,QP);
      a(l[1359],{[l[299]]=XP[l[740]][l[772]](l[393],l[1158]),[l[645]]=XP[l[740]][l[772]](l[393],l[930]),[l[1612]]=XP[l[740]][l[772]](l[393],l[303]),[l[517]]=XP[l[740]][l[772]](l[393],l[303])},QP);
      local function WP()
        local XP,EP=s[87](),e(YP);
        local RP=XP[l[35]][l[499]](e(VP)[l[1437]]+l[659]);
        return XP[l[35]][l[819]](RP,l[1592],XP[l[35]][l[850]](XP[l[35]][l[499]](EP[l[1437]])-l[1655],l[1592]));
      end
      local function XP()
        local EP,RP=s[87](),e(YP);
        local gP=EP[l[35]][l[850]](EP[l[35]][l[499]](e(QP)[l[636]]+l[659]),l[658]);
        return EP[l[35]][l[819]](l[913]+gP,l[1167],EP[l[35]][l[850]](EP[l[35]][l[499]](RP[l[636]])-l[1655],l[1167]));
      end
      local function EP()
        local RP,gP,uP,UP,MP,sC,lC=s[87](),G(YP),e(YP),G(VP),e(VP),G(wP),e(wP);
        local LC,yC=UP[l[1437]]-gP[l[1437]]+MP[l[1437]]+l[930],UP[l[1437]]-gP[l[1437]]-xP[l[559]]-l[930];
        UP,MP=if LC+xP[l[559]]>uP[l[1437]]-l[930]then yC>=l[930]and yC or RP[l[35]][l[850]](l[930],uP[l[1437]]-l[930]-xP[l[559]])else LC,RP[l[35]][l[819]](sC[l[636]]-gP[l[636]]+lC[l[636]]*l[659]-xP[l[434]]*l[659],l[930],RP[l[35]][l[850]](l[930],uP[l[636]]-xP[l[434]]-l[930]));
        iP[l[948]]=RP[l[1459]][l[588]](RP[l[35]][l[499]](UP+l[659]),RP[l[35]][l[499]](MP+l[659]));
        if vP then
          vP[l[948]]=iP[l[948]];
        end
      end
      local function RP()
        local gP=iP[l[1569]];
        local uP=xP[l[404]]and l[393]or l[229];
        b(iP,xP[l[404]]and l[894]or l[304],xP[l[404]]and N or q,function(UP)
          local MP=gP+(uP-gP)*UP;
          iP[l[1569]]=MP;
          if vP then
            vP[l[1646]]=MP;
            IP[l[747]]=l[330]+l[1419]*MP;
          end
          if UP>=l[229] then
            iP[l[1324]]=xP[l[404]];
            if vP then
              vP[l[1324]]=xP[l[404]];
            end
          end
        end);
      end
      local function IP()
        local gP=s[87]();
        xP[l[559]]=WP();
        xP[l[434]]=XP();
        iP[l[1639]]=gP[l[1459]][l[588]](xP[l[559]],xP[l[434]]);
        if vP then
          vP[l[1639]]=iP[l[1639]];
        end
      end
      local WP;
      local function XP()
        local gP=WP;
        if gP then
          WP:Disconnect();
          WP=nil;
        end
      end
      local function gP()
        local uP=S;
        if uP>l[393] then
          EP();
          return;
        end
        if not LP[l[1600]]or not KP[l[1324]]or not wP[l[1324]] then
          xP:setopen(l[1329]);
          return;
        end
        local UP,MP,sC,lC,LC,yC=VP[l[81]],VP[l[160]],_P[l[81]],_P[l[160]],wP[l[81]],wP[l[160]];
        uP=LC[l[636]]+yC[l[636]]*l[659];
        if uP<UP[l[636]]or uP>UP[l[636]]+MP[l[636]]or uP<sC[l[636]]or uP>sC[l[636]]+lC[l[636]] then
          xP:setopen(l[1329]);
          return;
        end
        EP();
      end
      local function wP(VP,_P)
        local uP={};
        VP=s[87]();
        _P=_P and l[383]or l[1329];
        if xP[l[404]]==_P then
          return;
        end
        xP[l[404]]=_P;
        if _P then
          IP();
          iP[l[1324]]=l[383];
          kP[l[1324]]=l[383];
          tP[l[1690]]=VP[l[1689]][l[772]]();
          if vP then
            vP[l[1324]]=l[383];
          end
          EP();
          XP();
          y[21](iP);
          uP[1]=(y[10][l[1119]]:Connect(gP));
          WP=uP[1];
        else
          XP();
          V();
          y[20](iP);
          kP[l[1324]]=l[1329];
        end
        RP();
      end
      xP[l[1521]--[[0]]]=wP;
      d(QP:GetPropertyChangedSignal(l[160]),function()
        local wP=s[87]();
        tP[l[392]]=wP[l[1459]][l[588]](l[393],wP[l[35]][l[499]](e(QP)[l[636]]+l[659]));
        if xP[l[404]] then
          IP();
          EP();
        end
      end);
      d(kP[l[445]],function()
        local wP=S;
        if wP>l[393] then
          return;
        end
        xP:setopen(l[1329]);
      end);
      xP[l[1594]--[[__index]]]=iP;
      xP[l[642]]=QP;
      xP[l[429]]=BP(QP,tP,tP);
      return xP;
    end
    local function BP(wP,WP)
      wP=s[87]();
      WP=X(WP,{[l[572]]=l[524],[l[950]]=l[1329],[l[925]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local VP,_P,XP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
      local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},VP);
      local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[829],l[829]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},xP);
      D(VP,l[786]);
      local kP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[874]},VP);
      local vP=a;
      local IP=l[859];
      local iP={};
      iP[l[1150]]=f();
      iP[l[1016]]=wP[l[1689]][l[772]](l[659],l[659]);
      iP[l[948]]=wP[l[1459]][l[1368]](l[659],l[659]);
      iP[l[1639]]=wP[l[1459]][l[588]](l[1158],l[1158]);
      iP[l[1646]]=l[229];
      iP[l[1451]]=y[30](l[1411]);
      iP[l[936]]=R[l[641]];
      iP[l[2]]=l[229];
      iP[l[1557]]=wP[l[128]][l[1557]][l[220]];
      iP[l[711]]=l[1092];
      local EP=vP(IP,iP,VP);
      local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=wP[l[1459]][l[588]](l[910],l[393]),[l[1639]]=wP[l[1459]][l[772]](l[229],WP[l[925]]and l[132]or l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=wP[l[128]][l[437]][l[1381]],[l[1420]]=WP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=wP[l[128]][l[164]][l[1021]],[l[1634]]=wP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
      local IP=a(l[1742],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},xP);
      local iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[59],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[1243],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},xP);
      local QP=WP[l[925]];
      if QP then
        local tP=a;
        local RP=l[1742];
        local gP={};
        gP[l[1150]]=f();
        gP[l[1016]]=wP[l[1689]][l[772]](l[229],l[659]);
        gP[l[948]]=wP[l[1459]][l[772]](l[229],l[66],l[659],l[393]);
        gP[l[1639]]=wP[l[1459]][l[588]](l[884],l[884]);
        gP[l[1535]]=R[l[1466]];
        gP[l[1646]]=l[229];
        gP[l[1418]]=l[393];
        gP[l[1451]]=y[30](l[1456]);
        gP[l[936]]=R[l[1379]];
        gP[l[2]]=l[615];
        gP[l[1557]]=wP[l[128]][l[1557]][l[220]];
        gP[l[711]]=l[730];
        QP=tP(RP,gP,xP);
      end
      local tP,RP,gP=IP,iP,QP or nil;
      if gP then
        D(gP,l[1158]);
      end
      local IP,iP,QP=wP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
      QP[l[572]]=WP[l[572]];
      IP(iP,QP);
      local wP={[l[266]]=xP,[l[404]]=l[1329]};
      local IP=l[1329];
      if gP then
        local QP=NP(xP,WP[l[572]],_P,XP);
        wP[l[1085]]=QP;
        wP[l[925]]=QP[l[429]];
        local function NP(uP,uP)
          QP:setopen(uP);
        end
        wP[l[691]]=NP;
        d(gP[l[445]],function()
          QP:setopen(not QP[l[404]]);
          y[18]:chime(l[1352]);
        end);
        d(gP[l[1538]],function()
          P(gP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
        end);
        d(gP[l[1628]],function()
          P(gP,H,{[l[2]]=l[615],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
        end);
      end
      local function NP()
        local QP,gP,uP,UP=s[87](),{},l[1646],wP[l[404]]and l[1296]or(IP and l[804]or l[229]);
        gP[uP]=UP;
        P(VP,H,gP);
        UP,gP,uP={},l[747],wP[l[404]]and l[229]or(IP and l[1296]or l[874]);
        UP[gP]=uP;
        P(kP,H,UP);
        P(EP,H,{[l[2]]=wP[l[404]]and l[393]or l[229],[l[1639]]=QP[l[1459]][l[588]](wP[l[404]]and l[310]or l[1158],wP[l[404]]and l[310]or l[1158])});
        P(vP,H,{[l[916]]=wP[l[404]]and l[393]or l[615],[l[510]]=wP[l[404]]and R[l[1095]]or R[l[1379]]});
      end
      local function VP(kP,kP,vP)
        kP=kP and l[383]or l[1329];
        if wP[l[404]]==kP and not y[18][l[921]] then
          return;
        end
        wP[l[404]]=kP;
        NP();
        if wP[l[1686]] then
          wP[l[1686]]:sync(kP);
          wP[l[1686]]:lit(kP);
        end
        if not vP then
          y[18]:chime(kP and l[404]or l[676]);
          if WP[l[1617]] then
            I(WP[l[1617]],kP);
          end
        end
      end
      wP[l[1255]]=VP;
      local function VP(kP)
        return wP[l[404]];
      end
      wP[l[506]]=VP;
      d(tP[l[445]],function()
        wP:set(not wP[l[404]]);
      end);
      d(RP[l[445]],function()
        wP:set(not wP[l[404]]);
      end);
      d(RP[l[1538]],function()
        IP=l[383];
        NP();
      end);
      d(RP[l[1628]],function()
        IP=l[1329];
        NP();
      end);
      if WP[l[950]] then
        wP[l[404]]=l[383];
        NP();
      end
      iP=WP[l[1013]]or hP..l[1074]..WP[l[572]];
      local NP=SP(xP,WP[l[572]],_P,XP,{[l[1463]]=iP,[l[103]]=l[1499],[l[649]]=l[383],[l[1498]]=function(WP)
        wP:set(WP);
      end,[l[194]]=function()
        wP:set(not wP[l[404]]);
      end,[l[1386]]=function()
        return wP[l[404]];
      end});
      wP[l[1686]]=NP;
      NP:lit(wP[l[404]]);
      d(tP[l[861]],function()
        if not NP:flip() then
          return;
        end
        y[18]:chime(l[1352]);
      end);
      d(RP[l[861]],function()
        if not NP:flip() then
          return;
        end
        y[18]:chime(l[1352]);
      end);
      y[18]:hook(iP,l[524],function()
        return wP[l[404]];
      end,function(NP)
        wP:set(NP==l[383]or NP==l[1102]or NP==l[229]);
      end);
      return wP;
    end
    fP[l[524]]=BP;
    local function NP(BP,wP)
      BP=s[87]();
      wP=X(wP,{[l[572]]=l[1223],[l[457]]=l[393],[l[850]]=l[856],[l[950]]=nil,[l[109]]=l[229],[l[26]]=l[1746],[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local WP,VP=aP[l[1594]--[[__index]]],aP[l[438]];
      local _P,XP=aP[l[745]],BP[l[35]][l[850]](BP[l[1382]](wP[l[109]])or l[229],l[393]);
      local xP=XP>l[393]and XP<l[229]and#(BP[l[409]][l[56]](BP[l[1130]](XP),l[361])or l[1746])or l[393];
      local kP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},WP);
      local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[229]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1057],l[393],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=wP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},kP);
      local IP=a(l[1070],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[393]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=BP[l[1459]][l[588]](l[1167],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[874],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[877]],[l[711]]=l[1158]},kP);
      local iP=a(l[211],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[1243]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},kP);
      local EP,QP=l[1112],{};
      QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
      a(EP,QP,iP);
      local tP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1092]},iP);
      EP,QP=l[1112],{};
      QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
      a(EP,QP,tP);
      local RP,gP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[393],l[973]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[114]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},kP),{[l[266]]=kP,[l[1019]]=wP[l[457]]};
      local uP=l[1329];
      local UP,MP,sC=l[1329];
      EP,QP,WP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=kP};
      WP[l[572]]=wP[l[572]];
      EP(QP,WP);
      local function lC(LC)
        local yC=s[87]();
        if xP>l[393] then
          return yC[l[409]][l[846]](l[1213]..xP..l[347],LC)..wP[l[26]];
        end
        return yC[l[409]][l[846]](l[1489],yC[l[35]][l[499]](LC+l[659]))..wP[l[26]];
      end
      local function LC(yC)
        local zC=s[87]();
        yC=zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
        yC=if XP>l[393]then wP[l[457]]+zC[l[35]][l[499]]((yC-wP[l[457]])/XP+l[659])*XP else yC;
        yC=if xP>l[393]then zC[l[1382]](zC[l[409]][l[846]](l[1213]..xP..l[347],yC))or yC else yC;
        return zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
      end
      local function yC(zC)
        local TC=s[87]();
        return TC[l[1459]][l[772]](zC,TC[l[35]][l[499]](l[1158]*(l[229]-zC)+l[659]),l[229],l[393]);
      end
      local function zC()
        local TC=wP[l[850]]-wP[l[457]];
        local nC=TC>l[393]and(gP[l[1019]]-wP[l[457]])/TC or l[393];
        IP[l[1420]]=lC(gP[l[1019]]);
        local TC,JC=UP and J or n,{};
        JC[l[1639]]=yC(nC);
        P(tP,TC,JC);
      end
      local function J()
        P(iP,H,{[l[1646]]=(UP or uP)and l[393]or l[841]});
        local yC,TC,nC={},l[1646],UP and l[393]or(uP and l[613]or l[1209]);
        yC[TC]=nC;
        P(tP,H,yC);
        P(vP,H,{[l[916]]=(UP or uP)and l[1209]or l[615]});
        P(IP,H,{[l[916]]=(UP or uP)and l[393]or l[874]});
      end
      local function vP(IP,tP,yC)
        IP=s[87]();
        tP=LC(IP[l[1382]](tP)or wP[l[457]]);
        if gP[l[1019]]==tP and not y[18][l[921]] then
          return;
        end
        gP[l[1019]]=tP;
        zC();
        if not yC and wP[l[1617]] then
          I(wP[l[1617]],tP);
        end
      end
      gP[l[1255]]=vP;
      local function vP(IP)
        return gP[l[1019]];
      end
      gP[l[506]]=vP;
      local function IP(tP)
        if tP and tP[l[948]] then
          return tP[l[948]][l[1437]];
        end
        return y[9]:GetMouseLocation()[l[1437]];
      end
      local function tP(yC)
        local TC,nC,JC=s[87](),iP[l[81]],iP[l[160]];
        if JC[l[1437]]<=l[393] then
          return gP[l[1019]];
        end
        return wP[l[457]]+(wP[l[850]]-wP[l[457]])*TC[l[35]][l[819]]((yC-nC[l[1437]])/JC[l[1437]],l[393],l[229]);
      end
      local function iP()
        local yC=sC;
        if yC then
          sC:Disconnect();
          sC=nil;
        end
        yC=UP;
        if not yC then
          return;
        end
        UP,MP=l[1329],nil;
        VP[l[1195]]=l[383];
        O(l[715]);
        zC();
        J();
      end
      d(RP[l[1558]],function(yC)
        local TC={};
        local nC=s[87]();
        if yC[l[1317]]~=nC[l[128]][l[1317]][l[1356]]and yC[l[1317]]~=nC[l[128]][l[1317]][l[239]] then
          return;
        end
        local JC=UP;
        if JC then
          return;
        end
        UP=l[383];
        MP=yC[l[1317]]==nC[l[128]][l[1317]][l[239]]and yC or nil;
        JC=sC;
        if JC then
          sC:Disconnect();
        end
        TC[1]=(y[10][l[756]]:Connect(function()
          local nC,JC,HC=s[87](),MP;
          if JC then
            local JC=MP;
            local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
            if fC then
              HC=fC;
            else
              JC=MP;
              HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
            end
          else
            HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
          end
          if not HC then
            iP();
          end
        end));
        sC=TC[1];
        O(l[229]);
        J();
        VP[l[1195]]=l[1329];
        y[18]:chime(l[1320]);
        gP:set(tP(IP(yC)));
      end);
      local function sC(yC)
        local TC,nC=s[87](),MP;
        if nC then
          local nC=MP;
          return yC==nC;
        end
        return yC[l[1317]]==TC[l[128]][l[1317]][l[1356]];
      end
      d(RP[l[412]],function(yC)
        if sC(yC) then
          iP();
        end
      end);
      d(y[9][l[233]],function(yC)
        local TC,nC=s[87](),UP;
        if not nC then
          return;
        end
        nC=MP;
        if nC then
          local UP=MP;
          if yC~=UP then
            return;
          end
        elseif yC[l[1317]]~=TC[l[128]][l[1317]][l[765]] then
          return;
        end
        gP:set(tP(IP(yC)));
      end);
      d(y[9][l[412]],function(IP)
        if sC(IP) then
          iP();
        end
      end);
      d(kP[l[1538]],function()
        uP=l[383];
        J();
      end);
      d(kP[l[1628]],function()
        uP=l[1329];
        J();
      end);
      gP[l[1019]]=LC(BP[l[1382]](wP[l[950]])or wP[l[457]]);
      zC();
      local J,IP,iP=wP[l[1013]]or hP..l[1074]..wP[l[572]];
      EP,WP,QP,vP=wP[l[572]],VP,{[l[1463]]=J,[l[103]]=l[1716],[l[649]]=l[383],[l[1019]]={[l[457]]=wP[l[457]],[l[850]]=wP[l[850]],[l[109]]=XP,[l[1647]]=xP,[l[26]]=wP[l[26]],[l[950]]=gP[l[1019]]},[l[1735]]=function()
        return lC(iP[l[1019]]);
      end},l[1498];
      local function VP(XP)
        if XP then
          local XP=IP==nil;
          if XP then
            IP=gP[l[1019]];
          end
          gP:set(iP[l[1019]]);
        else
          local XP=IP~=nil;
          if XP then
            gP:set(IP);
            IP=nil;
          end
        end
        iP:lit(IP~=nil);
      end
      QP[vP]=VP;
      QP[l[194]]=function()
        iP[l[1273]]=not iP[l[1273]];
        iP[l[1498]](iP[l[1273]]);
      end;
      QP[l[1386]]=function()
        local VP=IP;
        return VP~=nil;
      end;
      iP=SP(kP,EP,WP,_P,QP);
      gP[l[1686]]=iP;
      vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[973]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},kP);
      local function BP()
        if not iP:flip() then
          return;
        end
        y[18]:chime(l[1352]);
      end
      d(vP[l[861]],BP);
      d(RP[l[1558]],function(WP)
        local VP=s[87]();
        if WP[l[1317]]==VP[l[128]][l[1317]][l[321]--[[-1]]] then
          BP();
        end
      end);
      y[18]:hook(J,l[384],function()
        return gP[l[1019]];
      end,function(J)
        gP:set(J);
      end,{[l[457]]=wP[l[457]],[l[850]]=wP[l[850]]});
      return gP;
    end
    fP[l[1223]]=NP;
    local function J(NP,BP)
      NP=s[87]();
      BP=X(BP,{[l[572]]=l[166],[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local wP=aP[l[1594]--[[__index]]];
      local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
      local wP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
      local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
      D(VP,l[1158]);
      local _P=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},VP);
      local XP=a;
      local xP=l[859];
      local kP={};
      kP[l[1150]]=f();
      kP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
      kP[l[948]]=NP[l[1459]][l[772]](l[393],l[303],l[659],l[393]);
      kP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
      kP[l[1646]]=l[229];
      kP[l[1451]]=y[30](l[1680]);
      kP[l[936]]=R[l[1379]];
      kP[l[2]]=l[1431];
      kP[l[1557]]=NP[l[128]][l[1557]][l[220]];
      kP[l[711]]=l[1092];
      local vP=XP(xP,kP,VP);
      local XP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[1243],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[393],l[229],l[393],l[750]),[l[1535]]=R[l[966]],[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1092]},VP);
      K(XP,l[117],{NP[l[677]][l[772]](l[393],l[731]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[731])});
      local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[221],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},VP);
      local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},VP);
      K(kP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
      local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},WP),{[l[266]]=WP,[l[230]]=nil,[l[1273]]=l[1329]};
      local EP=l[1329];
      local QP,tP,RP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
      RP[l[572]]=BP[l[572]];
      QP(tP,RP);
      local function NP()
        xP[l[1420]]=iP[l[1273]]and l[538]or z(iP[l[230]]);
      end
      local function WP()
        local QP,tP,RP={},l[1646],iP[l[1273]]and l[393]or(EP and l[613]or l[841]);
        QP[tP]=RP;
        P(VP,H,QP);
        tP,QP,RP={},l[747],iP[l[1273]]and l[120]or(EP and l[323]or l[1373]);
        tP[QP]=RP;
        P(_P,H,tP);
        P(kP,H,{[l[1646]]=iP[l[1273]]and l[986]or l[229]});
        P(XP,H,{[l[1646]]=iP[l[1273]]and l[1209]or l[615]});
        P(xP,H,{[l[916]]=iP[l[1273]]and l[393]or l[1209],[l[510]]=iP[l[1273]]and R[l[98]]or R[l[1095]]});
        tP,QP,RP={},l[2],iP[l[1273]]and l[393]or(EP and l[1209]or l[1431]);
        tP[QP]=RP;
        tP[l[936]]=iP[l[1273]]and R[l[98]]or R[l[1379]];
        P(vP,H,tP);
        P(wP,H,{[l[916]]=(iP[l[1273]]or EP)and l[1209]or l[615]});
      end
      local function wP(VP,VP,_P)
        local XP,xP=s[87](),VP;
        xP=if XP[l[40]](xP)==l[409]then XP[l[199]](l[59],XP[l[1146]](function()
          local kP=s[87]();
          return kP[l[128]][l[880]--[[readu32]]][VP];
        end))else xP;
        if XP[l[1703]](xP)~=l[802]or xP==iP[l[230]] then
          return;
        end
        iP[l[230]]=xP;
        NP();
        if not _P and BP[l[1617]] then
          I(BP[l[1617]],xP[l[1150]]);
        end
      end
      iP[l[1255]]=wP;
      local function wP(VP)
        return iP[l[230]]and iP[l[230]][l[1150]]or nil;
      end
      iP[l[506]]=wP;
      local function wP()
        iP[l[1273]]=l[1329];
        NP();
        WP();
      end
      d(IP[l[445]],function()
        if iP[l[1273]] then
          lP(nil);
          wP();
          return;
        end
        iP[l[1273]]=l[383];
        NP();
        WP();
        y[18]:chime(l[1352]);
        lP(function(VP)
          wP();
          if VP then
            iP:set(VP);
            y[18]:chime(l[1320]);
          end
        end,wP);
      end);
      d(IP[l[1538]],function()
        EP=l[383];
        WP();
      end);
      d(IP[l[1628]],function()
        EP=l[1329];
        WP();
      end);
      iP:set(BP[l[950]]);
      NP();
      WP();
      y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[230],function()
        return iP:get();
      end,function(NP)
        iP:set(NP);
      end);
      return iP;
    end
    fP[l[166]]=J;
    local function J(NP,BP)
      NP=s[87]();
      BP=X(BP,{[l[572]]=l[654],[l[1206]]={},[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local wP=aP[l[1594]--[[__index]]];
      local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
      wP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[303]},WP);
      local VP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1218],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},wP);
      local _P=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
      D(_P,l[1158]);
      local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},_P);
      local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[289],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},_P);
      local kP=a;
      local vP=l[859];
      local IP={};
      IP[l[1150]]=f();
      IP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
      IP[l[948]]=NP[l[1459]][l[772]](l[229],l[348],l[659],l[393]);
      IP[l[1639]]=NP[l[1459]][l[588]](l[1307],l[1307]);
      IP[l[1646]]=l[229];
      IP[l[1451]]=y[30](l[606]--[[readu16]]);
      IP[l[936]]=R[l[1379]];
      IP[l[2]]=l[1431];
      IP[l[1557]]=NP[l[128]][l[1557]][l[220]];
      IP[l[711]]=l[1092];
      local iP=kP(vP,IP,_P);
      local kP,vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),a(l[211],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[688]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[393]),[l[1535]]=R[l[641]],[l[1646]]=l[269],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
      D(vP,l[1158]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},vP);
      local IP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=NP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP);
      local EP,QP=l[755],{[l[407]]=NP[l[128]][l[407]][l[537]]};
      QP[l[536]]=NP[l[740]][l[772]](l[393],l[229]);
      a(EP,QP,IP);
      a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786]),[l[1612]]=NP[l[740]][l[772]](l[393],l[786]),[l[517]]=NP[l[740]][l[772]](l[393],l[786])},IP);
      local tP={[l[266]]=WP,[l[404]]=l[1329],[l[955]]=nil,[l[1072]]={}};
      wP,EP,QP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
      QP[l[572]]=BP[l[572]];
      wP(EP,QP);
      local function wP(QP)
        local RP,gP=s[87](),tP[l[955]]==QP[l[572]];
        local uP,UP,MP,sC=QP[l[1642]],{},l[1646],gP and l[841]or(QP[l[892]]and l[659]or l[229]);
        UP[MP]=sC;
        P(uP,n,UP);
        MP,sC=QP[l[1377]],{[l[1646]]=gP and l[1296]or l[229]};
        sC[l[1639]]=RP[l[1459]][l[588]](gP and l[1092]or l[786],gP and l[1092]or l[786]);
        P(MP,n,sC);
        P(QP[l[1615]],n,{[l[916]]=gP and l[393]or(QP[l[892]]and l[820]or l[323]),[l[510]]=gP and R[l[1095]]or R[l[1379]]});
      end
      local function QP()
        local RP=vP[l[1639]][l[636]][l[1485]];
        local gP=tP[l[404]]and e(IP)[l[636]]or l[393];
        local uP=WP[l[1639]][l[636]][l[1485]];
        local UP=l[658]+(tP[l[404]]and gP+l[1158]or l[393]);
        local MP=iP[l[500]];
        local sC=tP[l[404]]and l[1510]or l[393];
        b(vP,l[1431],tP[l[404]]and N or q,function(lC)
          local LC=s[87]();
          vP[l[1639]]=LC[l[1459]][l[772]](l[229],l[1026],l[393],LC[l[35]][l[499]](RP+(gP-RP)*lC+l[659]));
          WP[l[1639]]=LC[l[1459]][l[772]](l[229],l[393],l[393],LC[l[35]][l[499]](uP+(UP-uP)*lC+l[659]));
        end);
        b(iP,l[1431],N,function(WP)
          iP[l[500]]=MP+(sC-MP)*WP;
        end);
        P(XP,H,{[l[747]]=tP[l[404]]and l[739]or l[1373]});
      end
      local function WP(XP,XP)
        tP[l[404]]=XP and l[383]or l[1329];
        QP();
      end
      tP[l[1521]--[[0]]]=WP;
      local function WP(XP,vP,QP)
        XP=s[87]();
        if XP[l[40]](vP)~=l[409]or vP==tP[l[955]]and not y[18][l[921]] then
          return;
        end
        if not XP[l[1346]][l[23]](BP[l[1206]],vP) then
          return;
        end
        tP[l[955]]=vP;
        xP[l[1420]]=vP;
        for XP,XP in y[3],tP[l[1072]],nil do
          wP(XP);
        end;
        if not QP and BP[l[1617]] then
          I(BP[l[1617]],vP);
        end
      end
      tP[l[1255]]=WP;
      local function XP(xP)
        return tP[l[955]];
      end
      tP[l[506]]=XP;
      for XP,xP in y[3],BP[l[1206]],nil do
        local vP={[l[572]]=xP,[l[892]]=l[1329],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[884]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=XP,[l[711]]=l[1158]},IP)};
        vP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP[l[1466]]);
        D(vP[l[1642]],l[303]);
        K(vP[l[1642]],l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[509],l[986]),NP[l[677]][l[772]](l[229],l[1017])});
        vP[l[1377]]=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[930],l[659],l[393]),[l[1639]]=NP[l[1459]][l[588]](l[786],l[786]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},vP[l[1466]]);
        WP,EP=l[1112],{};
        EP[l[1182]]=NP[l[740]][l[772]](l[229],l[393]);
        a(WP,EP,vP[l[1377]]);
        vP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[1243],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[14],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=xP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP[l[1466]]);
        vP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},vP[l[1466]]);
        d(vP[l[974]][l[1538]],function()
          vP[l[892]]=l[383];
          wP(vP);
        end);
        d(vP[l[974]][l[1628]],function()
          vP[l[892]]=l[1329];
          wP(vP);
        end);
        d(vP[l[974]][l[445]],function()
          tP:set(vP[l[572]]);
          tP:setopen(l[1329]);
          y[18]:chime(l[1320]);
        end);
        tP[l[1072]][XP]=vP;
      end;
      d(kP[l[445]],function()
        tP:setopen(not tP[l[404]]);
        y[18]:chime(l[1352]);
      end);
      d(kP[l[1538]],function()
        P(VP,H,{[l[916]]=l[1209]});
        P(iP,H,{[l[2]]=l[1296]});
        P(_P,H,{[l[1646]]=l[393]});
      end);
      d(kP[l[1628]],function()
        P(VP,H,{[l[916]]=l[615]});
        P(iP,H,{[l[2]]=l[1431]});
        P(_P,H,{[l[1646]]=l[841]});
      end);
      tP:set(BP[l[950]]or BP[l[1206]][l[229]]);
      y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
        return tP[l[955]];
      end,function(NP)
        tP:set(NP);
      end,{[l[284]]=function(NP)
        local wP=s[87]();
        return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
      end});
      return tP;
    end
    fP[l[654]]=J;
    local function J(NP,BP)
      NP=s[87]();
      BP=X(BP,{[l[572]]=l[1336],[l[1206]]={},[l[950]]=nil,[l[850]]=l[930],[l[1693]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
      local VP=aP[l[745]];
      local _P=l[941];
      local XP=NP[l[35]][l[850]](NP[l[35]][l[499]](NP[l[1382]](BP[l[850]])or l[930]),l[229]);
      local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
      local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
      local vP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},xP);
      D(vP,l[1158]);
      local IP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},vP);
      local iP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[662],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP);
      local EP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[551]},vP);
      K(EP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
      local QP=a;
      local tP=l[859];
      local RP={};
      RP[l[1150]]=f();
      RP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
      RP[l[948]]=NP[l[1459]][l[772]](l[229],l[708],l[659],l[393]);
      RP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
      RP[l[1646]]=l[229];
      RP[l[1451]]=y[30](l[606]--[[readu16]]);
      RP[l[936]]=R[l[1379]];
      RP[l[2]]=l[1431];
      RP[l[1557]]=NP[l[128]][l[1557]][l[220]];
      RP[l[711]]=l[1092];
      local gP=QP(tP,RP,vP);
      local QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[730]},vP),a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
      local RP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
      local uP=RP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=NP[l[740]][l[772]](l[393],l[829]),[l[1485]]=NP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=NP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},RP)or nil;
      if RP then
        D(RP,l[930]);
      end
      local UP=a(l[1751],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
      D(UP,l[930]);
      local MP,sC=l[1622],{[l[500]]=l[117]};
      sC[l[1630]]=NP[l[1262]][l[772]]({NP[l[527]][l[772]](l[393],NP[l[360]][l[772]](l[229],l[229],l[229])),NP[l[527]][l[772]](l[229],NP[l[360]][l[353]](l[291],l[291],l[920]))});
      a(MP,sC,UP);
      a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},UP);
      MP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},UP);
      D(MP,l[930]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},MP);
      local lC=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=NP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=NP[l[128]][l[62]][l[636]],[l[711]]=l[913]},UP);
      local LC=a(l[755],{[l[407]]=NP[l[128]][l[407]][l[537]],[l[536]]=NP[l[740]][l[772]](l[393],l[59])},lC);
      a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[1158]),[l[645]]=NP[l[740]][l[772]](l[393],l[1158]),[l[1612]]=NP[l[740]][l[772]](l[393],l[1158]),[l[517]]=NP[l[740]][l[772]](l[393],l[1158])},lC);
      local yC={[l[266]]=xP,[l[404]]=l[1329],[l[955]]=nil,[l[1406]--[[]]]={},[l[1072]]={},[l[771]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
      local zC=l[1329];
      local TC=l[393];
      MP,sC,wP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
      wP[l[572]]=BP[l[572]];
      MP(sC,wP);
      local function NP(wP)
        if BP[l[1693]] then
          return yC[l[1406]--[[]]][wP]==l[383];
        end
        return yC[l[955]]==wP;
      end
      local function wP()
        local MP,sC=s[87](),{};
        for nC=l[229],#BP[l[1206]],l[229]do
          if yC[l[1406]--[[]]][BP[l[1206]][nC]] then
            MP[l[1346]][l[968]](sC,BP[l[1206]][nC]);
          end
        end;
        return sC;
      end
      local function MP(sC,nC)
        local JC,HC,fC,aC=s[87](),NP(sC[l[572]]),sC[l[892]]or yC[l[1072]][TC]==sC,nC and n or H;
        local NP,dC,PC,ZC=sC[l[1466]],{},l[1646],HC and l[922]or(fC and l[330]or l[229]);
        dC[PC]=ZC;
        P(NP,aC,dC);
        ZC,nC=sC[l[1473]],{};
        nC[l[747]]=HC and l[509]or l[229];
        P(ZC,aC,nC);
        nC,PC=sC[l[1642]],{};
        PC[l[1646]]=HC and l[1432]or l[229];
        P(nC,aC,PC);
        P(sC[l[451]],aC,{[l[1639]]=JC[l[1459]][l[772]](l[393],l[863],l[393],HC and l[750]or l[393]),[l[1646]]=HC and l[1296]or l[229]});
        P(sC[l[1615]],aC,{[l[916]]=HC and l[393]or(fC and l[263]or l[323]),[l[510]]=HC and R[l[1095]]or R[l[1379]]});
        if BP[l[1693]] then
          nC,NP=sC[l[595]],{};
          NP[l[1646]]=HC and l[1296]or l[229];
          P(nC,aC,NP);
          local NP,nC,GC,YC=sC[l[741]],{},l[747],HC and l[229]or(fC and l[1296]or l[1431]);
          nC[GC]=YC;
          P(NP,aC,nC);
          PC,nC=sC[l[1572]],{[l[2]]=HC and l[393]or l[229]};
          nC[l[1639]]=JC[l[1459]][l[588]](HC and l[730]or l[786],HC and l[730]or l[786]);
          P(PC,aC,nC);
        else
          dC,ZC=sC[l[1040]],{[l[2]]=HC and l[393]or l[229]};
          ZC[l[1639]]=JC[l[1459]][l[588]](HC and l[310]or l[1092],HC and l[310]or l[1092]);
          P(dC,aC,ZC);
        end
      end
      local function NP()
        local sC=s[87]();
        if not BP[l[1693]] then
          iP[l[1420]]=yC[l[955]]or l[31];
          return;
        end
        local nC=wP();
        iP[l[1420]]=#nC>l[393]and sC[l[1346]][l[978]](nC,l[1200])or l[31];
      end
      local function iP()
        P(vP,H,{[l[1646]]=(yC[l[404]]or zC)and l[393]or l[841]});
        local sC,nC,JC={},l[747],yC[l[404]]and l[1431]or(zC and l[323]or l[1373]);
        sC[nC]=JC;
        P(IP,H,sC);
        P(EP,H,{[l[1646]]=yC[l[404]]and l[874]or l[229]});
        P(kP,H,{[l[916]]=(yC[l[404]]or zC)and l[1209]or l[615]});
        P(gP,H,{[l[2]]=(yC[l[404]]or zC)and l[1296]or l[1431],[l[936]]=yC[l[404]]and R[l[1095]]or R[l[1379]]});
      end
      local function kP()
        NP();
        for IP=l[229],#yC[l[1072]],l[229]do
          MP(yC[l[1072]][IP],l[383]);
        end;
      end
      local function IP()
        local EP=s[87]();
        return EP[l[35]][l[819]](#yC[l[1072]],l[229],XP)*_P+l[730];
      end
      local function XP()
        local EP,sC=s[87](),l[393];
        for nC=l[229],#BP[l[1206]],l[229]do
          local JC,HC=EP[l[1146]](function()
            local fC,aC,dC=s[87](),BP[l[1206]][nC],l[310];
            local nC,PC=fC[l[128]][l[437]][l[1381]],s[70](fC[l[1689]][l[772]](l[329],l[1655]));
            return y[8]:GetTextSize(aC,dC,nC,s:ZT(PC));
          end);
          sC=if JC and HC then EP[l[35]][l[850]](sC,HC[l[1437]])else sC;
        end;
        return EP[l[35]][l[139]](sC)+(BP[l[1693]]and l[205]or l[430]);
      end
      local function EP()
        local sC,nC,JC,HC,fC=s[87](),G(YP),e(YP),G(vP),e(vP);
        local aC,dC=HC[l[1437]]-nC[l[1437]],yC[l[771]]and HC[l[636]]-nC[l[636]]-l[1158]or HC[l[636]]-nC[l[636]]+fC[l[636]]+l[1158];
        aC=if aC+yC[l[559]]>JC[l[1437]]-l[930]then sC[l[35]][l[850]](l[930],HC[l[1437]]-nC[l[1437]]+fC[l[1437]]-yC[l[559]])else aC;
        UP[l[948]]=sC[l[1459]][l[588]](sC[l[35]][l[499]](aC+l[659]),sC[l[35]][l[499]](dC+l[659]));
        if RP then
          RP[l[948]]=UP[l[948]];
        end
      end
      local function sC()
        local nC=s[87]();
        yC[l[434]]=IP();
        UP[l[1639]]=nC[l[1459]][l[588]](yC[l[559]],yC[l[434]]);
        if RP then
          RP[l[1639]]=UP[l[1639]];
        end
        EP();
      end
      local function nC()
        local JC=UP[l[1569]];
        local HC=yC[l[404]]and l[393]or l[229];
        local fC=gP[l[500]];
        local aC=yC[l[404]]and l[1510]or l[393];
        b(UP,yC[l[404]]and l[894]or l[304],yC[l[404]]and N or q,function(dC)
          local PC=JC+(HC-JC)*dC;
          UP[l[1569]]=PC;
          if RP then
            RP[l[1646]]=PC;
            uP[l[747]]=l[615]+l[411]*PC;
          end
          if dC>=l[229] then
            UP[l[1324]]=yC[l[404]];
            if RP then
              RP[l[1324]]=yC[l[404]];
            end
          end
        end);
        b(gP,l[1431],N,function(uP)
          gP[l[500]]=fC+(aC-fC)*uP;
        end);
      end
      local function gP(uP)
        local JC,HC,fC=s[87](),lC[l[464]][l[636]]/y[29],j(LC)[l[636]]+l[310];
        local aC=JC[l[1346]][l[23]](yC[l[1072]],uP);
        if not aC or HC<=l[393]or fC<=HC then
          return;
        end
        uP,fC=l[1158]+(aC-l[229])*_P,lC[l[1690]][l[636]];
        if uP<fC then
          lC[l[1690]]=JC[l[1689]][l[772]](l[393],JC[l[35]][l[850]](uP-l[1158],l[393]));
        elseif uP+l[1660]>fC+HC then
          lC[l[1690]]=JC[l[1689]][l[772]](l[393],uP+l[1596]--[[__newindex]]-HC);
        end
      end
      local function _P(uP)
        local JC=yC[l[1072]][TC];
        TC=uP;
        if JC then
          MP(JC,l[383]);
        end
        uP=yC[l[1072]][TC];
        if uP then
          MP(uP,l[383]);
          gP(uP);
        end
      end
      local function uP(JC)
        if #yC[l[1072]]==l[393] then
          return;
        end
        local HC=TC+JC;
        _P(if HC<l[229]then#yC[l[1072]]else if HC>#yC[l[1072]]then l[229]else HC);
        y[18]:chime(l[1320]);
      end
      local function _P(JC)
        if not JC then
          return;
        end
        if BP[l[1693]] then
          yC[l[1406]--[[]]][JC[l[572]]]=not yC[l[1406]--[[]]][JC[l[572]]]or nil;
          kP();
          y[18]:chime(yC[l[1406]--[[]]][JC[l[572]]]and l[404]or l[676]);
          if BP[l[1617]] then
            I(BP[l[1617]],yC:get());
          end
          return;
        end
        yC:set(JC[l[572]]);
        yC:setopen(l[1329]);
        y[18]:chime(l[1320]);
      end
      local function JC()
        local HC={};
        local fC=s[87]();
        for aC=l[229],#yC[l[1072]],l[229]do
          local dC=yC[l[1072]][aC];
          for aC,aC in y[3],dC[l[608]],nil do
            aC:Disconnect();
          end;
          dC[l[1466]]:Destroy();
        end;
        fC[l[1346]][l[267]](yC[l[1072]]);
        local aC,dC,PC,ZC,GC=BP[l[1693]]and l[1249]or l[1307],BP[l[1693]]and l[730]or l[688],l[229],#BP[l[1206]],l[229];
        for YC=PC,ZC,GC do
          local PC=BP[l[1206]][YC];
          local ZC={[l[572]]=PC,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=YC,[l[711]]=l[913]},lC)};
          D(ZC[l[1466]],l[1158]);
          ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
          ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[913]},ZC[l[1466]]);
          D(ZC[l[1642]],l[1158]);
          K(ZC[l[1642]],l[393],{fC[l[677]][l[772]](l[393],l[393]),fC[l[677]][l[772]](l[1017],l[1373]),fC[l[677]][l[772]](l[229],l[229])});
          ZC[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=fC[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
          local GC,eC=l[1112],{};
          eC[l[1182]]=fC[l[740]][l[772]](l[229],l[393]);
          a(GC,eC,ZC[l[451]]);
          if BP[l[1693]] then
            ZC[l[595]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[551],l[659],l[393]),[l[1639]]=fC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
            D(ZC[l[595]],l[786]);
            ZC[l[741]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1431]},ZC[l[595]]);
            HC[1]=l[1572];
            HC[3]=a;
            HC[4]=l[859];
            HC[2]={};
            HC[2][l[1150]]=f();
            HC[2][l[1016]]=fC[l[1689]][l[772]](l[659],l[659]);
            HC[2][l[948]]=fC[l[1459]][l[1368]](l[659],l[659]);
            HC[2][l[1639]]=fC[l[1459]][l[588]](l[786],l[786]);
            HC[2][l[1646]]=l[229];
            HC[2][l[1451]]=y[30](l[1411]);
            HC[2][l[936]]=R[l[641]];
            HC[2][l[2]]=l[229];
            HC[2][l[1557]]=fC[l[128]][l[1557]][l[220]];
            HC[2][l[711]]=l[1282];
            HC[5]=(HC[3](HC[4],HC[2],ZC[l[595]]));
            ZC[HC[1]]=HC[5];
          else
            HC[6]=l[1040];
            HC[8]=a;
            HC[9]=l[859];
            HC[7]={};
            HC[7][l[1150]]=f();
            HC[7][l[1016]]=fC[l[1689]][l[772]](l[229],l[659]);
            HC[7][l[948]]=fC[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
            HC[7][l[1639]]=fC[l[1459]][l[588]](l[1092],l[1092]);
            HC[7][l[1646]]=l[229];
            HC[7][l[1451]]=y[30](l[1411]);
            HC[7][l[936]]=R[l[98]];
            HC[7][l[2]]=l[229];
            HC[7][l[1557]]=fC[l[128]][l[1557]][l[220]];
            HC[7][l[711]]=l[1526];
            HC[10]=(HC[8](HC[9],HC[7],ZC[l[1466]]));
            ZC[HC[6]]=HC[10];
          end
          ZC[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=fC[l[1459]][l[588]](aC,l[393]),[l[1639]]=fC[l[1459]][l[772]](l[229],-aC-dC,l[229],l[393]),[l[1646]]=l[229],[l[437]]=fC[l[128]][l[437]][l[1381]],[l[1420]]=PC,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=fC[l[128]][l[164]][l[1021]],[l[1634]]=fC[l[128]][l[1634]][l[701]],[l[711]]=l[1526]},ZC[l[1466]]);
          ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1282]},ZC[l[1466]]);
          fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1538]]:Connect(function()
            local HC=yC[l[1072]][TC];
            ZC[l[892]]=l[383];
            TC=l[393];
            if HC and HC~=ZC then
              MP(HC,l[383]);
            end
            MP(ZC,l[383]);
          end));
          fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1628]]:Connect(function()
            ZC[l[892]]=l[1329];
            MP(ZC,l[383]);
          end));
          fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[445]]:Connect(function()
            _P(ZC);
          end));
          yC[l[1072]][YC]=ZC;
          MP(ZC,l[383]);
        end;
      end
      local HC,fC;
      local function aC()
        local dC=HC;
        if dC then
          HC:Disconnect();
          HC=nil;
        end
      end
      local function dC()
        local PC=fC;
        if PC then
          fC:Disconnect();
          fC=nil;
        end
      end
      local function PC()
        yC:setopen(l[1329]);
      end
      local function ZC()
        local GC=S;
        if GC>l[393] then
          EP();
          return;
        end
        if not LP[l[1600]]or not KP[l[1324]]or not xP[l[1324]] then
          PC();
          return;
        end
        local xP,YC,eC,jC,CC,NC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],vP[l[81]],vP[l[160]];
        GC=CC[l[636]]+NC[l[636]]*l[659];
        if GC<xP[l[636]]or GC>xP[l[636]]+YC[l[636]]or GC<eC[l[636]]or GC>eC[l[636]]+jC[l[636]] then
          PC();
          return;
        end
        EP();
      end
      local function WP(VP)
        local xP=s[87]();
        if y[18][l[1333]]or VP[l[1317]]~=xP[l[128]][l[1317]][l[1441]] then
          return;
        end
        local EP=VP[l[880]--[[readu32]]];
        VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1492]];
        if VP then
          uP(l[229]);
        else
          local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1436]];
          if VP then
            uP(l[715]);
          else
            local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1183]]or EP==xP[l[128]][l[880]--[[readu32]]][l[839]];
            if VP then
              _P(yC[l[1072]][TC]);
            elseif EP==xP[l[128]][l[880]--[[readu32]]][l[1739]] then
              PC();
            end
          end
        end
      end
      local function VP(_P,xP)
        local EP={};
        _P=s[87]();
        xP=xP and l[383]or l[1329];
        if yC[l[404]]==xP then
          return;
        end
        yC[l[404]]=xP;
        if xP then
          V();
          local xP,uP,GC,YC=G(YP),e(YP),G(vP),e(vP);
          yC[l[559]]=_P[l[35]][l[819]](_P[l[35]][l[850]](XP(),_P[l[35]][l[499]](YC[l[1437]]+l[659])),l[492],_P[l[35]][l[850]](_P[l[35]][l[499]](uP[l[1437]])-l[829],l[492]));
          yC[l[434]]=IP();
          local XP,vP=uP[l[636]]-(GC[l[636]]-xP[l[636]]+YC[l[636]]+l[1158])-l[1158],GC[l[636]]-xP[l[636]]-l[310];
          yC[l[771]]=XP<yC[l[434]]and vP>XP;
          UP[l[1016]]=_P[l[1689]][l[772]](l[393],yC[l[771]]and l[229]or l[393]);
          UP[l[1324]]=l[383];
          tP[l[1324]]=l[383];
          lC[l[1690]]=_P[l[1689]][l[772]]();
          if RP then
            RP[l[1016]]=UP[l[1016]];
            RP[l[1324]]=l[383];
          end
          sC();
          kP();
          vP=not BP[l[1693]];
          if vP then
            uP,XP,GC=l[229],#yC[l[1072]],l[229];
            for _P=uP,XP,GC do
              xP=yC[l[1072]][_P][l[572]]==yC[l[955]];
              if xP then
                TC=_P;
                MP(yC[l[1072]][_P],l[383]);
                gP(yC[l[1072]][_P]);
                break;
              end
            end;
          end
          A,w=PC,UP;
          aC();
          dC();
          EP[1]=(y[10][l[1119]]:Connect(ZC));
          HC=EP[1];
          EP[2]=(y[9][l[1558]]:Connect(WP));
          fC=EP[2];
        else
          aC();
          dC();
          tP[l[1324]]=l[1329];
          TC=l[393];
          local WP=A==PC;
          if WP then
            A,w=nil,nil;
          end
          for WP=l[229],#yC[l[1072]],l[229]do
            yC[l[1072]][WP][l[892]]=l[1329];
            MP(yC[l[1072]][WP],l[383]);
          end;
        end
        iP();
        nC();
      end
      yC[l[1521]--[[0]]]=VP;
      local function WP(VP)
        if not BP[l[1693]] then
          return yC[l[955]];
        end
        return wP();
      end
      yC[l[506]]=WP;
      local function wP(WP,VP,_P)
        local XP=s[87]();
        if BP[l[1693]] then
          WP={};
          if XP[l[40]](VP)==l[1346] then
            for xP,xP in y[3],VP,nil do
              WP[xP]=l[383];
            end;
          elseif XP[l[40]](VP)==l[409] then
            for xP in XP[l[409]][l[78]](VP,l[397])do
              WP[XP[l[409]][l[56]](xP,l[381])]=l[383];
            end;
          else
            return;
          end
          XP[l[1346]][l[267]](yC[l[1406]--[[]]]);
          for xP=l[229],#BP[l[1206]],l[229]do
            if WP[BP[l[1206]][xP]] then
              yC[l[1406]--[[]]][BP[l[1206]][xP]]=l[383];
            end
          end;
          kP();
          if not _P and BP[l[1617]] then
            I(BP[l[1617]],yC:get());
          end
          return;
        end
        if XP[l[40]](VP)~=l[409]or VP==yC[l[955]]and not y[18][l[921]]or not XP[l[1346]][l[23]](BP[l[1206]],VP) then
          return;
        end
        yC[l[955]]=VP;
        kP();
        if not _P and BP[l[1617]] then
          I(BP[l[1617]],VP);
        end
      end
      yC[l[1255]]=wP;
      local function wP(WP,VP)
        WP=s[87]();
        if WP[l[40]](VP)~=l[1346] then
          return;
        end
        local _P=BP[l[1693]]and yC:get()or yC[l[955]];
        BP[l[1206]]=VP;
        yC[l[955]]=nil;
        WP[l[1346]][l[267]](yC[l[1406]--[[]]]);
        JC();
        if BP[l[1693]] then
          yC:set(_P,l[383]);
        elseif _P and WP[l[1346]][l[23]](VP,_P) then
          yC:set(_P,l[383]);
        else
          yC:set(VP[l[229]],l[383]);
        end
        NP();
        if not yC[l[404]] then
          return;
        end
        if #VP==l[393] then
          PC();
          return;
        end
        sC();
      end
      yC[l[1087]]=wP;
      d(LC:GetPropertyChangedSignal(l[996]),function()
        local wP=s[87]();
        lC[l[392]]=wP[l[1459]][l[588]](l[393],j(LC)[l[636]]+l[310]);
      end);
      d(tP[l[445]],PC);
      d(QP[l[445]],function()
        if #BP[l[1206]]==l[393] then
          return;
        end
        yC:setopen(not yC[l[404]]);
        y[18]:chime(l[1352]);
      end);
      d(QP[l[1538]],function()
        zC=l[383];
        iP();
      end);
      d(QP[l[1628]],function()
        zC=l[1329];
        iP();
      end);
      JC();
      if BP[l[1693]] then
        if BP[l[950]]~=nil then
          yC:set(BP[l[950]]);
        end
      else
        yC:set(BP[l[950]]or BP[l[1206]][l[229]]);
      end
      NP();
      iP();
      y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
        local NP=s[87]();
        if BP[l[1693]] then
          return NP[l[1346]][l[978]](yC:get(),l[1200]);
        end
        return yC[l[955]];
      end,function(NP)
        yC:set(NP);
      end,{[l[284]]=function(NP)
        local wP=s[87]();
        if not BP[l[1693]] then
          return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
        end
        for WP in wP[l[409]][l[78]](NP,l[397])do
          if not wP[l[1346]][l[23]](BP[l[1206]],wP[l[409]][l[56]](WP,l[381])) then
            return l[1329];
          end
        end;
        return l[383];
      end});
      return yC;
    end
    fP[l[1336]]=J;
    local function J(NP,BP)
      NP=s[87]();
      BP=X(BP,{[l[572]]=l[138],[l[13]]=nil,[l[1013]]=nil,[l[1617]]=nil});
      fP[l[668]]+=l[229];
      local wP,WP,VP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
      local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
      local wP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[1655]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},_P);
      D(wP,l[1158]);
      local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},wP);
      local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
      D(xP,l[1158]);
      K(xP,l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[1017],l[1373]),NP[l[677]][l[772]](l[229],l[229])});
      local kP=BP[l[13]];
      if kP then
        local vP=a;
        local IP=l[859];
        local iP={};
        iP[l[1150]]=f();
        iP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
        iP[l[948]]=NP[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
        iP[l[1639]]=NP[l[1459]][l[588]](l[750],l[750]);
        iP[l[1646]]=l[229];
        iP[l[1451]]=y[30](BP[l[13]]);
        iP[l[936]]=R[l[1379]];
        iP[l[2]]=l[986];
        iP[l[1557]]=NP[l[128]][l[1557]][l[220]];
        iP[l[711]]=l[1092];
        kP=vP(IP,iP,wP);
      end
      local vP=kP or nil;
      local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP[l[13]]and l[941]or l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],BP[l[13]]and l[860]or l[1069],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[986],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[13]]and NP[l[128]][l[1634]][l[701]]or NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},wP);
      local IP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},wP);
      K(IP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
      local iP,EP,QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=_P};
      tP[l[572]]=BP[l[572]];
      EP(QP,tP);
      local NP={[l[266]]=_P};
      local EP=l[1329];
      local function QP()
        P(wP,H,{[l[1646]]=EP and l[393]or l[841]});
        P(XP,H,{[l[747]]=EP and l[330]or l[1373]});
        P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
        P(kP,H,{[l[916]]=EP and l[393]or l[986],[l[510]]=EP and R[l[1095]]or R[l[1379]]});
        if vP then
          P(vP,H,{[l[2]]=EP and l[393]or l[986],[l[936]]=EP and R[l[1095]]or R[l[1379]]});
        end
      end
      local function wP(XP)
        xP[l[1646]]=l[1567];
        IP[l[1646]]=l[263];
        P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
        P(IP,H,{[l[1646]]=l[229]});
        y[18]:chime(l[1320]);
        if BP[l[1617]] then
          I(BP[l[1617]]);
        end
      end
      NP[l[1498]]=wP;
      d(iP[l[445]],function()
        NP:fire();
      end);
      d(iP[l[1538]],function()
        EP=l[383];
        QP();
      end);
      d(iP[l[1628]],function()
        EP=l[1329];
        QP();
      end);
      local wP=SP(_P,BP[l[572]],WP,VP,{[l[1463]]=BP[l[1013]]or hP..l[1074]..BP[l[572]],[l[103]]=nil,[l[649]]=l[1329],[l[1498]]=function(SP)
        if SP then
          NP:fire();
        end
      end});
      NP[l[1686]]=wP;
      d(iP[l[861]],function()
        if not wP:flip() then
          return;
        end
        y[18]:chime(l[1352]);
      end);
      QP();
      return NP;
    end
    fP[l[138]]=J;
    local function J(NP,SP)
      NP=s[87]();
      SP=X(if NP[l[40]](SP)==l[409]then{[l[572]]=SP}else SP,{[l[572]]=l[1094],[l[13]]=nil,[l[1141]]=l[1329],[l[73]]=nil});
      fP[l[668]]+=l[229];
      local BP=aP[l[1594]--[[__index]]];
      local wP=a(l[211],{[l[1150]]=f(),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],l[393],l[393],l[393])or NP[l[1459]][l[772]](l[229],l[393],l[393],l[1243]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},BP);
      local WP,VP,_P=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=wP};
      _P[l[572]]=SP[l[572]];
      WP(VP,_P);
      BP=l[303];
      if SP[l[13]] then
        BP=l[1655];
        local WP=a;
        local VP=l[859];
        local _P={};
        _P[l[1150]]=f();
        _P[l[1016]]=NP[l[1689]][l[772]](l[393],l[393]);
        _P[l[948]]=NP[l[1459]][l[588]](l[303],l[303]);
        _P[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
        _P[l[1646]]=l[229];
        _P[l[1451]]=y[30](SP[l[13]]);
        _P[l[936]]=R[l[1379]];
        _P[l[2]]=l[1431];
        _P[l[1557]]=NP[l[128]][l[1557]][l[220]];
        _P[l[711]]=l[1158];
        WP(VP,_P,wP);
      else
      end
      local WP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP,l[393]),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[393],l[393])or NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[229],l[393]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=NP[l[1130]](SP[l[572]]),[l[510]]=SP[l[73]]or R[l[1379]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=not SP[l[1141]]and NP[l[128]][l[164]][l[1021]]or NP[l[128]][l[164]][l[31]],[l[789]]=SP[l[1141]]and l[383]or l[1329],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[65]]=SP[l[1141]]and NP[l[128]][l[65]][l[1728]]or NP[l[128]][l[65]][l[46]],[l[711]]=l[1158]},wP);
      if SP[l[1141]] then
        a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786])},wP);
      end
      BP={[l[266]]=wP,[l[1095]]=WP};
      local function NP(SP,wP)
        SP=s[87]();
        WP[l[1420]]=SP[l[1130]](wP);
      end
      BP[l[1255]]=NP;
      local function NP(SP)
        return WP[l[1420]];
      end
      BP[l[506]]=NP;
      local function NP(SP,wP)
        SP=s[87]();
        if SP[l[1703]](wP)==l[360] then
          WP[l[510]]=wP;
        end
      end
      BP[l[539]]=NP;
      return BP;
    end
    fP[l[1094]]=J;
    local function J(NP,SP)
      local BP=s[87]();
      SP=X(SP,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1013]]=nil,[l[1617]]=nil});
      if SP[l[230]]and BP[l[1703]](R[SP[l[230]]])==l[360] then
        local wP=SP[l[1617]];
        SP[l[950]]=R[SP[l[230]]];
        SP[l[1617]]=function(WP)
          y[18]:recolor(SP[l[230]],WP);
          if wP then
            wP(WP);
          end
        end;
      end
      fP[l[668]]+=l[229];
      local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
      local VP=aP[l[745]];
      local aP=l[291];
      local _P=l[291];
      local XP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
      local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1099],l[229],l[393]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=SP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},XP);
      local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[658],l[829]),[l[1535]]=SP[l[950]],[l[1418]]=l[393],[l[711]]=l[1158]},XP);
      D(kP,l[786]);
      local vP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[986]},kP);
      wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},kP);
      D(wP,l[786]);
      K(wP,l[117],{BP[l[677]][l[772]](l[393],l[1567]),BP[l[677]][l[772]](l[229],l[229])});
      local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[1452],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[913],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},XP),a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
      local EP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
      local GP=EP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=BP[l[740]][l[772]](l[393],l[829]),[l[1485]]=BP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=BP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},EP)or nil;
      if EP then
        D(EP,l[930]);
      end
      local QP=a(l[1751],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
      D(QP,l[930]);
      wP,NP=l[1622],{[l[500]]=l[117]};
      NP[l[1630]]=BP[l[1262]][l[772]]({BP[l[527]][l[772]](l[393],BP[l[360]][l[772]](l[229],l[229],l[229])),BP[l[527]][l[772]](l[229],BP[l[360]][l[353]](l[291],l[291],l[920]))});
      a(wP,NP,QP);
      a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},QP);
      NP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},QP);
      D(NP,l[930]);
      a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},NP);
      local tP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[730]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[422]),[l[1535]]=BP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
      D(tP,l[1158]);
      wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
      D(wP,l[1158]);
      local RP,gP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]](l[229],l[229],l[229]))};
      gP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[393]),BP[l[677]][l[772]](l[229],l[229])});
      a(RP,gP,wP);
      gP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
      D(gP,l[1158]);
      wP,NP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]]()),[l[500]]=l[117]};
      NP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[229]),BP[l[677]][l[772]](l[229],l[393])});
      a(wP,NP,gP);
      a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},tP);
      local uP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},tP);
      RP,NP=l[1112],{};
      NP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
      a(RP,NP,uP);
      a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},uP);
      local NP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[633]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
      D(NP,l[303]);
      a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},NP);
      wP={};
      for UP=l[393],l[1158],l[229]do
        BP[l[1346]][l[968]](wP,BP[l[527]][l[772]](UP/l[1158],BP[l[360]][l[149]](UP/l[1158],l[229],l[229])));
      end;
      gP,RP=l[1622],{};
      RP[l[1630]]=BP[l[1262]][l[772]](wP);
      a(gP,RP,NP);
      local UP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[948]]=BP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},NP);
      gP,wP=l[1112],{};
      wP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
      a(gP,wP,UP);
      a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},UP);
      local MP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1743],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=p(SP[l[950]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[913]},QP);
      D(MP,l[303]);
      local sC=a(l[734],{[l[1161]]=BP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[411]},MP);
      local function lC(LC,yC)
        local zC=s[87]();
        local TC=a;
        local nC=l[1742];
        local JC={};
        JC[l[1150]]=f();
        JC[l[1016]]=zC[l[1689]][l[772]](l[229],l[393]);
        JC[l[948]]=zC[l[1459]][l[772]](l[229],LC,l[393],l[1394]);
        JC[l[1639]]=zC[l[1459]][l[588]](l[1707],l[1707]);
        JC[l[1535]]=R[l[1466]];
        JC[l[1646]]=l[229];
        JC[l[1418]]=l[393];
        JC[l[1451]]=y[30](yC);
        JC[l[936]]=R[l[1379]];
        JC[l[2]]=l[986];
        JC[l[1557]]=zC[l[128]][l[1557]][l[220]];
        JC[l[711]]=l[913];
        local LC=TC(nC,JC,QP);
        D(LC,l[303]);
        d(LC[l[1538]],function()
          P(LC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
        end);
        d(LC[l[1628]],function()
          P(LC,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
        end);
        return LC;
      end
      local LC=lC(l[1726],l[1549]);
      local yC=lC(l[1026],l[967]);
      local lC={[l[266]]=XP,[l[404]]=l[1329],[l[1409]]=SP[l[950]],[l[771]]=l[1329]};
      local zC={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
      local TC,nC=l[1329];
      local JC=l[1329];
      local HC=l[393];
      local function fC(aC)
        local dC=s[87]();
        if not SP[l[1617]] then
          return;
        end
        local PC=y[18][l[921]];
        if PC then
          local ZC=HC;
          HC=ZC+l[229];
          ZC=nil;
          ZC,nC=l[1329],nil;
          JC=ZC;
          I(SP[l[1617]],aC);
          return;
        end
        nC=aC;
        PC=JC;
        if PC then
          return;
        end
        JC=l[383];
        aC=HC;
        HC=aC+l[229];
        local aC=HC;
        local PC=y[18][l[1478]];
        dC[l[1022]][l[1330]](l[1296],function()
          local dC=HC;
          if aC~=dC then
            return;
          end
          dC=nC;
          local HC=dC;
          nC=nil;
          JC=l[1329];
          if HC and y[18][l[630]]and PC==y[18][l[1478]] then
            I(SP[l[1617]],HC);
          end
        end);
      end
      gP,RP,wP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=XP};
      wP[l[572]]=SP[l[572]];
      gP(RP,wP);
      zC[l[434]],zC[l[900]],zC[l[999]]=BP[l[360]][l[1412]](SP[l[950]]);
      local function BP()
        local wP=s[87]();
        P(vP,H,{[l[747]]=(lC[l[404]]or TC)and l[393]or l[986]});
        P(xP,H,{[l[916]]=(lC[l[404]]or TC)and l[1209]or l[615]});
        P(kP,H,{[l[1639]]=wP[l[1459]][l[588]]((lC[l[404]]or TC)and l[688]or l[658],(lC[l[404]]or TC)and l[114]or l[829])});
      end
      local function wP(FP,xP)
        local vP=s[87]();
        local RP,gP,nC=vP[l[360]][l[149]](zC[l[434]],zC[l[900]],zC[l[999]]),vP[l[1459]][l[1368]](zC[l[900]],l[229]-zC[l[999]]),vP[l[1459]][l[772]](zC[l[434]],l[393],l[659],l[393]);
        if xP then
          uP[l[948]]=gP;
          UP[l[948]]=nC;
          uP[l[1535]]=RP;
          tP[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229]);
          kP[l[1535]]=RP;
        else
          P(uP,n,{[l[948]]=gP,[l[1535]]=RP});
          P(UP,n,{[l[948]]=nC});
          P(tP,n,{[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229])});
          P(kP,n,{[l[1535]]=RP});
        end
        if not MP:IsFocused() then
          MP[l[1420]]=p(RP);
        end
        lC[l[1409]]=RP;
        if FP then
          fC(RP);
        end
      end
      local function FP()
        local xP,vP,RP,gP,uP=s[87](),G(YP),e(YP),G(kP),e(kP);
        local UP,nC=gP[l[1437]]-vP[l[1437]]+uP[l[1437]]-aP,lC[l[771]]and gP[l[636]]-vP[l[636]]-l[1158]or gP[l[636]]-vP[l[636]]+uP[l[636]]+l[1158];
        UP=if UP+aP>RP[l[1437]]-l[930]then RP[l[1437]]-l[930]-aP else UP;
        QP[l[948]]=xP[l[1459]][l[588]](xP[l[35]][l[499]](xP[l[35]][l[850]](UP,l[930])+l[659]),xP[l[35]][l[499]](nC+l[659]));
        if EP then
          EP[l[948]]=QP[l[948]];
        end
      end
      local function xP()
        local vP=QP[l[1569]];
        local RP=lC[l[404]]and l[393]or l[229];
        b(QP,lC[l[404]]and l[894]or l[304],lC[l[404]]and N or q,function(gP)
          local uP=vP+(RP-vP)*gP;
          QP[l[1569]]=uP;
          if EP then
            EP[l[1646]]=uP;
            GP[l[747]]=l[615]+l[411]*uP;
          end
          if gP>=l[229] then
            QP[l[1324]]=lC[l[404]];
            if EP then
              EP[l[1324]]=lC[l[404]];
            end
          end
        end);
      end
      local GP;
      local function vP()
        local RP=GP;
        if RP then
          GP:Disconnect();
          GP=nil;
        end
      end
      local function RP()
        local gP=S;
        if gP>l[393] then
          return;
        end
        lC:setopen(l[1329]);
      end
      local function gP()
        local uP=S;
        if uP>l[393] then
          FP();
          return;
        end
        if not LP[l[1600]]or not KP[l[1324]]or not XP[l[1324]] then
          lC:setopen(l[1329]);
          return;
        end
        local XP,UP,nC,JC,HC,fC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],kP[l[81]],kP[l[160]];
        uP=HC[l[636]]+fC[l[636]]*l[659];
        if uP<XP[l[636]]or uP>XP[l[636]]+UP[l[636]]or uP<nC[l[636]]or uP>nC[l[636]]+JC[l[636]] then
          lC:setopen(l[1329]);
          return;
        end
        FP();
      end
      local function VP(XP,uP)
        local UP={};
        XP=s[87]();
        uP=uP and l[383]or l[1329];
        if lC[l[404]]==uP then
          return;
        end
        lC[l[404]]=uP;
        if uP then
          V();
          local V,uP,nC,JC=G(YP),e(YP),G(kP),e(kP);
          local G,kP=uP[l[636]]-(nC[l[636]]-V[l[636]]+JC[l[636]]+l[1158])-l[1158],nC[l[636]]-V[l[636]]-l[310];
          lC[l[771]]=G<_P and kP>G;
          QP[l[1016]]=XP[l[1689]][l[772]](l[393],lC[l[771]]and l[229]or l[393]);
          QP[l[1639]]=XP[l[1459]][l[588]](aP,_P);
          QP[l[1324]]=l[383];
          iP[l[1324]]=l[383];
          if EP then
            EP[l[1016]]=QP[l[1016]];
            EP[l[1639]]=QP[l[1639]];
            EP[l[1324]]=l[383];
          end
          FP();
          A,w=RP,QP;
          vP();
          UP[1]=(y[10][l[1119]]:Connect(gP));
          GP=UP[1];
        else
          vP();
          iP[l[1324]]=l[1329];
          local G=A==RP;
          if G then
            A,w=nil,nil;
          end
          if MP:IsFocused() then
            MP:ReleaseFocus();
          end
        end
        BP();
        xP();
      end
      lC[l[1521]--[[0]]]=VP;
      local function G(A,w)
        A=s[87]();
        w=if A[l[1703]](w)==l[409]then r(w)else w;
        if A[l[1703]](w)~=l[360] then
          return;
        end
        zC[l[434]],zC[l[900]],zC[l[999]]=A[l[360]][l[1412]](w);
        wP(l[383]);
      end
      lC[l[1255]]=G;
      local function G(A)
        return lC[l[1409]];
      end
      lC[l[506]]=G;
      local function G()
        if not zC[l[259]] then
          return;
        end
        zC[l[259]]=l[1329];
        zC[l[700]]=nil;
        if zC[l[1731]] then
          zC[l[1731]]:Disconnect();
          zC[l[1731]]=nil;
        end
        WP[l[1195]]=l[383];
        O(l[715]);
      end
      local function A()
        local w=s[87]();
        if zC[l[259]]and zC[l[700]] then
          local V,aP=w[l[1146]](function()
            zC[l[700]]();
            wP(l[383],l[383]);
          end);
          if not V then
            G();
            w[l[972]](l[1752]..w[l[1130]](aP));
          end
        end
      end
      local function w(V,aP)
        d(V[l[956]],G);
        d(V[l[1558]],function(GP)
          local FP=s[87]();
          if GP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and GP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
            return;
          end
          if zC[l[259]] then
            return;
          end
          zC[l[259]]=l[383];
          zC[l[700]]=aP;
          zC[l[225]]=GP;
          O(l[229]);
          zC[l[1731]]=B(GP,G);
          WP[l[1195]]=l[1329];
          A();
        end);
        d(V[l[412]],function(B)
          local V=s[87]();
          if B[l[1317]]==V[l[128]][l[1317]][l[1356]]or B[l[1317]]==V[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
            G();
          end
        end);
      end
      w(tP,function()
        local B,V,aP,GP=s[87](),tP[l[81]],tP[l[160]],v(zC[l[225]]);
        zC[l[900]]=B[l[35]][l[819]]((GP[l[1437]]-V[l[1437]])/B[l[35]][l[850]](aP[l[1437]],l[229]),l[393],l[229]);
        zC[l[999]]=l[229]-B[l[35]][l[819]]((GP[l[636]]-V[l[636]])/B[l[35]][l[850]](aP[l[636]],l[229]),l[393],l[229]);
      end);
      w(NP,function()
        local B,w,V=s[87](),NP[l[81]],NP[l[160]];
        zC[l[434]]=B[l[35]][l[819]]((v(zC[l[225]])[l[1437]]-w[l[1437]])/B[l[35]][l[850]](V[l[1437]],l[229]),l[393],l[229]);
      end);
      d(y[9][l[412]],function(B)
        local w=s[87]();
        if B[l[1317]]==w[l[128]][l[1317]][l[1356]]or B[l[1317]]==w[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
          G();
        end
      end);
      d(y[9][l[233]],function(G)
        local B=s[87]();
        if not zC[l[259]] then
          return;
        end
        if G[l[1317]]==B[l[128]][l[1317]][l[765]]or G[l[1317]]==B[l[128]][l[1317]][l[239]] then
          if G[l[1317]]==B[l[128]][l[1317]][l[239]]and G~=zC[l[225]] then
            return;
          end
          A();
        end
      end);
      d(MP[l[505]],function()
        O(l[229]);
        P(sC,H,{[l[747]]=l[615]});
      end);
      d(MP[l[722]],function()
        local G=s[87]();
        O(l[715]);
        P(sC,H,{[l[747]]=l[411]});
        local B=r(MP[l[1420]]);
        if B then
          zC[l[434]],zC[l[900]],zC[l[999]]=G[l[360]][l[1412]](B);
        end
        wP(l[383]);
      end);
      local function G(B)
        B[l[936]]=R[l[98]];
        B[l[2]]=l[393];
        P(B,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
      end
      d(LC[l[445]],function()
        local B=s[87]();
        if y[14] then
          B[l[1146]](y[14],p(lC[l[1409]]));
        end
        G(LC);
        y[18]:chime(l[1320]);
      end);
      d(yC[l[445]],function()
        local B=s[87]();
        local A=r(y[15]and B[l[199]](l[59],B[l[1146]](y[15])));
        if A then
          zC[l[434]],zC[l[900]],zC[l[999]]=B[l[360]][l[1412]](A);
          wP(l[383]);
          G(yC);
          y[18]:chime(l[1320]);
        end
      end);
      d(iP[l[445]],RP);
      d(IP[l[445]],function()
        lC:setopen(not lC[l[404]]);
        y[18]:chime(l[1352]);
      end);
      d(IP[l[1538]],function()
        TC=l[383];
        BP();
      end);
      d(IP[l[1628]],function()
        TC=l[1329];
        BP();
      end);
      wP(l[1329],l[383]);
      BP();
      VP=SP[l[1013]]or SP[l[230]]and l[1321]..SP[l[230]];
      y[18]:hook(VP or hP..l[1074]..SP[l[572]],l[1409],function()
        return lC[l[1409]];
      end,function(G)
        lC:set(G);
      end);
      return lC;
    end
    fP[l[1409]]=J;
    return fP;
  end
  cP[l[146]]=F;
  local function J(G,B)
    local A=s[87]();
    B=X(B,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1132]]=l[356],[l[1013]]=nil,[l[1617]]=nil});
    if B[l[230]]and A[l[1703]](R[B[l[230]]])==l[360] then
      local w=B[l[1617]];
      B[l[950]]=R[B[l[230]]];
      B[l[1617]]=function(F)
        y[18]:recolor(B[l[230]],F);
        if w then
          w(F);
        end
      end;
    end
    G=AP(B[l[1132]]);
    local w,F=mP(G,l[1295]);
    A[l[1346]][l[968]](OP,{[l[590]]=F,[l[572]]=B[l[572]],[l[12]]={}});
    F=a(l[211],{[l[1150]]=f(),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},w);
    D(F,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=A[l[1689]][l[772]](l[393],l[229]),[l[948]]=A[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},F);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=A[l[1459]][l[588]](l[393],l[688]),[l[1639]]=A[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},w),l[393],{A[l[677]][l[772]](l[393],l[229]),A[l[677]][l[772]](l[841],l[874]),A[l[677]][l[772]](l[659],l[393]),A[l[677]][l[772]](l[804],l[874]),A[l[677]][l[772]](l[229],l[229])});
    a(l[1070],{[l[1150]]=f(),[l[948]]=A[l[1459]][l[588]](l[688],l[393]),[l[1639]]=A[l[1459]][l[772]](l[229],l[644],l[229],l[393]),[l[1646]]=l[229],[l[437]]=A[l[128]][l[437]][l[1381]],[l[1420]]=B[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=A[l[128]][l[164]][l[1021]],[l[711]]=l[1092]},F);
    local G,V,fP=a(l[211],{[l[1150]]=f(),[l[1016]]=A[l[1689]][l[772]](l[393],l[659]),[l[948]]=A[l[1459]][l[772]](l[393],l[730],l[659],l[393]),[l[1639]]=A[l[1459]][l[588]](l[310],l[310]),[l[1535]]=B[l[950]],[l[1418]]=l[393],[l[711]]=l[1092]},F),l[1112],{};
    fP[l[1182]]=A[l[740]][l[772]](l[229],l[393]);
    a(V,fP,G);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[615]},G);
    local A,F,V={[l[852]--[[readi16]]]=w,[l[1409]]=B[l[950]],[l[275]]=G},{};
    local G=l[1329];
    local fP=l[393];
    local function aP(GP)
      local NP=s[87]();
      if not B[l[1617]] then
        return;
      end
      local SP=y[18][l[921]];
      if SP then
        local BP=fP;
        fP=BP+l[229];
        BP=nil;
        BP,V=l[1329],nil;
        G=BP;
        I(B[l[1617]],GP);
        return;
      end
      V=GP;
      SP=G;
      if SP then
        return;
      end
      G=l[383];
      GP=fP;
      fP=GP+l[229];
      local GP=fP;
      local SP=y[18][l[1478]];
      NP[l[1022]][l[1330]](l[1296],function()
        local NP=fP;
        if GP~=NP then
          return;
        end
        NP=V;
        local fP=NP;
        V=nil;
        G=l[1329];
        if fP and y[18][l[630]]and SP==y[18][l[1478]] then
          I(B[l[1617]],fP);
        end
      end);
    end
    local function G(V,fP)
      A[l[1409]]=V;
      if fP then
        aP(V);
      end
    end
    A[l[1328]]=G;
    local function V(fP,aP)
      fP=s[87]();
      aP=if fP[l[1703]](aP)==l[409]then r(aP)else aP;
      if fP[l[1703]](aP)==l[360] then
        F[l[391]](aP);
      end
    end
    A[l[1255]]=V;
    local function V(fP)
      return A[l[1409]];
    end
    A[l[506]]=V;
    local function V(fP,aP)
      local GP=s[87]();
      local NP=a;
      local SP=l[1742];
      local BP={};
      BP[l[1150]]=f();
      BP[l[1016]]=GP[l[1689]][l[772]](l[229],l[659]);
      BP[l[948]]=GP[l[1459]][l[772]](l[229],fP,l[393],l[1413]);
      BP[l[1639]]=GP[l[1459]][l[588]](l[1707],l[1707]);
      BP[l[1535]]=R[l[1466]];
      BP[l[1646]]=l[229];
      BP[l[1418]]=l[393];
      BP[l[1451]]=y[30](aP);
      BP[l[936]]=R[l[1379]];
      BP[l[2]]=l[986];
      BP[l[1557]]=GP[l[128]][l[1557]][l[220]];
      BP[l[711]]=l[1092];
      local fP=NP(SP,BP,w);
      D(fP,l[303]);
      d(fP[l[1538]],function()
        P(fP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
      end);
      d(fP[l[1628]],function()
        P(fP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
      end);
      return fP;
    end
    local fP=V(l[1263],l[1549]);
    local aP=V(l[1026],l[967]);
    local function V(GP)
      GP[l[936]]=R[l[98]];
      GP[l[2]]=l[393];
      P(GP,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
    end
    d(fP[l[445]],function()
      local GP=s[87]();
      if y[14] then
        GP[l[1146]](y[14],p(A[l[1409]]));
      end
      V(fP);
    end);
    d(aP[l[445]],function()
      local p=s[87]();
      local fP=r(y[15]and p[l[199]](l[59],p[l[1146]](y[15])));
      if fP then
        F[l[391]](fP);
        V(aP);
      end
    end);
    DP(w,A,F);
    G=B[l[1013]]or B[l[230]]and l[1321]..B[l[230]];
    y[18]:hook(G or oP..l[1074]..B[l[572]],l[1409],function()
      return A[l[1409]];
    end,function(G)
      A:set(G);
    end);
    return A;
  end
  cP[l[1409]]=J;
  local function J(G,p)
    G=s[87]();
    p=X(p,{[l[572]]=l[1104],[l[1132]]=l[356]});
    local r=AP(p[l[1132]]);
    local B,A=mP(r,l[994]);
    G[l[1346]][l[968]](OP,{[l[590]]=A,[l[572]]=p[l[572]],[l[12]]={}});
    r=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},B);
    D(r,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[393],l[229]),[l[948]]=G[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},r);
    local A=a;
    local w=l[859];
    local F={};
    F[l[1150]]=f();
    F[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
    F[l[948]]=G[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
    F[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
    F[l[1646]]=l[229];
    F[l[1451]]=y[30](l[317]);
    F[l[936]]=R[l[1379]];
    F[l[2]]=l[986];
    F[l[1557]]=G[l[128]][l[1557]][l[220]];
    F[l[711]]=l[1092];
    A(w,F,r);
    a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=G[l[1459]][l[772]](l[229],l[207],l[229],l[393]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},r);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[393],l[688]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},B),l[393],{G[l[677]][l[772]](l[393],l[229]),G[l[677]][l[772]](l[841],l[874]),G[l[677]][l[772]](l[659],l[393]),G[l[677]][l[772]](l[804],l[874]),G[l[677]][l[772]](l[229],l[229])});
    local A=a(l[1439],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[392]]=G[l[1459]][l[772]](),[l[969]]=l[393],[l[711]]=l[1158]},B);
    D(A,l[1158]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},A);
    local w=a(l[755],{[l[407]]=G[l[128]][l[407]][l[537]],[l[536]]=G[l[740]][l[772]](l[393],l[59])},A);
    a(l[1359],{[l[299]]=G[l[740]][l[772]](l[393],l[786]),[l[645]]=G[l[740]][l[772]](l[393],l[786]),[l[1612]]=G[l[740]][l[772]](l[393],l[786]),[l[517]]=G[l[740]][l[772]](l[393],l[786])},A);
    d(w:GetPropertyChangedSignal(l[996]),function()
      local F=s[87]();
      A[l[392]]=F[l[1459]][l[588]](l[393],j(w)[l[636]]+l[930]);
    end);
    local w=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[633]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1604],[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[659],[l[1324]]=l[1329],[l[711]]=l[1092]},B);
    local F=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1571]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[658]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=G[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[759],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},B);
    D(F,l[1158]);
    a(l[1359],{[l[1612]]=G[l[740]][l[772]](l[393],l[730]),[l[517]]=G[l[740]][l[772]](l[393],l[730])},F);
    local V=a(l[734],{[l[1161]]=G[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1419]},F);
    local fP=a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1331]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},B);
    p,r=l[755],{[l[101]]=G[l[128]][l[101]][l[1505]],[l[407]]=G[l[128]][l[407]][l[537]]};
    r[l[536]]=G[l[740]][l[772]](l[393],l[1158]);
    a(p,r,fP);
    local p=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1307],l[1322]),[l[1639]]=G[l[1459]][l[772]](l[229],l[749],l[393],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[229],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},B);
    local G=l[393];
    local r=l[1329];
    local function aP(GP,NP,DP)
      local SP,BP=s[87](),G;
      G=BP+l[229];
      r=DP and l[383]or l[1329];
      local BP=G;
      p[l[1420]]=GP;
      p[l[510]]=NP or R[l[1379]];
      P(p,n,{[l[916]]=l[874]});
      if DP then
        return;
      end
      SP[l[1022]][l[1330]](l[1586],function()
        local GP=G;
        if GP==BP then
          P(p,H,{[l[916]]=l[229]});
        end
      end);
    end
    local function GP()
      local NP=r;
      if not NP then
        return;
      end
      NP=G;
      G=NP+l[229];
      r=l[1329];
      P(p,H,{[l[916]]=l[229]});
    end
    local G,p,r={};
    local function NP(DP)
      local SP,BP=s[87](),p;
      local wP,FP,hP=BP==DP[l[572]],DP[l[1466]],{};
      hP[l[1646]]=wP and l[1422]or l[629];
      P(FP,H,hP);
      local BP,FP,hP,WP=DP[l[1642]],{},l[1646],wP and l[841]or(DP[l[892]]and l[659]or l[229]);
      FP[hP]=WP;
      P(BP,H,FP);
      WP,BP=DP[l[1473]],{};
      BP[l[747]]=wP and l[1567]or l[229];
      P(WP,H,BP);
      P(DP[l[451]],H,{[l[1639]]=SP[l[1459]][l[772]](l[393],l[863],l[393],wP and l[750]or l[393]),[l[1646]]=wP and l[1296]or l[229]});
      P(DP[l[647]],H,{[l[2]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[936]]=wP and R[l[1095]]or R[l[1379]]});
      P(DP[l[1615]],H,{[l[916]]=wP and l[393]or(DP[l[892]]and l[263]or l[330]),[l[510]]=wP and R[l[1095]]or R[l[1379]]});
    end
    local function DP()
      for SP,SP in y[3],G,nil do
        NP(SP);
      end;
    end
    local function SP(BP)
      p=BP;
      F[l[1420]]=BP or l[1746];
      DP();
    end
    local function DP()
      local BP=sP(F[l[1420]])or p;
      if not BP then
        aP(l[455]);
        return;
      end
      local wP=y[18]:store(BP);
      if wP then
        p=BP;
        aP(l[1426]..BP,R[l[1095]]);
        zP();
      else
        aP(l[1702]);
      end
    end
    local function BP()
      local wP=p;
      if not wP then
        aP(l[1138]);
        return;
      end
      wP=(y[18]:store(p));
      if wP then
        F[l[1420]]=p;
        aP(l[479]..p,R[l[1095]]);
        zP();
      else
        aP(l[262]);
      end
    end
    local function wP(FP)
      local hP=sP(FP)or p;
      if not hP then
        aP(l[1138]);
        return;
      end
      if y[18]:fetch(hP) then
        SP(hP);
        aP(l[264]..hP,R[l[1095]]);
      else
        FP=y[18][l[171]];
        aP(FP and FP[l[1290]]and FP[l[1290]][l[229]]or l[418]);
      end
    end
    local function FP()
      local hP=p or sP(F[l[1420]]);
      if not hP then
        aP(l[1138]);
        return;
      end
      local WP=y[18]:erase(hP);
      if WP then
        if y[18]:autoload()==hP then
          y[18]:setautoload(nil);
        end
        p=nil;
        F[l[1420]]=l[1746];
        aP(l[285]..hP,R[l[1095]]);
        zP();
      else
        aP(l[1292]);
      end
    end
    local function hP()
      local WP,VP=sP(F[l[1420]]),p;
      if not VP then
        aP(l[1138]);
        return;
      end
      if not WP then
        aP(l[155]);
        return;
      end
      local VP,_P=p,y[18]:retitle(p,WP);
      if _P and y[18]:autoload()==VP then
        y[18]:setautoload(_P);
      end
      if _P then
        SP(_P);
        aP(l[355].._P,R[l[1095]]);
        zP();
      else
        aP(l[119]);
      end
    end
    local function zP(WP)
      local VP={};
      local _P=s[87]();
      for XP,XP in y[3],G,nil do
        for xP,xP in y[3],XP[l[608]],nil do
          xP:Disconnect();
        end;
        XP[l[1466]]:Destroy();
      end;
      _P[l[1346]][l[267]](G);
      local XP=p and not _P[l[1346]][l[23]](WP,p);
      if XP then
        p=nil;
      end
      w[l[1324]]=#WP==l[393];
      for w,XP in y[3],WP,nil do
        local WP={[l[572]]=XP,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1132]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=w,[l[711]]=l[1158]},A)};
        D(WP[l[1466]],l[1158]);
        WP[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},WP[l[1466]]);
        WP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},WP[l[1466]]);
        D(WP[l[1642]],l[1158]);
        K(WP[l[1642]],l[393],{_P[l[677]][l[772]](l[393],l[393]),_P[l[677]][l[772]](l[509],l[986]),_P[l[677]][l[772]](l[229],l[1017])});
        WP[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=_P[l[1689]][l[772]](l[393],l[659]),[l[948]]=_P[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},WP[l[1466]]);
        local xP,kP=l[1112],{};
        kP[l[1182]]=_P[l[740]][l[772]](l[229],l[393]);
        a(xP,kP,WP[l[451]]);
        VP[1]=l[647];
        VP[3]=a;
        VP[4]=l[859];
        VP[2]={};
        VP[2][l[1150]]=f();
        VP[2][l[1016]]=_P[l[1689]][l[772]](l[393],l[659]);
        VP[2][l[948]]=_P[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
        VP[2][l[1639]]=_P[l[1459]][l[588]](l[310],l[310]);
        VP[2][l[1646]]=l[229];
        VP[2][l[1451]]=y[30](XP==y[18]:autoload()and l[1059]or l[1177]);
        VP[2][l[936]]=R[l[1379]];
        VP[2][l[2]]=l[229];
        VP[2][l[1557]]=_P[l[128]][l[1557]][l[220]];
        VP[2][l[711]]=l[1092];
        VP[5]=(VP[3](VP[4],VP[2],WP[l[1466]]));
        WP[VP[1]]=VP[5];
        WP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=_P[l[1459]][l[588]](l[688],l[393]),[l[1639]]=_P[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=_P[l[128]][l[437]][l[1381]],[l[1420]]=XP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[229],[l[164]]=_P[l[128]][l[164]][l[1021]],[l[1634]]=_P[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},WP[l[1466]]);
        WP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},WP[l[1466]]);
        _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1538]]:Connect(function()
          WP[l[892]]=l[383];
          NP(WP);
        end));
        _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[1628]]:Connect(function()
          WP[l[892]]=l[1329];
          NP(WP);
        end));
        _P[l[1346]][l[968]](WP[l[608]],WP[l[974]][l[445]]:Connect(function()
          local VP=s[87]();
          local XP,xP=VP[l[655]][l[1587]](),p;
          VP=xP==WP[l[572]]and XP-(r or l[393])<l[330];
          if VP then
            r=nil;
            wP(WP[l[572]]);
            return;
          end
          r=XP;
          SP(WP[l[572]]);
        end));
        G[w]=WP;
        _P[l[1022]][l[1330]]((w-l[229])*l[182],function()
          if WP[l[1466]][l[382]] then
            NP(WP);
          end
        end);
      end;
    end
    local function G()
      local r=p;
      if not r then
        aP(l[1138]);
        return;
      end
      r=y[18]:autoload()==p;
      if r then
        y[18]:setautoload(nil);
        aP(l[851],R[l[1095]]);
      else
        local r=y[18]:setautoload(p);
        if r then
          aP(l[830]..p,R[l[1095]]);
        else
          aP(l[1702]);
        end
      end
      zP(y[18]:roster());
    end
    local r=l[393];
    local function w(NP,WP,VP)
      local _P,XP=s[87](),r;
      r=XP+l[229];
      local XP=a(l[1742],{[l[1150]]=f(),[l[1639]]=_P[l[1459]][l[772]](l[528],l[66],l[229],l[393]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1451]]=l[1746],[l[537]]=r,[l[711]]=l[1158]},fP);
      D(XP,l[1158]);
      local r=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[923]},XP);
      local fP=a;
      local xP=l[859];
      local kP={};
      kP[l[1150]]=f();
      kP[l[1016]]=_P[l[1689]][l[772]](l[659],l[659]);
      kP[l[948]]=_P[l[1459]][l[1368]](l[659],l[659]);
      kP[l[1639]]=_P[l[1459]][l[588]](l[973],l[973]);
      kP[l[1646]]=l[229];
      kP[l[1451]]=y[30](NP);
      kP[l[936]]=R[l[1379]];
      kP[l[2]]=l[986];
      kP[l[1557]]=_P[l[128]][l[1557]][l[220]];
      kP[l[711]]=l[1092];
      local NP=fP(xP,kP,XP);
      d(XP[l[1538]],function()
        P(XP,H,{[l[1646]]=l[393]});
        P(r,H,{[l[747]]=l[323]});
        P(NP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
        aP(WP,R[l[1379]],l[383]);
      end);
      d(XP[l[1628]],function()
        P(XP,H,{[l[1646]]=l[841]});
        P(r,H,{[l[747]]=l[923]});
        P(NP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]]});
        GP();
      end);
      d(XP[l[445]],function()
        NP[l[936]]=R[l[98]];
        P(NP,H,{[l[936]]=R[l[1095]]});
        y[18]:chime(l[1320]);
        VP();
      end);
      return XP;
    end
    w(l[317],l[512],DP);
    w(l[1517],l[680],wP);
    w(l[1169],l[172],BP);
    w(l[1177],l[1222],hP);
    w(l[905],l[704],FP);
    w(l[1059],l[1125],G);
    d(F[l[505]],function()
      P(V,H,{[l[747]]=l[615]});
    end);
    d(F[l[722]],function(G)
      P(V,H,{[l[747]]=l[1419]});
      if G then
        DP();
      end
    end);
    y[18]:watch(zP);
    w={[l[852]--[[readi16]]]=B,[l[1206]]=A,[l[1002]]=function()
      zP(y[18]:roster());
    end};
    local function G(r)
      r=p;
      return r;
    end
    w[l[506]]=G;
    local function G(p,p)
      SP(sP(p));
    end
    w[l[199]]=G;
    return w;
  end
  cP[l[963]]=J;
  local function J(G,p)
    local r={};
    G=s[87]();
    p=X(p,{[l[572]]=l[1503],[l[13]]=l[1736],[l[1132]]=l[356],[l[1477]]=l[1363],[l[1206]]={},[l[950]]=nil,[l[1693]]=l[1329],[l[798]]=l[1191],[l[1410]]=l[1736],[l[294]]=l[151],[l[136]]=l[1158],[l[1141]]=l[1329],[l[634]]=l[1329],[l[4]]=l[383],[l[1105]]=l[383],[l[1009]]=l[1329],[l[424]]=nil,[l[603]]=nil,[l[1669]]=nil,[l[472]]=l[686],[l[1013]]=nil,[l[1617]]=nil});
    local B,A,w=G[l[35]][l[819]](G[l[35]][l[499]](G[l[1382]](p[l[1477]])or l[1363]),l[422],l[218]),p[l[4]]and l[383]or l[1329],G[l[40]](p[l[424]])==l[1346]and p[l[424]]or{};
    local F,V=p[l[1105]]and l[383]or l[1329]or#w>l[393],y[31][G[l[409]][l[345]](G[l[1130]](p[l[798]]))];
    local sP=l[1289]+(A and l[913]or l[393]);
    local zP=sP+B+l[930];
    local fP,aP=zP+(F and l[1282]or l[393]),AP(p[l[1132]]);
    local GP,NP=mP(aP,fP+l[1707]);
    G[l[1346]][l[968]](OP,{[l[590]]=NP,[l[572]]=p[l[572]],[l[12]]={}});
    aP=a(l[211],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},GP);
    D(aP,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[393],l[229]),[l[948]]=G[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},aP);
    local DP=a;
    local SP=l[859];
    local BP={};
    BP[l[1150]]=f();
    BP[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
    BP[l[948]]=G[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
    BP[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
    BP[l[1646]]=l[229];
    BP[l[1451]]=y[30](p[l[13]]);
    BP[l[936]]=R[l[1379]];
    BP[l[2]]=l[986];
    BP[l[1557]]=G[l[128]][l[1557]][l[220]];
    BP[l[711]]=l[1092];
    DP(SP,BP,aP);
    a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=G[l[1459]][l[772]](l[229],l[571],l[229],l[393]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},aP);
    local DP=a(l[1070],{[l[1150]]=f(),[l[1016]]=G[l[1689]][l[772]](l[229],l[659]),[l[948]]=G[l[1459]][l[772]](l[229],l[1026],l[659],l[393]),[l[1639]]=G[l[1459]][l[588]](l[1632],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[121],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[1431],[l[1634]]=G[l[128]][l[1634]][l[877]],[l[711]]=l[1092]},aP);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[393],l[688]),[l[1639]]=G[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},GP),l[393],{G[l[677]][l[772]](l[393],l[229]),G[l[677]][l[772]](l[841],l[874]),G[l[677]][l[772]](l[659],l[393]),G[l[677]][l[772]](l[804],l[874]),G[l[677]][l[772]](l[229],l[229])});
    local aP,SP;
    if A then
      aP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[658]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=G[l[128]][l[437]][l[1381]],[l[592]]=R[l[1379]],[l[32]]=l[4],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},GP);
      D(aP,l[1158]);
      a(l[1359],{[l[1612]]=G[l[740]][l[772]](l[393],l[1249]),[l[517]]=G[l[740]][l[772]](l[393],l[730])},aP);
      SP=a(l[734],{[l[1161]]=G[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[1419]},aP);
      local A=a;
      local BP=l[859];
      local wP={};
      wP[l[1150]]=f();
      wP[l[1016]]=G[l[1689]][l[772]](l[393],l[659]);
      wP[l[948]]=G[l[1459]][l[772]](l[393],l[1707],l[393],l[29]);
      wP[l[1639]]=G[l[1459]][l[588]](l[750],l[750]);
      wP[l[1646]]=l[229];
      wP[l[1451]]=y[30](l[4]);
      wP[l[936]]=R[l[1379]];
      wP[l[2]]=l[1431];
      wP[l[1557]]=G[l[128]][l[1557]][l[220]];
      wP[l[711]]=l[930];
      A(BP,wP,GP);
    else
    end
    local A=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=G[l[1459]][l[588]](l[730],sP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],B),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[392]]=G[l[1459]][l[772]](),[l[656]]=l[383],[l[1226]]=G[l[128]][l[1226]][l[364]],[l[1195]]=l[383],[l[231]]=R[l[98]],[l[761]]=p[l[634]]and l[1431]or l[229],[l[969]]=p[l[634]]and l[863]or l[393],[l[62]]=G[l[128]][l[62]][l[636]],[l[711]]=l[1158]},GP);
    D(A,l[1158]);
    local BP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},A);
    local wP=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],sP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],B),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=p[l[472]],[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[659],[l[1324]]=l[1329],[l[711]]=l[1092]},GP);
    local FP,hP;
    if F then
      FP=a(l[211],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[730],zP),[l[1639]]=G[l[1459]][l[772]](l[229],l[1274],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},GP);
      sP,B=l[755],{[l[101]]=G[l[128]][l[101]][l[1505]],[l[407]]=G[l[128]][l[407]][l[537]]};
      B[l[536]]=G[l[740]][l[772]](l[393],l[1158]);
      a(sP,B,FP);
    else
    end
    hP=a(l[1070],{[l[1150]]=f(),[l[948]]=G[l[1459]][l[588]](l[1307],fP),[l[1639]]=G[l[1459]][l[772]](l[229],l[749],l[393],l[558]),[l[1646]]=l[229],[l[437]]=G[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1379]],[l[723]]=l[1307],[l[916]]=l[229],[l[164]]=G[l[128]][l[164]][l[1021]],[l[1634]]=G[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},GP);
    local B=l[393];
    local F=l[1329];
    local function sP(zP,fP,WP)
      local VP,_P=s[87](),B;
      B=_P+l[229];
      F=WP and l[383]or l[1329];
      local _P=B;
      hP[l[1420]]=zP;
      hP[l[510]]=fP or R[l[1379]];
      P(hP,n,{[l[916]]=l[874]});
      if WP then
        return;
      end
      VP[l[1022]][l[1330]](l[1586],function()
        local n=B;
        if n==_P then
          P(hP,H,{[l[916]]=l[229]});
        end
      end);
    end
    local function n()
      local zP=F;
      if not zP then
        return;
      end
      zP=B;
      B=zP+l[229];
      F=l[1329];
      P(hP,H,{[l[916]]=l[229]});
    end
    local B;
    local F,zP,fP={},{};
    local hP,WP={},{};
    local VP=l[393];
    local _P,XP=l[393],{};
    local xP=G[l[35]][l[819]](G[l[35]][l[499]](G[l[1382]](p[l[294]])or l[151]),l[520],l[667]);
    local kP=G[l[35]][l[850]](G[l[35]][l[499]](G[l[1382]](p[l[136]])or l[1158]),l[59]);
    local vP=l[303];
    local IP=p[l[1141]]and l[688]or l[558];
    local iP,EP=l[229],xP;
    local QP=xP+IP;
    local tP=xP+IP+l[1158];
    local RP=l[1746];
    local gP=l[383];
    local uP=l[1329];
    local UP,MP,sC,lC,LC,yC,zC=l[393];
    local function TC(nC)
      local JC=s[87]();
      if JC[l[40]](nC)==l[409] then
        if nC==l[1746] then
          return nil;
        end
        return{[l[572]]=nC,[l[1094]]=nC};
      end
      if JC[l[40]](nC)~=l[1346] then
        return nil;
      end
      local HC=nC[l[572]]or nC[l[1150]]or nC[l[1094]]or nC[l[1053]]or nC[l[1463]]or nC[l[1554]];
      if HC==nil then
        return nil;
      end
      HC=JC[l[1130]](HC);
      local fC,aC=JC[l[1382]](nC[l[1463]]or nC[l[1554]]or nC[l[568]]or nC[l[584]]or nC[l[1191]]or nC[l[1199]]or nC[l[1428]]or nC[l[707]]or nC[l[1675]]),nC[l[1736]]or nC[l[1451]]or nC[l[13]]or nC[l[79]]or nC[l[103]]or nC[l[798]]or nC[l[1035]];
      return{[l[572]]=HC,[l[1094]]=JC[l[1130]](nC[l[1062]]or nC[l[1389]]or nC[l[1094]]or nC[l[1053]]or HC),[l[1463]]=fC,[l[103]]=(JC[l[40]](aC)==l[409]or JC[l[40]](aC)==l[384])and aC or nil,[l[83]]=JC[l[1703]](nC[l[83]])==l[1689]and nC[l[83]]or nil,[l[297]]=JC[l[1703]](nC[l[297]])==l[1689]and nC[l[297]]or nil};
    end
    local function nC(JC)
      local HC=s[87]();
      if JC[l[103]] then
        return y[30](JC[l[103]]);
      end
      if V and JC[l[1463]]and JC[l[1463]]>l[393] then
        return HC[l[409]][l[846]](V,JC[l[1463]]);
      end
      return l[1746];
    end
    r[1]=y[18];
    r[2]=l[372];
    r[3]=y[18][l[372]]or{[l[805]]={},[l[1335]]={}};
    r[1][r[2]]=r[3];
    local V,JC=y[18][l[372]],{};
    local HC=l[1329];
    local function fC(aC)
      local dC,PC=s[87](),aC and nC(aC)or l[1746];
      if PC==l[1746]or V[l[805]][PC]or V[l[1335]][PC] then
        return;
      end
      V[l[1335]][PC]=l[383];
      JC[#JC+l[229]]=PC;
      PC=HC;
      if PC then
        return;
      end
      HC=l[383];
      dC[l[1022]][l[281]](function()
        local aC=s[87]();
        local dC=aC[l[1458]]:GetService(l[1358]);
        while y[18][l[630]]and#JC>l[393]do
          local PC={};
          for ZC=l[229],aC[l[35]][l[457]](l[310],#JC),l[229]do
            PC[#PC+l[229]]=aC[l[1346]][l[1357]](JC,l[229]);
          end;
          local ZC=aC[l[1146]](dC[l[1424]],dC,PC);
          for dC,dC in y[5](PC)do
            V[l[1335]][dC]=nil;
            if ZC then
              V[l[805]][dC]=l[383];
            end
          end;
          aC[l[1022]][l[153]]();
        end;
        for dC,dC in y[5](JC)do
          V[l[1335]][dC]=nil;
        end;
        aC[l[1346]][l[267]](JC);
        HC=l[1329];
      end);
    end
    local function V(JC)
      if p[l[1693]] then
        return hP[JC]==l[383];
      end
      local HC=fP;
      return HC==JC;
    end
    local function JC()
      local HC=not p[l[1693]];
      if HC then
        local aC=fP and l[229]or l[393];
        return aC;
      end
      HC=l[393];
      for aC in y[3],hP,nil do
        HC+=l[229];
      end;
      return HC;
    end
    local function HC()
      local aC,dC,PC=s[87](),#zP,#F;
      if dC==PC then
        DP[l[1420]]=p[l[1693]]and JC()..l[532]..PC or aC[l[1130]](PC);
      else
        DP[l[1420]]=dC..l[532]..PC;
      end
    end
    local function DP()
      local JC=not p[l[1693]];
      if JC then
        local aC=fP;
        return aC;
      end
      JC={};
      for aC=l[229],#F,l[229]do
        local dC=F[aC][l[572]];
        if hP[dC] then
          JC[#JC+l[229]]=dC;
        end
      end;
      return JC;
    end
    local function JC()
      if p[l[1617]]and not y[18][l[1334]] then
        I(p[l[1617]],DP());
      end
    end
    local function aC(dC,PC)
      if not dC[l[1466]][l[1324]]and not PC then
        return;
      end
      local ZC=dC[l[572]]~=nil and V(dC[l[572]]);
      local V,GC=dC[l[892]]and not ZC,ZC and l[1422]or l[1250];
      local YC,eC,jC,CC,NC,qC=ZC and l[1209]or(V and l[323]or l[229]),ZC and l[615]or(V and l[1419]or l[229]),ZC and R[l[98]]or R[l[966]],ZC and l[393]or(V and l[841]or l[330]),ZC and R[l[1095]]or R[l[1379]],ZC and l[393]or(V and l[629]or l[120]);
      dC[l[1040]][l[1324]]=ZC;
      if PC then
        dC[l[1466]][l[1646]]=GC;
        dC[l[1642]][l[1646]]=YC;
        dC[l[1473]][l[747]]=eC;
        dC[l[1473]][l[1630]]=jC;
        dC[l[1615]][l[916]]=CC;
        dC[l[1615]][l[510]]=NC;
        dC[l[748]][l[2]]=qC;
        return;
      end
      P(dC[l[1466]],H,{[l[1646]]=GC});
      P(dC[l[1642]],H,{[l[1646]]=YC});
      P(dC[l[1473]],H,{[l[747]]=eC,[l[1630]]=jC});
      P(dC[l[1615]],H,{[l[916]]=CC,[l[510]]=NC});
      P(dC[l[748]],H,{[l[2]]=qC});
    end
    local function V(dC)
      if not dC[l[572]] then
        return;
      end
      y[18]:chime(l[1320]);
      local PC=p[l[1693]];
      if PC then
        if hP[dC[l[572]]] then
          hP[dC[l[572]]]=nil;
        else
          hP[dC[l[572]]]=l[383];
        end
      else
        local ZC=fP;
        fP=if ZC==dC[l[572]]then nil else dC[l[572]];
      end
      PC,dC=l[229],VP;
      for ZC=PC,dC,l[229]do
        aC(WP[ZC]);
      end;
      HC();
      JC();
    end
    local function dC()
      local PC=s[87]();
      local ZC={[l[892]]=l[1329],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[588]](EP,QP),[l[1535]]=R[l[1132]],[l[1646]]=l[1250],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1158]},A)};
      D(ZC[l[1466]],l[1158]);
      ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
      ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},ZC[l[1466]]);
      D(ZC[l[1642]],l[1158]);
      K(ZC[l[1642]],l[117],{PC[l[677]][l[772]](l[393],l[1209]),PC[l[677]][l[772]](l[509],l[1431]),PC[l[677]][l[772]](l[229],l[1419])});
      local GC,YC,eC,jC,CC,NC=l[748],l[859],{[l[1150]]=f(),[l[948]]=PC[l[1459]][l[588]](l[786],l[786])},l[1639],PC[l[1459]][l[588]],EP;
      local qC,bC=NC-l[930],EP;
      eC[jC]=CC(qC,bC-l[930]);
      eC[l[1535]]=R[l[641]];
      eC[l[1646]]=l[323];
      eC[l[1418]]=l[393];
      eC[l[1451]]=l[1746];
      eC[l[936]]=PC[l[360]][l[772]](l[229],l[229],l[229]);
      eC[l[2]]=l[120];
      eC[l[1557]]=PC[l[128]][l[1557]][l[220]];
      eC[l[711]]=l[1092];
      ZC[GC]=a(YC,eC,ZC[l[1466]]);
      D(ZC[l[748]],l[303]);
      ZC[l[1040]]=a(l[211],{[l[1150]]=f(),[l[1016]]=PC[l[1689]][l[772]](l[229],l[393]),[l[948]]=PC[l[1459]][l[772]](l[229],l[348],l[393],l[1158]),[l[1639]]=PC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[930]},ZC[l[1466]]);
      YC,CC=l[1112],{};
      CC[l[1182]]=PC[l[740]][l[772]](l[229],l[393]);
      a(YC,CC,ZC[l[1040]]);
      local bC=a;
      local DC=l[859];
      local pC={};
      pC[l[1150]]=f();
      pC[l[1016]]=PC[l[1689]][l[772]](l[659],l[659]);
      pC[l[948]]=PC[l[1459]][l[1368]](l[659],l[659]);
      pC[l[1639]]=PC[l[1459]][l[588]](l[551],l[551]);
      pC[l[1646]]=l[229];
      pC[l[1451]]=y[30](l[1411]);
      pC[l[936]]=R[l[641]];
      pC[l[1557]]=PC[l[128]][l[1557]][l[220]];
      pC[l[711]]=l[551];
      bC(DC,pC,ZC[l[1040]]);
      GC,qC,CC,jC,eC,NC,YC=l[1615],l[1070],{[l[1150]]=f()},l[948],PC[l[1459]][l[588]],l[786],EP;
      CC[jC]=eC(NC,YC-l[863]);
      CC[l[1639]]=PC[l[1459]][l[772]](l[229],l[1519],l[393],IP);
      CC[l[1646]]=l[229];
      CC[l[437]]=PC[l[128]][l[437]][l[1381]];
      CC[l[1420]]=l[1746];
      CC[l[510]]=R[l[1379]];
      CC[l[723]]=l[1307];
      CC[l[916]]=l[330];
      CC[l[164]]=p[l[1141]]and PC[l[128]][l[164]][l[31]]or PC[l[128]][l[164]][l[1021]];
      CC[l[789]]=p[l[1141]];
      CC[l[65]]=p[l[1141]]and PC[l[128]][l[65]][l[1728]]or PC[l[128]][l[65]][l[46]];
      CC[l[711]]=l[1092];
      ZC[GC]=a(qC,CC,ZC[l[1466]]);
      ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=PC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},ZC[l[1466]]);
      d(ZC[l[974]][l[1538]],function()
        ZC[l[892]]=l[383];
        aC(ZC);
        if ZC[l[572]] then
          sP(ZC[l[1094]]or ZC[l[572]],R[l[1379]],l[383]);
        end
      end);
      d(ZC[l[974]][l[1628]],function()
        ZC[l[892]]=l[1329];
        aC(ZC);
        n();
      end);
      d(ZC[l[974]][l[445]],function()
        if ZC[l[1142]] then
          ZC[l[1142]]=nil;
          return;
        end
        V(ZC);
      end);
      if PC[l[40]](p[l[1669]])==l[1712] then
        local function V()
          local IP=s[87]();
          if not ZC[l[572]] then
            return;
          end
          y[18]:chime(l[1320]);
          local GC=ZC[l[1466]][l[81]];
          IP[l[1022]][l[281]](p[l[1669]],ZC[l[572]],B,GC[l[1437]]+ZC[l[1466]][l[160]][l[1437]]*l[659],GC[l[636]]+l[310],ZC[l[1466]]);
        end
        d(ZC[l[974]][l[861]],V);
        d(ZC[l[974]][l[1558]],function(IP)
          local GC=s[87]();
          if IP[l[1317]]~=GC[l[128]][l[1317]][l[239]] then
            return;
          end
          local IP=GC[l[655]][l[1587]]();
          ZC[l[259]]=IP;
          GC[l[1022]][l[1330]](l[615],function()
            if ZC[l[259]]==IP then
              ZC[l[259]]=nil;
              ZC[l[1142]]=l[383];
              V();
            end
          end);
        end);
        d(ZC[l[974]][l[233]],function(V)
          local IP=s[87]();
          if V[l[1317]]==IP[l[128]][l[1317]][l[239]] then
            ZC[l[259]]=nil;
          end
        end);
        d(ZC[l[974]][l[412]],function(V)
          local IP=s[87]();
          if V[l[1317]]==IP[l[128]][l[1317]][l[239]] then
            ZC[l[259]]=nil;
          end
        end);
      end
      if PC[l[40]](p[l[603]])==l[1346] then
        ZC[l[247]]=a(l[1742],{[l[1150]]=f(),[l[1016]]=PC[l[1689]][l[772]](l[229],l[393]),[l[948]]=PC[l[1459]][l[772]](l[229],l[66],l[393],l[303]),[l[1639]]=PC[l[1459]][l[588]](l[1241],l[1241]),[l[1535]]=R[l[641]],[l[1646]]=l[874],[l[1418]]=l[393],[l[43]]=l[383],[l[1451]]=l[1746],[l[711]]=l[730]},ZC[l[1466]]);
        D(ZC[l[247]],l[303]);
        a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},ZC[l[247]]);
        local V=a;
        local IP=l[859];
        local GC={};
        GC[l[1150]]=f();
        GC[l[1016]]=PC[l[1689]][l[772]](l[659],l[659]);
        GC[l[948]]=PC[l[1459]][l[1368]](l[659],l[659]);
        GC[l[1639]]=PC[l[1459]][l[588]](l[310],l[310]);
        GC[l[1646]]=l[229];
        GC[l[1451]]=y[30](p[l[603]][l[13]]or l[1716]);
        GC[l[936]]=R[l[1095]];
        GC[l[2]]=l[263];
        GC[l[1557]]=PC[l[128]][l[1557]][l[220]];
        GC[l[711]]=l[1307];
        local PC=V(IP,GC,ZC[l[247]]);
        d(ZC[l[247]][l[1538]],function()
          local V,IP=ZC[l[247]],{};
          IP[l[1646]]=l[393];
          P(V,H,IP);
          P(PC,H,{[l[2]]=l[393],[l[936]]=R[l[98]]});
        end);
        d(ZC[l[247]][l[1628]],function()
          local V,IP=ZC[l[247]],{};
          IP[l[1646]]=l[874];
          P(V,H,IP);
          P(PC,H,{[l[2]]=l[263],[l[936]]=R[l[1095]]});
        end);
        d(ZC[l[247]][l[445]],function()
          local V=s[87]();
          if not ZC[l[572]] then
            return;
          end
          y[18]:chime(l[1320]);
          local IP=p[l[603]][l[1617]];
          if V[l[40]](IP)==l[1712] then
            local PC=ZC[l[1466]][l[81]];
            V[l[1022]][l[281]](IP,ZC[l[572]],B,PC[l[1437]]+l[1243],PC[l[636]]+l[1707],ZC[l[1466]]);
          end
        end);
      end
      return ZC;
    end
    local function V(IP)
      local PC=s[87]();
      IP[l[1466]][l[1639]]=PC[l[1459]][l[588]](EP,QP);
      local ZC,GC,YC,eC=IP[l[748]],l[1639],PC[l[1459]][l[588]],EP;
      local jC,CC=eC-l[930],EP;
      ZC[GC]=YC(jC,CC-l[930]);
      GC,eC,ZC,YC,jC=IP[l[1615]],l[948],PC[l[1459]][l[588]],l[786],EP;
      GC[eC]=ZC(YC,jC-l[863]);
    end
    local function IP()
      local PC,ZC=s[87](),e(A)[l[1437]]-vP*l[59];
      if ZC<l[1707] then
        return l[1329];
      end
      local GC=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC+kP)/(xP+kP)),l[229]);
      local xP=PC[l[35]][l[850]](PC[l[35]][l[499]]((ZC-kP*(GC-l[229]))/GC),l[1249]);
      ZC=GC==iP and xP==EP;
      if ZC then
        return l[1329];
      end
      iP,EP=GC,xP;
      xP=EP;
      QP=xP+l[558];
      tP=QP+kP;
      for xP=l[229],#WP,l[229]do
        V(WP[xP]);
      end;
      return l[383];
    end
    local function V()
      local xP={};
      local QP,PC=s[87](),#zP;
      local ZC=QP[l[1459]][l[588]](l[393],QP[l[35]][l[850]](QP[l[35]][l[139]](PC/iP)*tP-kP+vP*l[59],l[393]));
      if A[l[392]]~=ZC then
        A[l[392]]=ZC;
      end
      local GC,YC,eC=A[l[1690]][l[636]],e(A)[l[636]],y[18][l[388]]and l[863]or l[59];
      ZC=QP[l[35]][l[850]](QP[l[35]][l[499]]((GC-vP)/tP)-eC,l[393]);
      local jC,CC=QP[l[35]][l[850]](QP[l[35]][l[139]]((GC+YC-vP)/tP)+eC,ZC+l[229]),ZC*iP+l[229];
      GC,ZC=QP[l[35]][l[457]](jC*iP,PC),iP;
      jC=ZC*(QP[l[35]][l[139]](YC/tP)+l[59]+eC*l[59]+l[229]);
      eC=MP==CC and sC==GC and lC==jC and LC==EP and yC==iP and zC==UP;
      if eC then
        return;
      end
      MP,sC,lC,LC,yC,zC=CC,GC,jC,EP,iP,UP;
      YC=jC~=_P;
      if YC then
        _P=jC;
        for _P=l[229],#WP,l[229]do
          WP[_P][l[572]]=nil;
          WP[_P][l[1466]][l[1324]]=l[1329];
        end;
      end
      QP[l[1346]][l[267]](XP);
      ZC=l[229];
      for _P=CC,GC,ZC do
        eC=zP[_P];
        if eC then
          fC(eC);
          YC=(_P-l[229])%jC+l[229];
          local MP=WP[YC];
          if not MP then
            MP=dC();
            WP[YC]=MP;
          else
          end
          XP[YC]=l[383];
          local sC,lC,LC=MP[l[572]]~=eC[l[572]]or MP[l[463]]~=eC,QP[l[35]][l[499]]((_P-l[229])/iP),(_P-l[229])%iP;
          MP[l[572]]=eC[l[572]];
          MP[l[463]]=eC;
          MP[l[1094]]=eC[l[1094]];
          MP[l[1466]][l[948]]=QP[l[1459]][l[588]](vP+LC*(EP+kP),vP+lC*tP);
          if sC then
            MP[l[1615]][l[1420]]=eC[l[1094]];
            MP[l[748]][l[1451]]=nC(eC);
            MP[l[748]][l[589]]=eC[l[83]]or QP[l[1689]][l[1729]];
            MP[l[748]][l[315]]=eC[l[297]]or QP[l[1689]][l[1729]];
            if MP[l[748]][l[1451]]==l[1746] then
              xP[1]=MP[l[748]];
              xP[2]=l[1451];
              xP[3]=(y[30](p[l[1410]]));
              xP[1][xP[2]]=xP[3];
              MP[l[748]][l[936]]=R[l[1379]];
            else
              MP[l[748]][l[936]]=QP[l[360]][l[772]](l[229],l[229],l[229]);
            end
          end
          if not MP[l[1466]][l[1324]] then
            MP[l[1466]][l[1324]]=l[383];
          end
          aC(MP,l[383]);
        end
      end;
      for _P=GC+l[229],QP[l[35]][l[457]](GC+jC,PC),l[229]do
        fC(zP[_P]);
      end;
      for _P=l[229],#WP,l[229]do
        if not XP[_P] then
          CC=WP[_P];
          CC[l[572]]=nil;
          CC[l[1466]][l[1324]]=l[1329];
        end
      end;
      VP=#WP;
    end
    local function _P()
      local XP,xP=s[87](),uP;
      if xP then
        return;
      end
      uP=l[383];
      XP[l[1022]][l[1061]](function()
        uP=l[1329];
        local XP=not LP[l[1600]]or not KP[l[1324]]or not NP[l[1273]];
        if XP then
          gP=l[383];
          return;
        end
        gP=l[1329];
        IP();
        V();
      end);
    end
    local function V()
      local XP,xP=s[87](),UP;
      UP=xP+l[229];
      XP[l[1346]][l[267]](zP);
      xP=RP;
      local vP=xP==l[1746];
      if vP then
        for vP=l[229],#F,l[229]do
          zP[vP]=F[vP];
        end;
      else
        local vP,IP,EP=l[229],#F,l[229];
        for QP=vP,IP,EP do
          xP=F[QP];
          QP=XP[l[409]][l[23]](XP[l[409]][l[345]](xP[l[1094]]),RP,l[229],l[383])or XP[l[409]][l[23]](XP[l[409]][l[345]](xP[l[572]]),RP,l[229],l[383]);
          if QP then
            zP[#zP+l[229]]=xP;
          end
        end;
      end
      wP[l[1324]]=#zP==l[393];
      A[l[1690]]=XP[l[1689]][l[772]](l[393],XP[l[35]][l[457]](A[l[1690]][l[636]],XP[l[35]][l[850]](XP[l[35]][l[139]](#zP/XP[l[35]][l[850]](iP,l[229]))*tP-e(A)[l[636]],l[393])));
      HC();
      _P();
    end
    local function wP(XP)
      local xP=s[87]();
      xP[l[1346]][l[267]](F);
      local vP={};
      if xP[l[40]](XP)==l[1346] then
        for IP,iP in y[3],XP,nil do
          IP=TC(iP);
          if IP and not vP[IP[l[572]]] then
            vP[IP[l[572]]]=l[383];
            F[#F+l[229]]=IP;
          end
        end;
      end
      XP=p[l[1693]];
      if XP then
        for XP in y[3],hP,nil do
          if not vP[XP] then
            hP[XP]=nil;
          end
        end;
      else
        xP=fP and not vP[fP];
        if xP then
          fP=nil;
        end
      end
      V();
    end
    d(A:GetPropertyChangedSignal(l[1690]),_P);
    d(A:GetPropertyChangedSignal(l[160]),_P);
    d(A[l[1538]],function()
      P(BP,H,{[l[747]]=l[659]});
    end);
    d(A[l[1628]],function()
      P(BP,H,{[l[747]]=l[52]});
    end);
    if aP then
      d(aP[l[505]],function()
        P(SP,H,{[l[747]]=l[615]});
      end);
      d(aP[l[722]],function()
        P(SP,H,{[l[747]]=l[1419]});
      end);
      d(aP:GetPropertyChangedSignal(l[1420]),function()
        local SP=s[87]();
        local BP,XP=SP[l[409]][l[345]](SP[l[409]][l[56]](aP[l[1420]],l[381])or l[1746]),RP;
        if BP==XP then
          return;
        end
        RP=BP;
        V();
      end);
    end
    B={[l[852]--[[readi16]]]=GP,[l[1206]]=A,[l[1722]]=F};
    local function A(GP)
      return DP();
    end
    B[l[506]]=A;
    local function A(GP,SP,BP)
      local XP,xP=s[87](),p[l[1693]];
      if xP then
        XP[l[1346]][l[267]](hP);
        if XP[l[40]](SP)==l[1346] then
          for vP,IP in y[3],SP,nil do
            if IP==l[383]and XP[l[40]](vP)==l[409] then
              hP[vP]=l[383];
            elseif XP[l[40]](IP)==l[409]and IP~=l[1746] then
              hP[IP]=l[383];
            end
          end;
        elseif XP[l[40]](SP)==l[409]and SP~=l[1746] then
          for vP in XP[l[409]][l[78]](SP,l[397])do
            GP=XP[l[409]][l[56]](vP,l[381]);
            if GP~=l[1746] then
              hP[GP]=l[383];
            end
          end;
        end
      else
        SP=if XP[l[40]](SP)==l[1346]then SP[l[572]]or SP[l[1150]]else SP;
        fP=XP[l[40]](SP)==l[409]and SP~=l[1746]and SP or nil;
      end
      xP,SP=l[229],VP;
      for GP=xP,SP,l[229]do
        aC(WP[GP]);
      end;
      HC();
      if not BP then
        JC();
      end
    end
    B[l[1255]]=A;
    local function A(GP,GP)
      wP(GP);
    end
    B[l[699]]=A;
    local function A(GP,GP)
      B:set(GP,l[383]);
    end
    B[l[529]]=A;
    local function GP(SP)
      SP=s[87]();
      SP[l[1346]][l[267]](hP);
      fP=nil;
      local SP,BP=l[229],VP;
      for XP=SP,BP,l[229]do
        aC(WP[XP]);
      end;
      HC();
      JC();
    end
    B[l[267]]=GP;
    local function GP(SP)
      if not p[l[1693]] then
        return;
      end
      for SP=l[229],#zP,l[229]do
        hP[zP[SP][l[572]]]=l[383];
      end;
      local zP,SP=l[229],VP;
      for BP=zP,SP,l[229]do
        aC(WP[BP]);
      end;
      HC();
      JC();
    end
    B[l[868]]=GP;
    local function zP(SP)
      V();
    end
    B[l[1002]]=zP;
    local function SP(BP)
      BP={};
      for hP=l[229],#F,l[229]do
        BP[hP]=F[hP][l[572]];
      end;
      return BP;
    end
    B[l[690]]=SP;
    local function SP(BP,hP)
      BP=s[87]();
      if aP then
        aP[l[1420]]=BP[l[1130]](hP or l[1746]);
      end
    end
    B[l[4]]=SP;
    if FP then
      GP,A=l[393],{};
      if p[l[1693]] then
        A[#A+l[229]]={[l[13]]=l[1411],[l[1658]]=l[1514],[l[1617]]=function()
          B:all();
        end};
        A[#A+l[229]]={[l[13]]=l[898],[l[1658]]=l[1664],[l[1617]]=function()
          B:clear();
        end};
      elseif p[l[1105]] then
        A[#A+l[229]]={[l[13]]=l[898],[l[1658]]=l[1664],[l[1617]]=function()
          B:clear();
        end};
      end
      if p[l[1105]] then
        A[#A+l[229]]={[l[13]]=l[1169],[l[1658]]=l[1117],[l[1617]]=function()
          V();
        end};
      end
      for V,V in y[3],w,nil do
        if G[l[40]](V)==l[1346] then
          A[#A+l[229]]=V;
        end
      end;
      zP=G[l[35]][l[850]](#A,l[229]);
      for w,w in y[3],A,nil do
        GP+=l[229];
        local A=a(l[1742],{[l[1150]]=f(),[l[1639]]=G[l[1459]][l[772]](l[229]/zP,-(kP*(zP-l[229]))/zP,l[229],l[393]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[1451]]=l[1746],[l[537]]=GP,[l[711]]=l[1158]},FP);
        D(A,l[1158]);
        local V=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[923]},A);
        r[5]=a;
        r[6]=l[859];
        r[4]={};
        r[4][l[1150]]=f();
        r[4][l[1016]]=G[l[1689]][l[772]](l[659],l[659]);
        r[4][l[948]]=G[l[1459]][l[1368]](l[659],l[659]);
        r[4][l[1639]]=G[l[1459]][l[588]](l[973],l[973]);
        r[4][l[1646]]=l[229];
        r[4][l[1451]]=y[30](w[l[13]]or w[l[79]]or l[234]);
        r[4][l[936]]=R[l[1379]];
        r[4][l[2]]=l[986];
        r[4][l[1557]]=G[l[128]][l[1557]][l[220]];
        r[4][l[711]]=l[1092];
        local zP=r[5](r[6],r[4],A);
        local r=w[l[1658]]or w[l[1033]]or w[l[572]]or w[l[1150]];
        d(A[l[1538]],function()
          P(A,H,{[l[1646]]=l[393]});
          P(V,H,{[l[747]]=l[323]});
          P(zP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]]});
          if r then
            sP(r,R[l[1379]],l[383]);
          end
        end);
        d(A[l[1628]],function()
          P(A,H,{[l[1646]]=l[841]});
          P(V,H,{[l[747]]=l[923]});
          P(zP,H,{[l[2]]=l[986],[l[936]]=R[l[1379]]});
          n();
        end);
        d(A[l[445]],function()
          local n=s[87]();
          zP[l[936]]=R[l[98]];
          P(zP,H,{[l[936]]=R[l[1095]]});
          y[18]:chime(l[1320]);
          local r=w[l[1617]]or w[l[1683]];
          if n[l[40]](r)==l[1712] then
            n[l[1022]][l[281]](r,B);
          end
        end);
      end;
    end
    local function n()
      local r=LP[l[1600]]and KP[l[1324]]and NP[l[1273]]and gP;
      if r then
        _P();
      end
    end
    d(NP[l[1594]--[[__index]]]:GetPropertyChangedSignal(l[1324]),n);
    d(KP:GetPropertyChangedSignal(l[1324]),n);
    d(dP:GetPropertyChangedSignal(l[1324]),n);
    wP(p[l[1206]]);
    if p[l[950]]~=nil then
      B:set(p[l[950]],l[383]);
    end
    y[18]:hook(p[l[1013]]or oP..l[1074]..p[l[572]],p[l[1693]]and l[1206]or l[409],function()
      local n=s[87]();
      if p[l[1693]] then
        return n[l[1346]][l[978]](DP(),l[1200]);
      end
      local n=fP or l[1746];
      return n;
    end,function(n)
      B:set(n,l[383]);
      if p[l[1617]] then
        I(p[l[1617]],DP());
      end
    end,{[l[284]]=function(n)
      local r=s[87]();
      local function A(w)
        for V,V in y[5](F)do
          if V[l[572]]==w then
            return l[383];
          end
        end;
        return l[1329];
      end
      if not p[l[1693]] then
        return n==l[1746]or A(n);
      end
      for p in r[l[409]][l[78]](n,l[397])do
        if not A(r[l[409]][l[56]](p,l[381])) then
          return l[1329];
        end
      end;
      return l[383];
    end});
    G[l[1022]][l[1061]](_P);
    return B;
  end
  cP[l[484]]=J;
  local function n(J,G)
    J=s[87]();
    G=X(G,{[l[572]]=l[1403],[l[13]]=l[453],[l[1132]]=l[356],[l[1477]]=l[1331],[l[273]]=l[1157],[l[1230]]=l[229],[l[1025]]=l[352],[l[687]]=l[348],[l[932]]=l[1655],[l[1330]]=l[323],[l[892]]=l[876],[l[150]]=l[659],[l[147]]=l[383],[l[1009]]=l[383],[l[1617]]=nil});
    local p,r=J[l[35]][l[819]](J[l[35]][l[499]](J[l[1382]](G[l[1477]])or l[1331]),l[117],l[218]),AP(G[l[1132]]);
    local B,A=mP(r,p+l[1506]);
    J[l[1346]][l[968]](OP,{[l[590]]=A,[l[572]]=G[l[572]],[l[12]]={}});
    local w=a(l[211],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},B);
    D(w,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=J[l[1689]][l[772]](l[393],l[229]),[l[948]]=J[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1158]},w);
    local F=a;
    local V=l[859];
    local sP={};
    sP[l[1150]]=f();
    sP[l[1016]]=J[l[1689]][l[772]](l[393],l[659]);
    sP[l[948]]=J[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
    sP[l[1639]]=J[l[1459]][l[588]](l[750],l[750]);
    sP[l[1646]]=l[229];
    sP[l[1451]]=y[30](G[l[13]]);
    sP[l[936]]=R[l[1379]];
    sP[l[2]]=l[986];
    sP[l[1557]]=J[l[128]][l[1557]][l[220]];
    sP[l[711]]=l[1092];
    F(V,sP,w);
    a(l[1070],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[1249],l[393]),[l[1639]]=J[l[1459]][l[772]](l[229],l[865],l[229],l[393]),[l[1646]]=l[229],[l[437]]=J[l[128]][l[437]][l[1381]],[l[1420]]=G[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=J[l[128]][l[164]][l[1021]],[l[1634]]=J[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},w);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[393],l[688]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1092]},B),l[393],{J[l[677]][l[772]](l[393],l[229]),J[l[677]][l[772]](l[841],l[874]),J[l[677]][l[772]](l[659],l[393]),J[l[677]][l[772]](l[804],l[874]),J[l[677]][l[772]](l[229],l[229])});
    local F=a(l[211],{[l[1150]]=f(),[l[948]]=J[l[1459]][l[588]](l[730],l[1289]),[l[1639]]=J[l[1459]][l[772]](l[229],l[1274],l[393],p),[l[1535]]=R[l[641]],[l[1646]]=l[1431],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},B);
    D(F,l[1158]);
    local V=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},F);
    p=a(l[211],{[l[1150]]=f(),[l[1016]]=J[l[1689]][l[772]](l[393],l[229]),[l[948]]=J[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=J[l[1459]][l[772]](l[229],l[393],l[1419],l[393]),[l[1535]]=R[l[1529]--[[cancel]]],[l[1646]]=l[804],[l[1418]]=l[393],[l[711]]=l[1158]},F);
    D(p,l[1158]);
    K(p,l[117],{J[l[677]][l[772]](l[393],l[229]),J[l[677]][l[772]](l[229],l[1431])});
    local p=a(l[757],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[854]]=J[l[360]][l[353]](l[1564],l[1564],l[1592]),[l[400]]=J[l[360]][l[353]](l[1682],l[1682],l[1682]),[l[879]]=J[l[135]][l[772]](l[1537]--[[Vector3]],l[715],l[758]),[l[711]]=l[1092]},F);
    D(p,l[1158]);
    local sP=p;
    if k(l[751]) then
      sP=a(l[751],{[l[1150]]=f()},p);
    else
    end
    local zP=a(l[1245],{[l[1150]]=f(),[l[1309]]=J[l[35]][l[819]](J[l[1382]](G[l[273]])or l[1157],l[730],l[856])},p);
    p[l[227]]=zP;
    local fP,aP=a(l[211],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[656]]=l[383],[l[711]]=l[930]},F),a(l[1742],{[l[1150]]=f(),[l[1639]]=J[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},F);
    local GP,NP={[l[852]--[[readi16]]]=B,[l[732]]=F,[l[1616]]=p,[l[541]]=sP,[l[179]]=zP,[l[410]]=fP,[l[1160]]=nil,[l[593]]=nil,[l[934]]={},[l[897]]=l[1329],[l[1025]]=J[l[1382]](G[l[1025]])or l[393],[l[687]]=J[l[35]][l[819]](J[l[1382]](G[l[687]])or l[393],l[1606],l[1367]),[l[1230]]=J[l[35]][l[819]](J[l[1382]](G[l[1230]])or l[229],l[615],l[786])},{};
    local B=J[l[135]][l[772]](l[786],l[1653],l[786]);
    local F=J[l[135]][l[772]](l[393],l[799],l[393]);
    local fP=J[l[135]][l[772]](l[393],l[799],l[393]);
    local DP=l[310];
    local oP=l[1329];
    local mP=l[1329];
    local SP,OP=l[393];
    local BP=l[393];
    local AP=l[393];
    local wP=l[1329];
    local FP=l[393];
    local function hP()
      local WP=s[87]();
      local VP,_P=WP[l[35]][l[899]](WP[l[35]][l[924]](zP[l[1309]]*l[659])),p[l[160]];
      local XP,xP,kP=_P[l[636]]>l[229]and _P[l[1437]]/_P[l[636]]or l[229],WP[l[35]][l[1575]],F;
      local vP,IP=kP[l[636]],fP;
      _P,kP=xP(vP-IP[l[636]]),B;
      vP,IP,xP=kP[l[636]]*l[659]+_P,WP[l[35]][l[18]],B;
      _P,kP=xP[l[1437]],B;
      local iP,EP=_P*kP[l[1437]],B;
      kP,_P=EP[l[989]],B;
      xP=IP(iP+kP*_P[l[989]])*l[659];
      DP=WP[l[35]][l[850]](vP/VP,xP/(VP*WP[l[35]][l[850]](XP,l[1296])))*l[618];
    end
    local function WP()
      local VP,_P=s[87](),l[1480];
      local XP,xP,kP,vP,IP=VP[l[1480]][l[772]](fP)*VP[l[1480]][l[369]](VP[l[35]][l[924]](GP[l[687]]),VP[l[35]][l[924]](GP[l[1025]]),l[393]),VP[l[1480]][l[772]],l[393],l[393],DP;
      zP[_P]=XP*xP(kP,vP,IP*GP[l[1230]]);
    end
    local function DP()
      local VP=p[l[382]];
      if not VP then
        return;
      end
      p[l[382]]=nil;
      p[l[382]]=VP;
    end
    local function VP()
      return p[l[81]]+h(),p[l[160]];
    end
    local function _P(XP)
      local xP,kP,vP=s[87](),VP();
      if vP[l[1437]]<l[229]or vP[l[636]]<l[229] then
        return l[393],l[393],l[1329];
      end
      local IP=zP[l[1480]]:PointToObjectSpace(XP);
      if IP[l[989]]>l[886]--[[readf32]] then
        return l[393],l[393],l[1329];
      end
      local iP,EP=xP[l[35]][l[899]](xP[l[35]][l[924]](zP[l[1309]]*l[659])),-IP[l[989]];
      XP,xP=IP[l[1437]]/(EP*iP*(vP[l[1437]]/vP[l[636]])),IP[l[636]]/(EP*iP);
      return kP[l[1437]]+vP[l[1437]]*(l[659]+XP*l[659]),kP[l[636]]+vP[l[636]]*(l[659]-xP*l[659]),l[383];
    end
    local function XP(xP)
      local kP=s[87]();
      for vP=#NP,l[229],l[715]do
        local IP=NP[vP];
        if kP[l[40]](IP)~=l[1712] then
          kP[l[1346]][l[1357]](NP,vP);
        elseif not kP[l[1146]](IP,GP,xP) then
          kP[l[1346]][l[1357]](NP,vP);
        end
      end;
    end
    local function xP()
      local kP,vP=s[87](),OP;
      if vP then
        OP:Disconnect();
        OP=nil;
      end
      if GP[l[1160]] then
        GP[l[1160]]:Destroy();
        GP[l[1160]]=nil;
      end
      kP[l[1346]][l[267]](GP[l[934]]);
      GP[l[593]]=nil;
      oP=l[1329];
    end
    local function kP(vP,IP,iP)
      local EP,QP=vP:GetChildren(),IP:GetChildren();
      for vP=l[229],#EP,l[229]do
        local tP,RP=EP[vP],QP[vP];
        RP=if not RP or RP[l[1150]]~=tP[l[1150]]or RP[l[657]]~=tP[l[657]]then IP:FindFirstChild(tP[l[1150]])else RP;
        if RP then
          if tP:IsA(l[1635])and RP:IsA(l[1635]) then
            iP[#iP+l[229]]={tP,RP};
          end
          kP(tP,RP,iP);
        end
      end;
    end
    local function vP(IP)
      local iP,EP,QP=s[87](),IP:GetDescendants();
      for tP,RP in y[3],EP,QP do
        tP=l[1635];
        if RP:IsA(tP) then
          RP[l[82]]=l[383];
          RP[l[1127]]=l[1329];
          RP[l[1219]]=l[383];
          RP[l[1312]]=l[1329];
          RP[l[1391]]=l[393];
        else
          IP=l[1266];
          if RP:IsA(IP) then
            local IP=RP:FindFirstChildOfClass(l[401]);
            if IP then
              IP:Destroy();
            end
            iP[l[1146]](function()
              local IP=s[87]();
              RP[l[702]]=IP[l[128]][l[1034]][l[31]];
              RP[l[873]]=IP[l[128]][l[1227]][l[1005]];
              RP[l[287]]=l[393];
              RP[l[736]]=l[393];
              RP[l[1233]]=l[1329];
              RP[l[47]]=l[1329];
              RP[l[1008]]=l[1329];
              RP[l[1374]]=l[1329];
              RP[l[540]]=RP[l[1698]];
            end);
          elseif RP:IsA(l[778])or RP:IsA(l[1058])or RP:IsA(l[1260])or RP:IsA(l[1245])or RP:IsA(l[1661])or RP:IsA(l[1000]) then
            RP:Destroy();
          end
        end
      end;
    end
    local function IP()
      local iP,EP=s[87](),not wP;
      if EP then
        wP=l[383];
        FP=iP[l[655]][l[1587]]();
      end
      SP=iP[l[655]][l[1587]]()+l[615];
    end
    local function iP()
      local EP,QP=s[87](),y[13][l[569]--[[traceback]]];
      if not QP or not QP[l[382]] then
        return;
      end
      local tP=QP[l[1281]]or QP:FindFirstChild(l[1405])or QP:FindFirstChild(l[780])or QP:FindFirstChild(l[1553])or QP:FindFirstChildWhichIsA(l[1635]);
      if not tP then
        return;
      end
      local RP,gP={},QP[l[1031]];
      local uP,UP=QP:GetDescendants();
      for MP,MP in y[3],uP,UP do
        if not MP[l[1031]] then
          RP[#RP+l[229]]=MP;
          EP[l[1146]](function()
            MP[l[1031]]=l[383];
          end);
        end
      end;
      EP[l[1146]](function()
        QP[l[1031]]=l[383];
      end);
      UP,uP=EP[l[1146]](function()
        return QP:Clone();
      end);
      EP[l[1146]](function()
        QP[l[1031]]=gP;
      end);
      for gP,gP in y[3],RP,nil do
        EP[l[1146]](function()
          gP[l[1031]]=l[1329];
        end);
      end;
      if not UP or not uP then
        return;
      end
      UP={};
      kP(QP,uP,UP);
      vP(uP);
      if #UP==l[393] then
        uP:Destroy();
        return;
      end
      uP[l[1150]]=f();
      xP();
      uP[l[382]]=sP;
      GP[l[1160]]=uP;
      GP[l[934]]=UP;
      GP[l[593]]=tP;
      RP=tP[l[1480]]:Inverse();
      for sP=l[229],#UP,l[229]do
        tP=UP[sP];
        if tP[l[229]][l[382]]and tP[l[59]][l[382]] then
          tP[l[59]][l[1480]]=RP*tP[l[229]][l[1480]];
        end
      end;
      UP,tP,RP=EP[l[1146]](uP[l[338]],uP);
      local sP=UP and EP[l[1703]](RP)==l[135]and RP[l[636]]>l[393];
      if sP then
        B=RP;
      end
      sP=UP and EP[l[1703]](tP)==l[1480];
      if sP then
        F=EP[l[135]][l[772]](l[393],tP[l[948]][l[636]],l[393]);
        local sP,kP,vP=EP[l[135]][l[772]],l[393],F;
        UP,RP=vP[l[636]],B;
        fP=sP(kP,UP-RP[l[636]]*l[922],l[393]);
      end
      oP=l[383];
      wP=l[1329];
      hP();
      WP();
      EP[l[1022]][l[1061]](DP);
      OP=d(QP[l[328]],function(B)
        if B:IsA(l[1635])or B:IsA(l[375])or B:IsA(l[674])or B:IsA(l[468])or B:IsA(l[1619]) then
          IP();
        end
      end);
      if G[l[1617]] then
        I(G[l[1617]],uP,GP);
      end
    end
    local function B()
      local F=GP[l[593]];
      if not F or not F[l[382]] then
        IP();
        return;
      end
      local sP,fP=F[l[1480]]:Inverse(),GP[l[934]];
      for OP=l[229],#fP,l[229]do
        F=fP[OP];
        local fP,OP=F[l[229]],F[l[59]];
        if fP[l[382]]and OP[l[382]] then
          OP[l[1480]]=sP*fP[l[1480]];
        end
      end;
    end
    d(p:GetPropertyChangedSignal(l[160]),function()
      hP();
      local p=oP;
      if p then
        WP();
      end
    end);
    d(y[10][l[1119]],function(p)
      local F,sP=s[87](),y[18][l[630]]and LP[l[1600]]and KP[l[1324]]and A[l[1273]]and l[383]or l[1329];
      if sP~=GP[l[897]] then
        GP[l[897]]=sP;
        if sP then
          F[l[1022]][l[1061]](DP);
        else
          XP(l[393]);
        end
      end
      if not sP then
        return;
      end
      sP=not oP or not GP[l[1160]]or not GP[l[1160]][l[382]];
      if sP then
        local A=F[l[655]][l[1587]]()>=SP;
        if A then
          SP=F[l[655]][l[1587]]()+l[330];
          iP();
        end
        return;
      end
      sP=wP and(F[l[655]][l[1587]]()>=SP or F[l[655]][l[1587]]()-FP>=l[59]);
      if sP then
        SP=F[l[655]][l[1587]]()+l[330];
        iP();
      end
      B();
      sP=mP;
      if sP then
        AP=l[393];
        local B,A=F[l[35]][l[850]],BP;
        BP=B(A-p*l[1092],l[393]);
      else
        AP+=p;
        local B=AP;
        local A=B>G[l[1330]];
        if A then
          local B,A=F[l[35]][l[457]],BP;
          BP=B(A+p/F[l[35]][l[850]](G[l[892]],l[1296]),l[229]);
        end
      end
      local B,A=G[l[932]]~=l[393];
      if B then
        sP=BP;
        A=sP>l[393];
      else
        A=B;
      end
      if A then
        B=BP*BP*(l[863]-l[59]*BP);
        GP[l[1025]]=(GP[l[1025]]+G[l[932]]*B*p)%l[1372];
      end
      WP();
      XP(p);
    end);
    d(aP[l[1558]],function(p)
      local B,A=s[87](),not G[l[147]]or mP;
      if A then
        return;
      end
      if p[l[1317]]~=B[l[128]][l[1317]][l[1356]]and p[l[1317]]~=B[l[128]][l[1317]][l[239]] then
        return;
      end
      mP=l[383];
      O(l[229]);
      r[l[1594]--[[__index]]][l[1195]]=l[1329];
      y[18]:chime(l[1320]);
      P(V,H,{[l[747]]=l[330]});
      A=(y[9]:GetMouseLocation());
      while true do
        local F=mP and(y[9]:IsMouseButtonPressed(B[l[128]][l[1317]][l[1356]])or p[l[1101]]~=B[l[128]][l[1101]][l[912]]);
        if not F then
          break;
        end
        F=(y[9]:GetMouseLocation());
        local p=F-A;
        local sP=p[l[1437]]~=l[393]or p[l[636]]~=l[393];
        if sP then
          GP[l[1025]]=(GP[l[1025]]-p[l[1437]]*G[l[150]])%l[1372];
          GP[l[687]]=B[l[35]][l[819]](GP[l[687]]-p[l[636]]*G[l[150]],l[1606],l[1367]);
          local p=oP;
          if p then
            WP();
          end
        end
        B[l[1022]][l[153]]();
        A=F;
      end;
      mP=l[1329];
      r[l[1594]--[[__index]]][l[1195]]=l[383];
      O(l[715]);
      P(V,H,{[l[747]]=l[52]});
    end);
    d(aP[l[412]],function(p)
      local r=s[87]();
      local B=p[l[1317]]==r[l[128]][l[1317]][l[1356]]or p[l[1317]]==r[l[128]][l[1317]][l[239]];
      if B then
        mP=l[1329];
      end
    end);
    d(y[9][l[412]],function(p)
      local r=s[87]();
      local B=p[l[1317]]==r[l[128]][l[1317]][l[1356]]or p[l[1317]]==r[l[128]][l[1317]][l[239]];
      if B then
        mP=l[1329];
      end
    end);
    d(aP[l[1538]],function()
      P(V,H,{[l[747]]=l[1017]});
    end);
    d(aP[l[1628]],function()
      local p=mP;
      if not p then
        P(V,H,{[l[747]]=l[52]});
      end
    end);
    local function p(r,B,A)
      r=s[87]();
      if r[l[1382]](B) then
        GP[l[1025]]=r[l[1382]](B)%l[1372];
      end
      if r[l[1382]](A) then
        GP[l[687]]=r[l[35]][l[819]](r[l[1382]](A),l[1606],l[1367]);
      end
      B=oP;
      if B then
        WP();
      end
    end
    GP[l[1255]]=p;
    local function p(r)
      return GP[l[1025]],GP[l[687]],GP[l[1230]];
    end
    GP[l[506]]=p;
    local function p(r,B)
      r=s[87]();
      GP[l[1230]]=r[l[35]][l[819]](r[l[1382]](B)or l[229],l[615],l[786]);
      r=oP;
      if r then
        WP();
      end
    end
    GP[l[55]]=p;
    local function p(r,B)
      r=s[87]();
      G[l[932]]=r[l[1382]](B)or l[393];
    end
    GP[l[1049]]=p;
    local function p(r,B)
      r=s[87]();
      zP[l[1309]]=r[l[35]][l[819]](r[l[1382]](B)or l[1157],l[730],l[856]);
      hP();
      r=oP;
      if r then
        WP();
      end
    end
    GP[l[1384]]=p;
    local function p(r)
      r=s[87]();
      GP[l[1025]]=r[l[1382]](G[l[1025]])or l[393];
      GP[l[687]]=r[l[35]][l[819]](r[l[1382]](G[l[687]])or l[393],l[1606],l[1367]);
      GP[l[1230]]=r[l[35]][l[819]](r[l[1382]](G[l[1230]])or l[229],l[615],l[786]);
      hP();
      r=oP;
      if r then
        WP();
      end
    end
    GP[l[1009]]=p;
    local function p(r)
      SP=l[393];
      xP();
    end
    GP[l[1002]]=p;
    local function p(r)
      DP();
    end
    GP[l[1555]]=p;
    local function p(r,B)
      r=s[87]();
      if r[l[40]](B)~=l[1712] then
        return function()
        end;
      end
      r[l[1346]][l[968]](NP,B);
      return function()
        local r=s[87]();
        local A=r[l[1346]][l[23]](NP,B);
        if A then
          r[l[1346]][l[1357]](NP,A);
        end
      end;
    end
    GP[l[64]]=p;
    local function p(r,B)
      r=s[87]();
      if r[l[1703]](B)~=l[135] then
        return r[l[1689]][l[772]](),l[1329];
      end
      local A,F,V=_P(B);
      if not V then
        return r[l[1689]][l[772]](),l[1329];
      end
      B,V=VP();
      return r[l[1689]][l[772]](A,F),A>=B[l[1437]]and F>=B[l[636]]and A<=B[l[1437]]+V[l[1437]]and F<=B[l[636]]+V[l[636]];
    end
    GP[l[467]]=p;
    local function p(r,B,A)
      local F,V=s[87](),B or GP[l[1160]];
      if not GP[l[897]]or not V or not V[l[382]] then
        return nil;
      end
      local sP=F[l[35]][l[1670]];
      local zP=F[l[35]][l[1670]];
      local fP=-l[94];
      local aP=-l[94];
      local NP=l[1329];
      local function DP(KP)
        local oP=s[87]();
        if KP[l[747]]>=l[229]or KP[l[1639]][l[945]]<=l[393] then
          return l[383];
        end
        local mP,SP,OP,BP=KP[l[1639]]*l[659],l[229],l[930],l[229];
        for AP=SP,OP,BP do
          local SP,OP,BP=_P(KP[l[1480]]*(o[AP]*mP));
          if not BP then
            return l[1329];
          end
          BP,AP=oP[l[35]][l[457]](sP,SP),oP[l[35]][l[457]](zP,OP);
          sP,zP=BP,AP;
          AP,BP=oP[l[35]][l[850]](fP,SP),oP[l[35]][l[850]](aP,OP);
          fP,aP=AP,BP;
        end;
        NP=l[383];
        return l[383];
      end
      B=l[1635];
      if V:IsA(B) then
        if not DP(V) then
          return nil;
        end
      elseif V==GP[l[1160]] then
        r=GP[l[934]];
        for o=l[229],#r,l[229]do
          local KP=r[o][l[59]];
          if KP[l[382]]and not DP(KP) then
            return nil;
          end
        end;
      else
        local o,KP=V:GetDescendants();
        for oP,oP in y[3],o,KP do
          if oP:IsA(l[1635])and not DP(oP) then
            return nil;
          end
        end;
      end
      B=not NP;
      if B then
        return nil;
      end
      V=not A;
      if V then
        r,B=VP();
        sP=F[l[35]][l[850]](sP,r[l[1437]]);
        zP=F[l[35]][l[850]](zP,r[l[636]]);
        fP=F[l[35]][l[457]](fP,r[l[1437]]+B[l[1437]]);
        aP=F[l[35]][l[457]](aP,r[l[636]]+B[l[636]]);
        A=fP-sP<l[229]or aP-zP<l[229];
        if A then
          return nil;
        end
      else
      end
      r,V,DP,F=sP,zP,fP-sP,aP-zP;
      return r,V,DP,F;
    end
    GP[l[83]]=p;
    local function p(r)
      local r,o=VP();
      return r,o,GP[l[897]];
    end
    GP[l[1470]]=p;
    if G[l[1009]] then
      local G=a;
      local p=l[1742];
      local r={};
      r[l[1150]]=f();
      r[l[1016]]=J[l[1689]][l[772]](l[229],l[659]);
      r[l[948]]=J[l[1459]][l[772]](l[229],l[1519],l[659],l[393]);
      r[l[1639]]=J[l[1459]][l[588]](l[1707],l[1707]);
      r[l[1535]]=R[l[1466]];
      r[l[1646]]=l[229];
      r[l[1418]]=l[393];
      r[l[1451]]=y[30](l[1169]);
      r[l[936]]=R[l[1379]];
      r[l[2]]=l[986];
      r[l[1557]]=J[l[128]][l[1557]][l[220]];
      r[l[711]]=l[930];
      local J=G(p,r,w);
      D(J,l[303]);
      d(J[l[1538]],function()
        P(J,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
      end);
      d(J[l[1628]],function()
        P(J,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
      end);
      d(J[l[445]],function()
        J[l[936]]=R[l[98]];
        P(J,H,{[l[936]]=R[l[1379]]});
        y[18]:chime(l[1320]);
        GP:reset();
        GP:refresh();
      end);
    end
    d(y[13][l[426]],IP);
    d(y[13][l[1385]],IP);
    return GP;
  end
  cP[l[822]]=n;
  return cP;
end
