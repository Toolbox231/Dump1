-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #17
-- offset 3600857..3601078 (221 bytes, type=payload)

function(v)
  local I=v.UserInputType==Enum.UserInputType.MouseButton1 or v.UserInputType==Enum.UserInputType.Touch;
  if I then
    local I;
    I,h=v.Position.X,true;
    _=I;
    x=v.UserInputType==Enum.UserInputType.Touch and v or nil;
  end
end
