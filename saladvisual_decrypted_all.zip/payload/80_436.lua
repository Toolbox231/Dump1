-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #436
-- offset 3427823..3429044 (1221 bytes, type=payload)

local function VP(_P,xP)
  local EP={};
  _P=s[87]();
  xP=xP and l[383]or l[1329];
  if yC[l[404]]==xP then
    return;
  end
  yC[l[404]]=xP;
  if xP then
    V();
    local xP,uP,GC,YC=G(YP),e(YP),G(vP),e(vP);
    yC[l[559]]=_P[l[35]][l[819]](_P[l[35]][l[850]](XP(),_P[l[35]][l[499]](YC[l[1437]]+l[659])),l[492],_P[l[35]][l[850]](_P[l[35]][l[499]](uP[l[1437]])-l[829],l[492]));
    yC[l[434]]=IP();
    local XP,vP=uP[l[636]]-(GC[l[636]]-xP[l[636]]+YC[l[636]]+l[1158])-l[1158],GC[l[636]]-xP[l[636]]-l[310];
    yC[l[771]]=XP<yC[l[434]]and vP>XP;
    UP[l[1016]]=_P[l[1689]][l[772]](l[393],yC[l[771]]and l[229]or l[393]);
    UP[l[1324]]=l[383];
    tP[l[1324]]=l[383];
    lC[l[1690]]=_P[l[1689]][l[772]]();
    if RP then
      RP[l[1016]]=UP[l[1016]];
      RP[l[1324]]=l[383];
    end
    sC();
    kP();
    vP=not BP[l[1693]];
    if vP then
      uP,XP,GC=l[229],#yC[l[1072]],l[229];
      for _P=uP,XP,GC do
        xP=yC[l[1072]][_P][l[572]]==yC[l[955]];
        if xP then
          TC=_P;
          MP(yC[l[1072]][_P],l[383]);
          gP(yC[l[1072]][_P]);
          break;
        end
      end;
    end
    A,w=PC,UP;
    aC();
    dC();
    EP[1]=(y[10][l[1119]]:Connect(ZC));
    HC=EP[1];
    EP[2]=(y[9][l[1558]]:Connect(WP));
    fC=EP[2];
  else
    aC();
    dC();
    tP[l[1324]]=l[1329];
    TC=l[393];
    local WP=A==PC;
    if WP then
      A,w=nil,nil;
    end
    for WP=l[229],#yC[l[1072]],l[229]do
      yC[l[1072]][WP][l[892]]=l[1329];
      MP(yC[l[1072]][WP],l[383]);
    end;
  end
  iP();
  nC();
end
