-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #40
-- offset 3219253..3219998 (745 bytes, type=payload)

local function b()
  local W=K or s:FindFirstChildOfClass("Sky");
  local V=not W and G.Body~="Default";
  if V then
    W=Instance.new("Sky");
    local _=l;
    W.Name=_.RandomString();
    W.Parent=s;
    e=W;
  else
  end
  if not W then
    return;
  end
  V=e and W==e and G.Body=="Default";
  if V then
    A(e);
    pcall(function()
      e:Destroy();
    end);
    e=nil;
    return;
  end
  B(W);
  O(W);
  W.StarCount=G.Stars;
  if G.Body=="Default" then
    W.CelestialBodiesShown=true;
    return;
  end
  W.CelestialBodiesShown=G.Body~="None";
  if G.Body=="Sun" then
    W.SunAngularSize=G.Size;
    W.MoonAngularSize=0;
  elseif G.Body=="Moon" then
    W.SunAngularSize=0;
    W.MoonAngularSize=G.Size;
  elseif G.Body=="Eclipse" then
    W.SunTextureId="rbxasset://sky/moon.jpg";
    W.SunAngularSize=G.Size;
    W.MoonAngularSize=0;
  else
    W.SunAngularSize=0;
    W.MoonAngularSize=0;
  end
end
