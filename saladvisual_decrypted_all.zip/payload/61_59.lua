-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #59
-- offset 126499..126894 (395 bytes, type=payload)

function(G)
  local c,m,O=G.parent,{["1"]=1.2,["2"]=1.8,["3"]=1.6,["4"]=1.9,["5"]=1.3},{};
  for B,A in pairs(m)do
    local m=c:FindFirstChild(B);
    if m then
      O[m]={A,m.CFrame};
    end
  end;
  if not next(O) then
    return;
  end
  local c,m=0;
  G.conn(J.RenderStepped:Connect(function(G)
    local m=c;
    c=m+3.141592653589793*G;
    for G,m in pairs(O)do
      local O,B,A,w=m[2],CFrame.Angles,c/1.0E19,c;
      G.CFrame=O*B(A,w/m[1],0);
    end;
  end));
end
