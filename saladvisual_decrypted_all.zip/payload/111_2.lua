-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[111] / function #2
-- offset 3078569..3079145 (576 bytes, type=payload)

function(s,L)
  local y=buffer.fromstring(s);
  local z,T,n,J,H,f=buffer.len(y),bit32.bxor,bit32.lshift,bit32.rshift,buffer.readu32,buffer.writeu32;
  local a,d,P,Z=z-4,4,L,os.clock();
  while d<=a do
    P=T(P,n(P,13));
    P=T(P,J(P,17));
    P=T(P,n(P,5));
    f(y,d,T(H(y,d),P));
    d+=4;
    s=d%262144==0 and os.clock()-Z>0.012;
    if s then
      task.wait();
      local s;
      L=l;
      if not L.current() then
        return nil;
      end
      Z=os.clock();
    else
    end
  end;
  P=T(P,n(P,13));
  P=T(P,J(P,17));
  P=T(P,n(P,5));
  for s=d,z-1,1 do
    buffer.writeu8(y,s,T(buffer.readu8(y,s),J(P,(s-d)*8)%256));
  end;
  buffer.writestring(y,0,"SVP1");
  return buffer.tostring(y);
end
