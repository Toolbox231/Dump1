-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #15
-- offset 3631832..3632226 (394 bytes, type=payload)

local function T(n,c)
  local S;
  local S=not z[4][z[6]]or not P or p~=w or not n;
  if S then
    return;
  end
  S=o[c];
  if S and S.container==n then
    return;
  end
  if S then
    S.add:Disconnect();
    S.remove:Disconnect();
  end
  local function S(A)
    local V=A.Name~="Gun"or not z[4][z[6]]or p~=w;
    if V then
      return;
    end
    A=m();
    y(true,A);
    Y(A);
  end
  o[c]={container=n,add=n.ChildAdded:Connect(S),remove=n.ChildRemoved:Connect(S)};
end
