-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #9
-- offset 3645731..3647141 (1410 bytes, type=payload)

local function w(F,h,W)
  local V=F.color;
  local _,X=h or 1,#F.particles;
  for x=_,X,1 do
    h=F.particles[x];
    x=h.emitter;
    local k=x.Parent;
    if k then
      local k=y;
      k.FxDepth(x,false);
      x.Color=N.Tint and ColorSequence.new(V)or h.color;
      x.Rate=h.rate*N.Rate;
      x.Brightness=h.bright*N.Glow*0.5;
      x.Size=B(h.size,N.Size);
      k=math.clamp(N.Speed,0.05,5);
      x.Speed=NumberRange.new(h.speed.Min*k,h.speed.Max*k);
      x.RotSpeed=NumberRange.new(h.rotation.Min*k,h.rotation.Max*k);
      x.Lifetime=NumberRange.new(math.max(0.05,h.life.Min/k),math.max(0.06,h.life.Max/k));
      x.LightEmission=math.clamp(h.emission+(N.Glow*0.5-1)*0.5,0,1);
    end
  end;
  _,X=W or 1,#F.accents;
  for B=_,X,1 do
    local _=F.accents[B];
    local B=_.item;
    h=B.Parent;
    if h then
      W=y;
      W.FxDepth(B,false);
      pcall(function()
        local F=N.Tint and V or nil;
        if B:IsA("PointLight")or B:IsA("SpotLight")or B:IsA("SurfaceLight") then
          B.Color=F or _.color;
          B.Brightness=_.brightness*N.Glow*0.5;
        elseif B:IsA("Beam")or B:IsA("Trail") then
          B.Color=F and ColorSequence.new(F)or _.color;
        elseif B:IsA("Fire") then
          B.Color,B.SecondaryColor=F or _.color,F or _.color2;
        elseif B:IsA("Smoke") then
          B.Color=F or _.color;
        elseif B:IsA("Sparkles") then
          B.SparkleColor=F or _.color;
        elseif B:IsA("Highlight") then
          B.FillColor,B.OutlineColor=F or _.color,F or _.color2;
        elseif B:IsA("Decal") then
          B.Color3=F or _.color;
        elseif B:IsA("BasePart") then
          B.Color=F or _.color;
          if _.texture then
            B.TextureID=F and""or _.texture;
          end
        end
      end);
    end
  end;
end
