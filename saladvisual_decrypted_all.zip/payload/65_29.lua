-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #29
-- offset 12823..14126 (1303 bytes, type=payload)

local function S(O)
  n(m);
  local B={player=m,character=O,conns={},humanConns={},lastJump=-1/0};
  l[m]=B;
  local function A(w)
    local F;
    local F=B.human and B.human.Parent or not z[4][z[6]]or l[m]~=B or m.Character~=O;
    if F then
      return;
    end
    for F,F in ipairs(B.humanConns)do
      F:Disconnect();
    end;
    table.clear(B.humanConns);
    B.human=w;
    B.air=w.FloorMaterial==Enum.Material.Air;
    B.floorAir=B.air;
    B.humanConns[#B.humanConns+1]=w.StateChanged:Connect(function(F,h)
      F=not z[4][z[6]]or l[m]~=B;
      if F then
        return;
      end
      if h==Enum.HumanoidStateType.Jumping then
        G(B);
      elseif h==Enum.HumanoidStateType.Freefall then
        B.air=true;
      elseif h==Enum.HumanoidStateType.Landed then
        j(B);
      end
    end);
    B.humanConns[#B.humanConns+1]=w.Jumping:Connect(function(w)
      local F=z[4][z[6]]and w and l[m]==B;
      if F then
        G(B);
      end
    end);
  end
  B.conns[#B.conns+1]=O.DescendantAdded:Connect(function(w)
    if w:IsA("Humanoid") then
      A(w);
    end
  end);
  B.conns[#B.conns+1]=O.ChildRemoved:Connect(function(w)
    if w==B.human then
      for w,w in ipairs(B.humanConns)do
        w:Disconnect();
      end;
      table.clear(B.humanConns);
      B.human=nil;
      local B=O:FindFirstChildOfClass("Humanoid");
      if B then
        A(B);
      end
    end
  end);
  task.spawn(function()
    local B,w=O:FindFirstChildOfClass("Humanoid")or O:WaitForChild("Humanoid",10);
    local w=B and z[4][z[6]]and O.Parent and m.Parent and m.Character==O;
    if w then
      A(B);
    end
  end);
end
