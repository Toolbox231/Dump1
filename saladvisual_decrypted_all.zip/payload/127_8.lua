-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #8
-- offset 201239..203309 (2070 bytes, type=payload)

local function G(O)
  local B;
  local B=not y[4][y[6]]or not d.On or not b or not b.Parent;
  if B then
    return;
  end
  local A;
  B=n;
  local A=B.camera();
  if not A then
    return;
  end
  O=math.clamp(O,0,0.1);
  B=A.CFrame.Position;
  local F=r and(B-r).Magnitude>d.Distance*2;
  if F then
    for h,h in ipairs(C)do
      z(h);
    end;
    p=0;
  end
  r=B;
  F=math.floor(a.Number(d.Count,20,1,Y));
  for h=1,math.min(3,F-#C),1 do
    C[#C+1]=L();
  end;
  d.Allocated=#C;
  local L=c;
  local h,W=L~=d.Head;
  if h then
    W=h;
  else
    L=m;
    W=L~=d.Tail;
  end
  if W then
    local V,_,X=d.Head,d.Tail,ColorSequence.new(d.Tail,d.Head);
    c,m,S=V,_,X;
  end
  p-=O;
  h=p<=0;
  if h then
    T(A);
    p=60/d.Rate*j:NextNumber(0.8,1.2);
  end
  A,h=ipairs,0;
  for T,j in A(C)do
    W=j.busy;
    if W then
      h+=1;
      L=h>F;
      if L then
        z(j);
        h-=1;
      else
        j.age=j.age+O;
        j.travel=j.travel+O*d.Speed/100;
        T=a.MeteorPoint(j.origin,j.velocity,j.travel);
        local L=a.Smooth((T.Y-B.Y-10)/40);
        local c=j.age>=j.life or L<=0;
        if c then
          z(j);
          h-=1;
        else
          local c,m=a.Envelope(j.age,j.life,0.1,0.32)*L,math.min(j.travel*j.velocity.Magnitude,(30+j.mass*22)*d.Length/100);
          local L=j.travel-m/j.velocity.Magnitude;
          m=a.MeteorPoint(j.origin,j.velocity,L);
          j.nose.WorldCFrame=a.Frame(T,j.velocity+Vector3.new(0,-3.6*j.travel,0));
          j.tail.WorldCFrame=a.Frame(m,j.velocity+Vector3.new(0,-3.6*L,0));
          local O,B,A,F=math.floor(math.clamp(c,0,1)*e+0.5),0.55*j.mass*d.Size/100,(T-m).Magnitude/3,j.colors~=S;
          if F then
            local T,e,F,W,V,_=j.line,j.haze,j.blob,S,S,d.Head;
            T.Color=W;
            e.Color=V;
            F.ImageColor3=_;
            j.star.ImageColor3=d.Head;
            j.colors=S;
          end
          if j.level~=O then
            j.line.Transparency,j.haze.Transparency=N[O],q[O];
            j.level=O;
          end
          j.line.Width1,j.haze.Width1=B,B*3.4;
          j.line.CurveSize0,j.line.CurveSize1=A,A;
          j.haze.CurveSize0,j.haze.CurveSize1=A,A;
          j.line.Enabled,j.haze.Enabled,j.card.Enabled=c>0.005,c>0.005,c>0.005;
          A=n;
          A.FxDepth(j.line,d.ThroughWalls);
          L=n;
          L.FxDepth(j.haze,d.ThroughWalls);
          j.card.AlwaysOnTop=d.ThroughWalls;
          m=d.HeadSize*(j.fire and 1.35 or 1);
          j.card.Size=UDim2.fromOffset(m,m);
          O,L=j.blob,d.Stars and 0.35 or(j.fire and 0.9 or 0.72);
          O.ImageTransparency=1-c*L;
          j.star.ImageTransparency=d.Stars and 1-c*0.95 or 1;
        end
      end
    else
    end
  end;
  d.Active=h;
end
