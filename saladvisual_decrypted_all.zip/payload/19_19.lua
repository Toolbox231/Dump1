-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #19
-- offset 3601322..3601539 (217 bytes, type=payload)

function(v)
  local I=h;
  if not I then
    return;
  end
  I=x and v==x or not x and v.UserInputType==Enum.UserInputType.MouseMovement;
  if I then
    local I=v.Position.X-(_ or v.Position.X);
    _=v.Position.X;
    local _=s;
    s=_-I*0.012;
  end
end
