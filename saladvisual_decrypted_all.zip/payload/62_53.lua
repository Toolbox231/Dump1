-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #53
-- offset 3237144..3237365 (221 bytes, type=payload)

local function P()
  r+=1;
  H();
  if not(b.On and b.Pick) then
    return;
  end
  local m=r;
  task.spawn(function()
    local S,_=pcall(h,m);
    if not S then
      warn("[visuals] model: "..tostring(_));
    end
    S=m==r and not b.On;
    if S then
      H();
    end
  end);
end
