-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #3
-- offset 3204907..3205281 (374 bytes, type=payload)

local function G(Y,e,j)
  local C;
  local function N(q)
    local b,D=Instance.new(Y),l;
    b.Name=D.RandomString();
    b.Enabled=false;
    for Y,D in pairs(e)do
      b[Y]=D;
    end;
    if q then
      for Y in pairs(e)do
        pcall(function()
          b[Y]=q[Y];
        end);
      end;
      pcall(function()
        b.Enabled=q.Enabled;
      end);
    end
    b.Parent=s;
    return b;
  end
  C=N(nil);
  Z[#Z+1]=function()
    local Y=C.Parent~=s;
    if Y then
      C=N(C);
      j(C);
    end
  end;
  return C;
end
