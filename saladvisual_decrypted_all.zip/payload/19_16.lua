-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #16
-- offset 3600510..3600819 (309 bytes, type=payload)

local function k()
  local v=T.AbsoluteSize;
  if v.X<2 or v.Y<2 then
    return;
  end
  local I,i=math.tan(math.rad(S.FieldOfView)/2),v.X/v.Y;
  local v,E=(math.max(F.Y/2/I,math.max(F.X,F.Z)/2/(I*i))*1.25+F.Z/2)*m,w;
  I=E+Vector3.new(0,F.Y*0.02,0);
  S.CFrame=CFrame.lookAt(I+Vector3.new(math.sin(s),0.1,math.cos(s)).Unit*v,I);
end
