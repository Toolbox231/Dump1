-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #10
-- offset 3598157..3600350 (2193 bytes, type=payload)

function()
  task.wait(x and 0.25 or 0);
  while true do
    local x;
    local x=J[4][J[6]];
    if not x then
      break;
    end
    x=not q.Visible;
    if x then
      local k=n;
      k.NeedsRefresh=true;
      break;
    end
    local k,v=_,z;
    local I=v.Character;
    if not(I and I.Parent) then
      break;
    end
    x=I.Archivable;
    I.Archivable=true;
    local i,E=pcall(function()
      return I:Clone();
    end);
    I.Archivable=x;
    v=not(i and E);
    if v then
      x=_;
      if k==x then
        break;
      end
      continue;
    end
    x,i=ipairs,s[70](E:GetDescendants());
    for Q,t in x(s:ZT(i))do
      pcall(function()
        local s=false;
        for R in pairs(h)do
          if t:IsA(R) then
            s=true;
            break;
          end
        end;
        if s then
          t:Destroy();
        elseif t:IsA("BasePart") then
          t.Anchored=true;
          t.CanCollide=false;
          t.CanQuery=false;
          t.CanTouch=false;
          t.LocalTransparencyModifier=0;
        end
      end);
      if Q%48==0 then
        task.wait();
      end
      v=not J[4][J[6]]or k~=_ or not q.Visible;
      if v then
        break;
      end
    end;
    i=J[4][J[6]];
    if not i then
      E:Destroy();
      break;
    end
    i=not q.Visible;
    if i then
      E:Destroy();
      x=n;
      x.NeedsRefresh=true;
      break;
    end
    x,v=k~=_;
    if x then
      v=x;
    else
      i=z;
      v=i.Character~=I;
    end
    if v then
      E:Destroy();
      continue;
    end
    local s=E:FindFirstChildOfClass("Humanoid");
    if s then
      s.DisplayDistanceType=Enum.HumanoidDisplayDistanceType.None;
      pcall(function()
        s.HealthDisplayType=Enum.HumanoidHealthDisplayType.AlwaysOff;
      end);
    end
    i=E:FindFirstChild("HumanoidRootPart")or E:FindFirstChild("UpperTorso")or E:FindFirstChild("Torso");
    x=not i;
    if x then
      E:Destroy();
      v=_;
      if k==v then
        break;
      end
      continue;
    end
    E.PrimaryPart=i;
    E:PivotTo(CFrame.Angles(0,3.141592653589793,0));
    local s,h,Q,t,R,g=1/0,1/0,1/0,-1/0,-1/0,-1/0;
    for u,U in ipairs(E:GetChildren())do
      if U:IsA("BasePart")and B[U.Name] then
        v,i=U.Size/2,{-1,1};
        for M,sP in ipairs(i)do
          u={-1,1};
          for lP,LP in ipairs(u)do
            lP={-1,1};
            for u,u in ipairs(lP)do
              M=U.CFrame*Vector3.new(v.X*sP,v.Y*LP,v.Z*u);
              s,h,Q,t,R=math.min(s,M.X),math.min(h,M.Y),math.min(Q,M.Z),math.max(t,M.X),math.max(R,M.Y);
              g=math.max(g,M.Z);
            end;
          end;
        end;
      else
      end
    end;
    i,x=k~=_;
    if i then
      x=i;
    else
      v=z;
      x=v.Character~=I;
    end
    if x then
      E:Destroy();
      continue;
    end
    W();
    E.Parent=m;
    A=E;
    v=t>s;
    if v then
      i,x=Vector3.new((s+t)/2,(h+R)/2,(Q+g)/2),Vector3.new(t-s,R-h,g-Q);
      w,F=i,x;
    else
      local s,m=E:GetBoundingBox();
      w,F=s.Position,m;
    end
    E=n;
    x=E.Paint;
    if x then
      pcall(n.Paint);
    end
    E=_;
    if k==E then
      break;
    end
  end;
  V=false;
end
