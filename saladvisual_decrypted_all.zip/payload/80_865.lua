-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #865
-- offset 3564261..3565589 (1328 bytes, type=payload)

local function d(P,Z)
  P=s[87]();
  Z=Z or{};
  local G,Y=C[l[557]][l[1577]],P[l[1089]][l[772]](l[211]);
  Y[l[1150]]=T[l[1416]]();
  Y[l[1646]]=l[229];
  Y[l[1639]]=P[l[1459]][l[772]](l[229],l[393],l[393],l[658]);
  Y[l[382]]=G;
  local G=P[l[1089]][l[772]](l[1400]--[[-1]]);
  G[l[1150]]=l[766];
  G[l[1535]]=J[l[131]][l[1466]];
  G[l[1418]]=l[393];
  G[l[948]]=P[l[1459]][l[772]](l[393],l[786],l[393],l[863]);
  G[l[1639]]=P[l[1459]][l[772]](l[229],l[1519],l[393],l[1707]);
  G[l[437]]=P[l[128]][l[437]][l[807]];
  G[l[723]]=l[310];
  G[l[510]]=J[l[131]][l[1095]];
  G[l[32]]=Z[l[940]]or N;
  G[l[592]]=J[l[131]][l[1379]];
  G[l[1420]]=Z[l[1380]]or l[1746];
  G[l[1155]]=l[1329];
  G[l[382]]=Y;
  P[l[1089]][l[772]](l[1112],G)[l[1182]]=P[l[740]][l[772]](l[393],l[303]);
  local Y={[l[477]]=G};
  local N=l[1329];
  local function b(D)
    return G[l[1420]];
  end
  Y[l[582]]=b;
  local function b(D,r)
    D=s[87]();
    N=l[383];
    G[l[1420]]=D[l[1130]](r or l[1746]);
    N=l[1329];
    if Z[l[1683]]and not(J[l[1207]]and J[l[1207]][Z[l[1315]]]) then
      Z[l[1683]](G[l[1420]]);
    end
  end
  Y[l[1629]]=b;
  T:AddSignal(G:GetPropertyChangedSignal(l[1420]):Connect(function()
    local b=N or not Z[l[1683]];
    if b then
      return;
    end
    Z[l[1683]](G[l[1420]]);
  end));
  if P[l[40]](Z[l[1315]])==l[409]and Z[l[1315]]~=l[1746] then
    P[l[1146]](function()
      J:hook(Z[l[1315]],l[409],function()
        return G[l[1420]];
      end,function(P)
        Y:SetValue(P);
      end);
    end);
  end
  return a(Z[l[1315]],Y);
end
