-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #120
-- offset 138647..138847 (200 bytes, type=payload)

function()
  while true do
    local T;
    local T=y[4][y[6]];
    if not T then
      break;
    end
    task.wait(1);
    for T,T in pairs(l)do
      pcall(K,T);
    end;
    for T,T in pairs(f)do
      for n,n in pairs(T.worn)do
        pcall(K,n);
      end;
    end;
  end;
end
