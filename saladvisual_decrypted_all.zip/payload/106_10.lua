-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[106] / function #10
-- offset 3638270..3638628 (358 bytes, type=payload)

local function L(z,T)
  local C=a[z];
  if C and C.character==T then
    return C;
  end
  G(z);
  C={character=T,history={},connections={},dirty=false,rebuildAt=0};
  local function N(q)
    if q:IsA("Accessory")or q:IsA("Hat") then
      C.dirty=true;
      C.rebuildAt=os.clock()+0.1;
    end
  end
  C.connections[1]=T.ChildAdded:Connect(N);
  C.connections[2]=T.ChildRemoved:Connect(N);
  a[z]=C;
  return C;
end
