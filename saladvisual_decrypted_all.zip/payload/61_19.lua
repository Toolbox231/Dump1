-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #19
-- offset 113458..113918 (460 bytes, type=payload)

local function e(j,C)
  C=Z[C]or C;
  local Z=j:FindFirstChild(C);
  if Z and(Z:IsA("BasePart")) then
    return Z,CFrame.new();
  end
  if C=="HumanoidRootPart" then
    return e(j,"Torso");
  end
  Z=G[C];
  local G=Z and(j:FindFirstChild(Z));
  if not(G and(G:IsA("BasePart"))) then
    return nil;
  end
  if C=="Torso" then
    Z=j:FindFirstChild("HumanoidRootPart");
    return G,CFrame.new(Z and G.CFrame:PointToObjectSpace(Z.Position)or Vector3.new(0.0,0.0,0.0));
  end
  return G,CFrame.new(0,-G.Size.Y/2,0);
end
