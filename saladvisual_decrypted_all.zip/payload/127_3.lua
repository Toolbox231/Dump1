-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #3
-- offset 198790..199427 (637 bytes, type=payload)

local function w(F)
  local h=b and b.Parent;
  if h then
    return true;
  end
  local W;
  h=L;
  local W,V=h.asset("trail/bloom.png")or"",L;
  local _,X=V.asset("particles/p_glow.png")or"rbxasset://textures/particles/sparkles_main.dds",L;
  local L,x=X.asset("particles/star_user.png")or _;
  X=not y[4][y[6]]or not d.On or F~=K;
  if X then
    return false;
  end
  O,B,A=W,_,L;
  b=Instance.new("Part");
  b.Name="VisualsStarfall";
  W,V,X=b,b,b;
  b.Anchored=true;
  W.CanCollide=false;
  V.CanTouch=false;
  X.CanQuery=false;
  F,_,h,V=b,b,b,Vector3.new(1.0,1.0,1.0);
  F.Transparency=1;
  _.CastShadow=false;
  h.Size=V;
  local L;
  local L,h=z;
  F=T;
  b:SetAttribute(L,F);
  _=b;
  _.Parent=workspace;
  return true;
end
