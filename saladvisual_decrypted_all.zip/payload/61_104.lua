-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #104
-- offset 135842..136331 (489 bytes, type=payload)

local function e(r)
  local o,c=d.ById[r],O;
  local S=J[r];
  if not(o and c and S)or l[r]or m[r] then
    return;
  end
  local A={};
  m[r]=A;
  f();
  task.spawn(function()
    local w,F=pcall(function()
      local h=Y(o.g);
      local o,W=h and h[r];
      h=o and y[4][y[6]]and m[r]==A and J[r]==S and O==c;
      if h then
        p(r,o,c,S,nil,nil,function()
          local o=m[r]==A and O==c and J[r]==S and not l[r];
          return o;
        end);
      end
    end);
    local o=not w;
    if o then
      local o;
      w=T;
      w("game fx "..r..": "..tostring(F));
    end
    if m[r]==A then
      m[r]=nil;
      f();
    end
  end);
end
