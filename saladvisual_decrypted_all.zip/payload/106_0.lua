-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[106] / function #0
-- offset 3635889..3640559 (4670 bytes, type=payload)

function(s,s,s,s)
  return function(s,s)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    return function()
      local s;
      local s=l;
      local f,a,d,P,Z=s.Backtrack,{},0,0.03333333333333333,{};
      local function G(Y)
        local e=a[Y];
        if not e then
          return;
        end
        for j,j in ipairs(e.connections or{})do
          j:Disconnect();
        end;
        if e.model then
          e.model:Destroy();
        end
        a[Y]=nil;
      end
      local function Y()
        while next(a)do
          G(next(a));
        end;
      end
      local function e(j)
        local C,N=f.On;
        if C then
          local q,b,D=f.Target=="All";
          if q then
            b=q;
          else
            local D=f.Target=="Self";
            if D then
              local p=L;
              b=j==p;
            else
              b=D;
            end
          end
          if b then
            N=b;
          else
            q=f.Target=="Other";
            if q then
              local b=L;
              N=j~=b;
            else
              N=q;
            end
          end
        else
          N=C;
        end
        return N;
      end
      local function L(j,C,N)
        if j:IsA("BasePart")and C:IsA("BasePart")and j.Name~="HumanoidRootPart"and j.Transparency<1 then
          N[#N+1]={source=j,clone=C,baseTransparency=j.Transparency};
        end
        local q={};
        for b,D in ipairs(j:GetChildren())do
          b=D.ClassName.."\0"..D.Name;
          q[b]=(q[b]or 0)+1;
          local j=q[b];
          for q,q in ipairs(C:GetChildren())do
            if q.ClassName==D.ClassName and q.Name==D.Name then
              j-=1;
              if j==0 then
                L(D,q,N);
                break;
              end
            else
            end
          end;
        end;
      end
      local j;
      local function j(C)
        local N=os.clock();
        if C.model and C.model.Parent then
          if not C.dirty or N<C.rebuildAt then
            return true;
          end
          C.model:Destroy();
          C.model=nil;
          C.links=nil;
          C.highlight=nil;
        elseif N<C.rebuildAt then
          return false;
        end
        local q=C.character;
        local b=q.Archivable;
        pcall(function()
          q.Archivable=true;
        end);
        local D,p=pcall(q.Clone,q);
        pcall(function()
          q.Archivable=b;
        end);
        if not D or not p then
          C.rebuildAt=N+0.5;
          return false;
        end
        for b,b in ipairs(p:GetDescendants())do
          if b:IsA("BasePart") then
            b.Anchored=true;
            b.CanCollide=false;
            b.CanTouch=false;
            b.CanQuery=false;
            b.CastShadow=false;
            b.Transparency=1;
          elseif b:IsA("Humanoid")or b:IsA("BaseScript")or b:IsA("Sound")or b:IsA("ValueBase")or b:IsA("Decal")or b:IsA("Texture")or b:IsA("ParticleEmitter")or b:IsA("Trail")or b:IsA("Beam")or b:IsA("Light")or b:IsA("Highlight")or b:IsA("BillboardGui")or b:IsA("SurfaceGui") then
            b:Destroy();
          end
        end;
        D={};
        L(q,p,D);
        N=Instance.new("Highlight");
        N.Name="BacktrackPlayerChams";
        N.Adornee=p;
        N.DepthMode=Enum.HighlightDepthMode.Occluded;
        N.Parent=p;
        local L=y;
        p.Name=L.RandomString();
        local q;
        local q,b=z;
        L=T;
        p:SetAttribute(q,L);
        p.Parent=workspace;
        C.model=p;
        C.links=D;
        C.highlight=N;
        C.history={};
        C.dirty=false;
        C.rebuildAt=0;
        return true;
      end
      local function L(z,T)
        local C=a[z];
        if C and C.character==T then
          return C;
        end
        G(z);
        C={character=T,history={},connections={},dirty=false,rebuildAt=0};
        local function N(q)
          if q:IsA("Accessory")or q:IsA("Hat") then
            C.dirty=true;
            C.rebuildAt=os.clock()+0.1;
          end
        end
        C.connections[1]=T.ChildAdded:Connect(N);
        C.connections[2]=T.ChildRemoved:Connect(N);
        a[z]=C;
        return C;
      end
      local function z(T,C,N)
        local q={};
        for b,D in ipairs(T.links or{})do
          if D.source.Parent then
            q[b]=D.source.CFrame;
          end
        end;
        T.history[#T.history+1]={t=N,root=C.CFrame,pose=q};
        q=math.max(1.05,f.Delay/1000+0.2);
        while#T.history>2 and T.history[2].t<N-q do
          table.remove(T.history,1);
        end;
      end
      local function T(C,N)
        if #C==0 then
          return nil;
        end
        local q,b=C[1],C[1];
        for D=2,#C,1 do
          local p=C[D];
          if p.t>=N then
            q,b=C[D-1],p;
            break;
          end
          q,b=p,p;
        end;
        return q,b,q==b and 0 or math.clamp((N-q.t)/math.max(b.t-q.t,1.0E-5),0,1);
      end
      local function C(N,q,b,D)
        local p=l;
        local r,K=p.MaterialStyles[f.ChamsMaterial];
        if r then
          K=r;
        else
          p=l;
          K=p.MaterialStyles.ForceField;
        end
        r,p=math.clamp(f.Transparency/100,0,1),math.clamp(K.transparency or 0,0,1);
        for o,c in ipairs(N.links)do
          local m=q.pose[o];
          local q=b.pose[o]or m;
          if m and c.clone.Parent then
            c.clone.CFrame=m:Lerp(q,D);
            c.clone.Material=K.material or Enum.Material.ForceField;
            c.clone.Reflectance=K.reflectance or 0;
            c.clone.Color=f.Color;
            c.clone.Transparency=1-(1-c.baseTransparency)*(1-r)*(1-p);
          end
        end;
        b=N.highlight;
        if b then
          b.Enabled=true;
          b.FillColor=f.Color;
          b.FillTransparency=r;
          b.OutlineColor=f.ChamsOutline;
          b.OutlineTransparency=f.OutlineOn and math.clamp(f.ChamsOutlineTransparency/100,0,1)or 1;
        end
      end
      local N,q=y;
      s=n;
      N:AddSignal(s.PlayerRemoving:Connect(G));
      local N,q=y;
      s=J;
      N:AddSignal(s.RenderStepped:Connect(function(s)
        local y;
        local y=H[4][H[6]];
        if not y then
          return;
        end
        y=not f.On;
        if y then
          d=0;
          if next(a) then
            Y();
          end
          return;
        end
        d+=s;
        s=d>=P;
        if s then
          d%=P;
        end
        y=os.clock();
        table.clear(Z);
        local J=n;
        for n,H in ipairs(J:GetPlayers())do
          Z[H]=true;
          n=H.Character;
          local J=n and(n:FindFirstChild("HumanoidRootPart"));
          if e(H)and n and J then
            local d=L(H,n);
            if j(d) then
              if s or#d.history==0 then
                z(d,J,y);
              end
              local s,L,z=T(d.history,y-f.Delay/1000);
              if s then
                C(d,s,L,z);
              end
            end
          elseif a[H] then
            G(H);
          end
        end;
        for s in pairs(a)do
          if not Z[s] then
            G(s);
          end
        end;
      end));
      N=l;
      N.ClearBacktrackChams=Y;
    end;
  end;
end
