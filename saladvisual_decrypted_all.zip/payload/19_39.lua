-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #39
-- offset 3607464..3607686 (222 bytes, type=payload)

local function K()
  local S=e();
  local e=S and S~=r;
  if e then
    r=S;
    local e=L;
    e:AddSignal(S:GetPropertyChangedSignal("AbsolutePosition"):Connect(v));
    e=L;
    e:AddSignal(S:GetPropertyChangedSignal("AbsoluteSize"):Connect(v));
  end
end
