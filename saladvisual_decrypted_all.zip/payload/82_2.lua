-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[82] / function #2
-- offset 26245..33076 (6831 bytes, type=payload)

function()
  local l,a="rbxasset://textures/particles/smoke_main.dds",ipairs;
  local d=s[70](workspace:GetChildren());
  local P,P;
  for P,Z in a(s:ZT(d))do
    P=L;
    local s=Z:GetAttribute(P);
    P=nil;
    if s then
      local G=y;
      P=s~=G;
    else
      P=s;
    end
    if P and(Z:FindFirstChildWhichIsA("ParticleEmitter")) then
      Z:Destroy();
    end
  end;
  local s={Snow={texture="particles/p_glow.png",color=Color3.fromRGB(226,240,255),lifetime=NumberRange.new(4,6),speed=NumberRange.new(6,12),acceleration=Vector3.new(2,-6,1),spread=Vector2.new(35,35),spin=NumberRange.new(-40,40),size=0.32,squash=0,emission=0.15,density=2.2,transparency={0.1,0.2},fade=0.8},["Snow Soft"]={color=Color3.fromRGB(150,200,255),lifetime=NumberRange.new(4,6),speed=NumberRange.new(6,12),acceleration=Vector3.new(2,-6,1),spread=Vector2.new(35,35),spin=NumberRange.new(-40,40),size=0.55,squash=0,emission=0.4,transparency={0.2,0.3},fade=0.8},Sakura={color=Color3.fromRGB(255,170,210),lifetime=NumberRange.new(5,7),speed=NumberRange.new(5,10),acceleration=Vector3.new(4,-5,2),spread=Vector2.new(40,40),spin=NumberRange.new(-80,80),size=0.5,squash=1.4,emission=0.4,transparency={0.15,0.25},fade=0.85},Rain={color=Color3.fromRGB(170,200,255),lifetime=NumberRange.new(1.1,1.6),speed=NumberRange.new(70,95),acceleration=Vector3.new(0,-40,0),spread=Vector2.new(1,1),spin=NumberRange.new(0,0),size=0.5,squash=6,emission=0.35,density=4.5,transparency={0.35,0.45},fade=0.9,orientation=Enum.ParticleOrientation.FacingCameraWorldUp,rotation=NumberRange.new(0,0)},Ash={color=Color3.fromRGB(90,90,95),lifetime=NumberRange.new(6,9),speed=NumberRange.new(3,7),acceleration=Vector3.new(3,-3,2),spread=Vector2.new(45,45),spin=NumberRange.new(-25,25),size=0.32,squash=0,emission=0.1,transparency={0.25,0.4},fade=0.85},Fireflies={color=Color3.fromRGB(255,220,120),lifetime=NumberRange.new(3,5),speed=NumberRange.new(1,3),acceleration=Vector3.new(0,0.5,0),spread=Vector2.new(180,180),spin=NumberRange.new(-10,10),size=0.22,squash=0,emission=1,transparency={0.1,0.1},fade=0.75}};
  local P,Z,G,Y,e,j={Kind="Off",Rate=250,Speed=100,Size=100,Fade=100,Distance=120,Height=90,Color=s.Snow.color,ThroughWalls=false};
  local function C()
    local N,q=s[P.Kind],(P.Distance/120)^2;
    return math.min(P.Rate*q*(N and N.density or 1),4000);
  end
  local N=P.Color;
  local q=P.Color;
  local function b(D)
    q=D;
  end
  local function D()
    local p=G;
    if not p then
      return;
    end
    local r,K,o=N.R-q.R,N.G-q.G,N.B-q.B;
    p=r*r+K*K+o*o<2.0E-5;
    if p then
      o=N~=q;
      if o then
        N=q;
        K=G;
        K.Color=ColorSequence.new(N);
      end
      return;
    end
    N=N:Lerp(q,0.09);
    p=G;
    p.Color=ColorSequence.new(N);
  end
  local function q()
    local p=s[P.Kind];
    local r=G and p;
    if not r then
      return;
    end
    local K,o=P.Speed/100,p.texture;
    r=o and not o:find("://",1,true);
    if r then
      local c;
      local c=z;
      o=c.asset(o);
    else
    end
    G.Texture=o or l;
    G.LightInfluence=0;
    r=G;
    r.LightEmission=p.emission;
    local l;
    r=T;
    r.FxDepth(G,P.ThroughWalls);
    G.Drag=0;
    r=G;
    r.EmissionDirection=Enum.NormalId.Bottom;
    r=G;
    r.Rate=C();
    r=G;
    r.Color=ColorSequence.new(N);
    r=G;
    r.Rotation=p.rotation or NumberRange.new(0,360);
    r=G;
    r.RotSpeed=p.spin;
    r=G;
    r.SpreadAngle=p.spread;
    pcall(function()
      local l=G;
      l.Orientation=p.orientation or Enum.ParticleOrientation.FacingCamera;
    end);
    r=G;
    r.Speed=NumberRange.new(p.speed.Min*K,p.speed.Max*K);
    r=G;
    r.Acceleration=(p.acceleration+(p.lean or Vector3.new(0.0,0.0,0.0)))*K;
    r=G;
    r.Lifetime=NumberRange.new(p.lifetime.Min/K,p.lifetime.Max/K);
    K=G;
    K.Size=NumberSequence.new(p.size*(P.Size/100));
    pcall(function()
      local l=G;
      l.Squash=NumberSequence.new(p.squash);
    end);
    r=P.Fade/100;
    local l,z,T=math.clamp(1-(1-p.transparency[1])/r,0,1),math.clamp(1-(1-p.transparency[2])/r,0,1),G;
    T.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,l),NumberSequenceKeypoint.new(p.fade,z),NumberSequenceKeypoint.new(1,1)});
  end
  local function l()
    local z=Z;
    if not z then
      return;
    end
    z=Z;
    z.Size=Vector3.new(P.Distance,P.Height,P.Distance);
    z=G;
    if z then
      local z=G;
      z.Rate=C();
    end
    e,j=nil,nil;
  end
  local function z()
    local T=Y;
    if T then
      pcall(function()
        Y:Disconnect();
      end);
      Y=nil;
    end
    T=Z;
    if T then
      pcall(function()
        Z:Destroy();
      end);
      Z=nil;
    end
    G,e,j=nil,nil,nil;
  end
  local function T()
    local N=Z and Z.Parent;
    if N then
      return;
    end
    Z=Instance.new("Part");
    local p;
    local p,r=Z,n;
    p.Name=n.RandomString();
    Z.Anchored=true;
    Z.CanCollide=false;
    Z.CanQuery=false;
    Z.CanTouch=false;
    Z.CastShadow=false;
    Z.Transparency=1;
    p=Z;
    p.Size=Vector3.new(P.Distance,P.Height,P.Distance);
    N,p=L,y;
    Z:SetAttribute(N,p);
    N=Z;
    N.Parent=workspace;
    G=Instance.new("ParticleEmitter");
    pcall(function()
      local L=G;
      L.Shape=Enum.ParticleEmitterShape.Box;
      L=G;
      L.ShapeStyle=Enum.ParticleEmitterShapeStyle.Volume;
    end);
    G.Parent=Z;
    q();
  end
  local function L()
    local y=G;
    if not y then
      return;
    end
    y=G;
    y:Emit(math.clamp(math.floor(C()*0.2),30,600));
  end
  local function y()
    T();
    local T=Y;
    if T then
      return;
    end
    e,j=nil,nil;
    local N;
    local N,p=n;
    T=J;
    Y=N:AddSignal(T.RenderStepped:Connect(function()
      local T=Z and Z.Parent;
      if not T then
        return;
      end
      D();
      T=workspace.CurrentCamera;
      if not T then
        return;
      end
      local n=T.CFrame;
      local J,Y=n.Position,n.LookVector;
      n=Vector3.new(Y.X,0,Y.Z);
      n=if n.Magnitude<0.05 then Vector3.new(0,0,-1)else n.Unit;
      T=e and j and(J-e).Magnitude<10 and n:Dot(j)>0.95;
      if T then
        return;
      end
      e,j=J,n;
      Y=Z;
      Y.CFrame=CFrame.new(J+n*(P.Distance*0.22)+Vector3.new(0,P.Height*0.5-26,0));
    end));
    L();
  end
  local T;
  d=H;
  d.Weather=P;
  a=H;
  a.ClearWeather=z;
  local T;
  d=f;
  d.Weather:AddLabel("Type"):AddDropdown({Default="Off",Values={"Off","Snow","Snow Soft","Sakura","Rain","Ash","Fireflies"},Flag="weather_kind",Callback=function(T)
    P.Kind=T;
    if T=="Off" then
      z();
      return;
    end
    P.Color=s[T].color;
    b(P.Custom and P.Pick or P.Color);
    y();
    q();
    L();
  end});
  a=f;
  local s,y=a.Weather:AddLabel("Amount"),{Min=20,Max=800,Default=250,Rounding=0,Size=100,Flag="weather_rate"};
  y.Callback=function(z)
    P.Rate=z;
    z=G;
    if z then
      local z=G;
      z.Rate=C();
    end
  end;
  s:AddSlider(y);
  a=f;
  a.Weather:AddLabel("Fall Speed"):AddSlider({Min=10,Max=400,Default=100,Type="%",Size=100,Flag="weather_speed",Callback=function(y)
    P.Speed=y;
    q();
  end});
  a=f;
  a.Weather:AddLabel("Particle Size"):AddSlider({Min=10,Max=500,Default=100,Type="%",Size=100,Flag="weather_size",Callback=function(y)
    P.Size=y;
    q();
  end});
  s=f;
  s.Weather:AddLabel("Transparency"):AddSlider({Min=20,Max=400,Default=100,Type="%",Size=100,Flag="weather_fade",Callback=function(y)
    P.Fade=y;
    q();
  end});
  d=f;
  d.Weather:AddLabel("Distance"):AddSlider({Min=60,Max=600,Default=120,Rounding=0,Size=100,Flag="weather_distance",Callback=function(y)
    P.Distance=y;
    l();
  end});
  d=f;
  d.Weather:AddLabel("Height"):AddSlider({Min=40,Max=400,Default=90,Rounding=0,Size=100,Flag="weather_height",Callback=function(y)
    P.Height=y;
    l();
  end});
  a=f;
  s=a.Weather:AddLabel("Custom Color");
  s:AddToggle({Default=false,Flag="weather_custom",Callback=function(l)
    P.Custom=l;
    b(l and P.Pick or P.Color);
  end});
  s:AddColorPicker({Default=P.Color,Flag="weather_color",Callback=function(s)
    P.Pick=s;
    if P.Custom then
      b(s);
    end
  end});
  d=f;
  d.Weather:AddButton({Name="Burst",Callback=L});
end
