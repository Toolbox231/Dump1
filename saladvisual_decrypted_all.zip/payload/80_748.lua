-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #748
-- offset 3530042..3544303 (14261 bytes, type=payload)

local function T(n,J)
  local G={};
  n=s[87]();
  J=n[l[40]](J)==l[1346]and J or{};
  local Y,j=n[l[40]](J[l[1577]])==l[1346]and J[l[1577]]or{},{};
  for C,C in y[5](n[l[40]](J[l[61]])==l[1346]and J[l[61]]or{})do
    if n[l[40]](C)==l[1346]and#j<l[930] then
      j[#j+l[229]]=C;
    end
  end;
  if #j==l[393]and n[l[40]](J[l[1223]])==l[1346] then
    j[l[229]]=J[l[1223]];
  end
  local C={};
  local function p(r,o)
    local B=r:Connect(o);
    C[#C+l[229]]=B;
    return B;
  end
  y[18]:closepopup();
  if #Y==l[393]and#j==l[393]or not y[18][l[630]] then
    return;
  end
  local r=x[l[160]];
  local o=r/y[29];
  local B,A,w=n[l[35]][l[819]](n[l[35]][l[499]](n[l[1382]](J[l[597]])or l[450]),l[827],n[l[35]][l[850]](n[l[35]][l[499]](o[l[1437]])-l[1655],l[827])),l[913],#Y*l[941]+l[558]+#j*l[1506];
  local F,h=n[l[35]][l[819]](A+w,l[1167],n[l[35]][l[850]](n[l[35]][l[499]](o[l[636]])-l[1655],l[1167])),y[9]:GetMouseLocation();
  o,A=n[l[35]][l[499]](n[l[1382]](J[l[898]])or h[l[1437]]),n[l[35]][l[499]](n[l[1382]](J[l[504]])or h[l[636]]);
  local V=n[l[35]][l[819]](o,l[930],n[l[35]][l[850]](r[l[1437]]-B*y[29]-l[930],l[930]));
  local _=n[l[35]][l[819]](A,l[930],n[l[35]][l[850]](r[l[636]]-F*y[29]-l[930],l[930]));
  local r=nP and a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](V,_),[l[1639]]=n[l[1459]][l[588]](B,F),[l[1535]]=c[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1649]},x)or nil;
  local k=r and a(l[1198],{[l[1630]]=c[l[641]],[l[258]]=n[l[740]][l[772]](l[393],l[558]),[l[1485]]=n[l[1459]][l[588]](l[393],l[786]),[l[1326]]=n[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},r)or nil;
  if r then
    D(r,l[1092]);
    Z(r);
  end
  local i=a(l[1751],{[l[1150]]=J[l[572]]or f(),[l[948]]=n[l[1459]][l[588]](V,_),[l[1639]]=n[l[1459]][l[588]](B,F),[l[1535]]=c[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[711]]=l[1651]},x);
  D(i,l[1092]);
  Z(i);
  F,B=l[1622],{[l[500]]=l[117]};
  B[l[1630]]=n[l[1262]][l[772]]({n[l[527]][l[772]](l[393],n[l[360]][l[772]](l[229],l[229],l[229])),n[l[527]][l[772]](l[229],n[l[360]][l[353]](l[291],l[291],l[920]))});
  a(F,B,i);
  o=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[487]},i);
  D(o,l[1092]);
  a(l[734],{[l[1630]]=c[l[966]],[l[747]]=l[1419]},o);
  h=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[917]},i);
  A=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[917]},h);
  D(A,l[1092]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[393],l[229]),[l[948]]=n[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[917]},A);
  local Z=a;
  local E=l[859];
  local Q={};
  Q[l[1150]]=f();
  Q[l[1016]]=n[l[1689]][l[772]](l[393],l[659]);
  Q[l[948]]=n[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
  Q[l[1639]]=n[l[1459]][l[588]](l[310],l[310]);
  Q[l[1646]]=l[229];
  Q[l[1451]]=y[30](J[l[13]]or l[1456]);
  Q[l[936]]=c[l[1379]];
  Q[l[2]]=l[1431];
  Q[l[1557]]=n[l[128]][l[1557]][l[220]];
  Q[l[711]]=l[1237];
  Z(E,Q,A);
  a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[688],l[393]),[l[1639]]=n[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](J[l[1434]]or l[1746]),[l[510]]=c[l[1095]],[l[723]]=l[750],[l[164]]=n[l[128]][l[164]][l[1021]],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1237]},A);
  K(a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=c[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1237]},h),l[393],{n[l[677]][l[772]](l[393],l[229]),n[l[677]][l[772]](l[841],l[874]),n[l[677]][l[772]](l[659],l[393]),n[l[677]][l[772]](l[804],l[874]),n[l[677]][l[772]](l[229],l[229])});
  local Z=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=n[l[1459]][l[588]](l[393],l[913]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=n[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=n[l[128]][l[62]][l[636]],[l[711]]=l[917]},h);
  local E=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=n[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[917]},Z);
  A,o=l[755],{[l[407]]=n[l[128]][l[407]][l[537]]};
  o[l[536]]=n[l[740]][l[772]](l[393],l[229]);
  a(A,o,E);
  a(l[1359],{[l[299]]=n[l[740]][l[772]](l[393],l[303]),[l[645]]=n[l[740]][l[772]](l[393],l[930]),[l[1612]]=n[l[740]][l[772]](l[393],l[303]),[l[517]]=n[l[740]][l[772]](l[393],l[303])},E);
  local A={[l[630]]=l[383],[l[1594]--[[__index]]]=i,[l[89]]={},[l[61]]={}};
  local function Q(t)
    local R=i[l[1569]];
    b(i,l[304],q,function(g)
      local u,sP=s[87](),R+(l[229]-R)*g;
      i[l[1569]]=sP;
      i[l[948]]=u[l[1459]][l[588]](V,_+u[l[35]][l[499]](l[1092]*g+l[659]));
      if r then
        r[l[1646]]=sP;
        r[l[948]]=i[l[948]];
        k[l[747]]=l[330]+l[1419]*sP;
      end
      if g>=l[229] then
        i[l[1324]]=l[1329];
        if r then
          r[l[1324]]=l[1329];
        end
        if t then
          t();
        end
      end
    end);
  end
  local function t()
    local R=s[87]();
    if not A[l[630]] then
      return;
    end
    A[l[630]]=l[1329];
    for g,g in y[5](A[l[89]])do
      g();
    end;
    for g,g in y[5](C)do
      g:Disconnect();
    end;
    R[l[1346]][l[267]](C);
    if A[l[1731]] then
      R[l[1146]](function()
        A[l[1731]]:Disconnect();
      end);
      A[l[1731]]=nil;
    end
    if A[l[932]] then
      R[l[1146]](function()
        A[l[932]]:Disconnect();
      end);
      A[l[932]]=nil;
    end
    if A[l[1052]] then
      R[l[1146]](function()
        A[l[1052]]:Disconnect();
      end);
      A[l[1052]]=nil;
    end
    if not y[18][l[630]]or not i[l[382]] then
      i:Destroy();
      if r then
        r:Destroy();
      end
      return;
    end
    Q(function()
      local C=s[87]();
      C[l[1146]](function()
        i:Destroy();
      end);
      if r then
        C[l[1146]](function()
          r:Destroy();
        end);
      end
    end);
  end
  A[l[794]]=t;
  p(i[l[956]],A[l[794]]);
  o,t,h=l[229],#Y,l[229];
  for C=o,t,h do
    local h=Y[C];
    local Q=h[l[404]]~=nil;
    local t=h[l[404]]==l[383];
    B=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=C,[l[711]]=l[1237]},E);
    local C,R,g=Q and a(l[211],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[393],l[659]),[l[948]]=n[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=n[l[1459]][l[588]](l[829],l[829]),[l[1535]]=c[l[98]],[l[1646]]=t and l[1296]or l[229],[l[1418]]=l[393],[l[711]]=l[1001]},B)or nil;
    if C then
      D(C,l[786]);
      R=a(l[734],{[l[1630]]=c[l[966]],[l[747]]=t and l[229]or l[874]},C);
      G[2]=a;
      G[3]=l[859];
      G[1]={};
      G[1][l[1150]]=f();
      G[1][l[1016]]=n[l[1689]][l[772]](l[659],l[659]);
      G[1][l[948]]=n[l[1459]][l[1368]](l[659],l[659]);
      G[1][l[1639]]=n[l[1459]][l[588]](t and l[310]or l[1158],t and l[310]or l[1158]);
      G[1][l[1646]]=l[229];
      G[1][l[1451]]=y[30](l[1411]);
      G[1][l[936]]=c[l[641]];
      G[1][l[2]]=t and l[393]or l[229];
      G[1][l[1557]]=n[l[128]][l[1557]][l[220]];
      G[1][l[711]]=l[1376];
      g=(G[2](G[3],G[1],C));
    else
    end
    G[7]=not Q;
    if G[7] then
      G[5]=a;
      G[6]=l[859];
      G[4]={};
      G[4][l[1150]]=f();
      G[4][l[1016]]=n[l[1689]][l[772]](l[393],l[659]);
      G[4][l[948]]=n[l[1459]][l[772]](l[393],l[1092],l[659],l[393]);
      G[4][l[1639]]=n[l[1459]][l[588]](l[750],l[750]);
      G[4][l[1646]]=l[229];
      G[4][l[1451]]=y[30](h[l[13]]or l[234]);
      G[4][l[936]]=c[l[1379]];
      G[4][l[2]]=l[1431];
      G[4][l[1557]]=n[l[128]][l[1557]][l[220]];
      G[4][l[711]]=l[1001];
      G[7]=G[5](G[6],G[4],B);
    end
    local u=G[7]or nil;
    local sP=a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[910],l[393]),[l[1639]]=n[l[1459]][l[772]](l[229],l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](h[l[572]]or l[1746]),[l[510]]=t and c[l[1095]]or c[l[1379]],[l[723]]=l[750],[l[916]]=t and l[393]or l[615],[l[164]]=n[l[128]][l[164]][l[1021]],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1001]},B);
    local LP,yP=a(l[1742],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[838]},B),l[1329];
    local function B()
      local zP=s[87]();
      if C then
        local JP,HP,fP={},l[1646],t and l[1296]or(yP and l[804]or l[229]);
        JP[HP]=fP;
        P(C,H,JP);
        HP,fP,JP={},l[747],t and l[229]or(yP and l[1296]or l[874]);
        HP[fP]=JP;
        P(R,H,HP);
        P(g,H,{[l[2]]=t and l[393]or l[229],[l[1639]]=zP[l[1459]][l[588]](t and l[310]or l[1158],t and l[310]or l[1158])});
      end
      if u then
        P(u,H,{[l[2]]=yP and l[393]or l[1431],[l[936]]=yP and c[l[1095]]or c[l[1379]]});
      end
      P(sP,H,{[l[916]]=(t or yP)and l[393]or l[615],[l[510]]=(t or yP)and c[l[1095]]or c[l[1379]]});
    end
    p(LP[l[1538]],function()
      yP=l[383];
      B();
    end);
    p(LP[l[1628]],function()
      yP=l[1329];
      B();
    end);
    p(LP[l[445]],function()
      local C,R,g=s[87](),h[l[1617]],not Q;
      if g then
        y[18]:chime(l[1320]);
        local Q=z==A;
        if Q then
          z=nil;
        end
        A[l[794]]();
        if C[l[40]](R)==l[1712] then
          C[l[1022]][l[281]](R,h);
        end
        return;
      end
      y[18]:chime(t and l[676]or l[404]);
      g=nil;
      if C[l[40]](R)==l[1712] then
        local Q,u=C[l[1146]](R,h);
        g=if Q then u else g;
      else
      end
      t=if C[l[40]](g)==l[268]then g else not t;
      h[l[404]]=t;
      if not A[l[630]] then
        return;
      end
      B();
    end);
  end;
  p(E:GetPropertyChangedSignal(l[160]),function()
    local C=s[87]();
    Z[l[392]]=C[l[1459]][l[588]](l[393],C[l[35]][l[499]](e(E)[l[636]]+l[659]));
  end);
  for e,C in y[5](j)do
    local j=n[l[1382]](C[l[457]])or l[393];
    local B=n[l[1382]](C[l[850]])or l[856];
    local h=n[l[1382]](C[l[109]])or l[229];
    if h~=h or h<=l[393]or h==l[94] then
      h=l[229];
    else
    end
    local Q=n[l[35]][l[819]](n[l[35]][l[499]](n[l[1382]](C[l[435]])or l[393]),l[393],l[786]);
    local t=n[l[35]][l[819]](n[l[1382]](C[l[1019]])or j,j,B);
    F=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[520]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=#Y+e,[l[711]]=l[1237]},E);
    a(l[1070],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[303],l[229]),[l[1639]]=n[l[1459]][l[772]](l[229],l[108],l[393],l[829]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[1420]]=n[l[1130]](C[l[572]]or l[1096]),[l[510]]=c[l[1379]],[l[723]]=l[310],[l[1634]]=n[l[128]][l[1634]][l[701]],[l[711]]=l[1001]},F);
    local Y=a(l[1070],{[l[1150]]=f(),[l[1016]]=n[l[1689]][l[772]](l[229],l[393]),[l[948]]=n[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=n[l[1459]][l[588]](l[205],l[829]),[l[1646]]=l[229],[l[437]]=n[l[128]][l[437]][l[1381]],[l[510]]=c[l[1095]],[l[723]]=l[310],[l[1634]]=n[l[128]][l[1634]][l[877]],[l[711]]=l[1001]},F);
    local E=a(l[211],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[303],l[1660]),[l[1639]]=n[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=c[l[1466]],[l[1418]]=l[393],[l[711]]=l[1001]},F);
    D(E,l[786]);
    local R=a(l[211],{[l[1150]]=f(),[l[1639]]=n[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=c[l[98]],[l[1418]]=l[393],[l[711]]=l[1376]},E);
    D(R,l[786]);
    local g,u,sP=a(l[1742],{[l[1150]]=f(),[l[948]]=n[l[1459]][l[588]](l[393],l[352]),[l[1639]]=n[l[1459]][l[772]](l[229],l[393],l[393],l[1707]),[l[1646]]=l[229],[l[2]]=l[229],[l[43]]=l[383],[l[711]]=l[838]},F),l[1329];
    local function LP()
      local yP=u;
      if yP then
        u=l[1329];
        O(l[715]);
      end
      sP=nil;
    end
    A[l[89]][#A[l[89]]+l[229]]=LP;
    local function yP()
      local zP,JP=s[87](),B-j;
      local HP,fP,aP,dP=JP>l[393]and(t-j)/JP or l[393],l[1420],Q>l[393]and zP[l[409]][l[846]](l[1213]..Q..l[347],t);
      if aP then
        dP=aP;
      else
        local JP,aP,PP=zP[l[1130]],zP[l[35]][l[499]],t;
        dP=(JP(aP(PP+l[659])));
      end
      Y[fP]=dP..zP[l[1130]](C[l[26]]or l[1387]);
      R[l[1639]]=zP[l[1459]][l[772]](HP,zP[l[35]][l[499]](l[1158]*(l[229]-HP)+l[659]),l[229],l[393]);
    end
    local function Y(R)
      local zP=s[87]();
      if not A[l[630]] then
        return;
      end
      local JP,HP=E[l[81]],E[l[160]];
      if HP[l[1437]]<=l[393] then
        return;
      end
      local fP=j+(B-j)*zP[l[35]][l[819]]((R-JP[l[1437]])/HP[l[1437]],l[393],l[229]);
      R=zP[l[35]][l[819]](j+zP[l[35]][l[499]]((fP-j)/h+l[659])*h,j,B);
      if Q>l[393] then
        fP=l[730]^Q;
        R=zP[l[35]][l[499]](R*fP+l[659])/fP;
      else
      end
      JP=t;
      if R==JP then
        return;
      end
      t=R;
      yP();
      HP=zP[l[40]](C[l[1617]])==l[1712];
      if HP then
        I(function(j)
          if A[l[630]] then
            C[l[1617]](j);
          end
        end,t);
      end
    end
    local function j(B)
      return v(B)[l[1437]];
    end
    p(g[l[1558]],function(B)
      local h,I=s[87](),not A[l[630]]or u;
      if I then
        return;
      end
      if B[l[1317]]~=h[l[128]][l[1317]][l[1356]]and B[l[1317]]~=h[l[128]][l[1317]][l[239]] then
        return;
      end
      u,sP=l[383],B;
      O(l[229]);
      local I,Q=h[l[1146]](Y,j(B));
      if not I then
        LP();
        h[l[972]](l[125]..h[l[1130]](Q));
      end
    end);
    p(y[9][l[233]],function(B)
      local h,I=s[87](),not A[l[630]]or not u;
      if I then
        return;
      end
      if B[l[1317]]~=h[l[128]][l[1317]][l[765]]and B[l[1317]]~=h[l[128]][l[1317]][l[239]] then
        return;
      end
      I=B[l[1317]]==h[l[128]][l[1317]][l[239]]and B~=sP;
      if I then
        return;
      end
      I,B=h[l[1146]](Y,j(sP));
      if not I then
        LP();
        h[l[972]](l[125]..h[l[1130]](B));
      end
    end);
    p(y[9][l[412]],function(Y)
      local j=s[87]();
      local B=Y[l[1317]]==j[l[128]][l[1317]][l[1356]]or Y[l[1317]]==j[l[128]][l[1317]][l[239]]and Y==sP;
      if B then
        LP();
      end
    end);
    p(g[l[956]],LP);
    A[l[61]][e]={[l[572]]=C[l[572]],[l[1681]]=g,[l[695]]=E,[l[266]]=F};
    yP();
  end;
  Z[l[392]]=n[l[1459]][l[588]](l[393],w);
  local function Z()
    i[l[1324]]=l[383];
    if r then
      r[l[1324]]=l[383];
    end
    b(i,l[894],N,function(Y)
      local e,j=s[87](),l[229]-Y;
      i[l[1569]]=j;
      i[l[948]]=e[l[1459]][l[588]](V,_+e[l[35]][l[499]](l[1092]*(l[229]-Y)+l[659]));
      if r then
        r[l[1646]]=j;
        r[l[948]]=i[l[948]];
        k[l[747]]=l[330]+l[1419]*j;
      end
    end);
  end
  local Y=n[l[655]][l[1587]]();
  local function e(j)
    local C,r=s[87](),j[l[1317]];
    if not A[l[630]]or C[l[655]][l[1587]]()-Y<l[874] then
      return l[1329];
    end
    if r~=C[l[128]][l[1317]][l[1356]]and r~=C[l[128]][l[1317]][l[321]--[[-1]]]and r~=C[l[128]][l[1317]][l[239]]and r~=C[l[128]][l[1317]][l[72]] then
      return l[1329];
    end
    if r==C[l[128]][l[1317]][l[239]] then
      local Y,C,r=v(j),i[l[81]],i[l[160]];
      return Y[l[1437]]<C[l[1437]]-l[786]or Y[l[636]]<C[l[636]]-l[786]or Y[l[1437]]>C[l[1437]]+r[l[1437]]+l[786]or Y[l[636]]>C[l[636]]+r[l[636]]+l[786];
    end
    return not W(i,l[786]);
  end
  G[8]=l[1731];
  G[9]=(p(y[9][l[1558]],function(Y)
    if not e(Y) then
      return;
    end
    Y=z==A;
    if Y then
      z=nil;
    end
    A[l[794]]();
  end));
  A[G[8]]=G[9];
  G[10]=l[932];
  G[11]=(p(y[9][l[233]],function(Y)
    local j=s[87]();
    if Y[l[1317]]~=j[l[128]][l[1317]][l[72]] then
      return;
    end
    if not e(Y) then
      return;
    end
    Y=z==A;
    if Y then
      z=nil;
    end
    A[l[794]]();
  end));
  A[G[10]]=G[11];
  o=n[l[1703]](J[l[1699]])==l[1089]and J[l[1699]]:IsA(l[957]);
  if o then
    local Y=J[l[1699]];
    local J=Y[l[81]];
    G[12]=l[1052];
    G[13]=(p(y[10][l[1119]],function()
      if not A[l[630]] then
        return;
      end
      local e=not Y[l[382]]or not Y[l[1324]]or(Y[l[81]]-J)[l[945]]>l[786];
      if e then
        local J=z==A;
        if J then
          z=nil;
        end
        A[l[794]]();
      end
    end));
    A[G[12]]=G[13];
  end
  n[l[1022]][l[281]](function()
    local n=s[87]();
    while A[l[630]]do
      local J=not y[18][l[630]]or not y[18][l[583]];
      if J then
        local J=z==A;
        if J then
          z=nil;
        end
        A[l[794]]();
        break;
      end
      n[l[1022]][l[153]](l[841]);
    end;
  end);
  z=A;
  Z();
  return A;
end
