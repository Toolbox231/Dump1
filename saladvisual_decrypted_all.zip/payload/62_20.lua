-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #20
-- offset 3229297..3229889 (592 bytes, type=payload)

local function i(E)
  if E:IsA("Accessory")and E.AccessoryType==Enum.AccessoryType.Hair then
    return true;
  end
  for nP,nP in ipairs(E:GetDescendants())do
    if nP:IsA("Attachment")and nP.Name=="HairAttachment" then
      return true;
    end
  end;
  local nP=zP(E);
  local zP=nP and string.format("%.0f",nP)or nil;
  if zP and(v[zP]or I[zP]==true) then
    return true;
  end
  if zP and I[zP]==nil then
    TP(E,nP);
  end
  local v,I,zP=string.lower(E.Name),pcall(E.GetTags,E);
  if I then
    for I,I in ipairs(zP)do
      v..=" "..string.lower(I);
    end;
  else
  end
  for I,I in ipairs(A)do
    if string.find(v,I,1,true) then
      return true;
    end
  end;
  return false;
end
