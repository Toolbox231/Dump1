-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #56
-- offset 3276563..3277898 (1335 bytes, type=payload)

local function _(X,x,k)
  local v=s[87]();
  local I=v[l[1725]][l[772]](k or l[243],v[l[128]][l[1353]][l[816]],v[l[128]][l[848]--[[readu8]]][l[100]]);
  local k,v,i,E=l[1329];
  d(X[l[1558]],function(X)
    local Q=s[87]();
    if X[l[1317]]~=Q[l[128]][l[1317]][l[1356]]and X[l[1317]]~=Q[l[128]][l[1317]][l[239]] then
      return;
    end
    local t,R=X[l[948]],x[l[948]];
    Q[l[1022]][l[153]]();
    local g=S;
    if g>l[393]or X[l[1101]]==Q[l[128]][l[1101]][l[912]] then
      return;
    end
    k,v,i=l[383],t,R;
    E=X[l[1317]]==Q[l[128]][l[1317]][l[239]]and X or nil;
    local Q;
    Q=X[l[1551]]:Connect(function()
      local t=s[87]();
      local R=X[l[1101]]==t[l[128]][l[1101]][l[912]];
      if R then
        k=l[1329];
        Q:Disconnect();
      end
    end);
  end);
  d(y[9][l[412]],function(X)
    local Q,t=s[87](),E;
    if t then
      local t=X==E;
      if t then
        k=l[1329];
      end
    else
      local t=X[l[1317]]==Q[l[128]][l[1317]][l[1356]];
      if t then
        k=l[1329];
      end
    end
  end);
  d(y[9][l[233]],function(X)
    local Q,t,R=s[87](),not k;
    if t then
      R=t;
    else
      local k=S;
      R=k>l[393];
    end
    if R then
      return;
    end
    t=E;
    if t then
      R=E;
      if X~=R then
        return;
      end
    elseif X[l[1317]]~=Q[l[128]][l[1317]][l[765]] then
      return;
    end
    local k,g,u=X[l[948]]-v,Q[l[1459]][l[772]],i;
    R,t,X=u[l[1437]][l[1609]],Q[l[35]][l[499]],i;
    local v,U=t(X[l[1437]][l[1485]]+k[l[1437]]),i;
    t,X,u=U[l[636]][l[1609]],Q[l[35]][l[499]],i;
    local i,Q=g(R,v,t,X(u[l[636]][l[1485]]+k[l[636]])),E;
    if Q then
      x[l[948]]=i;
    else
      P(x,I,{[l[948]]=i});
    end
  end);
end
