-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #38
-- offset 119423..119957 (534 bytes, type=payload)

local function K(o,c)
  if o.group~="cosmetic" then
    return;
  end
  local m=Vector3.new(tonumber(c.x)or 0,tonumber(c.y)or 0,tonumber(c.z)or 0);
  local S=math.clamp(tonumber(c.scale)or 1,0.25,2.5);
  for c,O in pairs(o.transforms or{})do
    if c.Parent then
      pcall(function()
        if O.kind=="attachment" then
          c.CFrame=p(O.cframe,m,S);
          return;
        end
        c.Size=O.size*S;
        if O.mesh and O.mesh.Parent and O.meshScale then
          O.mesh.Scale=O.meshScale*S;
        end
        local o=O.joint;
        if o and o.Parent then
          if O.first then
            o.C1=p(O.c1,m,S);
          else
            o.C0=p(O.c0,m,S);
          end
        end
      end);
    end
  end;
end
