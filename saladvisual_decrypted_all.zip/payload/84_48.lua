-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #48
-- offset 3674988..3676910 (1922 bytes, type=payload)

function()
  local N,K=pcall(r,s);
  local r,B=not l.Alive or o~=l._request;
  if r then
    B=r;
  else
    local A=z;
    B=A.Character~=m;
  end
  if B then
    return;
  end
  local B=Instance.new("Animation");
  B.AnimationId=N and K or O;
  local O=c:FindFirstChildOfClass("Animator")or c:WaitForChild("Animator",5);
  local A,w=pcall(function()
    return O and(O:LoadAnimation(B));
  end);
  if A and w then
    K=os.clock()+5;
    while l.Alive and o==l._request and w.Length<=0 and os.clock()<K do
      task.wait(0.05);
    end;
  end
  K,N=not l.Alive or o~=l._request;
  if K then
    N=K;
  else
    r=z;
    N=r.Character~=m;
  end
  if N then
    if A and w then
      pcall(function()
        w:Stop(0);
        w:Destroy();
      end);
    end
    B:Destroy();
    return;
  end
  l.PendingEmoteId=nil;
  if not A or not w or w.Length<=0 then
    if A and w then
      w:Destroy();
    end
    B:Destroy();
    if l._resumePack then
      l.ResetEmote();
    end
    l.LastError="Emote unavailable for this character or experience";
    if l.OnStateChange then
      l.OnStateChange();
    end
    return;
  end
  w.Priority=Enum.AnimationPriority.Action4;
  w.Looped=l.EmoteLoop==true;
  S=m:FindFirstChild("Animate");
  K=S;
  if K then
    l._emoteAnimate=S;
    N=not S.Disabled or l._reloadAnimate==S and l._reloadEnabled;
    l._emoteAnimateWasEnabled=N;
    l._reloadSerial=(l._reloadSerial or 0)+1;
    l._reloadAnimate=nil;
    l._reloadEnabled=nil;
    S.Disabled=true;
  end
  r=c:FindFirstChildOfClass("Animator");
  q(c,w);
  l._currentEmoteTrack=w;
  l._currentEmoteAnim=B;
  l.SelectedEmoteId=s;
  if r then
    l._emotePlayed=r.AnimationPlayed:Connect(function(s)
      if l._currentEmoteTrack==w and s~=w then
        pcall(function()
          s:Stop(0);
        end);
      end
    end);
  end
  l._emoteStopped=w.Stopped:Connect(function()
    if l._currentEmoteTrack~=w then
      return;
    end
    task.defer(function()
      if l._currentEmoteTrack~=w or w.IsPlaying then
        return;
      end
      if l.EmoteLoop then
        pcall(function()
          w:Play(0,1,l.EmoteSpeed/100);
        end);
      else
        l.ResetEmote();
      end
    end);
  end);
  if not pcall(function()w:Play(0,1,l.EmoteSpeed/100);end) then
    l.ResetEmote();
    l.LastError="Unable to play this emote";
  end
  if l.OnStateChange then
    l.OnStateChange();
  end
end
