-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #15
-- offset 8120..8818 (698 bytes, type=payload)

local function H(G,b)
  local o=RaycastParams.new();
  o.FilterType=Enum.RaycastFilterType.Exclude;
  o.FilterDescendantsInstances={G};
  o.IgnoreWater=true;
  local c,m,S,O={"LeftFoot","RightFoot","Left Leg","Right Leg"},(Vector3.new(0.0,0.0,0.0)),(Vector3.new(0.0,0.0,0.0)),0;
  for B,A in ipairs(c)do
    B=G:FindFirstChild(A);
    if B and(B:IsA("BasePart")) then
      A=workspace:Raycast(B.Position+Vector3.new(0,0.35,0),Vector3.new(0,-7,0),o);
      if A then
        m,S,O=m+A.Position,S+A.Normal,O+1;
      else
      end
    else
    end
  end;
  if O>0 then
    return m/O,S.Unit;
  end
  G=workspace:Raycast(b.Position+Vector3.new(0,1,0),Vector3.new(0,-16,0),o);
  if G then
    return G.Position,G.Normal;
  end
  return b.Position-Vector3.new(0,3,0),(Vector3.new(0.0,1.0,0.0));
end
