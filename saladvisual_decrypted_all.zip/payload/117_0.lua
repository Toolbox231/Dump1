-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[117] / function #0
-- offset 3628775..3629021 (246 bytes, type=payload)

function(s,s,s,s)
  return function(s,s,s)
    return function(s,l,L)
      local y,z,T,n=0,s,l,L;
      while true do
        if y<=0 then
          l,L=game:GetService("StarterGui"),{Title=z,Text=T};
          L.Duration=n or 5;
          l:SetCore("SendNotification",L);
          y=1;
        else
          return;
        end
      end;
    end;
  end;
end
