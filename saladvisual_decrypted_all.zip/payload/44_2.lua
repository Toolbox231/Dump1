-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #2
-- offset 3610438..3625493 (15055 bytes, type=payload)

function()
  local s,P,Z,G,Y={On=false,Target="Self",Color=Color3.fromRGB(120,200,255),Color2=Color3.fromRGB(255,120,220),Rainbow=false,Tint=false,Style="Bloom",Size=10,Life=0.9,Rate=140,Bright=85,Amount=100,Spread=100,Gravity=100,Always=false,Speed=18},"particles/",{Bloom={kind="particle",sprite={"p_bloom"},size=2.04,rate=34,life=1,speed={0.4,1.4},spread=16,rise=1.6,drag=3.5,spin=20,light=0.85},Glow={kind="particle",sprite={"p_glow","p_softglow"},size=2.4,rate=26,life=1.2,speed={0.2,1},spread=22,rise=2.2,drag=4,spin=12,light=1},Sparkle={kind="particle",sprite={"p_sparkle"},size=1.2,rate=46,life=0.8,speed={1,3.2},spread=45,rise=-2,drag=2.2,spin=180,light=0.9},Stars={kind="particle",sprite={"p_star","p_starnew"},size=1.32,rate=34,life=1.1,speed={0.8,2.4},spread=38,rise=-1.5,drag=2,spin=140,light=0.55},Fireflies={kind="particle",sprite={"p_firefly"},size=0.96,rate=30,life=1.8,speed={0.3,1.2},spread=60,rise=1.2,drag=5,spin=30,light=1},Hearts={kind="particle",sprite={"p_heart"},size=1.44,rate=22,life=1.3,speed={0.6,1.8},spread=30,rise=2.4,drag=3,spin=60,light=0.35},Snow={kind="particle",sprite={"p_snowflake"},size=1.2,rate=30,life=1.6,speed={0.3,1.1},spread=42,rise=-1.8,drag=3.5,spin=90,light=0.4},Lightning={kind="particle",sprite={"p_lightning"},size=1.44,rate=28,life=0.6,speed={1.4,3.6},spread=30,rise=0,drag=1.5,spin=220,light=1},Crowns={kind="particle",sprite={"p_crown"},size=1.44,rate=16,life=1.4,speed={0.6,1.6},spread=28,rise=2,drag=3,spin=70,light=0.3},Smolder={kind="particle",sprite={"p_bloom","p_softglow"},size=3.2,rate=14,life=2.6,speed={0.1,0.5},spread=70,rise=1,drag=6,spin=8,light=0.45},Halo={kind="particle",sprite={"p_glowboost"},size=2.8,rate=12,life=1.6,speed={0.05,0.3},spread=90,rise=0.4,drag=7,spin=15,light=1.3},Starfall={kind="particle",sprite={"p_star","p_starnew","p_sparkle"},size=0.84,rate=60,life=2.2,speed={0.2,0.9},spread=25,rise=-6,drag=1.2,spin=200,light=0.8},Swarm={kind="particle",sprite={"p_firefly","p_sparkle"},size=0.6,rate=90,life=1.1,speed={1.6,4.2},spread=120,rise=0,drag=2.5,spin=260,light=1},Static={kind="particle",sprite={"p_lightning","p_sparkle"},size=0.9,rate=75,life=0.35,speed={2.4,5.5},spread=75,rise=0,drag=0.8,spin=300,light=1.2},Frost={kind="particle",sprite={"p_snowflake","p_sparkle"},size=0.78,rate=55,life=2.4,speed={0.2,0.8},spread=80,rise=-1,drag=5,spin=60,light=0.7},Bloomburst={kind="particle",sprite={"p_bloom","p_glow","p_glowboost"},size=1.1,rate=100,life=0.5,speed={3,7},spread=180,rise=0,drag=1,spin=120,light=1.4},Ribbon={kind="ribbon",texture="",light=1}},{kind="ribbon"};
  local Y=l;
  G.texture=Y.file(P.."p_glow.png");
  G.local_file=true;
  G.light=2;
  Z.Comet=G;
  Z.Smoke={kind="ribbon",texture="rbxasset://textures/particles/smoke_main.dds",light=0.4};
  local e={"Bloom","Glow","Sparkle","Stars","Fireflies","Hearts","Snow","Lightning","Crowns","Smolder","Halo","Starfall","Swarm","Static","Frost","Bloomburst","Ribbon","Comet","Smoke"};
  local function j(C)
    local N=l;
    return N.id(C)or"";
  end
  local function C(N)
    local q=N.sprite;
    if q then
      local q=l;
      return j(q.file(P..N.sprite[math.random(1,#N.sprite)]..".png"));
    end
    if not N.local_file then
      return N.texture;
    end
    return j(N.texture);
  end
  local l={};
  local P=Color3.new(1,1,1);
  local function j(N)
    local q=l[N];
    if not q then
      return;
    end
    local b={"trail","emitter","a","b"};
    for D,D in ipairs(b)do
      local b=q[D];
      if b then
        pcall(function()
          b:Destroy();
        end);
      end
    end;
    l[N]=nil;
  end
  local function N()
    for q,b in pairs(l)do
      if not b.cfg or b.cfg==s then
        j(q);
      end
    end;
  end
  local function q(b)
    b=b or s;
    if b.Rainbow then
      local D=os.clock()*0.12%1;
      return Color3.fromHSV(D,0.85,1),Color3.fromHSV((D+0.22)%1,0.85,1);
    end
    return b.Color,b.Color2;
  end
  local function b(D,p)
    if D.own then
      return ColorSequence.new(Color3.new(1,1,1));
    end
    local D,r=q(p);
    return ColorSequence.new(D,r);
  end
  local function D(p,r)
    r=r or s;
    local K=p.size*(r.Size/10);
    return NumberSequence.new({NumberSequenceKeypoint.new(0,K*0.35),NumberSequenceKeypoint.new(0.25,K),NumberSequenceKeypoint.new(1,K*0.1)});
  end
  local function p(r)
    r=r or s;
    local K=1-math.clamp(r.Bright/100,0.05,1);
    return NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.12,K),NumberSequenceKeypoint.new(0.55,K+(1-K)*0.35),NumberSequenceKeypoint.new(1,1)});
  end
  local r;
  local function r(K,o,c,m)
    m=m or s;
    local S,O=Instance.new("Attachment"),L;
    S.Name=O.RandomString();
    S.Position=Vector3.new(0,-0.9,0);
    S.Parent=o;
    local O,B=Instance.new("ParticleEmitter"),L;
    O.Name=B.RandomString();
    O.Texture=C(c);
    O.LightEmission=c.light;
    O.LightInfluence=0;
    O.Enabled=false;
    O.Rate=c.rate*(m.Rate/100)*(m.Amount/100);
    O.Lifetime=NumberRange.new(m.Life*0.65,m.Life);
    O.Speed=NumberRange.new(c.speed[1],c.speed[2]);
    O.SpreadAngle=Vector2.new(c.spread,c.spread)*(m.Spread/100);
    O.Acceleration=Vector3.new(0,c.rise*(m.Gravity/100),0);
    O.Drag=c.drag;
    O.VelocityInheritance=0.3;
    O.EmissionDirection=Enum.NormalId.Back;
    O.Rotation=NumberRange.new(0,360);
    O.RotSpeed=NumberRange.new(-c.spin,c.spin);
    O.Color=b(c,m);
    O.Size=D(c,m);
    O.Transparency=p(m);
    O.Parent=S;
    l[K]={emitter=O,a=S,root=o,style=c,swap=0,size=m.Size,rate=m.Rate,amount=m.Amount,bright=m.Bright,enabled=false,life=m.Life,cfg=m};
  end
  local function b(K,o,c,m)
    m=m or s;
    local S,O=Instance.new("Attachment"),L;
    S.Name=O.RandomString();
    S.Position=Vector3.new(0,m.Size*0.09,0);
    S.Parent=o;
    local B,A=Instance.new("Attachment"),L;
    B.Name=A.RandomString();
    B.Position=Vector3.new(0,-m.Size*0.09,0);
    B.Parent=o;
    A,O=q(m);
    local w,F=Instance.new("Trail"),L;
    w.Name=F.RandomString();
    w.Attachment0=S;
    w.Attachment1=B;
    w.Lifetime=m.Life;
    w.MinLength=0.08;
    w.FaceCamera=true;
    w.LightEmission=c.light;
    w.LightInfluence=0;
    w.Texture=C(c);
    w.TextureMode=Enum.TextureMode.Static;
    w.TextureLength=4;
    w.Color=ColorSequence.new(A,O);
    w.WidthScale=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.5,0.62),NumberSequenceKeypoint.new(1,0)});
    F=1-math.clamp(m.Bright/100,0.05,1);
    w.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,F),NumberSequenceKeypoint.new(0.7,F+(1-F)*0.5),NumberSequenceKeypoint.new(1,1)});
    w.Parent=o;
    l[K]={trail=w,a=S,b=B,root=o,style=c,size=m.Size,life=m.Life,first=A,second=O,cfg=m};
  end
  local K;
  Y=y;
  local K,o,c=Y.GameFX,{};
  local function c(m)
    local S=m:FindFirstChild("HumanoidRootPart");
    if not S then
      return;
    end
    j(m);
    local O=z;
    local B=O:GetPlayerFromCharacter(m);
    O=B and o[B]or s;
    local A,w=O==s and s.Game;
    if A then
      local F;
      B=T;
      w=m==B.Character;
    else
      w=A;
    end
    if w then
      return;
    end
    w=Z[O.Style]or Z.Bloom;
    if w.kind=="ribbon" then
      b(m,S,w,O);
    else
      r(m,S,w,O);
    end
  end
  local function b(r)
    if not s.On then
      return false;
    end
    local m;
    local m=T;
    local S=r==m;
    return s.Target=="All"or S and s.Target=="Self"or not S and s.Target=="Other";
  end
  local function r()
    if not K then
      return;
    end
    local m,S=q();
    local O,B=K.Tune,{glow=s.Bright/85,rate=s.Rate/140,size=s.Size/10,life=s.Life/0.9,amount=s.Amount/100};
    B.color=s.Tint and ColorSequence.new(m,S)or nil;
    O("trail",B);
  end
  local function m(S,O)
    local B,A=(tostring(S).." "..tostring(O or"")):lower(),{"pride","minecraft","cubic","block","cube","dash","petal","leaves","flower","flame","bubble","ember","bloomfall","confetti","reicle","reticle","relic","soap","beam","chain"};
    for S,S in ipairs(A)do
      if B:find(S,1,true) then
        return false;
      end
    end;
    return true;
  end
  local function S()
    N();
    if s.Game and not m(s.Game) then
      s.Game=nil;
    end
    if K then
      K.SetGroup("trail",s.On and s.Game and m(s.Game)and{s.Game}or{});
    end
    r();
    if not s.On then
      return;
    end
    if not s.Style and not s.Game then
      return;
    end
    local O=z;
    for B,B in ipairs(O:GetPlayers())do
      if b(B)and B.Character then
        c(B.Character);
      end
    end;
  end
  local O,B=0;
  local A,w=L;
  G=n;
  A:AddSignal(G.RenderStepped:Connect(function(n)
    local w=L;
    if not w.ScreenGui.Parent then
      return;
    end
    w=s.Game and s.On;
    if w then
      O+=n;
      local F=O>0.12;
      if F then
        O=0;
        local O,F=q();
        local h=table.concat({tostring(O),tostring(F),s.Bright,s.Rate,s.Amount,s.Size,s.Life,tostring(s.Rainbow),tostring(s.Tint)},"|");
        O=h~=B;
        if O then
          B=h;
          r();
        end
      end
    end
    if not next(l) then
      return;
    end
    local O,B=q();
    w=s.Rainbow and ColorSequence.new(O,B)or nil;
    for F,h in pairs(l)do
      local W,V,_=h.cfg or s;
      if W~=s then
        V,_=q(W);
        w=W.Rainbow and ColorSequence.new(V,_)or nil;
      else
        V,_=O,B;
      end
      if not h.root or not h.root.Parent then
        j(F);
      elseif h.emitter then
        if not h.emitter.Parent then
          j(F);
        else
          local q,O=(h.root.AssemblyLinearVelocity*Vector3.new(1,0,1)).Magnitude,F:FindFirstChildOfClass("Humanoid");
          local B,X=O and O.MoveDirection.Magnitude>0.05,O and(O:GetState()==Enum.HumanoidStateType.Jumping or O:GetState()==Enum.HumanoidStateType.Freefall);
          X=W.Always or q>7 and(B or X);
          B=h.style;
          if h.enabled~=X then
            h.enabled=X;
            h.emitter.Enabled=X;
          end
          q,O=nil;
          if B.own then
            q,O=P,P;
          else
            q,O=V,_;
          end
          if h.first~=q or h.second~=O then
            h.first=q;
            h.second=O;
            h.emitter.Color=not B.own and w or ColorSequence.new(q,O);
          end
          if h.life~=W.Life then
            h.life=W.Life;
            h.emitter.Lifetime=NumberRange.new(W.Life*0.65,W.Life);
          end
          if h.size~=W.Size then
            h.size=W.Size;
            h.emitter.Size=D(B,W);
          end
          if h.rate~=W.Rate or h.amount~=W.Amount then
            h.rate,h.amount=W.Rate,W.Amount;
            h.emitter.Rate=B.rate*(W.Rate/100)*(W.Amount/100);
          end
          if h.bright~=W.Bright then
            h.bright=W.Bright;
            h.emitter.Transparency=p(W);
          end
          if B.sprite and#B.sprite>1 and X then
            h.swap=h.swap+n;
            if h.swap>0.22 then
              h.swap=0;
              h.emitter.Texture=C(B);
            end
          end
        end
      elseif not h.trail or not h.trail.Parent then
        j(F);
      else
        if h.first~=V or h.second~=_ then
          h.first=V;
          h.second=_;
          h.trail.Color=w or ColorSequence.new(V,_);
        end
        if h.life~=W.Life then
          h.life=W.Life;
          h.trail.Lifetime=W.Life;
        end
        if h.size~=W.Size then
          h.size=W.Size;
          h.a.Position=Vector3.new(0,W.Size*0.09,0);
          h.b.Position=Vector3.new(0,-W.Size*0.09,0);
        end
      end
    end;
  end));
  local function n(P)
    local q=L;
    q:AddPlayerSignal(P,P.CharacterAdded:Connect(function(q)
      if not b(P) then
        return;
      end
      task.delay(1,function()
        local D;
        local D=J[4][J[6]]and s.On and b(P)and P.Parent and P.Character==q and q.Parent;
        if D then
          c(q);
        end
      end);
    end));
  end
  G=z;
  for P,P in ipairs(G:GetPlayers())do
    n(P);
  end;
  Y,A=L,z;
  Y:AddSignal(A.PlayerAdded:Connect(n));
  n=y;
  n.Trail=s;
  s.Worn=function()
    if not(s.On and s.Style and Z[s.Style]and(s.Target=="Self"or s.Target=="All")) then
      return nil;
    end
    return{s=s.Style,a=s.Color:ToHex(),b=s.Color2:ToHex(),r=s.Rainbow==true,z=s.Size,l=s.Life,n=s.Rate,g=s.Bright,m=s.Amount,w=s.Always==true};
  end;
  s.Dress=function(L,z)
    local P;
    local P=T;
    if L==P then
      return;
    end
    if type(z)~="table"or not Z[tostring(z.s)] then
      s.Undress(L);
      return;
    end
    local T,q=pcall(Color3.fromHex,tostring(z.a));
    local D,p=pcall(Color3.fromHex,tostring(z.b));
    P={Style=tostring(z.s),Color=T and q or s.Color,Color2=D and p or s.Color2,Rainbow=z.r==true,Size=math.clamp(tonumber(z.z)or 10,1,40),Life=math.clamp(tonumber(z.l)or 0.9,0.1,5),Rate=math.clamp(tonumber(z.n)or 140,1,600),Bright=math.clamp(tonumber(z.g)or 85,1,100),Amount=math.clamp(tonumber(z.m)or 100,1,400),Spread=100,Gravity=100,Always=z.w==true};
    P.key=table.concat({P.Style,tostring(z.a),tostring(z.b),tostring(P.Rainbow),P.Size,P.Life,P.Rate,P.Bright,P.Amount,tostring(P.Always)},"|");
    if o[L]and o[L].key==P.key then
      return;
    end
    o[L]=P;
    if L.Character then
      pcall(c,L.Character);
    end
  end;
  s.Undress=function(L)
    if not o[L] then
      return;
    end
    o[L]=nil;
    local z=L.Character;
    if z and l[z]and l[z].cfg~=s then
      j(z);
    end
    if z and s.On and b(L) then
      pcall(c,z);
    end
  end;
  s.Guests=function()
    return o;
  end;
  task.spawn(function()
    while true do
      local L;
      local L=J[4][J[6]];
      if not L then
        break;
      end
      task.wait(1);
      for z,T in pairs(o)do
        if not z.Parent then
          o[z]=nil;
        else
          L=z.Character;
          local z=L and l[L];
          if L and L:FindFirstChild("HumanoidRootPart")and not(z and z.cfg==T) then
            pcall(c,L);
          end
        end
      end;
    end;
  end);
  Y=y;
  Y.TrailStyles=e;
  local l=y;
  l.ClearTrail=function()
    s.On=false;
    N();
    if K then
      pcall(K.SetGroup,"trail",{});
    end
  end;
  local l;
  A=H;
  n=A.Trail:AddLabel("Enabled");
  n:AddToggle({Default=false,Flag="trail",Callback=function(l)
    s.On=l;
    S();
  end});
  n:AddColorPicker({Default=s.Color,Flag="trail_color",Callback=function(l)
    s.Color=l;
    local L,y=not s.Tint and s.Game;
    if L then
      local z;
      l=f;
      y=(l());
    else
      y=L;
    end
    if y then
      local L;
      l=a;
      l("trail_tint",true);
    end
    S();
    r();
  end});
  local l="rbxasset://textures/particles/sparkles_main.dds";
  local function L(y)
    local z={};
    for T,T in ipairs(e)do
      if m(T) then
        local P,j,N,q=y and y[T]or l;
        if K then
          q,j,N=K.Art("builtin/trail/"..T,P);
        else
          q=P;
        end
        z[#z+1]={name=T,label=T,image=q,rect=j,rectsize=N};
      end
    end;
    for y,y in ipairs(K and K.Catalog or{})do
      if y.kind=="Trail"and m(y.id,y.label) then
        local T,P,j,N=K.Row(y),K.Art(y.id,nil);
        if P then
          T.image=P;
          T.rect=j;
          T.rectsize=N;
        end
        T.image=T.image or l;
        z[#z+1]=T;
      end
    end;
    return z;
  end
  local l;
  A=d;
  local l=A.Trails:AddGallery({Name="Trails",Icon="wand-sparkles",Position="left",Height=440,Cell=74,Reset=true,Smooth=true,Thumb="Asset",Blank="wand-sparkles",Empty="No trails",Values=L(),Default="Bloom",Flag="trail_style",Callback=function(y)
    if type(y)~="string"or y=="" then
      s.Style=nil;
      s.Game=nil;
      S();
      return;
    end
    if Z[y]and m(y) then
      s.Style=y;
      s.Game=nil;
    elseif K and K.ById[y]and m(y,K.ById[y].label) then
      s.Game=y;
    else
      s.Game=nil;
    end
    S();
  end});
  if K then
    K.OnThumbs(function()
      l:setdata(L());
    end);
    A=d;
    G,Y=A.Trails,function(y)
      if y then
        K.LoadThumbs();
      end
    end;
    G.Signal:Connect(Y);
  end
  task.delay(4,function()
    local y;
    local y=J[4][J[6]];
    if not y then
      return;
    end
    local z={};
    for T,d in ipairs(e)do
      T=Z[d];
      local P,Z=pcall(C,T);
      if P and type(Z)=="string"and Z~="" then
        z[d]=Z;
      end
      task.wait();
    end;
    y=J[4][J[6]];
    if y then
      pcall(function()
        l:setdata(L(z));
      end);
    end
  end);
  A=H;
  A.Trail:AddLabel("Target"):AddDropdown({Default="Self",Values={"Self","Other","All"},Flag="trail_target",Callback=function(l)
    s.Target=l;
    S();
  end});
  n:AddColorPicker({Name="Fade Color",Default=s.Color2,Flag="trail_color2",Callback=function(l)
    s.Color2=l;
    local L,y=not s.Tint and s.Game;
    if L then
      local z;
      l=f;
      y=(l());
    else
      y=L;
    end
    if y then
      local l;
      L=a;
      L("trail_tint",true);
    end
    S();
    r();
  end});
  Y=H;
  Y.Trail:AddLabel("Rainbow"):AddToggle({Default=false,Flag="trail_rainbow",Callback=function(l)
    s.Rainbow=l;
    S();
    r();
  end});
  A=H;
  A.Trail:AddLabel("Custom Colors"):AddToggle({Default=false,Flag="trail_tint",Callback=function(l)
    s.Tint=l;
    r();
  end});
  r();
  Y=H;
  A=Y.Trail:AddLabel("Options"):AddOption(1);
  A:AddLabel("Size"):AddSlider({Min=2,Max=40,Default=10,Rounding=0,Size=100,Flag="trail_width",Callback=function(l)
    s.Size=l;
  end});
  A:AddLabel("Length"):AddSlider({Min=2,Max=40,Default=9,Rounding=0,Size=100,Flag="trail_life",Callback=function(l)
    s.Life=l/10;
  end});
  A:AddLabel("Density"):AddSlider({Min=10,Max=300,Default=140,Type="%",Size=100,Flag="trail_rate",Callback=function(l)
    s.Rate=l;
  end});
  A:AddLabel("Amount"):AddSlider({Min=10,Max=300,Default=100,Type="%",Size=100,Flag="trail_amount",Callback=function(l)
    s.Amount=l;
    S();
    r();
  end});
  A:AddLabel("Brightness"):AddSlider({Min=5,Max=100,Default=85,Type="%",Size=100,Flag="trail_bright",Callback=function(l)
    s.Bright=l;
  end});
  A:AddLabel("Spread"):AddSlider({Min=0,Max=250,Default=100,Type="%",Size=100,Flag="trail_spread",Callback=function(l)
    s.Spread=l;
    S();
  end});
  A:AddLabel("Drift"):AddSlider({Min=0,Max=250,Default=100,Type="%",Size=100,Flag="trail_gravity",Callback=function(l)
    s.Gravity=l;
    S();
  end});
  A:AddLabel("Always On"):AddToggle({Default=false,Flag="trail_always",Callback=function(l)
    s.Always=l;
    S();
  end});
end
