-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #888
-- offset 3568274..3583125 (14851 bytes, type=payload)

local function Z(G,Y)
  local j=s[87]();
  Y=Y or{};
  local C=J:window({[l[1096]]=P(Y[l[1639]]or j[l[1459]][l[588]](l[1493],l[563])),[l[1132]]=T[l[826]]and l[827]or nil,[l[1686]]=Y[l[483]]or l[1383]});
  T[l[1067]]=C[l[1156]];
  if T[l[826]] then
    local N=j[l[1458]]:GetService(l[1408]--[[nparams]]);
    local function q()
      local b,D=s[87](),N:GetGuiInset()[l[636]];
      b[l[1146]](function()
        local N=s[87]();
        C:setsize(P(C[l[1096]]or N[l[1459]][l[588]](l[1493],l[563])));
        C[l[1156]][l[948]]=N[l[1459]][l[772]](l[659],l[393],l[659],N[l[35]][l[499]](D/l[59]));
      end);
    end
    q();
    G=j[l[964]][l[227]];
    if G then
      T:AddSignal(G:GetPropertyChangedSignal(l[952]):Connect(q));
    end
  end
  T[l[938]]=C[l[593]];
  local P={[l[336]]=C,[l[211]]=C[l[1156]],[l[256]]={},[l[552]]=l[229],[l[483]]=Y[l[483]]or l[1383]};
  local function Y(N)
    local q=s[87]();
    if q[l[1703]](N)~=l[1089] then
      return l[393];
    end
    local b=l[393];
    for D,p in q[l[1471]](N:GetDescendants())do
      if p:IsA(l[211])and p:GetAttribute(l[226]) then
        D=p:FindFirstChildWhichIsA(l[211]);
        if D and D[l[1347]]==q[l[128]][l[1347]][l[636]] then
          local N=D[l[160]][l[636]];
          if N>l[59]and p[l[160]][l[636]]<N-l[59] then
            p[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
            local D=p[l[382]];
            if D and D:IsA(l[211])and D[l[160]][l[636]]<N-l[59] then
              D[l[1639]]=q[l[1459]][l[772]](l[229],l[393],l[393],N);
            end
            b+=l[229];
          else
          end
        else
        end
      else
      end
    end;
    return b;
  end
  local function N(q)
    local b=s[87]();
    b[l[1022]][l[1061]](function()
      Y(q);
    end);
    b[l[1022]][l[1330]](l[659],function()
      Y(q);
    end);
  end
  local Y=l[383];
  local q=j[l[1089]][l[772]](l[37]);
  q[l[382]]=T[l[122]];
  local b,D,p=l[901],{[l[582]]=function()
    local r=Y;
    return r;
  end},l[1629];
  local function r(K,K)
    Y=K;
    q:Fire(K);
  end
  D[p]=r;
  D[l[34]]=function(p,r)
    p=s[70](q[l[511]]:Connect(r));
    return T:AddSignal(s:ZT(p));
  end;
  P[b]=D;
  local function b(D)
    C:render(not C[l[1600]]);
  end
  P[l[293]]=b;
  local b=C[l[80]];
  local function D(p,r)
    b(p,r);
    r=p[l[1600]]and l[383]or l[1329];
    local b=r~=Y;
    if b then
      Y=r;
      q:Fire(r);
      if r and p[l[897]] then
        N(p[l[897]][l[178]]);
      end
    end
  end
  C[l[80]]=D;
  local Y={};
  local q=l[1329];
  local function b(p)
    local r=s[87]();
    local K=r[l[1471]];
    for o,c in K(Y)do
      local K=c==p;
      o=K and q;
      if o then
        continue;
      end
      if c[l[1600]]~=K and c[l[1521]--[[0]]] then
        r[l[1146]](function()
          c:setopen(K);
        end);
      end
    end;
  end
  local function p(r)
    local r,K=s[87](),C[l[897]];
    if r[l[40]](K)~=l[1346] then
      return nil;
    end
    for o,o in r[l[1471]](C[l[1206]])do
      if o==K then
        return r[l[1130]](o[l[572]]);
      end
      for c,c in r[l[1471]](o[l[245]]or{})do
        if c==K then
          return r[l[1130]](o[l[572]])..l[532]..r[l[1130]](c[l[572]]);
        end
      end;
    end;
    return nil;
  end
  P[l[423]]=p;
  local function r(K,o)
    K=s[87]();
    if K[l[40]](o)~=l[409]or o==l[1746] then
      return l[1329];
    end
    local c,m=K[l[409]][l[56]](o,l[85]);
    c=c or o;
    for o,o in K[l[1471]](C[l[1206]])do
      if K[l[1130]](o[l[572]])==c then
        if m then
          for c,c in K[l[1471]](o[l[245]]or{})do
            if K[l[1130]](c[l[572]])==m then
              K[l[1146]](function()
                c[l[199]]();
              end);
              b(o);
              return l[383];
            end
          end;
        end
        K[l[1146]](function()
          o[l[199]]();
        end);
        return l[383];
      end
    end;
    return l[1329];
  end
  P[l[176]]=r;
  local function r(K,o)
    K=s[87]();
    if K[l[1703]](o)~=l[1459]or T[l[826]] then
      return;
    end
    K[l[1146]](function()
      C:setsize(o);
    end);
  end
  P[l[1193]]=r;
  local function r(K,o)
    K=s[87]();
    if o==nil then
      return;
    end
    P[l[483]]=o;
    K[l[1146]](function()
      C:setbind(o);
    end);
  end
  P[l[612]]=r;
  local r,K;
  local o,c={};
  local function m()
    local S=not K;
    if S then
      K=C:tab({[l[572]]=l[28],[l[13]]=l[240]});
      local O=K;
      local B,A=O[l[1674]],K;
      A[l[1674]]=function(O)
        local A=s[87]();
        if B then
          B(O);
        end
        if not O then
          return;
        end
        A[l[1022]][l[1061]](function()
          local O,B=s[87](),c or o[l[788]];
          q=l[383];
          if B then
            O[l[1146]](function()
              B:select();
            end);
          end
          q=l[1329];
        end);
      end;
    end
    S=K;
    return S;
  end
  local function K(S,O)
    local B,A=s[87](),not o[S];
    if A then
      local A=m();
      local m=A:sub({[l[572]]=S,[l[13]]=O});
      local O=m[l[1674]];
      if not B[l[1346]][l[23]](Y,A) then
        B[l[1346]][l[968]](Y,A);
      end
      m[l[1674]]=function(B)
        if O then
          O(B);
        end
        if B then
          c=m;
          b(A);
        end
      end;
      o[S]=m;
    end
    return o[S];
  end
  local function o(c,m,S)
    local O=s[87]();
    return O[l[360]][l[353]](c,m,S);
  end
  local function c(m,S,O,B,A,w,F,h,W)
    return{[l[641]]=m,[l[1132]]=S,[l[675]]=O,[l[1466]]=B,[l[966]]=A,[l[1529]--[[cancel]]]=w,[l[1095]]=F,[l[1379]]=h,[l[98]]=W};
  end
  local m={[l[1380]]=n,[l[614]]=c(o(l[1158],l[930],l[558]),o(l[1307],l[558],l[209]),o(l[730],l[750],l[884]),o(l[973],l[1241],l[1249]),o(l[520],l[161],l[694]),o(l[492],l[1592],l[929]),o(l[725],l[1305],l[1682]),o(l[1308],l[494],l[777]),o(l[1627],l[777],l[1682])),[l[815]]=c(o(l[786],l[551],l[310]),o(l[930],l[829],l[884]),o(l[1092],l[558],l[1241]),o(l[1307],l[884],l[941]),o(l[489],l[1708],l[694]),o(l[710],l[1115],l[1475]),o(l[725],l[1293],l[1682]),o(l[1396],l[632],l[1179]),o(l[205],l[768],l[1475])),[l[417]]=c(o(l[303],l[730],l[551]),o(l[730],l[114],l[829]),o(l[551],l[973],l[558]),o(l[750],l[1243],l[1707]),o(l[726],l[616],l[1167]),o(l[827],l[929],l[768]),o(l[307],l[1054],l[465]),o(l[627],l[123],l[544]),o(l[754],l[307],l[1671])),[l[1257]]=c(o(l[1158],l[551],l[303]),o(l[1307],l[829],l[730]),o(l[730],l[558],l[551]),o(l[973],l[884],l[750]),o(l[1656],l[616],l[520]),o(l[450],l[929],l[827]),o(l[1322],l[1054],l[1425]),o(l[1339],l[123],l[1308]),o(l[1179],l[929],l[117])),[l[390]]=c(o(l[930],l[1092],l[303]),o(l[973],l[750],l[551]),o(l[750],l[1307],l[930]),o(l[1707],l[114],l[310]),o(l[616],l[652],l[520]),o(l[929],l[1115],l[1179]),o(l[1682],l[1363],l[1305]),o(l[1242],l[544],l[1308]),o(l[725],l[1295],l[1627])),[l[167]]=c(o(l[730],l[930],l[303]),o(l[352],l[558],l[551]),o(l[829],l[310],l[930]),o(l[209],l[352],l[1307]),o(l[1098],l[652],l[906]),o(l[1475],l[920],l[710]),o(l[1682],l[1284],l[725]),o(l[1179],l[1479],l[627]),o(l[1682],l[1300],l[1167])),[l[1244]]=c(o(l[551],l[303],l[303]),o(l[829],l[551],l[551]),o(l[558],l[930],l[930]),o(l[884],l[310],l[310]),o(l[1168],l[906],l[906]),o(l[1475],l[492],l[492]),o(l[1682],l[1305],l[1305]),o(l[1179],l[422],l[422]),o(l[1475],l[652],l[1366])),[l[1103]]=c(o(l[730],l[1158],l[551]),o(l[114],l[1307],l[973]),o(l[973],l[730],l[558]),o(l[1243],l[558],l[1241]),o(l[1168],l[834],l[652]),o(l[929],l[1179],l[920]),o(l[1682],l[1425],l[580]),o(l[1179],l[1308],l[492]),o(l[1682],l[710],l[450])),[l[927]]=c(o(l[310],l[551],l[1307]),o(l[1707],l[973],l[352]),o(l[352],l[750],l[829]),o(l[658],l[1241],l[209]),o(l[339],l[652],l[1168]),o(l[1682],l[1295],l[667]),o(l[1682],l[1322],l[465]),o(l[1201],l[1479],l[1109]),o(l[1682],l[1300],l[681])),[l[1692]]=c(o(l[930],l[1158],l[750]),o(l[973],l[1307],l[1243]),o(l[750],l[730],l[1707]),o(l[1707],l[973],l[910]),o(l[652],l[1506],l[995]),o(l[920],l[1592],l[1682]),o(l[580],l[1305],l[1682]),o(l[1479],l[581],l[1592]),o(l[60],l[494],l[1682]))};
  local n,o={l[1380],l[614],l[815],l[417],l[1257],l[390],l[167],l[1244],l[1103],l[927],l[1692]};
  local function c(S,O)
    local B,A=s[87](),m[O];
    if not A then
      return;
    end
    J:retheme(A);
    O=J[l[1334]];
    J[l[1334]]=l[383];
    for m,w in B[l[534]](A)do
      S=J[l[1294]][l[1321]..m];
      if S and S[l[1255]] then
        B[l[1146]](S[l[1255]],w);
      end
    end;
    J[l[1334]]=O;
  end
  P[l[186]]=c;
  local function m(S)
    P:ApplyMenuTheme(l[1380]);
  end
  P[l[447]]=m;
  local function S(O)
    local B,A=s[87](),o;
    if A then
      O=o;
      return O;
    end
    o=K(l[1468],l[478]);
    A=o;
    O=a(A:section({[l[572]]=l[271],[l[1132]]=H(l[356])}));
    O:AddLabel(l[165]):AddDropdown({[l[1380]]=l[1380],[l[1561]]=n,[l[1315]]=l[1361],[l[1683]]=function(n)
      P:ApplyMenuTheme(n);
    end});
    O:AddLabel(l[437]):AddDropdown({[l[1380]]=l[1380],[l[1561]]=J:fontnames(),[l[1315]]=l[1344],[l[1683]]=function(n)
      J:setfont(n);
    end});
    A,O=B[l[1471]],{{l[1602],l[98],l[356]},{l[1420],l[1095],l[1316]},{l[1325],l[675],l[356]},{l[1082],l[1466],l[1316]},{l[296],l[1132],l[356]},{l[620],l[966],l[1316]},{l[979],l[1379],l[356]},{l[918],l[1529]--[[cancel]],l[1316]},{l[1515],l[641],l[356]}};
    for n,n in A(O)do
      B=o;
      B:color({[l[572]]=n[l[229]],[l[230]]=n[l[59]],[l[1132]]=H(n[l[863]])});
    end;
    O,A=o,{[l[572]]=l[1380]};
    A[l[1132]]=H(l[1316]);
    O:section(A):button({[l[572]]=l[1677],[l[1617]]=function()
      P:ResetMenuColors();
    end});
    O=o;
    return O;
  end
  P[l[1663]]=S;
  local n;
  local function o(S)
    S=n;
    if S then
      local O=n;
      return O;
    end
    S=K(l[1104],l[1517]);
    S:configs({[l[572]]=l[1104],[l[1132]]=H(l[356])});
    local O=S:section({[l[572]]=l[399],[l[1132]]=H(l[1316])});
    local function S(B,A)
      J:notify({[l[1434]]=B,[l[13]]=A and l[898]or l[1411],[l[440]]=l[863]});
    end
    local B;
    O:button({[l[572]]=l[1011],[l[1617]]=function()
      local A=s[87]();
      if A[l[40]](T[l[1332]])~=l[1712] then
        S(l[461],l[383]);
        return;
      end
      local w,F=T[l[1332]]();
      if not w then
        S(A[l[1130]](F),l[383]);
        return;
      end
      w=A[l[40]](A[l[302]])==l[1712]and A[l[1146]](A[l[302]],F);
      if B then
        B:SetValue(F);
      end
      S(w and l[881]or F);
    end});
    O:button({[l[572]]=l[17],[l[1617]]=function()
      local A,w,F=s[87](),J:clipboardExport();
      S(w and l[1234]or A[l[1130]](F),not w);
    end});
    B=a(O):AddLabel(l[386]):AddTextInput({[l[940]]=l[1123]});
    O:button({[l[572]]=l[1172],[l[1617]]=function()
      local A=s[87]();
      local w=A[l[409]][l[56]](B:GetValue()or l[1746],l[381])or l[1746];
      if A[l[409]][l[56]](w,l[698]) then
        if A[l[40]](T[l[148]])~=l[1712] then
          S(l[461],l[383]);
          return;
        end
        local F,h=T[l[148]](w);
        if F then
          B:SetValue(l[1746]);
          S(l[432]);
        else
          S(A[l[1130]](h),l[383]);
        end
        return;
      end
      local F,h;
      if w~=l[1746] then
        local W=J:thaw(w);
        if W then
          F,h=J:apply(W)==l[383],J[l[171]]and J[l[171]][l[1290]]and J[l[171]][l[1290]][l[229]];
        else
          F,h=l[1329],l[1279];
        end
        if F then
          B:SetValue(l[1746]);
        end
      else
        F,h=J:clipboardLoad();
      end
      S(F and l[432]or A[l[1130]](h or l[51]),not F);
    end});
    n={[l[1002]]=function()
    end};
    O=n;
    return O;
  end
  P[l[1211]]=o;
  local function n(o,o,S)
    local O,B=K(l[788],l[1716]),{[l[572]]=o or l[146],[l[1132]]=H(S)};
    return a(O:section(B));
  end
  P[l[395]]=n;
  m,p,c,D=l[693],j[l[1488]],{},l[533];
  local function n(o,S)
    local O,B=s[87](),not r;
    if B then
      o=K(l[788],l[1716]);
      r=a(o:section({[l[572]]=l[788],[l[1132]]=l[356]}));
    end
    local K=r[S];
    if O[l[40]](K)~=l[1712] then
      return K;
    end
    local function o(S,...)
      S=r;
      return K(S,...);
    end
    return o;
  end
  c[D]=n;
  P[m]=p({},c);
  do
    m=z(l[1329]);
    if m then
      m[l[1016]]=j[l[1689]][l[772]](l[393],l[229]);
      m[l[948]]=j[l[1459]][l[772]](l[393],l[730],l[229],l[1026]);
    end
    local n=z(l[383]);
    if n then
      (n:FindFirstChildOfClass(l[238])or j[l[1089]][l[772]](l[238],n))[l[1609]]=T[l[826]]and l[731]or l[229];
    end
    G=n and T[l[826]];
    if G then
      n[l[43]]=l[383];
      local z=l[393];
      local function G()
        local D=s[87]();
        local r=D[l[655]][l[1587]]();
        local K=r-z;
        if K<l[820] then
          return;
        end
        z=r;
        D[l[1146]](function()
          C:toggle();
        end);
      end
      local z=j[l[1458]]:GetService(l[1]);
      local D=j[l[1458]]:GetService(l[1408]--[[nparams]]);
      local r,K,o;
      local function c(m)
        local S=s[87]();
        if m[l[1317]]==S[l[128]][l[1317]][l[239]] then
          return S[l[1689]][l[772]](m[l[948]][l[1437]],m[l[948]][l[636]]);
        end
        return z:GetMouseLocation()-D:GetGuiInset();
      end
      local function D(m)
        local S,O=n[l[81]],n[l[160]];
        return m[l[1437]]>=S[l[1437]]and m[l[1437]]<=S[l[1437]]+O[l[1437]]and m[l[636]]>=S[l[636]]and m[l[636]]<=S[l[636]]+O[l[636]];
      end
      local function m(S)
        local O=s[87]();
        return S[l[1317]]==O[l[128]][l[1317]][l[1356]]or S[l[1317]]==O[l[128]][l[1317]][l[239]];
      end
      T:AddSignal(z[l[1558]]:Connect(function(S)
        local O=s[87]();
        if not m(S) then
          return;
        end
        if not(n[l[382]]and n[l[1324]]and J[l[1185]]) then
          return;
        end
        local B=c(S);
        local A,w=D(B)and B or nil,O[l[655]][l[1587]]();
        r,K=A,w;
        o=r and S or nil;
      end));
      T:AddSignal(z[l[412]]:Connect(function(z)
        local D=s[87]();
        if not m(z) then
          return;
        end
        local m=o;
        if z~=m then
          return;
        end
        m=r;
        local S=m;
        r,o=nil,nil;
        if not S then
          return;
        end
        if (c(z)-S)[l[945]]>l[930] then
          return;
        end
        S=D[l[655]][l[1587]]()-K;
        if S>l[509] then
          return;
        end
        G();
      end));
      for z,z in j[l[1471]](n:GetChildren())do
        p=l[957];
        if z:IsA(p) then
          z[l[43]]=l[383];
        end
      end;
    end
    j[l[1146]](function()
      J:setopener(l[1329]);
    end);
    local z=l[383];
    local function n(G)
      local j=s[87]();
      z=G and l[383]or l[1329];
      j[l[1146]](function()
        J:setwatermark(z);
      end);
      j[l[1146]](function()
        J:setopener(T[l[826]]and not z);
      end);
    end
    T[l[1665]]=n;
  end;
  local function z(n,J)
    n=s[87]();
    J=J or{};
    local G=C:tab({[l[572]]=J[l[1150]]or l[367],[l[13]]=T[l[810]](J[l[79]])});
    if J[l[911]]and G[l[1466]]and G[l[1466]][l[382]] then
      G[l[1466]][l[382]][l[537]]=l[823];
    end
    local j=G[l[1674]];
    G[l[1674]]=function(D)
      if j then
        j(D);
      end
      if D then
        b(G);
      end
    end;
    local j={[l[113]]=G,[l[1150]]=J[l[1150]],[l[901]]=d(G)};
    local function J(D,p)
      p=p or{};
      D={[l[572]]=p[l[1150]]or l[146],[l[1132]]=H(p[l[948]])};
      return a(G:section(D));
    end
    j[l[157]]=J;
    local function J(D)
      if D and G[l[199]] then
        G:select();
      end
    end
    j[l[1629]]=J;
    n[l[1346]][l[968]](P[l[256]],j);
    return f(j);
  end
  P[l[1530]--[[spawn]]]=z;
  local function z(n,J,G,j)
    local D,p=s[87](),C:tab({[l[572]]=J,[l[13]]=T[l[810]](G)});
    n={[l[113]]=p};
    for r,r in D[l[1471]](j or{})do
      local K=p:sub({[l[572]]=r[l[1150]],[l[13]]=T[l[810]](r[l[79]])});
      J={[l[1711]]=K,[l[1150]]=r[l[1150]],[l[901]]=d(K)};
      local function d(o,c)
        c=c or{};
        o={[l[572]]=c[l[1150]]or l[146],[l[1132]]=H(c[l[948]])};
        return a(K:section(o));
      end
      J[l[157]]=d;
      local function a(d)
        if d and K[l[199]] then
          K:select();
        end
      end
      J[l[1629]]=a;
      local function a(d,o)
        local c=s[87]();
        o=o or{};
        local m,S=l[919]+((o[l[543]]==l[383]or c[l[40]](o[l[869]])==l[1346])and l[1282]or l[393])-(o[l[665]]==l[1329]and l[913]or l[393]),c[l[1703]](C[l[1096]])==l[1459]and C[l[1096]][l[636]][l[1485]]or l[1709];
        d=c[l[35]][l[850]](l[422],c[l[35]][l[457]](o[l[1044]]or l[341],S-l[913]-l[1282]-m-l[1158]));
        S={[l[572]]=o[l[1150]]or l[484],[l[13]]=o[l[79]]and T[l[810]](o[l[79]])or l[1736],[l[1132]]=H(o[l[948]]),[l[1477]]=d,[l[1206]]=o[l[1561]]or{},[l[950]]=o[l[1380]],[l[1693]]=o[l[660]]and l[383]or l[1329],[l[1009]]=o[l[242]]==l[383],[l[798]]=o[l[1035]]or l[1191],[l[1410]]=o[l[19]]and T[l[810]](o[l[19]])or l[1736],[l[294]]=o[l[1264]]or l[151],[l[1141]]=o[l[1738]]==l[383],[l[634]]=o[l[883]]==l[383],[l[4]]=o[l[665]]~=l[1329],[l[1105]]=o[l[543]]==l[383],[l[424]]=o[l[869]],[l[603]]=c[l[40]](o[l[1516]])==l[1346]and{[l[13]]=T[l[810]](o[l[1516]][l[79]]or o[l[1516]][l[13]]or l[1716]),[l[1617]]=o[l[1516]][l[1683]]or o[l[1516]][l[1617]]}or nil,[l[1669]]=o[l[882]],[l[472]]=o[l[814]]or l[686],[l[1013]]=o[l[1315]],[l[1617]]=e(o[l[1315]],o[l[1683]])};
        return K:gallery(S);
      end
      J[l[420]]=a;
      n[r[l[1150]]]=f(J);
      D[l[1346]][l[968]](P[l[256]],n[r[l[1150]]]);
    end;
    local J=p[l[245]]and p[l[245]][l[229]]or nil;
    local H=l[1329];
    D[l[1346]][l[968]](Y,p);
    j,G=D[l[1471]],p[l[245]]or{};
    for a,a in j(G)do
      local d=a[l[1674]];
      a[l[1674]]=function(G)
        if G then
          J=a;
        end
        if d then
          d(G);
        end
        if G then
          N(a[l[178]]);
          b(p);
        end
      end;
    end;
    local a=p[l[1674]];
    p[l[1674]]=function(d)
      local G=s[87]();
      if a then
        a(d);
      end
      if d then
        N(p[l[178]]);
      end
      local a=d and J and not H;
      if not a then
        return;
      end
      H=l[383];
      G[l[1022]][l[1061]](function()
        local a=s[87]();
        H=l[1329];
        q=l[383];
        a[l[1146]](function()
          J:select();
        end);
        q=l[1329];
      end);
    end;
    local function H()
      local a,d=s[87](),J;
      if d then
        a[l[1146]](function()
          J:select();
        end);
      end
    end
    n[l[174]]=H;
    j=J and C[l[897]]==p;
    if j then
      D[l[1022]][l[1061]](function()
        local H=s[87]();
        H[l[1146]](function()
          J:select();
        end);
      end);
    end
    local function s()
      if p[l[1521]--[[0]]] then
        p:setopen(not p[l[1600]]);
      end
      return p[l[1600]];
    end
    n[l[1229]]=s;
    local function s()
      return p[l[1600]];
    end
    n[l[408]]=s;
    return n;
  end
  P[l[1084]]=z;
  return f(P);
end
