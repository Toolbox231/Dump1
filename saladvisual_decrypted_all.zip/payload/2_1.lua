-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[2] / function #1
-- offset 3641224..3642275 (1051 bytes, type=payload)

function(s,s,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  return function()
    local function s(z,T,n,J,H)
      return z.X>=T and z.X<=J and z.Y>=n and z.Y<=H;
    end
    local function z(T,n,J,H,f,a)
      if n=="Line" then
        local d,P=T.From,T.To;
        return s(d,J,H,f,a)or s(P,J,H,f,a)or s((d+P)/2,J,H,f,a);
      elseif n=="Square"or n=="Image" then
        local d,P=T.Position,T.Size;
        return d.X<f and d.X+P.X>J and d.Y<a and d.Y+P.Y>H;
      elseif n=="Triangle" then
        return s(T.PointA,J,H,f,a)or s(T.PointB,J,H,f,a)or s(T.PointC,J,H,f,a);
      elseif n=="Quad" then
        return s(T.PointA,J,H,f,a)or s(T.PointC,J,H,f,a);
      end
      return s(T.Position,J,H,f,a);
    end
    local s;
    local s,T=l;
    local T=L;
    local function L()
      local n=l;
      local J=n.WindowFrame;
      local H,f=J and J.Parent and J.Visible;
      if H then
        n=l;
        f=n.Lib.shown;
      else
        f=H;
      end
      if not f then
        return;
      end
      f,n,H=l,J.AbsolutePosition-l.ScreenGui.AbsolutePosition,J.AbsoluteSize;
      local l,f,a,d,P=n.X,n.Y,n.X+H.X,n.Y+H.Y;
      H=y;
      for y,P in pairs(H)do
        if y.Visible then
          n,J=pcall(z,y,P,l,f,a,d);
          if n and J then
            y.Visible=false;
          end
        end
      end;
    end
    s:AddSignal(T.RenderStepped:Connect(L));
  end;
end
