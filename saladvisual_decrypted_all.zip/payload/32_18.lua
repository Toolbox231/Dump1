-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #18
-- offset 231853..232620 (767 bytes, type=payload)

local function O(w)
  local F,h=0.3+math.random()*0.55,math.random()*3.141592653589793*2;
  local W=math.sqrt(math.max(0,1-F*F));
  local V=Vector3.new(W*math.cos(h),F,W*math.sin(h))*m;
  h,W=V.Unit,Vector3.new(math.random()-0.5,-1.1,math.random()-0.5);
  F=W-h*W:Dot(h);
  F=if F.Magnitude<0.05 then h:Cross((Vector3.new(0.0,1.0,0.0)))else F;
  h,W=Instance.new("Attachment"),L;
  h.Name=W.RandomString();
  h.Parent=D;
  local _,X=Instance.new("Attachment"),L;
  _.Name=X.RandomString();
  _.Parent=D;
  W=Instance.new("Beam");
  W.Attachment0=_;
  W.Attachment1=h;
  W.FaceCamera=true;
  W.LightInfluence=0;
  W.LightEmission=1;
  W.Segments=8;
  W.Width0=0.8;
  W.Width1=11;
  W.Parent=D;
  G[#G+1]={beam=W,head=h,tail=_,from=V,dir=F.Unit,born=w,life=0.9+math.random()*0.8,span=240+math.random()*300,trail=110+math.random()*150};
end
