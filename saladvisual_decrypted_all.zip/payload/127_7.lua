-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[127] / function #7
-- offset 200430..201238 (808 bytes, type=payload)

local function T(O)
  local B,A,F=math.floor(a.Number(d.Count,20,1,Y)),0;
  for h,h in ipairs(C)do
    if h.busy then
      A=A+1;
    else
      F=if not F then h else F;
    end
  end;
  if not F or A>=B then
    return false;
  end
  local B,A=G[d.Preset]or G.Perseids,O.CFrame.LookVector;
  local G,h=math.atan2(A.Z,A.X)+j:NextNumber(-1.45,1.45),d.Distance*j:NextNumber(0.7,1.2);
  F.origin=O.CFrame.Position+Vector3.new(math.cos(G)*h,h*j:NextNumber(0.5,1),math.sin(G)*h);
  G=Vector3.new(j:NextNumber(-B.spread,B.spread),j:NextNumber(-0.06,0.06),j:NextNumber(-B.spread,B.spread));
  F.velocity=(B.direction+G).Unit*B.speed*j:NextNumber(0.85,1.15);
  F.fire=d.Fireballs and j:NextNumber()<0.07;
  F.mass=F.fire and j:NextNumber(1.7,2.2)or j:NextNumber(0.45,1.1);
  F.life=d.Life*j:NextNumber(0.85,1.15)*(F.fire and 1.2 or 1);
  F.age=0;
  F.travel=0;
  F.busy=true;
  return true;
end
