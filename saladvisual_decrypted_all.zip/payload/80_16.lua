-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #16
-- offset 3269062..3269317 (255 bytes, type=payload)

local function d(P,Z)
  local G=s[87]();
  if #y[18][l[673]]>l[633] then
    for Y=#y[18][l[673]],l[229],l[715]do
      if not y[18][l[673]][Y][l[49]] then
        G[l[1346]][l[1357]](y[18][l[673]],Y);
      end
    end;
  end
  local Y=P:Connect(Z);
  G[l[1346]][l[968]](y[18][l[673]],Y);
  return Y;
end
