-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[82] / function #6
-- offset 28772..29944 (1172 bytes, type=payload)

local function q()
  local p=s[P.Kind];
  local r=G and p;
  if not r then
    return;
  end
  local K,o=P.Speed/100,p.texture;
  r=o and not o:find("://",1,true);
  if r then
    local c;
    local c=z;
    o=c.asset(o);
  else
  end
  G.Texture=o or l;
  G.LightInfluence=0;
  r=G;
  r.LightEmission=p.emission;
  local l;
  r=T;
  r.FxDepth(G,P.ThroughWalls);
  G.Drag=0;
  r=G;
  r.EmissionDirection=Enum.NormalId.Bottom;
  r=G;
  r.Rate=C();
  r=G;
  r.Color=ColorSequence.new(N);
  r=G;
  r.Rotation=p.rotation or NumberRange.new(0,360);
  r=G;
  r.RotSpeed=p.spin;
  r=G;
  r.SpreadAngle=p.spread;
  pcall(function()
    local l=G;
    l.Orientation=p.orientation or Enum.ParticleOrientation.FacingCamera;
  end);
  r=G;
  r.Speed=NumberRange.new(p.speed.Min*K,p.speed.Max*K);
  r=G;
  r.Acceleration=(p.acceleration+(p.lean or Vector3.new(0.0,0.0,0.0)))*K;
  r=G;
  r.Lifetime=NumberRange.new(p.lifetime.Min/K,p.lifetime.Max/K);
  K=G;
  K.Size=NumberSequence.new(p.size*(P.Size/100));
  pcall(function()
    local l=G;
    l.Squash=NumberSequence.new(p.squash);
  end);
  r=P.Fade/100;
  local l,z,T=math.clamp(1-(1-p.transparency[1])/r,0,1),math.clamp(1-(1-p.transparency[2])/r,0,1),G;
  T.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,l),NumberSequenceKeypoint.new(p.fade,z),NumberSequenceKeypoint.new(1,1)});
end
