-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #14
-- offset 3647654..3649119 (1465 bytes, type=payload)

local function W(V)
  local _=F(V,"Torso","UpperTorso");
  if not _ then
    return;
  end
  local X,x=h(_,CFrame.new(-1.012,0.5,0.852,0.966,0,0.259,0,1,0,-0.259,0,0.966)),Instance.new("ParticleEmitter");
  x.Lifetime=NumberRange.new(1,1);
  x.LockedToPart=true;
  x.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,0.944),NumberSequenceKeypoint.new(0.2,0),NumberSequenceKeypoint.new(0.8,0),NumberSequenceKeypoint.new(1,1)});
  x.LightEmission=1;
  x.Color=ColorSequence.new(N.Color);
  x.Speed=NumberRange.new(0.05,0.05);
  x.Size=NumberSequence.new(2.75,3.5);
  x.Rate=4;
  x.Texture="rbxassetid://13267054240";
  x.EmissionDirection=Enum.NormalId.Back;
  x.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  x.Rotation=NumberRange.new(-15,-15);
  O(x,X);
  X,V=h(_,CFrame.new(1.167,0.5,0.852,0.966,0,-0.259,0,1,0,0.259,0,0.966)),x:Clone();
  V.EmissionDirection=Enum.NormalId.Front;
  O(V,X);
  V,X=h(_,CFrame.new(0,0.3,0)),Instance.new("ParticleEmitter");
  X.Lifetime=NumberRange.new(2,2);
  X.FlipbookLayout=Enum.ParticleFlipbookLayout.Grid4x4;
  X.SpreadAngle=Vector2.new(180,180);
  X.LockedToPart=true;
  X.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.5,0.3),NumberSequenceKeypoint.new(1,1)});
  X.LightEmission=1;
  X.Color=ColorSequence.new(N.Color);
  X.Speed=NumberRange.new(0.5,0.5);
  X.Brightness=2;
  X.Size=NumberSequence.new(3,4);
  X.Rate=5;
  X.Texture="rbxassetid://11402221943";
  X.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;
  X.Rotation=NumberRange.new(0,360);
  O(X,V);
end
