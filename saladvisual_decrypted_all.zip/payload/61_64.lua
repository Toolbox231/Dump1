-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #64
-- offset 127308..128104 (796 bytes, type=payload)

local function O(B)
  local A=B.char:WaitForChild("HumanoidRootPart",5);
  local w=B.char:WaitForChild("Humanoid",5);
  local F=B.live.roots.HumanoidRootPart;
  local h=F and(F:WaitForChild("Main",5));
  h=h and(h:WaitForChild("Path",5));
  local F=h and(h:WaitForChild(c,5));
  local c=h and(h:WaitForChild(m,5));
  if not(A and w and F and c) then
    return;
  end
  local m,h,W,W=F.Rate;
  W,h=J,B.conn(J.RenderStepped:Connect(function()
    local B=w:GetState();
    if B==Enum.HumanoidStateType.Dead or not(F.Parent and c.Parent) then
      h:Disconnect();
      return;
    end
    local w=B==Enum.HumanoidStateType.Running;
    if F.Enabled~=w then
      F.Enabled=w;
    end
    if c.Enabled~=w then
      c.Enabled=w;
    end
    B=math.min((A.AssemblyLinearVelocity*Vector3.new(1,0,1)).Magnitude*2,m);
    B=B<=3 and 0 or B;
    if F.Rate~=B then
      F.Rate=B;
    end
    if c.Rate~=B then
      c.Rate=B;
    end
  end));
end
