-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[106] / function #14
-- offset 3639139..3639864 (725 bytes, type=payload)

local function C(N,q,b,D)
  local p=l;
  local r,K=p.MaterialStyles[f.ChamsMaterial];
  if r then
    K=r;
  else
    p=l;
    K=p.MaterialStyles.ForceField;
  end
  r,p=math.clamp(f.Transparency/100,0,1),math.clamp(K.transparency or 0,0,1);
  for o,c in ipairs(N.links)do
    local m=q.pose[o];
    local q=b.pose[o]or m;
    if m and c.clone.Parent then
      c.clone.CFrame=m:Lerp(q,D);
      c.clone.Material=K.material or Enum.Material.ForceField;
      c.clone.Reflectance=K.reflectance or 0;
      c.clone.Color=f.Color;
      c.clone.Transparency=1-(1-c.baseTransparency)*(1-r)*(1-p);
    end
  end;
  b=N.highlight;
  if b then
    b.Enabled=true;
    b.FillColor=f.Color;
    b.FillTransparency=r;
    b.OutlineColor=f.ChamsOutline;
    b.OutlineTransparency=f.OutlineOn and math.clamp(f.ChamsOutlineTransparency/100,0,1)or 1;
  end
end
