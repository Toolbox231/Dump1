-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #66
-- offset 3680071..3680300 (229 bytes, type=payload)

local function b()
  local D,p=pcall(function()
    if not(isfile and isfile(q)) then
      return nil;
    end
    local r=game:GetService("HttpService"):JSONDecode(readfile(q));
    return type(r)=="table"and#r>0 and r or nil;
  end);
  return D and p or nil;
end
