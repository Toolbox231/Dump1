-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #126
-- offset 139727..139939 (212 bytes, type=payload)

function(a)
  local Z,Y,j,q=a.image~=""and a.image~="rbxassetid://0"and a.image or nil;
  if not(a.g=="nullscape"and Z) then
    q,Y,j=d.Art(a.id,Z);
  else
    q=Z;
  end
  return{name=a.id,label=a.label,image=q,rect=Y,rectsize=j};
end
