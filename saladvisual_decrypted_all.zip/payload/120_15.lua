-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #15
-- offset 3649120..3651260 (2140 bytes, type=payload)

local function V(_)
  local X=F(_,"HumanoidRootPart");
  if not X then
    return;
  end
  local x,k,v=h(X,CFrame.new(0,-2.75,0)),NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.3,1),NumberSequenceKeypoint.new(0.6,2.5),NumberSequenceKeypoint.new(0.8,4),NumberSequenceKeypoint.new(1,6)}),Instance.new("ParticleEmitter");
  v.Lifetime=NumberRange.new(2,2);
  v.SpreadAngle=Vector2.new(0.001,0.001);
  v.LockedToPart=true;
  v.Transparency=NumberSequence.new(0,1);
  v.LightEmission=1;
  v.Color=ColorSequence.new(N.Color);
  v.Squash=NumberSequence.new(0);
  v.Speed=NumberRange.new(0.001,0.001);
  v.Brightness=2;
  v.Size=k;
  v.RotSpeed=NumberRange.new(-600,600);
  v.Texture="rbxassetid://12713358087";
  v.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  v.Rotation=NumberRange.new(0,360);
  O(v,x);
  _=Instance.new("ParticleEmitter");
  _.Lifetime=NumberRange.new(2,2);
  _.SpreadAngle=Vector2.new(0.001,0.001);
  _.LockedToPart=true;
  _.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.6,0.2),NumberSequenceKeypoint.new(1,1)});
  _.LightEmission=1;
  _.Color=ColorSequence.new(N.Color);
  _.Squash=NumberSequence.new(0,2);
  _.Speed=NumberRange.new(0.001,0.001);
  _.Brightness=2;
  _.Size=k;
  _.RotSpeed=NumberRange.new(-30,30);
  _.Texture="rbxassetid://7216849325";
  _.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  _.Rotation=NumberRange.new(0,360);
  O(_,x);
  X=Instance.new("ParticleEmitter");
  X.Lifetime=NumberRange.new(2,2);
  X.SpreadAngle=Vector2.new(0.001,0.001);
  X.LockedToPart=true;
  X.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.2,0.3),NumberSequenceKeypoint.new(1,1)});
  X.LightEmission=1;
  X.Color=ColorSequence.new(N.Color);
  X.Squash=NumberSequence.new(0);
  X.Speed=NumberRange.new(0.001,0.001);
  X.Brightness=2;
  X.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.3,2),NumberSequenceKeypoint.new(0.6,5),NumberSequenceKeypoint.new(0.8,8),NumberSequenceKeypoint.new(1,12)});
  X.RotSpeed=NumberRange.new(-40,40);
  X.Texture="rbxassetid://7216855136";
  X.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;
  X.Rotation=NumberRange.new(0,360);
  O(X,x);
end
