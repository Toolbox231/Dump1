-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #134
-- offset 140735..141086 (351 bytes, type=payload)

function()
  while true do
    local s;
    local s=y[4][y[6]];
    if not s then
      break;
    end
    s=C();
    local z=s~=O;
    if z then
      table.clear(m);
      for z in pairs(l)do
        B(z);
      end;
      O=nil;
      if s then
        task.wait(0.5);
        local z=y[4][y[6]]and C()==s;
        if z then
          O=s;
          for s in pairs(J)do
            e(s);
          end;
        end
      end
    else
      for s,y in pairs(l)do
        if not y.char.Parent then
          B(s);
        end
      end;
    end
    task.wait(0.5);
  end;
end
