-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #26
-- offset 115439..116223 (784 bytes, type=payload)

local function p(r)
  local K="rbxassetid://"..(string.match(r,"(%d+)%s*$")or"");
  r=N[K];
  local o=r==nil;
  if o then
    local c,m=q[K];
    if c then
      while true do
        task.wait(0.05);
        local c=not q[K]or not y[4][y[6]]or not b;
        if c then
          break;
        end
      end;
      r=N[K]or false;
    else
      q[K]=true;
      r=D(6,function()
        local c,m,S=game:GetService("InsertService"),Enum.CollisionFidelity.Box,Enum.RenderFidelity.Precise;
        return c:CreateMeshPartAsync(K,m,S);
      end)or D(6,function()
        local D=s[70](Content.fromUri(K));
        return f:CreateMeshPartAsync(s:ZT(D));
      end)or false;
      local f=y[4][y[6]]and b;
      if f then
        N[K]=r;
      else
        if r then
          r:Destroy();
          r=false;
        else
        end
      end
      q[K]=nil;
    end
  else
  end
  if r then
    return r:Clone();
  end
  r,o=Instance.new("Part"),Instance.new("SpecialMesh");
  o.MeshType=Enum.MeshType.FileMesh;
  o.MeshId=K;
  o.Parent=r;
  return r,o;
end
