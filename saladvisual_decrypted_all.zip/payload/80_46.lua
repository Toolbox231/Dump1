-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #46
-- offset 3274644..3274982 (338 bytes, type=payload)

local function B(A,w)
  local F;
  local h,W=l[756],function()
    local V=s[87]();
    if not(if A and A[l[1317]]==V[l[128]][l[1317]][l[239]]then A[l[1101]]==V[l[128]][l[1101]][l[115]]or A[l[1101]]==V[l[128]][l[1101]][l[890]]else y[9]:IsMouseButtonPressed(V[l[128]][l[1317]][l[1356]])) then
      F:Disconnect();
      w();
    end
  end;
  F=(y[10][h]:Connect(W));
  return F;
end
