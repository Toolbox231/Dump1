-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #72
-- offset 3280486..3281142 (656 bytes, type=payload)

local function u(U)
  if i[U]or y[18][l[388]]or not U[l[382]] then
    return;
  end
  local M={[l[504]]=U[l[1690]][l[636]],[l[717]]=U[l[1690]][l[636]],[l[77]]=U[l[1195]],[l[1018]]=l[393]};
  i[U]=M;
  local function sP()
    if U[l[1195]] then
      M[l[1018]]+=l[229];
      U[l[1195]]=l[1329];
    end
  end
  sP();
  local lP,LP,yP,zP=l[1271],{},l[1195],function()
    if M[l[1018]]>l[393] then
      M[l[1018]]-=l[229];
      return;
    end
    M[l[77]]=U[l[1195]];
    sP();
  end;
  s:MT(LP,0,U:GetPropertyChangedSignal(yP):Connect(zP));
  M[lP]=LP;
  M[l[1271]][l[863]]=U[l[648]]:Connect(function()
    local sP=s[87]();
    if not U:IsDescendantOf(sP[l[1458]]) then
      for sP,sP in y[3],M[l[1271]],nil do
        sP:Disconnect();
      end;
      i[U]=nil;
      E[U]=nil;
    end
  end);
end
