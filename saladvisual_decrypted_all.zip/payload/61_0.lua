-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #0
-- offset 47425..141331 (93906 bytes, type=payload)

function(s,l,l)
  return function(l,l,L)
    local L=l[1];
    local y=l[2];
    local z=l[3];
    local T=l[4];
    local n=l[5];
    local J=l[6];
    local H=l[7];
    return function()
      local l=game:GetService("TweenService");
      local f,a=game:GetService("AssetService"),{{id="aura/DevHere",g="nullscape",kind="Aura",label="DEV AURA",image="rbxassetid://126197195740375"},{id="aura/Sparkle",g="nullscape",kind="Aura",label="sparkle on",image="rbxassetid://88567310147890"},{id="aura/Tripmine",g="nullscape",kind="Aura",label="Tripmine",image="rbxassetid://75237315495863"},{id="aura/ElectricRing",g="nullscape",kind="Aura",label="Electric Ring",image="rbxassetid://124146817785034"},{id="aura/Binary",g="nullscape",kind="Aura",label="Binary",image="rbxassetid://107377966388858"},{id="aura/Gamble",g="nullscape",kind="Aura",label="Money Money",image="rbxassetid://109697815920086"},{id="aura/LightningCloud",g="nullscape",kind="Aura",label="Lightning Cloud",image="rbxassetid://99984622423083"},{id="aura/Gamble2",g="nullscape",kind="Aura",label="Gamble",image="rbxassetid://122674320949555"},{id="aura/FlamingPassion",g="nullscape",kind="Aura",label="Flaming Passion",image="rbxassetid://123311584895289"},{id="aura/LovelyFlowers",g="nullscape",kind="Aura",label="Lovely Flowers",image="rbxassetid://115908084010666"},{id="aura/WindPowers",g="nullscape",kind="Aura",label="Windforce",image="rbxassetid://114853551435521"},{id="aura/SpiritWielder",g="nullscape",kind="Aura",label="Spirit Wielder",image="rbxassetid://74064249035159"},{id="aura/Fireworks",g="nullscape",kind="Aura",label="Fireworks",image="rbxassetid://75759060370315"},{id="aura/PinkyStar",g="nullscape",kind="Aura",label="Pinky Star",image="rbxassetid://116380024686068"},{id="aura/Spotlight",g="nullscape",kind="Aura",label="Spotlight",image="rbxassetid://115595690497691"},{id="aura/Magnetised",g="nullscape",kind="Aura",label="Magnetised",image="rbxassetid://85986330936564"},{id="aura/Omniscient",g="nullscape",kind="Aura",label="Omniscient",image="rbxassetid://120348334337452"},{id="aura/Orbit",g="nullscape",kind="Aura",label="Orbit",image="rbxassetid://127047573770205"},{id="aura/Flare",g="nullscape",kind="Aura",label="Fleeting Flare",image="rbxassetid://124227578819417"},{id="aura/Dreamer",g="nullscape",kind="Aura",label="Dreamer",image="rbxassetid://113763601666046"},{id="aura/Smokescreen",g="nullscape",kind="Aura",label="Smokescreen",image="rbxassetid://101789464980556"},{id="aura/ArcSurge",g="nullscape",kind="Aura",label="Arc Surge",image="rbxassetid://75130954289443"},{id="aura/TwoLeafClover",g="nullscape",kind="Aura",label="Two Leaf Clover",image="rbxassetid://77608178317045"},{id="aura/Sparkly",g="nullscape",kind="Aura",label="Sparkly",image="rbxassetid://92419556417144"},{id="aura/SakuraDrift",g="nullscape",kind="Aura",label="Sakura Drift",image="rbxassetid://132187953750626"},{id="aura/Constellations",g="nullscape",kind="Aura",label="Constellations",image="rbxassetid://113126856512734"},{id="aura/Heartbeat",g="nullscape",kind="Aura",label="Pounding Heart",image="rbxassetid://140160563383584"},{id="aura/Symphony",g="nullscape",kind="Aura",label="Symphony",image="rbxassetid://105625212970330"},{id="aura/Halo",g="nullscape",kind="Aura",label="Halo",image="rbxassetid://102502972098940"},{id="aura/Hallucination",g="nullscape",kind="Aura",label="Hallucination",image="rbxassetid://116929175543565"},{id="aura/Starshower",g="nullscape",kind="Aura",label="Starshower",image="rbxassetid://78698906348004"},{id="aura/Sorrow",g="nullscape",kind="Aura",label="Burrowing Heaven",image="rbxassetid://94486508928781"},{id="aura/OFF",g="nullscape",kind="Aura",label="OFF",image="rbxassetid://78819877969385"},{id="aura/Artistry",g="nullscape",kind="Aura",label="Artistry",image="rbxassetid://73297187058880"},{id="aura/Gleach",g="nullscape",kind="Aura",label="Fragile Ocean",image="rbxassetid://102873835308297"},{id="aura/God",g="nullscape",kind="Aura",label="Divine",image="rbxassetid://123529670079452"},{id="aura/IntrusiveThoughts",g="nullscape",kind="Aura",label="Intrusive Thoughts",image="rbxassetid://74933855775024"},{id="aura/Fake I.C.B.M",g="nullscape",kind="Aura",label="Fake I.C.B.M",image="rbxassetid://106988079747139"},{id="aura/Doturer",g="nullscape",kind="Aura",label="Doturer",image="rbxassetid://119606002311633"},{id="aura/Bioluminescence",g="nullscape",kind="Aura",label="Bioluminescence",image="rbxassetid://112428303301349"},{id="aura/Confetti",g="nullscape",kind="Aura",label="Confetti",image="rbxassetid://133909575500318"},{id="aura/Greeny",g="nullscape",kind="Aura",label="Greeny",image="rbxassetid://107232357425080"},{id="aura/HamsterWheel",g="nullscape",kind="Aura",label="Hamster Wheel",image="rbxassetid://87982253630712"},{id="aura/Mistlebell",g="nullscape",kind="Aura",label="Mistlebell",image="rbxassetid://101312612475336"},{id="aura/RainbowRoad",g="nullscape",kind="Aura",label="Rainbow Road",image="rbxassetid://127570972043269"},{id="aura/ShakySignal",g="nullscape",kind="Aura",label="Shaky Signal",image="rbxassetid://101365494741965"},{id="aura/Warmth",g="nullscape",kind="Aura",label="Warmth",image="rbxassetid://133215054247701"},{id="aura/Censored",g="nullscape",kind="Aura",label="Censored",image="rbxassetid://4554671670"},{id="aura/ChristmasTree",g="nullscape",kind="Aura",label="Christmas Tree",image="rbxassetid://80046968475625"},{id="aura/Snowflakes",g="nullscape",kind="Aura",label="Snow flakes",image="rbxassetid://108321970042100"},{id="aura/Helicopter",g="nullscape",kind="Aura",label="Hamster wheel",image="rbxassetid://95316586744403"},{id="aura/Echo",g="nullscape",kind="Aura",label="Echo",image="rbxassetid://100155853581977"},{id="aura/RNS_Ring",g="nullscape",kind="Aura",label="Rabbit Ring",image="rbxassetid://95776534296229"},{id="aura/Heartbreaker",g="nullscape",kind="Aura",label="Heartbreaker",image="rbxassetid://85088847682110"},{id="aura/VoidbrokenFull",g="nullscape",kind="Aura",label="The Voidbreaker",image="rbxassetid://87557759899681"},{id="aura/Voidbroken",g="nullscape",kind="Aura",label="Voidbroken",image="rbxassetid://99117732084642"},{id="aura/ConvergingEnergy",g="nullscape",kind="Aura",label="Converging Energy",image="rbxassetid://117267373338774"},{id="aura/Core",g="nullscape",kind="Aura",label="CORE",image="rbxassetid://128688817823173"},{id="aura/Digitalization",g="nullscape",kind="Aura",label="Digitalization",image="rbxassetid://123405541371605"},{id="aura/FairyWings",g="nullscape",kind="Aura",label="Fairy Wings",image="rbxassetid://117769159678958"},{id="aura/Framework",g="nullscape",kind="Aura",label="Framework",image="rbxassetid://113561621150985"},{id="aura/Holographic",g="nullscape",kind="Aura",label="Holographic",image="rbxassetid://78687980925242"},{id="aura/Layers",g="nullscape",kind="Aura",label="Layers",image="rbxassetid://122936592663811"},{id="aura/MartOrbit",g="nullscape",kind="Aura",label="Mart Orbit",image="rbxassetid://78666709943037"},{id="aura/Monovoid",g="nullscape",kind="Aura",label="Monovoid",image="rbxassetid://84950035160857"},{id="aura/MysticalPortal",g="nullscape",kind="Aura",label="Mystical Portal",image="rbxassetid://109606892934316"},{id="aura/Fran",g="nullscape",kind="Aura",label="Fran",image="rbxassetid://121961339583744"},{id="aura/(???)",g="nullscape",kind="Aura",label="(???)",image="rbxassetid://129301720888774"},{id="aura/Strings",g="nullscape",kind="Aura",label="Strings",image="rbxassetid://91105633534388"},{id="aura/StarLight",g="nullscape",kind="Aura",label="StarLight",image="rbxassetid://80419156704731"},{id="aura/Null",g="nullscape",kind="Aura",label="Null",image="rbxassetid://131731770427779"},{id="aura/PrototypeFusionCoil",g="nullscape",kind="Aura",label="Prototype Fusion Coil",image="rbxassetid://90228827190818"},{id="aura/SparklyDuet",g="nullscape",kind="Aura",label="Sparkly Duet",image="rbxassetid://95185510424047"},{id="aura/Tria.OS",g="nullscape",kind="Aura",label="Tria.OS",image="rbxassetid://133540510629848"},{id="aura/Beacon",g="nullscape",kind="Aura",label="Beacon of Hope",image="rbxassetid://78521528368744"},{id="aura/Disco",g="nullscape",kind="Aura",label="Disco",image="rbxassetid://96245049429594"},{id="aura/EchoDev",g="nullscape",kind="Aura",label="Echo",image="rbxassetid://121493846930435"},{id="aura/Bubbles",g="nullscape",kind="Aura",label="Bubbles",image="rbxassetid://100567949148560"},{id="aura/Leandro",g="nullscape",kind="Aura",label="Leandro",image="rbxassetid://114152167600306"},{id="aura/AuraMonster",g="nullscape",kind="Aura",label="Aura Monster",image="rbxassetid://93830740367012"},{id="aura/CoreMeltdown",g="nullscape",kind="Aura",label="Core Meltdown",image="rbxassetid://114810290296330"},{id="aura/Prophecised",g="nullscape",kind="Aura",label="Prophecised",image="rbxassetid://5186314328"},{id="aura/Virtuous",g="nullscape",kind="Aura",label="Virtuous",image="rbxassetid://99511421371093"},{id="aura/ExAltiora",g="nullscape",kind="Aura",label="Ex Altiora",image="rbxassetid://101111334873986"},{id="aura/CeaselessWatcher",g="nullscape",kind="Aura",label="Watcher's Crown",image="rbxassetid://86330471036167"},{id="aura/Sigil",g="nullscape",kind="Aura",label="Sigil",image="rbxassetid://123902991349920"},{id="aura/Afflicted",g="nullscape",kind="Aura",label="Afflicted",image="rbxassetid://99800979270490"},{id="aura/Resinwoven",g="nullscape",kind="Aura",label="Resinwoven",image="rbxassetid://81758931624783"},{id="aura/Springer",g="nullscape",kind="Aura",label="Springer",image="rbxassetid://118652061920702"},{id="aura/SpeedLines",g="nullscape",kind="Aura",label="Speed Lines",image="rbxassetid://74496358115612"},{id="aura/Nulllight",g="nullscape",kind="Aura",label="Null-light",image="rbxassetid://122883125817418"},{id="aura/Marionette",g="nullscape",kind="Aura",label="Marionette",image="rbxassetid://118652061920702"},{id="aura/GraceDeserving",g="nullscape",kind="Aura",label="Grace Deserving",image="rbxassetid://87423954166041"},{id="aura/CyclingKnowledge",g="nullscape",kind="Aura",label="Cycling Knowledge",image="rbxassetid://109054253094651"},{id="trail/Plain",g="nullscape",kind="Trail",label="Plain Trail",image="rbxassetid://111439499681583"},{id="trail/Evil",g="nullscape",kind="Trail",label="Evil Long Trail",image="rbxassetid://95806490556974"},{id="trail/BlueFire",g="nullscape",kind="Trail",label="Blue Fire",image="rbxassetid://132334252419648"},{id="trail/Fire",g="nullscape",kind="Trail",label="Fire",image="rbxassetid://96731610907422"},{id="trail/Nullpower",g="nullscape",kind="Trail",label="Nullpower",image="rbxassetid://131782352093312"},{id="trail/Orange",g="nullscape",kind="Trail",label="Orange Lover",image="rbxassetid://137348177613640"},{id="trail/GuardianTrail",g="nullscape",kind="Trail",label="Blooming Flowers",image="rbxassetid://139471280164226"},{id="trail/Energizer",g="nullscape",kind="Trail",label="Energizer",image="rbxassetid://129555231598487"},{id="trail/LooseYarn",g="nullscape",kind="Trail",label="Loose Yarn",image="rbxassetid://85091833841282"},{id="trail/Buttery",g="nullscape",kind="Trail",label="Subspace",image="rbxassetid://83581993299641"},{id="trail/Duality",g="nullscape",kind="Trail",label="Duality",image="rbxassetid://114857776748830"},{id="trail/FriendshipMaximum",g="nullscape",kind="Trail",label="Friendship Maximum",image="rbxassetid://83526667519731"},{id="trail/Vaporwaver",g="nullscape",kind="Trail",label="Vaporwaver",image="rbxassetid://140585661878190"},{id="trail/ComicallyOnFire",g="nullscape",kind="Trail",label="Comically on Fire",image="rbxassetid://114364981025591"},{id="trail/ChainAndBall",g="nullscape",kind="Trail",label="Chain and Ball",image="rbxassetid://134726616486773"},{id="trail/Greedy",g="nullscape",kind="Trail",label="Greedy Goblin",image="rbxassetid://113812925355477"},{id="trail/PathTrail",g="nullscape",kind="Trail",label="Path Trail",image="rbxassetid://14354670986"},{id="trail/Pride1",g="nullscape",kind="Trail",label="Pride 1",image="rbxassetid://93387465730458"},{id="trail/Pride2",g="nullscape",kind="Trail",label="Pride 2",image="rbxassetid://108649024325046"},{id="trail/Pride3",g="nullscape",kind="Trail",label="Pride 3",image="rbxassetid://79248356345459"},{id="trail/Pride4",g="nullscape",kind="Trail",label="Pride 4",image="rbxassetid://105919436510097"},{id="trail/Pride5",g="nullscape",kind="Trail",label="Pride 5",image="rbxassetid://134246492956790"},{id="trail/Kanni",g="nullscape",kind="Trail",label="Cosmic Breeze",image="rbxassetid://9382695985"},{id="trail/PaintBrush",g="nullscape",kind="Trail",label="Paint Brush",image="rbxassetid://80422061342283"},{id="trail/Pride7",g="nullscape",kind="Trail",label="Pride 7",image="rbxassetid://126946896002176"},{id="trail/Pride9",g="nullscape",kind="Trail",label="Pride 9",image="rbxassetid://103755236226633"},{id="trail/Pride6",g="nullscape",kind="Trail",label="Pride 6",image="rbxassetid://73211428952704"},{id="trail/Pride10",g="nullscape",kind="Trail",label="Pride 10",image="rbxassetid://76809541307957"},{id="trail/Pride8",g="nullscape",kind="Trail",label="Pride 8",image="rbxassetid://115250458239655"},{id="trail/HorribleLongTrail",g="nullscape",kind="Trail",label="Horrible Long Trail",image="rbxassetid://94658685338670"},{id="trail/ArmTrails",g="nullscape",kind="Trail",label="Arm Trails",image="rbxassetid://100091462847457"},{id="trail/ShinyWhitePebbles",g="nullscape",kind="Trail",label="Pebbles",image="rbxassetid://78183375080727"},{id="trail/NeonWarrior",g="nullscape",kind="Trail",label="Neon Warrior",image="rbxassetid://75045636668409"},{id="trail/NeonGuardian",g="nullscape",kind="Trail",label="Neon Guardian",image="rbxassetid://133255617275191"},{id="trail/HotPink",g="nullscape",kind="Trail",label="Hot Pink",image="rbxassetid://110575592248299"},{id="trail/Flow",g="nullscape",kind="Trail",label="Flow",image="rbxassetid://95338961796024"},{id="trail/Connection",g="nullscape",kind="Trail",label="Connection",image="rbxassetid://78801209880886"},{id="trail/ColdFeet",g="nullscape",kind="Trail",label="Cold Feet",image="rbxassetid://116134128400606"},{id="trail/Domasp",g="nullscape",kind="Trail",label="Domasp Mode",image="rbxassetid://6808789896"},{id="trail/Candycane",g="nullscape",kind="Trail",label="Candy Cane",image="rbxassetid://99765652276307"},{id="trail/Pride11",g="nullscape",kind="Trail",label="Pride 11",image="rbxassetid://135288314296180"},{id="trail/IsaacCreepBlue",g="nullscape",kind="Trail",label="Teary",image="rbxassetid://128212963463472"},{id="trail/IsaacCreepRed",g="nullscape",kind="Trail",label="Unclean",image="rbxassetid://117529618828696"},{id="trail/Shimmer",g="nullscape",kind="Trail",label="Shimmering",image="rbxassetid://125756450389965"},{id="trail/Dogma",g="nullscape",kind="Trail",label="Dogma",image="rbxassetid://84564187893246"},{id="trail/EvilEye",g="nullscape",kind="Trail",label="Evil Eye",image="rbxassetid://114968891254827"},{id="trail/OoeyGooey",g="nullscape",kind="Trail",label="Ooey Gooey",image="rbxassetid://128450282482613"},{id="trail/CounterSpectrum",g="nullscape",kind="Trail",label="Counter Spectrum",image="rbxassetid://99845641550700"},{id="trail/DarkEcho",g="nullscape",kind="Trail",label="Dark Echo",image="rbxassetid://100435889289587"},{id="trail/BloomingBlossom",g="nullscape",kind="Trail",label="Blooming Blossom",image="rbxassetid://88029840741842"},{id="trail/Wizardry",g="nullscape",kind="Trail",label="Wizardry",image="rbxassetid://94856857380618"},{id="Unusual/WarpAura",g="evade",kind="Unusual",label="Warp Aura",image="rbxassetid://16782021847"},{id="Unusual/TopazAura",g="evade",kind="Unusual",label="Topaz Aura",image="rbxassetid://14579645898"},{id="Unusual/SapphireAura",g="evade",kind="Unusual",label="Sapphire Aura",image="rbxassetid://18552696263"},{id="Unusual/RubyAura",g="evade",kind="Unusual",label="Ruby Aura",image="rbxassetid://15527225018"},{id="Unusual/GeometricAura",g="evade",kind="Unusual",label="Geometric Aura",image="rbxassetid://12371709421"},{id="Unusual/EmeraldAura",g="evade",kind="Unusual",label="Emerald Aura",image="rbxassetid://13992197350"},{id="Unusual/DuometricAura",g="evade",kind="Unusual",label="EVADE Aura",image="rbxassetid://14292325666"},{id="Unusual/ChromaticAura",g="evade",kind="Unusual",label="Chromatic Aura",image="rbxassetid://14579645898"},{id="Unusual/AmethystAura",g="evade",kind="Unusual",label="Amethyst Aura",image="rbxassetid://15040069701"},{id="Unusual/AmberAura",g="evade",kind="Unusual",label="Amber Aura",image="rbxassetid://15988431458"},{id="Cosmetic/Angelic",g="evade",kind="Cosmetic",label="Angelic",image=""},{id="Cosmetic/AviatorCap",g="evade",kind="Cosmetic",label="Aviator Cap",image=""},{id="Cosmetic/BackGuitar",g="evade",kind="Cosmetic",label="Back Guitar",image=""},{id="Cosmetic/BlueFadedCape",g="evade",kind="Cosmetic",label="Blue Faded Cape",image="rbxassetid://595695917"},{id="Cosmetic/BlueNeonShades",g="evade",kind="Cosmetic",label="Blue Neon Shades",image="rbxassetid://8058084568"},{id="Cosmetic/BoboFriend",g="evade",kind="Cosmetic",label="Mini Bobo",image="rbxassetid://6043896316"},{id="Cosmetic/BoxedBobo",g="evade",kind="Cosmetic",label="Boxed Bobo",image="rbxassetid://11747561857"},{id="Cosmetic/BoxedElectricizer",g="evade",kind="Cosmetic",label="Boxed Electricizer",image="rbxassetid://11747561263"},{id="Cosmetic/BoxedSlinger",g="evade",kind="Cosmetic",label="Boxed Slinger",image="rbxassetid://11736636027"},{id="Cosmetic/BoxedVulcan",g="evade",kind="Cosmetic",label="Boxed Vulcan",image="http://www.roblox.com/asset/?id=11749043972"},{id="Cosmetic/Chained",g="evade",kind="Cosmetic",label="Chained",image=""},{id="Cosmetic/Chainsaw",g="evade",kind="Cosmetic",label="Chainsaw",image=""},{id="Cosmetic/Conductor",g="evade",kind="Cosmetic",label="Conductor's Cap",image=""},{id="Cosmetic/DigitalBeeFriends",g="evade",kind="Cosmetic",label="Digital Bee Friends",image=""},{id="Cosmetic/EggToast",g="evade",kind="Cosmetic",label="Egg on Toast",image=""},{id="Cosmetic/EnergySword",g="evade",kind="Cosmetic",label="Energy Sword",image="http://www.roblox.com/asset/?id=10743649831"},{id="Cosmetic/ExoHelmet",g="evade",kind="Cosmetic",label="ExoHelmet",image=""},{id="Cosmetic/Glyph",g="evade",kind="Cosmetic",label="Glyph",image=""},{id="Cosmetic/GreenFadedCape",g="evade",kind="Cosmetic",label="Green Faded Cape",image="rbxassetid://595695917"},{id="Cosmetic/Headset",g="evade",kind="Cosmetic",label="Headset",image=""},{id="Cosmetic/JardFriend",g="evade",kind="Cosmetic",label="Mini Jard",image="rbxassetid://6043896316"},{id="Cosmetic/KrustyHat",g="evade",kind="Cosmetic",label="Krusty Hat",image="rbxassetid://3792182290"},{id="Cosmetic/Milkman",g="evade",kind="Cosmetic",label="Milkman",image=""},{id="Cosmetic/OldBarrel",g="evade",kind="Cosmetic",label="Old Barrel",image=""},{id="Cosmetic/OrangeHeadphones",g="evade",kind="Cosmetic",label="Orange Headphones",image=""},{id="Cosmetic/OrangeSnowboard",g="evade",kind="Cosmetic",label="Orange Snowboard",image="rbxassetid://11635748697"},{id="Cosmetic/PlaidHat",g="evade",kind="Cosmetic",label="Plaid Hat",image=""},{id="Cosmetic/PuddingHat",g="evade",kind="Cosmetic",label="Pudding Hat",image=""},{id="Cosmetic/PurpleSnowboard",g="evade",kind="Cosmetic",label="Purple Snowboard",image="rbxassetid://11635740207"},{id="Cosmetic/RedFadedCape",g="evade",kind="Cosmetic",label="Red Faded Cape",image="rbxassetid://595695917"},{id="Cosmetic/RoastedChicken",g="evade",kind="Cosmetic",label="Roasted Chicken",image=""},{id="Cosmetic/Technician",g="evade",kind="Cosmetic",label="Orange Neon Shades",image="rbxassetid://516107903"},{id="Cosmetic/Wings",g="evade",kind="Cosmetic",label="Purified Wings",image=""},{id="Cosmetic/BlastPack",g="evade",kind="Cosmetic",label="Blast Pack",image="http://www.roblox.com/asset/?id=15062093333"},{id="Cosmetic/DemonSword",g="evade",kind="Cosmetic",label="Demon Sword",image="rbxassetid://9643361666"},{id="Cosmetic/TurboThruster",g="evade",kind="Cosmetic",label="Turbo Thruster",image="http://www.roblox.com/asset/?id=13846791767"},{id="Unusual/PrismaticRadiance",g="evade",kind="Unusual",label="Prismatic Radiance",image="rbxassetid://11371838660"},{id="Unusual/DarkStar",g="evade",kind="Unusual",label="Dark Star",image="rbxassetid://11371829447"},{id="Unusual/IgneousGeyser",g="evade",kind="Unusual",label="Igneous Geyser",image="rbxassetid://11371841768"},{id="Unusual/BlueAbduction",g="evade",kind="Unusual",label="Blue Abduction",image="rbxassetid://11007448825"},{id="Unusual/AstralNebula",g="evade",kind="Unusual",label="Astral Nebula",image="rbxassetid://11007450598"},{id="Unusual/IrradiatingHalo",g="evade",kind="Unusual",label="Irradiating Halo",image="rbxassetid://11371832975"},{id="Unusual/ParticulateIridescence",g="evade",kind="Unusual",label="Particulate Iridescence",image="rbxassetid://11371893137"},{id="Unusual/CharmingHearts",g="evade",kind="Unusual",label="Charming Heart",image="rbxassetid://11007464164"},{id="Unusual/EnergizedRed",g="evade",kind="Unusual",label="Red Energized",image="rbxassetid://11371834157"},{id="Unusual/RoseateGeyser",g="evade",kind="Unusual",label="Roseate Geyser",image="rbxassetid://11371842314"},{id="Unusual/CosmicVortex",g="evade",kind="Unusual",label="Cosmic Vortex",image="rbxassetid://11371896369"},{id="Unusual/ThunderingStorm",g="evade",kind="Unusual",label="Thundering Storm",image="rbxassetid://11007335671"},{id="Unusual/NightLights",g="evade",kind="Unusual",label="Night Lights",image="rbxassetid://11007519937"},{id="Unusual/EnergizedPurple",g="evade",kind="Unusual",label="Purple Energized",image="rbxassetid://11371837893"},{id="Unusual/ShiningSparkles",g="evade",kind="Unusual",label="Shining Sparkles",image="rbxassetid://11007440142"},{id="Unusual/RedAbduction",g="evade",kind="Unusual",label="Red Abduction",image="rbxassetid://11007505404"},{id="Unusual/Voltaic",g="evade",kind="Unusual",label="Voltaic",image="rbxassetid://11007442073"},{id="Unusual/AutumnLeaves",g="evade",kind="Unusual",label="Autumn Leaves",image="rbxassetid://11007589084"},{id="Unusual/Haha",g="evade",kind="Unusual",label="Haha",image="rbxassetid://11007331344"},{id="Unusual/GreenAbduction",g="evade",kind="Unusual",label="Green Abduction",image="rbxassetid://11007491209"},{id="Unusual/FloweringPetals",g="evade",kind="Unusual",label="Flowering Petals",image="rbxassetid://11007333606"},{id="Unusual/FireHorns",g="evade",kind="Unusual",label="Fire Horns",image="rbxassetid://11007522362"},{id="Unusual/Electrified",g="evade",kind="Unusual",label="Electrified",image="rbxassetid://11007515712"},{id="Unusual/CursedHorns",g="evade",kind="Unusual",label="Cursed Horns",image="rbxassetid://11007502623"},{id="Unusual/PrismaticGeyser",g="evade",kind="Unusual",label="Prismatic Geyser",image="rbxassetid://11371836890"},{id="Unusual/RoaringSingularity",g="evade",kind="Unusual",label="Roaring Singularity",image="rbxassetid://18226793990"},{id="Unusual/ColossalFlashes",g="evade",kind="Unusual",label="Colossal Flashes",image="rbxassetid://15281525354"},{id="Unusual/DizzyStars",g="evade",kind="Unusual",label="Dizzy Stars",image="rbxassetid://15281525844"},{id="Unusual/Refractions",g="evade",kind="Unusual",label="Refractions",image="rbxassetid://15281526067"},{id="Unusual/Timewarp",g="evade",kind="Unusual",label="Timewarp",image="rbxassetid://15281526251"},{id="Unusual/ByteFracture",g="evade",kind="Unusual",label="Byte Fracture",image="rbxassetid://15281526548"},{id="Unusual/BinaryBeams",g="evade",kind="Unusual",label="Binary Beams",image="rbxassetid://15281524645"},{id="Unusual/AmethystEnergy",g="evade",kind="Unusual",label="Amethyst Energy",image="rbxassetid://15281524314"},{id="Unusual/LunarLight",g="evade",kind="Unusual",label="Lunar Light",image="rbxassetid://15281559265"},{id="Unusual/VioletNocturne",g="evade",kind="Unusual",label="Violet Nocturne",image="rbxassetid://15281559486"},{id="Unusual/HowliteMaelstrom",g="evade",kind="Unusual",label="Howlite Maelstrom",image="rbxassetid://15281558802"},{id="Unusual/ScarletMaelstrom",g="evade",kind="Unusual",label="Scarlet Maelstrom",image="rbxassetid://15281559063"},{id="Unusual/AzureMaelstrom",g="evade",kind="Unusual",label="Azure Maelstrom",image="rbxassetid://15281558617"},{id="Unusual/CosmicHalo",g="evade",kind="Unusual",label="Cosmic Halo",image="rbxassetid://15281525606"},{id="Unusual/CollapsingSingularity",g="evade",kind="Unusual",label="Collapsing Singularity",image="rbxassetid://18226794493"},{id="Unusual/EctoplasmicStar",g="evade",kind="Unusual",label="Ectoplasmic Star",image="rbxassetid://15330231393"},{id="Unusual/AustralisNebula",g="evade",kind="Unusual",label="Australis Nebula",image="rbxassetid://15332670165"},{id="Unusual/BorealisNebula",g="evade",kind="Unusual",label="Borealis Nebula",image="rbxassetid://15332670525"},{id="Unusual/ShimmeringParadise",g="evade",kind="Unusual",label="Shimmering Paradise",image="rbxassetid://15332669124"},{id="Unusual/LavenderUtopia",g="evade",kind="Unusual",label="Lavender Utopia",image="rbxassetid://15332669649"},{id="Unusual/HalleysComet",g="evade",kind="Unusual",label="Halley's Comet",image="rbxassetid://16381516740"},{id="Unusual/Bubbly",g="evade",kind="Unusual",label="Bubbly",image="rbxassetid://15330230743"},{id="Unusual/TimeKeeper",g="evade",kind="Unusual",label="Time Keeper",image="rbxassetid://138871601023661"},{id="Unusual/PurpleEMP",g="evade",kind="Unusual",label="Purple EMP",image="rbxassetid://112966779401533"},{id="Unusual/OrangeEMP",g="evade",kind="Unusual",label="Orange EMP",image="rbxassetid://101243983312796"},{id="Unusual/MorningButterflies",g="evade",kind="Unusual",label="Morning Butterflies",image="rbxassetid://135339199382899"},{id="Unusual/MoonlightButterflies",g="evade",kind="Unusual",label="Moonlight Butterflies",image="rbxassetid://139303086452755"},{id="Unusual/EclipseButterflies",g="evade",kind="Unusual",label="Eclipse Butterflies",image="rbxassetid://76057239086215"},{id="Unusual/ShiftingParadigm",g="evade",kind="Unusual",label="Shifting Paradigm",image="rbxassetid://120583500421161"},{id="Unusual/PinkStarEruption",g="evade",kind="Unusual",label="Pink Star Eruption",image="rbxassetid://91724644834923"},{id="Unusual/OrangeStarEruption",g="evade",kind="Unusual",label="Orange Star Eruption",image="rbxassetid://111642115077366"},{id="Unusual/HeadphoneResonance",g="evade",kind="Unusual",label="Headphone Resonance",image="rbxassetid://108135161456588"},{id="Unusual/BlueStarEruption",g="evade",kind="Unusual",label="Blue Star Eruption",image="rbxassetid://85662712339382"},{id="Unusual/AbyssalRapture",g="evade",kind="Unusual",label="Abyssal Rapture",image="rbxassetid://114907099719126"},{id="Unusual/Absorption",g="evade",kind="Unusual",label="Absorption",image="rbxassetid://10762641231"},{id="Unusual/BoboVortex",g="evade",kind="Unusual",label="Vortex of Bobos",image="rbxassetid://11116252268"},{id="Cosmetic/EliteHelmet",g="evade",kind="Cosmetic",label="Elite Helmet",image=""},{id="Cosmetic/Glow",g="evade",kind="Cosmetic",label="Glow",image=""},{id="Cosmetic/GlowSolid",g="evade",kind="Cosmetic",label="Glow Solid",image=""},{id="Cosmetic/Grunt",g="evade",kind="Cosmetic",label="Grunt",image="rbxassetid://15426725522"},{id="Unusual/NuclearDoom",g="evade",kind="Unusual",label="Nuclear Doom",image="rbxassetid://10762381639"},{id="Unusual/CirclingBeams",g="evade",kind="Unusual",label="Circling Beams",image="rbxassetid://16055904290"},{id="Cosmetic/BlackCape",g="evade",kind="Cosmetic",label="Black Cape",image=""},{id="Cosmetic/WhiteCape",g="evade",kind="Cosmetic",label="White Cape",image=""},{id="Cosmetic/BlueCape",g="evade",kind="Cosmetic",label="Blue Cape",image=""},{id="Cosmetic/RedCape",g="evade",kind="Cosmetic",label="Red Cape",image=""},{id="Unusual/LOLCATZ",g="evade",kind="Unusual",label="LOL CATZ",image="rbxassetid://15426458068"},{id="Unusual/2023Celebration",g="evade",kind="Unusual",label="2023 Celebration",image="rbxassetid://11981547226"},{id="Cosmetic/OneBillionReward",g="evade",kind="Cosmetic",label="1B Celebration",image="http://www.roblox.com/asset/?id=241685484"},{id="Cosmetic/OverhaulHat",g="evade",kind="Cosmetic",label="Overhaul Hat",image="rbxassetid://115661027359355"},{id="Unusual/Party",g="evade",kind="Unusual",label="Party",image="http://www.roblox.com/asset/?id=241685484"},{id="Unusual/AlphaTester",g="evade",kind="Unusual",label="Alpha Tester",image="rbxassetid://83681447045862"},{id="Unusual/CCHaze",g="evade",kind="Unusual",label="Content Creator Haze",image="rbxassetid://17885254022"},{id="Cosmetic/Default",g="evade",kind="Cosmetic",label="Default",image="rbxassetid://15039682906"},{id="Unusual/DonationVictorian",g="evade",kind="Unusual",label="Donation Victorian",image="rbxassetid://17885253007"},{id="Unusual/GlowingHaze",g="evade",kind="Unusual",label="Glowing Haze",image="rbxassetid://17885254538"},{id="Unusual/LevelVictorian",g="evade",kind="Unusual",label="Experienced Victorian",image="rbxassetid://17885251312"},{id="Unusual/SurvivalVictorian",g="evade",kind="Unusual",label="Survival Victorian",image="rbxassetid://17885252036"},{id="Cosmetic/TweetReward",g="evade",kind="Cosmetic",label="Bird Badge",image="rbxassetid://1324431872"},{id="Cosmetic/BlazingCandle",g="evade",kind="Cosmetic",label="Blazing Candle",image="http://www.roblox.com/asset/?id=291880914"},{id="Unusual/2AnniversaryHat",g="evade",kind="Unusual",label="2nd Anniversary Hat",image="rbxassetid://18792905069"},{id="Unusual/CirclingEclipseCola",g="evade",kind="Unusual",label="Circling Eclipse Cola",image="rbxassetid://12993740584"},{id="Unusual/CirclingCatJard",g="evade",kind="Unusual",label="Circling Cat Jard",image="rbxassetid://12993740584"},{id="Unusual/CirclingCatPufferfish",g="evade",kind="Unusual",label="Circling Cat Pufferfish",image="rbxassetid://108841332189641"},{id="Unusual/FallingStar",g="evade",kind="Unusual",label="Falling Star",image="rbxassetid://97846690813225"},{id="Unusual/FlameWreath",g="evade",kind="Unusual",label="Flame Wreath",image="rbxassetid://138212246167996"},{id="Unusual/SelenesGrace",g="evade",kind="Unusual",label="Selene's Grace",image="rbxassetid://137618753380511"},{id="Unusual/VoidStar",g="evade",kind="Unusual",label="Void Star",image="rbxassetid://101980586701695"},{id="Unusual/ButterflyOrchid",g="evade",kind="Unusual",label="Butterfly Orchid",image="rbxassetid://84200247312644"},{id="Unusual/ButterflyEclipse",g="evade",kind="Unusual",label="Butterfly Eclipse",image="rbxassetid://111031793665530"},{id="Unusual/ButterflyCrimson",g="evade",kind="Unusual",label="Butterfly Crimson",image="rbxassetid://87647249329845"},{id="Unusual/ButterflyAzure",g="evade",kind="Unusual",label="Butterfly Azure",image="rbxassetid://122727820994212"},{id="Unusual/BoltSkaters",g="evade",kind="Unusual",label="Bolt Skaters",image="rbxassetid://107453486910454"},{id="Unusual/EclipseNova",g="evade",kind="Unusual",label="Eclipse Nova",image="rbxassetid://119573933912128"},{id="Unusual/DoggoAura",g="evade",kind="Unusual",label="Doggo Aura",image="rbxassetid://71000477513248"},{id="Unusual/CatRadiance",g="evade",kind="Unusual",label="Cat Radiance",image="rbxassetid://113487941303989"},{id="Unusual/AnimalAura",g="evade",kind="Unusual",label="Animal Aura",image="rbxassetid://97257795606364"},{id="Unusual/Technotic",g="evade",kind="Unusual",label="Technotic",image="rbxassetid://15330230247"},{id="Unusual/PrismaticWhispers",g="evade",kind="Unusual",label="Prismastic Whispers",image="rbxassetid://124588689494430"},{id="Unusual/ChaoticRadiance",g="evade",kind="Unusual",label="Chaotic Radiance",image="rbxassetid://70646476497424"},{id="Unusual/KoiPond",g="evade",kind="Unusual",label="Koi Pond",image="rbxassetid://82752178121149"},{id="Cosmetic/KingOfTheNight",g="evade",kind="Cosmetic",label="King Of The Moon",image="rbxassetid://109985324958700"},{id="Cosmetic/KingOfTheMoon",g="evade",kind="Cosmetic",label="King Of The Moon",image="rbxassetid://109985324958700"},{id="Cosmetic/SkullOfFrost",g="evade",kind="Cosmetic",label="Skull Of Frost",image="rbxassetid://112204114961537"},{id="Cosmetic/SkullOfInferno",g="evade",kind="Cosmetic",label="Skull Of Inferno",image="rbxassetid://112204114961537"},{id="Unusual/HornsOfToxicity",g="evade",kind="Unusual",label="Horns Of Toxicity",image="rbxassetid://110110350075471"},{id="Unusual/HornsOfInferno",g="evade",kind="Unusual",label="Horns Of Inferno",image="rbxassetid://113617200475980"},{id="Unusual/HornsOfFrost",g="evade",kind="Unusual",label="Horns Of Frost",image="rbxassetid://82004430032231"},{id="Cosmetic/GildedValkyrie",g="evade",kind="Cosmetic",label="Gilded Valkyrie",image="rbxassetid://17510992903"},{id="Cosmetic/Ghosdeeri",g="evade",kind="Cosmetic",label="Ghosdeeri",image="rbxassetid://15011464541"},{id="Cosmetic/DualEtherealSwords",g="evade",kind="Cosmetic",label="Dual Ethereal Swords",image="rbxassetid://72216936161912"},{id="Cosmetic/SilveryCrown",g="evade",kind="Cosmetic",label="Silvery Crown",image="rbxassetid://107682251407543"},{id="Cosmetic/FederationCrown",g="evade",kind="Cosmetic",label="Federation Crown",image="rbxassetid://129365772874252"},{id="Cosmetic/CoinEyes",g="evade",kind="Cosmetic",label="Coin Eyes",image="rbxassetid://12324843445"},{id="Unusual/OozingMoney",g="evade",kind="Unusual",label="Oozing Money",image="rbxassetid://12816281237"},{id="Cosmetic/FourCloverPin",g="evade",kind="Cosmetic",label="Four Clover Pin",image="rbxassetid://12689982957"},{id="Cosmetic/CharmLantern",g="evade",kind="Cosmetic",label="Charm Lantern",image="rbxassetid://12178157972"},{id="Unusual/Thermocline",g="evade",kind="Unusual",label="Thermocline",image="rbxassetid://12492024449"},{id="Unusual/EncapsulatedBarbedWires",g="evade",kind="Unusual",label="Encapsulated Barbed Wires",image="rbxassetid://12492024319"},{id="Unusual/BeeShield",g="evade",kind="Unusual",label="Bee Shield",image="rbxassetid://92583363584950"},{id="Unusual/CapeOfPoseidon",g="evade",kind="Unusual",label="Cape Of Poseidon",image="rbxassetid://123342745981242"},{id="Unusual/AuroranBunnyEars",g="evade",kind="Unusual",label="Auroran Bunny Ears",image="rbxassetid://77912379935869"},{id="Unusual/CarrotBunnyEars",g="evade",kind="Unusual",label="Carrot Bunny Ears",image="rbxassetid://100915538026509"},{id="Unusual/LunarFortune",g="evade",kind="Unusual",label="Lunar Fortune",image="rbxassetid://106726775566810"},{id="Cosmetic/MedallionLantern",g="evade",kind="Cosmetic",label="Medallion Lantern",image="rbxassetid://14049993216"},{id="Unusual/NewYearRays",g="evade",kind="Unusual",label="New Year Rays",image="rbxassetid://75041051920569"},{id="Cosmetic/FireworkPack",g="evade",kind="Cosmetic",label="Firework Pack",image="rbxassetid://14124153904"},{id="Unusual/SpawnHalo",g="evade",kind="Unusual",label="Spawn Halo",image="rbxassetid://126411772146887"},{id="Unusual/RingOfFireHalo",g="evade",kind="Unusual",label="Ring of Fire Halo",image="rbxassetid://83016554141159"},{id="Unusual/Tixsplosion",g="evade",kind="Unusual",label="Tixsplosion",image="rbxassetid://88222779054366"},{id="Unusual/FieryCandle",g="evade",kind="Unusual",label="Fiery Candle",image="rbxassetid://92736922434350"},{id="Unusual/AnniversaryFireworks",g="evade",kind="Unusual",label="Anniversary Fireworks",image="rbxassetid://121533477626515"},{id="Cosmetic/KugelblitzRing",g="evade",kind="Cosmetic",label="Kugelblitz Ring",image="rbxassetid://5101923607"},{id="Cosmetic/KugelblitzHorizon",g="evade",kind="Cosmetic",label="Kugelblitz Horizon",image="rbxassetid://5101923607"},{id="Cosmetic/Infection",g="evade",kind="Cosmetic",label="Infection",image="http://www.roblox.com/asset/?id=85005758"},{id="Cosmetic/AvarianStaff",g="evade",kind="Cosmetic",label="Avarian Staff",image="rbxassetid://516107903"},{id="Cosmetic/OverlordSet",g="evade",kind="Cosmetic",label="Overlord Set",image="rbxassetid://13414392494"},{id="Cosmetic/ArchangelWings",g="evade",kind="Cosmetic",label="Archangel Wings",image="rbxassetid://6267211748"},{id="Unusual/VoidCorruption",g="evade",kind="Unusual",label="Void Corruption",image="rbxassetid://89801516113872"},{id="Cosmetic/Tombstone",g="evade",kind="Cosmetic",label="Tombstone",image=""},{id="Cosmetic/DemonHorns",g="evade",kind="Cosmetic",label="Demon Horns",image=""},{id="Cosmetic/Candlehead",g="evade",kind="Cosmetic",label="Candlehead",image="rbxassetid://5598180738"},{id="Cosmetic/BatAttack",g="evade",kind="Cosmetic",label="Bat Attack",image=""},{id="Cosmetic/Baghead",g="evade",kind="Cosmetic",label="Baghead",image="rbxassetid://11138654810"},{id="Unusual/CursedEye",g="evade",kind="Unusual",label="Cursed Eye",image="rbxassetid://11353302964"},{id="Cosmetic/PinkUFOAbduction",g="evade",kind="Cosmetic",label="Pink UFO Abduction",image="rbxassetid://1084976679"},{id="Cosmetic/Cauldronhead",g="evade",kind="Cosmetic",label="Cauldronhead",image="rbxassetid://1084987899"},{id="Cosmetic/BlueUFOAbduction",g="evade",kind="Cosmetic",label="Blue UFO Abduction",image="rbxassetid://1084976679"},{id="Unusual/HauntedIridescence",g="evade",kind="Unusual",label="Haunted Iridescence",image="rbxassetid://11353371106"},{id="Cosmetic/EyeCorruption",g="evade",kind="Cosmetic",label="Eye Corruption",image=""},{id="Cosmetic/HellishGrip",g="evade",kind="Cosmetic",label="Hellish Grip",image="rbxassetid://11112230045"},{id="Cosmetic/GhostFriend",g="evade",kind="Cosmetic",label="Ghost Friend",image="rbxassetid://8928882451"},{id="Unusual/DarkTendrils",g="evade",kind="Unusual",label="Dark Tendrils",image="rbxassetid://11353368350"},{id="Cosmetic/DragonSkull",g="evade",kind="Cosmetic",label="Dragon Skull",image=""},{id="Cosmetic/MechanicalScythe",g="evade",kind="Cosmetic",label="Mechanical Scythe",image="http://www.roblox.com/asset/?id=11118529801"},{id="Cosmetic/GoldTicket",g="evade",kind="Cosmetic",label="Gold Ticket",image="rbxassetid://1084975295"},{id="Cosmetic/OrangeTicket",g="evade",kind="Cosmetic",label="Orange Ticket",image="http://www.roblox.com/asset/?id=298984512"},{id="Cosmetic/RedTicket",g="evade",kind="Cosmetic",label="Red Ticket",image=""},{id="Cosmetic/CarvedPumpkinHead",g="evade",kind="Cosmetic",label="Carved Pumpkin Head",image="rbxassetid://11193989374"},{id="Unusual/HallowedSpecters",g="evade",kind="Unusual",label="Hallowed Specters",image="rbxassetid://10642208994"},{id="Cosmetic/AmethystStaff",g="evade",kind="Cosmetic",label="Amethyst Staff",image=""},{id="Cosmetic/PhantomBlades",g="evade",kind="Cosmetic",label="Phantom Blades",image=""},{id="Unusual/HellfirePortal",g="evade",kind="Unusual",label="Hellfire Portal",image="rbxassetid://11353367353"},{id="Unusual/BluefirePortal",g="evade",kind="Unusual",label="Bluefire Portal",image="rbxassetid://11353470385"},{id="Cosmetic/WretchedWings",g="evade",kind="Cosmetic",label="Wretched Wings",image="rbxassetid://11116357700"},{id="Cosmetic/Monoculi",g="evade",kind="Cosmetic",label="Monoculi",image=""},{id="Cosmetic/GhostAbduction",g="evade",kind="Cosmetic",label="Ghost Abduction",image=""},{id="Unusual/IllusionEyes",g="evade",kind="Unusual",label="Eye Illusions",image="rbxassetid://11353472646"},{id="Cosmetic/Frankenstein",g="evade",kind="Cosmetic",label="Frankenstein",image="rbxassetid://11313994323"},{id="Cosmetic/ElectrifyingGuitar",g="evade",kind="Cosmetic",label="Electrifying Guitar",image="http://www.roblox.com/asset/?id=71553365"},{id="Cosmetic/BananaSuit",g="evade",kind="Cosmetic",label="Banana Suit",image="rbxassetid://11328700838"},{id="Cosmetic/AlchemistBelt",g="evade",kind="Cosmetic",label="Alchemist Belt",image="rbxassetid://1084976679"},{id="Unusual/BloodMoon",g="evade",kind="Unusual",label="Blood Moon",image="rbxassetid://11353372060"},{id="Unusual/ToxicInferno",g="evade",kind="Unusual",label="Toxic Inferno",image="rbxassetid://11353407906"},{id="Cosmetic/GreenHallowedFace",g="evade",kind="Cosmetic",label="Green Hallowed Face",image=""},{id="Cosmetic/OrangeHallowedFace",g="evade",kind="Cosmetic",label="Orange Hallowed Face",image=""},{id="Cosmetic/BlueHallowedFace",g="evade",kind="Cosmetic",label="Blue Hallowed Face",image=""},{id="Cosmetic/FungalOvergrowth",g="evade",kind="Cosmetic",label="Fungal Overgrowth",image=""},{id="Cosmetic/DemonWings",g="evade",kind="Cosmetic",label="Demon Wings",image=""},{id="Unusual/OminousDemise",g="evade",kind="Unusual",label="Ominous Demise",image="rbxassetid://11353369618"},{id="Cosmetic/DualBoneSwords",g="evade",kind="Cosmetic",label="Dual Bone Swords",image=""},{id="Cosmetic/VampireOutfit",g="evade",kind="Cosmetic",label="Vampire Outfit",image=""},{id="Cosmetic/ImpaledHead",g="evade",kind="Cosmetic",label="Impaled Head",image=""},{id="Cosmetic/SpiderInfestation",g="evade",kind="Cosmetic",label="Spider Infestation",image=""},{id="Cosmetic/WitchHat",g="evade",kind="Cosmetic",label="Witch Hat",image="rbxassetid://11137829541"},{id="Unusual/MintyExplosion",g="evade",kind="Unusual",label="Minty Explosion",image="rbxassetid://11916773394"},{id="Cosmetic/SantaHat",g="evade",kind="Cosmetic",label="Santa Hat",image="rbxassetid://11605377637"},{id="Cosmetic/Snowflakes",g="evade",kind="Cosmetic",label="Snowflakes",image=""},{id="Cosmetic/FestiveHeadband",g="evade",kind="Cosmetic",label="Festive Headband",image="rbxassetid://11548362763"},{id="Cosmetic/CozyScarf",g="evade",kind="Cosmetic",label="Cozy Scarf",image="rbxassetid://11736328539"},{id="Unusual/BlizzardyStorm",g="evade",kind="Unusual",label="Blizzardy Storm",image="rbxassetid://11916778459"},{id="Unusual/FrostFlame",g="evade",kind="Unusual",label="Frost Flame",image="rbxassetid://11916774023"},{id="Cosmetic/VintageHat",g="evade",kind="Cosmetic",label="Vintage Hat",image=""},{id="Cosmetic/BackpackGift",g="evade",kind="Cosmetic",label="Backpack Gift",image="rbxassetid://11591699783"},{id="Unusual/GlowingTree",g="evade",kind="Unusual",label="Glowing Tree",image="rbxassetid://11916769135"},{id="Cosmetic/XMasTreeHat",g="evade",kind="Cosmetic",label="Xmas Tree Hat",image=""},{id="Cosmetic/CaneDaggers",g="evade",kind="Cosmetic",label="Cane Daggers",image="rbxassetid://11735455322"},{id="Cosmetic/SnowmanHead",g="evade",kind="Cosmetic",label="Snowman Head",image="rbxassetid://11703528168"},{id="Cosmetic/CandyCaneShotgun",g="evade",kind="Cosmetic",label="Candy Cane Shotgun",image="rbxassetid://11715740340"},{id="Cosmetic/PortableChimney",g="evade",kind="Cosmetic",label="Portable Chimney",image="rbxassetid://11481019804"},{id="Unusual/ShimmeringCoronet",g="evade",kind="Unusual",label="Shimmering Coronet",image="rbxassetid://11916780549"},{id="Unusual/SuspendedLights",g="evade",kind="Unusual",label="Suspended Lights",image="rbxassetid://11916780026"},{id="Cosmetic/FestiveAntlers",g="evade",kind="Cosmetic",label="Festive Antlers",image="rbxassetid://11548367886"},{id="Cosmetic/HangingMistletoe",g="evade",kind="Cosmetic",label="Hanging Mistletoe",image="http://www.roblox.com/asset/?id=11761477571"},{id="Cosmetic/BoboSnowmanPal",g="evade",kind="Cosmetic",label="Bobo Snowman Pal",image=""},{id="Cosmetic/MelodicalHarp",g="evade",kind="Cosmetic",label="Melodical Harp",image=""},{id="Cosmetic/JollyScythe",g="evade",kind="Cosmetic",label="Jolly Scythe",image=""},{id="Unusual/WinterChains",g="evade",kind="Unusual",label="Winter Chains",image="rbxassetid://11916779030"},{id="Cosmetic/GlaciusSet",g="evade",kind="Cosmetic",label="Glacius Set",image="rbxasset://textures/particles/explosion01_implosion_main.dds"},{id="Cosmetic/BackCrank",g="evade",kind="Cosmetic",label="Back Crank",image="rbxassetid://11705977614"},{id="Unusual/AngelicRedemption",g="evade",kind="Unusual",label="Angelic Redemption",image="rbxassetid://11916852423"},{id="Unusual/FrigidPerception",g="evade",kind="Unusual",label="Frigid Perception",image="rbxassetid://11916781787"},{id="Unusual/SubzeroBurst",g="evade",kind="Unusual",label="Subzero Burst",image="rbxassetid://11916781171"},{id="Cosmetic/GingerbreadGuards",g="evade",kind="Cosmetic",label="Gingerbread Guards",image="rbxassetid://6047637442"},{id="Cosmetic/CandyConfetti",g="evade",kind="Cosmetic",label="Candy Confetti",image="rbxassetid://11819505553"},{id="Cosmetic/SockStocking",g="evade",kind="Cosmetic",label="Sock Stocking",image=""},{id="Unusual/XmasBurst",g="evade",kind="Unusual",label="Xmas Burst",image="rbxassetid://11916771701"},{id="Unusual/GlacialOutburst",g="evade",kind="Unusual",label="Glacial Outburst",image="rbxassetid://11916865929"},{id="Cosmetic/CarrotNose",g="evade",kind="Cosmetic",label="Carrot Nose",image="http://www.roblox.com/asset/?id=11687235757"},{id="Cosmetic/SantasSpecter",g="evade",kind="Cosmetic",label="Santa's Specter",image=""},{id="Cosmetic/OrnamentBandolier",g="evade",kind="Cosmetic",label="Ornament Bandolier",image="rbxassetid://11715229201"},{id="Cosmetic/CandyFlintlock",g="evade",kind="Cosmetic",label="Candy Flintlock",image="rbxassetid://11782663631"},{id="Cosmetic/BackMenorah",g="evade",kind="Cosmetic",label="Back Menorah",image="http://www.roblox.com/asset/?id=242461088"},{id="Cosmetic/GiftPair",g="evade",kind="Cosmetic",label="Gift Pair",image="http://www.roblox.com/asset/?id=298984512"},{id="Cosmetic/GreenGift",g="evade",kind="Cosmetic",label="Green Gift",image="http://www.roblox.com/asset/?id=298984512"},{id="Cosmetic/GiftStack",g="evade",kind="Cosmetic",label="Gift Stack",image="http://www.roblox.com/asset/?id=298984512"},{id="Unusual/KhanOfWinter",g="evade",kind="Unusual",label="Khan of Winter",image="rbxassetid://11916772337"},{id="Cosmetic/SantaSuit",g="evade",kind="Cosmetic",label="Santa Suit",image="rbxassetid://11716016338"},{id="Cosmetic/GiftHat",g="evade",kind="Cosmetic",label="Gift Hat",image="http://www.roblox.com/asset/?id=11809676234"},{id="Cosmetic/GiftSack",g="evade",kind="Cosmetic",label="Gift Sack",image="rbxassetid://11620087801"},{id="Unusual/AuroraBorealis",g="evade",kind="Unusual",label="Aurora Borealis",image="rbxassetid://11916768467"},{id="Cosmetic/PermafrostStaff",g="evade",kind="Cosmetic",label="Permafrost Staff",image="rbxassetid://11313855052"},{id="Cosmetic/GildedJetpack",g="evade",kind="Cosmetic",label="Gilded Jetpack",image="rbxasset://textures/particles/smoke_main.dds"},{id="Cosmetic/DualCandyCanes",g="evade",kind="Cosmetic",label="Dual Candy Canes",image="rbxassetid://11660119756"},{id="Cosmetic/NorthPoleSign",g="evade",kind="Cosmetic",label="North Pole Sign",image="rbxassetid://11809539944"},{id="Cosmetic/Wreath",g="evade",kind="Cosmetic",label="Wreath",image="rbxassetid://11660119756"},{id="Cosmetic/HoverTrain",g="evade",kind="Cosmetic",label="Hover Train",image="rbxassetid://1237803088"},{id="Cosmetic/HollyBerryInfection",g="evade",kind="Cosmetic",label="Holly Berry Infection",image="rbxassetid://11808738520"},{id="Cosmetic/GrinchMask",g="evade",kind="Cosmetic",label="Grinch Mask",image="rbxassetid://11809198448"},{id="Cosmetic/GiftSled",g="evade",kind="Cosmetic",label="Gift Sled",image="http://www.roblox.com/asset/?id=11680917831"},{id="Unusual/AuroranStag",g="evade",kind="Unusual",label="Auroran Stag",image="rbxassetid://11916775812"},{id="Unusual/VerdantStag",g="evade",kind="Unusual",label="Verdant Stag",image="rbxassetid://11916776667"},{id="Unusual/GildedStag",g="evade",kind="Unusual",label="Gilded Stag",image="rbxassetid://11916774995"},{id="Cosmetic/OrnamentHook",g="evade",kind="Cosmetic",label="Ornament Hook",image=""},{id="Cosmetic/BlueWindbreaker",g="evade",kind="Cosmetic",label="Blue Windbreaker",image="rbxassetid://11719698683"},{id="Cosmetic/CandyCrown",g="evade",kind="Cosmetic",label="Candy Crown",image="http://www.roblox.com/asset/?id=11739661332"},{id="Cosmetic/SatchelOfNoobs",g="evade",kind="Cosmetic",label="Satchel of Noobs",image="rbxassetid://11473814524"},{id="Cosmetic/ChainedCoffin",g="evade",kind="Cosmetic",label="Chained Coffin",image="rbxassetid://10523242807"},{id="Unusual/ScarletSlash",g="evade",kind="Unusual",label="Scarlet Slash",image="rbxassetid://15230292120"},{id="Unusual/SoulSnatcher",g="evade",kind="Unusual",label="Soul Snatcher",image="rbxassetid://15230291936"},{id="Cosmetic/SealedBook",g="evade",kind="Cosmetic",label="Sealed Book",image=""},{id="Cosmetic/ClownButcher",g="evade",kind="Cosmetic",label="Clown Butcher",image="rbxassetid://15081211038"},{id="Cosmetic/DemonHelmet",g="evade",kind="Cosmetic",label="Demon Helmet",image="rbxassetid://100372797168529"},{id="Cosmetic/SoulExtinguisher",g="evade",kind="Cosmetic",label="Soul Extinguisher",image="http://www.roblox.com/asset/?id=4770542473"},{id="Unusual/AzureMistWatcher",g="evade",kind="Unusual",label="Azure Mist Watcher",image="rbxassetid://15230292790"},{id="Unusual/CrimsonMistWatcher",g="evade",kind="Unusual",label="Crimson Mist Watcher",image="rbxassetid://15230292943"},{id="Unusual/NoxiousAura",g="evade",kind="Unusual",label="Noxious Aura",image="rbxassetid://130958590010587"},{id="Cosmetic/PhantomHat",g="evade",kind="Cosmetic",label="Phantom Hat",image=""},{id="Unusual/AbyssalEyes",g="evade",kind="Unusual",label="Abyssal Eyes",image="rbxassetid://120842068158373"},{id="Unusual/DemonIris",g="evade",kind="Unusual",label="Demon Iris",image="rbxassetid://15230308515"},{id="Unusual/HexerIris",g="evade",kind="Unusual",label="Hexer Iris",image="rbxassetid://15230308685"},{id="Unusual/PlaguedIris",g="evade",kind="Unusual",label="Plagued Iris",image="rbxassetid://15230308826"},{id="Cosmetic/MechanicalWitchHat",g="evade",kind="Cosmetic",label="Mechanical Witch Hat",image=""},{id="Unusual/SoulRifter",g="evade",kind="Unusual",label="Soul Rifter",image="rbxassetid://15230309015"},{id="Cosmetic/CalmingMask",g="evade",kind="Cosmetic",label="Calming Mask",image="rbxassetid://15092743612"},{id="Cosmetic/ScarletsStrike",g="evade",kind="Cosmetic",label="Scarlet's Strike",image="rbxassetid://1084999891"},{id="Cosmetic/HeadlessHorsemanHeadtaker",g="evade",kind="Cosmetic",label="Headless Horseman Headtaker",image="rbxassetid://12524470529"},{id="Unusual/RuinousArcana",g="evade",kind="Unusual",label="Ruinous Arcana",image="rbxassetid://15230309211"},{id="Unusual/RunicRitual",g="evade",kind="Unusual",label="Runic Ritual",image="rbxassetid://15230309357"},{id="Unusual/NuclearFuture",g="evade",kind="Unusual",label="Nuclear Future",image="rbxassetid://15230309530"},{id="Cosmetic/BatwingBasher",g="evade",kind="Cosmetic",label="Batwing Basher",image="rbxassetid://8708637750"},{id="Unusual/Vortex",g="evade",kind="Unusual",label="Paranormal Vortex",image="rbxassetid://15230309704"},{id="Unusual/AtomicHeart",g="evade",kind="Unusual",label="Atomic Heart",image="rbxassetid://16371185278"},{id="Cosmetic/CupidMirage",g="evade",kind="Cosmetic",label="Cupid Mirage",image=""},{id="Unusual/EclipseLove",g="evade",kind="Unusual",label="Eclipse Love",image="rbxassetid://16371186145"},{id="Unusual/PureLove",g="evade",kind="Unusual",label="Pure Love",image="rbxassetid://16371186444"},{id="Cosmetic/TeddyInfestation",g="evade",kind="Cosmetic",label="Teddy Infestation",image="rbxassetid://16093046892"},{id="Unusual/CupidsArrow",g="evade",kind="Unusual",label="Cupids Arrow",image="rbxassetid://16371185593"},{id="Cosmetic/ReindeerHood",g="evade",kind="Cosmetic",label="Reindeer Hood",image="rbxassetid://78521326833497"},{id="Cosmetic/XmasTreeSuit",g="evade",kind="Cosmetic",label="Xmas Tree Suit",image="rbxassetid://15330303812"},{id="Unusual/EtherealSaucer",g="evade",kind="Unusual",label="Ethereal Saucer",image="rbxassetid://101457882527178"},{id="Cosmetic/OrnamentalHelmet",g="evade",kind="Cosmetic",label="Ornamental Helmet",image="rbxassetid://111631175711566"},{id="Cosmetic/IceCrown",g="evade",kind="Cosmetic",label="Ice Crown",image="http://www.roblox.com/asset/?id=1084976679"},{id="Unusual/GleamingConstellation",g="evade",kind="Unusual",label="Festive Constellation",image="rbxassetid://90341999892074"},{id="Cosmetic/JollyGuitar",g="evade",kind="Cosmetic",label="Jolly Guitar",image="rbxassetid://13448020277"},{id="Unusual/Candynado",g="evade",kind="Unusual",label="Candynado",image="rbxassetid://95360634713334"},{id="Unusual/Snownado",g="evade",kind="Unusual",label="Snownado",image="rbxassetid://118608431351473"},{id="Cosmetic/TatteredCape",g="evade",kind="Cosmetic",label="Tattered Cape",image="rbxassetid://111630965464413"},{id="Unusual/AuroranTophat",g="evade",kind="Unusual",label="Auroran Tophat",image="rbxassetid://79865900380656"},{id="Unusual/CandyCaneAura",g="evade",kind="Unusual",label="Candy Cane Aura",image="rbxassetid://80811087061395"},{id="Unusual/JollyCrown",g="evade",kind="Unusual",label="Jolly Crown",image="rbxassetid://72135144627200"},{id="Unusual/EclipseCrown",g="evade",kind="Unusual",label="Eclipse Crown",image="rbxassetid://80697798579086"},{id="Unusual/FrigidCrown",g="evade",kind="Unusual",label="Jolly Crown",image="rbxassetid://75807041743117"},{id="Cosmetic/SealPal",g="evade",kind="Cosmetic",label="Seal Pal",image="rbxassetid://137820781191847"},{id="Unusual/OrbitingSerenade",g="evade",kind="Unusual",label="Orbiting Serenade",image="rbxassetid://97988062645095"},{id="Cosmetic/XmasTreeCookie",g="evade",kind="Cosmetic",label="Xmas Tree Cookie",image="rbxassetid://15330303812"},{id="Cosmetic/CatchTheRainbow",g="evade",kind="Cosmetic",label="Catch The Rainbow",image="rbxassetid://11368109749"},{id="Unusual/CloverEssence",g="evade",kind="Unusual",label="Clover Essence",image="rbxassetid://16773279427"},{id="Unusual/LeprechaunsRune",g="evade",kind="Unusual",label="Leprechauns Rune",image="rbxassetid://16773280045"},{id="Cosmetic/LuckySuspenders",g="evade",kind="Cosmetic",label="Lucky Suspenders",image="rbxassetid://9069600131"},{id="Cosmetic/LuckyValkyrie",g="evade",kind="Cosmetic",label="Lucky Valkyrie",image=""},{id="Cosmetic/PotOfGoldPin",g="evade",kind="Cosmetic",label="Pot of Gold Pin",image="rbxassetid://16396381936"},{id="Unusual/StPixels",g="evade",kind="Unusual",label="St. Pixels",image="rbxassetid://16773280324"},{id="Unusual/LuckyStrike",g="evade",kind="Unusual",label="Lucky Strike",image="rbxassetid://16773279772"},{id="Cosmetic/214Vision",g="evade",kind="Cosmetic",label="2-14 Vision",image=""},{id="Unusual/Adoration",g="evade",kind="Unusual",label="Adoration",image="rbxassetid://12483356412"},{id="Unusual/BionicRejuvination",g="evade",kind="Unusual",label="Bionic Rejuvination",image="rbxassetid://12492024832"},{id="Cosmetic/CupidWand",g="evade",kind="Cosmetic",label="Cupid's Wand",image=""},{id="Unusual/Euphoria",g="evade",kind="Unusual",label="Euphoria",image="rbxassetid://12483355967"},{id="Cosmetic/HeartAttack",g="evade",kind="Cosmetic",label="Heart Attack",image=""},{id="Cosmetic/HeartBelt",g="evade",kind="Cosmetic",label="Heart Belt",image="http://www.roblox.com/asset/?id=12168238764"},{id="Cosmetic/HermesPack",g="evade",kind="Cosmetic",label="Hermes Pack",image="http://www.roblox.com/asset/?id=12168238764"},{id="Cosmetic/Lollipop",g="evade",kind="Cosmetic",label="Lollipop",image=""},{id="Cosmetic/LoveChaser",g="evade",kind="Cosmetic",label="Love Chaser",image=""},{id="Cosmetic/LupercaliaTommy",g="evade",kind="Cosmetic",label="Lupercalia Tommy",image=""},{id="Cosmetic/NaturesTrident",g="evade",kind="Cosmetic",label="Natures Trident",image="rbxassetid://12324843445"},{id="Cosmetic/Rose",g="evade",kind="Cosmetic",label="Rose",image=""},{id="Cosmetic/ValentineBrawler",g="evade",kind="Cosmetic",label="Valentine Brawler",image=""},{id="Cosmetic/ValentinianBeast",g="evade",kind="Cosmetic",label="Valentinian Beast",image="rbxassetid://12472890540"},{id="Cosmetic/ValentinesHeadband",g="evade",kind="Cosmetic",label="Valentine Headband",image="rbxassetid://12273180514"},{id="Cosmetic/SakuraTree",g="evade",kind="Cosmetic",label="Sakura Tree",image="rbxassetid://12492024558"},{id="Cosmetic/RomanSword",g="evade",kind="Cosmetic",label="Roman Sword",image=""},{id="Unusual/WintertideEssence",g="evade",kind="Unusual",label="Wintertide Essence",image="rbxassetid://15750973623"},{id="Cosmetic/SealBuds",g="evade",kind="Cosmetic",label="Seal Buds",image="rbxassetid://8546590232"},{id="Cosmetic/ValentineRoses",g="evade",kind="Cosmetic",label="Valentine Roses",image="rbxassetid://11102170674"},{id="Cosmetic/HeartKugelblitz",g="evade",kind="Cosmetic",label="Heart Kugelblitz",image="rbxassetid://5101923607"},{id="Unusual/HeartSkaters",g="evade",kind="Unusual",label="Heart Skaters",image="rbxassetid://87822649590460"},{id="Unusual/CelestialStars",g="evade",kind="Unusual",label="Celestial Stars",image="rbxassetid://96348957254204"},{id="Cosmetic/BoboPopsicle",g="evade",kind="Cosmetic",label="Bobo Popsicle",image="rbxassetid://18222011237"},{id="Cosmetic/ColaCooler",g="evade",kind="Cosmetic",label="Cola Cooler",image="rbxassetid://18339102302"},{id="Cosmetic/CoolEvadeSurfboard",g="evade",kind="Cosmetic",label="Cool Evade Surfboard",image="rbxassetid://11102170674"},{id="Unusual/CoolHawaiianFlowers",g="evade",kind="Unusual",label="Cool Hawaiian Flowers",image="rbxassetid://93895877992072"},{id="Unusual/DeepseaAngler",g="evade",kind="Unusual",label="Deepsea Angler",image="rbxassetid://118206010282228"},{id="Unusual/EyeOfHorus",g="evade",kind="Unusual",label="Eye Of Horus",image="rbxassetid://71574332757057"},{id="Cosmetic/HotEvadeSurfboard",g="evade",kind="Cosmetic",label="Hot Evade Surfboard",image="rbxassetid://11102170674"},{id="Unusual/HotHawaiianFlowers",g="evade",kind="Unusual",label="Hot Hawaiian Flowers",image="rbxassetid://118552090951990"},{id="Cosmetic/ShiningSun",g="evade",kind="Cosmetic",label="Shining Sun",image="rbxassetid://1084975295"},{id="Unusual/SolarFlareStreak",g="evade",kind="Unusual",label="Solar Flare Streak",image="rbxassetid://126332844713619"},{id="Unusual/SunnySkies",g="evade",kind="Unusual",label="Sunny Skies",image="rbxassetid://72073869329310"},{id="Unusual/TropicalHawaiianFlowers",g="evade",kind="Unusual",label="Tropical Hawaiian Flowers",image="rbxassetid://109810629720224"},{id="Unusual/VaporwaveRays",g="evade",kind="Unusual",label="Vaporwave Rays",image="rbxassetid://82399966962456"},{id="Unusual/RadiantSun",g="evade",kind="Unusual",label="Radiant Sun",image="rbxassetid://114771344927184"},{id="Unusual/JellyfishSwarm",g="evade",kind="Unusual",label="Jellyfish Swarm",image="rbxassetid://117622941872168"},{id="Unusual/WebTraps",g="evade",kind="Unusual",label="Web Traps",image="rbxassetid://129262852826025"},{id="Cosmetic/MariachiSetYellow",g="evade",kind="Cosmetic",label="Mariachi Set Yellow",image=""},{id="Unusual/CacklingMoon",g="evade",kind="Unusual",label="Cackling Moon",image="rbxassetid://122583731423211"},{id="Unusual/MonochromeEclipse",g="evade",kind="Unusual",label="Monochrome Eclipse",image="rbxassetid://93673084841179"},{id="Unusual/PalpitatingHeart",g="evade",kind="Unusual",label="Palpitating Heart",image="rbxassetid://89086775000887"},{id="Unusual/MarigoldRitual",g="evade",kind="Unusual",label="Marigold Ritual",image="rbxassetid://84544451175492"},{id="Unusual/RunicWinds",g="evade",kind="Unusual",label="Runic Winds",image="rbxassetid://71560253038680"},{id="Unusual/SpectralSummoning",g="evade",kind="Unusual",label="Runic Summoning",image="rbxassetid://90695383226564"},{id="Unusual/DemonicAcidicWings",g="evade",kind="Unusual",label="Demonic Acidic Wings",image="rbxassetid://85498696267411"},{id="Unusual/CataclysmicPortal",g="evade",kind="Unusual",label="Cataclysmic Portal",image="rbxassetid://116414110442039"},{id="Unusual/DemonicInfernalWings",g="evade",kind="Unusual",label="Demonic Infernal Wings",image="rbxassetid://114320126086861"},{id="Cosmetic/MariachiSetBlack",g="evade",kind="Cosmetic",label="Mariachi Set Black",image=""},{id="Unusual/DemonicEclipseWings",g="evade",kind="Unusual",label="Demonic Eclipse Wings",image="rbxassetid://88827446585128"},{id="Cosmetic/SealGift",g="evade",kind="Cosmetic",label="Seal Gift",image="http://www.roblox.com/asset/?id=8779210242"},{id="Unusual/HeavenlyCrown",g="evade",kind="Unusual",label="Heavenly Crown",image="rbxassetid://116000112880052"},{id="Unusual/SnowflakeAegis",g="evade",kind="Unusual",label="Snowflake Aegis",image="rbxassetid://109810589747414"},{id="Unusual/BorealisAurora",g="evade",kind="Unusual",label="Borealis Aurora",image="rbxassetid://99107525229701"},{id="Unusual/AmethystAurora",g="evade",kind="Unusual",label="Amethyst Aurora",image="rbxassetid://82060568190116"},{id="Unusual/PepperimentAurora",g="evade",kind="Unusual",label="Pepperiment Aurora",image="rbxassetid://112836828364897"},{id="Unusual/RelentlessBlizzard",g="evade",kind="Unusual",label="Relentless Blizzard",image="rbxassetid://83448291598965"},{id="Unusual/GlacialEntrails",g="evade",kind="Unusual",label="Glacial Entrails",image="rbxassetid://115361358434627"},{id="Unusual/MysticalTree",g="evade",kind="Unusual",label="Mystical Tree",image="rbxassetid://136230366882665"},{id="Unusual/NorthernStarRadiance",g="evade",kind="Unusual",label="Northern Star Radiance",image="rbxassetid://111231871430271"},{id="Unusual/DiscoMania",g="evade",kind="Unusual",label="Disco Mania",image="rbxassetid://114291195700248"},{id="Cosmetic/GleamingTreasureChest",g="evade",kind="Cosmetic",label="Gleaming Treasure Chest",image="rbxassetid://16396381936"},{id="Cosmetic/IrishShield",g="evade",kind="Cosmetic",label="Irish Shield",image="rbxassetid://94385819032791"},{id="Unusual/MidasTouch",g="evade",kind="Unusual",label="Midas Touch",image="rbxassetid://82418794303065"},{id="Unusual/RetroCloverExplosion",g="evade",kind="Unusual",label="Retro Clover Explosion",image="rbxassetid://93065731055504"},{id="Unusual/RunicCloverLegs",g="evade",kind="Unusual",label="Runic Clover Legs",image="rbxassetid://117679637866001"},{id="Unusual/CircleOfRoses",g="evade",kind="Unusual",label="Circle of Roses",image="rbxassetid://101614340696980"},{id="Unusual/SakuraFlowers",g="evade",kind="Unusual",label="Sakura Flowers",image="rbxassetid://80966505301911"},{id="Unusual/HealingHalo",g="evade",kind="Unusual",label="Healing Halo",image="rbxassetid://89450817409507"},{id="Unusual/ShamrockShimmer",g="evade",kind="Unusual",label="Shamrock Shimmer",image="rbxassetid://108552949290601"},{id="Unusual/LuminousBlossom",g="evade",kind="Unusual",label="Luminous Blossom",image="rbxassetid://122029044572026"},{id="Unusual/CrimsonBlossom",g="evade",kind="Unusual",label="Crimson Blossom",image="rbxassetid://78552078599584"},{id="Unusual/AquamarineBlossom",g="evade",kind="Unusual",label="Aquamarine Blossom",image="rbxassetid://103571589865681"},{id="Unusual/VerdantLaurel",g="evade",kind="Unusual",label="Verdant Laurel",image="rbxassetid://132790033099748"},{id="Unusual/OakBlessing",g="evade",kind="Unusual",label="Oak Blessing",image="rbxassetid://110236140125732"},{id="Unusual/EasterEggHunter",g="evade",kind="Unusual",label="Easter Egg Hunter",image="rbxassetid://103784839343919"},{id="Unusual/LotusRift",g="evade",kind="Unusual",label="Lotus Rift",image="rbxassetid://123940738438234"},{id="Unusual/MonarchWings",g="evade",kind="Unusual",label="Monarch Wings",image="rbxassetid://73715962984251"},{id="Cosmetic/LeviathanAnchor",g="evade",kind="Cosmetic",label="Leviathan Anchor",image="rbxassetid://94146244556464"},{id="Unusual/RetroSunset",g="evade",kind="Unusual",label="Retro Sunset",image="rbxassetid://106466437282098"},{id="Unusual/TropicalNatureCrown",g="evade",kind="Unusual",label="Tropical Nature Crown",image="rbxassetid://136815544544764"},{id="Unusual/SunnyDay",g="evade",kind="Unusual",label="Sunny Day",image="rbxassetid://75344077957401"},{id="Unusual/DuckyWaterFall",g="evade",kind="Unusual",label="Ducky WaterFall",image="rbxassetid://126390064469383"},{id="Unusual/BlazingSun",g="evade",kind="Unusual",label="Blazing Sun",image="rbxassetid://125398027841020"},{id="Unusual/SkylineVinyl",g="evade",kind="Unusual",label="Skyline Vinyl",image="rbxassetid://109696031257894"},{id="Unusual/OceanSymphony",g="evade",kind="Unusual",label="Ocean Symphony",image="rbxassetid://124244987665503"},{id="Unusual/LuminescentJellyfish",g="evade",kind="Unusual",label="Luminescent Jellyfish",image="rbxassetid://85112817012734"},{id="Cosmetic/GhostlyAnchor",g="evade",kind="Cosmetic",label="Ghostly Anchor",image="rbxassetid://82798669195289"}};
      local d,P={Catalog=a,ById={},Loaded={}};
      local P=L;
      P.GameFX=d;
      for Z,Z in ipairs(a)do
        d.ById[Z.id]=Z;
      end;
      local a={};
      local Z,G={math=math,R=function(Y)
        return setmetatable({Y},a);
      end,V3=Vector3.new,V2=Vector2.new,C3=Color3.new,CF=CFrame.new,BC=function(Y)
        return BrickColor.new(Y);
      end,UD=function(Y,e)
        return UDim.new(Y,e);
      end,UD2=function(Y,e,j,C)
        return UDim2.new(Y,e,j,C);
      end,RC=function(Y,e,j,C)
        return Rect.new(Y,e,j,C);
      end,NR=function(Y,e)
        return NumberRange.new(Y,e);
      end,E=function(Y,e)
        local j,C=pcall(function()
          return Enum[Y][e];
        end);
        return j and C or nil;
      end,CS=function(Y)
        local e={};
        for j=1,#Y,4 do
          e[#e+1]=ColorSequenceKeypoint.new(Y[j],Color3.new(Y[j+1],Y[j+2],Y[j+3]));
        end;
        return ColorSequence.new(e);
      end,NS=function(Y)
        local e={};
        for j=1,#Y,3 do
          e[#e+1]=NumberSequenceKeypoint.new(Y[j],Y[j+1],Y[j+2]);
        end;
        return NumberSequence.new(e);
      end,FT=function(Y,e,j)
        local C,N=pcall(Font.new,Y,Enum.FontWeight[e],Enum.FontStyle[j]);
        return C and N or nil;
      end,FC=function(Y)
        local e={};
        for j,j in ipairs(Y)do
          e[#e+1]=Enum.NormalId[j];
        end;
        return Faces.new(unpack(e));
      end,AX=function(Y)
        local e={};
        for j,j in ipairs(Y)do
          e[#e+1]=Enum.Axis[j];
        end;
        return Axes.new(unpack(e));
      end,PP=function(Y,e,j,C,N)
        return PhysicalProperties.new(Y,e,j,C,N);
      end},{};
      local function Y(e)
        if d.Loaded[e] then
          return d.Loaded[e];
        end
        local j=G[e];
        if j then
          local C=os.clock()+60;
          while true do
            task.wait(0.05);
            local N;
            local N=not G[e]or not y[4][y[6]];
            if N or os.clock()>C then
              break;
            end
          end;
          return d.Loaded[e];
        end
        G[e]=true;
        local C,N=pcall(function()
          local q;
          local b="fxdata/"..e..".lua";
          if isfile and readfile then
            local D,p=pcall(isfile,b);
            if D and p then
              local D,p=pcall(readfile,b);
              q=if D then p else q;
            else
            end
          else
          end
          if q then
          else
            local D;
            b=z;
            q=b.body("fx/"..e..".bin");
          end
          if type(q)~="string"or q:sub(1,7)~="return " then
            error("fx/"..e..".bin did not arrive");
          end
          local D,p=loadstring(q,"@fx_"..e);
          if not D then
            error(p);
          end
          local q,p,r=setfenv,setmetatable,{__index=Z};
          q(D,p({},r));
          b={};
          for Z,Z in ipairs(D().items)do
            b[Z.id]=Z;
          end;
          return b;
        end);
        G[e]=nil;
        j=not C;
        if j then
          local Z;
          C=T;
          C("game fx "..e..": "..tostring(N));
          return nil;
        end
        d.Loaded[e]=N;
        return N;
      end
      local Z,G={LeftArm="Left Arm",RightArm="Right Arm",LeftLeg="Left Leg",RightLeg="Right Leg"},{Torso="UpperTorso",["Left Arm"]="LeftUpperArm",["Right Arm"]="RightUpperArm",["Left Leg"]="LeftUpperLeg",["Right Leg"]="RightUpperLeg"};
      local function e(j,C)
        C=Z[C]or C;
        local Z=j:FindFirstChild(C);
        if Z and(Z:IsA("BasePart")) then
          return Z,CFrame.new();
        end
        if C=="HumanoidRootPart" then
          return e(j,"Torso");
        end
        Z=G[C];
        local G=Z and(j:FindFirstChild(Z));
        if not(G and(G:IsA("BasePart"))) then
          return nil;
        end
        if C=="Torso" then
          Z=j:FindFirstChild("HumanoidRootPart");
          return G,CFrame.new(Z and G.CFrame:PointToObjectSpace(Z.Position)or Vector3.new(0.0,0.0,0.0));
        end
        return G,CFrame.new(0,-G.Size.Y/2,0);
      end
      local Z={"Torso","Right Arm","Left Arm","Right Leg","Left Leg","Head"};
      local function G(j)
        local C={};
        for N,q in ipairs(Z)do
          N=j:FindFirstChild(q);
          if N and(N:IsA("BasePart")) then
            C[#C+1]=N;
          end
        end;
        if #C<=1 then
          for Z,Z in ipairs(j:GetChildren())do
            if Z:IsA("BasePart")and Z.Name~="HumanoidRootPart"and not table.find(C,Z) then
              C[#C+1]=Z;
            end
          end;
        end
        return C;
      end
      local function Z(j)
        local C=j and(j:FindFirstChild("Torso")or j:FindFirstChild("UpperTorso")or j:FindFirstChild("HumanoidRootPart"));
        return C~=nil and C:IsA("BasePart");
      end
      local function j(C)
        local N={"Torso","UpperTorso","Head"};
        for q,b in ipairs(N)do
          q=C:FindFirstChild(b);
          if q and q:IsA("BasePart")and q.Transparency<1 then
            return true;
          end
        end;
        return false;
      end
      local function C()
        local N;
        local N=n;
        local q,b=N.Character,workspace:FindFirstChild("Rigs");
        N=nil;
        if b then
          local D=n;
          N=b:FindFirstChild(D.Name);
        else
          N=b;
        end
        if q and q.Parent and Z(q)and j(q) then
          return q;
        end
        if N and N:IsA("Model")and Z(N) then
          return N;
        end
        if q and q.Parent and Z(q) then
          return q;
        end
        return nil;
      end
      d.Wearer=C;
      local N,q,b={},{},true;
      local function D(p,r)
        local K;
        local K=not y[4][y[6]]or not b;
        if K then
          return nil;
        end
        local o,c=false;
        local m=true;
        task.spawn(function()
          local S,O=pcall(r);
          local r=m and y[4][y[6]]and b;
          if r then
            c=S and O or nil;
          elseif typeof(O)=="Instance" then
            O:Destroy();
          end
          o=true;
        end);
        K=os.clock()+p;
        while true do
          p=not o and y[4][y[6]]and b;
          if not(p and os.clock()<K) then
            break;
          end
          task.wait(0.05);
        end;
        m=false;
        p=typeof(c)=="Instance"and c or nil;
        return p;
      end
      local function p(r)
        local K="rbxassetid://"..(string.match(r,"(%d+)%s*$")or"");
        r=N[K];
        local o=r==nil;
        if o then
          local c,m=q[K];
          if c then
            while true do
              task.wait(0.05);
              local c=not q[K]or not y[4][y[6]]or not b;
              if c then
                break;
              end
            end;
            r=N[K]or false;
          else
            q[K]=true;
            r=D(6,function()
              local c,m,S=game:GetService("InsertService"),Enum.CollisionFidelity.Box,Enum.RenderFidelity.Precise;
              return c:CreateMeshPartAsync(K,m,S);
            end)or D(6,function()
              local D=s[70](Content.fromUri(K));
              return f:CreateMeshPartAsync(s:ZT(D));
            end)or false;
            local f=y[4][y[6]]and b;
            if f then
              N[K]=r;
            else
              if r then
                r:Destroy();
                r=false;
              else
              end
            end
            q[K]=nil;
          end
        else
        end
        if r then
          return r:Clone();
        end
        r,o=Instance.new("Part"),Instance.new("SpecialMesh");
        o.MeshType=Enum.MeshType.FileMesh;
        o.MeshId=K;
        o.Parent=r;
        return r,o;
      end
      local f,q={Attachment=true,ParticleEmitter=true,Beam=true,Trail=true,Bone=true,Folder=true,PointLight=true,SpotLight=true,SurfaceLight=true,Fire=true,Smoke=true,Sparkles=true},{SpecialMesh=true,BlockMesh=true,CylinderMesh=true,Decal=true,Texture=true,SurfaceGui=true};
      local function D(r)
        local K=false;
        for o,o in ipairs(r.k or{})do
          if q[o.c] then
            return false;
          end
          K=if f[o.c]then true else K;
        end;
        return K;
      end
      local function f(q,r)
        if q.limb then
          local K=e(r.char,q.n);
          if not K then
            return nil;
          end
          r.map[q.i]=K;
          for o,c in ipairs(q.k or{})do
            o=f(c,r);
            if o then
              r.limbKids[#r.limbKids+1]={o,K,q.cf};
            end
          end;
          return nil;
        end
        local K,o;
        if q.c=="MeshPart"and q.m and q.m~="" then
          local c;
          K,c=p(q.m);
          o=c;
        else
          local p,c=pcall(Instance.new,q.c);
          if not p then
            return nil;
          end
          K=c;
        end
        K.Name=q.n;
        r.map[q.i]=K;
        for p,c in pairs(q.p)do
          if getmetatable(c)==a then
            local a,m=r.refs,r.refs;
            local S,O=#m+1,{};
            s:MT(O,0,K,p,c[1]);
            a[S]=O;
          else
            pcall(function()
              K[p]=c;
            end);
          end
        end;
        if q.a then
          for s,a in pairs(q.a)do
            pcall(K.SetAttribute,K,s,a);
          end;
        end
        if o then
          local s=q.z;
          if typeof(s)=="Vector3"and s.X>0 and s.Y>0 and s.Z>0 then
            o.Scale=K.Size/s;
          else
            K.Transparency=1;
          end
          if type(q.p.TextureID)=="string" then
            o.TextureId=q.p.TextureID;
          end
        end
        if q.c=="Part"and K.Shape==Enum.PartType.Block and D(q) then
          K.Transparency=1;
        end
        if K:IsA("BasePart") then
          K.Anchored=false;
          K.CanCollide=false;
          K.CanTouch=false;
          K.CanQuery=false;
          K.Massless=true;
        end
        for s,a in ipairs(q.k or{})do
          if a.c=="SurfaceAppearance" then
            local q=a.p.ColorMap;
            if type(q)=="string"and q~="" then
              if o then
                if o.TextureId=="" then
                  o.TextureId=q;
                end
              elseif K:IsA("MeshPart")and K.TextureID=="" then
                pcall(function()
                  K.TextureID=q;
                end);
              end
            end
          else
            s=f(a,r);
            if s then
              s.Parent=K;
            end
          end
        end;
        return K;
      end
      local function s(a)
        local q=a:IsA("BasePart")and{a}or{};
        for D,D in ipairs(a:GetDescendants())do
          if D:IsA("BasePart") then
            q[#q+1]=D;
          end
        end;
        return q;
      end
      local a={aura={},trail={},cosmetic={}};
      local function q(D,p)
        if D==p then
          return true;
        end
        if typeof(D)~="ColorSequence"or typeof(p)~="ColorSequence" then
          return false;
        end
        local r,K=D.Keypoints,p.Keypoints;
        if #r~=#K then
          return false;
        end
        for D,p in ipairs(r)do
          if p.Time~=K[D].Time or p.Value~=K[D].Value then
            return false;
          end
        end;
        return true;
      end
      local function D(p,r)
        if r==1 then
          return p;
        end
        local K={};
        for o,c in ipairs(p.Keypoints)do
          K[o]=NumberSequenceKeypoint.new(c.Time,c.Value*r,c.Envelope*r);
        end;
        return NumberSequence.new(K);
      end
      local function p(r,K,o)
        return CFrame.new(r.Position*o+K)*(r-r.Position);
      end
      local function r(K)
        K.transforms={};
        local o,c={},{};
        for m,m in ipairs(K.worn or{})do
          o[m]=true;
          c[#c+1]=m;
          for S,S in ipairs(m:GetDescendants())do
            o[S]=true;
            c[#c+1]=S;
          end;
        end;
        for m,S in ipairs(c)do
          if S:IsA("BasePart") then
            m=S:FindFirstChildOfClass("SpecialMesh");
            local c,O;
            for B,A in ipairs(S:GetJoints())do
              if A:IsA("Weld")or A:IsA("Motor6D") then
                B=A.Part0==S and A.Part1 or A.Part0;
                if B and not o[B] then
                  c,O=A,A.Part0==S;
                  break;
                end
              end
            end;
            K.transforms[S]={kind="part",cframe=S.CFrame,size=S.Size,mesh=m,meshScale=m and m.Scale or nil,joint=c,first=O,c0=c and c.C0 or CFrame.new(),c1=c and c.C1 or CFrame.new()};
          elseif S:IsA("Attachment") then
            K.transforms[S]={kind="attachment",cframe=S.CFrame};
          end
        end;
      end
      local function K(o,c)
        if o.group~="cosmetic" then
          return;
        end
        local m=Vector3.new(tonumber(c.x)or 0,tonumber(c.y)or 0,tonumber(c.z)or 0);
        local S=math.clamp(tonumber(c.scale)or 1,0.25,2.5);
        for c,O in pairs(o.transforms or{})do
          if c.Parent then
            pcall(function()
              if O.kind=="attachment" then
                c.CFrame=p(O.cframe,m,S);
                return;
              end
              c.Size=O.size*S;
              if O.mesh and O.mesh.Parent and O.meshScale then
                O.mesh.Scale=O.meshScale*S;
              end
              local o=O.joint;
              if o and o.Parent then
                if O.first then
                  o.C1=p(O.c1,m,S);
                else
                  o.C0=p(O.c0,m,S);
                end
              end
            end);
          end
        end;
      end
      local function p(o)
        if o:IsA("ParticleEmitter") then
          return{o,rate=o.Rate,bright=o.Brightness,size=o.Size,speed=o.Speed,spin=o.RotSpeed,life=o.Lifetime,color=o.Color};
        elseif o:IsA("Beam") then
          return{o,color=o.Color,bright=o.Brightness};
        elseif o:IsA("Trail") then
          return{o,color=o.Color,life=o.Lifetime,bright=o.Brightness};
        elseif o:IsA("Light") then
          return{o,color=o.Color,bright=o.Brightness};
        elseif o:IsA("Fire") then
          return{o,color=o.Color,color2=o.SecondaryColor};
        elseif o:IsA("Smoke") then
          return{o,color=o.Color};
        elseif o:IsA("Sparkles") then
          return{o,color=o.SparkleColor};
        elseif o:IsA("Highlight") then
          return{o,color=o.FillColor,color2=o.OutlineColor};
        elseif (o:IsA("BasePart")or o:IsA("Decal"))and o.Transparency<1 then
          return{o,transparency=o.Transparency,color=o:IsA("Decal")and o.Color3 or o.Color,texture=o:IsA("MeshPart")and o.TextureID or nil};
        end
      end
      local function o(c,m)
        local S=c[1];
        if not m then
          if not c.tinted then
            return;
          end
          c.tinted=false;
          if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail")or S:IsA("Light")or S:IsA("Smoke") then
            S.Color=c.color;
          elseif S:IsA("Decal") then
            S.Color3=c.color;
          elseif S:IsA("BasePart") then
            S.Color=c.color;
            if c.texture then
              S.TextureID=c.texture;
            end
          elseif S:IsA("Fire") then
            S.Color,S.SecondaryColor=c.color,c.color2;
          elseif S:IsA("Sparkles") then
            S.SparkleColor=c.color;
          elseif S:IsA("Highlight") then
            S.FillColor,S.OutlineColor=c.color,c.color2;
          end
          return;
        end
        if not c.tinted then
          c.tinted=true;
          if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail")or S:IsA("Light")or S:IsA("Smoke") then
            c.color=S.Color;
          elseif S:IsA("Decal") then
            c.color=S.Color3;
          elseif S:IsA("BasePart") then
            c.color=S.Color;
            if S:IsA("MeshPart") then
              c.texture=S.TextureID;
            end
          elseif S:IsA("Fire") then
            c.color,c.color2=S.Color,S.SecondaryColor;
          elseif S:IsA("Sparkles") then
            c.color=S.SparkleColor;
          elseif S:IsA("Highlight") then
            c.color,c.color2=S.FillColor,S.OutlineColor;
          end
        end
        local O=m.Keypoints[1].Value;
        if S:IsA("ParticleEmitter")or S:IsA("Beam")or S:IsA("Trail") then
          if S.Color~=m then
            S.Color=m;
          end
        elseif S:IsA("Decal") then
          if S.Color3~=O then
            S.Color3=O;
          end
        elseif S:IsA("BasePart") then
          if S.Color~=O then
            S.Color=O;
          end
          if c.texture and S.TextureID~="" then
            S.TextureID="";
          end
        elseif S:IsA("Fire") then
          if S.Color~=O then
            S.Color=O;
            S.SecondaryColor=O;
          end
        elseif S:IsA("Sparkles") then
          if S.SparkleColor~=O then
            S.SparkleColor=O;
          end
        elseif S:IsA("Highlight") then
          if S.FillColor~=O then
            S.FillColor=O;
            S.OutlineColor=O;
          end
        elseif S:IsA("Light")or S:IsA("Smoke") then
          if S.Color~=O then
            S.Color=O;
          end
        end
      end
      local function c(m)
        local S=a[m.group]or{};
        if m.guest then
          return S,m.tint;
        end
        return S,S.color;
      end
      local function m(S,O,B)
        local A=S[1];
        if not A.Parent then
          return;
        end
        local w=O.glow or 1;
        local F=O.rate or 1;
        local h=O.amount or 1;
        local W=O.size or 1;
        local V=O.speed or 1;
        local _=O.life or 1;
        local X=O.opacity or 1;
        pcall(function()
          if A:IsA("ParticleEmitter") then
            A.Rate=S.rate*F*h;
            A.Brightness=S.bright*w;
            A.Size=D(S.size,W);
            local D=math.clamp(V,0.05,5);
            A.Speed=NumberRange.new(S.speed.Min*D,S.speed.Max*D);
            A.RotSpeed=NumberRange.new(S.spin.Min*D,S.spin.Max*D);
            A.Lifetime=NumberRange.new(math.max(0.05,S.life.Min*_/D),math.max(0.06,S.life.Max*_/D));
          elseif A:IsA("Trail") then
            A.Lifetime=math.max(0.05,S.life*_);
            A.Brightness=S.bright*w;
          elseif A:IsA("Beam")or A:IsA("Light") then
            A.Brightness=S.bright*w;
          elseif A:IsA("BasePart")or A:IsA("Decal") then
            A.Transparency=1-(1-S.transparency)*X;
          end
          o(S,B);
        end);
      end
      local function D(S)
        local O,B=c(S);
        for A,A in ipairs(S.tune or{})do
          m(A,O,B);
        end;
        K(S,O);
      end
      local function K(S)
        local O=S.tune;
        if not O then
          return;
        end
        local B,B=c(S);
        if #O>200 then
          for S=#O,1,-1 do
            if not O[S][1].Parent then
              table.remove(O,S);
            end
          end;
        end
        if not B then
          return;
        end
        for S,S in ipairs(O)do
          if S[1].Parent then
            pcall(o,S,B);
          end
        end;
      end
      local o;
      local function S(O,B)
        local A,w,F={},setmetatable,{__mode="k"};
        local h,W,V=w({},F),setmetatable,{__mode="k"};
        local w=W({},V);
        O.tune=A;
        local function F(W)
          if h[W] then
            return nil;
          end
          local V=p(W);
          if V then
            h[W]=true;
            A[#A+1]=V;
          end
          if o then
            o(W);
          end
          return V;
        end
        O.watch=function(p)
          if not O.alive or w[p] then
            return;
          end
          w[p]=true;
          F(p);
          for A,A in ipairs(p:GetDescendants())do
            F(A);
          end;
          O.conns[#O.conns+1]=p.DescendantAdded:Connect(function(p)
            if not O.alive then
              return;
            end
            local A=F(p);
            if A and O.alive then
              local p,w=c(O);
              m(A,p,w);
            end
          end);
        end;
        for p,p in ipairs(B)do
          O.watch(p);
        end;
      end
      local p={["Echo/DistortionThing"]=function(c)
        local m,O=c.limb("Torso"),c.live.roots.Torso;
        local B=O and(O:WaitForChild("EchoBubbleMesh",5));
        if not(m and B) then
          return;
        end
        O=workspace:FindFirstChild(c.player.Name.."_distortion")or Instance.new("Folder");
        O.Name=c.player.Name.."_distortion";
        O.Parent=workspace;
        c.made(O);
        local A;
        local A=J;
        A.RenderStepped:Wait();
        while c.alive()and m.Parent do
          local c=B:Clone();
          c.CFrame=m.CFrame;
          c.Anchored=false;
          c.CanCollide=false;
          c.CanTouch=false;
          c.CanQuery=false;
          A=c:FindFirstChild("Weld");
          if A then
            A.Part0=m;
            A.Part1=c;
          end
          c.Massless=true;
          c.Parent=O;
          c.Material=Enum.Material.Glass;
          c.Size=Vector3.new(6,6,6);
          c.Transparency=1;
          local m=Instance.new("Highlight");
          m.Enabled=false;
          m.Parent=c;
          game:GetService("Debris"):AddItem(c,11);
          local O,B=TweenInfo.new,Enum;
          local A,w=B.EasingStyle.Sine,Enum.EasingDirection;
          B,m=O(3,A,w.In),{Transparency=6};
          m.Size=Vector3.new(7,7,7);
          l:Create(c,B,m):Play();
          task.delay(2,function()
            if c.Parent then
              local m,O=TweenInfo.new,Enum;
              local B,A=O.EasingStyle.Sine,Enum.EasingDirection;
              local O,w=m(8,B,A.Out),{Transparency=1};
              w.Size=Vector3.new(8,8,8);
              l:Create(c,O,w):Play();
            end
          end);
          task.wait(4);
        end;
      end,["RNS_Ring/TorsoRecolor"]=function(c)
        local m=c.live.roots.HumanoidRootPart;
        local O=m and(m:WaitForChild("Main",5));
        if not O then
          return;
        end
        local B,A=c.char:FindFirstChild("Body Colors")or c.char:FindFirstChildOfClass("BodyColors"),c.limb("Torso");
        m=B and B.TorsoColor3 or A and A.Color or Color3.new(1,1,1);
        for c,c in ipairs(O:GetDescendants())do
          if c:IsA("ParticleEmitter") then
            c.Color=ColorSequence.new(m);
          end
        end;
      end};
      local function c(m,O)
        for B,B in ipairs(G(m.char))do
          if B.Name~="Head" then
            local G=B.Transparency;
            B.Transparency=1;
            m.undo(function()
              if B.Parent then
                B.Transparency=G;
              end
            end);
          end
        end;
        if O then
          for G,G in ipairs(m.char:GetChildren())do
            if G:IsA("Accessory") then
              for O,O in ipairs(G:GetDescendants())do
                if O:IsA("BasePart")or O:IsA("Decal") then
                  local G=O.Transparency;
                  O.Transparency=1;
                  m.undo(function()
                    if O.Parent then
                      O.Transparency=G;
                    end
                  end);
                end
              end;
            end
          end;
        end
      end
      p["Voidbroken/Body"]=function(G)
        c(G,false);
      end;
      p["VoidbrokenFull/Body"]=function(G)
        c(G,true);
      end;
      p["MartOrbit/MartOrbitHandler"]=function(G)
        local c,m,O=G.parent,{["1"]=1.2,["2"]=1.8,["3"]=1.6,["4"]=1.9,["5"]=1.3},{};
        for B,A in pairs(m)do
          local m=c:FindFirstChild(B);
          if m then
            O[m]={A,m.CFrame};
          end
        end;
        if not next(O) then
          return;
        end
        local c,m=0;
        G.conn(J.RenderStepped:Connect(function(G)
          local m=c;
          c=m+3.141592653589793*G;
          for G,m in pairs(O)do
            local O,B,A,w=m[2],CFrame.Angles,c/1.0E19,c;
            G.CFrame=O*B(A,w/m[1],0);
          end;
        end));
      end;
      p["SparklyDuet/SparklyDuetHandler"]=function(G)
        local c=G.parent;
        local m=c:FindFirstChild("1")and c["1"]:FindFirstChild("1Number");
        local O=c:FindFirstChild("2")and c["2"]:FindFirstChild("2Number");
        if not(m and O) then
          return;
        end
        local c,B=0;
        G.conn(J.RenderStepped:Connect(function(G)
          local B=c;
          c=B+3.141592653589793*G;
          G=CFrame.Angles(c/4,c/2,0);
          m.CFrame=m.CFrame*G;
          O.CFrame=O.CFrame*G;
        end));
      end;
      local function G(c,m)
        local function O(B)
          local A=B.char:WaitForChild("HumanoidRootPart",5);
          local w=B.char:WaitForChild("Humanoid",5);
          local F=B.live.roots.HumanoidRootPart;
          local h=F and(F:WaitForChild("Main",5));
          h=h and(h:WaitForChild("Path",5));
          local F=h and(h:WaitForChild(c,5));
          local c=h and(h:WaitForChild(m,5));
          if not(A and w and F and c) then
            return;
          end
          local m,h,W,W=F.Rate;
          W,h=J,B.conn(J.RenderStepped:Connect(function()
            local B=w:GetState();
            if B==Enum.HumanoidStateType.Dead or not(F.Parent and c.Parent) then
              h:Disconnect();
              return;
            end
            local w=B==Enum.HumanoidStateType.Running;
            if F.Enabled~=w then
              F.Enabled=w;
            end
            if c.Enabled~=w then
              c.Enabled=w;
            end
            B=math.min((A.AssemblyLinearVelocity*Vector3.new(1,0,1)).Magnitude*2,m);
            B=B<=3 and 0 or B;
            if F.Rate~=B then
              F.Rate=B;
            end
            if c.Rate~=B then
              c.Rate=B;
            end
          end));
        end
        return O;
      end
      p["GuardianTrail/GuardianTrailScript"]=G("Blue","Red");
      p["BloomingBlossom/BloomingBlossomScript"]=G("Green","Purple");
      local function c(m)
        local O,B,A=m.parent,0;
        m.conn(J.RenderStepped:Connect(function(m)
          B+=m;
          O.Lifetime=(math.sin(B*3.141592653589793)+1)/2/2+1;
        end));
      end
      p["OoeyGooey/Origin"]=c;
      p["OoeyGooey/AnimateOoeyGooey"]=c;
      local function m(O,B,A,w)
        local F=O.parent;
        local h,W=F:FindFirstChildOfClass("AnimationController"),O.anims[B];
        if h and W then
          local V=h:FindFirstChildOfClass("Animator")or h;
          local h=Instance.new("Animation");
          h.AnimationId=W;
          O.undo(function()
            h:Destroy();
          end);
          local W,_=pcall(function()
            return V:LoadAnimation(h);
          end);
          if W and _ then
            if not O.alive() then
              pcall(function()
                _:Stop(0);
              end);
              return;
            end
            O.undo(function()
              pcall(function()
                _:Stop(0);
              end);
            end);
            _:Play(0);
            B=os.clock();
            repeat
              task.wait(0.1);
            until _.Length>0 or os.clock()-B>3 or not O.alive();
            if _.Length>0 then
              if w then
                _.TimePosition=Random.new(tick()):NextNumber(0,_.Length);
              end
              return;
            end
            pcall(function()
              _:Stop(0);
            end);
          end
        end
        if not A then
          return;
        end
        local B={};
        for h,h in ipairs(F:GetDescendants())do
          if h:IsA("Motor6D") then
            B[#B+1]={h,h.C0};
          end
        end;
        if #B==0 then
          return;
        end
        local F,h=w and math.random()*10 or 0;
        O.conn(J.RenderStepped:Connect(function(J)
          F+=J;
          J=CFrame.Angles(0,F*A,0);
          for O,O in ipairs(B)do
            O[1].C0=O[2]*J;
          end;
        end));
      end
      p["spins/Script"]=function(J)
        m(J,"Animation",1.4,true);
      end;
      p["Model/Script"]=function(J)
        task.wait();
        m(J,"Voidstar",0.8,false);
      end;
      p["NeonSign/LocalScript"]=function(J)
        m(J,"Animation",nil,false);
      end;
      local J={Color3.fromRGB(255,52,52),Color3.fromRGB(216,140,63),Color3.fromRGB(239,235,95),Color3.fromRGB(137,216,102),Color3.fromRGB(105,177,216),Color3.fromRGB(112,98,216)};
      local function m(O,B)
        local A=TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out);
        while O.alive()and B.Parent and B.Parent.Parent do
          for w,w in ipairs(J)do
            if not O.alive() then
              return;
            end
            l:Create(B,A,{OutlineColor=w}):Play();
            task.wait(0.5);
          end;
        end;
      end
      p["Glow/LocalScript"]=function(l)
        task.wait(1);
        local J=l.parent;
        J.Adornee=l.char;
        m(l,J);
      end;
      p["GlowSolid/LocalScript"]=function(l)
        task.wait(1);
        l.parent.Adornee=l.char;
      end;
      p["Grunt/LocalScript"]=function(l)
        m(l,l.parent);
      end;
      local l,J,m,O={},{},{};
      local function B(A,w)
        w=w or l;
        local F=w[A];
        if not F then
          return;
        end
        w[A]=nil;
        F.alive=false;
        for A,A in ipairs(F.tasks)do
          pcall(task.cancel,A);
        end;
        for A,A in ipairs(F.conns)do
          pcall(function()
            A:Disconnect();
          end);
        end;
        for A=#F.undo,1,-1 do
          pcall(F.undo[A]);
        end;
        for A,A in ipairs(F.made)do
          pcall(function()
            A:Destroy();
          end);
        end;
      end
      local function A(w,F)
        if F=="" then
          return w.char;
        end
        local h;
        for W in string.gmatch(F,"[^%.]+")do
          h=if h==nil then w.roots[W]else(h:FindFirstChild(W));
          if not h then
            return nil;
          end
        end;
        return h;
      end
      local function w(F,h,W)
        local V,_=ipairs,h.scripts or{};
        for X,x in V(_)do
          X=x.at:match("([^%.]+)$")or"";
          local V=p[F.key.."/"..x.n]or p[X.."/"..x.n];
          X=A(h,x.at);
          local p=V and X;
          if p then
            local p,A={char=h.char};
            if W then
              A=W;
            else
              local W;
              local W=n;
              A=W;
            end
            p.player=A;
            p.parent=X;
            p.live=h;
            p.anims=x.anims or{};
            p.limb=function(A)
              return(e(h.char,A));
            end;
            local A;
            p.conn=function(A)
              local W=h.alive and y[4][y[6]];
              if W then
                h.conns[#h.conns+1]=A;
              else
                A:Disconnect();
              end
              return A;
            end;
            p.undo=function(A)
              local W=h.alive and y[4][y[6]];
              if W then
                h.undo[#h.undo+1]=A;
              else
                pcall(A);
              end
            end;
            p.alive=function()
              local A=h.alive and y[4][y[6]];
              return A;
            end;
            p.made=function(A)
              local W=h.alive and y[4][y[6]];
              if W then
                h.made[#h.made+1]=A;
                if h.watch then
                  h.watch(A);
                end
              else
                A:Destroy();
              end
              return A;
            end;
            local A,W=task.spawn(function()
              local _,X=pcall(V,p);
              local p=not _;
              if p then
                local p;
                _=T;
                _("game fx "..F.key.."/"..x.n..": "..tostring(X));
              end
            end),h.alive and y[4][y[6]];
            if W then
              h.tasks[#h.tasks+1]=A;
            else
              pcall(task.cancel,A);
            end
          end
        end;
      end
      local p,A,F,h=game:GetService("ContentProvider"),{},{},{};
      local W=NumberSequence.new(1);
      local function V(_)
        pcall(function()
          _.Transparency=W;
          _.Enabled=false;
        end);
      end
      o=function(W)
        if not(W:IsA("ParticleEmitter")or W:IsA("Beam")or W:IsA("Trail"))or W.Texture=="" then
          return;
        end
        local _=W.Texture;
        local X,x=pcall(p.GetAssetFetchStatus,p,_);
        if A[_]or X and(x==Enum.AssetFetchStatus.Failure or x==Enum.AssetFetchStatus.TimedOut) then
          A[_]=true;
          V(W);
        elseif X and x~=Enum.AssetFetchStatus.Success then
          local X=F[_];
          if not X then
            local x,k=setmetatable,{__mode="k"};
            X=x({},k);
            F[_]=X;
            k,x=pcall(p.GetAssetFetchStatusChangedSignal,p,_);
            if not k then
              F[_]=nil;
              return;
            end
            local p;
            p=x:Connect(function(x)
              if x==Enum.AssetFetchStatus.Success then
                p:Disconnect();
                F[_]=nil;
              elseif x==Enum.AssetFetchStatus.Failure or x==Enum.AssetFetchStatus.TimedOut then
                p:Disconnect();
                F[_]=nil;
                A[_]=true;
                for A in pairs(X)do
                  V(A);
                end;
              end
            end);
            h[#h+1]=p;
          else
          end
          X[W]=true;
        end
      end;
      d.ProtectTexture=o;
      local p;
      c=H;
      c("fx textures",function()
        for p,p in ipairs(h)do
          p:Disconnect();
        end;
        table.clear(h);
      end);
      local function p(o,c,A,F,h,W,V)
        local _,X=c.trees,c.scripts;
        if c.mode=="rig" then
          local x=A:FindFirstChild("UpperTorso")~=nil and(c.r15 or c.r6)or(c.r6 or c.r15);
          _,X={},x and x.scripts or{};
          for k,v in ipairs(x and x.limbs or{})do
            _[k]=v;
          end;
          if c.aura then
            _[#_+1]=c.aura;
          end
        else
        end
        local x,k={map={},refs={},char=A,limbKids={}},{};
        for v,I in ipairs(_)do
          v=f(I,x);
          if v then
            k[#k+1]=v;
          end
        end;
        local f,_=V and not V()or h and not A.Parent or not h and(A~=C()or J[o]~=F);
        V=f or not y[4][y[6]];
        if V then
          for _,_ in ipairs(k)do
            pcall(function()
              _:Destroy();
            end);
          end;
          for _,_ in ipairs(x.limbKids)do
            pcall(function()
              _[1]:Destroy();
            end);
          end;
          return;
        end
        local _,v,I,i={item=c,char=A,made={},conns={},undo={},tasks={},roots={},worn={},transforms={},alive=true,scripts=X,group=F,guest=h~=nil},c.kind=="Trail"and"Trail_"or"Aura_",{},{};
        for X,E in ipairs(k)do
          if c.mode=="parts"and E:IsA("BasePart") then
            X=E.Name;
            f,F=e(A,X);
            if not f then
              f,F=e(A,"HumanoidRootPart");
            else
            end
            if f then
              V=f.CFrame*F*E.CFrame:Inverse();
              for Q,Q in ipairs(s(E))do
                Q.CFrame=V*Q.CFrame;
              end;
              E.Transparency=1;
              E.Name=v..X;
              _.roots[X]=E;
              I[#I+1]={E,f,F};
            else
              E:Destroy();
            end
          elseif c.mode=="rig"and E:IsA("BasePart") then
            local X=e(A,"HumanoidRootPart");
            if X then
              E.Name="Aura";
              local Q=Instance.new("Attachment");
              Q.Name="AuraMount";
              Q.Parent=E;
              Q=X:FindFirstChildOfClass("Attachment");
              local t=Q and Q.CFrame or CFrame.new();
              for Q,Q in ipairs(s(E))do
                Q.CFrame=X.CFrame*t*E.CFrame:Inverse()*Q.CFrame;
              end;
              E.Transparency=1;
              I[#I+1]={E,X,t,true};
            else
              E:Destroy();
            end
          elseif c.mode=="attach"and E:IsA("Attachment") then
            local X,Q=e(A,"Torso");
            if X then
              E.CFrame=Q*E.CFrame;
              E.Name=c.kind=="Trail"and"Trail"or"AuraAttachment";
              I[#I+1]={E,X};
            else
              E:Destroy();
            end
          elseif c.mode=="trail"and E:IsA("Trail") then
            local X,Q=e(A,"Torso");
            if X then
              local e,A,t=tonumber(c.width)or 1,Instance.new("Attachment"),Instance.new("Attachment");
              A.Name="LeftTrail";
              t.Name="RightTrail";
              A.CFrame,t.CFrame=Q*CFrame.new(-e,0,0),Q*CFrame.new(e,0,0);
              A.Parent=X;
              t.Parent=X;
              E.Attachment0=A;
              E.Attachment1=t;
              _.made[#_.made+1]=A;
              _.made[#_.made+1]=t;
              I[#I+1]={E,X};
            else
              E:Destroy();
            end
          else
            E:Destroy();
          end
        end;
        for e,A in ipairs(x.limbKids)do
          e,f,k=A[1],A[2],A[3];
          if k then
            A=f.CFrame*k:Inverse();
            for X,X in ipairs(s(e))do
              X.CFrame=A*X.CFrame;
            end;
          end
          if e:IsA("Attachment") then
            V=f:FindFirstChild(e.Name);
            if V and(V:IsA("Attachment")) then
              e.CFrame=V.CFrame;
            end
          end
          _.roots[f.Name]=f;
        end;
        for s,s in ipairs(x.refs)do
          local e=x.map[s[3]];
          if e then
            pcall(function()
              s[1][s[2]]=e;
            end);
          end
        end;
        for s,s in ipairs(x.limbKids)do
          s[1].Parent=s[2];
          _.made[#_.made+1]=s[1];
          i[#i+1]=s[1];
        end;
        for s,s in ipairs(I)do
          F,f,v,V=s[1],s[2],s[3],s[4];
          F.Parent=f;
          if v then
            x=Instance.new("Weld");
            x.Name="Weld";
            x.Part0=f;
            x.Part1=F;
            x.C0,x.C1=v,CFrame.new();
            x.Parent=F;
          end
          _.made[#_.made+1]=F;
          i[#i+1]=F;
        end;
        _.worn=i;
        r(_);
        S(_,i);
        (h or l)[o]=_;
        D(_);
        w(c,_,W);
      end
      local s={};
      local function f()
        for e,e in ipairs(s)do
          pcall(e);
        end;
      end
      local function e(r)
        local o,c=d.ById[r],O;
        local S=J[r];
        if not(o and c and S)or l[r]or m[r] then
          return;
        end
        local A={};
        m[r]=A;
        f();
        task.spawn(function()
          local w,F=pcall(function()
            local h=Y(o.g);
            local o,W=h and h[r];
            h=o and y[4][y[6]]and m[r]==A and J[r]==S and O==c;
            if h then
              p(r,o,c,S,nil,nil,function()
                local o=m[r]==A and O==c and J[r]==S and not l[r];
                return o;
              end);
            end
          end);
          local o=not w;
          if o then
            local o;
            w=T;
            w("game fx "..r..": "..tostring(F));
          end
          if m[r]==A then
            m[r]=nil;
            f();
          end
        end);
      end
      d.Set=function(f,r)
        if not d.ById[f] then
          return;
        end
        if J[f]==r then
          return;
        end
        m[f]=nil;
        B(f);
        J[f]=r;
        if r then
          e(f);
        end
      end;
      d.SetGroup=function(f,r)
        local o={};
        for c,c in ipairs(r or{})do
          if d.ById[c] then
            o[c]=true;
          end
        end;
        for r,c in pairs(J)do
          if c==f and not o[r] then
            d.Set(r,nil);
          end
        end;
        for r in pairs(o)do
          d.Set(r,f);
        end;
      end;
      local f={};
      local function r(o)
        local c,S=o.Character,workspace:FindFirstChild("Rigs");
        local A=S and S:FindFirstChild(o.Name);
        if c and c.Parent and Z(c)and j(c) then
          return c;
        end
        if A and A:IsA("Model")and Z(A) then
          return A;
        end
        if c and c.Parent and Z(c) then
          return c;
        end
        return nil;
      end
      local function Z(j)
        table.clear(j.busy);
        for o in pairs(j.worn)do
          B(o,j.worn);
        end;
      end
      d.Undress=function(j)
        local o=f[j];
        if not o then
          return;
        end
        Z(o);
        f[j]=nil;
      end;
      d.Guests=function()
        return f;
      end;
      d.Dress=function(j,o,c)
        local S,A=not j;
        if S then
          A=S;
        else
          local w;
          local w=n;
          A=j==w;
        end
        if A then
          return;
        end
        S=f[j];
        if not S then
          S={worn={},busy={},want={}};
          f[j]=S;
        else
        end
        A={};
        for n,j in ipairs(o or{})do
          n=type(j)=="table"and j.id or j;
          if d.ById[n] then
            A[n]=type(j)=="table"and j.group or"aura";
          end
        end;
        for n in pairs(S.busy)do
          if A[n]~=S.want[n] then
            S.busy[n]=nil;
          end
        end;
        S.want=A;
        S.tint=c;
      end;
      local function n(j,o)
        local c=r(j);
        if not c then
          if o.char or next(o.worn)or next(o.busy) then
            Z(o);
          end
          o.char=nil;
          return;
        end
        if o.char~=c then
          Z(o);
          o.char=c;
        end
        for Z,r in pairs(o.worn)do
          if o.want[Z]~=r.group then
            B(Z,o.worn);
          else
            local Z=o.tint and o.tint[r.group]or nil;
            if not q(r.tint,Z) then
              r.tint=Z;
              D(r);
            end
          end
        end;
        local Z,r=pairs,o.want;
        for S,A in Z(r)do
          local Z=not o.worn[S]and not o.busy[S];
          if Z then
            local Z={};
            o.busy[S]=Z;
            task.spawn(function()
              local r,w=pcall(function()
                local F=d.ById[S];
                local h=F and Y(F.g);
                local Y,F=h and h[S];
                h=Y and y[4][y[6]]and o.busy[S]==Z and o.want[S]==A and o.char==c and c.Parent;
                if h then
                  p(S,Y,c,A,o.worn,j,function()
                    return f[j]==o and o.busy[S]==Z and not o.worn[S]and o.want[S]==A and o.char==c and c.Parent~=nil;
                  end);
                end
              end);
              local Y=not r;
              if Y then
                local Y;
                r=T;
                r("share "..tostring(S)..": "..tostring(w));
              end
              if o.busy[S]==Z then
                o.busy[S]=nil;
              end
            end);
          end
        end;
      end
      task.spawn(function()
        while true do
          local T;
          local T=y[4][y[6]];
          if not T then
            break;
          end
          task.wait(0.5);
          for T,Z in pairs(f)do
            if not T.Parent then
              d.Undress(T);
            else
              pcall(n,T,Z);
            end
          end;
        end;
      end);
      task.spawn(function()
        while true do
          local T;
          local T=y[4][y[6]];
          if not T then
            break;
          end
          task.wait(1);
          for T,T in pairs(l)do
            pcall(K,T);
          end;
          for T,T in pairs(f)do
            for n,n in pairs(T.worn)do
              pcall(K,n);
            end;
          end;
        end;
      end);
      d.WornList=function()
        local T={};
        for n,Z in pairs(J)do
          if Z then
            T[#T+1]={id=n,group=Z};
          end
        end;
        return T;
      end;
      d.Tune=function(T,n)
        n=type(n)=="table"and n or{};
        local Z,Y=a[T]or{},true;
        for j,p in pairs(n)do
          if j=="color" then
            if not q(Z[j],p) then
              Y=false;
              break;
            end
          elseif Z[j]~=p then
            Y=false;
            break;
          end
        end;
        if Y then
          for j in pairs(Z)do
            if n[j]==nil then
              Y=false;
              break;
            end
          end;
        else
        end
        if Y then
          return;
        end
        a[T]=table.clone(n);
        for n,n in pairs(l)do
          if n.group==T then
            D(n);
          end
        end;
        for n,n in pairs(f)do
          for a,a in pairs(n.worn)do
            if a.group==T then
              D(a);
            end
          end;
        end;
      end;
      local T,n={},"idle";
      local function a(Z)
        return(tostring(Z):gsub("[^%w_%.%-]","_"));
      end
      d.OnThumbs=function(Z)
        T[#T+1]=Z;
      end;
      d.Art=function(Z,Y)
        local j=d.ThumbMap and d.ThumbMap[a(Z)];
        Z=j and d.ThumbSheets[j[1]];
        if not Z then
          return Y;
        end
        Y=d.ThumbCell;
        return Z,Vector2.new(j[2]*Y,j[3]*Y),Vector2.new(Y,Y);
      end;
      d.Row=function(a)
        local Z,Y,j,q=a.image~=""and a.image~="rbxassetid://0"and a.image or nil;
        if not(a.g=="nullscape"and Z) then
          q,Y,j=d.Art(a.id,Z);
        else
          q=Z;
        end
        return{name=a.id,label=a.label,image=q,rect=Y,rectsize=j};
      end;
      d.LoadThumbs=function()
        local a=n;
        if a~="idle" then
          return;
        end
        n="loading";
        task.spawn(function()
          local a;
          local a=z;
          local Z=a.body("fxatlas/index.json");
          local Y,j=pcall(function()
            return game:GetService("HttpService"):JSONDecode(Z);
          end);
          a=not(Y and type(j)=="table"and type(j.map)=="table"and type(j.sheets)=="table");
          if a then
            n="idle";
            return;
          end
          local Z,q,D={},ipairs,j.sheets;
          for p,r in q(D)do
            local q;
            a=y[4][y[6]];
            if not a then
              return;
            end
            Y=z;
            Z[p]=Y.asset(r);
          end;
          d.ThumbMap,d.ThumbSheets,d.ThumbCell=j.map,Z,tonumber(j.cell)or 128;
          n="ready";
          for z,z in ipairs(T)do
            pcall(z);
          end;
        end);
      end;
      task.delay(12,function()
        local z;
        local z=y[4][y[6]];
        if z then
          d.LoadThumbs();
        end
      end);
      d.Busy=function(z)
        return m[z]~=nil;
      end;
      d.Worn=function(z)
        return l[z]~=nil;
      end;
      d.OnChange=function(z)
        s[#s+1]=z;
      end;
      task.spawn(function()
        while true do
          local s;
          local s=y[4][y[6]];
          if not s then
            break;
          end
          s=C();
          local z=s~=O;
          if z then
            table.clear(m);
            for z in pairs(l)do
              B(z);
            end;
            O=nil;
            if s then
              task.wait(0.5);
              local z=y[4][y[6]]and C()==s;
              if z then
                O=s;
                for s in pairs(J)do
                  e(s);
                end;
              end
            end
          else
            for s,y in pairs(l)do
              if not y.char.Parent then
                B(s);
              end
            end;
          end
          task.wait(0.5);
        end;
      end);
      G,P=L,H;
      G.ClearGameFX=P("gamefx",function()
        b=false;
        table.clear(m);
        for s in pairs(f)do
          pcall(d.Undress,s);
        end;
        table.clear(J);
        for s in pairs(l)do
          B(s);
        end;
        for s,s in pairs(N)do
          pcall(function()
            s:Destroy();
          end);
        end;
        table.clear(N);
      end);
    end;
  end;
end
