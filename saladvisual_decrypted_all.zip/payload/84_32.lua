-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #32
-- offset 3671631..3672878 (1247 bytes, type=payload)

function()
  while true do
    task.wait(0.5);
    local c,m=not l.Alive;
    if c then
      m=c;
    else
      local c;
      local c=T;
      local S=c.stage=="ready";
      if S then
        c=y;
        m=c.Status.stage~="fetching";
      else
        m=S;
      end
    end
    if m then
      break;
    end
  end;
  if not l.Alive then
    return;
  end
  local c;
  pcall(function()
    local m=isfile and isfile(K);
    if m then
      local m=game:GetService("HttpService"):JSONDecode(readfile(K));
      local S=type(m)=="table"and#m>0;
      if S then
        c=m;
      end
    end
  end);
  if c then
    s(c);
    table.sort(l.PackCatalog,function(c,m)
      return c.name<m.name;
    end);
    local c,m=pcall(function()
      return isfile(K..".time")and tonumber(readfile(K..".time"));
    end);
    if c and m and os.time()-m<86400 then
      return;
    end
  end
  local c,m={},ipairs;
  for S,S in m(r)do
    local r,m=pcall(function()
      local O=y;
      local B=O.download(S);
      return B~=""and game:GetService("HttpService"):JSONDecode(B)or nil;
    end);
    if r and type(m)=="table" then
      for r,r in pairs(type(m.data)=="table"and m.data or m)do
        if type(r)=="table"and r.id and type(r.bundledItems)=="table" then
          c[#c+1]=r;
        end
      end;
    end
  end;
  if not l.Alive or#c==0 then
    return;
  end
  l.PackCatalog={};
  o={};
  s(c);
  table.sort(l.PackCatalog,function(s,r)
    return s.name<r.name;
  end);
  pcall(function()
    writefile(K,game:GetService("HttpService"):JSONEncode(c));
    writefile(K..".time",tostring(os.time()));
  end);
end
