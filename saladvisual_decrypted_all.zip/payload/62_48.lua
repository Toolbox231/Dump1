-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #48
-- offset 3235012..3237143 (2131 bytes, type=payload)

local function h(_)
  local k=b.Pick and N[b.Pick];
  if not k then
    return;
  end
  local i,E;
  local R;
  for R=1,40,1 do
    R=_~=r or not(b.On and b.Pick);
    if R then
      return;
    end
    R=T;
    i=R.Character;
    E=i and(i:FindFirstChild("HumanoidRootPart"));
    if E then
      break;
    end
    task.wait(0.25);
  end;
  if not i or not E then
    return;
  end
  local R,g=i:FindFirstChildOfClass("Humanoid"),B(k);
  local u;
  local u,lP=not z[4][z[6]]or not b.On or _~=r;
  if u then
    lP=u;
  else
    _=T;
    lP=_.Character~=i;
  end
  if lP or not i.Parent or not E.Parent then
    return;
  end
  _=not g;
  if _ then
    local zP;
    lP=d;
    local zP,TP=lP.new,{Title="Models"};
    TP.Content,TP.Duration="Could not load "..k.Name,4;
    zP(TP);
    return;
  end
  local zP=g:Clone();
  if not zP then
    return;
  end
  u=y;
  _=u.BodyExtents(i,E);
  g,lP,u=_ and _.half*2 or Vector3.new(3,5,2),zP:GetBoundingBox();
  if u.Y>0.01 then
    _=math.clamp(tonumber(b.Sizes[k.Name])or 1,0.35,1.25);
    local lP=g.Y/u.Y*_;
    if math.abs(lP-1)>0.02 then
      pcall(function()
        zP:ScaleTo(zP:GetScale()*lP);
      end);
    end
  end
  g,_=zP:GetBoundingBox();
  local u=(zP:GetPivot():Inverse()*g):Inverse();
  local g=_.Y*0.5-E.Size.Y*0.5-(R and R.HipHeight or 0);
  zP.Name="VisualsModelShell";
  local _;
  R=P;
  R.DepthTree(zP,false);
  local _={};
  for R,R in ipairs(zP:GetDescendants())do
    if R:IsA("BasePart") then
      _[#_+1]={R,R.LocalTransparencyModifier};
    end
  end;
  zP.Parent=workspace;
  m=zP;
  LP(i);
  local R,lP;
  local TP,nP=0;
  local JP,HP=i.DescendantAdded:Connect(function()
    local fP=z[4][z[6]]and b.On and m;
    if fP then
      TP=0;
    end
  end),n;
  HP:AddSignal(JP);
  local function fP()
    JP:Disconnect();
  end
  zP.Destroying:Once(fP);
  HP=J;
  S=HP.RenderStepped:Connect(function()
    local S=z[4][z[6]]and b.On and m and m.Parent;
    if not S then
      return;
    end
    if not E.Parent then
      return;
    end
    S=y;
    local zP,zP=P,S.Visibility.Character(P.camera(),i,E);
    S=nP~=zP;
    if S then
      nP=zP;
      for P,P in ipairs(_)do
        if P[1].Parent then
          P[1].LocalTransparencyModifier=zP and P[2]or 1;
        end
      end;
    end
    local P,_,nP=E.CFrame,b.Rotations[k.Name]or 0,os.clock()>=TP;
    if nP then
      TP=os.clock()+0.2;
      LP(i);
    end
    nP=R==P and lP==_;
    if nP then
      return;
    end
    R,lP=P,_;
    S,zP,nP=P.LookVector,P.Position,m;
    nP:PivotTo(CFrame.new(zP.X,zP.Y+g,zP.Z)*CFrame.fromEulerAnglesYXZ(0,math.atan2(-S.X,-S.Z)+math.rad(_),0)*u);
  end);
end
