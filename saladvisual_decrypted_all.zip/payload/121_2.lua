-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[121] / function #2
-- offset 148595..151882 (3287 bytes, type=payload)

function()
  local l;
  local l=L;
  if not l.ScreenGui.Parent then
    return;
  end
  local L;
  l=y;
  local L,c=l.Enabled;
  if L then
    l=y;
    local m,S=l.Box;
    if m then
      S=m;
    else
      local O=y;
      S=O.Name;
    end
    m=nil;
    if S then
      m=S;
    else
      local O=y;
      m=O.Distance;
    end
    S=nil;
    if m then
      S=m;
    else
      local O=y;
      S=O.Skeleton;
    end
    m=nil;
    if S then
      m=S;
    else
      local S=y;
      m=S.Arrows;
    end
    c=m;
  else
    c=L;
  end
  L=nil;
  if c then
    L=c;
  else
    l=y;
    L=l.Chams;
  end
  l=nil;
  if L then
    l=L;
  else
    local m=y;
    l=m.MatChams;
  end
  L=nil;
  if l then
    L=l;
  else
    local m=y;
    L=m.ItemChams;
  end
  local m,S,S,S=not L;
  if m then
    L=z[4][z[6]];
    if L then
      z[4][z[6]]=false;
      local S,O=ipairs,T;
      l=s[70](O:GetPlayers());
      for B,B in S(s:ZT(l))do
        local S;
        O=n;
        pcall(O,B);
      end;
      table.clear(J);
      local n;
      table.clear(H);
    end
    return;
  end
  z[4][z[6]]=true;
  local z=workspace.CurrentCamera;
  f[4][f[6]]=z;
  m=f[4][f[6]];
  if not m then
    return;
  end
  local z;
  local z,n=a[4][a[6]]>30;
  if z then
    m,l=os.clock(),d[4][d[6]];
    if m<l then
      return;
    end
    a[4][a[6]]=0;
  end
  z,L=pcall(function()
    local n;
    P[4][P[6]]+=1;
    local n,H=ipairs,T;
    local T=s[70](H:GetPlayers());
    for P,S in n(s:ZT(T))do
      local s;
      P=Z;
      local s,T=S==P,S.Character;
      H,P=T and(T:FindFirstChild("HumanoidRootPart")),T and(T:FindFirstChildWhichIsA("Humanoid"));
      local n,Z=H and P and P.Health>0;
      local Z,O=G,y;
      local G,B,B=O.Chams and n;
      if G then
        O,P=Y,y;
        B=O(P.ChamsTarget,s);
      else
        B=G;
      end
      Z(S,T,B);
      local A;
      P,Z=e,y;
      O,G=Z.MatChams and n;
      if O then
        Z,B=Y,y;
        G=Z(B.ChamsTarget,s);
      else
        G=O;
      end
      P(S,T,G);
      local e;
      G,Z=j,y;
      O,P=Z.ItemChams and n;
      if O then
        Z,B=Y,y;
        P=Z(B.ItemTarget,s);
      else
        P=O;
      end
      G(S,T,P);
      local e,j,j=not c;
      if e then
        P=J;
        G=P[S];
        B=G and G.DrawActive;
        if B then
          G.DrawActive=false;
          Z=C;
          Z(G);
          O=N;
          O(G);
          if G.arrow.Visible then
            G.arrow.Visible=false;
          end
        end
        continue;
      end
      local J;
      B=q;
      P=B(S);
      P.DrawActive=true;
      O=y;
      B,G=O.Enabled and n;
      if B then
        O,Z=Y,y;
        G=O(Z.Target,s);
      else
        G=B;
      end
      e=nil;
      if G then
        local J;
        B=b;
        e=B.Visibility.Character(f[4][f[6]],T,H);
      else
        e=G;
      end
      G,B,Z,n=nil;
      if e then
        O=y;
        local J,Y=O.Box;
        if J then
          Y=J;
        else
          local j=y;
          Y=j.Name;
        end
        if Y then
          n=Y;
        else
          J=y;
          n=J.Distance;
        end
      else
        n=e;
      end
      if n then
        local J;
        O=D;
        G,B,Z=O(T);
      else
      end
      if not e then
        P.arrow.Visible=false;
      end
      n=nil;
      if e then
        O=y;
        n=O.Skeleton;
      else
        n=e;
      end
      if n then
        local J;
        O=p;
        O(P,T);
      else
        local J=C;
        J(P);
      end
      O=nil;
      if e then
        n=y;
        O=n.Arrows;
      else
        O=e;
      end
      T=O and H and not s;
      if T then
        O=f[4][f[6]]:WorldToViewportPoint(H.Position);
        s=O.Z>0 and O.X>=0 and O.X<=f[4][f[6]].ViewportSize.X and O.Y>=0 and O.Y<=f[4][f[6]].ViewportSize.Y;
        if s then
          P.arrow.Visible=false;
        else
          local J;
          n=r;
          n(P,H);
        end
      else
        P.arrow.Visible=false;
      end
      T=nil;
      if e then
        n=y;
        T=n.Box;
      else
        T=e;
      end
      O=T and G;
      if O then
        local J;
        T=K;
        T(P,G,B,Z);
      else
        n=N;
        n(P);
      end
      T=nil;
      if e then
        n=y;
        Z=n.Name;
        if Z then
          T=Z;
        else
          s=y;
          T=s.Distance;
        end
      else
        T=e;
      end
      O=T and G;
      if O then
        Z=y;
        n,T=Z.Distance and H and math.round((H.Position-f[4][f[6]].CFrame.Position).Magnitude)or nil,y;
        e=T.Name and S.DisplayName or"";
        if P.nameDist~=n or P.nameFor~=e then
          P.nameDist=n;
          P.nameFor=e;
          local T,J=P.name,n and(e~=""and e.."  "..n.."m"or n.."m");
          T.Text=J or e;
        end
        s=nil;
        s,P.name.Color=y,y.NameColor;
        P.name.Position=Vector2.new(G.X+B.X/2,G.Y-16);
        P.name.Visible=true;
      else
        P.name.Visible=false;
      end
    end;
  end);
  if z then
    a[4][a[6]]=0;
  else
    a[4][a[6]]+=1;
    d[4][d[6]]=os.clock()+2;
    m=a[4][a[6]]==1;
    if m then
      local s;
      l=o;
      l("render: "..tostring(L));
      warn("[visuals] render loop: "..tostring(L));
    end
  end
end
