-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[5] / function #9
-- offset 39217..41851 (2634 bytes, type=payload)

function(L)
  local y=s.Character;
  local s=y and(y:FindFirstChild("Head"));
  if not s or not s:IsA("BasePart")or not L then
    N.visible(false);
    return;
  end
  local e,j,q,b=s.Position,L.CFrame,L.FieldOfView,L.ViewportSize;
  local D,p=b.X,b.Y;
  y=N.head==s and N.pos==e and N.cf==j and N.headSize==s.Size and N.fov==q and N.vx==D and N.vy==p and N.col==d;
  if y then
    return;
  end
  N.head=s;
  N.pos=e;
  N.cf=j;
  N.headSize=s.Size;
  b=nil;
  b,N.fov,N.vx,N.vy=d,q,D,p;
  N.col=b;
  local r,K,o,c,m=N.px,N.py,N.cos,N.sin,e.Y+s.Size.Y*0.5-G;
  b=Vector3.new(e.X,m,e.Z);
  m=L:WorldToViewportPoint(b+Vector3.new(0,Z,0));
  if m.Z<=0 then
    N.visible(false);
    return;
  end
  e=L:WorldToViewportPoint(b+Vector3.new(o[1],0,c[1]));
  if e.Z<=0 then
    N.visible(false);
    return;
  end
  r[1],K[1]=m.X,m.Y;
  r[2],K[2]=e.X,e.Y;
  local G,S,O,B=j.Position,j.RightVector,j.UpVector,j.LookVector;
  j,y,s=b.X-G.X,b.Y-G.Y,b.Z-G.Z;
  local A,w,F,h,W,V,_,X,x,k,v,I,i,E=j*S.X+y*S.Y+s*S.Z,j*O.X+y*O.Y+s*O.Z,j*B.X+y*B.Y+s*B.Z,S.X,S.Z,O.X,O.Z,B.X,B.Z,p*0.5/math.tan(math.rad(q*0.5)),D*0.5,p*0.5,N.eps,false;
  s=F+Z*B.Y;
  if s>0 then
    B=k/s;
    if math.abs(v+(A+Z*S.Y)*B-m.X)<=i and math.abs(I-(w+Z*O.Y)*B-m.Y)<=i then
      D,y=o[1],c[1];
      s=F+D*X+y*x;
      if s>0 then
        B=k/s;
        E=if math.abs(v+(A+D*h+y*W)*B-e.X)<=i and math.abs(I-(w+D*V+y*_)*B-e.Y)<=i then true else E;
      else
      end
    else
    end
  else
  end
  if E then
    for Z=2,Y,1 do
      B,q=o[Z],c[Z];
      O=F+B*X+q*x;
      if O<=0 then
        N.visible(false);
        return;
      end
      i=k/O;
      r[Z+1]=v+(A+B*h+q*W)*i;
      K[Z+1]=I-(w+B*V+q*_)*i;
    end;
  else
    for Z=2,Y,1 do
      G=L:WorldToViewportPoint(b+Vector3.new(o[Z],0,c[Z]));
      if G.Z<=0 then
        N.visible(false);
        return;
      end
      r[Z+1]=G.X;
      K[Z+1]=G.Y;
    end;
  end
  I=N.hull(Y+1);
  if I<3 then
    N.visible(false);
    return;
  end
  k,h,S=N.stack,1/0,-1/0;
  for Z=1,I,1 do
    i=K[k[Z]];
    h,S=if i<h then i else h,if i>S then i else S;
  end;
  e,s=math.max(0,math.floor(h)),math.min(p,math.ceil(S));
  if s-e<2 then
    N.visible(false);
    return;
  end
  X,L,j,V,b,c,O,x,F,A,i=math.max(1,math.ceil((s-e)/C)),math.max(1,S-h),N.rows,N.shown,N.cpos,N.csize,N.ccol,N.white,N.black,s-1,0;
  for Z=e,A,X do
    v=math.min(X,s-Z);
    S,w,D,y,W=Z+v*0.5,K[k[I]],r[k[I]],1/0,-1/0;
    for s=1,I,1 do
      B=k[s];
      p,m=r[B],K[B];
      if w<=S and m>S or m<=S and w>S then
        o=D+(S-w)*(p-D)/(m-w);
        y,W=if o<y then o else y,if o>W then o else W;
      else
      end
      w,D=m,p;
    end;
    _=W-y;
    G=_>=2.5;
    if G then
      i+=1;
      local s,G=N.row(i),(S-h)/L;
      local L,Y,e=1-G*1.35,(G-0.58)/0.42,d;
      local G,C,q=e:Lerp(x,(if L<0 then 0 else L)*0.26):Lerp(F,(if Y<0 then 0 else Y)*0.1),Vector2.new(y,Z),Vector2.new(_,v);
      if b[i]~=C then
        s.Position=C;
        b[i]=C;
      end
      if c[i]~=q then
        s.Size=q;
        c[i]=q;
      end
      if O[i]~=G then
        s.Color=G;
        O[i]=G;
      end
      if not V[i] then
        s.Visible=true;
        V[i]=true;
      end
    else
    end
  end;
  for s=i+1,#j,1 do
    if V[s] then
      j[s].Visible=false;
      V[s]=false;
    end
  end;
end
