-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #97
-- offset 132545..132773 (228 bytes, type=payload)

function(x)
  if x==Enum.AssetFetchStatus.Success then
    p:Disconnect();
    F[_]=nil;
  elseif x==Enum.AssetFetchStatus.Failure or x==Enum.AssetFetchStatus.TimedOut then
    p:Disconnect();
    F[_]=nil;
    A[_]=true;
    for A in pairs(X)do
      V(A);
    end;
  end
end
