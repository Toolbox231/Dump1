-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #474
-- offset 3446309..3447036 (727 bytes, type=payload)

local function VP(XP,uP)
  local UP={};
  XP=s[87]();
  uP=uP and l[383]or l[1329];
  if lC[l[404]]==uP then
    return;
  end
  lC[l[404]]=uP;
  if uP then
    V();
    local V,uP,nC,JC=G(YP),e(YP),G(kP),e(kP);
    local G,kP=uP[l[636]]-(nC[l[636]]-V[l[636]]+JC[l[636]]+l[1158])-l[1158],nC[l[636]]-V[l[636]]-l[310];
    lC[l[771]]=G<_P and kP>G;
    QP[l[1016]]=XP[l[1689]][l[772]](l[393],lC[l[771]]and l[229]or l[393]);
    QP[l[1639]]=XP[l[1459]][l[588]](aP,_P);
    QP[l[1324]]=l[383];
    iP[l[1324]]=l[383];
    if EP then
      EP[l[1016]]=QP[l[1016]];
      EP[l[1639]]=QP[l[1639]];
      EP[l[1324]]=l[383];
    end
    FP();
    A,w=RP,QP;
    vP();
    UP[1]=(y[10][l[1119]]:Connect(gP));
    GP=UP[1];
  else
    vP();
    iP[l[1324]]=l[1329];
    local G=A==RP;
    if G then
      A,w=nil,nil;
    end
    if MP:IsFocused() then
      MP:ReleaseFocus();
    end
  end
  BP();
  xP();
end
