-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[5] / function #0
-- offset 37400..42540 (5140 bytes, type=payload)

function(s,s,s,s)
  return function(s,s,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    local f=s[9];
    return function()
      local s;
      local s,a=l,false;
      local d,P,Z,G,Y,e,j,C=Color3.fromRGB(170,85,255),1.55,0.82,0.02,48,6.283185307179586,0.72,220;
      local N={rows={},px=table.create(Y+1),py=table.create(Y+1),cos=table.create(Y),sin=table.create(Y),ord=table.create(Y+1),stack=table.create(Y+2),shown={},cpos={},csize={},ccol={},white=Color3.new(1,1,1),black=Color3.new(0,0,0),eps=0.75};
      for q=1,Y,1 do
        local b=(q-1)/Y*e;
        N.cos[q]=math.cos(b)*P;
        N.sin[q]=math.sin(b)*P;
      end;
      N.order=function(e,q)
        local b,D=N.px,N.py;
        local p,r=b[e],b[q];
        return p==r and D[e]<D[q]or p<r;
      end;
      N.hull=function(e)
        local q,b,D,p=N.px,N.py,N.ord,N.stack;
        for r=1,e,1 do
          D[r]=r;
        end;
        table.sort(D,N.order);
        local r=0;
        for K=1,e,1 do
          local o=D[K];
          local K,c=q[o],b[o];
          while r>=2 do
            local m,S=p[r-1],p[r];
            local O,B=q[m],b[m];
            if (q[S]-O)*(c-B)-(b[S]-B)*(K-O)>0 then
              break;
            end
            r-=1;
          end;
          r+=1;
          p[r]=o;
        end;
        for K=e-1,1,-1 do
          local e=D[K];
          local D,K=q[e],b[e];
          while r>r do
            local o,c=p[r-1],p[r];
            local m,S=q[o],b[o];
            if (q[c]-m)*(K-S)-(b[c]-S)*(D-m)>0 then
              break;
            end
            r-=1;
          end;
          r+=1;
          p[r]=e;
        end;
        return r-1;
      end;
      N.visible=function(e)
        local q,b=N.rows,N.shown;
        for D=1,#q,1 do
          if b[D]~=e then
            q[D].Visible=e;
            b[D]=e;
          end
        end;
      end;
      N.clear=function()
        local e=N.rows;
        local q=#e;
        for b=1,q,1 do
          local q;
          local q=L;
          q(e[b]);
        end;
        table.clear(e);
        table.clear(N.shown);
        table.clear(N.cpos);
        table.clear(N.csize);
        table.clear(N.ccol);
        N.head=nil;
        N.pos=nil;
        N.cf=nil;
        N.fov=nil;
        N.vx=nil;
        N.vy=nil;
        N.col=nil;
      end;
      N.build=function()
        N.clear();
      end;
      N.row=function(L)
        local e=N.rows;
        local q=e[L];
        if q then
          return q;
        end
        local b;
        local b=y;
        q=b("Square");
        q.Filled=true;
        q.Thickness=0;
        q.Transparency=j;
        q.Visible=false;
        q.ZIndex=1;
        e[L]=q;
        N.shown[L]=false;
        return q;
      end;
      N.update=function(L)
        local y=s.Character;
        local s=y and(y:FindFirstChild("Head"));
        if not s or not s:IsA("BasePart")or not L then
          N.visible(false);
          return;
        end
        local e,j,q,b=s.Position,L.CFrame,L.FieldOfView,L.ViewportSize;
        local D,p=b.X,b.Y;
        y=N.head==s and N.pos==e and N.cf==j and N.headSize==s.Size and N.fov==q and N.vx==D and N.vy==p and N.col==d;
        if y then
          return;
        end
        N.head=s;
        N.pos=e;
        N.cf=j;
        N.headSize=s.Size;
        b=nil;
        b,N.fov,N.vx,N.vy=d,q,D,p;
        N.col=b;
        local r,K,o,c,m=N.px,N.py,N.cos,N.sin,e.Y+s.Size.Y*0.5-G;
        b=Vector3.new(e.X,m,e.Z);
        m=L:WorldToViewportPoint(b+Vector3.new(0,Z,0));
        if m.Z<=0 then
          N.visible(false);
          return;
        end
        e=L:WorldToViewportPoint(b+Vector3.new(o[1],0,c[1]));
        if e.Z<=0 then
          N.visible(false);
          return;
        end
        r[1],K[1]=m.X,m.Y;
        r[2],K[2]=e.X,e.Y;
        local G,S,O,B=j.Position,j.RightVector,j.UpVector,j.LookVector;
        j,y,s=b.X-G.X,b.Y-G.Y,b.Z-G.Z;
        local A,w,F,h,W,V,_,X,x,k,v,I,i,E=j*S.X+y*S.Y+s*S.Z,j*O.X+y*O.Y+s*O.Z,j*B.X+y*B.Y+s*B.Z,S.X,S.Z,O.X,O.Z,B.X,B.Z,p*0.5/math.tan(math.rad(q*0.5)),D*0.5,p*0.5,N.eps,false;
        s=F+Z*B.Y;
        if s>0 then
          B=k/s;
          if math.abs(v+(A+Z*S.Y)*B-m.X)<=i and math.abs(I-(w+Z*O.Y)*B-m.Y)<=i then
            D,y=o[1],c[1];
            s=F+D*X+y*x;
            if s>0 then
              B=k/s;
              E=if math.abs(v+(A+D*h+y*W)*B-e.X)<=i and math.abs(I-(w+D*V+y*_)*B-e.Y)<=i then true else E;
            else
            end
          else
          end
        else
        end
        if E then
          for Z=2,Y,1 do
            B,q=o[Z],c[Z];
            O=F+B*X+q*x;
            if O<=0 then
              N.visible(false);
              return;
            end
            i=k/O;
            r[Z+1]=v+(A+B*h+q*W)*i;
            K[Z+1]=I-(w+B*V+q*_)*i;
          end;
        else
          for Z=2,Y,1 do
            G=L:WorldToViewportPoint(b+Vector3.new(o[Z],0,c[Z]));
            if G.Z<=0 then
              N.visible(false);
              return;
            end
            r[Z+1]=G.X;
            K[Z+1]=G.Y;
          end;
        end
        I=N.hull(Y+1);
        if I<3 then
          N.visible(false);
          return;
        end
        k,h,S=N.stack,1/0,-1/0;
        for Z=1,I,1 do
          i=K[k[Z]];
          h,S=if i<h then i else h,if i>S then i else S;
        end;
        e,s=math.max(0,math.floor(h)),math.min(p,math.ceil(S));
        if s-e<2 then
          N.visible(false);
          return;
        end
        X,L,j,V,b,c,O,x,F,A,i=math.max(1,math.ceil((s-e)/C)),math.max(1,S-h),N.rows,N.shown,N.cpos,N.csize,N.ccol,N.white,N.black,s-1,0;
        for Z=e,A,X do
          v=math.min(X,s-Z);
          S,w,D,y,W=Z+v*0.5,K[k[I]],r[k[I]],1/0,-1/0;
          for s=1,I,1 do
            B=k[s];
            p,m=r[B],K[B];
            if w<=S and m>S or m<=S and w>S then
              o=D+(S-w)*(p-D)/(m-w);
              y,W=if o<y then o else y,if o>W then o else W;
            else
            end
            w,D=m,p;
          end;
          _=W-y;
          G=_>=2.5;
          if G then
            i+=1;
            local s,G=N.row(i),(S-h)/L;
            local L,Y,e=1-G*1.35,(G-0.58)/0.42,d;
            local G,C,q=e:Lerp(x,(if L<0 then 0 else L)*0.26):Lerp(F,(if Y<0 then 0 else Y)*0.1),Vector2.new(y,Z),Vector2.new(_,v);
            if b[i]~=C then
              s.Position=C;
              b[i]=C;
            end
            if c[i]~=q then
              s.Size=q;
              c[i]=q;
            end
            if O[i]~=G then
              s.Color=G;
              O[i]=G;
            end
            if not V[i] then
              s.Visible=true;
              V[i]=true;
            end
          else
          end
        end;
        for s=i+1,#j,1 do
          if V[s] then
            j[s].Visible=false;
            V[s]=false;
          end
        end;
      end;
      local s;
      local s,L=z;
      P=T;
      s:AddSignal(P.RenderStepped:Connect(function()
        local L=a;
        if not L then
          return;
        end
        N.update(workspace.CurrentCamera);
      end));
      s,P=z,l;
      s:AddSignal(P.CharacterAdded:Connect(function()
        task.wait(0.4);
        local l;
        local l=n[4][n[6]]and a;
        if l then
          N.build();
        end
      end));
      local l;
      P=J;
      s=P.Extras:AddLabel("China Hat");
      s:AddToggle({Name="China Hat",Default=false,Flag="china_hat",Callback=function(l)
        a=l;
        if l then
          N.build();
        else
          N.clear();
        end
      end});
      s:AddColorPicker({Default=d,Flag="china_hat_color",Callback=function(l)
        d=l;
      end});
      local l;
      s=H;
      s.ChinaHat={On=function()
        local l=a;
        return l;
      end};
      local l,L=H;
      s=f;
      l.ClearChinaHat=s("chinahat",function()
        a=false;
        pcall(N.clear);
      end);
    end;
  end;
end
