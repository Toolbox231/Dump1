-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #32
-- offset 3657947..3658669 (722 bytes, type=payload)

local function T()
  r+=1;
  local H=r;
  S();
  s();
  local j;
  local j=z[4][z[6]]and N.On;
  if not j then
    return;
  end
  local O;
  j=n;
  local O=j.Character;
  if not O then
    return;
  end
  task.defer(function()
    local j=ipairs;
    for F,V in j(l)do
      F=N.Types[V];
      if F then
        local F,x,k=y[V],H~=r or not z[4][z[6]]or not N.On;
        if x then
          k=x;
        else
          local v=n;
          k=v.Character~=O;
        end
        if k then
          return;
        end
        if F then
          local v,I,i,Q=#b.particles+1,#b.accents+1,pcall(F,O,H);
          k=not i and H==r;
          if k then
            N.LoadErrors[V]=tostring(Q);
            local O;
            x=f;
            x("aura "..V..": "..tostring(Q));
          end
          Q=i and H==r;
          if Q then
            N.ReadyTypes[V]=true;
            w(b,v,I);
          end
        end
      end
    end;
    local f;
    local f,O=a;
    if f then
      j=a;
      O=j.ReadAura;
    else
      O=f;
    end
    f=O and z[4][z[6]]and H==r;
    if f then
      pcall(a.ReadAura);
    end
  end);
end
