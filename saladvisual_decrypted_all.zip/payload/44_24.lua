-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #24
-- offset 3620645..3621451 (806 bytes, type=payload)

function(L,z)
  local P;
  local P=T;
  if L==P then
    return;
  end
  if type(z)~="table"or not Z[tostring(z.s)] then
    s.Undress(L);
    return;
  end
  local T,q=pcall(Color3.fromHex,tostring(z.a));
  local D,p=pcall(Color3.fromHex,tostring(z.b));
  P={Style=tostring(z.s),Color=T and q or s.Color,Color2=D and p or s.Color2,Rainbow=z.r==true,Size=math.clamp(tonumber(z.z)or 10,1,40),Life=math.clamp(tonumber(z.l)or 0.9,0.1,5),Rate=math.clamp(tonumber(z.n)or 140,1,600),Bright=math.clamp(tonumber(z.g)or 85,1,100),Amount=math.clamp(tonumber(z.m)or 100,1,400),Spread=100,Gravity=100,Always=z.w==true};
  P.key=table.concat({P.Style,tostring(z.a),tostring(z.b),tostring(P.Rainbow),P.Size,P.Life,P.Rate,P.Bright,P.Amount,tostring(P.Always)},"|");
  if o[L]and o[L].key==P.key then
    return;
  end
  o[L]=P;
  if L.Character then
    pcall(c,L.Character);
  end
end
