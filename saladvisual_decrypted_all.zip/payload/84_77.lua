-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #77
-- offset 3682318..3687751 (5433 bytes, type=payload)

local function B(A,w,F,h)
  local W=Instance.new("ScrollingFrame");
  W.Name="AnimationCatalog";
  W.Size=UDim2.new(1,-8,0,w);
  W.BackgroundColor3=Color3.fromRGB(13,14,18);
  W.ZIndex=20;
  W.BorderSizePixel=0;
  W.ScrollBarThickness=4;
  W.ScrollBarImageColor3=T;
  W.CanvasSize=UDim2.new();
  W.ClipsDescendants=true;
  W.Parent=A;
  W.LayoutOrder=F;
  Instance.new("UICorner",W).CornerRadius=UDim.new(0,6);
  local V=Instance.new("TextLabel");
  V.Name="Empty";
  V.Text="No matching results";
  V.Size,V.Position=UDim2.new(1,-16,0,48),UDim2.fromOffset(8,16);
  V.BackgroundTransparency=1;
  V.TextTransparency=0.35;
  V.Font=Enum.Font.Gotham;
  V.TextSize=12;
  V.TextColor3=c;
  V.ZIndex=21;
  V.Parent=W;
  local _,X,x,k={},{},{};
  local v,I,i=true,false,{Frame=W};
  local function E()
    for Q,t in pairs(x)do
      if Q.Parent then
        Q.ScrollingEnabled=t;
      end
      x[Q]=nil;
    end;
  end
  local function x()
    local Q=I or not l.Alive or not W.Parent;
    if Q then
      return false;
    end
    Q=W;
    while Q do
      if Q:IsA("GuiObject")and not Q.Visible then
        return false;
      end
      if Q:IsA("ScreenGui") then
        return Q.Enabled;
      end
      Q=Q.Parent;
    end;
    return false;
  end
  local function Q()
    local t=Instance.new("TextButton");
    t.Name="CatalogCard";
    t.ClipsDescendants=true;
    t.BackgroundColor3=r;
    t.BorderSizePixel=0;
    t.ZIndex=21;
    t.AutoButtonColor=false;
    t.Text="";
    Instance.new("UICorner",t).CornerRadius=UDim.new(0,6);
    local R=Instance.new("UIStroke",t);
    R.Color=m;
    R.Thickness=1;
    R.Transparency=0.45;
    local g,u=Instance.new("UIScale",t),Instance.new("ImageLabel",t);
    u.Name="Thumb";
    u.ZIndex=22;
    u.BackgroundTransparency=1;
    u.ScaleType=Enum.ScaleType.Fit;
    u.Size,u.Position=UDim2.new(1,-16,0,D-44),UDim2.fromOffset(8,7);
    local U=Instance.new("TextLabel",t);
    U.Name="Title";
    U.ZIndex=23;
    U.BackgroundTransparency=1;
    local M=n;
    U.FontFace=M.BuiltInRegular;
    U.TextSize=12;
    U.TextColor3=c;
    U.TextWrapped,U.TextTruncate=false,Enum.TextTruncate.AtEnd;
    U.TextXAlignment=Enum.TextXAlignment.Center;
    U.Size,U.Position=UDim2.new(1,-10,0,16),UDim2.fromOffset(5,D-26);
    M=Instance.new("TextLabel",t);
    M.Name,M.Text,M.Font="Favorite","\226\152\133",Enum.Font.GothamBold;
    M.ZIndex=24;
    M.TextSize=17;
    M.BackgroundTransparency=1;
    M.TextColor3=Color3.fromRGB(255,211,104);
    M.TextTransparency=1;
    M.Position,M.Size=UDim2.fromOffset(5,3),UDim2.fromOffset(20,20);
    local sP=Instance.new("Frame",t);
    sP.Name="ActiveDot";
    sP.ZIndex=24;
    sP.BorderSizePixel=0;
    sP.AnchorPoint,sP.Position=Vector2.new(1,0),UDim2.new(1,-7,0,8);
    sP.Size=UDim2.fromOffset(7,7);
    sP.BackgroundColor3=T;
    sP.BackgroundTransparency=1;
    Instance.new("UICorner",sP).CornerRadius=UDim.new(1,0);
    local T={card=t,img=u,label=U,stroke=R,scale=g,dot=sP,star=M,active=0,hover=0,favorite=0,pulse=0};
    local function R()
      T.hovered=true;
    end
    t.MouseEnter:Connect(R);
    local function R()
      T.hovered=false;
    end
    t.MouseLeave:Connect(R);
    local function R()
      if not T.entry or not x() then
        return;
      end
      local g,u=T.entry,T.key;
      T.pulse=1;
      h.onClick(g,u);
    end
    t.MouseButton1Click:Connect(R);
    local function R()
      if T.entry and x()and h.onFav then
        h.onFav(T.entry,T.key);
      end
    end
    t.MouseButton2Click:Connect(R);
    return T;
  end
  i.refresh=function()
    local T=I;
    if T then
      return;
    end
    v=false;
    T=h.getList()or{};
    local t,R=#T,D+p;
    local g=math.ceil(t/b);
    local u=math.max(0,g*R+p);
    if W.CanvasSize.Y.Offset~=u then
      W.CanvasSize=UDim2.fromOffset(0,u);
    end
    V.Visible=t==0;
    local V,U=math.max(40,(W.AbsoluteSize.X-W.ScrollBarThickness-p*(b+1))/b),{};
    for M=math.max(0,math.floor((W.CanvasPosition.Y-p)/R)-1),math.min(g-1,math.floor((W.CanvasPosition.Y+math.max(W.AbsoluteSize.Y,w))/R)+1),1 do
      for w=0,b-1,1 do
        u=M*b+w+1;
        if u<=t then
          U[u]={M,w};
        end
      end;
    end;
    for b,w in pairs(X)do
      if not U[b] then
        w.card.Visible=false;
        w.hovered=false;
        w.entry=nil;
        w.key=nil;
        _[#_+1]=w;
        X[b]=nil;
      end
    end;
    for b,w in pairs(U)do
      g=X[b]or table.remove(_)or Q();
      X[b]=g;
      u,t=T[b],h.keyOf(T[b]);
      b=t~=g.key;
      if b then
        g.active=t==k and 1 or 0;
        g.hover=0;
        g.favorite=0;
        g.pulse=0;
        g.accent=nil;
        g.hovered=false;
        g.img.Image,g.label.Text=h.imageOf(u),h.nameOf(u);
      end
      g.entry=u;
      g.key=t;
      g.card.Parent,g.card.Visible=W,true;
      g.card.Size=UDim2.fromOffset(V,D);
      g.card.Position=UDim2.fromOffset(p+w[2]*(V+p),p+w[1]*R);
    end;
  end;
  i.select=function(T)
    k=T;
  end;
  i.queue=function(T)
    local b=I;
    if b then
      return;
    end
    v=true;
    if T then
      W.CanvasPosition=Vector2.zero;
    end
  end;
  i.step=function(T)
    if not x() then
      E();
      return;
    end
    local b=v;
    if b then
      i.refresh();
    end
    local D,p=1-math.exp(-18*math.min(T,0.1)),pairs;
    for w,V in p(X)do
      b,w=V.key==k,h.isFav and h.isFav(V.entry)and 1 or 0;
      local p,_,X,x,k=O(V.active,b and 1 or 0,D),O(V.hover,V.hovered and 1 or 0,D),O(V.favorite,w,D),O(V.pulse,0,D),n;
      T=k.AccentColor;
      if p==V.active and _==V.hover and X==V.favorite and x==V.pulse and V.accent==T then
        continue;
      end
      V.active=p;
      V.hover=_;
      V.favorite=X;
      V.pulse=x;
      V.accent=T;
      V.card.BackgroundColor3=r:Lerp(K,V.hover*0.7):Lerp(o,V.active);
      V.stroke.Color=m:Lerp(T,V.active);
      V.stroke.Thickness=1+V.active;
      V.stroke.Transparency=0.45*(1-V.active);
      V.label.TextColor3=c:Lerp(T,V.active);
      V.dot.BackgroundColor3,V.dot.BackgroundTransparency=T,1-V.active;
      V.star.TextTransparency=1-V.favorite;
      V.star.Rotation=-15*(1-V.favorite);
      V.scale.Scale=1-V.pulse*0.025;
    end;
  end;
  local function T()
    i.queue();
  end
  W:GetPropertyChangedSignal("CanvasPosition"):Connect(T);
  local function b()
    i.queue();
  end
  W:GetPropertyChangedSignal("AbsoluteSize"):Connect(b);
  W.MouseLeave:Connect(E);
  W.Destroying:Connect(function()
    I=true;
    E();
  end);
  local b;
  F=H;
  local function b(D)
    if not D then
      E();
    else
      i.queue();
    end
  end
  F.Signal:Connect(b);
  if h.tab then
    A,T=h.tab,function(b)
      if not b then
        E();
      else
        i.queue();
      end
    end;
    A.Signal:Connect(T);
  end
  S[#S+1]=i;
  return i;
end
