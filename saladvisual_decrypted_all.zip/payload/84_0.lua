-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #0
-- offset 3664085..3696048 (31963 bytes, type=payload)

function(s,l,l,l)
  return function(l,l,L)
    local L=l[1];
    local y=l[2];
    local z=l[3];
    local T=l[4];
    local n=l[5];
    local J=l[6];
    local H=l[7];
    local f=l[8];
    local a=l[9];
    local d=l[10];
    local P=l[11];
    local Z=l[12];
    local G=l[13];
    local Y=l[14];
    return function()
      local l,e={EmoteLoop=false,EmoteSpeed=100,Alive=true,_request=0,PackName="Default"};
      local e=L;
      e("animations",function()
        if l.Destroy then
          l.Destroy();
        else
          l.Alive=false;
          l._request=l._request+1;
        end
      end);
      local function j(C)
        local N=tostring(C or""):gsub("[_]+"," "):gsub("%s+"," "):match("^%s*(.-)%s*$")or"";
        if N==""or N:match("^%[%d+%]$") then
          return"Untitled";
        end
        return(N:gsub("(%a[%w']*)",function(C)
          if C:match("^%l")and not C:match("%u") then
            return C:sub(1,1):upper()..C:sub(2);
          end
          return C;
        end));
      end
      local C={};
      local function N(q)
        local b=tostring(q or""):match("^%s*(.-)%s*$"):match("(%d+)");
        if not b or tonumber(b)==0 then
          return nil;
        end
        return"rbxassetid://"..b;
      end
      local function q(b,D)
        local p,r=pcall(function()
          local K=b:FindFirstChildOfClass("Animator");
          return K and K:GetPlayingAnimationTracks()or b:GetPlayingAnimationTracks();
        end);
        if not p then
          return;
        end
        for b,b in ipairs(r)do
          if b~=D then
            pcall(function()
              b:Stop(0);
            end);
          end
        end;
      end
      local function b(D,p)
        local r,K=pcall(function()
          return not p.Disabled;
        end);
        if not r then
          return;
        end
        local r=K or l._reloadAnimate==p and l._reloadEnabled;
        l._reloadSerial=(l._reloadSerial or 0)+1;
        local K=l._reloadSerial;
        l._reloadAnimate=p;
        l._reloadEnabled=r;
        if not pcall(function()p.Disabled=true;end) then
          return;
        end
        q(D);
        task.spawn(function()
          task.wait();
          if K~=l._reloadSerial then
            return;
          end
          l._reloadAnimate=nil;
          l._reloadEnabled=nil;
          if p.Parent~=D.Parent or l._emoteAnimate==p then
            return;
          end
          q(D);
          if r then
            pcall(function()
              p.Disabled=false;
            end);
          end
        end);
      end
      local function D()
        if l._packPlayed then
          l._packPlayed:Disconnect();
          l._packPlayed=nil;
        end
        if l._packAnimatorAdded then
          l._packAnimatorAdded:Disconnect();
          l._packAnimatorAdded=nil;
        end
      end
      local function p()
        local r,K=C,false;
        for o,c in pairs(r)do
          K=if o.Parent and o.AnimationId~=c then if pcall(function()
            local r=o.Parent;
            o.AnimationId=c;
            o.Parent=nil;
            o.Parent=r;
          end)then true else K else K;
        end;
        C={};
        return K;
      end
      local r,K={"https://raw.githubusercontent.com/7yd7/sniper-Emote/refs/heads/test/AnimationSniper.json","https://raw.githubusercontent.com/7yd7/sniper-Emote/refs/heads/test/AnimationSniperoffsale.json"};
      e=y;
      local K,o,c=e.file("animpacks.json"),{},{};
      l.PackCatalog={};
      l.PackSearch="";
      l.PackPage=1;
      l.PacksPerPage=24;
      l.PackFiltered={};
      local function m(S)
        local O=tostring(S.id);
        if c[O] then
          return c[O];
        end
        local B=S.bundledItems;
        if type(B)~="table" then
          return nil;
        end
        local A={};
        local w,F=os.clock()+30,pairs;
        for h,W in F(B)do
          h=type(W)=="table";
          if h then
            S=pairs;
            for B,F in S(W)do
              local S,h=not l.Alive;
              if S then
                h=S;
              else
                B=y;
                h=not B.current();
              end
              if h or os.clock()>=w then
                return nil;
              end
              h=y;
              B,S=h.objects(function()
                local w,h=game,"rbxassetid://"..tostring(F);
                return w:GetObjects(h);
              end);
              if B and S then
                local function B(w,F)
                  for h,W in ipairs(w:GetChildren())do
                    if W:IsA("Animation") then
                      h=N(W.AnimationId);
                      if h then
                        local w=(F.."."..W.Name):split(".");
                        local V;
                        for _ in(F.."."..W.Name):gmatch("[^.]+")do
                          local X=_:lower();
                          V=if X:find("r15",1,true)then"R15"else if X:find("r6",1,true)then"R6"else V;
                        end;
                        A[#A+1]={category=w[#w-1],name=w[#w],id=h,rig=V};
                      end
                    elseif #W:GetChildren()>0 then
                      B(W,F.."."..W.Name);
                    end
                  end;
                end
                for w,w in ipairs(S)do
                  B(w,w.Name);
                  pcall(function()
                    w:Destroy();
                  end);
                end;
              end
            end;
          end
        end;
        c[O]=next(A)and A or nil;
        return A;
      end
      local function c(S,O,B,A)
        local w,F={};
        for h,h in ipairs(B)do
          if h.category and h.category:lower()==O then
            w[h.name:lower()]=w[h.name:lower()]or h.id;
            F=F or h.id;
          else
          end
        end;
        B=S:FindFirstChild(O);
        if not B then
          return 0;
        end
        local h,W,V=ipairs,s[70](B:GetChildren()),0;
        for _,X in h(s:ZT(W))do
          S=X:IsA("Animation");
          if S then
            B=w[X.Name:lower()]or F or A;
            if B then
              _=C[X]==nil;
              if _ then
                O=C;
                O[X]=X.AnimationId;
              end
              V+=1;
              X.AnimationId=B;
              local s=X.Parent;
              X.Parent=nil;
              X.Parent=s;
            else
            end
          else
          end
        end;
        return V;
      end
      local s;
      l.ApplyPack=function(s)
        if not l.Alive then
          return false;
        end
        D();
        l._resumePack=nil;
        l.ResetEmote(true);
        local S=l._request;
        local O,B=s or l.PackName or"Default",z;
        local s=B.Character;
        l.PackName="Default";
        l.PendingPack=O~="Default"and O or nil;
        if l.OnStateChange then
          l.OnStateChange();
        end
        local B,A,w=p(),s and(s:FindFirstChildOfClass("Humanoid")),s and(s:FindFirstChild("Animate"));
        if B and A and w then
          b(A,w);
        end
        if O=="Default" then
          l.LastError=nil;
          return true;
        end
        local w=o[O];
        if not w then
          l.PendingPack=nil;
          if l.OnStateChange then
            l.OnStateChange();
          end
          return false;
        end
        A,B=task,function()
          local F,h=pcall(m,w);
          local m,w=not l.Alive or S~=l._request;
          if m then
            w=m;
          else
            local W=z;
            w=W.Character~=s;
          end
          if w then
            return;
          end
          w=z;
          m=w.Character;
          local s,w=m and(m:FindFirstChildOfClass("Humanoid")),m and(m:FindFirstChild("Animate"));
          l.PendingPack=nil;
          if not(F and h and#h>0 and s and w) then
            l.LastError="Animation pack could not load on this character";
            if l.OnStateChange then
              l.OnStateChange();
            end
            return;
          end
          m,F=s.RigType==Enum.HumanoidRigType.R6 and"R6"or"R15",{};
          for W,W in ipairs(h)do
            if W.rig==m then
              F[#F+1]=W;
            end
          end;
          for W,W in ipairs(h)do
            if not W.rig then
              F[#F+1]=W;
            end
          end;
          h={};
          for W,W in ipairs(F)do
            m=W.category and W.category:lower();
            if m and not h[m] then
              h[m]=W.id;
            end
          end;
          local m,W,V,_=h.idle or h.walk or h.run or h.jump or h.fall or h.climb or h.swim or h.swimidle,{walk="run",run="walk",jump="fall",fall="jump",swim="swimidle",swimidle="swim"},{"idle","walk","run","jump","fall","climb","swim","swimidle"},0;
          for X,X in ipairs(V)do
            _+=c(w,X,F,h[W[X]]or m);
          end;
          if _>0 then
            l.PackName=O;
            l.LastError=nil;
            local c={};
            for m,h in ipairs(F)do
              m=N(h.id);
              if m then
                c[m]=true;
              end
            end;
            local function m(F)
              if not l.Alive or S~=l._request or l.PackName~=O then
                return;
              end
              l._packPlayed=F.AnimationPlayed:Connect(function(S)
                if l.PackName~=O then
                  return;
                end
                local O,F,h=pcall(function()
                  return N(S.Animation.AnimationId),S.Priority.Value;
                end);
                if O and h<=Enum.AnimationPriority.Movement.Value and not c[F] then
                  pcall(function()
                    S:Stop(0);
                  end);
                end
              end);
            end
            W=s:FindFirstChildOfClass("Animator");
            if W then
              m(W);
            else
              l._packAnimatorAdded=s.ChildAdded:Connect(function(c)
                if not c:IsA("Animator") then
                  return;
                end
                local S=l._packAnimatorAdded;
                l._packAnimatorAdded=nil;
                if S then
                  S:Disconnect();
                end
                m(c);
              end);
            end
            b(s,w);
          else
            l.LastError="This pack has no matching animation slots";
          end
          if l.OnStateChange then
            l.OnStateChange();
          end
        end;
        A.spawn(B);
        return true;
      end;
      l._RefreshPackList=function()
        l.PackFavs=l.PackFavs or{};
        local s,c=tostring(l.PackSearch or""):lower(),l.PackCatalog;
        if s~="" then
          local m={};
          for S,S in ipairs(c)do
            if S.name:lower():find(s,1,true) then
              m[#m+1]=S;
            end
          end;
          l.PackFiltered=m;
        else
          l.PackFiltered=c;
        end
        if next(l.PackFavs)~=nil then
          c,s={},{};
          for m,m in ipairs(l.PackFiltered)do
            if l.PackFavs[m.name] then
              c[#c+1]=m;
            else
              s[#s+1]=m;
            end
          end;
          for m,m in ipairs(s)do
            c[#c+1]=m;
          end;
          l.PackFiltered=c;
        end
        c=#l.PackFiltered;
        l.PackTotalPages=math.max(1,math.ceil(c/l.PacksPerPage));
        if l.PackPage>l.PackTotalPages then
          l.PackPage=l.PackTotalPages;
        end
        if l.PackPage<1 then
          l.PackPage=1;
        end
      end;
      local function s(c)
        local m={};
        for S,S in ipairs(l.PackCatalog)do
          m[S.id]=true;
        end;
        for S,O in pairs(c)do
          S=type(O)=="table"and tonumber(O.id);
          local c=S and S>0 and S<9007199254740992 and S%1==0 and type(O.bundledItems)=="table"and not m[S];
          if c then
            m[S]=true;
            local c=j(O.name or"Animation "..S);
            c=if o[c]then c.." ["..S.."]"else c;
            local m=o;
            m[c]={id=S,bundledItems=O.bundledItems};
            l.PackCatalog[#l.PackCatalog+1]={id=S,name=c};
          end
        end;
      end
      task.spawn(function()
        while true do
          task.wait(0.5);
          local c,m=not l.Alive;
          if c then
            m=c;
          else
            local c;
            local c=T;
            local S=c.stage=="ready";
            if S then
              c=y;
              m=c.Status.stage~="fetching";
            else
              m=S;
            end
          end
          if m then
            break;
          end
        end;
        if not l.Alive then
          return;
        end
        local c;
        pcall(function()
          local m=isfile and isfile(K);
          if m then
            local m=game:GetService("HttpService"):JSONDecode(readfile(K));
            local S=type(m)=="table"and#m>0;
            if S then
              c=m;
            end
          end
        end);
        if c then
          s(c);
          table.sort(l.PackCatalog,function(c,m)
            return c.name<m.name;
          end);
          local c,m=pcall(function()
            return isfile(K..".time")and tonumber(readfile(K..".time"));
          end);
          if c and m and os.time()-m<86400 then
            return;
          end
        end
        local c,m={},ipairs;
        for S,S in m(r)do
          local r,m=pcall(function()
            local O=y;
            local B=O.download(S);
            return B~=""and game:GetService("HttpService"):JSONDecode(B)or nil;
          end);
          if r and type(m)=="table" then
            for r,r in pairs(type(m.data)=="table"and m.data or m)do
              if type(r)=="table"and r.id and type(r.bundledItems)=="table" then
                c[#c+1]=r;
              end
            end;
          end
        end;
        if not l.Alive or#c==0 then
          return;
        end
        l.PackCatalog={};
        o={};
        s(c);
        table.sort(l.PackCatalog,function(s,r)
          return s.name<r.name;
        end);
        pcall(function()
          writefile(K,game:GetService("HttpService"):JSONEncode(c));
          writefile(K..".time",tostring(os.time()));
        end);
      end);
      l.ResetEmote=function(s)
        local r=l._resumePack;
        l._resumePack=nil;
        l._request=l._request+1;
        l.PendingEmoteId=nil;
        l.PendingPack=nil;
        l.SelectedEmoteId=nil;
        if l._emoteStopped then
          l._emoteStopped:Disconnect();
          l._emoteStopped=nil;
        end
        if l._emotePlayed then
          l._emotePlayed:Disconnect();
          l._emotePlayed=nil;
        end
        local K=l._currentEmoteTrack;
        l._currentEmoteTrack=nil;
        local o=l._currentEmoteAnim;
        l._currentEmoteAnim=nil;
        if K then
          pcall(function()
            K:Stop(0);
          end);
          task.delay(0.25,function()
            pcall(function()
              K:Destroy();
            end);
            if o then
              pcall(function()
                o:Destroy();
              end);
            end
          end);
        elseif o then
          o:Destroy();
        end
        local o=l._emoteAnimate;
        local c=l._emoteAnimateWasEnabled;
        l._emoteAnimate=nil;
        l._emoteAnimateWasEnabled=nil;
        local m;
        if o then
          local S;
          S,m=z,o.Parent==z.Character;
        else
          m=o;
        end
        if m then
          local m=o.Parent:FindFirstChildOfClass("Humanoid");
          if m then
            if c then
              pcall(function()
                o.Disabled=false;
              end);
            end
            b(m,o);
          end
        elseif K then
          local K=z;
          local o=K.Character;
          local K,c=o and(o:FindFirstChildOfClass("Humanoid")),o and(o:FindFirstChild("Animate"));
          if K and c then
            b(K,c);
          end
        end
        if l.OnStateChange then
          l.OnStateChange();
        end
        if r and not s and l.Alive then
          l.ApplyPack(r);
        end
      end;
      local s={};
      local function r(K)
        local o=tostring(K);
        if s[o] then
          return s[o];
        end
        local c=N(K);
        if not c then
          return nil;
        end
        K=nil;
        local m=y;
        local S,O=m.objects(function()
          return game:GetObjects(c);
        end);
        if S and type(O)=="table" then
          for m,m in ipairs(O)do
            K=if m:IsA("Animation")then N(m.AnimationId)else K;
            if not K then
              for S,S in ipairs(m:GetDescendants())do
                if S:IsA("Animation") then
                  K=N(S.AnimationId);
                  if K then
                    break;
                  end
                else
                end
              end;
            else
            end
            m:Destroy();
          end;
        else
        end
        s[o]=K or c;
        return s[o];
      end
      l.PlayEmote=function(s)
        if not l.Alive then
          return false;
        end
        local K=l.PendingPack or l._resumePack;
        l.ResetEmote(true);
        l._resumePack=K;
        local o,c=l._request,z;
        local m=c.Character;
        local c=m and(m:FindFirstChildOfClass("Humanoid"));
        local S=m and(m:FindFirstChild("Animate"));
        local O=N(s);
        if not(c and O) then
          if K then
            l.ResetEmote();
          end
          return false;
        end
        l.PendingEmoteId=tostring(s);
        l.LastError=nil;
        if l.OnStateChange then
          l.OnStateChange();
        end
        task.spawn(function()
          local N,K=pcall(r,s);
          local r,B=not l.Alive or o~=l._request;
          if r then
            B=r;
          else
            local A=z;
            B=A.Character~=m;
          end
          if B then
            return;
          end
          local B=Instance.new("Animation");
          B.AnimationId=N and K or O;
          local O=c:FindFirstChildOfClass("Animator")or c:WaitForChild("Animator",5);
          local A,w=pcall(function()
            return O and(O:LoadAnimation(B));
          end);
          if A and w then
            K=os.clock()+5;
            while l.Alive and o==l._request and w.Length<=0 and os.clock()<K do
              task.wait(0.05);
            end;
          end
          K,N=not l.Alive or o~=l._request;
          if K then
            N=K;
          else
            r=z;
            N=r.Character~=m;
          end
          if N then
            if A and w then
              pcall(function()
                w:Stop(0);
                w:Destroy();
              end);
            end
            B:Destroy();
            return;
          end
          l.PendingEmoteId=nil;
          if not A or not w or w.Length<=0 then
            if A and w then
              w:Destroy();
            end
            B:Destroy();
            if l._resumePack then
              l.ResetEmote();
            end
            l.LastError="Emote unavailable for this character or experience";
            if l.OnStateChange then
              l.OnStateChange();
            end
            return;
          end
          w.Priority=Enum.AnimationPriority.Action4;
          w.Looped=l.EmoteLoop==true;
          S=m:FindFirstChild("Animate");
          K=S;
          if K then
            l._emoteAnimate=S;
            N=not S.Disabled or l._reloadAnimate==S and l._reloadEnabled;
            l._emoteAnimateWasEnabled=N;
            l._reloadSerial=(l._reloadSerial or 0)+1;
            l._reloadAnimate=nil;
            l._reloadEnabled=nil;
            S.Disabled=true;
          end
          r=c:FindFirstChildOfClass("Animator");
          q(c,w);
          l._currentEmoteTrack=w;
          l._currentEmoteAnim=B;
          l.SelectedEmoteId=s;
          if r then
            l._emotePlayed=r.AnimationPlayed:Connect(function(s)
              if l._currentEmoteTrack==w and s~=w then
                pcall(function()
                  s:Stop(0);
                end);
              end
            end);
          end
          l._emoteStopped=w.Stopped:Connect(function()
            if l._currentEmoteTrack~=w then
              return;
            end
            task.defer(function()
              if l._currentEmoteTrack~=w or w.IsPlaying then
                return;
              end
              if l.EmoteLoop then
                pcall(function()
                  w:Play(0,1,l.EmoteSpeed/100);
                end);
              else
                l.ResetEmote();
              end
            end);
          end);
          if not pcall(function()w:Play(0,1,l.EmoteSpeed/100);end) then
            l.ResetEmote();
            l.LastError="Unable to play this emote";
          end
          if l.OnStateChange then
            l.OnStateChange();
          end
        end);
        return true;
      end;
      l._SetEmoteLoop=function(s)
        l.EmoteLoop=s==true;
        s=l._currentEmoteTrack;
        if s then
          s.Looped=l.EmoteLoop;
        end
      end;
      local s;
      local s,N=n,z;
      s:AddSignal(N.CharacterAdded:Connect(function(q)
        local r=l.SelectedEmoteId or l.PendingEmoteId;
        local K=l.PendingPack or l._resumePack or l.PackName;
        l.ResetEmote(true);
        D();
        C={};
        local C=l._request;
        task.spawn(function()
          local o,c=q:WaitForChild("Humanoid",10),q:WaitForChild("Animate",10);
          if c then
            c:WaitForChild("idle",5);
          end
          local m,S=not l.Alive or C~=l._request;
          if m then
            S=m;
          else
            c=z;
            S=c.Character~=q;
          end
          if S or not o then
            return;
          end
          if r then
            l._resumePack=K~="Default"and K or nil;
            l.PlayEmote(r);
          elseif K and K~="Default" then
            l.ApplyPack(K);
          end
        end);
      end));
      l.Destroy=function()
        if not l.Alive then
          return;
        end
        l.Alive=false;
        l.OnStateChange=nil;
        l.ResetEmote();
        D();
        local C,q=p(),z;
        local D=q.Character;
        local q,p=D and(D:FindFirstChildOfClass("Humanoid")),D and(D:FindFirstChild("Animate"));
        if C and q and p then
          b(q,p);
        end
        l.PackName="Default";
      end;
      N,s=n,n;
      N:AddSignal(s.ScreenGui.Destroying:Connect(l.Destroy));
      l.EmoteCatalog={};
      l.EmoteSearch="";
      l.EmoteFavorites={};
      l.EmoteSpeed=100;
      l.EmoteLoop=false;
      l.SelectedEmoteId=nil;
      l._emotePage=1;
      l._emotesPerPage=24;
      l._emoteFilteredList={};
      do
        l.EmoteCatalog={{id=129149402922241,name="Griddy"}};
        local C={[129149402922241]=true};
        pcall(function()
          if isfile and isfile("emotes.json") then
            local q=game:GetService("HttpService"):JSONDecode(readfile("emotes.json"));
            if type(q)=="table" then
              for b,D in pairs(q)do
                local q,p;
                if type(D)=="table" then
                  q,p=(tostring(D.name or D[1]or b)),D.id or D[2];
                else
                  q,p=tostring(b),D;
                end
                b=tonumber(tostring(p or""):gsub("%D",""))or 0;
                if q~=""and b>0 and not C[b] then
                  C[b]=true;
                  l.EmoteCatalog[#l.EmoteCatalog+1]={id=b,name=j(q)};
                end
              end;
            end
          end
        end);
      end;
      local function C()
        local q,b=pcall(function()
          local D=y;
          local p=D.download("https://raw.githubusercontent.com/7yd7/sniper-Emote/refs/heads/test/EmoteSniper.json");
          if p and p~="" then
            return game:GetService("HttpService"):JSONDecode(p).data or{};
          end
        end);
        if q and type(b)=="table" then
          local q={};
          for D,p in pairs(b)do
            D=type(p)=="table"and tonumber(p.id);
            if D and D>0 and D<9007199254740992 and D%1==0 then
              local b,r=#q+1,{id=D};
              r.name,q[b]=j(p.name or"Emote_"..D),r;
            end
          end;
          return q;
        end
        return{};
      end
      local function q(b)
        b=b:lower();
        local D=l.EmoteCatalog;
        if b~="" then
          local p,r=b:match("^%d+$"),{};
          for K,K in ipairs(D)do
            if p then
              if tostring(K.id)==b then
                r[#r+1]=K;
              end
            else
              local p,o=j(K.name):lower(),true;
              for c in b:gmatch("%S+")do
                if not p:find(c,1,true) then
                  o=false;
                  break;
                end
              end;
              if o then
                r[#r+1]=K;
              end
            end
          end;
          l._emoteFilteredList=r;
        else
          l._emoteFilteredList=D;
        end
      end
      l._refreshEmoteList=function()
        q(l.EmoteSearch);
        if next(l.EmoteFavorites)~=nil then
          local q,b={},{};
          for D,D in ipairs(l._emoteFilteredList)do
            if l.EmoteFavorites[D.id] then
              q[#q+1]=D;
            else
              b[#b+1]=D;
            end
          end;
          for D,D in ipairs(b)do
            q[#q+1]=D;
          end;
          l._emoteFilteredList=q;
        end
        local q,b=#l._emoteFilteredList,l._emotesPerPage;
        l._emoteTotalPages=math.max(1,math.ceil(q/b));
        if l._emotePage>l._emoteTotalPages then
          l._emotePage=l._emoteTotalPages;
        end
        if l._emotePage<1 then
          l._emotePage=1;
        end
      end;
      N=y;
      local q=N.file("emotes.json");
      local function b()
        local D,p=pcall(function()
          if not(isfile and isfile(q)) then
            return nil;
          end
          local r=game:GetService("HttpService"):JSONDecode(readfile(q));
          return type(r)=="table"and#r>0 and r or nil;
        end);
        return D and p or nil;
      end
      local function D(p)
        pcall(function()
          writefile(q,game:GetService("HttpService"):JSONEncode(p));
        end);
      end
      e=y;
      local q=e.file("emotes.time");
      local function p(r,K)
        local o,c,m,S={},{},{r,K},0;
        for r,r in ipairs(m)do
          for K,K in ipairs(r)do
            if K and K.id and not o[K.id] then
              K.name=j(K.name or K.id);
              o[K.id]=true;
              c[#c+1]=K;
            end
            S+=1;
            if S%3000==0 then
              task.wait();
            end
          end;
        end;
        return c;
      end
      s,N=task,function()
        while true do
          task.wait(0.5);
          local r,K=not l.Alive;
          if r then
            K=r;
          else
            local r;
            local r=T;
            local T=r.stage=="ready";
            if T then
              r=y;
              K=r.Status.stage~="fetching";
            else
              K=T;
            end
          end
          if K then
            break;
          end
        end;
        if not l.Alive then
          return;
        end
        local T=b();
        if T then
          l.EmoteCatalog=p(l.EmoteCatalog,T);
          l._refreshEmoteList();
          if l._buildEmoteGrid then
            pcall(l._buildEmoteGrid);
          end
          local b,p=pcall(function()
            return isfile(q)and tonumber(readfile(q));
          end);
          if b and p and os.time()-p<86400 then
            return;
          end
        end
        for b=1,5,1 do
          if not l.Alive then
            return;
          end
          T=C();
          if not l.Alive then
            return;
          end
          if #T>0 then
            local C,b={},{};
            for p,p in ipairs(l.EmoteCatalog)do
              if p and p.id and not C[p.id] then
                p.name=j(p.name or p.id);
                C[p.id]=true;
                b[#b+1]=p;
              end
            end;
            for p,p in ipairs(T)do
              if p and p.id and not C[p.id] then
                p.name=j(p.name or p.id);
                C[p.id]=true;
                b[#b+1]=p;
              end
            end;
            l.EmoteCatalog=b;
            D(l.EmoteCatalog);
            pcall(function()
              writefile(q,tostring(os.time()));
            end);
            l._refreshEmoteList();
            if l._buildEmoteGrid then
              pcall(l._buildEmoteGrid);
            end
            return;
          end
          task.wait(3);
        end;
      end;
      s.spawn(N);
      local T;
      e=J;
      e.Anim=l;
      s=J;
      s.ClearAnimations=l.Destroy;
      e=n;
      local T=e.AccentColor;
      local function C(q)
        return q.Items or q.Root;
      end
      local function q(b)
        local D;
        local D=H;
        local p,r=D.__win;
        if p then
          D=H;
          r=D.__win.size;
        else
          r=p;
        end
        p=typeof(r)=="UDim2"and r.Y.Offset or 540;
        return math.max(140,p-66-b);
      end
      local b,D,p=2,118,8;
      local r=Color3.fromRGB(25,27,33);
      local K=Color3.fromRGB(35,38,48);
      local o=Color3.fromRGB(30,34,48);
      local c=Color3.fromRGB(236,238,244);
      local m,S=Color3.fromRGB(45,48,58),{};
      local function O(B,A,w)
        local F=B+(A-B)*w;
        return math.abs(F-A)<0.001 and A or F;
      end
      local function B(A,w,F,h)
        local W=Instance.new("ScrollingFrame");
        W.Name="AnimationCatalog";
        W.Size=UDim2.new(1,-8,0,w);
        W.BackgroundColor3=Color3.fromRGB(13,14,18);
        W.ZIndex=20;
        W.BorderSizePixel=0;
        W.ScrollBarThickness=4;
        W.ScrollBarImageColor3=T;
        W.CanvasSize=UDim2.new();
        W.ClipsDescendants=true;
        W.Parent=A;
        W.LayoutOrder=F;
        Instance.new("UICorner",W).CornerRadius=UDim.new(0,6);
        local V=Instance.new("TextLabel");
        V.Name="Empty";
        V.Text="No matching results";
        V.Size,V.Position=UDim2.new(1,-16,0,48),UDim2.fromOffset(8,16);
        V.BackgroundTransparency=1;
        V.TextTransparency=0.35;
        V.Font=Enum.Font.Gotham;
        V.TextSize=12;
        V.TextColor3=c;
        V.ZIndex=21;
        V.Parent=W;
        local _,X,x,k={},{},{};
        local v,I,i=true,false,{Frame=W};
        local function E()
          for Q,t in pairs(x)do
            if Q.Parent then
              Q.ScrollingEnabled=t;
            end
            x[Q]=nil;
          end;
        end
        local function x()
          local Q=I or not l.Alive or not W.Parent;
          if Q then
            return false;
          end
          Q=W;
          while Q do
            if Q:IsA("GuiObject")and not Q.Visible then
              return false;
            end
            if Q:IsA("ScreenGui") then
              return Q.Enabled;
            end
            Q=Q.Parent;
          end;
          return false;
        end
        local function Q()
          local t=Instance.new("TextButton");
          t.Name="CatalogCard";
          t.ClipsDescendants=true;
          t.BackgroundColor3=r;
          t.BorderSizePixel=0;
          t.ZIndex=21;
          t.AutoButtonColor=false;
          t.Text="";
          Instance.new("UICorner",t).CornerRadius=UDim.new(0,6);
          local R=Instance.new("UIStroke",t);
          R.Color=m;
          R.Thickness=1;
          R.Transparency=0.45;
          local g,u=Instance.new("UIScale",t),Instance.new("ImageLabel",t);
          u.Name="Thumb";
          u.ZIndex=22;
          u.BackgroundTransparency=1;
          u.ScaleType=Enum.ScaleType.Fit;
          u.Size,u.Position=UDim2.new(1,-16,0,D-44),UDim2.fromOffset(8,7);
          local U=Instance.new("TextLabel",t);
          U.Name="Title";
          U.ZIndex=23;
          U.BackgroundTransparency=1;
          local M=n;
          U.FontFace=M.BuiltInRegular;
          U.TextSize=12;
          U.TextColor3=c;
          U.TextWrapped,U.TextTruncate=false,Enum.TextTruncate.AtEnd;
          U.TextXAlignment=Enum.TextXAlignment.Center;
          U.Size,U.Position=UDim2.new(1,-10,0,16),UDim2.fromOffset(5,D-26);
          M=Instance.new("TextLabel",t);
          M.Name,M.Text,M.Font="Favorite","\226\152\133",Enum.Font.GothamBold;
          M.ZIndex=24;
          M.TextSize=17;
          M.BackgroundTransparency=1;
          M.TextColor3=Color3.fromRGB(255,211,104);
          M.TextTransparency=1;
          M.Position,M.Size=UDim2.fromOffset(5,3),UDim2.fromOffset(20,20);
          local sP=Instance.new("Frame",t);
          sP.Name="ActiveDot";
          sP.ZIndex=24;
          sP.BorderSizePixel=0;
          sP.AnchorPoint,sP.Position=Vector2.new(1,0),UDim2.new(1,-7,0,8);
          sP.Size=UDim2.fromOffset(7,7);
          sP.BackgroundColor3=T;
          sP.BackgroundTransparency=1;
          Instance.new("UICorner",sP).CornerRadius=UDim.new(1,0);
          local T={card=t,img=u,label=U,stroke=R,scale=g,dot=sP,star=M,active=0,hover=0,favorite=0,pulse=0};
          local function R()
            T.hovered=true;
          end
          t.MouseEnter:Connect(R);
          local function R()
            T.hovered=false;
          end
          t.MouseLeave:Connect(R);
          local function R()
            if not T.entry or not x() then
              return;
            end
            local g,u=T.entry,T.key;
            T.pulse=1;
            h.onClick(g,u);
          end
          t.MouseButton1Click:Connect(R);
          local function R()
            if T.entry and x()and h.onFav then
              h.onFav(T.entry,T.key);
            end
          end
          t.MouseButton2Click:Connect(R);
          return T;
        end
        i.refresh=function()
          local T=I;
          if T then
            return;
          end
          v=false;
          T=h.getList()or{};
          local t,R=#T,D+p;
          local g=math.ceil(t/b);
          local u=math.max(0,g*R+p);
          if W.CanvasSize.Y.Offset~=u then
            W.CanvasSize=UDim2.fromOffset(0,u);
          end
          V.Visible=t==0;
          local V,U=math.max(40,(W.AbsoluteSize.X-W.ScrollBarThickness-p*(b+1))/b),{};
          for M=math.max(0,math.floor((W.CanvasPosition.Y-p)/R)-1),math.min(g-1,math.floor((W.CanvasPosition.Y+math.max(W.AbsoluteSize.Y,w))/R)+1),1 do
            for w=0,b-1,1 do
              u=M*b+w+1;
              if u<=t then
                U[u]={M,w};
              end
            end;
          end;
          for b,w in pairs(X)do
            if not U[b] then
              w.card.Visible=false;
              w.hovered=false;
              w.entry=nil;
              w.key=nil;
              _[#_+1]=w;
              X[b]=nil;
            end
          end;
          for b,w in pairs(U)do
            g=X[b]or table.remove(_)or Q();
            X[b]=g;
            u,t=T[b],h.keyOf(T[b]);
            b=t~=g.key;
            if b then
              g.active=t==k and 1 or 0;
              g.hover=0;
              g.favorite=0;
              g.pulse=0;
              g.accent=nil;
              g.hovered=false;
              g.img.Image,g.label.Text=h.imageOf(u),h.nameOf(u);
            end
            g.entry=u;
            g.key=t;
            g.card.Parent,g.card.Visible=W,true;
            g.card.Size=UDim2.fromOffset(V,D);
            g.card.Position=UDim2.fromOffset(p+w[2]*(V+p),p+w[1]*R);
          end;
        end;
        i.select=function(T)
          k=T;
        end;
        i.queue=function(T)
          local b=I;
          if b then
            return;
          end
          v=true;
          if T then
            W.CanvasPosition=Vector2.zero;
          end
        end;
        i.step=function(T)
          if not x() then
            E();
            return;
          end
          local b=v;
          if b then
            i.refresh();
          end
          local D,p=1-math.exp(-18*math.min(T,0.1)),pairs;
          for w,V in p(X)do
            b,w=V.key==k,h.isFav and h.isFav(V.entry)and 1 or 0;
            local p,_,X,x,k=O(V.active,b and 1 or 0,D),O(V.hover,V.hovered and 1 or 0,D),O(V.favorite,w,D),O(V.pulse,0,D),n;
            T=k.AccentColor;
            if p==V.active and _==V.hover and X==V.favorite and x==V.pulse and V.accent==T then
              continue;
            end
            V.active=p;
            V.hover=_;
            V.favorite=X;
            V.pulse=x;
            V.accent=T;
            V.card.BackgroundColor3=r:Lerp(K,V.hover*0.7):Lerp(o,V.active);
            V.stroke.Color=m:Lerp(T,V.active);
            V.stroke.Thickness=1+V.active;
            V.stroke.Transparency=0.45*(1-V.active);
            V.label.TextColor3=c:Lerp(T,V.active);
            V.dot.BackgroundColor3,V.dot.BackgroundTransparency=T,1-V.active;
            V.star.TextTransparency=1-V.favorite;
            V.star.Rotation=-15*(1-V.favorite);
            V.scale.Scale=1-V.pulse*0.025;
          end;
        end;
        local function T()
          i.queue();
        end
        W:GetPropertyChangedSignal("CanvasPosition"):Connect(T);
        local function b()
          i.queue();
        end
        W:GetPropertyChangedSignal("AbsoluteSize"):Connect(b);
        W.MouseLeave:Connect(E);
        W.Destroying:Connect(function()
          I=true;
          E();
        end);
        local b;
        F=H;
        local function b(D)
          if not D then
            E();
          else
            i.queue();
          end
        end
        F.Signal:Connect(b);
        if h.tab then
          A,T=h.tab,function(b)
            if not b then
              E();
            else
              i.queue();
            end
          end;
          A.Signal:Connect(T);
        end
        S[#S+1]=i;
        return i;
      end
      local T,b=n;
      N=f;
      local function f(b)
        local D,p=not l.Alive;
        if D then
          p=D;
        else
          local D;
          local D=H;
          p=not D.__win.open;
        end
        if p then
          return;
        end
        for H,H in ipairs(S)do
          H.step(b);
        end;
      end
      T:AddSignal(N.Heartbeat:Connect(f));
      local T;
      f=a;
      local T,H=f("favourites.json"),{emotes={},packs={}};
      pcall(function()
        if isfile and isfile(T) then
          local a=game:GetService("HttpService"):JSONDecode(readfile(T));
          if type(a)=="table" then
            H.emotes=type(a.emotes)=="table"and a.emotes or{};
            H.packs=type(a.packs)=="table"and a.packs or{};
            local function a(b)
              local D={};
              if type(b)~="table" then
                return D;
              end
              for p,r in pairs(b)do
                if r then
                  D[j(p)]=true;
                end
              end;
              return D;
            end
            H.emotes=a(H.emotes);
            H.packs=a(H.packs);
          end
        end
      end);
      local function a()
        pcall(function()
          if not(writefile and isfolder) then
            return;
          end
          local b;
          local b,b=d,not isfolder(d);
          if b then
            local b=d;
            makefolder(b);
          end
          writefile(T,game:GetService("HttpService"):JSONEncode(H));
        end);
      end
      local function T(d)
        return tostring(d.id);
      end
      local function d(b,D)
        return b[T(D)]==true or b[D.name]==true or b[j(D.name)]==true;
      end
      local function b(D,p)
        local r=not d(D,p);
        D[p.name],D[j(p.name)]=nil,nil;
        D[T(p)]=r or nil;
        a();
      end
      local function T(a,D,p,r)
        local K,o,c=tostring(D or""):lower(),{},{};
        for m,S in ipairs(a or{})do
          D,m=(r(S).." "..tostring(S.id)):lower(),true;
          for a in K:gmatch("%S+")do
            if not D:find(a,1,true) then
              m=false;
              break;
            end
          end;
          if m then
            local a=d(p,S)and o or c;
            a[#a+1]=S;
          end
        end;
        for a,a in ipairs(c)do
          o[#o+1]=a;
        end;
        return o;
      end
      local a,D,p,r,K,o="",{};
      local function c()
        D=T(l.EmoteCatalog,a,H.emotes,function(m)
          return j(m.name or tostring(m.id));
        end);
        if p then
          p.queue();
        end
      end
      local m;
      e=P;
      local m,S=e.Emotes:AddLabel("Search"),{Default="",Placeholder="Search emotes...",Flag="emote_search",Size=130};
      S.Callback=function(O)
        a=O or"";
        c();
        if p then
          p.queue(true);
        end
      end;
      m:AddTextInput(S);
      m=P;
      local a,S,O,A=C(m.Emotes),q(104),{};
      e=Z;
      O.tab=e.Emotes;
      O.getList=function()
        local A=D;
        return A;
      end;
      O.keyOf=function(D)
        return tostring(D.id);
      end;
      O.nameOf=function(D)
        return j(D.name or tostring(D.id));
      end;
      O.imageOf=function(D)
        return"rbxthumb://type=Asset&id="..tostring(D.id).."&w=420&h=420";
      end;
      O.onClick=function(D,A)
        if tostring(l.SelectedEmoteId or l.PendingEmoteId or"")==A then
          l.ResetEmote();
        else
          l.PlayEmote(D.id);
        end
      end;
      O.isFav=function(D)
        return d(H.emotes,D);
      end;
      O.onFav=function(D)
        b(H.emotes,D);
        c();
        p.queue(true);
      end;
      p=B(a,S,10,O);
      N=P;
      N.EmoteOptions:AddLabel("Loop"):AddToggle({Default=false,Flag="emote_loop",Callback=function(a)
        if l._SetEmoteLoop then
          l._SetEmoteLoop(a);
        else
          l.EmoteLoop=a;
        end
      end});
      e=P;
      e.EmoteOptions:AddLabel("Speed"):AddSlider({Min=10,Max=300,Default=100,Type="%",Size=100,Flag="emote_speed",Callback=function(a)
        l.EmoteSpeed=a;
        local D=l._currentEmoteTrack;
        if D then
          pcall(D.AdjustSpeed,D,a/100);
        end
      end});
      e=P;
      e.EmoteOptions:AddButton({Name="Stop Emote",Callback=function()
        if l.ResetEmote then
          pcall(l.ResetEmote);
        end
        p.select(nil);
      end});
      r,K,o="",{},{};
      local function a()
        K=T(l.PackCatalog,r,H.packs,function(T)
          return j(T.name);
        end);
        if o and o.queue then
          o.queue();
        end
      end
      e=P;
      local T,D=e.Animations:AddLabel("Search"),{Default="",Placeholder="Search packs...",Flag="pack_search",Size=130};
      D.Callback=function(O)
        r=O or"";
        a();
        if o and o.queue then
          o.queue(true);
        end
      end;
      T:AddTextInput(D);
      S=P;
      local T,D,r,O=C(S.Animations),q(104),{},Z;
      r.tab=O.Animations;
      r.getList=function()
        local Z=K;
        return Z;
      end;
      r.keyOf=function(Z)
        return Z.name;
      end;
      r.nameOf=function(Z)
        return j(Z.name);
      end;
      r.imageOf=function(Z)
        return"rbxthumb://type=BundleThumbnail&id="..tostring(Z.id).."&w=420&h=420";
      end;
      r.onClick=function(Z,j)
        l.ApplyPack((l.PackName==Z.name or l.PendingPack==Z.name or l._resumePack==Z.name)and"Default"or Z.name);
      end;
      r.isFav=function(Z)
        return d(H.packs,Z);
      end;
      r.onFav=function(d)
        b(H.packs,d);
        a();
        o.queue(true);
      end;
      o=B(T,D,10,r);
      local function T()
        local H=n;
        H.Lib:hook("anim_pack","string",function()
          return tostring(l.PendingPack or l._resumePack or l.PackName or"Default");
        end,function(d)
          d=tostring(d or"Default");
          d=if d==""then"Default"else d;
          local Z;
          local Z=not G[4][G[6]]or not l.Alive;
          if Z then
            return;
          end
          assert(l.ApplyPack(d),"Animation pack is unavailable");
        end);
        H=n;
        H.Lib:hook("emote_pick","string",function()
          return tostring(l.SelectedEmoteId or l.PendingEmoteId or"");
        end,function(H)
          local d=tonumber(H);
          local Z;
          local Z=not G[4][G[6]]or not l.Alive;
          if Z then
            return;
          end
          if H=="" then
            if l.SelectedEmoteId or l.PendingEmoteId or l._currentEmoteTrack then
              l.ResetEmote();
            end
            return;
          end
          assert(d and d>0 and d%1==0,"Invalid emote id");
          assert(l.PlayEmote(d),"Emote could not start");
        end);
      end
      pcall(T);
      D=P;
      D.AnimationOptions:AddButton({Name="Reapply",Callback=function()
        if l.ApplyPack then
          pcall(l.ApplyPack,l.PendingPack or l._resumePack or l.PackName);
        end
      end});
      N=P;
      N.AnimationOptions:AddButton({Name="Reset To Default",Callback=function()
        l.PackName="Default";
        if l.ApplyPack then
          pcall(l.ApplyPack,"Default");
        end
        o.select(nil);
      end});
      l.OnStateChange=function()
        if not l.Alive then
          return;
        end
        p.select(l.SelectedEmoteId and tostring(l.SelectedEmoteId)or nil);
        local T=l.PendingPack or l._resumePack or l.PackName;
        o.select(T~="Default"and T or nil);
      end;
      l.OnStateChange();
      local T=J;
      T.RefreshAnimGrids=function()
        c();
        a();
      end;
      task.spawn(function()
        local T,J=-1,-1;
        while true do
          local H,d=l.Alive;
          if H then
            local Z=n;
            d=Z.ScreenGui.Parent;
          else
            d=H;
          end
          if not d then
            break;
          end
          d,H=#(l.EmoteCatalog or{}),#(l.PackCatalog or{});
          if d~=T or H~=J then
            pcall(c);
            pcall(a);
            T,J=d,H;
          else
          end
          task.wait(2);
        end;
      end);
      local l=game:GetService("TeleportService");
      local T=game:GetService("HttpService");
      local function J(H,a)
        local d;
        local d=Y;
        d.new({Title=H and"Helpers"or"Helpers failed",Content=tostring(a),Duration=H and 4 or 6});
      end
      local H={On=false,Max=nil,Min=nil};
      local function a()
        local function d()
          local Z=H.On;
          if Z then
            local Z=H.Max==nil;
            if Z then
              local Y=z;
              H.Max=Y.CameraMaxZoomDistance;
              Y=z;
              H.Min=Y.CameraMinZoomDistance;
            end
            Z=z;
            Z.CameraMaxZoomDistance=2048;
          else
            local Z=H.Max~=nil;
            if Z then
              local Z=z;
              Z.CameraMaxZoomDistance=H.Max;
              Z=z;
              Z.CameraMinZoomDistance=H.Min;
              H.Max=nil;
              H.Min=nil;
            end
          end
        end
        return(pcall(d));
      end
      local d;
      local function Z()
        local Y=d==nil or type(setfpscap)~="function";
        if Y then
          return;
        end
        pcall(setfpscap,d);
        d=nil;
      end
      N=P;
      local Y,j=N.Helpers:AddLabel("Unlock FPS"),{Name="Unlock FPS",Default=false,Flag="unlock_fps"};
      j.Callback=function(C)
        if type(setfpscap)~="function" then
          return;
        end
        if not C then
          Z();
          return;
        end
        C=d==nil;
        if C then
          local C,N=pcall(function()
            return getfpscap();
          end);
          d=C and tonumber(N)or 0;
        end
        pcall(setfpscap,999);
      end;
      Y:AddToggle(j);
      D=L;
      D("unlock fps",Z);
      s=P;
      s.Helpers:AddLabel("No Zoom Limit"):AddToggle({Name="No Zoom Limit",Default=false,Flag="no_zoom_limit",Callback=function(s)
        H.On=s;
        a();
      end});
      S,f=n,z;
      S:AddSignal(f.CharacterAdded:Connect(function()
        task.wait(0.6);
        local s;
        local s=G[4][G[6]]and H.On;
        if s then
          local s=z;
          local n=s.CameraMaxZoomDistance~=2048;
          if n then
            local s,n=z;
            n,H.Max,H.Min=z,s.CameraMaxZoomDistance,z.CameraMinZoomDistance;
          end
          a();
        end
      end));
      e=L;
      e("zoom limit",function()
        H.On=false;
        a();
      end);
      m=P;
      m.Helpers:AddButton({Name="Rejoin",Callback=function()
        task.spawn(function()
          local s,L=pcall(function()
            l:TeleportToPlaceInstance(game.PlaceId,game.JobId,z);
          end);
          if not s then
            J(false,tostring(L));
          end
        end);
      end});
      q=P;
      local s,L=q.Helpers,{Name="Server Hop"};
      L.Callback=function()
        local n,H=task,function()
          local f,a=0,"";
          while f<6 do
            f+=1;
            local f,d=("https://games.roblox.com/v1/games/%d/servers/Public?sortOrder=Desc&limit=100"):format(game.PlaceId)..(a~=""and"&cursor="..a or""),y;
            local y=d.download(f);
            f,d=pcall(function()
              return T:JSONDecode(y);
            end);
            if not(f and type(d)=="table"and type(d.data)=="table") then
              return J(false,"server list unavailable");
            end
            local y,T=ipairs,d.data;
            for f,Z in y(T)do
              f=Z.id~=game.JobId and(tonumber(Z.playing)or 0)<(tonumber(Z.maxPlayers)or 0);
              if f then
                local function y()
                  l:TeleportToPlaceInstance(game.PlaceId,Z.id,z);
                end
                if pcall(y) then
                  return;
                end
              end
            end;
            if type(d.nextPageCursor)~="string" then
              break;
            end
            a=d.nextPageCursor;
          end;
          J(false,"No open servers");
        end;
        n.spawn(H);
      end;
      s:AddButton(L);
      q=P;
      q.Helpers:AddButton({Name="Copy Join Link",Callback=function()
        if setclipboard and pcall(setclipboard,(("roblox://experiences/start?placeId=%d&gameInstanceId=%s"):format(game.PlaceId,game.JobId))) then
          J(true,"join link copied");
        else
          J(false,"No clipboard support");
        end
      end});
    end;
  end;
end
