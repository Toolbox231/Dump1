-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #66
-- offset 3239655..3239992 (337 bytes, type=payload)

local function K()
  local _=O;
  if _ then
    return;
  end
  local k,i=n;
  _=T;
  local function i(E)
    s(E);
    task.spawn(q);
  end
  O=k:AddSignal(_.CharacterAdded:Connect(i));
  k=T;
  s(k.Character);
  k=T;
  V=k.CharacterAppearanceLoaded:Connect(function(s)
    local _;
    local _,k=z[4][z[6]];
    if _ then
      local i=T;
      k=i.Character==s;
    else
      k=_;
    end
    if k then
      task.spawn(q);
    end
  end);
end
