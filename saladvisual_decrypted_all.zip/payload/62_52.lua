-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #52
-- offset 3236547..3237138 (591 bytes, type=payload)

function()
  local S=z[4][z[6]]and b.On and m and m.Parent;
  if not S then
    return;
  end
  if not E.Parent then
    return;
  end
  S=y;
  local zP,zP=P,S.Visibility.Character(P.camera(),i,E);
  S=nP~=zP;
  if S then
    nP=zP;
    for P,P in ipairs(_)do
      if P[1].Parent then
        P[1].LocalTransparencyModifier=zP and P[2]or 1;
      end
    end;
  end
  local P,_,nP=E.CFrame,b.Rotations[k.Name]or 0,os.clock()>=TP;
  if nP then
    TP=os.clock()+0.2;
    LP(i);
  end
  nP=R==P and lP==_;
  if nP then
    return;
  end
  R,lP=P,_;
  S,zP,nP=P.LookVector,P.Position,m;
  nP:PivotTo(CFrame.new(zP.X,zP.Y+g,zP.Z)*CFrame.fromEulerAnglesYXZ(0,math.atan2(-S.X,-S.Z)+math.rad(_),0)*u);
end
