-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #61
-- offset 3678233..3678673 (440 bytes, type=payload)

function()
  if isfile and isfile("emotes.json") then
    local q=game:GetService("HttpService"):JSONDecode(readfile("emotes.json"));
    if type(q)=="table" then
      for b,D in pairs(q)do
        local q,p;
        if type(D)=="table" then
          q,p=(tostring(D.name or D[1]or b)),D.id or D[2];
        else
          q,p=tostring(b),D;
        end
        b=tonumber(tostring(p or""):gsub("%D",""))or 0;
        if q~=""and b>0 and not C[b] then
          C[b]=true;
          l.EmoteCatalog[#l.EmoteCatalog+1]={id=b,name=j(q)};
        end
      end;
    end
  end
end
