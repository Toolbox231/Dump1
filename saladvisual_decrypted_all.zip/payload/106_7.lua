-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[106] / function #7
-- offset 3637055..3638269 (1214 bytes, type=payload)

local function j(C)
  local N=os.clock();
  if C.model and C.model.Parent then
    if not C.dirty or N<C.rebuildAt then
      return true;
    end
    C.model:Destroy();
    C.model=nil;
    C.links=nil;
    C.highlight=nil;
  elseif N<C.rebuildAt then
    return false;
  end
  local q=C.character;
  local b=q.Archivable;
  pcall(function()
    q.Archivable=true;
  end);
  local D,p=pcall(q.Clone,q);
  pcall(function()
    q.Archivable=b;
  end);
  if not D or not p then
    C.rebuildAt=N+0.5;
    return false;
  end
  for b,b in ipairs(p:GetDescendants())do
    if b:IsA("BasePart") then
      b.Anchored=true;
      b.CanCollide=false;
      b.CanTouch=false;
      b.CanQuery=false;
      b.CastShadow=false;
      b.Transparency=1;
    elseif b:IsA("Humanoid")or b:IsA("BaseScript")or b:IsA("Sound")or b:IsA("ValueBase")or b:IsA("Decal")or b:IsA("Texture")or b:IsA("ParticleEmitter")or b:IsA("Trail")or b:IsA("Beam")or b:IsA("Light")or b:IsA("Highlight")or b:IsA("BillboardGui")or b:IsA("SurfaceGui") then
      b:Destroy();
    end
  end;
  D={};
  L(q,p,D);
  N=Instance.new("Highlight");
  N.Name="BacktrackPlayerChams";
  N.Adornee=p;
  N.DepthMode=Enum.HighlightDepthMode.Occluded;
  N.Parent=p;
  local L=y;
  p.Name=L.RandomString();
  local q;
  local q,b=z;
  L=T;
  p:SetAttribute(q,L);
  p.Parent=workspace;
  C.model=p;
  C.links=D;
  C.highlight=N;
  C.history={};
  C.dirty=false;
  C.rebuildAt=0;
  return true;
end
