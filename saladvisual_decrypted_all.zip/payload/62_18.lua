-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #18
-- offset 3228884..3229296 (412 bytes, type=payload)

local function TP(nP,JP)
  local HP=JP and string.format("%.0f",JP)or nil;
  if not HP or JP<=0 or I[HP]~=nil or i[HP] then
    return;
  end
  i[HP]=true;
  task.spawn(function()
    local fP,aP=pcall(E.GetProductInfo,E,JP,Enum.InfoType.Asset);
    i[HP]=nil;
    I[HP]=fP and type(aP)=="table"and tonumber(aP.AssetTypeId)==Enum.AssetType.HairAccessory.Value or false;
    local i;
    fP=I[HP]and z[4][z[6]]and X and nP.Parent;
    if fP then
      F();
    end
  end);
end
