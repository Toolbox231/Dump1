-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #24
-- offset 3602432..3602655 (223 bytes, type=payload)

local function Q(t)
  return Y("TextLabel",{AnchorPoint=Vector2.new(0.5,0.5),BackgroundTransparency=1,Font=Enum.Font.GothamBold,TextSize=t,TextStrokeTransparency=0.5,Size=UDim2.fromOffset(160,14),Visible=false,ZIndex=8},O);
end
