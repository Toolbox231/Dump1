-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[119] / function #0
-- offset 3586638..3592977 (6339 bytes, type=payload)

function(s,s,s,s)
  return function(s,s,l,l)
    local l=s[1];
    local L=s[2];
    local y=s[3];
    local z=s[4];
    local T=s[5];
    local n=s[6];
    local J=s[7];
    local H=s[8];
    return function()
      local s,f={On=false};
      local f=l;
      f.MotionGraph=s;
      local a;
      local a,d,P=L,workspace;
      local L,P=y,false;
      local y,Z,G,Y,e,j,C,N,q,b,D,p,r,K,o,c=Color3.fromRGB(242,242,242),280,72,105,1,2.8,0.03333333333333333,0,0,0,{},{},{},{};
      local function m(S)
        local O;
        local O=z;
        O(S);
      end
      local function z()
        local S=L.Character;
        local O=S and(S:FindFirstChild("HumanoidRootPart"));
        if not O then
          return 0;
        end
        S=O.AssemblyLinearVelocity;
        return Vector3.new(S.X,0,S.Z).Magnitude;
      end
      local function S()
        local O=L.Character;
        local B=O and(O:FindFirstChildOfClass("Humanoid"));
        return math.max(1,B and B.WalkSpeed or 16);
      end
      local function O(B,A,w,F)
        local h;
        local h=T;
        local W=h("Line");
        W.Color=B;
        W.Thickness=A;
        W.Transparency=F;
        W.ZIndex=w;
        W.Visible=false;
        return W;
      end
      local function B()
        local A;
        local A=T;
        local T=A("Text");
        T.Center=true;
        T.Outline=true;
        T.Color=y;
        T.Size=12;
        T.ZIndex=904;
        T.Visible=false;
        return T;
      end
      local function T(A)
        while#p<A do
          r[#r+1]=O(Color3.new(0,0,0),e+2,901,0.45);
          p[#p+1]=O(y,e,902,1);
        end;
        while#p>A do
          m(table.remove(p));
          m(table.remove(r));
        end;
      end
      local function O()
        local A=o;
        if A then
          return;
        end
        o=B();
        o.Center=false;
        for A=1,6,1 do
          K[A]=B();
        end;
      end
      local function A()
        local w=o;
        if w then
          o.Visible=false;
        end
        for w=1,#p,1 do
          p[w].Visible=false;
          r[w].Visible=false;
        end;
        for w=1,#K,1 do
          K[w].Visible=false;
        end;
      end
      local function w()
        local F=c;
        if F then
          pcall(function()
            c:Disconnect();
          end);
          c=nil;
        end
        m(o);
        o=nil;
        for F=1,#p,1 do
          m(p[F]);
          m(r[F]);
        end;
        for F=1,#K,1 do
          m(K[F]);
        end;
        table.clear(p);
        table.clear(r);
        table.clear(K);
        table.clear(D);
        N,q=0,0;
      end
      local function m()
        table.clear(D);
        local F,h=os.clock(),z();
        b=h;
        for W=0,math.ceil(j/C),1 do
          local V,_=#D+1,{};
          _.t,_.v,D[V]=F-j+W*C,h,_;
        end;
        T(#D);
      end
      local function F()
        local h=o;
        if h then
          o.Color=y;
        end
        h=#p;
        for W=1,h,1 do
          p[W].Color=y;
          p[W].Thickness=e;
          r[W].Thickness=e+2;
        end;
        h=#K;
        for W=1,h,1 do
          K[W].Color=y;
        end;
      end
      local function h(W,V,_,X)
        return V-math.clamp(W/X-1,-1,1)*_*0.44;
      end
      local function W(V)
        local _=d.CurrentCamera;
        local d=not P or not _ or#D<2;
        if d then
          A();
          return;
        end
        d=_.ViewportSize;
        local X,x=math.min(Z,math.max(120,d.X-48)),math.min(G,math.max(36,d.Y-32));
        local k,v,I,i,E=math.floor(d.X*0.5-X*0.5),math.clamp(math.floor(d.Y*0.5+Y),x*0.5+8,d.Y-x*0.5-8),S(),V-j,#D;
        T(E);
        for T=1,E-1,1 do
          d,_=D[T],D[T+1];
          local S,Q=math.clamp((d.t-i)/j,0,1),math.clamp((_.t-i)/j,0,1);
          local t,R,g,u,U=math.clamp(math.min((S+Q)*6,(2-S-Q)*5),0,1),Vector2.new(k+S*X,h(d.v,v,x,I)),Vector2.new(k+Q*X,h(_.v,v,x,I)),p[T],r[T];
          u.From=R;
          u.To=g;
          u.Transparency=t;
          u.Visible=t>0.02;
          U.From=R;
          U.To=g;
          U.Transparency=t*0.42;
          U.Visible=t>0.02;
        end;
        d=D[E];
        _=math.clamp((d.t-i)/j,0,1);
        local T,S,Q,t=Vector2.new(k+_*X,h(d.v,v,x,I)),Vector2.new(k+X,h(b,v,x,I)),p[E],r[E];
        Q.From=T;
        Q.To=S;
        Q.Transparency=0.72;
        Q.Visible=true;
        t.From=T;
        t.To=S;
        t.Transparency=0.3;
        t.Visible=true;
        for R=E+1,#p,1 do
          p[R].Visible=false;
          r[R].Visible=false;
        end;
        d=o;
        d.Text=tostring(math.floor(b+0.5));
        t=o;
        t.Position=Vector2.new(k+X+5,S.Y-7);
        o.Color=y;
        o.Visible=true;
        while#K<12 do
          K[#K+1]=B();
        end;
        V,Q=math.max(0.8,I*0.08),0.42;
        for p=5,E-4,1 do
          _=D[p];
          if not _.checked then
            _.checked=true;
            t,S=_.v-D[p-4].v,D[p+4].v-_.v;
            if math.abs(t)>=V and(t*S<=0 or math.abs(S)<V*0.35) then
              T=nil;
              for r=p-1,1,-1 do
                d=D[r];
                if _.t-d.t>Q then
                  break;
                end
                if d.label~=nil then
                  T=d;
                  break;
                end
              end;
              local p=math.abs(t)-math.abs(S);
              if not T then
                _.label=math.floor(_.v+0.5);
                _.label_score=p;
              elseif p>(T.label_score or-1/0) then
                T.label=nil;
                T.label_score=nil;
                _.label=math.floor(_.v+0.5);
                _.label_score=p;
              end
            end
          end
        end;
        for p=1,#K,1 do
          K[p].Visible=false;
        end;
        t,Q={},0;
        for p=E,1,-1 do
          T=D[p];
          p=T.label~=nil and Q<#K;
          if p then
            _=(T.t-i)/j;
            d=_>0.04 and _<0.82;
            if d then
              local d,p,r=tostring(T.label),k+_*X,h(T.v,v,x,I)-15;
              S,V=math.max(8,#d*3.5+2),false;
              for T=1,#t,1 do
                local o=t[T];
                if p+S+5>o.x1 and p-S-5<o.x2 and r+13>o.y1 and r-3<o.y2 then
                  V=true;
                  break;
                end
              end;
              local T=not V;
              if T then
                Q+=1;
                local T=K[Q];
                T.Text=d;
                T.Position=Vector2.new(p,r);
                T.Color=y;
                T.Visible=true;
                t[#t+1]={x1=p-S,x2=p+S,y1=r-3,y2=r+13};
              else
              end
            else
            end
          else
          end
        end;
      end
      Y=180;
      local function T()
        w();
        O();
        m();
        F();
        c=a.RenderStepped:Connect(function(a)
          local d;
          local d=not n[4][n[6]]or not P;
          if d then
            A();
            return;
          end
          local p,r=z(),b;
          b=r+(p-r)*(1-math.exp(-a*18));
          N+=a;
          r,p=os.clock(),N>=C;
          if p then
            N%=C;
            D[#D+1]={t=r,v=b};
            d=r-j;
            while#D>2 and D[2].t<d do
              table.remove(D,1);
            end;
          end
          q+=a;
          d=q>=0.016666666666666666;
          if d then
            q%=0.016666666666666666;
            W(r);
          end
        end);
      end
      s.On=false;
      s.Color=y;
      s.Width=Z;
      s.Height=G;
      s.Thickness=e;
      s.OffsetY=Y;
      f=l;
      f.MotionGraphSet={set=function(z,a)
        local d=z=="color";
        if d then
          y=a;
          F();
        else
          local d=z=="width";
          if d then
            Z=a;
          else
            local d=z=="height";
            if d then
              G=a;
            else
              local d=z=="y";
              if d then
                Y=a;
              else
                local d=z=="thickness";
                if d then
                  e=a;
                  F();
                end
              end
            end
          end
        end
        local z,a,d,j;
        z,a,d,j,s.Color=Z,G,Y,e,y;
        s.Width,s.Height,s.OffsetY,s.Thickness=z,a,d,j;
      end};
      local y=l;
      y.StartMotionGraph=function()
        P=true;
        s.On=true;
        T();
      end;
      local y=l;
      y.ClearMotionGraph=function()
        P=false;
        s.On=false;
        w();
      end;
      f=l;
      f.MotionGraphStyle=F;
      local y;
      f=J;
      f:AddSignal(L.CharacterAdded:Connect(function()
        task.wait(0.4);
        local L;
        local L=n[4][n[6]]and P;
        if L then
          m();
        end
      end));
      local L;
      f=H;
      local L=f.ScreenInfo:AddLabel("Speed Graph");
      L:AddToggle({Default=false,Flag="motion_graph",Callback=function(y)
        if y then
          local y=l;
          y.StartMotionGraph();
        else
          local y=l;
          y.ClearMotionGraph();
        end
      end});
      L:AddColorPicker({Default=s.Color,Flag="motion_graph_color",Callback=function(s)
        local y=l;
        y.MotionGraphSet.set("color",s);
      end});
      f=L:AddOption(1);
      local s,L=f:AddLabel("Width"),{Min=120,Max=600,Default=280,Rounding=0,Size=90,Flag="motion_graph_width"};
      L.Callback=function(y)
        local z=l;
        z.MotionGraphSet.set("width",y);
      end;
      s:AddSlider(L);
      local s,L=f:AddLabel("Height"),{Min=30,Max=200,Default=72,Rounding=0,Size=90,Flag="motion_graph_height"};
      L.Callback=function(y)
        local z=l;
        z.MotionGraphSet.set("height",y);
      end;
      s:AddSlider(L);
      local s,L=f:AddLabel("Offset"),{Min=40,Max=400,Default=180,Rounding=0,Size=90,Flag="motion_graph_offset"};
      L.Callback=function(y)
        local z=l;
        z.MotionGraphSet.set("y",y);
      end;
      s:AddSlider(L);
      local s,L=f:AddLabel("Thickness"),{Min=1,Max=5,Default=1,Rounding=0,Size=90,Flag="motion_graph_thickness"};
      L.Callback=function(y)
        local z=l;
        z.MotionGraphSet.set("thickness",y);
      end;
      s:AddSlider(L);
    end;
  end;
end
