-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #49
-- offset 124009..124281 (272 bytes, type=payload)

function(p)
  if not O.alive or w[p] then
    return;
  end
  w[p]=true;
  F(p);
  for A,A in ipairs(p:GetDescendants())do
    F(A);
  end;
  O.conns[#O.conns+1]=p.DescendantAdded:Connect(function(p)
    if not O.alive then
      return;
    end
    local A=F(p);
    if A and O.alive then
      local p,w=c(O);
      m(A,p,w);
    end
  end);
end
