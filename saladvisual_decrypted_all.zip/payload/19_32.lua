-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #32
-- offset 3606663..3607191 (528 bytes, type=payload)

local function S()
  local x=h();
  B=true;
  _(r,0.25,{Rotation=x.right==O and 0 or 180});
  local r=O;
  if r then
    _(q,0.26,{Position=UDim2.fromOffset(x.tucked,x.y)},Enum.EasingDirection.In);
    task.delay(0.26,function()
      B=false;
      local r=O;
      if r then
        q.Visible=false;
      end
    end);
  else
    q.Size=UDim2.fromOffset(x.width,x.height);
    q.Position=UDim2.fromOffset(x.tucked,x.y);
    local r,h=Z.shown==true;
    if r then
      local I=L;
      h=not I.Mobile;
    else
      h=r;
    end
    q.Visible=h;
    _(q,0.3,{Position=UDim2.fromOffset(x.open,x.y)});
    task.delay(0.3,function()
      B=false;
      v();
    end);
  end
end
