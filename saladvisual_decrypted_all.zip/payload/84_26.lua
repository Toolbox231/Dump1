-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #26
-- offset 3669906..3670139 (233 bytes, type=payload)

function(S)
  if l.PackName~=O then
    return;
  end
  local O,F,h=pcall(function()
    return N(S.Animation.AnimationId),S.Priority.Value;
  end);
  if O and h<=Enum.AnimationPriority.Movement.Value and not c[F] then
    pcall(function()
      S:Stop(0);
    end);
  end
end
