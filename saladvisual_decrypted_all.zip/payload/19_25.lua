-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #25
-- offset 3603211..3605360 (2149 bytes, type=payload)

local function R()
  I=0;
  h=T.AbsoluteSize;
  i.Visible=false;
  Y.Visible=false;
  O.Visible=false;
  local h,g,g=A;
  if h then
    local u=H;
    g=u.Enabled;
  else
    g=h;
  end
  if g then
    local g,u,U,M,sP=1/0,1/0,-1/0,-1/0,A;
    for lP,LP in ipairs(sP:GetChildren())do
      if LP:IsA("BasePart")and B[LP.Name] then
        h=LP.Size/2;
        for B,B in ipairs(_)do
          for yP,yP in ipairs(_)do
            for zP,zP in ipairs(_)do
              lP=x(LP.CFrame*Vector3.new(h.X*B,h.Y*yP,h.Z*zP));
              if lP then
                g,u,U=math.min(g,lP.X),math.min(u,lP.Y),math.max(U,lP.X);
                M=math.max(M,lP.Y);
              else
              end
            end;
          end;
        end;
      else
      end
    end;
    sP=U>g;
    if sP then
      local B,_,lP,lP,LP=Vector2.new(g-3,u-3),Vector2.new(U+3,M+3),H,math.clamp(tonumber(H.BoxThickness)or 1,1,4),H;
      local g=LP.Box;
      if g then
        local u,U,M=Vector2.new(_.X,B.Y),Vector2.new(B.X,_.Y),H;
        LP=M.BoxStyle=="Corner";
        if LP then
          local yP,zP=(_.X-B.X)*0.25,(_.Y-B.Y)*0.2;
          E(B,B+Vector2.new(yP,0),H.BoxColor,lP);
          E(B,B+Vector2.new(0,zP),H.BoxColor,lP);
          E(u,u-Vector2.new(yP,0),H.BoxColor,lP);
          E(u,u+Vector2.new(0,zP),H.BoxColor,lP);
          E(U,U+Vector2.new(yP,0),H.BoxColor,lP);
          E(U,U-Vector2.new(0,zP),H.BoxColor,lP);
          E(_,_-Vector2.new(yP,0),H.BoxColor,lP);
          E(_,_-Vector2.new(0,zP),H.BoxColor,lP);
        else
          M=H;
          E(B,u,M.BoxColor,lP);
          local yP=H;
          E(U,_,yP.BoxColor,lP);
          yP=H;
          E(B,U,yP.BoxColor,lP);
          yP=H;
          E(u,_,yP.BoxColor,lP);
        end
        M=H;
        u=M.BoxFilled;
        if u then
          i.Visible=true;
          M=H;
          i.BackgroundColor3=M.BoxColor;
          i.BackgroundTransparency=0.82;
          i.Position,i.Size=UDim2.fromOffset(B.X,B.Y),UDim2.fromOffset(_.X-B.X,_.Y-B.Y);
        end
      end
      LP=H;
      g=LP.Name;
      if g then
        Y.Visible=true;
        LP,lP=z;
        lP,Y.Text,Y.TextColor3=H,LP.DisplayName,H.NameColor;
        Y.Position=UDim2.fromOffset((B.X+_.X)/2,B.Y-9);
      end
      LP=H;
      g=LP.Distance;
      if g then
        O.Visible=true;
        LP=nil;
        LP,O.Text,O.TextColor3=H,("%dm"):format(math.floor((S.CFrame.Position-w).Magnitude+0.5)),H.NameColor;
        O.Position=UDim2.fromOffset((B.X+_.X)/2,_.Y+9);
      end
    end
    sP=H;
    local Y=sP.Skeleton;
    if Y then
      sP=ipairs;
      for Y,S in sP(t)do
        Y=A;
        local O,B=Y:FindFirstChild(S[1]),A;
        Y=B:FindFirstChild(S[2]);
        B=O and Y and O:IsA("BasePart")and Y:IsA("BasePart");
        if B then
          local B,_=x(O.Position),x(Y.Position);
          S=B and _;
          if S then
            local Y=H;
            E(B,_,Y.SkeletonColor,1);
          end
        end
      end;
    end
  end
  h=I+1;
  for H=h,#v,1 do
    v[H].Visible=false;
  end;
end
