-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[86] / function #49
-- offset 3220871..3221250 (379 bytes, type=payload)

local function J()
  m+=1;
  pcall(C);
  local K=y;
  local S=K.ApplyLighting;
  if S then
    pcall(y.ApplyLighting);
  end
  if G.Box=="Off" then
    h();
    return;
  end
  K=T[G.Box];
  if K then
    local K=T[G.Box];
    S=K.files;
    if S then
      local S,O=G.Box,m;
      task.spawn(function()
        local B=c(K);
        local c;
        local c=B and L[4][L[6]]and O==m and G.Box==S;
        if c then
          z(B);
        end
      end);
    else
      z(K);
    end
  elseif q[G.Box] then
    e(q[G.Box]);
  end
end
