-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #1
-- offset 18434..25584 (7150 bytes, type=payload)

function(s,s,l,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  local z=s[4];
  local T=s[5];
  local n=s[6];
  local J=s[7];
  local H=s[8];
  local f=s[9];
  return function()
    local s={On=false,Count=55,Mode="Theme",Color=Color3.fromRGB(120,200,255),Speed=16,Length=34,Width=2,Life=7,Glow=true};
    local a,d=Random.new(93882),{};
    local P,Z,G,Y,e,j,C,N,q,b={Vector3.new(1,0,0),Vector3.new(-1,0,0),Vector3.new(0,1,0),Vector3.new(0,-1,0),Vector3.new(0,0,1),Vector3.new(0,0,-1)},120,0.7,1.4,0.22,{14,24,36,50,66,84},0,2.39996323,0;
    local b=l;
    local D,p=b.pool("Line",function(r)
      r.Visible=false;
    end),l;
    local r,K,o,c=p.gui("glyphdots",-3),{},0;
    task.spawn(function()
      local m,S=pcall(function()
        local O;
        local O,B=L,L;
        return O.id(B.file("particles/p_bloom.png"));
      end);
      local L;
      local L=y[4][y[6]]and m;
      if L then
        c=S;
      end
    end);
    local function L()
      local y=not c or o>=420;
      if y then
        return nil;
      end
      o+=1;
      y=K[o];
      local m=not y;
      if m then
        y=Instance.new("ImageLabel");
        y.Name="Bloom";
        y.AnchorPoint=Vector2.new(0.5,0.5);
        y.BackgroundTransparency=1;
        y.BorderSizePixel=0;
        y.Image=c;
        y.ResampleMode=Enum.ResamplerMode.Default;
        y.Visible=false;
        y.Parent=r;
        K[o]=y;
      else
      end
      return y;
    end
    local function y()
      D.done();
      local r=o+1;
      for c=r,#K,1 do
        if K[c].Visible then
          K[c].Visible=false;
        end
      end;
    end
    local r;
    local function c()
      local m=r;
      if m then
        pcall(function()
          r:Disconnect();
        end);
        r=nil;
      end
      D.wipe();
      for m,m in ipairs(K)do
        pcall(function()
          m:Destroy();
        end);
      end;
      table.clear(K);
      table.clear(d);
      o=0;
    end
    local function K(m)
      local S=l;
      local O=S.camera();
      if not O then
        return nil;
      end
      local B,A=O.CFrame,C;
      C=A%#j+1;
      q+=N;
      A=j[C]*a:NextNumber(0.85,1.15);
      S=A*0.7;
      O=math.sqrt(a:NextNumber(0.05,1))*S;
      local j,C,N=B.Position+B.LookVector*A+B.RightVector*math.cos(q)*O+B.UpVector*math.sin(q)*O*0.6,P[a:NextInteger(1,6)],s.Life*a:NextNumber(0.7,1.35);
      return{pts={j},sx={},sy={},son={},sfar={},head=j,dir=C,goal=C,turn=1,run=0,leg=a:NextNumber(3,9),life=N,age=m and a:NextNumber(0,N*0.8)or 0,phase=a:NextNumber(0,1)};
    end
    local function j(C,N)
      C.age=C.age+N;
      if C.turn<1 then
        C.turn=math.min(1,C.turn+N/e);
        local e=C.turn*C.turn*(3-2*C.turn);
        local q=C.dir:Lerp(C.goal,e);
        if q.Magnitude>0.001 then
          C.dir=q.Unit;
        end
      end
      local e=s.Speed*N;
      C.head=C.head+C.dir*e;
      C.run=C.run+e;
      if C.run>=C.leg then
        C.pts[#C.pts+1]=C.head;
        C.goal=P[a:NextInteger(1,6)];
        C.turn=0;
        C.run=0;
        C.leg=a:NextNumber(3,9);
      end
      e=(C.head-C.pts[#C.pts]).Magnitude;
      for a=2,#C.pts,1 do
        e+=(C.pts[a]-C.pts[a-1]).Magnitude;
      end;
      N=e-s.Length;
      while N>0 and#C.pts>=2 do
        e=C.pts[2]-C.pts[1];
        local a=e.Magnitude;
        if a<=N then
          table.remove(C.pts,1);
          N-=a;
        else
          C.pts[1]=C.pts[1]+e.Unit*N;
          N=0;
        end
      end;
      if N>0 and#C.pts==1 then
        e=C.head-C.pts[1];
        if e.Magnitude>N then
          C.pts[1]=C.pts[1]+e.Unit*N;
        end
      end
    end
    local function a(P,e)
      if P.age>=P.life then
        return 0;
      end
      local C,N=math.min(1,P.age/G),P.life-P.age;
      C=if N<Y then math.min(C,N/Y)else C;
      N=(P.head-e).Magnitude;
      if N>Z then
        return 0;
      end
      return if N>Z*0.75 then C*(1-(N-Z*0.75)/(Z*0.25))else C;
    end
    local P;
    local function P(G,Y,e)
      if s.Mode=="Rainbow" then
        return Color3.fromHSV((e*0.11+G.phase)%1,0.85,1);
      end
      if s.Mode=="Single" then
        return s.Color;
      end
      e=z;
      local C=e.AccentColor or s.Color;
      local e,N,q=C:ToHSV();
      C=math.sin(Y*0.5+G.phase*6.283)*0.09;
      return Color3.fromHSV((e+C)%1,math.clamp(N,0.35,1),math.max(q,0.65));
    end
    local G,Y;
    local function e(C,N)
      if not(C and C.Visible and C.AbsoluteSize.X>8) then
        return;
      end
      local q,m=C.AbsolutePosition-Vector2.new(10,N),C.AbsolutePosition+C.AbsoluteSize+Vector2.new(10,10);
      G=G and Vector2.new(math.min(G.X,q.X),math.min(G.Y,q.Y))or q;
      Y=Y and Vector2.new(math.max(Y.X,m.X),math.max(Y.Y,m.Y))or m;
    end
    local function C(N,q,m,S)
      local O=G;
      if not O then
        return false;
      end
      local B,A,w,F=m-N,S-q,1,0;
      for h=1,4,1 do
        S,m,O=h==1;
        if S then
          m,O=-B,N-G.X;
        else
          local S=h==2;
          if S then
            m,O=B,Y.X-N;
          else
            local N=h==3;
            if N then
              m,O=-A,q-G.Y;
            else
              m,O=A,Y.Y-q;
            end
          end
        end
        if m==0 then
          if O<0 then
            return false;
          end
        else
          h=O/m;
          if m<0 then
            if h>w then
              return false;
            end
            F=if h>F then h else F;
          else
            if h<F then
              return false;
            end
            w=if h<w then h else w;
          end
        end
      end;
      return true;
    end
    local function N(q,m,S,O,B)
      if s.Glow then
        local A=D.take();
        A.From=q;
        A.To=m;
        A.Color=S;
        A.Thickness=math.max(1,O*3.2);
        A.Transparency=B*0.16;
        A.Visible=true;
      end
      local A=D.take();
      A.From=q;
      A.To=m;
      A.Color=S;
      A.Thickness=math.max(1,O);
      A.Transparency=B;
      A.Visible=true;
    end
    local q,m,S=true,z;
    local S,O=T;
    r=m:AddSignal(S.RenderStepped:Connect(function(T)
      local r=z;
      if not r.ScreenGui.Parent then
        return;
      end
      r=not s.On;
      if r then
        local z=q;
        if z then
          q=false;
          D.reset();
          o=0;
          if #d>0 then
            table.clear(d);
          end
          y();
        end
        return;
      end
      q=true;
      D.reset();
      o=0;
      r=l;
      local z=r.basis();
      if not z then
        y();
        return;
      end
      T=math.min(T,0.1);
      r=z.pos;
      for q=#d,1,-1 do
        local D=d[q];
        j(D,T);
        if D.age>=D.life or(D.head-r).Magnitude>Z*1.3 then
          table.remove(d,q);
        end
      end;
      local T=3;
      while#d<s.Count and T>0 do
        T-=1;
        local T=K(#d<s.Count*0.5);
        if not T then
          break;
        end
        d[#d+1]=T;
      end;
      G,Y=nil,nil;
      local T=n;
      local G,Y=T.WindowFrame;
      if G then
        T=n;
        Y=T.WindowFrame();
      else
        Y=G;
      end
      e(Y,42);
      local j;
      G,T=J;
      if G then
        Y=J;
        T=Y.Panel;
      else
        T=G;
      end
      e(T,10);
      Y,T=os.clock(),ipairs;
      for J,e in T(d)do
        G=a(e,r);
        local T=G>0.02;
        if T then
          local T=e.pts;
          local a,j,q,D,r,K=#T,P(e,J,Y),e.sx,e.sy,e.son,e.sfar;
          for J=1,a,1 do
            local P=l;
            local Y,o,S=P.project(z,T[J]);
            q[J],D[J],r[J]=Y,o,S>0;
            K[J]=S;
          end;
          T=l;
          local l,J,P=T.project(z,e.head);
          T=a+1;
          q[T],D[T],r[T]=l,J,P>0;
          K[T]=P;
          for z=2,T,1 do
            if r[z-1]and r[z] then
              local Y,e,o,S=q[z-1],D[z-1],q[z],D[z];
              if not C(Y,e,o,S) then
                l,P,J=Vector2.new(Y,e),Vector2.new(o,S),(z-1)/a;
                local Y,e=G*(0.08+0.92*J),math.clamp(1-K[z]/Z,0.12,1);
                if Y>0.02 then
                  N(l,P,j,s.Width*e*(0.45+0.55*J),Y);
                end
              end
            end
          end;
          if s.Glow then
            for z=2,a,1 do
              if r[z] then
                T=L();
                if not T then
                  break;
                end
                l,J=(z-1)/a,math.clamp(1-K[z]/Z,0.12,1);
                P=math.max(7,s.Width*J*11);
                T.Position=UDim2.fromOffset(q[z],D[z]);
                T.Size=UDim2.fromOffset(P,P);
                T.ImageColor3=j;
                T.ImageTransparency=1-math.clamp(G*(0.12+0.88*l)*0.85,0,1);
                T.Visible=true;
              end
            end;
          end
        end
      end;
      y();
    end));
    b=n;
    b.Glyphs=s;
    local l,L=n;
    p=H;
    l.ClearGlyphs=p("glyphs",c);
    local L;
    m=f;
    l=m.Glyphs:AddLabel("Enabled");
    l:AddToggle({Default=false,Flag="glyphs",Callback=function(L)
      s.On=L;
      if not L then
        table.clear(d);
      end
    end});
    l:AddColorPicker({Default=s.Color,Flag="glyphs_color",Callback=function(l)
      s.Color=l;
    end});
    p=f;
    p.Glyphs:AddLabel("Color"):AddDropdown({Default="Theme",Values={"Theme","Rainbow","Single"},Flag="glyphs_mode",Callback=function(l)
      s.Mode=l;
    end});
    b=f;
    b.Glyphs:AddLabel("Count"):AddSlider({Min=8,Max=160,Default=55,Rounding=0,Size=100,Flag="glyphs_count",Callback=function(l)
      s.Count=l;
    end});
    p=f;
    p.Glyphs:AddLabel("Speed"):AddSlider({Min=1,Max=90,Default=16,Rounding=0,Size=100,Flag="glyphs_speed",Callback=function(l)
      s.Speed=l;
    end});
    m=f;
    m.Glyphs:AddLabel("Trail"):AddSlider({Min=6,Max=120,Default=34,Rounding=0,Size=100,Flag="glyphs_length",Callback=function(l)
      s.Length=l;
    end});
    b=f;
    b.Glyphs:AddLabel("Lifetime"):AddSlider({Min=2,Max=25,Default=7,Rounding=0,Size=100,Type="s",Flag="glyphs_life",Callback=function(l)
      s.Life=l;
    end});
    p=f;
    p.Glyphs:AddLabel("Width"):AddSlider({Min=1,Max=8,Default=2,Rounding=0,Size=100,Flag="glyphs_width",Callback=function(l)
      s.Width=l;
    end});
    p=f;
    p.Glyphs:AddLabel("Glow"):AddToggle({Default=true,Flag="glyphs_glow",Callback=function(l)
      s.Glow=l;
    end});
  end;
end
