-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #320
-- offset 3385435..3391840 (6405 bytes, type=payload)

local function NP(wP,WP,VP,_P)
  local XP,xP=s[87](),{[l[404]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
  local kP=a(l[1742],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1243]},YP);
  local vP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[209]},YP)or nil;
  local IP=vP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=XP[l[740]][l[772]](l[393],l[558]),[l[1485]]=XP[l[1459]][l[588]](l[393],l[786]),[l[1326]]=XP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},vP)or nil;
  if vP then
    D(vP,l[1092]);
  end
  local iP=a(l[1751],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1655]},YP);
  D(iP,l[1092]);
  local EP,QP=l[1622],{[l[500]]=l[117]};
  QP[l[1630]]=XP[l[1262]][l[772]]({XP[l[527]][l[772]](l[393],XP[l[360]][l[772]](l[229],l[229],l[229])),XP[l[527]][l[772]](l[229],XP[l[360]][l[353]](l[291],l[291],l[920]))});
  a(EP,QP,iP);
  EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[658]},iP);
  D(EP,l[1092]);
  a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},EP);
  QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},iP);
  EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},QP);
  D(EP,l[1092]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=XP[l[1689]][l[772]](l[393],l[229]),[l[948]]=XP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},EP);
  local tP=a;
  local RP=l[859];
  local gP={};
  gP[l[1150]]=f();
  gP[l[1016]]=XP[l[1689]][l[772]](l[393],l[659]);
  gP[l[948]]=XP[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
  gP[l[1639]]=XP[l[1459]][l[588]](l[310],l[310]);
  gP[l[1646]]=l[229];
  gP[l[1451]]=y[30](l[1716]);
  gP[l[936]]=R[l[1379]];
  gP[l[2]]=l[1431];
  gP[l[1557]]=XP[l[128]][l[1557]][l[220]];
  gP[l[711]]=l[1660];
  tP(RP,gP,EP);
  a(l[1070],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=XP[l[128]][l[437]][l[1381]],[l[1420]]=WP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=XP[l[128]][l[164]][l[1021]],[l[1634]]=XP[l[128]][l[1634]][l[701]],[l[711]]=l[1660]},EP);
  K(a(l[211],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1660]},QP),l[393],{XP[l[677]][l[772]](l[393],l[229]),XP[l[677]][l[772]](l[841],l[874]),XP[l[677]][l[772]](l[659],l[393]),XP[l[677]][l[772]](l[804],l[874]),XP[l[677]][l[772]](l[229],l[229])});
  local tP=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=XP[l[1459]][l[588]](l[393],l[913]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=XP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=XP[l[128]][l[62]][l[636]],[l[711]]=l[1655]},QP);
  local QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=XP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},tP);
  EP,WP=l[755],{[l[407]]=XP[l[128]][l[407]][l[537]]};
  WP[l[536]]=XP[l[740]][l[772]](l[393],l[229]);
  a(EP,WP,QP);
  a(l[1359],{[l[299]]=XP[l[740]][l[772]](l[393],l[1158]),[l[645]]=XP[l[740]][l[772]](l[393],l[930]),[l[1612]]=XP[l[740]][l[772]](l[393],l[303]),[l[517]]=XP[l[740]][l[772]](l[393],l[303])},QP);
  local function WP()
    local XP,EP=s[87](),e(YP);
    local RP=XP[l[35]][l[499]](e(VP)[l[1437]]+l[659]);
    return XP[l[35]][l[819]](RP,l[1592],XP[l[35]][l[850]](XP[l[35]][l[499]](EP[l[1437]])-l[1655],l[1592]));
  end
  local function XP()
    local EP,RP=s[87](),e(YP);
    local gP=EP[l[35]][l[850]](EP[l[35]][l[499]](e(QP)[l[636]]+l[659]),l[658]);
    return EP[l[35]][l[819]](l[913]+gP,l[1167],EP[l[35]][l[850]](EP[l[35]][l[499]](RP[l[636]])-l[1655],l[1167]));
  end
  local function EP()
    local RP,gP,uP,UP,MP,sC,lC=s[87](),G(YP),e(YP),G(VP),e(VP),G(wP),e(wP);
    local LC,yC=UP[l[1437]]-gP[l[1437]]+MP[l[1437]]+l[930],UP[l[1437]]-gP[l[1437]]-xP[l[559]]-l[930];
    UP,MP=if LC+xP[l[559]]>uP[l[1437]]-l[930]then yC>=l[930]and yC or RP[l[35]][l[850]](l[930],uP[l[1437]]-l[930]-xP[l[559]])else LC,RP[l[35]][l[819]](sC[l[636]]-gP[l[636]]+lC[l[636]]*l[659]-xP[l[434]]*l[659],l[930],RP[l[35]][l[850]](l[930],uP[l[636]]-xP[l[434]]-l[930]));
    iP[l[948]]=RP[l[1459]][l[588]](RP[l[35]][l[499]](UP+l[659]),RP[l[35]][l[499]](MP+l[659]));
    if vP then
      vP[l[948]]=iP[l[948]];
    end
  end
  local function RP()
    local gP=iP[l[1569]];
    local uP=xP[l[404]]and l[393]or l[229];
    b(iP,xP[l[404]]and l[894]or l[304],xP[l[404]]and N or q,function(UP)
      local MP=gP+(uP-gP)*UP;
      iP[l[1569]]=MP;
      if vP then
        vP[l[1646]]=MP;
        IP[l[747]]=l[330]+l[1419]*MP;
      end
      if UP>=l[229] then
        iP[l[1324]]=xP[l[404]];
        if vP then
          vP[l[1324]]=xP[l[404]];
        end
      end
    end);
  end
  local function IP()
    local gP=s[87]();
    xP[l[559]]=WP();
    xP[l[434]]=XP();
    iP[l[1639]]=gP[l[1459]][l[588]](xP[l[559]],xP[l[434]]);
    if vP then
      vP[l[1639]]=iP[l[1639]];
    end
  end
  local WP;
  local function XP()
    local gP=WP;
    if gP then
      WP:Disconnect();
      WP=nil;
    end
  end
  local function gP()
    local uP=S;
    if uP>l[393] then
      EP();
      return;
    end
    if not LP[l[1600]]or not KP[l[1324]]or not wP[l[1324]] then
      xP:setopen(l[1329]);
      return;
    end
    local UP,MP,sC,lC,LC,yC=VP[l[81]],VP[l[160]],_P[l[81]],_P[l[160]],wP[l[81]],wP[l[160]];
    uP=LC[l[636]]+yC[l[636]]*l[659];
    if uP<UP[l[636]]or uP>UP[l[636]]+MP[l[636]]or uP<sC[l[636]]or uP>sC[l[636]]+lC[l[636]] then
      xP:setopen(l[1329]);
      return;
    end
    EP();
  end
  local function wP(VP,_P)
    local uP={};
    VP=s[87]();
    _P=_P and l[383]or l[1329];
    if xP[l[404]]==_P then
      return;
    end
    xP[l[404]]=_P;
    if _P then
      IP();
      iP[l[1324]]=l[383];
      kP[l[1324]]=l[383];
      tP[l[1690]]=VP[l[1689]][l[772]]();
      if vP then
        vP[l[1324]]=l[383];
      end
      EP();
      XP();
      y[21](iP);
      uP[1]=(y[10][l[1119]]:Connect(gP));
      WP=uP[1];
    else
      XP();
      V();
      y[20](iP);
      kP[l[1324]]=l[1329];
    end
    RP();
  end
  xP[l[1521]--[[0]]]=wP;
  d(QP:GetPropertyChangedSignal(l[160]),function()
    local wP=s[87]();
    tP[l[392]]=wP[l[1459]][l[588]](l[393],wP[l[35]][l[499]](e(QP)[l[636]]+l[659]));
    if xP[l[404]] then
      IP();
      EP();
    end
  end);
  d(kP[l[445]],function()
    local wP=S;
    if wP>l[393] then
      return;
    end
    xP:setopen(l[1329]);
  end);
  xP[l[1594]--[[__index]]]=iP;
  xP[l[642]]=QP;
  xP[l[429]]=BP(QP,tP,tP);
  return xP;
end
