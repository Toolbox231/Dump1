-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[120] / function #30
-- offset 3657639..3657845 (206 bytes, type=payload)

local function s()
  local y=N.On and N.Types.Comet;
  if y then
    Q();
    local y=not x;
    if y then
      local y;
      local y,j=J;
      local j=H;
      x=y:AddSignal(j.RenderStepped:Connect(T));
    end
  else
    local y=F;
    if y<=0 then
      E();
    end
  end
end
