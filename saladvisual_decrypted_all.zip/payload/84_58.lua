-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #58
-- offset 3677096..3677616 (520 bytes, type=payload)

function(q)
  local r=l.SelectedEmoteId or l.PendingEmoteId;
  local K=l.PendingPack or l._resumePack or l.PackName;
  l.ResetEmote(true);
  D();
  C={};
  local C=l._request;
  task.spawn(function()
    local o,c=q:WaitForChild("Humanoid",10),q:WaitForChild("Animate",10);
    if c then
      c:WaitForChild("idle",5);
    end
    local m,S=not l.Alive or C~=l._request;
    if m then
      S=m;
    else
      c=z;
      S=c.Character~=q;
    end
    if S or not o then
      return;
    end
    if r then
      l._resumePack=K~="Default"and K or nil;
      l.PlayEmote(r);
    elseif K and K~="Default" then
      l.ApplyPack(K);
    end
  end);
end
