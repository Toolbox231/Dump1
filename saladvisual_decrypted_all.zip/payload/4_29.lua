-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #29
-- offset 3250771..3251788 (1017 bytes, type=payload)

function()
  local X=C[V];
  if X then
    local x=Instance.new("Attachment");
    x:SetAttribute("VisualsGunAura",true);
    local k=Instance.new("ParticleEmitter");
    k:SetAttribute("VisualsGunAura",true);
    k.Enabled=false;
    k.LightEmission=1;
    k.LightInfluence=0;
    k.Lifetime=NumberRange.new(0.6,1.2);
    k.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(0.15,0.25),NumberSequenceKeypoint.new(0.7,0.4),NumberSequenceKeypoint.new(1,1)});
    k.Parent=x;
    x.Parent=h;
    task.defer(function()
      local v;
      local v=d;
      local I,I=d,v.id(d.file("particles/"..C[V]..".png"));
      local d;
      v=T[4][T[6]]and j[F]==a and a.AuraEffect==x and x.Parent and I;
      if v then
        k.Texture,k.Enabled=I,Y.On and Y.Aura;
      end
    end);
    return x;
  end
  if V=="Sparkle"or V=="Fire"or V=="Smoke" then
    X=Instance.new(V=="Sparkle"and"Sparkles"or V);
    X:SetAttribute("VisualsGunAura",true);
    if V=="Fire" then
      X.Size=1.2;
      X.Heat=0.3;
    end
    if V=="Smoke" then
      X.Size=0.75;
      X.Opacity=0.12;
      X.RiseVelocity=0.4;
    end
    X.Parent=h;
    return X;
  end
  local d=w(h);
  if d then
    d.Parent=b;
  end
  return d;
end
