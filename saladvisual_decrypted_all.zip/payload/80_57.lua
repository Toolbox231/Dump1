-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #57
-- offset 3276730..3277205 (475 bytes, type=payload)

function(X)
  local Q=s[87]();
  if X[l[1317]]~=Q[l[128]][l[1317]][l[1356]]and X[l[1317]]~=Q[l[128]][l[1317]][l[239]] then
    return;
  end
  local t,R=X[l[948]],x[l[948]];
  Q[l[1022]][l[153]]();
  local g=S;
  if g>l[393]or X[l[1101]]==Q[l[128]][l[1101]][l[912]] then
    return;
  end
  k,v,i=l[383],t,R;
  E=X[l[1317]]==Q[l[128]][l[1317]][l[239]]and X or nil;
  local Q;
  Q=X[l[1551]]:Connect(function()
    local t=s[87]();
    local R=X[l[1101]]==t[l[128]][l[1101]][l[912]];
    if R then
      k=l[1329];
      Q:Disconnect();
    end
  end);
end
