-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #307
-- offset 3380912..3450121 (69209 bytes, type=payload)

local function F(fP,aP)
  fP=s[87]();
  aP=X(aP,{[l[572]]=l[146],[l[1132]]=l[356]});
  local NP=AP(aP[l[1132]]);
  local BP,wP=mP(NP);
  local FP={[l[590]]=wP,[l[572]]=aP[l[572]],[l[12]]={}};
  local hP=oP..l[1074]..aP[l[572]];
  fP[l[1346]][l[968]](OP,FP);
  local WP,VP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
  VP[l[536]]=fP[l[740]][l[772]](l[393],l[393]);
  a(WP,VP,BP);
  WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[537]]=l[229],[l[711]]=l[303]},BP);
  D(WP,l[1092]);
  a(l[211],{[l[1150]]=f(),[l[1016]]=fP[l[1689]][l[772]](l[393],l[229]),[l[948]]=fP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1646]]=l[393],[l[1418]]=l[393],[l[711]]=l[303]},WP);
  a(l[1070],{[l[1150]]=f(),[l[948]]=fP[l[1459]][l[588]](l[730],l[393]),[l[1639]]=fP[l[1459]][l[772]](l[229],l[644],l[229],l[393]),[l[1646]]=l[229],[l[437]]=fP[l[128]][l[437]][l[1381]],[l[1420]]=aP[l[572]],[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=fP[l[128]][l[164]][l[1021]],[l[1634]]=fP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
  local _P=a;
  local XP=l[859];
  local xP={};
  xP[l[1150]]=f();
  xP[l[1016]]=fP[l[1689]][l[772]](l[229],l[659]);
  xP[l[948]]=fP[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
  xP[l[1639]]=fP[l[1459]][l[588]](l[750],l[750]);
  xP[l[1646]]=l[229];
  xP[l[1451]]=y[30](l[606]--[[readu16]]);
  xP[l[936]]=R[l[1379]];
  xP[l[2]]=l[615];
  xP[l[500]]=l[1510];
  xP[l[711]]=l[1158];
  local kP=_P(XP,xP,WP);
  aP=a(l[1742],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},WP);
  K(a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[537]]=l[59],[l[711]]=l[1158]},BP),l[393],{fP[l[677]][l[772]](l[393],l[229]),fP[l[677]][l[772]](l[841],l[874]),fP[l[677]][l[772]](l[659],l[393]),fP[l[677]][l[772]](l[804],l[874]),fP[l[677]][l[772]](l[229],l[229])});
  local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=l[863],[l[711]]=l[303]},BP);
  local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=fP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=fP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[711]]=l[303]},WP);
  VP,wP=l[755],{[l[407]]=fP[l[128]][l[407]][l[537]]};
  wP[l[536]]=fP[l[740]][l[772]](l[393],l[229]);
  a(VP,wP,_P);
  a(l[1359],{[l[299]]=fP[l[740]][l[772]](l[393],l[1158]),[l[645]]=fP[l[740]][l[772]](l[393],l[930]),[l[1612]]=fP[l[740]][l[772]](l[393],l[303]),[l[517]]=fP[l[740]][l[772]](l[393],l[303])},_P);
  local fP={[l[675]]=BP,[l[1577]]=_P,[l[668]]=l[393],[l[1600]]=l[383]};
  d(_P:GetPropertyChangedSignal(l[160]),function()
    local BP=s[87]();
    if fP[l[1600]]and not fP[l[1678]] then
      WP[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],e(_P)[l[636]]);
    end
  end);
  local function BP()
    local wP,VP=s[87](),WP[l[1639]][l[636]][l[1485]];
    fP[l[1678]]=l[383];
    wP[l[1022]][l[1061]](function()
      local wP=fP[l[1600]]and e(_P)[l[636]]or l[393];
      b(WP,l[1491],wP>=VP and N or q,function(XP)
        local xP=s[87]();
        WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],xP[l[35]][l[499]](VP+(wP-VP)*XP+l[659]));
        if XP>=l[229] then
          fP[l[1678]]=l[1329];
          WP[l[1639]]=xP[l[1459]][l[772]](l[229],l[393],l[393],fP[l[1600]]and e(_P)[l[636]]or l[393]);
        end
      end);
    end);
  end
  fP[l[721]]=BP;
  local function BP(wP,wP)
    fP[l[1600]]=wP and l[383]or l[1329];
    local wP=kP[l[500]];
    local VP=fP[l[1600]]and l[1510]or l[393];
    b(kP,l[894],N,function(XP)
      kP[l[500]]=wP+(VP-wP)*XP;
    end);
    fP[l[721]]();
  end
  fP[l[1521]--[[0]]]=BP;
  FP[l[1654]]=fP[l[721]];
  FP[l[1637]]=function(BP)
    if BP==nil then
      if FP[l[1626]]~=nil then
        local wP=FP[l[1626]];
        FP[l[1626]]=nil;
        if fP[l[1600]]~=wP then
          fP:setopen(wP);
        end
      end
      return;
    end
    if BP and not fP[l[1600]] then
      if FP[l[1626]]==nil then
        FP[l[1626]]=l[1329];
      end
      fP:setopen(l[383]);
    end
  end;
  d(aP[l[445]],function()
    fP:setopen(not fP[l[1600]]);
    y[18]:chime(l[1352]);
  end);
  d(aP[l[1538]],function()
    P(kP,H,{[l[2]]=l[1209]});
  end);
  d(aP[l[1628]],function()
    P(kP,H,{[l[2]]=l[615]});
  end);
  local aP={[l[1594]--[[__index]]]=_P,[l[438]]=NP[l[1594]--[[__index]]],[l[745]]=WP};
  local NP={l[524],l[1223],l[166],l[654],l[1336],l[1409],l[138],l[1094]};
  local function BP(wP,WP,VP)
    local _P={};
    for XP,XP in y[3],NP,nil do
      _P[XP]=function(NP,NP)
        local xP,kP,vP,IP=s[87](),aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
        aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=wP,WP,VP;
        local wP,WP=xP[l[1146]](fP[XP],fP,NP);
        aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]]=kP,vP,IP;
        if not wP then
          xP[l[279]](WP,l[59]);
        end
        xP[l[1346]][l[1357]](FP[l[12]]);
        return WP;
      end;
    end;
    return _P;
  end
  local function NP(wP,WP,VP,_P)
    local XP,xP=s[87](),{[l[404]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
    local kP=a(l[1742],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1243]},YP);
    local vP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[209]},YP)or nil;
    local IP=vP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=XP[l[740]][l[772]](l[393],l[558]),[l[1485]]=XP[l[1459]][l[588]](l[393],l[786]),[l[1326]]=XP[l[1459]][l[588]](l[1402]--[[-1]],l[1402]--[[-1]]),[l[747]]=l[229],[l[711]]=l[715]},vP)or nil;
    if vP then
      D(vP,l[1092]);
    end
    local iP=a(l[1751],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1655]},YP);
    D(iP,l[1092]);
    local EP,QP=l[1622],{[l[500]]=l[117]};
    QP[l[1630]]=XP[l[1262]][l[772]]({XP[l[527]][l[772]](l[393],XP[l[360]][l[772]](l[229],l[229],l[229])),XP[l[527]][l[772]](l[229],XP[l[360]][l[353]](l[291],l[291],l[920]))});
    a(EP,QP,iP);
    EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[658]},iP);
    D(EP,l[1092]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},EP);
    QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},iP);
    EP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[1249]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},QP);
    D(EP,l[1092]);
    a(l[211],{[l[1150]]=f(),[l[1016]]=XP[l[1689]][l[772]](l[393],l[229]),[l[948]]=XP[l[1459]][l[1368]](l[393],l[229]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[930]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[711]]=l[1655]},EP);
    local tP=a;
    local RP=l[859];
    local gP={};
    gP[l[1150]]=f();
    gP[l[1016]]=XP[l[1689]][l[772]](l[393],l[659]);
    gP[l[948]]=XP[l[1459]][l[772]](l[393],l[730],l[659],l[393]);
    gP[l[1639]]=XP[l[1459]][l[588]](l[310],l[310]);
    gP[l[1646]]=l[229];
    gP[l[1451]]=y[30](l[1716]);
    gP[l[936]]=R[l[1379]];
    gP[l[2]]=l[1431];
    gP[l[1557]]=XP[l[128]][l[1557]][l[220]];
    gP[l[711]]=l[1660];
    tP(RP,gP,EP);
    a(l[1070],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[860],l[229],l[393]),[l[1646]]=l[229],[l[437]]=XP[l[128]][l[437]][l[1381]],[l[1420]]=WP,[l[510]]=R[l[1095]],[l[723]]=l[750],[l[164]]=XP[l[128]][l[164]][l[1021]],[l[1634]]=XP[l[128]][l[1634]][l[701]],[l[711]]=l[1660]},EP);
    K(a(l[211],{[l[1150]]=f(),[l[948]]=XP[l[1459]][l[588]](l[393],l[1249]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[59]),[l[1535]]=R[l[98]],[l[1646]]=l[323],[l[1418]]=l[393],[l[711]]=l[1660]},QP),l[393],{XP[l[677]][l[772]](l[393],l[229]),XP[l[677]][l[772]](l[841],l[874]),XP[l[677]][l[772]](l[659],l[393]),XP[l[677]][l[772]](l[804],l[874]),XP[l[677]][l[772]](l[229],l[229])});
    local tP=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=XP[l[1459]][l[588]](l[393],l[913]),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[229],l[1263]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=XP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=XP[l[128]][l[62]][l[636]],[l[711]]=l[1655]},QP);
    local QP=a(l[211],{[l[1150]]=f(),[l[1639]]=XP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=XP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1655]},tP);
    EP,WP=l[755],{[l[407]]=XP[l[128]][l[407]][l[537]]};
    WP[l[536]]=XP[l[740]][l[772]](l[393],l[229]);
    a(EP,WP,QP);
    a(l[1359],{[l[299]]=XP[l[740]][l[772]](l[393],l[1158]),[l[645]]=XP[l[740]][l[772]](l[393],l[930]),[l[1612]]=XP[l[740]][l[772]](l[393],l[303]),[l[517]]=XP[l[740]][l[772]](l[393],l[303])},QP);
    local function WP()
      local XP,EP=s[87](),e(YP);
      local RP=XP[l[35]][l[499]](e(VP)[l[1437]]+l[659]);
      return XP[l[35]][l[819]](RP,l[1592],XP[l[35]][l[850]](XP[l[35]][l[499]](EP[l[1437]])-l[1655],l[1592]));
    end
    local function XP()
      local EP,RP=s[87](),e(YP);
      local gP=EP[l[35]][l[850]](EP[l[35]][l[499]](e(QP)[l[636]]+l[659]),l[658]);
      return EP[l[35]][l[819]](l[913]+gP,l[1167],EP[l[35]][l[850]](EP[l[35]][l[499]](RP[l[636]])-l[1655],l[1167]));
    end
    local function EP()
      local RP,gP,uP,UP,MP,sC,lC=s[87](),G(YP),e(YP),G(VP),e(VP),G(wP),e(wP);
      local LC,yC=UP[l[1437]]-gP[l[1437]]+MP[l[1437]]+l[930],UP[l[1437]]-gP[l[1437]]-xP[l[559]]-l[930];
      UP,MP=if LC+xP[l[559]]>uP[l[1437]]-l[930]then yC>=l[930]and yC or RP[l[35]][l[850]](l[930],uP[l[1437]]-l[930]-xP[l[559]])else LC,RP[l[35]][l[819]](sC[l[636]]-gP[l[636]]+lC[l[636]]*l[659]-xP[l[434]]*l[659],l[930],RP[l[35]][l[850]](l[930],uP[l[636]]-xP[l[434]]-l[930]));
      iP[l[948]]=RP[l[1459]][l[588]](RP[l[35]][l[499]](UP+l[659]),RP[l[35]][l[499]](MP+l[659]));
      if vP then
        vP[l[948]]=iP[l[948]];
      end
    end
    local function RP()
      local gP=iP[l[1569]];
      local uP=xP[l[404]]and l[393]or l[229];
      b(iP,xP[l[404]]and l[894]or l[304],xP[l[404]]and N or q,function(UP)
        local MP=gP+(uP-gP)*UP;
        iP[l[1569]]=MP;
        if vP then
          vP[l[1646]]=MP;
          IP[l[747]]=l[330]+l[1419]*MP;
        end
        if UP>=l[229] then
          iP[l[1324]]=xP[l[404]];
          if vP then
            vP[l[1324]]=xP[l[404]];
          end
        end
      end);
    end
    local function IP()
      local gP=s[87]();
      xP[l[559]]=WP();
      xP[l[434]]=XP();
      iP[l[1639]]=gP[l[1459]][l[588]](xP[l[559]],xP[l[434]]);
      if vP then
        vP[l[1639]]=iP[l[1639]];
      end
    end
    local WP;
    local function XP()
      local gP=WP;
      if gP then
        WP:Disconnect();
        WP=nil;
      end
    end
    local function gP()
      local uP=S;
      if uP>l[393] then
        EP();
        return;
      end
      if not LP[l[1600]]or not KP[l[1324]]or not wP[l[1324]] then
        xP:setopen(l[1329]);
        return;
      end
      local UP,MP,sC,lC,LC,yC=VP[l[81]],VP[l[160]],_P[l[81]],_P[l[160]],wP[l[81]],wP[l[160]];
      uP=LC[l[636]]+yC[l[636]]*l[659];
      if uP<UP[l[636]]or uP>UP[l[636]]+MP[l[636]]or uP<sC[l[636]]or uP>sC[l[636]]+lC[l[636]] then
        xP:setopen(l[1329]);
        return;
      end
      EP();
    end
    local function wP(VP,_P)
      local uP={};
      VP=s[87]();
      _P=_P and l[383]or l[1329];
      if xP[l[404]]==_P then
        return;
      end
      xP[l[404]]=_P;
      if _P then
        IP();
        iP[l[1324]]=l[383];
        kP[l[1324]]=l[383];
        tP[l[1690]]=VP[l[1689]][l[772]]();
        if vP then
          vP[l[1324]]=l[383];
        end
        EP();
        XP();
        y[21](iP);
        uP[1]=(y[10][l[1119]]:Connect(gP));
        WP=uP[1];
      else
        XP();
        V();
        y[20](iP);
        kP[l[1324]]=l[1329];
      end
      RP();
    end
    xP[l[1521]--[[0]]]=wP;
    d(QP:GetPropertyChangedSignal(l[160]),function()
      local wP=s[87]();
      tP[l[392]]=wP[l[1459]][l[588]](l[393],wP[l[35]][l[499]](e(QP)[l[636]]+l[659]));
      if xP[l[404]] then
        IP();
        EP();
      end
    end);
    d(kP[l[445]],function()
      local wP=S;
      if wP>l[393] then
        return;
      end
      xP:setopen(l[1329]);
    end);
    xP[l[1594]--[[__index]]]=iP;
    xP[l[642]]=QP;
    xP[l[429]]=BP(QP,tP,tP);
    return xP;
  end
  local function BP(wP,WP)
    wP=s[87]();
    WP=X(WP,{[l[572]]=l[524],[l[950]]=l[1329],[l[925]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local VP,_P,XP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
    local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},VP);
    local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[303],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[829],l[829]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},xP);
    D(VP,l[786]);
    local kP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[874]},VP);
    local vP=a;
    local IP=l[859];
    local iP={};
    iP[l[1150]]=f();
    iP[l[1016]]=wP[l[1689]][l[772]](l[659],l[659]);
    iP[l[948]]=wP[l[1459]][l[1368]](l[659],l[659]);
    iP[l[1639]]=wP[l[1459]][l[588]](l[1158],l[1158]);
    iP[l[1646]]=l[229];
    iP[l[1451]]=y[30](l[1411]);
    iP[l[936]]=R[l[641]];
    iP[l[2]]=l[229];
    iP[l[1557]]=wP[l[128]][l[1557]][l[220]];
    iP[l[711]]=l[1092];
    local EP=vP(IP,iP,VP);
    local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=wP[l[1459]][l[588]](l[910],l[393]),[l[1639]]=wP[l[1459]][l[772]](l[229],WP[l[925]]and l[132]or l[57],l[229],l[393]),[l[1646]]=l[229],[l[437]]=wP[l[128]][l[437]][l[1381]],[l[1420]]=WP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=wP[l[128]][l[164]][l[1021]],[l[1634]]=wP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
    local IP=a(l[1742],{[l[1150]]=f(),[l[1639]]=wP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},xP);
    local iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=wP[l[1689]][l[772]](l[393],l[659]),[l[948]]=wP[l[1459]][l[772]](l[393],l[59],l[659],l[393]),[l[1639]]=wP[l[1459]][l[588]](l[1243],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},xP);
    local QP=WP[l[925]];
    if QP then
      local tP=a;
      local RP=l[1742];
      local gP={};
      gP[l[1150]]=f();
      gP[l[1016]]=wP[l[1689]][l[772]](l[229],l[659]);
      gP[l[948]]=wP[l[1459]][l[772]](l[229],l[66],l[659],l[393]);
      gP[l[1639]]=wP[l[1459]][l[588]](l[884],l[884]);
      gP[l[1535]]=R[l[1466]];
      gP[l[1646]]=l[229];
      gP[l[1418]]=l[393];
      gP[l[1451]]=y[30](l[1456]);
      gP[l[936]]=R[l[1379]];
      gP[l[2]]=l[615];
      gP[l[1557]]=wP[l[128]][l[1557]][l[220]];
      gP[l[711]]=l[730];
      QP=tP(RP,gP,xP);
    end
    local tP,RP,gP=IP,iP,QP or nil;
    if gP then
      D(gP,l[1158]);
    end
    local IP,iP,QP=wP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
    QP[l[572]]=WP[l[572]];
    IP(iP,QP);
    local wP={[l[266]]=xP,[l[404]]=l[1329]};
    local IP=l[1329];
    if gP then
      local QP=NP(xP,WP[l[572]],_P,XP);
      wP[l[1085]]=QP;
      wP[l[925]]=QP[l[429]];
      local function NP(uP,uP)
        QP:setopen(uP);
      end
      wP[l[691]]=NP;
      d(gP[l[445]],function()
        QP:setopen(not QP[l[404]]);
        y[18]:chime(l[1352]);
      end);
      d(gP[l[1538]],function()
        P(gP,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[323]});
      end);
      d(gP[l[1628]],function()
        P(gP,H,{[l[2]]=l[615],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
      end);
    end
    local function NP()
      local QP,gP,uP,UP=s[87](),{},l[1646],wP[l[404]]and l[1296]or(IP and l[804]or l[229]);
      gP[uP]=UP;
      P(VP,H,gP);
      UP,gP,uP={},l[747],wP[l[404]]and l[229]or(IP and l[1296]or l[874]);
      UP[gP]=uP;
      P(kP,H,UP);
      P(EP,H,{[l[2]]=wP[l[404]]and l[393]or l[229],[l[1639]]=QP[l[1459]][l[588]](wP[l[404]]and l[310]or l[1158],wP[l[404]]and l[310]or l[1158])});
      P(vP,H,{[l[916]]=wP[l[404]]and l[393]or l[615],[l[510]]=wP[l[404]]and R[l[1095]]or R[l[1379]]});
    end
    local function VP(kP,kP,vP)
      kP=kP and l[383]or l[1329];
      if wP[l[404]]==kP and not y[18][l[921]] then
        return;
      end
      wP[l[404]]=kP;
      NP();
      if wP[l[1686]] then
        wP[l[1686]]:sync(kP);
        wP[l[1686]]:lit(kP);
      end
      if not vP then
        y[18]:chime(kP and l[404]or l[676]);
        if WP[l[1617]] then
          I(WP[l[1617]],kP);
        end
      end
    end
    wP[l[1255]]=VP;
    local function VP(kP)
      return wP[l[404]];
    end
    wP[l[506]]=VP;
    d(tP[l[445]],function()
      wP:set(not wP[l[404]]);
    end);
    d(RP[l[445]],function()
      wP:set(not wP[l[404]]);
    end);
    d(RP[l[1538]],function()
      IP=l[383];
      NP();
    end);
    d(RP[l[1628]],function()
      IP=l[1329];
      NP();
    end);
    if WP[l[950]] then
      wP[l[404]]=l[383];
      NP();
    end
    iP=WP[l[1013]]or hP..l[1074]..WP[l[572]];
    local NP=SP(xP,WP[l[572]],_P,XP,{[l[1463]]=iP,[l[103]]=l[1499],[l[649]]=l[383],[l[1498]]=function(WP)
      wP:set(WP);
    end,[l[194]]=function()
      wP:set(not wP[l[404]]);
    end,[l[1386]]=function()
      return wP[l[404]];
    end});
    wP[l[1686]]=NP;
    NP:lit(wP[l[404]]);
    d(tP[l[861]],function()
      if not NP:flip() then
        return;
      end
      y[18]:chime(l[1352]);
    end);
    d(RP[l[861]],function()
      if not NP:flip() then
        return;
      end
      y[18]:chime(l[1352]);
    end);
    y[18]:hook(iP,l[524],function()
      return wP[l[404]];
    end,function(NP)
      wP:set(NP==l[383]or NP==l[1102]or NP==l[229]);
    end);
    return wP;
  end
  fP[l[524]]=BP;
  local function NP(BP,wP)
    BP=s[87]();
    wP=X(wP,{[l[572]]=l[1223],[l[457]]=l[393],[l[850]]=l[856],[l[950]]=nil,[l[109]]=l[229],[l[26]]=l[1746],[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local WP,VP=aP[l[1594]--[[__index]]],aP[l[438]];
    local _P,XP=aP[l[745]],BP[l[35]][l[850]](BP[l[1382]](wP[l[109]])or l[229],l[393]);
    local xP=XP>l[393]and XP<l[229]and#(BP[l[409]][l[56]](BP[l[1130]](XP),l[361])or l[1746])or l[393];
    local kP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[913]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},WP);
    local vP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[229]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1057],l[393],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=wP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},kP);
    local IP=a(l[1070],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[393]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[393],l[229]),[l[1639]]=BP[l[1459]][l[588]](l[1167],l[829]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[874],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[877]],[l[711]]=l[1158]},kP);
    local iP=a(l[211],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[1243]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1026],l[393],l[1158]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},kP);
    local EP,QP=l[1112],{};
    QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
    a(EP,QP,iP);
    local tP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[393],l[1158],l[229],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[1209],[l[1418]]=l[393],[l[711]]=l[1092]},iP);
    EP,QP=l[1112],{};
    QP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
    a(EP,QP,tP);
    local RP,gP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[393],l[973]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[114]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},kP),{[l[266]]=kP,[l[1019]]=wP[l[457]]};
    local uP=l[1329];
    local UP,MP,sC=l[1329];
    EP,QP,WP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=kP};
    WP[l[572]]=wP[l[572]];
    EP(QP,WP);
    local function lC(LC)
      local yC=s[87]();
      if xP>l[393] then
        return yC[l[409]][l[846]](l[1213]..xP..l[347],LC)..wP[l[26]];
      end
      return yC[l[409]][l[846]](l[1489],yC[l[35]][l[499]](LC+l[659]))..wP[l[26]];
    end
    local function LC(yC)
      local zC=s[87]();
      yC=zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
      yC=if XP>l[393]then wP[l[457]]+zC[l[35]][l[499]]((yC-wP[l[457]])/XP+l[659])*XP else yC;
      yC=if xP>l[393]then zC[l[1382]](zC[l[409]][l[846]](l[1213]..xP..l[347],yC))or yC else yC;
      return zC[l[35]][l[819]](yC,wP[l[457]],wP[l[850]]);
    end
    local function yC(zC)
      local TC=s[87]();
      return TC[l[1459]][l[772]](zC,TC[l[35]][l[499]](l[1158]*(l[229]-zC)+l[659]),l[229],l[393]);
    end
    local function zC()
      local TC=wP[l[850]]-wP[l[457]];
      local nC=TC>l[393]and(gP[l[1019]]-wP[l[457]])/TC or l[393];
      IP[l[1420]]=lC(gP[l[1019]]);
      local TC,JC=UP and J or n,{};
      JC[l[1639]]=yC(nC);
      P(tP,TC,JC);
    end
    local function J()
      P(iP,H,{[l[1646]]=(UP or uP)and l[393]or l[841]});
      local yC,TC,nC={},l[1646],UP and l[393]or(uP and l[613]or l[1209]);
      yC[TC]=nC;
      P(tP,H,yC);
      P(vP,H,{[l[916]]=(UP or uP)and l[1209]or l[615]});
      P(IP,H,{[l[916]]=(UP or uP)and l[393]or l[874]});
    end
    local function vP(IP,tP,yC)
      IP=s[87]();
      tP=LC(IP[l[1382]](tP)or wP[l[457]]);
      if gP[l[1019]]==tP and not y[18][l[921]] then
        return;
      end
      gP[l[1019]]=tP;
      zC();
      if not yC and wP[l[1617]] then
        I(wP[l[1617]],tP);
      end
    end
    gP[l[1255]]=vP;
    local function vP(IP)
      return gP[l[1019]];
    end
    gP[l[506]]=vP;
    local function IP(tP)
      if tP and tP[l[948]] then
        return tP[l[948]][l[1437]];
      end
      return y[9]:GetMouseLocation()[l[1437]];
    end
    local function tP(yC)
      local TC,nC,JC=s[87](),iP[l[81]],iP[l[160]];
      if JC[l[1437]]<=l[393] then
        return gP[l[1019]];
      end
      return wP[l[457]]+(wP[l[850]]-wP[l[457]])*TC[l[35]][l[819]]((yC-nC[l[1437]])/JC[l[1437]],l[393],l[229]);
    end
    local function iP()
      local yC=sC;
      if yC then
        sC:Disconnect();
        sC=nil;
      end
      yC=UP;
      if not yC then
        return;
      end
      UP,MP=l[1329],nil;
      VP[l[1195]]=l[383];
      O(l[715]);
      zC();
      J();
    end
    d(RP[l[1558]],function(yC)
      local TC={};
      local nC=s[87]();
      if yC[l[1317]]~=nC[l[128]][l[1317]][l[1356]]and yC[l[1317]]~=nC[l[128]][l[1317]][l[239]] then
        return;
      end
      local JC=UP;
      if JC then
        return;
      end
      UP=l[383];
      MP=yC[l[1317]]==nC[l[128]][l[1317]][l[239]]and yC or nil;
      JC=sC;
      if JC then
        sC:Disconnect();
      end
      TC[1]=(y[10][l[756]]:Connect(function()
        local nC,JC,HC=s[87](),MP;
        if JC then
          local JC=MP;
          local fC=JC[l[1101]]==nC[l[128]][l[1101]][l[115]];
          if fC then
            HC=fC;
          else
            JC=MP;
            HC=JC[l[1101]]==nC[l[128]][l[1101]][l[890]];
          end
        else
          HC=(y[9]:IsMouseButtonPressed(nC[l[128]][l[1317]][l[1356]]));
        end
        if not HC then
          iP();
        end
      end));
      sC=TC[1];
      O(l[229]);
      J();
      VP[l[1195]]=l[1329];
      y[18]:chime(l[1320]);
      gP:set(tP(IP(yC)));
    end);
    local function sC(yC)
      local TC,nC=s[87](),MP;
      if nC then
        local nC=MP;
        return yC==nC;
      end
      return yC[l[1317]]==TC[l[128]][l[1317]][l[1356]];
    end
    d(RP[l[412]],function(yC)
      if sC(yC) then
        iP();
      end
    end);
    d(y[9][l[233]],function(yC)
      local TC,nC=s[87](),UP;
      if not nC then
        return;
      end
      nC=MP;
      if nC then
        local UP=MP;
        if yC~=UP then
          return;
        end
      elseif yC[l[1317]]~=TC[l[128]][l[1317]][l[765]] then
        return;
      end
      gP:set(tP(IP(yC)));
    end);
    d(y[9][l[412]],function(IP)
      if sC(IP) then
        iP();
      end
    end);
    d(kP[l[1538]],function()
      uP=l[383];
      J();
    end);
    d(kP[l[1628]],function()
      uP=l[1329];
      J();
    end);
    gP[l[1019]]=LC(BP[l[1382]](wP[l[950]])or wP[l[457]]);
    zC();
    local J,IP,iP=wP[l[1013]]or hP..l[1074]..wP[l[572]];
    EP,WP,QP,vP=wP[l[572]],VP,{[l[1463]]=J,[l[103]]=l[1716],[l[649]]=l[383],[l[1019]]={[l[457]]=wP[l[457]],[l[850]]=wP[l[850]],[l[109]]=XP,[l[1647]]=xP,[l[26]]=wP[l[26]],[l[950]]=gP[l[1019]]},[l[1735]]=function()
      return lC(iP[l[1019]]);
    end},l[1498];
    local function VP(XP)
      if XP then
        local XP=IP==nil;
        if XP then
          IP=gP[l[1019]];
        end
        gP:set(iP[l[1019]]);
      else
        local XP=IP~=nil;
        if XP then
          gP:set(IP);
          IP=nil;
        end
      end
      iP:lit(IP~=nil);
    end
    QP[vP]=VP;
    QP[l[194]]=function()
      iP[l[1273]]=not iP[l[1273]];
      iP[l[1498]](iP[l[1273]]);
    end;
    QP[l[1386]]=function()
      local VP=IP;
      return VP~=nil;
    end;
    iP=SP(kP,EP,WP,_P,QP);
    gP[l[1686]]=iP;
    vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[973]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1092]},kP);
    local function BP()
      if not iP:flip() then
        return;
      end
      y[18]:chime(l[1352]);
    end
    d(vP[l[861]],BP);
    d(RP[l[1558]],function(WP)
      local VP=s[87]();
      if WP[l[1317]]==VP[l[128]][l[1317]][l[321]--[[-1]]] then
        BP();
      end
    end);
    y[18]:hook(J,l[384],function()
      return gP[l[1019]];
    end,function(J)
      gP:set(J);
    end,{[l[457]]=wP[l[457]],[l[850]]=wP[l[850]]});
    return gP;
  end
  fP[l[1223]]=NP;
  local function J(NP,BP)
    NP=s[87]();
    BP=X(BP,{[l[572]]=l[166],[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local wP=aP[l[1594]--[[__index]]];
    local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
    local wP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},WP);
    local VP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
    D(VP,l[1158]);
    local _P=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},VP);
    local XP=a;
    local xP=l[859];
    local kP={};
    kP[l[1150]]=f();
    kP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
    kP[l[948]]=NP[l[1459]][l[772]](l[393],l[303],l[659],l[393]);
    kP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
    kP[l[1646]]=l[229];
    kP[l[1451]]=y[30](l[1680]);
    kP[l[936]]=R[l[1379]];
    kP[l[2]]=l[1431];
    kP[l[1557]]=NP[l[128]][l[1557]][l[220]];
    kP[l[711]]=l[1092];
    local vP=XP(xP,kP,VP);
    local XP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[1243],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[393],l[229],l[393],l[750]),[l[1535]]=R[l[966]],[l[1646]]=l[615],[l[1418]]=l[393],[l[711]]=l[1092]},VP);
    K(XP,l[117],{NP[l[677]][l[772]](l[393],l[731]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[731])});
    local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[688],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[221],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[31],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},VP);
    local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},VP);
    K(kP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
    local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},WP),{[l[266]]=WP,[l[230]]=nil,[l[1273]]=l[1329]};
    local EP=l[1329];
    local QP,tP,RP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
    RP[l[572]]=BP[l[572]];
    QP(tP,RP);
    local function NP()
      xP[l[1420]]=iP[l[1273]]and l[538]or z(iP[l[230]]);
    end
    local function WP()
      local QP,tP,RP={},l[1646],iP[l[1273]]and l[393]or(EP and l[613]or l[841]);
      QP[tP]=RP;
      P(VP,H,QP);
      tP,QP,RP={},l[747],iP[l[1273]]and l[120]or(EP and l[323]or l[1373]);
      tP[QP]=RP;
      P(_P,H,tP);
      P(kP,H,{[l[1646]]=iP[l[1273]]and l[986]or l[229]});
      P(XP,H,{[l[1646]]=iP[l[1273]]and l[1209]or l[615]});
      P(xP,H,{[l[916]]=iP[l[1273]]and l[393]or l[1209],[l[510]]=iP[l[1273]]and R[l[98]]or R[l[1095]]});
      tP,QP,RP={},l[2],iP[l[1273]]and l[393]or(EP and l[1209]or l[1431]);
      tP[QP]=RP;
      tP[l[936]]=iP[l[1273]]and R[l[98]]or R[l[1379]];
      P(vP,H,tP);
      P(wP,H,{[l[916]]=(iP[l[1273]]or EP)and l[1209]or l[615]});
    end
    local function wP(VP,VP,_P)
      local XP,xP=s[87](),VP;
      xP=if XP[l[40]](xP)==l[409]then XP[l[199]](l[59],XP[l[1146]](function()
        local kP=s[87]();
        return kP[l[128]][l[880]--[[readu32]]][VP];
      end))else xP;
      if XP[l[1703]](xP)~=l[802]or xP==iP[l[230]] then
        return;
      end
      iP[l[230]]=xP;
      NP();
      if not _P and BP[l[1617]] then
        I(BP[l[1617]],xP[l[1150]]);
      end
    end
    iP[l[1255]]=wP;
    local function wP(VP)
      return iP[l[230]]and iP[l[230]][l[1150]]or nil;
    end
    iP[l[506]]=wP;
    local function wP()
      iP[l[1273]]=l[1329];
      NP();
      WP();
    end
    d(IP[l[445]],function()
      if iP[l[1273]] then
        lP(nil);
        wP();
        return;
      end
      iP[l[1273]]=l[383];
      NP();
      WP();
      y[18]:chime(l[1352]);
      lP(function(VP)
        wP();
        if VP then
          iP:set(VP);
          y[18]:chime(l[1320]);
        end
      end,wP);
    end);
    d(IP[l[1538]],function()
      EP=l[383];
      WP();
    end);
    d(IP[l[1628]],function()
      EP=l[1329];
      WP();
    end);
    iP:set(BP[l[950]]);
    NP();
    WP();
    y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[230],function()
      return iP:get();
    end,function(NP)
      iP:set(NP);
    end);
    return iP;
  end
  fP[l[166]]=J;
  local function J(NP,BP)
    NP=s[87]();
    BP=X(BP,{[l[572]]=l[654],[l[1206]]={},[l[950]]=nil,[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local wP=aP[l[1594]--[[__index]]];
    local WP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[656]]=l[383],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
    wP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[303]},WP);
    local VP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1218],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},wP);
    local _P=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1404]--[[=[C] ]],l[66],l[393],l[884]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
    D(_P,l[1158]);
    local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},_P);
    local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[289],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},_P);
    local kP=a;
    local vP=l[859];
    local IP={};
    IP[l[1150]]=f();
    IP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
    IP[l[948]]=NP[l[1459]][l[772]](l[229],l[348],l[659],l[393]);
    IP[l[1639]]=NP[l[1459]][l[588]](l[1307],l[1307]);
    IP[l[1646]]=l[229];
    IP[l[1451]]=y[30](l[606]--[[readu16]]);
    IP[l[936]]=R[l[1379]];
    IP[l[2]]=l[1431];
    IP[l[1557]]=NP[l[128]][l[1557]][l[220]];
    IP[l[711]]=l[1092];
    local iP=kP(vP,IP,_P);
    local kP,vP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),a(l[211],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[688]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[393]),[l[1535]]=R[l[641]],[l[1646]]=l[269],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},WP);
    D(vP,l[1158]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[52]},vP);
    local IP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[393]),[l[1347]]=NP[l[128]][l[1347]][l[636]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP);
    local EP,QP=l[755],{[l[407]]=NP[l[128]][l[407]][l[537]]};
    QP[l[536]]=NP[l[740]][l[772]](l[393],l[229]);
    a(EP,QP,IP);
    a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786]),[l[1612]]=NP[l[740]][l[772]](l[393],l[786]),[l[517]]=NP[l[740]][l[772]](l[393],l[786])},IP);
    local tP={[l[266]]=WP,[l[404]]=l[1329],[l[955]]=nil,[l[1072]]={}};
    wP,EP,QP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=WP};
    QP[l[572]]=BP[l[572]];
    wP(EP,QP);
    local function wP(QP)
      local RP,gP=s[87](),tP[l[955]]==QP[l[572]];
      local uP,UP,MP,sC=QP[l[1642]],{},l[1646],gP and l[841]or(QP[l[892]]and l[659]or l[229]);
      UP[MP]=sC;
      P(uP,n,UP);
      MP,sC=QP[l[1377]],{[l[1646]]=gP and l[1296]or l[229]};
      sC[l[1639]]=RP[l[1459]][l[588]](gP and l[1092]or l[786],gP and l[1092]or l[786]);
      P(MP,n,sC);
      P(QP[l[1615]],n,{[l[916]]=gP and l[393]or(QP[l[892]]and l[820]or l[323]),[l[510]]=gP and R[l[1095]]or R[l[1379]]});
    end
    local function QP()
      local RP=vP[l[1639]][l[636]][l[1485]];
      local gP=tP[l[404]]and e(IP)[l[636]]or l[393];
      local uP=WP[l[1639]][l[636]][l[1485]];
      local UP=l[658]+(tP[l[404]]and gP+l[1158]or l[393]);
      local MP=iP[l[500]];
      local sC=tP[l[404]]and l[1510]or l[393];
      b(vP,l[1431],tP[l[404]]and N or q,function(lC)
        local LC=s[87]();
        vP[l[1639]]=LC[l[1459]][l[772]](l[229],l[1026],l[393],LC[l[35]][l[499]](RP+(gP-RP)*lC+l[659]));
        WP[l[1639]]=LC[l[1459]][l[772]](l[229],l[393],l[393],LC[l[35]][l[499]](uP+(UP-uP)*lC+l[659]));
      end);
      b(iP,l[1431],N,function(WP)
        iP[l[500]]=MP+(sC-MP)*WP;
      end);
      P(XP,H,{[l[747]]=tP[l[404]]and l[739]or l[1373]});
    end
    local function WP(XP,XP)
      tP[l[404]]=XP and l[383]or l[1329];
      QP();
    end
    tP[l[1521]--[[0]]]=WP;
    local function WP(XP,vP,QP)
      XP=s[87]();
      if XP[l[40]](vP)~=l[409]or vP==tP[l[955]]and not y[18][l[921]] then
        return;
      end
      if not XP[l[1346]][l[23]](BP[l[1206]],vP) then
        return;
      end
      tP[l[955]]=vP;
      xP[l[1420]]=vP;
      for XP,XP in y[3],tP[l[1072]],nil do
        wP(XP);
      end;
      if not QP and BP[l[1617]] then
        I(BP[l[1617]],vP);
      end
    end
    tP[l[1255]]=WP;
    local function XP(xP)
      return tP[l[955]];
    end
    tP[l[506]]=XP;
    for XP,xP in y[3],BP[l[1206]],nil do
      local vP={[l[572]]=xP,[l[892]]=l[1329],[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[884]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=XP,[l[711]]=l[1158]},IP)};
      vP[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},vP[l[1466]]);
      D(vP[l[1642]],l[303]);
      K(vP[l[1642]],l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[509],l[986]),NP[l[677]][l[772]](l[229],l[1017])});
      vP[l[1377]]=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]),[l[948]]=NP[l[1459]][l[772]](l[393],l[930],l[659],l[393]),[l[1639]]=NP[l[1459]][l[588]](l[786],l[786]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},vP[l[1466]]);
      WP,EP=l[1112],{};
      EP[l[1182]]=NP[l[740]][l[772]](l[229],l[393]);
      a(WP,EP,vP[l[1377]]);
      vP[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[1243],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[14],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=xP,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP[l[1466]]);
      vP[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[930]},vP[l[1466]]);
      d(vP[l[974]][l[1538]],function()
        vP[l[892]]=l[383];
        wP(vP);
      end);
      d(vP[l[974]][l[1628]],function()
        vP[l[892]]=l[1329];
        wP(vP);
      end);
      d(vP[l[974]][l[445]],function()
        tP:set(vP[l[572]]);
        tP:setopen(l[1329]);
        y[18]:chime(l[1320]);
      end);
      tP[l[1072]][XP]=vP;
    end;
    d(kP[l[445]],function()
      tP:setopen(not tP[l[404]]);
      y[18]:chime(l[1352]);
    end);
    d(kP[l[1538]],function()
      P(VP,H,{[l[916]]=l[1209]});
      P(iP,H,{[l[2]]=l[1296]});
      P(_P,H,{[l[1646]]=l[393]});
    end);
    d(kP[l[1628]],function()
      P(VP,H,{[l[916]]=l[615]});
      P(iP,H,{[l[2]]=l[1431]});
      P(_P,H,{[l[1646]]=l[841]});
    end);
    tP:set(BP[l[950]]or BP[l[1206]][l[229]]);
    y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
      return tP[l[955]];
    end,function(NP)
      tP:set(NP);
    end,{[l[284]]=function(NP)
      local wP=s[87]();
      return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
    end});
    return tP;
  end
  fP[l[654]]=J;
  local function J(NP,BP)
    NP=s[87]();
    BP=X(BP,{[l[572]]=l[1336],[l[1206]]={},[l[950]]=nil,[l[850]]=l[930],[l[1693]]=l[1329],[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
    local VP=aP[l[745]];
    local _P=l[941];
    local XP=NP[l[35]][l[850]](NP[l[35]][l[499]](NP[l[1382]](BP[l[850]])or l[930]),l[229]);
    local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
    local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[893],l[1519],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},xP);
    local vP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]),[l[948]]=NP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[1474],l[66],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},xP);
    D(vP,l[1158]);
    local IP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},vP);
    local iP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[662],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=l[1746],[l[510]]=R[l[1095]],[l[723]]=l[310],[l[916]]=l[1209],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[711]]=l[1092]},vP);
    local EP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[551]},vP);
    K(EP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
    local QP=a;
    local tP=l[859];
    local RP={};
    RP[l[1150]]=f();
    RP[l[1016]]=NP[l[1689]][l[772]](l[229],l[659]);
    RP[l[948]]=NP[l[1459]][l[772]](l[229],l[708],l[659],l[393]);
    RP[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
    RP[l[1646]]=l[229];
    RP[l[1451]]=y[30](l[606]--[[readu16]]);
    RP[l[936]]=R[l[1379]];
    RP[l[2]]=l[1431];
    RP[l[1557]]=NP[l[128]][l[1557]][l[220]];
    RP[l[711]]=l[1092];
    local gP=QP(tP,RP,vP);
    local QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[730]},vP),a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
    local RP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
    local uP=RP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=NP[l[740]][l[772]](l[393],l[829]),[l[1485]]=NP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=NP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},RP)or nil;
    if RP then
      D(RP,l[930]);
    end
    local UP=a(l[1751],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
    D(UP,l[930]);
    local MP,sC=l[1622],{[l[500]]=l[117]};
    sC[l[1630]]=NP[l[1262]][l[772]]({NP[l[527]][l[772]](l[393],NP[l[360]][l[772]](l[229],l[229],l[229])),NP[l[527]][l[772]](l[229],NP[l[360]][l[353]](l[291],l[291],l[920]))});
    a(MP,sC,UP);
    a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},UP);
    MP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},UP);
    D(MP,l[930]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},MP);
    local lC=a(l[1439],{[l[1150]]=f(),[l[43]]=l[383],[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[392]]=NP[l[1459]][l[772]](),[l[969]]=l[393],[l[62]]=NP[l[128]][l[62]][l[636]],[l[711]]=l[913]},UP);
    local LC=a(l[755],{[l[407]]=NP[l[128]][l[407]][l[537]],[l[536]]=NP[l[740]][l[772]](l[393],l[59])},lC);
    a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[1158]),[l[645]]=NP[l[740]][l[772]](l[393],l[1158]),[l[1612]]=NP[l[740]][l[772]](l[393],l[1158]),[l[517]]=NP[l[740]][l[772]](l[393],l[1158])},lC);
    local yC={[l[266]]=xP,[l[404]]=l[1329],[l[955]]=nil,[l[1406]--[[]]]={},[l[1072]]={},[l[771]]=l[1329],[l[559]]=l[393],[l[434]]=l[393]};
    local zC=l[1329];
    local TC=l[393];
    MP,sC,wP=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=xP};
    wP[l[572]]=BP[l[572]];
    MP(sC,wP);
    local function NP(wP)
      if BP[l[1693]] then
        return yC[l[1406]--[[]]][wP]==l[383];
      end
      return yC[l[955]]==wP;
    end
    local function wP()
      local MP,sC=s[87](),{};
      for nC=l[229],#BP[l[1206]],l[229]do
        if yC[l[1406]--[[]]][BP[l[1206]][nC]] then
          MP[l[1346]][l[968]](sC,BP[l[1206]][nC]);
        end
      end;
      return sC;
    end
    local function MP(sC,nC)
      local JC,HC,fC,aC=s[87](),NP(sC[l[572]]),sC[l[892]]or yC[l[1072]][TC]==sC,nC and n or H;
      local NP,dC,PC,ZC=sC[l[1466]],{},l[1646],HC and l[922]or(fC and l[330]or l[229]);
      dC[PC]=ZC;
      P(NP,aC,dC);
      ZC,nC=sC[l[1473]],{};
      nC[l[747]]=HC and l[509]or l[229];
      P(ZC,aC,nC);
      nC,PC=sC[l[1642]],{};
      PC[l[1646]]=HC and l[1432]or l[229];
      P(nC,aC,PC);
      P(sC[l[451]],aC,{[l[1639]]=JC[l[1459]][l[772]](l[393],l[863],l[393],HC and l[750]or l[393]),[l[1646]]=HC and l[1296]or l[229]});
      P(sC[l[1615]],aC,{[l[916]]=HC and l[393]or(fC and l[263]or l[323]),[l[510]]=HC and R[l[1095]]or R[l[1379]]});
      if BP[l[1693]] then
        nC,NP=sC[l[595]],{};
        NP[l[1646]]=HC and l[1296]or l[229];
        P(nC,aC,NP);
        local NP,nC,GC,YC=sC[l[741]],{},l[747],HC and l[229]or(fC and l[1296]or l[1431]);
        nC[GC]=YC;
        P(NP,aC,nC);
        PC,nC=sC[l[1572]],{[l[2]]=HC and l[393]or l[229]};
        nC[l[1639]]=JC[l[1459]][l[588]](HC and l[730]or l[786],HC and l[730]or l[786]);
        P(PC,aC,nC);
      else
        dC,ZC=sC[l[1040]],{[l[2]]=HC and l[393]or l[229]};
        ZC[l[1639]]=JC[l[1459]][l[588]](HC and l[310]or l[1092],HC and l[310]or l[1092]);
        P(dC,aC,ZC);
      end
    end
    local function NP()
      local sC=s[87]();
      if not BP[l[1693]] then
        iP[l[1420]]=yC[l[955]]or l[31];
        return;
      end
      local nC=wP();
      iP[l[1420]]=#nC>l[393]and sC[l[1346]][l[978]](nC,l[1200])or l[31];
    end
    local function iP()
      P(vP,H,{[l[1646]]=(yC[l[404]]or zC)and l[393]or l[841]});
      local sC,nC,JC={},l[747],yC[l[404]]and l[1431]or(zC and l[323]or l[1373]);
      sC[nC]=JC;
      P(IP,H,sC);
      P(EP,H,{[l[1646]]=yC[l[404]]and l[874]or l[229]});
      P(kP,H,{[l[916]]=(yC[l[404]]or zC)and l[1209]or l[615]});
      P(gP,H,{[l[2]]=(yC[l[404]]or zC)and l[1296]or l[1431],[l[936]]=yC[l[404]]and R[l[1095]]or R[l[1379]]});
    end
    local function kP()
      NP();
      for IP=l[229],#yC[l[1072]],l[229]do
        MP(yC[l[1072]][IP],l[383]);
      end;
    end
    local function IP()
      local EP=s[87]();
      return EP[l[35]][l[819]](#yC[l[1072]],l[229],XP)*_P+l[730];
    end
    local function XP()
      local EP,sC=s[87](),l[393];
      for nC=l[229],#BP[l[1206]],l[229]do
        local JC,HC=EP[l[1146]](function()
          local fC,aC,dC=s[87](),BP[l[1206]][nC],l[310];
          local nC,PC=fC[l[128]][l[437]][l[1381]],s[70](fC[l[1689]][l[772]](l[329],l[1655]));
          return y[8]:GetTextSize(aC,dC,nC,s:ZT(PC));
        end);
        sC=if JC and HC then EP[l[35]][l[850]](sC,HC[l[1437]])else sC;
      end;
      return EP[l[35]][l[139]](sC)+(BP[l[1693]]and l[205]or l[430]);
    end
    local function EP()
      local sC,nC,JC,HC,fC=s[87](),G(YP),e(YP),G(vP),e(vP);
      local aC,dC=HC[l[1437]]-nC[l[1437]],yC[l[771]]and HC[l[636]]-nC[l[636]]-l[1158]or HC[l[636]]-nC[l[636]]+fC[l[636]]+l[1158];
      aC=if aC+yC[l[559]]>JC[l[1437]]-l[930]then sC[l[35]][l[850]](l[930],HC[l[1437]]-nC[l[1437]]+fC[l[1437]]-yC[l[559]])else aC;
      UP[l[948]]=sC[l[1459]][l[588]](sC[l[35]][l[499]](aC+l[659]),sC[l[35]][l[499]](dC+l[659]));
      if RP then
        RP[l[948]]=UP[l[948]];
      end
    end
    local function sC()
      local nC=s[87]();
      yC[l[434]]=IP();
      UP[l[1639]]=nC[l[1459]][l[588]](yC[l[559]],yC[l[434]]);
      if RP then
        RP[l[1639]]=UP[l[1639]];
      end
      EP();
    end
    local function nC()
      local JC=UP[l[1569]];
      local HC=yC[l[404]]and l[393]or l[229];
      local fC=gP[l[500]];
      local aC=yC[l[404]]and l[1510]or l[393];
      b(UP,yC[l[404]]and l[894]or l[304],yC[l[404]]and N or q,function(dC)
        local PC=JC+(HC-JC)*dC;
        UP[l[1569]]=PC;
        if RP then
          RP[l[1646]]=PC;
          uP[l[747]]=l[615]+l[411]*PC;
        end
        if dC>=l[229] then
          UP[l[1324]]=yC[l[404]];
          if RP then
            RP[l[1324]]=yC[l[404]];
          end
        end
      end);
      b(gP,l[1431],N,function(uP)
        gP[l[500]]=fC+(aC-fC)*uP;
      end);
    end
    local function gP(uP)
      local JC,HC,fC=s[87](),lC[l[464]][l[636]]/y[29],j(LC)[l[636]]+l[310];
      local aC=JC[l[1346]][l[23]](yC[l[1072]],uP);
      if not aC or HC<=l[393]or fC<=HC then
        return;
      end
      uP,fC=l[1158]+(aC-l[229])*_P,lC[l[1690]][l[636]];
      if uP<fC then
        lC[l[1690]]=JC[l[1689]][l[772]](l[393],JC[l[35]][l[850]](uP-l[1158],l[393]));
      elseif uP+l[1660]>fC+HC then
        lC[l[1690]]=JC[l[1689]][l[772]](l[393],uP+l[1596]--[[__newindex]]-HC);
      end
    end
    local function _P(uP)
      local JC=yC[l[1072]][TC];
      TC=uP;
      if JC then
        MP(JC,l[383]);
      end
      uP=yC[l[1072]][TC];
      if uP then
        MP(uP,l[383]);
        gP(uP);
      end
    end
    local function uP(JC)
      if #yC[l[1072]]==l[393] then
        return;
      end
      local HC=TC+JC;
      _P(if HC<l[229]then#yC[l[1072]]else if HC>#yC[l[1072]]then l[229]else HC);
      y[18]:chime(l[1320]);
    end
    local function _P(JC)
      if not JC then
        return;
      end
      if BP[l[1693]] then
        yC[l[1406]--[[]]][JC[l[572]]]=not yC[l[1406]--[[]]][JC[l[572]]]or nil;
        kP();
        y[18]:chime(yC[l[1406]--[[]]][JC[l[572]]]and l[404]or l[676]);
        if BP[l[1617]] then
          I(BP[l[1617]],yC:get());
        end
        return;
      end
      yC:set(JC[l[572]]);
      yC:setopen(l[1329]);
      y[18]:chime(l[1320]);
    end
    local function JC()
      local HC={};
      local fC=s[87]();
      for aC=l[229],#yC[l[1072]],l[229]do
        local dC=yC[l[1072]][aC];
        for aC,aC in y[3],dC[l[608]],nil do
          aC:Disconnect();
        end;
        dC[l[1466]]:Destroy();
      end;
      fC[l[1346]][l[267]](yC[l[1072]]);
      local aC,dC,PC,ZC,GC=BP[l[1693]]and l[1249]or l[1307],BP[l[1693]]and l[730]or l[688],l[229],#BP[l[1206]],l[229];
      for YC=PC,ZC,GC do
        local PC=BP[l[1206]][YC];
        local ZC={[l[572]]=PC,[l[892]]=l[1329],[l[608]]={},[l[1466]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[772]](l[229],l[393],l[393],l[1660]),[l[1535]]=R[l[1466]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=YC,[l[711]]=l[913]},lC)};
        D(ZC[l[1466]],l[1158]);
        ZC[l[1473]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[229]},ZC[l[1466]]);
        ZC[l[1642]]=a(l[211],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[913]},ZC[l[1466]]);
        D(ZC[l[1642]],l[1158]);
        K(ZC[l[1642]],l[393],{fC[l[677]][l[772]](l[393],l[393]),fC[l[677]][l[772]](l[1017],l[1373]),fC[l[677]][l[772]](l[229],l[229])});
        ZC[l[451]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[229],l[659],l[393]),[l[1639]]=fC[l[1459]][l[772]](l[393],l[863],l[393],l[393]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
        local GC,eC=l[1112],{};
        eC[l[1182]]=fC[l[740]][l[772]](l[229],l[393]);
        a(GC,eC,ZC[l[451]]);
        if BP[l[1693]] then
          ZC[l[595]]=a(l[211],{[l[1150]]=f(),[l[1016]]=fC[l[1689]][l[772]](l[393],l[659]),[l[948]]=fC[l[1459]][l[772]](l[393],l[551],l[659],l[393]),[l[1639]]=fC[l[1459]][l[588]](l[558],l[558]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1526]},ZC[l[1466]]);
          D(ZC[l[595]],l[786]);
          ZC[l[741]]=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1431]},ZC[l[595]]);
          HC[1]=l[1572];
          HC[3]=a;
          HC[4]=l[859];
          HC[2]={};
          HC[2][l[1150]]=f();
          HC[2][l[1016]]=fC[l[1689]][l[772]](l[659],l[659]);
          HC[2][l[948]]=fC[l[1459]][l[1368]](l[659],l[659]);
          HC[2][l[1639]]=fC[l[1459]][l[588]](l[786],l[786]);
          HC[2][l[1646]]=l[229];
          HC[2][l[1451]]=y[30](l[1411]);
          HC[2][l[936]]=R[l[641]];
          HC[2][l[2]]=l[229];
          HC[2][l[1557]]=fC[l[128]][l[1557]][l[220]];
          HC[2][l[711]]=l[1282];
          HC[5]=(HC[3](HC[4],HC[2],ZC[l[595]]));
          ZC[HC[1]]=HC[5];
        else
          HC[6]=l[1040];
          HC[8]=a;
          HC[9]=l[859];
          HC[7]={};
          HC[7][l[1150]]=f();
          HC[7][l[1016]]=fC[l[1689]][l[772]](l[229],l[659]);
          HC[7][l[948]]=fC[l[1459]][l[772]](l[229],l[1151],l[659],l[393]);
          HC[7][l[1639]]=fC[l[1459]][l[588]](l[1092],l[1092]);
          HC[7][l[1646]]=l[229];
          HC[7][l[1451]]=y[30](l[1411]);
          HC[7][l[936]]=R[l[98]];
          HC[7][l[2]]=l[229];
          HC[7][l[1557]]=fC[l[128]][l[1557]][l[220]];
          HC[7][l[711]]=l[1526];
          HC[10]=(HC[8](HC[9],HC[7],ZC[l[1466]]));
          ZC[HC[6]]=HC[10];
        end
        ZC[l[1615]]=a(l[1070],{[l[1150]]=f(),[l[948]]=fC[l[1459]][l[588]](aC,l[393]),[l[1639]]=fC[l[1459]][l[772]](l[229],-aC-dC,l[229],l[393]),[l[1646]]=l[229],[l[437]]=fC[l[128]][l[437]][l[1381]],[l[1420]]=PC,[l[510]]=R[l[1379]],[l[723]]=l[310],[l[916]]=l[323],[l[164]]=fC[l[128]][l[164]][l[1021]],[l[1634]]=fC[l[128]][l[1634]][l[701]],[l[711]]=l[1526]},ZC[l[1466]]);
        ZC[l[974]]=a(l[1742],{[l[1150]]=f(),[l[1639]]=fC[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[1282]},ZC[l[1466]]);
        fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1538]]:Connect(function()
          local HC=yC[l[1072]][TC];
          ZC[l[892]]=l[383];
          TC=l[393];
          if HC and HC~=ZC then
            MP(HC,l[383]);
          end
          MP(ZC,l[383]);
        end));
        fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[1628]]:Connect(function()
          ZC[l[892]]=l[1329];
          MP(ZC,l[383]);
        end));
        fC[l[1346]][l[968]](ZC[l[608]],ZC[l[974]][l[445]]:Connect(function()
          _P(ZC);
        end));
        yC[l[1072]][YC]=ZC;
        MP(ZC,l[383]);
      end;
    end
    local HC,fC;
    local function aC()
      local dC=HC;
      if dC then
        HC:Disconnect();
        HC=nil;
      end
    end
    local function dC()
      local PC=fC;
      if PC then
        fC:Disconnect();
        fC=nil;
      end
    end
    local function PC()
      yC:setopen(l[1329]);
    end
    local function ZC()
      local GC=S;
      if GC>l[393] then
        EP();
        return;
      end
      if not LP[l[1600]]or not KP[l[1324]]or not xP[l[1324]] then
        PC();
        return;
      end
      local xP,YC,eC,jC,CC,NC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],vP[l[81]],vP[l[160]];
      GC=CC[l[636]]+NC[l[636]]*l[659];
      if GC<xP[l[636]]or GC>xP[l[636]]+YC[l[636]]or GC<eC[l[636]]or GC>eC[l[636]]+jC[l[636]] then
        PC();
        return;
      end
      EP();
    end
    local function WP(VP)
      local xP=s[87]();
      if y[18][l[1333]]or VP[l[1317]]~=xP[l[128]][l[1317]][l[1441]] then
        return;
      end
      local EP=VP[l[880]--[[readu32]]];
      VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1492]];
      if VP then
        uP(l[229]);
      else
        local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1436]];
        if VP then
          uP(l[715]);
        else
          local VP=EP==xP[l[128]][l[880]--[[readu32]]][l[1183]]or EP==xP[l[128]][l[880]--[[readu32]]][l[839]];
          if VP then
            _P(yC[l[1072]][TC]);
          elseif EP==xP[l[128]][l[880]--[[readu32]]][l[1739]] then
            PC();
          end
        end
      end
    end
    local function VP(_P,xP)
      local EP={};
      _P=s[87]();
      xP=xP and l[383]or l[1329];
      if yC[l[404]]==xP then
        return;
      end
      yC[l[404]]=xP;
      if xP then
        V();
        local xP,uP,GC,YC=G(YP),e(YP),G(vP),e(vP);
        yC[l[559]]=_P[l[35]][l[819]](_P[l[35]][l[850]](XP(),_P[l[35]][l[499]](YC[l[1437]]+l[659])),l[492],_P[l[35]][l[850]](_P[l[35]][l[499]](uP[l[1437]])-l[829],l[492]));
        yC[l[434]]=IP();
        local XP,vP=uP[l[636]]-(GC[l[636]]-xP[l[636]]+YC[l[636]]+l[1158])-l[1158],GC[l[636]]-xP[l[636]]-l[310];
        yC[l[771]]=XP<yC[l[434]]and vP>XP;
        UP[l[1016]]=_P[l[1689]][l[772]](l[393],yC[l[771]]and l[229]or l[393]);
        UP[l[1324]]=l[383];
        tP[l[1324]]=l[383];
        lC[l[1690]]=_P[l[1689]][l[772]]();
        if RP then
          RP[l[1016]]=UP[l[1016]];
          RP[l[1324]]=l[383];
        end
        sC();
        kP();
        vP=not BP[l[1693]];
        if vP then
          uP,XP,GC=l[229],#yC[l[1072]],l[229];
          for _P=uP,XP,GC do
            xP=yC[l[1072]][_P][l[572]]==yC[l[955]];
            if xP then
              TC=_P;
              MP(yC[l[1072]][_P],l[383]);
              gP(yC[l[1072]][_P]);
              break;
            end
          end;
        end
        A,w=PC,UP;
        aC();
        dC();
        EP[1]=(y[10][l[1119]]:Connect(ZC));
        HC=EP[1];
        EP[2]=(y[9][l[1558]]:Connect(WP));
        fC=EP[2];
      else
        aC();
        dC();
        tP[l[1324]]=l[1329];
        TC=l[393];
        local WP=A==PC;
        if WP then
          A,w=nil,nil;
        end
        for WP=l[229],#yC[l[1072]],l[229]do
          yC[l[1072]][WP][l[892]]=l[1329];
          MP(yC[l[1072]][WP],l[383]);
        end;
      end
      iP();
      nC();
    end
    yC[l[1521]--[[0]]]=VP;
    local function WP(VP)
      if not BP[l[1693]] then
        return yC[l[955]];
      end
      return wP();
    end
    yC[l[506]]=WP;
    local function wP(WP,VP,_P)
      local XP=s[87]();
      if BP[l[1693]] then
        WP={};
        if XP[l[40]](VP)==l[1346] then
          for xP,xP in y[3],VP,nil do
            WP[xP]=l[383];
          end;
        elseif XP[l[40]](VP)==l[409] then
          for xP in XP[l[409]][l[78]](VP,l[397])do
            WP[XP[l[409]][l[56]](xP,l[381])]=l[383];
          end;
        else
          return;
        end
        XP[l[1346]][l[267]](yC[l[1406]--[[]]]);
        for xP=l[229],#BP[l[1206]],l[229]do
          if WP[BP[l[1206]][xP]] then
            yC[l[1406]--[[]]][BP[l[1206]][xP]]=l[383];
          end
        end;
        kP();
        if not _P and BP[l[1617]] then
          I(BP[l[1617]],yC:get());
        end
        return;
      end
      if XP[l[40]](VP)~=l[409]or VP==yC[l[955]]and not y[18][l[921]]or not XP[l[1346]][l[23]](BP[l[1206]],VP) then
        return;
      end
      yC[l[955]]=VP;
      kP();
      if not _P and BP[l[1617]] then
        I(BP[l[1617]],VP);
      end
    end
    yC[l[1255]]=wP;
    local function wP(WP,VP)
      WP=s[87]();
      if WP[l[40]](VP)~=l[1346] then
        return;
      end
      local _P=BP[l[1693]]and yC:get()or yC[l[955]];
      BP[l[1206]]=VP;
      yC[l[955]]=nil;
      WP[l[1346]][l[267]](yC[l[1406]--[[]]]);
      JC();
      if BP[l[1693]] then
        yC:set(_P,l[383]);
      elseif _P and WP[l[1346]][l[23]](VP,_P) then
        yC:set(_P,l[383]);
      else
        yC:set(VP[l[229]],l[383]);
      end
      NP();
      if not yC[l[404]] then
        return;
      end
      if #VP==l[393] then
        PC();
        return;
      end
      sC();
    end
    yC[l[1087]]=wP;
    d(LC:GetPropertyChangedSignal(l[996]),function()
      local wP=s[87]();
      lC[l[392]]=wP[l[1459]][l[588]](l[393],j(LC)[l[636]]+l[310]);
    end);
    d(tP[l[445]],PC);
    d(QP[l[445]],function()
      if #BP[l[1206]]==l[393] then
        return;
      end
      yC:setopen(not yC[l[404]]);
      y[18]:chime(l[1352]);
    end);
    d(QP[l[1538]],function()
      zC=l[383];
      iP();
    end);
    d(QP[l[1628]],function()
      zC=l[1329];
      iP();
    end);
    JC();
    if BP[l[1693]] then
      if BP[l[950]]~=nil then
        yC:set(BP[l[950]]);
      end
    else
      yC:set(BP[l[950]]or BP[l[1206]][l[229]]);
    end
    NP();
    iP();
    y[18]:hook(BP[l[1013]]or hP..l[1074]..BP[l[572]],l[1206],function()
      local NP=s[87]();
      if BP[l[1693]] then
        return NP[l[1346]][l[978]](yC:get(),l[1200]);
      end
      return yC[l[955]];
    end,function(NP)
      yC:set(NP);
    end,{[l[284]]=function(NP)
      local wP=s[87]();
      if not BP[l[1693]] then
        return wP[l[1346]][l[23]](BP[l[1206]],NP)~=nil;
      end
      for WP in wP[l[409]][l[78]](NP,l[397])do
        if not wP[l[1346]][l[23]](BP[l[1206]],wP[l[409]][l[56]](WP,l[381])) then
          return l[1329];
        end
      end;
      return l[383];
    end});
    return yC;
  end
  fP[l[1336]]=J;
  local function J(NP,BP)
    NP=s[87]();
    BP=X(BP,{[l[572]]=l[138],[l[13]]=nil,[l[1013]]=nil,[l[1617]]=nil});
    fP[l[668]]+=l[229];
    local wP,WP,VP=aP[l[1594]--[[__index]]],aP[l[438]],aP[l[745]];
    local _P=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[688]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
    local wP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[659]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[659]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[1026],l[393],l[1655]),[l[1535]]=R[l[1466]],[l[1646]]=l[841],[l[1418]]=l[393],[l[656]]=l[383],[l[711]]=l[1158]},_P);
    D(wP,l[1158]);
    local XP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1373]},wP);
    local xP=a(l[211],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1158]},wP);
    D(xP,l[1158]);
    K(xP,l[393],{NP[l[677]][l[772]](l[393],l[393]),NP[l[677]][l[772]](l[1017],l[1373]),NP[l[677]][l[772]](l[229],l[229])});
    local kP=BP[l[13]];
    if kP then
      local vP=a;
      local IP=l[859];
      local iP={};
      iP[l[1150]]=f();
      iP[l[1016]]=NP[l[1689]][l[772]](l[393],l[659]);
      iP[l[948]]=NP[l[1459]][l[772]](l[393],l[551],l[659],l[393]);
      iP[l[1639]]=NP[l[1459]][l[588]](l[750],l[750]);
      iP[l[1646]]=l[229];
      iP[l[1451]]=y[30](BP[l[13]]);
      iP[l[936]]=R[l[1379]];
      iP[l[2]]=l[986];
      iP[l[1557]]=NP[l[128]][l[1557]][l[220]];
      iP[l[711]]=l[1092];
      kP=vP(IP,iP,wP);
    end
    local vP=kP or nil;
    local kP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP[l[13]]and l[941]or l[551],l[393]),[l[1639]]=NP[l[1459]][l[772]](l[229],BP[l[13]]and l[860]or l[1069],l[229],l[393]),[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=BP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[986],[l[164]]=NP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[13]]and NP[l[128]][l[1634]][l[701]]or NP[l[128]][l[1634]][l[46]],[l[711]]=l[1092]},wP);
    local IP=a(l[211],{[l[1150]]=f(),[l[1016]]=NP[l[1689]][l[772]](l[659],l[229]),[l[948]]=NP[l[1459]][l[1368]](l[659],l[229]),[l[1639]]=NP[l[1459]][l[772]](l[229],l[393],l[393],l[229]),[l[1535]]=R[l[98]],[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[930]},wP);
    K(IP,l[393],{NP[l[677]][l[772]](l[393],l[229]),NP[l[677]][l[772]](l[659],l[393]),NP[l[677]][l[772]](l[229],l[229])});
    local iP,EP,QP,tP=a(l[1742],{[l[1150]]=f(),[l[1639]]=NP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},wP),NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=_P};
    tP[l[572]]=BP[l[572]];
    EP(QP,tP);
    local NP={[l[266]]=_P};
    local EP=l[1329];
    local function QP()
      P(wP,H,{[l[1646]]=EP and l[393]or l[841]});
      P(XP,H,{[l[747]]=EP and l[330]or l[1373]});
      P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
      P(kP,H,{[l[916]]=EP and l[393]or l[986],[l[510]]=EP and R[l[1095]]or R[l[1379]]});
      if vP then
        P(vP,H,{[l[2]]=EP and l[393]or l[986],[l[936]]=EP and R[l[1095]]or R[l[1379]]});
      end
    end
    local function wP(XP)
      xP[l[1646]]=l[1567];
      IP[l[1646]]=l[263];
      P(xP,H,{[l[1646]]=EP and l[804]or l[229]});
      P(IP,H,{[l[1646]]=l[229]});
      y[18]:chime(l[1320]);
      if BP[l[1617]] then
        I(BP[l[1617]]);
      end
    end
    NP[l[1498]]=wP;
    d(iP[l[445]],function()
      NP:fire();
    end);
    d(iP[l[1538]],function()
      EP=l[383];
      QP();
    end);
    d(iP[l[1628]],function()
      EP=l[1329];
      QP();
    end);
    local wP=SP(_P,BP[l[572]],WP,VP,{[l[1463]]=BP[l[1013]]or hP..l[1074]..BP[l[572]],[l[103]]=nil,[l[649]]=l[1329],[l[1498]]=function(SP)
      if SP then
        NP:fire();
      end
    end});
    NP[l[1686]]=wP;
    d(iP[l[861]],function()
      if not wP:flip() then
        return;
      end
      y[18]:chime(l[1352]);
    end);
    QP();
    return NP;
  end
  fP[l[138]]=J;
  local function J(NP,SP)
    NP=s[87]();
    SP=X(if NP[l[40]](SP)==l[409]then{[l[572]]=SP}else SP,{[l[572]]=l[1094],[l[13]]=nil,[l[1141]]=l[1329],[l[73]]=nil});
    fP[l[668]]+=l[229];
    local BP=aP[l[1594]--[[__index]]];
    local wP=a(l[211],{[l[1150]]=f(),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],l[393],l[393],l[393])or NP[l[1459]][l[772]](l[229],l[393],l[393],l[1243]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},BP);
    local WP,VP,_P=NP[l[1346]][l[968]],FP[l[12]],{[l[266]]=wP};
    _P[l[572]]=SP[l[572]];
    WP(VP,_P);
    BP=l[303];
    if SP[l[13]] then
      BP=l[1655];
      local WP=a;
      local VP=l[859];
      local _P={};
      _P[l[1150]]=f();
      _P[l[1016]]=NP[l[1689]][l[772]](l[393],l[393]);
      _P[l[948]]=NP[l[1459]][l[588]](l[303],l[303]);
      _P[l[1639]]=NP[l[1459]][l[588]](l[310],l[310]);
      _P[l[1646]]=l[229];
      _P[l[1451]]=y[30](SP[l[13]]);
      _P[l[936]]=R[l[1379]];
      _P[l[2]]=l[1431];
      _P[l[1557]]=NP[l[128]][l[1557]][l[220]];
      _P[l[711]]=l[1158];
      WP(VP,_P,wP);
    else
    end
    local WP=a(l[1070],{[l[1150]]=f(),[l[948]]=NP[l[1459]][l[588]](BP,l[393]),[l[1639]]=SP[l[1141]]and NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[393],l[393])or NP[l[1459]][l[772]](l[229],-(BP+l[930]),l[229],l[393]),[l[1347]]=SP[l[1141]]and NP[l[128]][l[1347]][l[636]]or NP[l[128]][l[1347]][l[31]],[l[1646]]=l[229],[l[437]]=NP[l[128]][l[437]][l[1381]],[l[1420]]=NP[l[1130]](SP[l[572]]),[l[510]]=SP[l[73]]or R[l[1379]],[l[723]]=l[310],[l[916]]=l[263],[l[164]]=not SP[l[1141]]and NP[l[128]][l[164]][l[1021]]or NP[l[128]][l[164]][l[31]],[l[789]]=SP[l[1141]]and l[383]or l[1329],[l[1634]]=NP[l[128]][l[1634]][l[701]],[l[65]]=SP[l[1141]]and NP[l[128]][l[65]][l[1728]]or NP[l[128]][l[65]][l[46]],[l[711]]=l[1158]},wP);
    if SP[l[1141]] then
      a(l[1359],{[l[299]]=NP[l[740]][l[772]](l[393],l[786]),[l[645]]=NP[l[740]][l[772]](l[393],l[786])},wP);
    end
    BP={[l[266]]=wP,[l[1095]]=WP};
    local function NP(SP,wP)
      SP=s[87]();
      WP[l[1420]]=SP[l[1130]](wP);
    end
    BP[l[1255]]=NP;
    local function NP(SP)
      return WP[l[1420]];
    end
    BP[l[506]]=NP;
    local function NP(SP,wP)
      SP=s[87]();
      if SP[l[1703]](wP)==l[360] then
        WP[l[510]]=wP;
      end
    end
    BP[l[539]]=NP;
    return BP;
  end
  fP[l[1094]]=J;
  local function J(NP,SP)
    local BP=s[87]();
    SP=X(SP,{[l[572]]=l[1409],[l[950]]=R[l[98]],[l[1013]]=nil,[l[1617]]=nil});
    if SP[l[230]]and BP[l[1703]](R[SP[l[230]]])==l[360] then
      local wP=SP[l[1617]];
      SP[l[950]]=R[SP[l[230]]];
      SP[l[1617]]=function(WP)
        y[18]:recolor(SP[l[230]],WP);
        if wP then
          wP(WP);
        end
      end;
    end
    fP[l[668]]+=l[229];
    local wP,WP=aP[l[1594]--[[__index]]],aP[l[438]];
    local VP=aP[l[745]];
    local aP=l[291];
    local _P=l[291];
    local XP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[772]](l[229],l[393],l[393],l[658]),[l[1646]]=l[229],[l[1418]]=l[393],[l[537]]=fP[l[668]],[l[711]]=l[303]},wP);
    local xP=a(l[1070],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[303],l[393]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1099],l[229],l[393]),[l[1646]]=l[229],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=SP[l[572]],[l[510]]=R[l[1379]],[l[723]]=l[750],[l[916]]=l[615],[l[164]]=BP[l[128]][l[164]][l[1021]],[l[1634]]=BP[l[128]][l[1634]][l[701]],[l[711]]=l[1158]},XP);
    local kP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[66],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[658],l[829]),[l[1535]]=SP[l[950]],[l[1418]]=l[393],[l[711]]=l[1158]},XP);
    D(kP,l[786]);
    local vP=a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[986]},kP);
    wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[1092]},kP);
    D(wP,l[786]);
    K(wP,l[117],{BP[l[677]][l[772]](l[393],l[1567]),BP[l[677]][l[772]](l[229],l[229])});
    local IP,iP=a(l[1742],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[229],l[659]),[l[948]]=BP[l[1459]][l[772]](l[229],l[1452],l[659],l[393]),[l[1639]]=BP[l[1459]][l[588]](l[913],l[1243]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[551]},XP),a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[1324]]=l[1329],[l[711]]=l[910]},YP);
    local EP=GP and a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1646]]=l[229],[l[1418]]=l[393],[l[1324]]=l[1329],[l[711]]=l[1249]},YP)or nil;
    local GP=EP and a(l[1198],{[l[1630]]=R[l[641]],[l[258]]=BP[l[740]][l[772]](l[393],l[829]),[l[1485]]=BP[l[1459]][l[588]](l[393],l[303]),[l[1326]]=BP[l[1459]][l[588]](l[1452],l[1452]),[l[747]]=l[229],[l[711]]=l[715]},EP)or nil;
    if EP then
      D(EP,l[930]);
    end
    local QP=a(l[1751],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[588]](l[393],l[393]),[l[1535]]=R[l[675]],[l[1418]]=l[393],[l[656]]=l[383],[l[1569]]=l[229],[l[1324]]=l[1329],[l[711]]=l[1596]--[[__newindex]]},YP);
    D(QP,l[930]);
    wP,NP=l[1622],{[l[500]]=l[117]};
    NP[l[1630]]=BP[l[1262]][l[772]]({BP[l[527]][l[772]](l[393],BP[l[360]][l[772]](l[229],l[229],l[229])),BP[l[527]][l[772]](l[229],BP[l[360]][l[353]](l[291],l[291],l[920]))});
    a(wP,NP,QP);
    a(l[1742],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[2]]=l[229],[l[711]]=l[229]},QP);
    NP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1646]]=l[229],[l[1418]]=l[393],[l[711]]=l[906]},QP);
    D(NP,l[930]);
    a(l[734],{[l[1630]]=R[l[966]],[l[747]]=l[1419]},NP);
    local tP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[730]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[422]),[l[1535]]=BP[l[360]][l[149]](l[393],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
    D(tP,l[1158]);
    wP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
    D(wP,l[1158]);
    local RP,gP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]](l[229],l[229],l[229]))};
    gP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[393]),BP[l[677]][l[772]](l[229],l[229])});
    a(RP,gP,wP);
    gP=a(l[211],{[l[1150]]=f(),[l[1639]]=BP[l[1459]][l[1368]](l[229],l[229]),[l[1535]]=BP[l[360]][l[772]](),[l[1418]]=l[393],[l[711]]=l[1526]},tP);
    D(gP,l[1158]);
    wP,NP=l[1622],{[l[1630]]=BP[l[1262]][l[772]](BP[l[360]][l[772]]()),[l[500]]=l[117]};
    NP[l[747]]=BP[l[1197]][l[772]]({BP[l[677]][l[772]](l[393],l[229]),BP[l[677]][l[772]](l[229],l[393])});
    a(wP,NP,gP);
    a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},tP);
    local uP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[551],l[551]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},tP);
    RP,NP=l[1112],{};
    NP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
    a(RP,NP,uP);
    a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},uP);
    local NP=a(l[211],{[l[1150]]=f(),[l[43]]=l[383],[l[948]]=BP[l[1459]][l[588]](l[730],l[633]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1274],l[393],l[730]),[l[1535]]=BP[l[360]][l[772]](l[229],l[229],l[229]),[l[1418]]=l[393],[l[711]]=l[913]},QP);
    D(NP,l[303]);
    a(l[734],{[l[1630]]=R[l[675]],[l[1544]]=l[1525]},NP);
    wP={};
    for UP=l[393],l[1158],l[229]do
      BP[l[1346]][l[968]](wP,BP[l[527]][l[772]](UP/l[1158],BP[l[360]][l[149]](UP/l[1158],l[229],l[229])));
    end;
    gP,RP=l[1622],{};
    RP[l[1630]]=BP[l[1262]][l[772]](wP);
    a(gP,RP,NP);
    local UP=a(l[211],{[l[1150]]=f(),[l[1016]]=BP[l[1689]][l[772]](l[659],l[659]),[l[948]]=BP[l[1459]][l[1368]](l[393],l[659]),[l[1639]]=BP[l[1459]][l[588]](l[786],l[829]),[l[1535]]=R[l[98]],[l[1418]]=l[393],[l[711]]=l[1282]},NP);
    gP,wP=l[1112],{};
    wP[l[1182]]=BP[l[740]][l[772]](l[229],l[393]);
    a(gP,wP,UP);
    a(l[734],{[l[1630]]=R[l[641]],[l[747]]=l[986]},UP);
    local MP=a(l[1400]--[[-1]],{[l[1150]]=f(),[l[948]]=BP[l[1459]][l[588]](l[730],l[1109]),[l[1639]]=BP[l[1459]][l[772]](l[229],l[1743],l[393],l[1243]),[l[1535]]=R[l[1466]],[l[1418]]=l[393],[l[1155]]=l[1329],[l[656]]=l[383],[l[437]]=BP[l[128]][l[437]][l[1381]],[l[1420]]=p(SP[l[950]]),[l[510]]=R[l[1095]],[l[723]]=l[750],[l[711]]=l[913]},QP);
    D(MP,l[303]);
    local sC=a(l[734],{[l[1161]]=BP[l[128]][l[1161]][l[1741]],[l[1630]]=R[l[966]],[l[747]]=l[411]},MP);
    local function lC(LC,yC)
      local zC=s[87]();
      local TC=a;
      local nC=l[1742];
      local JC={};
      JC[l[1150]]=f();
      JC[l[1016]]=zC[l[1689]][l[772]](l[229],l[393]);
      JC[l[948]]=zC[l[1459]][l[772]](l[229],LC,l[393],l[1394]);
      JC[l[1639]]=zC[l[1459]][l[588]](l[1707],l[1707]);
      JC[l[1535]]=R[l[1466]];
      JC[l[1646]]=l[229];
      JC[l[1418]]=l[393];
      JC[l[1451]]=y[30](yC);
      JC[l[936]]=R[l[1379]];
      JC[l[2]]=l[986];
      JC[l[1557]]=zC[l[128]][l[1557]][l[220]];
      JC[l[711]]=l[913];
      local LC=TC(nC,JC,QP);
      D(LC,l[303]);
      d(LC[l[1538]],function()
        P(LC,H,{[l[2]]=l[393],[l[936]]=R[l[1095]],[l[1646]]=l[330]});
      end);
      d(LC[l[1628]],function()
        P(LC,H,{[l[2]]=l[986],[l[936]]=R[l[1379]],[l[1646]]=l[229]});
      end);
      return LC;
    end
    local LC=lC(l[1726],l[1549]);
    local yC=lC(l[1026],l[967]);
    local lC={[l[266]]=XP,[l[404]]=l[1329],[l[1409]]=SP[l[950]],[l[771]]=l[1329]};
    local zC={[l[434]]=l[393],[l[900]]=l[229],[l[999]]=l[229],[l[259]]=l[1329],[l[700]]=nil};
    local TC,nC=l[1329];
    local JC=l[1329];
    local HC=l[393];
    local function fC(aC)
      local dC=s[87]();
      if not SP[l[1617]] then
        return;
      end
      local PC=y[18][l[921]];
      if PC then
        local ZC=HC;
        HC=ZC+l[229];
        ZC=nil;
        ZC,nC=l[1329],nil;
        JC=ZC;
        I(SP[l[1617]],aC);
        return;
      end
      nC=aC;
      PC=JC;
      if PC then
        return;
      end
      JC=l[383];
      aC=HC;
      HC=aC+l[229];
      local aC=HC;
      local PC=y[18][l[1478]];
      dC[l[1022]][l[1330]](l[1296],function()
        local dC=HC;
        if aC~=dC then
          return;
        end
        dC=nC;
        local HC=dC;
        nC=nil;
        JC=l[1329];
        if HC and y[18][l[630]]and PC==y[18][l[1478]] then
          I(SP[l[1617]],HC);
        end
      end);
    end
    gP,RP,wP=BP[l[1346]][l[968]],FP[l[12]],{[l[266]]=XP};
    wP[l[572]]=SP[l[572]];
    gP(RP,wP);
    zC[l[434]],zC[l[900]],zC[l[999]]=BP[l[360]][l[1412]](SP[l[950]]);
    local function BP()
      local wP=s[87]();
      P(vP,H,{[l[747]]=(lC[l[404]]or TC)and l[393]or l[986]});
      P(xP,H,{[l[916]]=(lC[l[404]]or TC)and l[1209]or l[615]});
      P(kP,H,{[l[1639]]=wP[l[1459]][l[588]]((lC[l[404]]or TC)and l[688]or l[658],(lC[l[404]]or TC)and l[114]or l[829])});
    end
    local function wP(FP,xP)
      local vP=s[87]();
      local RP,gP,nC=vP[l[360]][l[149]](zC[l[434]],zC[l[900]],zC[l[999]]),vP[l[1459]][l[1368]](zC[l[900]],l[229]-zC[l[999]]),vP[l[1459]][l[772]](zC[l[434]],l[393],l[659],l[393]);
      if xP then
        uP[l[948]]=gP;
        UP[l[948]]=nC;
        uP[l[1535]]=RP;
        tP[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229]);
        kP[l[1535]]=RP;
      else
        P(uP,n,{[l[948]]=gP,[l[1535]]=RP});
        P(UP,n,{[l[948]]=nC});
        P(tP,n,{[l[1535]]=vP[l[360]][l[149]](zC[l[434]],l[229],l[229])});
        P(kP,n,{[l[1535]]=RP});
      end
      if not MP:IsFocused() then
        MP[l[1420]]=p(RP);
      end
      lC[l[1409]]=RP;
      if FP then
        fC(RP);
      end
    end
    local function FP()
      local xP,vP,RP,gP,uP=s[87](),G(YP),e(YP),G(kP),e(kP);
      local UP,nC=gP[l[1437]]-vP[l[1437]]+uP[l[1437]]-aP,lC[l[771]]and gP[l[636]]-vP[l[636]]-l[1158]or gP[l[636]]-vP[l[636]]+uP[l[636]]+l[1158];
      UP=if UP+aP>RP[l[1437]]-l[930]then RP[l[1437]]-l[930]-aP else UP;
      QP[l[948]]=xP[l[1459]][l[588]](xP[l[35]][l[499]](xP[l[35]][l[850]](UP,l[930])+l[659]),xP[l[35]][l[499]](nC+l[659]));
      if EP then
        EP[l[948]]=QP[l[948]];
      end
    end
    local function xP()
      local vP=QP[l[1569]];
      local RP=lC[l[404]]and l[393]or l[229];
      b(QP,lC[l[404]]and l[894]or l[304],lC[l[404]]and N or q,function(gP)
        local uP=vP+(RP-vP)*gP;
        QP[l[1569]]=uP;
        if EP then
          EP[l[1646]]=uP;
          GP[l[747]]=l[615]+l[411]*uP;
        end
        if gP>=l[229] then
          QP[l[1324]]=lC[l[404]];
          if EP then
            EP[l[1324]]=lC[l[404]];
          end
        end
      end);
    end
    local GP;
    local function vP()
      local RP=GP;
      if RP then
        GP:Disconnect();
        GP=nil;
      end
    end
    local function RP()
      local gP=S;
      if gP>l[393] then
        return;
      end
      lC:setopen(l[1329]);
    end
    local function gP()
      local uP=S;
      if uP>l[393] then
        FP();
        return;
      end
      if not LP[l[1600]]or not KP[l[1324]]or not XP[l[1324]] then
        lC:setopen(l[1329]);
        return;
      end
      local XP,UP,nC,JC,HC,fC=WP[l[81]],WP[l[160]],VP[l[81]],VP[l[160]],kP[l[81]],kP[l[160]];
      uP=HC[l[636]]+fC[l[636]]*l[659];
      if uP<XP[l[636]]or uP>XP[l[636]]+UP[l[636]]or uP<nC[l[636]]or uP>nC[l[636]]+JC[l[636]] then
        lC:setopen(l[1329]);
        return;
      end
      FP();
    end
    local function VP(XP,uP)
      local UP={};
      XP=s[87]();
      uP=uP and l[383]or l[1329];
      if lC[l[404]]==uP then
        return;
      end
      lC[l[404]]=uP;
      if uP then
        V();
        local V,uP,nC,JC=G(YP),e(YP),G(kP),e(kP);
        local G,kP=uP[l[636]]-(nC[l[636]]-V[l[636]]+JC[l[636]]+l[1158])-l[1158],nC[l[636]]-V[l[636]]-l[310];
        lC[l[771]]=G<_P and kP>G;
        QP[l[1016]]=XP[l[1689]][l[772]](l[393],lC[l[771]]and l[229]or l[393]);
        QP[l[1639]]=XP[l[1459]][l[588]](aP,_P);
        QP[l[1324]]=l[383];
        iP[l[1324]]=l[383];
        if EP then
          EP[l[1016]]=QP[l[1016]];
          EP[l[1639]]=QP[l[1639]];
          EP[l[1324]]=l[383];
        end
        FP();
        A,w=RP,QP;
        vP();
        UP[1]=(y[10][l[1119]]:Connect(gP));
        GP=UP[1];
      else
        vP();
        iP[l[1324]]=l[1329];
        local G=A==RP;
        if G then
          A,w=nil,nil;
        end
        if MP:IsFocused() then
          MP:ReleaseFocus();
        end
      end
      BP();
      xP();
    end
    lC[l[1521]--[[0]]]=VP;
    local function G(A,w)
      A=s[87]();
      w=if A[l[1703]](w)==l[409]then r(w)else w;
      if A[l[1703]](w)~=l[360] then
        return;
      end
      zC[l[434]],zC[l[900]],zC[l[999]]=A[l[360]][l[1412]](w);
      wP(l[383]);
    end
    lC[l[1255]]=G;
    local function G(A)
      return lC[l[1409]];
    end
    lC[l[506]]=G;
    local function G()
      if not zC[l[259]] then
        return;
      end
      zC[l[259]]=l[1329];
      zC[l[700]]=nil;
      if zC[l[1731]] then
        zC[l[1731]]:Disconnect();
        zC[l[1731]]=nil;
      end
      WP[l[1195]]=l[383];
      O(l[715]);
    end
    local function A()
      local w=s[87]();
      if zC[l[259]]and zC[l[700]] then
        local V,aP=w[l[1146]](function()
          zC[l[700]]();
          wP(l[383],l[383]);
        end);
        if not V then
          G();
          w[l[972]](l[1752]..w[l[1130]](aP));
        end
      end
    end
    local function w(V,aP)
      d(V[l[956]],G);
      d(V[l[1558]],function(GP)
        local FP=s[87]();
        if GP[l[1317]]~=FP[l[128]][l[1317]][l[1356]]and GP[l[1317]]~=FP[l[128]][l[1317]][l[239]] then
          return;
        end
        if zC[l[259]] then
          return;
        end
        zC[l[259]]=l[383];
        zC[l[700]]=aP;
        zC[l[225]]=GP;
        O(l[229]);
        zC[l[1731]]=B(GP,G);
        WP[l[1195]]=l[1329];
        A();
      end);
      d(V[l[412]],function(B)
        local V=s[87]();
        if B[l[1317]]==V[l[128]][l[1317]][l[1356]]or B[l[1317]]==V[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
          G();
        end
      end);
    end
    w(tP,function()
      local B,V,aP,GP=s[87](),tP[l[81]],tP[l[160]],v(zC[l[225]]);
      zC[l[900]]=B[l[35]][l[819]]((GP[l[1437]]-V[l[1437]])/B[l[35]][l[850]](aP[l[1437]],l[229]),l[393],l[229]);
      zC[l[999]]=l[229]-B[l[35]][l[819]]((GP[l[636]]-V[l[636]])/B[l[35]][l[850]](aP[l[636]],l[229]),l[393],l[229]);
    end);
    w(NP,function()
      local B,w,V=s[87](),NP[l[81]],NP[l[160]];
      zC[l[434]]=B[l[35]][l[819]]((v(zC[l[225]])[l[1437]]-w[l[1437]])/B[l[35]][l[850]](V[l[1437]],l[229]),l[393],l[229]);
    end);
    d(y[9][l[412]],function(B)
      local w=s[87]();
      if B[l[1317]]==w[l[128]][l[1317]][l[1356]]or B[l[1317]]==w[l[128]][l[1317]][l[239]]and B==zC[l[225]] then
        G();
      end
    end);
    d(y[9][l[233]],function(G)
      local B=s[87]();
      if not zC[l[259]] then
        return;
      end
      if G[l[1317]]==B[l[128]][l[1317]][l[765]]or G[l[1317]]==B[l[128]][l[1317]][l[239]] then
        if G[l[1317]]==B[l[128]][l[1317]][l[239]]and G~=zC[l[225]] then
          return;
        end
        A();
      end
    end);
    d(MP[l[505]],function()
      O(l[229]);
      P(sC,H,{[l[747]]=l[615]});
    end);
    d(MP[l[722]],function()
      local G=s[87]();
      O(l[715]);
      P(sC,H,{[l[747]]=l[411]});
      local B=r(MP[l[1420]]);
      if B then
        zC[l[434]],zC[l[900]],zC[l[999]]=G[l[360]][l[1412]](B);
      end
      wP(l[383]);
    end);
    local function G(B)
      B[l[936]]=R[l[98]];
      B[l[2]]=l[393];
      P(B,H,{[l[936]]=R[l[1379]],[l[2]]=l[986]});
    end
    d(LC[l[445]],function()
      local B=s[87]();
      if y[14] then
        B[l[1146]](y[14],p(lC[l[1409]]));
      end
      G(LC);
      y[18]:chime(l[1320]);
    end);
    d(yC[l[445]],function()
      local B=s[87]();
      local A=r(y[15]and B[l[199]](l[59],B[l[1146]](y[15])));
      if A then
        zC[l[434]],zC[l[900]],zC[l[999]]=B[l[360]][l[1412]](A);
        wP(l[383]);
        G(yC);
        y[18]:chime(l[1320]);
      end
    end);
    d(iP[l[445]],RP);
    d(IP[l[445]],function()
      lC:setopen(not lC[l[404]]);
      y[18]:chime(l[1352]);
    end);
    d(IP[l[1538]],function()
      TC=l[383];
      BP();
    end);
    d(IP[l[1628]],function()
      TC=l[1329];
      BP();
    end);
    wP(l[1329],l[383]);
    BP();
    VP=SP[l[1013]]or SP[l[230]]and l[1321]..SP[l[230]];
    y[18]:hook(VP or hP..l[1074]..SP[l[572]],l[1409],function()
      return lC[l[1409]];
    end,function(G)
      lC:set(G);
    end);
    return lC;
  end
  fP[l[1409]]=J;
  return fP;
end
