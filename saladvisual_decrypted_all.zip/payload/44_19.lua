-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #19
-- offset 3618022..3620010 (1988 bytes, type=payload)

function(n)
  local w=L;
  if not w.ScreenGui.Parent then
    return;
  end
  w=s.Game and s.On;
  if w then
    O+=n;
    local F=O>0.12;
    if F then
      O=0;
      local O,F=q();
      local h=table.concat({tostring(O),tostring(F),s.Bright,s.Rate,s.Amount,s.Size,s.Life,tostring(s.Rainbow),tostring(s.Tint)},"|");
      O=h~=B;
      if O then
        B=h;
        r();
      end
    end
  end
  if not next(l) then
    return;
  end
  local O,B=q();
  w=s.Rainbow and ColorSequence.new(O,B)or nil;
  for F,h in pairs(l)do
    local W,V,_=h.cfg or s;
    if W~=s then
      V,_=q(W);
      w=W.Rainbow and ColorSequence.new(V,_)or nil;
    else
      V,_=O,B;
    end
    if not h.root or not h.root.Parent then
      j(F);
    elseif h.emitter then
      if not h.emitter.Parent then
        j(F);
      else
        local q,O=(h.root.AssemblyLinearVelocity*Vector3.new(1,0,1)).Magnitude,F:FindFirstChildOfClass("Humanoid");
        local B,X=O and O.MoveDirection.Magnitude>0.05,O and(O:GetState()==Enum.HumanoidStateType.Jumping or O:GetState()==Enum.HumanoidStateType.Freefall);
        X=W.Always or q>7 and(B or X);
        B=h.style;
        if h.enabled~=X then
          h.enabled=X;
          h.emitter.Enabled=X;
        end
        q,O=nil;
        if B.own then
          q,O=P,P;
        else
          q,O=V,_;
        end
        if h.first~=q or h.second~=O then
          h.first=q;
          h.second=O;
          h.emitter.Color=not B.own and w or ColorSequence.new(q,O);
        end
        if h.life~=W.Life then
          h.life=W.Life;
          h.emitter.Lifetime=NumberRange.new(W.Life*0.65,W.Life);
        end
        if h.size~=W.Size then
          h.size=W.Size;
          h.emitter.Size=D(B,W);
        end
        if h.rate~=W.Rate or h.amount~=W.Amount then
          h.rate,h.amount=W.Rate,W.Amount;
          h.emitter.Rate=B.rate*(W.Rate/100)*(W.Amount/100);
        end
        if h.bright~=W.Bright then
          h.bright=W.Bright;
          h.emitter.Transparency=p(W);
        end
        if B.sprite and#B.sprite>1 and X then
          h.swap=h.swap+n;
          if h.swap>0.22 then
            h.swap=0;
            h.emitter.Texture=C(B);
          end
        end
      end
    elseif not h.trail or not h.trail.Parent then
      j(F);
    else
      if h.first~=V or h.second~=_ then
        h.first=V;
        h.second=_;
        h.trail.Color=w or ColorSequence.new(V,_);
      end
      if h.life~=W.Life then
        h.life=W.Life;
        h.trail.Lifetime=W.Life;
      end
      if h.size~=W.Size then
        h.size=W.Size;
        h.a.Position=Vector3.new(0,W.Size*0.09,0);
        h.b.Position=Vector3.new(0,-W.Size*0.09,0);
      end
    end
  end;
end
