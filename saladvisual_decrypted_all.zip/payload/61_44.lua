-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #44
-- offset 122807..123383 (576 bytes, type=payload)

function()
  if A:IsA("ParticleEmitter") then
    A.Rate=S.rate*F*h;
    A.Brightness=S.bright*w;
    A.Size=D(S.size,W);
    local D=math.clamp(V,0.05,5);
    A.Speed=NumberRange.new(S.speed.Min*D,S.speed.Max*D);
    A.RotSpeed=NumberRange.new(S.spin.Min*D,S.spin.Max*D);
    A.Lifetime=NumberRange.new(math.max(0.05,S.life.Min*_/D),math.max(0.06,S.life.Max*_/D));
  elseif A:IsA("Trail") then
    A.Lifetime=math.max(0.05,S.life*_);
    A.Brightness=S.bright*w;
  elseif A:IsA("Beam")or A:IsA("Light") then
    A.Brightness=S.bright*w;
  elseif A:IsA("BasePart")or A:IsA("Decal") then
    A.Transparency=1-(1-S.transparency)*X;
  end
  o(S,B);
end
