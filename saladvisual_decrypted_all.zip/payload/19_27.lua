-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[19] / function #27
-- offset 3605563..3606016 (453 bytes, type=payload)

local function h()
  local _,x=e(),workspace.CurrentCamera;
  local v,I=x and x.ViewportSize or Vector2.new(1280,720),_ and _.AbsoluteSize or Vector2.new(640,480);
  local i,E=_ and _.AbsolutePosition or v/2-I/2,L;
  local t,g,u=E.ScreenGui.AbsolutePosition,math.floor(I.Y*0.46),16;
  _=i.X+I.X+u+g<=v.X;
  x=_ and i.X+I.X or i.X;
  return{right=_,width=g,height=I.Y,y=i.Y-t.Y,open=(_ and x+u or x-u-g)-t.X,tucked=(_ and x-g-16 or x+16)-t.X,edge=x-t.X,mid=i.Y+I.Y/2-t.Y};
end
