-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #24
-- offset 114992..115438 (446 bytes, type=payload)

local function D(p,r)
  local K;
  local K=not y[4][y[6]]or not b;
  if K then
    return nil;
  end
  local o,c=false;
  local m=true;
  task.spawn(function()
    local S,O=pcall(r);
    local r=m and y[4][y[6]]and b;
    if r then
      c=S and O or nil;
    elseif typeof(O)=="Instance" then
      O:Destroy();
    end
    o=true;
  end);
  K=os.clock()+p;
  while true do
    p=not o and y[4][y[6]]and b;
    if not(p and os.clock()<K) then
      break;
    end
    task.wait(0.05);
  end;
  m=false;
  p=typeof(c)=="Instance"and c or nil;
  return p;
end
