-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #10
-- offset 3665272..3665830 (558 bytes, type=payload)

local function b(D,p)
  local r,K=pcall(function()
    return not p.Disabled;
  end);
  if not r then
    return;
  end
  local r=K or l._reloadAnimate==p and l._reloadEnabled;
  l._reloadSerial=(l._reloadSerial or 0)+1;
  local K=l._reloadSerial;
  l._reloadAnimate=p;
  l._reloadEnabled=r;
  if not pcall(function()p.Disabled=true;end) then
    return;
  end
  q(D);
  task.spawn(function()
    task.wait();
    if K~=l._reloadSerial then
      return;
    end
    l._reloadAnimate=nil;
    l._reloadEnabled=nil;
    if p.Parent~=D.Parent or l._emoteAnimate==p then
      return;
    end
    q(D);
    if r then
      pcall(function()
        p.Disabled=false;
      end);
    end
  end);
end
