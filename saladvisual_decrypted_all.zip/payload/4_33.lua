-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[4] / function #33
-- offset 3255203..3255414 (211 bytes, type=payload)

local function y()
  if z[1] then
    return;
  end
  p+=1;
  local T=p;
  r=0.25;
  z[#z+1]=workspace.DescendantAdded:Connect(n);
  z[#z+1]=workspace.DescendantRemoving:Connect(c);
  local n;
  local n=Z;
  D=n.RenderStepped:Connect(d);
  m(T);
end
