-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #43
-- offset 122587..123388 (801 bytes, type=payload)

local function m(S,O,B)
  local A=S[1];
  if not A.Parent then
    return;
  end
  local w=O.glow or 1;
  local F=O.rate or 1;
  local h=O.amount or 1;
  local W=O.size or 1;
  local V=O.speed or 1;
  local _=O.life or 1;
  local X=O.opacity or 1;
  pcall(function()
    if A:IsA("ParticleEmitter") then
      A.Rate=S.rate*F*h;
      A.Brightness=S.bright*w;
      A.Size=D(S.size,W);
      local D=math.clamp(V,0.05,5);
      A.Speed=NumberRange.new(S.speed.Min*D,S.speed.Max*D);
      A.RotSpeed=NumberRange.new(S.spin.Min*D,S.spin.Max*D);
      A.Lifetime=NumberRange.new(math.max(0.05,S.life.Min*_/D),math.max(0.06,S.life.Max*_/D));
    elseif A:IsA("Trail") then
      A.Lifetime=math.max(0.05,S.life*_);
      A.Brightness=S.bright*w;
    elseif A:IsA("Beam")or A:IsA("Light") then
      A.Brightness=S.bright*w;
    elseif A:IsA("BasePart")or A:IsA("Decal") then
      A.Transparency=1-(1-S.transparency)*X;
    end
    o(S,B);
  end);
end
