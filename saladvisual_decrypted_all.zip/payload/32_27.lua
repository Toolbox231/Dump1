-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #27
-- offset 234000..234951 (951 bytes, type=payload)

local function h()
  local W=C.Field and math.floor(C.Density)or 0;
  while#G>W do
    local V=table.remove(G);
    pcall(function()
      V.board:Destroy();
    end);
    pcall(function()
      V.seat:Destroy();
    end);
  end;
  while#G<W do
    local W,V=math.random()*2-1,math.random()*3.141592653589793*2;
    local _=math.sqrt(math.max(0,1-W*W));
    local X,x,k=Vector3.new(_*math.cos(V),W,_*math.sin(V)),Instance.new("Attachment"),L;
    x.Name=k.RandomString();
    x.Position=X*m;
    x.Parent=D;
    V,W=Instance.new("BillboardGui"),L;
    V.Name=W.RandomString();
    V.Adornee=x;
    V.LightInfluence=0;
    V.Size=UDim2.fromScale(1,1);
    V.Parent=y;
    k=Instance.new("ImageLabel");
    k.BackgroundTransparency=1;
    k.AnchorPoint=Vector2.new(0.5,0.5);
    k.Position=UDim2.fromScale(0.5,0.5);
    k.Size=UDim2.fromScale(1,1);
    k.Image=r or"rbxasset://textures/particles/sparkles_main.dds";
    k.Parent=V;
    G[#G+1]={seat=x,board=V,dot=k,aim=X,weight=0.1+math.random()^3*0.28,phase=math.random()*3.141592653589793*2,rate=0.4+math.random()*1.4,warm=math.random()<0.3};
  end;
end
