-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #53
-- offset 125508..125902 (394 bytes, type=payload)

function(c)
  local m=c.live.roots.HumanoidRootPart;
  local O=m and(m:WaitForChild("Main",5));
  if not O then
    return;
  end
  local B,A=c.char:FindFirstChild("Body Colors")or c.char:FindFirstChildOfClass("BodyColors"),c.limb("Torso");
  m=B and B.TorsoColor3 or A and A.Color or Color3.new(1,1,1);
  for c,c in ipairs(O:GetDescendants())do
    if c:IsA("ParticleEmitter") then
      c.Color=ColorSequence.new(m);
    end
  end;
end
