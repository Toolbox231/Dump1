-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[62] / function #19
-- offset 3229034..3229291 (257 bytes, type=payload)

function()
  local fP,aP=pcall(E.GetProductInfo,E,JP,Enum.InfoType.Asset);
  i[HP]=nil;
  I[HP]=fP and type(aP)=="table"and tonumber(aP.AssetTypeId)==Enum.AssetType.HairAccessory.Value or false;
  local i;
  fP=I[HP]and z[4][z[6]]and X and nP.Parent;
  if fP then
    F();
  end
end
