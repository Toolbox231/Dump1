-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[32] / function #35
-- offset 235781..239375 (3594 bytes, type=payload)

local function W(_)
  local X;
  local X=not(J[4][J[6]]and C.On);
  if X then
    B=0;
    return;
  end
  B=math.min(B+_,0.1);
  X=B;
  if X<0.03333333333333333 then
    return;
  end
  _=B;
  X=_;
  B%=0.03333333333333333;
  local J;
  local J=n;
  local B=J.camera();
  if not B then
    return;
  end
  local _,x=os.clock(),K;
  K=(x+X*(C.Spin/1000))%6.283185307179586;
  D.CFrame=CFrame.new(B.CFrame.Position)*CFrame.Angles(0,c,0)*CFrame.Angles(o,0,0)*CFrame.Angles(0,K,0);
  m-=X;
  X=m<=0;
  if X then
    m=0.25;
    q(B);
  end
  x=0;
  while x<2 and#r>0 do
    J=table.remove(r,1);
    if y[J]and C.Picked[J]and not T[J] then
      T[J]=A(J);
      x+=1;
    else
    end
  end;
  Y();
  local y,Y,q,r,K=C.Scale/100*S,C.Glow/100,C.Twinkle/100,C.Natural,D.CFrame;
  w(_,r and j or C.Star);
  h();
  X=C.Star:Lerp(e,0.5);
  s=(s+1)%3;
  B=1+s;
  for s=B,#G,3 do
    x=G[s];
    s=d(K:VectorToWorldSpace(x.aim).Y);
    if s<=0.002 then
      if x.board.Enabled then
        x.board.Enabled=false;
      end
    else
      if not x.board.Enabled then
        x.board.Enabled=true;
      end
      J=1+q*0.2*math.sin(_*x.rate+x.phase);
      local G,e=Y*s*x.weight*J,78*x.weight*y*J;
      x.board.Size=UDim2.fromScale(e,e);
      if x.board.AlwaysOnTop~=C.Always then
        x.board.AlwaysOnTop=C.Always;
      end
      e=r and x.warm and X or C.Star;
      if x.tone~=e then
        x.tone=e;
        x.dot.ImageColor3=e;
      end
      x.dot.ImageTransparency=math.clamp(1-G,0,1);
    end
  end;
  O=1-O;
  x=pairs;
  for s,G in x(T)do
    s,B=0.92+0.08*math.sin(_*0.32+G.sway),_-G.born;
    if C.Lines then
      for T,T in ipairs(G.stars)do
        T.horizon=d(K:VectorToWorldSpace(T.aim).Y);
      end;
    end
    X=1+O;
    for T=X,#G.stars,2 do
      J=G.stars[T];
      T=C.Lines and J.horizon or d(K:VectorToWorldSpace(J.aim).Y);
      if T<=0.002 then
        if J.board.Enabled then
          J.board.Enabled=false;
        end
        continue;
      end
      if not J.board.Enabled then
        J.board.Enabled=true;
      end
      J.alpha=math.clamp((B-J.delay)/0.55,0,1);
      local e=1+q*0.16*math.sin(_*J.rate+J.phase)+q*0.07*math.sin(_*J.rate*2.7+J.phase*1.7);
      local j,o,c=Y*T*J.alpha*s*(0.35+J.weight*0.65)*e,34*J.weight*y*(0.55+0.45*J.alpha)*(1+q*0.08*(e-1)*6),C.Star;
      if r then
        if J.mixedFor~=C.Star then
          J.mixedFor=C.Star;
          J.mixedTone=J.tint:Lerp(C.Star,0.35);
        end
        c=J.mixedTone;
      else
      end
      J.board.Size=UDim2.fromScale(o,o);
      if J.board.AlwaysOnTop~=C.Always then
        J.board.AlwaysOnTop=C.Always;
      end
      if J.tone~=c then
        J.tone=c;
        J.dot.ImageColor3=c;
        J.halo.ImageColor3=c;
      end
      J.dot.ImageTransparency=math.clamp(1-j,0,1);
      J.halo.ImageTransparency=math.clamp(1-j*J.weight*0.7,0,1);
      if J.label then
        j=C.Labels and T>0.25 and J.weight>0.62;
        if J.label.Visible~=j then
          J.label.Visible=j;
        end
        if j then
          if J.labelTone~=c then
            J.labelTone=c;
            J.label.TextColor3=c;
          end
          J.label.TextTransparency=math.clamp(0.35+(1-T)*0.65,0,1);
        end
      end
    end;
    if G.title then
      local T=G.title;
      if not C.Names then
        if T.board.Enabled then
          T.board.Enabled=false;
        end
      else
        local J=d(K:VectorToWorldSpace(T.aim).Y);
        local d=J>0.2;
        if T.board.Enabled~=d then
          T.board.Enabled=d;
        end
        if d then
          local d=26*y;
          T.board.Size=UDim2.fromScale(d*4,d);
          if T.board.AlwaysOnTop~=C.Always then
            T.board.AlwaysOnTop=C.Always;
          end
          if T.tone~=C.Line then
            T.tone=C.Line;
            T.tag.TextColor3=C.Line;
          end
          T.tag.TextTransparency=math.clamp(0.5+(1-J)*0.5,0,1);
        end
      end
    end
    local T,J=ipairs,G.beams;
    for d,e in T(J)do
      d,G=e.beam,n;
      G.FxDepth(d,C.Always);
      if not C.Lines then
        d.Enabled=false;
      else
        local T,n=math.min(e.a.horizon,e.b.horizon),math.clamp((B-e.delay)/0.7,0,1);
        local J=Y*T*n*s;
        T=J>0.02;
        if d.Enabled~=T then
          d.Enabled=T;
        end
        if T then
          n=math.clamp(1-J*1.35,0.42,0.9);
          if math.abs(n-e.shown)>0.015 then
            e.shown=n;
            d.Transparency=P(n);
          end
          local s=4*y;
          if e.wide~=s then
            e.wide=s;
            d.Width0=s;
            d.Width1=s;
          end
          if e.natural~=r or e.tone~=C.Line then
            e.natural=r;
            e.tone=C.Line;
            d.Color=r and ColorSequence.new(e.a.tint:Lerp(C.Line,0.55),e.b.tint:Lerp(C.Line,0.55))or ColorSequence.new(C.Line);
          end
        end
      end
    end;
  end;
end
