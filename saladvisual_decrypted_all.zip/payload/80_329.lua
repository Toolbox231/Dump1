-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #329
-- offset 3391126..3391490 (364 bytes, type=payload)

local function wP(VP,_P)
  local uP={};
  VP=s[87]();
  _P=_P and l[383]or l[1329];
  if xP[l[404]]==_P then
    return;
  end
  xP[l[404]]=_P;
  if _P then
    IP();
    iP[l[1324]]=l[383];
    kP[l[1324]]=l[383];
    tP[l[1690]]=VP[l[1689]][l[772]]();
    if vP then
      vP[l[1324]]=l[383];
    end
    EP();
    XP();
    y[21](iP);
    uP[1]=(y[10][l[1119]]:Connect(gP));
    WP=uP[1];
  else
    XP();
    V();
    y[20](iP);
    kP[l[1324]]=l[1329];
  end
  RP();
end
