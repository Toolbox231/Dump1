-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[61] / function #79
-- offset 129810..130075 (265 bytes, type=payload)

local function m(O,B)
  local A=TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out);
  while O.alive()and B.Parent and B.Parent.Parent do
    for w,w in ipairs(J)do
      if not O.alive() then
        return;
      end
      l:Create(B,A,{OutlineColor=w}):Play();
      task.wait(0.5);
    end;
  end;
end
