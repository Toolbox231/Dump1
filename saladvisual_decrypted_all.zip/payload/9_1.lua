-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[9] / function #1
-- offset 3629061..3634772 (5711 bytes, type=payload)

function(s,s,l,l)
  local l=s[1];
  local L=s[2];
  local y=s[3];
  local z=s[4];
  local T=s[5];
  local n=s[6];
  local J=s[7];
  local H=s[8];
  local f=s[9];
  return function()
    local s=game:GetService("UserInputService");
    local a;
    local a,d,P,Z,G=l,{},false,false;
    local l,Y,e=false;
    local j,C,N=4,8,2;
    local q=Color3.fromRGB(255,255,255);
    local b,D,p,r=Color3.fromRGB(0,0,0),0,0;
    local K,o,c={},{},{0,0,0,0};
    local function m()
      local S=a.Character;
      if S and(S:FindFirstChild("Gun")) then
        return true;
      end
      return false;
    end
    local function S()
      for O=1,8,1 do
        local B;
        local B=L;
        local L=B("Line");
        L.Visible=false;
        L.Color=O%2==0 and b or q;
        L.Thickness=O%2==0 and N+2 or N;
        L.Transparency=1;
        L.ZIndex=O%2==0 and 999 or 1000;
        d[O]=L;
      end;
    end
    local function L()
      local O=#d;
      for B=1,O,1 do
        local O=d[B];
        if O then
          local O;
          local O=y;
          O(d[B]);
          d[B]=nil;
        end
      end;
    end
    local function y(O,B)
      l=if B==nil then(m())else B;
      local B=O and P and l;
      for O=1,#d,1 do
        if d[O] then
          d[O].Visible=B;
        end
      end;
    end
    local O,B=setmetatable,{__mode="k"};
    local A,w=O({},B),0;
    local function F()
      local h;
      local h=z[4][z[6]]and P and Z and m();
      if not h then
        return;
      end
      h=a:FindFirstChild("PlayerGui");
      local W=h and(h:FindFirstChild("GameTopbar"));
      h=W and(W:FindFirstChild("Crosshair"));
      W=h and(h:IsA("GuiObject"));
      if W then
        if A[h]==nil then
          A[h]=h.Visible;
        end
        Y=h;
        h.Visible=false;
      end
    end
    local function h()
      for W,V in pairs(A)do
        if W.Parent then
          W.Visible=V;
        end
        A[W]=nil;
      end;
      Y=nil;
    end
    local Y;
    local function A()
      local W=Y;
      if W then
        return;
      end
      local W=a:GetMouse();
      local V,_=pcall(W.GetPropertyChangedSignal,W,"Icon");
      if not V then
        return;
      end
      Y=_:Connect(function()
        if W.Icon~="" then
          W.Icon="";
        end
      end);
    end
    local function W()
      local V=Y;
      if V then
        Y:Disconnect();
        Y=nil;
      end
    end
    local function Y(V)
      local _=a:GetMouse();
      local X;
      local X=z[4][z[6]]and P and Z and V and m();
      if X then
        A();
        V=G==nil;
        if V then
          G=_.Icon;
        end
        if _.Icon~="" then
          _.Icon="";
        end
        F();
      else
        W();
        local A,V=G~=nil;
        if A then
          local X;
          local X=T;
          V=not X.Lib.cursor;
        else
          V=A;
        end
        if V then
          _.Icon=G;
        end
        G=nil;
        h();
      end
    end
    local function T(G)
      local A=not P or#d==0;
      if A then
        return;
      end
      A=m();
      l=A;
      Y(A);
      if not A then
        y(false,A);
        return;
      end
      local V=s:GetMouseLocation();
      local s,_,X=V.X,V.Y,D>0;
      if X then
        V=p;
        p=(V+G*D*100)%360;
      else
        p=0;
      end
      V,X,G=math.rad(p),math.cos,math.sin;
      c[1]=V;
      c[2]=1.5707963267948966+V;
      c[3]=3.141592653589793+V;
      c[4]=4.71238898038469+V;
      for p=1,4,1 do
        local x,k=c[p],(p-1)*2+1;
        V,p=k+1,j;
        local c,v=s+p*X(x),j;
        local p,I,i,E,Q,t,R=_+v*G(x),s+(j+C)*X(x),_+(j+C)*G(x),s+(j-1)*X(x),_+(j-1)*G(x),s+(j+C+1)*X(x),_+(j+C+1)*G(x);
        if d[k] then
          d[k].From=Vector2.new(c,p);
          d[k].To=Vector2.new(I,i);
        end
        if d[V] then
          d[V].From=Vector2.new(E,Q);
          d[V].To=Vector2.new(t,R);
        end
      end;
      y(true,A);
    end
    local function s()
      local G=r;
      if G then
        return;
      end
      w+=1;
      local p=w;
      if #d==0 then
        S();
      end
      local c;
      G=n;
      r=G.RenderStepped:Connect(T);
      local function T(n,c)
        local S;
        local S=not z[4][z[6]]or not P or p~=w or not n;
        if S then
          return;
        end
        S=o[c];
        if S and S.container==n then
          return;
        end
        if S then
          S.add:Disconnect();
          S.remove:Disconnect();
        end
        local function S(A)
          local V=A.Name~="Gun"or not z[4][z[6]]or p~=w;
          if V then
            return;
          end
          A=m();
          y(true,A);
          Y(A);
        end
        o[c]={container=n,add=n.ChildAdded:Connect(S),remove=n.ChildRemoved:Connect(S)};
      end
      G=not e;
      if G then
        local n=a:FindFirstChild("PlayerGui");
        if n then
          e=n.DescendantAdded:Connect(function(n)
            local c=n.Name=="Crosshair"and n.Parent and n.Parent.Name=="GameTopbar";
            if c then
              local c;
              local c=z[4][z[6]]and P and Z and n:IsA("GuiObject");
              if c then
                F();
              end
            end
          end);
        end
      end
      G=a.Character;
      if G then
        T(G,"character");
      end
      G=a:FindFirstChildOfClass("Backpack");
      if G then
        T(G,"backpack");
      end
      G=a.CharacterAdded:Connect(function(n)
        task.wait(0.3);
        local c;
        local c=not z[4][z[6]]or not P or p~=w or a.Character~=n;
        if c then
          return;
        end
        T(n,"character");
        T(a:FindFirstChildOfClass("Backpack"),"backpack");
        l=m();
        y(true,l);
        Y(l and Z);
      end);
      table.insert(K,G);
      table.insert(K,a.ChildAdded:Connect(function(z)
        if z:IsA("Backpack") then
          T(z,"backpack");
        end
      end));
      l=m();
      y(true,l);
      Y(l and Z);
    end
    local function l()
      w+=1;
      local z=r;
      if z then
        pcall(function()
          r:Disconnect();
        end);
        r=nil;
      end
      z=e;
      if z then
        pcall(function()
          e:Disconnect();
        end);
        e=nil;
      end
      z=K;
      for T,T in ipairs(z)do
        pcall(function()
          T:Disconnect();
        end);
      end;
      K={};
      for z,T in pairs(o)do
        T.add:Disconnect();
        T.remove:Disconnect();
        o[z]=nil;
      end;
      y(false);
      Y(false);
      h();
      L();
    end
    local L;
    B=J;
    O=B.Screen:AddLabel("Enabled");
    O:AddToggle({Name="crosshair",Default=false,Flag="crosshair",Callback=function(L)
      P=L;
      if L then
        s();
      else
        l();
      end
    end});
    B=O:AddOption(1);
    local s,L=B:AddLabel("Hide Default"),{Name="hide original",Default=false,Flag="crosshair_hide_original"};
    L.Callback=function(y)
      Z=y;
      Y(y);
    end;
    s:AddToggle(L);
    local s,L=B:AddLabel("Gap"),{Min=0,Max=20,Default=4,Rounding=0,Size=100,Flag="crosshair_gap"};
    L.Callback=function(y)
      j=y;
    end;
    s:AddSlider(L);
    local s,L=B:AddLabel("Line"),{Min=2,Max=30,Default=8,Rounding=0,Size=100,Flag="crosshair_length"};
    L.Callback=function(y)
      C=y;
    end;
    s:AddSlider(L);
    local L,y=B:AddLabel("Thickness"),{Min=1,Max=5,Default=2,Rounding=0,Size=100,Flag="crosshair_thickness"};
    y.Callback=function(z)
      N=z;
      for T=1,#d,1 do
        if d[T] then
          d[T].Thickness=T%2==0 and z+2 or z;
        end
      end;
    end;
    L:AddSlider(y);
    local L,y=B:AddLabel("Rotation"),{Min=0,Max=10,Default=0,Rounding=0,Size=100,Flag="crosshair_rotation"};
    y.Callback=function(z)
      D=z;
    end;
    L:AddSlider(y);
    local L,y=B:AddLabel("Line"),{Default=q,Flag="crosshair_color"};
    y.Callback=function(z)
      q=z;
      for T=1,#d,1 do
        if d[T]and T%2==1 then
          d[T].Color=z;
        end
      end;
    end;
    L:AddColorPicker(y);
    local L,y=B:AddLabel("Outline"),{Default=b,Flag="crosshair_outline_color"};
    y.Callback=function(z)
      b=z;
      for T=1,#d,1 do
        if d[T]and T%2==0 then
          d[T].Color=z;
        end
      end;
    end;
    L:AddColorPicker(y);
    local L;
    local L,y=H;
    s=f;
    L.ClearCrosshair=s("crosshair",function()
      P=false;
      l();
      W();
    end);
  end;
end
