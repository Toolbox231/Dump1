-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #17
-- offset 8992..11633 (2641 bytes, type=payload)

local function c(m,S)
  local O;
  local O=z[4][z[6]];
  if not O then
    return;
  end
  local B=j[e.Style]or j[Y];
  local j,A=s(B),0;
  local s,w=1/0;
  for F,h in pairs(b)do
    A+=1;
    if h.born<s then
      s,w=h.born,F;
    else
    end
  end;
  if A>=24 and w then
    w:Destroy();
  end
  O=S or(Vector3.new(0.0,1.0,0.0));
  S=math.abs(O.Y)>0.98 and Vector3.new(1.0,0.0,0.0)or Vector3.new(0.0,1.0,0.0);
  local s=O:Cross(S).Unit;
  local A,w=s:Cross(O).Unit,Instance.new("Part");
  w.Name="VisualsJumpCircle";
  local F;
  local F,h=T;
  S=n;
  w:SetAttribute(F,S);
  w.Anchored=true;
  w.CanCollide=false;
  w.CanQuery=false;
  w.CanTouch=false;
  w.CastShadow=false;
  w.Transparency=1;
  w.Size=Vector3.new(0.2,0.2,0.2);
  w.CFrame=CFrame.fromMatrix(m+O*0.08,s,O,A);
  G[w]=true;
  local function s()
    G[w]=nil;
    b[w]=nil;
  end
  w.Destroying:Once(s);
  w.Parent=workspace;
  local s=Instance.new("SurfaceGui");
  s.Face=Enum.NormalId.Top;
  s.Adornee=w;
  s.AlwaysOnTop=false;
  s.LightInfluence=0;
  s.CanvasSize=Vector2.new(512,512);
  s.Parent=w;
  m=Instance.new("Frame");
  m.BackgroundTransparency,m.Size=1,UDim2.fromScale(0.94,0.94);
  m.Position=UDim2.fromScale(0.03,0.03);
  m.BorderSizePixel=0;
  m.Parent=s;
  O=Instance.new("UICorner");
  O.CornerRadius=UDim.new(1,0);
  O.Parent=m;
  A=Instance.new("UIStroke");
  A.ApplyStrokeMode=Enum.ApplyStrokeMode.Border;
  A.Thickness=7;
  A.Color=e.Color;
  A.Parent=m;
  b[w]={born=os.clock(),life=e.Life,size=e.Size,grow=e.Grow/100,bright=math.clamp(e.Bright/100,0,1),stroke=A,base=w.CFrame,spin=math.rad(e.Spin)};
  w.Size=Vector3.new(e.Size*0.35,0.025,e.Size*0.35);
  l:AddItem(w,e.Life+0.4);
  if not j then
    return w;
  end
  if not pcall(function()local l=Instance.new("Attachment");l.Parent=w;local T,n=math.clamp(e.Bright/100,0,1),Instance.new("ParticleEmitter");n.Texture=j;n.Color=ColorSequence.new(e.Color);n.LightEmission=1;n.LightInfluence=0;n.Rate=0;n.Lifetime=NumberRange.new(e.Life);n.Speed=NumberRange.new(0.01);n.Drag=0;n.Acceleration=Vector3.new(0.0,0.0,0.0);n.VelocityInheritance=0;n.EmissionDirection=Enum.NormalId.Top;n.Rotation=NumberRange.new(0);n.RotSpeed=NumberRange.new(e.Spin);n.ZOffset=0;pcall(function()n.Orientation=Enum.ParticleOrientation.VelocityPerpendicular;end);n.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,e.Size*0.35),NumberSequenceKeypoint.new(0.4,e.Size),NumberSequenceKeypoint.new(1,e.Size*e.Grow/100)});n.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1-T),NumberSequenceKeypoint.new(0.6,1-T*0.55),NumberSequenceKeypoint.new(1,1)});if B.frames and L[B.cols]then pcall(function()n.FlipbookLayout=L[B.cols];n.FlipbookMode=Enum.ParticleFlipbookMode.OneShot;end);end;n.Parent=l;n:Emit(1);s.Enabled=false;end) then
    for s,s in ipairs(w:GetChildren())do
      if s:IsA("Attachment") then
        s:Destroy();
      end
    end;
  end
  return w;
end
