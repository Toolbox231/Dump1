-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[65] / function #31
-- offset 13251..13474 (223 bytes, type=payload)

function(F,h)
  F=not z[4][z[6]]or l[m]~=B;
  if F then
    return;
  end
  if h==Enum.HumanoidStateType.Jumping then
    G(B);
  elseif h==Enum.HumanoidStateType.Freefall then
    B.air=true;
  elseif h==Enum.HumanoidStateType.Landed then
    j(B);
  end
end
