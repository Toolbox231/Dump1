-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[80] / function #881
-- offset 3567147..3567533 (386 bytes, type=payload)

local function d(P)
  local Z=s[87]();
  local G=Z[l[1089]][l[772]](l[37]);
  G[l[382]]=T[l[122]];
  local Y=l[1329];
  local j=P[l[1674]];
  P[l[1674]]=function(P)
    Y=P and l[383]or l[1329];
    if j then
      j(P);
    end
    G:Fire(Y);
  end;
  Z={[l[582]]=function()
    local P=Y;
    return P;
  end,[l[1629]]=function(P,P)
    Y=P;
    G:Fire(P);
  end,[l[34]]=function(P,Y)
    P=s[70](G[l[511]]:Connect(Y));
    return T:AddSignal(s:ZT(P));
  end};
  return Z;
end
