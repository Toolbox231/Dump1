-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #25
-- offset 3669782..3670144 (362 bytes, type=payload)

local function m(F)
  if not l.Alive or S~=l._request or l.PackName~=O then
    return;
  end
  l._packPlayed=F.AnimationPlayed:Connect(function(S)
    if l.PackName~=O then
      return;
    end
    local O,F,h=pcall(function()
      return N(S.Animation.AnimationId),S.Priority.Value;
    end);
    if O and h<=Enum.AnimationPriority.Movement.Value and not c[F] then
      pcall(function()
        S:Stop(0);
      end);
    end
  end);
end
