-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[44] / function #20
-- offset 3620013..3620269 (256 bytes, type=payload)

local function n(P)
  local q=L;
  q:AddPlayerSignal(P,P.CharacterAdded:Connect(function(q)
    if not b(P) then
      return;
    end
    task.delay(1,function()
      local D;
      local D=J[4][J[6]]and s.On and b(P)and P.Parent and P.Character==q and q.Parent;
      if D then
        c(q);
      end
    end);
  end));
end
