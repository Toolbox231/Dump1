-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[84] / function #63
-- offset 3678713..3678928 (215 bytes, type=payload)

function()
  local D=y;
  local p=D.download("https://raw.githubusercontent.com/7yd7/sniper-Emote/refs/heads/test/EmoteSniper.json");
  if p and p~="" then
    return game:GetService("HttpService"):JSONDecode(p).data or{};
  end
end
