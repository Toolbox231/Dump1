-- ===== Luraph v15.1 artifact: recovered code =====
-- entry s[27] / function #6
-- offset 19215..19551 (336 bytes, type=payload)

local function L()
  local y=not c or o>=420;
  if y then
    return nil;
  end
  o+=1;
  y=K[o];
  local m=not y;
  if m then
    y=Instance.new("ImageLabel");
    y.Name="Bloom";
    y.AnchorPoint=Vector2.new(0.5,0.5);
    y.BackgroundTransparency=1;
    y.BorderSizePixel=0;
    y.Image=c;
    y.ResampleMode=Enum.ResamplerMode.Default;
    y.Visible=false;
    y.Parent=r;
    K[o]=y;
  else
  end
  return y;
end
